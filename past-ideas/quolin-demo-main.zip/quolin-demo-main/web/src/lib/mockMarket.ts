export type Candle = { time: number; open: number; high: number; low: number; close: number };
export type Timeframe = "1H" | "4H" | "1D" | "1W";

export const AVAILABLE_PRODUCTS: { symbol: string; label: string; category: string }[] = [
  { symbol: "BTC", label: "Bitcoin", category: "Major" },
  { symbol: "ETH", label: "Ethereum", category: "Major" },
  { symbol: "SOL", label: "Solana", category: "Major" },
  { symbol: "XMR", label: "Monero", category: "Privacy coin" },
  { symbol: "USDT", label: "Tether", category: "Stablecoin" },
  { symbol: "USDC", label: "USD Coin", category: "Stablecoin" },
  { symbol: "BTC3L", label: "BTC 3x Long", category: "Leveraged token" },
];

export const ASSET_NAMES: Record<string, string> = {
  BTC: "Bitcoin",
  ETH: "Ethereum",
  XMR: "Monero",
  USDT: "Tether",
  SOL: "Solana",
  USDC: "USD Coin",
  BTC3L: "BTC 3x Long",
  ETH3L: "ETH 3x Long",
  BTC3S: "BTC 3x Short",
};

const BASE_PRICES: Record<string, number> = {
  BTC: 64000,
  ETH: 3400,
  XMR: 170,
  USDT: 1,
  USDC: 1,
  SOL: 148,
  BTC3L: 42,
  ETH3L: 38,
  BTC3S: 19,
};

const CIRCULATING_SUPPLY: Record<string, number> = {
  BTC: 19_800_000,
  ETH: 120_300_000,
  XMR: 18_450_000,
  USDT: 112_000_000_000,
  USDC: 34_000_000_000,
  SOL: 470_000_000,
  BTC3L: 5_000_000,
  ETH3L: 3_500_000,
  BTC3S: 2_000_000,
};

const BASE_24H_VOLUME_USD: Record<string, number> = {
  BTC: 28_000_000_000,
  ETH: 14_000_000_000,
  XMR: 85_000_000,
  USDT: 55_000_000_000,
  USDC: 5_000_000_000,
  SOL: 3_200_000_000,
  BTC3L: 40_000_000,
  ETH3L: 22_000_000,
  BTC3S: 15_000_000,
};

const VOLATILITY_MULTIPLIER: Record<string, number> = {
  BTC3L: 2.5,
  ETH3L: 2.5,
  BTC3S: 2.5,
  USDT: 0.02,
  USDC: 0.02,
};

const TIMEFRAME_STEP_SECONDS: Record<Timeframe, number> = {
  "1H": 3600,
  "4H": 14400,
  "1D": 86400,
  "1W": 604800,
};

function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function generateCandles(symbol: string, timeframe: Timeframe, count = 120): Candle[] {
  const rand = mulberry32(hashString(symbol + timeframe));
  const step = TIMEFRAME_STEP_SECONDS[timeframe];
  const now = Math.floor(Date.now() / 1000);
  const startTime = now - step * count;
  const volMult = VOLATILITY_MULTIPLIER[symbol] ?? 1;
  let price = BASE_PRICES[symbol] ?? 100;
  const candles: Candle[] = [];
  for (let i = 0; i < count; i++) {
    const open = price;
    const swing = open * 0.015 * volMult;
    const close = Math.max(open + (rand() - 0.5) * swing * 2, open * 0.4);
    const high = Math.max(open, close) + rand() * swing * 0.6;
    const low = Math.max(Math.min(open, close) - rand() * swing * 0.6, 0.0001);
    candles.push({ time: startTime + i * step, open, high, low, close });
    price = close;
  }
  return candles;
}

export function computeStats(candles: Candle[], symbol: string) {
  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2] ?? last;
  const window = candles.slice(-24);
  const high = Math.max(...window.map((c) => c.high));
  const low = Math.min(...window.map((c) => c.low));
  const open = window[0].open;
  const changeAbs = last.close - prev.close;
  const changePct = prev.close === 0 ? 0 : (changeAbs / prev.close) * 100;
  const rand = mulberry32(hashString(symbol + "vol"));
  const volumeUsd = (BASE_24H_VOLUME_USD[symbol] ?? 1_000_000) * (0.9 + rand() * 0.2);
  const marketCapUsd = last.close * (CIRCULATING_SUPPLY[symbol] ?? 1_000_000);
  return { price: last.close, open, high, low, changeAbs, changePct, volumeUsd, marketCapUsd };
}

export function nextTick(symbol: string, price: number): number {
  const volMult = VOLATILITY_MULTIPLIER[symbol] ?? 1;
  return Math.max(price * (1 + (Math.random() - 0.5) * 0.004 * volMult), 0.0001);
}

export function randomQty(price: number): number {
  const raw = (5000 / price) * (0.2 + Math.random() * 1.8);
  return price > 100 ? Number(raw.toFixed(3)) : Number(raw.toFixed(1));
}
