import type { Verdict } from "../api";

export const VERDICT_STYLES: Record<Verdict, { label: string; className: string }> = {
  compliant: { label: "Compliant", className: "border-[var(--positive)] bg-[var(--positive)]/10 text-[var(--positive)]" },
  needs_review: { label: "Needs review", className: "border-[var(--warning)] bg-[var(--warning)]/10 text-[var(--warning)]" },
  non_compliant: { label: "Non-compliant", className: "border-[var(--negative)] bg-[var(--negative)]/10 text-[var(--negative)]" },
};
