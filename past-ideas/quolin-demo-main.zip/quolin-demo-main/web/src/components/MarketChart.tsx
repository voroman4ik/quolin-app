import { useEffect, useMemo, useRef, useState } from "react";
import {
  CandlestickSeries,
  ColorType,
  createChart,
  type IChartApi,
  type ISeriesApi,
  type UTCTimestamp,
} from "lightweight-charts";
import { AVAILABLE_PRODUCTS, ASSET_NAMES, computeStats, generateCandles, type Timeframe } from "../lib/mockMarket";

const TIMEFRAMES: Timeframe[] = ["1H", "4H", "1D", "1W"];

const PRODUCT_CATEGORIES = Array.from(new Set(AVAILABLE_PRODUCTS.map((p) => p.category)));

function formatCompactUsd(value: number): string {
  if (value >= 1_000_000_000) return `$${(value / 1_000_000_000).toFixed(2)}B`;
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(2)}M`;
  if (value >= 1_000) return `$${(value / 1_000).toFixed(1)}K`;
  return `$${value.toFixed(2)}`;
}

function formatPrice(value: number): string {
  return value >= 100 ? value.toLocaleString(undefined, { maximumFractionDigits: 2 }) : value.toFixed(4);
}

export function MarketChart({ initialSymbol }: { initialSymbol: string }) {
  const [symbol, setSymbol] = useState(initialSymbol);
  const [timeframe, setTimeframe] = useState<Timeframe>("1D");

  useEffect(() => {
    setSymbol(initialSymbol);
  }, [initialSymbol]);

  const product = AVAILABLE_PRODUCTS.find((p) => p.symbol === symbol);
  const candles = useMemo(() => generateCandles(symbol, timeframe), [symbol, timeframe]);
  const stats = useMemo(() => computeStats(generateCandles(symbol, "1D"), symbol), [symbol]);

  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const cssVar = (name: string) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();

    const chart = createChart(containerRef.current, {
      autoSize: true,
      height: 320,
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: cssVar("--text-dim"),
        attributionLogo: false,
      },
      grid: { vertLines: { color: cssVar("--border") }, horzLines: { color: cssVar("--border") } },
      timeScale: { borderColor: cssVar("--border") },
      rightPriceScale: { borderColor: cssVar("--border") },
    });
    const series = chart.addSeries(CandlestickSeries, {
      upColor: cssVar("--positive"),
      downColor: cssVar("--negative"),
      borderVisible: false,
      wickUpColor: cssVar("--positive"),
      wickDownColor: cssVar("--negative"),
    });

    chartRef.current = chart;
    seriesRef.current = series;
    return () => {
      chart.remove();
      chartRef.current = null;
      seriesRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!seriesRef.current || !chartRef.current) return;
    seriesRef.current.setData(candles.map((c) => ({ ...c, time: c.time as UTCTimestamp })));
    chartRef.current.timeScale().fitContent();
  }, [candles]);

  const isPositive = stats.changeAbs >= 0;

  return (
    <div className="flex flex-col overflow-hidden rounded-[var(--radius-card)] bg-[var(--panel)]">
      <div className="flex items-center gap-2 bg-[var(--panel-header)] px-6 py-4">
        <h2 className="flex-1 text-base font-semibold text-[var(--text)]">Market</h2>
        <select
          value={symbol}
          onChange={(e) => setSymbol(e.target.value)}
          className="rounded-[var(--radius-input)] border-[0.5px] border-[var(--border-input)] bg-[var(--input-bg)] px-3 py-1.5 text-xs text-[var(--text)] shadow-[var(--shadow-input)] focus:outline-none"
        >
          {PRODUCT_CATEGORIES.map((category) => (
            <optgroup key={category} label={category}>
              {AVAILABLE_PRODUCTS.filter((p) => p.category === category).map((p) => (
                <option key={p.symbol} value={p.symbol}>
                  {p.symbol} · {p.label}
                </option>
              ))}
            </optgroup>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-4 p-6">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-[var(--text)]">
              {symbol} · {ASSET_NAMES[symbol] ?? symbol}
            </span>
            {product && product.category !== "Major" && (
              <span className="rounded-full border border-[var(--accent)] px-2 py-0.5 text-[10px] text-[var(--accent)]">
                {product.category}
              </span>
            )}
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-semibold tabular-nums text-[var(--text)]">${formatPrice(stats.price)}</span>
            <span
              className={`text-sm tabular-nums ${isPositive ? "text-[var(--positive)]" : "text-[var(--negative)]"}`}
            >
              {isPositive ? "+" : ""}
              {stats.changeAbs.toFixed(2)} ({isPositive ? "+" : ""}
              {stats.changePct.toFixed(2)}%)
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 text-xs">
          {[
            ["Open", `$${formatPrice(stats.open)}`],
            ["Low", `$${formatPrice(stats.low)}`],
            ["High", `$${formatPrice(stats.high)}`],
            ["24h Volume", formatCompactUsd(stats.volumeUsd)],
            ["Market Cap", formatCompactUsd(stats.marketCapUsd)],
          ].map(([label, value], i) => (
            <div key={label} className="flex items-center gap-4">
              {i > 0 && <div className="h-8 w-px bg-[var(--border)]" />}
              <div>
                <div className="text-[var(--text-dim)]">{label}</div>
                <div className="mt-0.5 tabular-nums text-[var(--text)]">{value}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex gap-1.5">
          {TIMEFRAMES.map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`rounded-full border-[0.5px] px-3 py-1 text-xs transition-colors ${
                tf === timeframe
                  ? "border-[var(--accent)] bg-[var(--input-bg)] text-[var(--text)]"
                  : "border-[var(--border-input)] bg-[var(--input-bg)] text-[var(--text-dim)] hover:text-[var(--text)]"
              }`}
            >
              {tf}
            </button>
          ))}
        </div>

        <div ref={containerRef} className="h-[320px]" />
      </div>
    </div>
  );
}
