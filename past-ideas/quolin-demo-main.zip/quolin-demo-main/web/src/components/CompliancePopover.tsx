import { useRef, useState } from "react";
import type { ReactNode } from "react";
import { createPortal } from "react-dom";
import type { ComplianceSource } from "../api";

// Rendered via a portal (rather than positioned inline) because every trigger
// here sits inside ClientRow's accordion body, which is permanently
// overflow-hidden (it's how the expand/collapse height animation works) -
// an inline-positioned popup would get clipped the moment it crossed that
// boundary.
export function CompliancePopover({ source, children }: { source?: ComplianceSource; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [coords, setCoords] = useState<{ top: number; left: number } | null>(null);
  const anchorRef = useRef<HTMLSpanElement>(null);

  function show() {
    const rect = anchorRef.current?.getBoundingClientRect();
    if (!rect) return;
    const width = 320;
    setCoords({
      top: rect.bottom + 6,
      left: Math.min(rect.left, window.innerWidth - width - 12),
    });
    setOpen(true);
  }

  function hide() {
    setOpen(false);
  }

  if (!source) return <>{children}</>;

  const sectionOrPage = [source.documentSection, source.documentPage].filter(Boolean).join(" · ");

  return (
    <>
      <span
        ref={anchorRef}
        onMouseEnter={show}
        onMouseLeave={hide}
        onFocus={show}
        onBlur={hide}
        tabIndex={0}
        className="cursor-help underline decoration-dotted decoration-[var(--text-dim-2)] underline-offset-2 outline-none"
      >
        {children}
      </span>
      {open &&
        coords &&
        createPortal(
          <div
            role="tooltip"
            onMouseEnter={show}
            onMouseLeave={hide}
            className="fixed z-50 w-80 rounded-[var(--radius-input)] border-[0.5px] border-[var(--border-input)] bg-[var(--panel-header)] p-3 text-xs shadow-[var(--shadow-input)]"
            style={{ top: coords.top, left: coords.left }}
          >
            <div className="font-medium text-[var(--text)]">{source.regimeName}</div>
            <div className="mt-0.5 text-[var(--text-dim)]">
              {source.regulator}
              {source.jurisdiction ? ` · ${source.jurisdiction}` : ""}
            </div>

            {source.legalBasisCitation && (
              <div className="mt-2 text-[var(--text-dim)]">
                <span className="text-[var(--text-dim-2)]">Legal basis — </span>
                {source.legalBasisCitation}
              </div>
            )}

            <div className="mt-1 text-[var(--text-dim)]">
              <span className="text-[var(--text-dim-2)]">Section/page — </span>
              {sectionOrPage || "not paginated / no fixed section"}
            </div>

            {source.sourceCodeFile && source.sourceCodeLines && (
              <div className="mt-1 text-[var(--text-dim)]">
                <span className="text-[var(--text-dim-2)]">Implemented at — </span>
                {source.sourceCodeFile}:{source.sourceCodeLines}
              </div>
            )}

            {source.penaltySummary && (
              <div className="mt-1 text-[var(--text-dim)]">
                <span className="text-[var(--text-dim-2)]">Penalty — </span>
                {source.penaltySummary}
              </div>
            )}

            {source.documentUrl ? (
              <a
                href={source.documentUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-2 inline-block text-[var(--accent)] hover:underline"
              >
                View source on {new URL(source.documentUrl).hostname} ↗
              </a>
            ) : (
              <div className="mt-2 text-[var(--text-dim-2)]">No external document (internal/demo-only citation)</div>
            )}

            {source.notes && (
              <div className="mt-2 border-t border-[var(--border)] pt-2 text-[10px] text-[var(--text-dim-2)]">
                {source.notes}
              </div>
            )}
          </div>,
          document.body,
        )}
    </>
  );
}
