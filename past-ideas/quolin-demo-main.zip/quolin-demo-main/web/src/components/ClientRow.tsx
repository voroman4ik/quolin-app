import iconCaretDown from "../assets/figma/icon-caret-down.svg";
import type { Client } from "../api";
import { VERDICT_STYLES } from "../lib/verdict";
import { CompliancePopover } from "./CompliancePopover";
import { DecisionTreeView } from "./DecisionTreeView";

// Shared column template so the collapsed rows and the header label row
// above them line up exactly, regardless of each row's own content height.
export const CLIENT_ROW_GRID =
  "grid-cols-[28px_minmax(180px,1.3fr)_minmax(130px,0.9fr)_112px_minmax(150px,1fr)_minmax(220px,1.6fr)]";

function TradeHistoryTable({ history }: { history: Client["tradeHistory"] }) {
  return (
    <div>
      <div className="mb-2 text-xs font-medium text-[var(--text-dim)]">Trade history</div>
      <div className="overflow-hidden rounded-[var(--radius-input)] border-[0.5px] border-[var(--border-input)]">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-[var(--input-bg)] text-[var(--text-dim)]">
              <th className="px-3 py-2 text-left font-normal">Date</th>
              <th className="px-3 py-2 text-left font-normal">Asset</th>
              <th className="px-3 py-2 text-left font-normal">Side</th>
              <th className="px-3 py-2 text-right font-normal">Notional</th>
              <th className="px-3 py-2 text-right font-normal">Verdict</th>
            </tr>
          </thead>
          <tbody>
            {history.map((h) => (
              <tr key={h.id} className="border-t border-[var(--border)]">
                <td className="px-3 py-2 text-[var(--text-dim)]">{new Date(h.timestamp).toLocaleDateString()}</td>
                <td className="px-3 py-2 text-[var(--text)]">{h.asset}</td>
                <td className="px-3 py-2 capitalize text-[var(--text)]">{h.side}</td>
                <td className="px-3 py-2 text-right tabular-nums text-[var(--text)]">${h.notionalUsd.toLocaleString()}</td>
                <td className="px-3 py-2 text-right">
                  <span className={`rounded px-1.5 py-0.5 text-[10px] font-medium ${VERDICT_STYLES[h.verdict].className}`}>
                    {VERDICT_STYLES[h.verdict].label}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function HoldingsTable({ holdings }: { holdings: Client["holdings"] }) {
  return (
    <div>
      <div className="mb-2 text-xs font-medium text-[var(--text-dim)]">Holdings</div>
      <div className="overflow-hidden rounded-[var(--radius-input)] border-[0.5px] border-[var(--border-input)]">
        <table className="w-full text-xs">
          <thead>
            <tr className="bg-[var(--input-bg)] text-[var(--text-dim)]">
              <th className="px-3 py-2 text-left font-normal">Asset</th>
              <th className="px-3 py-2 text-right font-normal">Quantity</th>
              <th className="px-3 py-2 text-right font-normal">Value</th>
            </tr>
          </thead>
          <tbody>
            {holdings.map((h) => (
              <tr key={h.asset} className="border-t border-[var(--border)]">
                <td className="px-3 py-2 text-[var(--text)]">{h.asset}</td>
                <td className="px-3 py-2 text-right tabular-nums text-[var(--text)]">{h.quantity.toLocaleString()}</td>
                <td className="px-3 py-2 text-right tabular-nums text-[var(--text)]">${h.valueUsd.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function RegimeDetail({ rules, jurisdiction }: { rules: Client["applicableRules"]; jurisdiction: string }) {
  return (
    <div>
      <div className="mb-2 text-xs font-medium text-[var(--text-dim)]">
        Applicable compliance rules · {jurisdiction}
        <span className="ml-1.5 text-[var(--text-dim-2)]">(hover a rule for its source)</span>
      </div>
      <div className="flex flex-col gap-2">
        {rules.length === 0 && (
          <div className="text-[var(--text-dim-2)]">No rules matched this client's jurisdiction/company-type classifiers.</div>
        )}
        {rules.map((rule) => (
          <div
            key={rule.regimeId}
            className="rounded-[var(--radius-input)] border-[0.5px] border-[var(--border-input)] bg-[var(--input-bg)] px-3 py-2 text-xs"
          >
            <div className="font-medium text-[var(--text)]">
              <CompliancePopover source={rule}>{rule.regimeName}</CompliancePopover>
            </div>
            <div className="mt-0.5 text-[var(--text-dim)]">
              {rule.regulator}
              {rule.companyTypes.length > 0 ? ` · applies to ${rule.companyTypes.join(", ")}` : ""}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ClientRow({
  client,
  isExpanded,
  onToggle,
  flashNodeId,
}: {
  client: Client;
  isExpanded: boolean;
  onToggle: () => void;
  flashNodeId: string | null;
}) {
  const verdictStyle = VERDICT_STYLES[client.currentEvaluation.verdict];
  const holdingsTotal = client.holdings.reduce((sum, h) => sum + h.valueUsd, 0);

  return (
    <div className="overflow-hidden rounded-[var(--radius-card)] bg-[var(--panel)]">
      <button
        onClick={onToggle}
        aria-expanded={isExpanded}
        className={`grid w-full items-center gap-4 px-4 py-3 text-left ${CLIENT_ROW_GRID}`}
      >
        <img
          src={iconCaretDown}
          alt=""
          className={`size-4 shrink-0 transition-transform duration-200 ${isExpanded ? "rotate-180" : ""}`}
        />
        <div className="min-w-0">
          <div className="truncate text-sm font-medium text-[var(--text)]">{client.name}</div>
          <div className="truncate text-xs text-[var(--text-dim)]">
            {client.jurisdiction} · {client.primaryExchange}
          </div>
        </div>
        <div className="truncate text-xs text-[var(--text)]">
          {client.currentTrade.asset} · ${client.currentTrade.notionalUsd.toLocaleString()}
        </div>
        <span className={`w-fit rounded px-1.5 py-0.5 text-[10px] font-medium ${verdictStyle.className}`}>
          {verdictStyle.label}
        </span>
        <div className="truncate text-xs text-[var(--text-dim)]">
          {client.holdings.length} positions · ${holdingsTotal.toLocaleString()}
        </div>
        <div className="flex flex-wrap gap-1.5">
          {client.regulatorySources.map((source) => (
            <span
              key={source.name}
              className="rounded-full border border-[var(--accent)] px-2 py-0.5 text-[10px] text-[var(--accent)]"
            >
              {source.name}
            </span>
          ))}
        </div>
      </button>

      <div
        className="grid transition-[grid-template-rows] duration-300 ease-out"
        style={{ gridTemplateRows: isExpanded ? "1fr" : "0fr" }}
      >
        <div className="overflow-hidden">
          <div className="flex flex-col gap-6 border-t border-[var(--border)] p-6">
            <DecisionTreeView result={client.currentEvaluation} flashNodeId={flashNodeId} />
            <TradeHistoryTable history={client.tradeHistory} />
            <HoldingsTable holdings={client.holdings} />
            <RegimeDetail rules={client.applicableRules} jurisdiction={client.jurisdiction} />
          </div>
        </div>
      </div>
    </div>
  );
}
