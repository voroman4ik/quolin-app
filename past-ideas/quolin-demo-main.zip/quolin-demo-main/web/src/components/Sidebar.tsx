import logo from "../assets/figma/logo.svg";
import iconWatchlist from "../assets/figma/icon-watchlist.svg";
import iconMarkets from "../assets/figma/icon-markets.svg";
import iconDashboard from "../assets/figma/icon-dashboard.svg";
import iconWallet from "../assets/figma/icon-wallet.svg";
import iconCommunity from "../assets/figma/icon-community.svg";
import iconSettings from "../assets/figma/icon-settings.svg";
import iconMail from "../assets/figma/icon-mail.svg";
import iconHelp from "../assets/figma/icon-help.svg";

export type TabId = "dashboard" | "quolin";

const TOP_ICONS = [
  { icon: iconWatchlist, label: "Watchlist" },
  { icon: iconMarkets, label: "Markets" },
  { icon: iconDashboard, label: "Dashboard", tab: "dashboard" as TabId },
  { icon: logo, label: "Quolin", tab: "quolin" as TabId },
  { icon: iconWallet, label: "Wallet" },
  { icon: iconCommunity, label: "Community" },
];

const BOTTOM_ICONS = [
  { icon: iconSettings, label: "Settings" },
  { icon: iconMail, label: "Messages" },
  { icon: iconHelp, label: "Help" },
];

export function Sidebar({
  activeTab,
  onSelectTab,
}: {
  activeTab: TabId;
  onSelectTab: (tab: TabId) => void;
}) {
  return (
    <aside className="flex w-16 shrink-0 flex-col items-center gap-6 border-r border-[var(--accent)] bg-[var(--bg)] px-2 py-4">
      <img src={logo} alt="Quolin" className="size-8" />

      <nav className="flex flex-1 flex-col items-center gap-4 pt-16">
        {TOP_ICONS.map(({ icon, label, tab }) => (
          <button
            key={label}
            title={label}
            onClick={tab ? () => onSelectTab(tab) : undefined}
            className={`relative flex size-12 items-center justify-center rounded-full p-3 transition-colors ${
              tab && activeTab === tab
                ? "border border-[rgba(45,202,255,0.25)] bg-[radial-gradient(circle,rgba(45,202,255,0.35)_0%,rgba(45,202,255,0.08)_70%)]"
                : "hover:bg-white/5"
            }`}
          >
            <img src={icon} alt="" className="size-6" />
          </button>
        ))}
      </nav>

      <div className="flex flex-col items-center gap-4">
        {BOTTOM_ICONS.map(({ icon, label }) => (
          <button
            key={label}
            title={label}
            className="flex size-12 items-center justify-center rounded-full p-3 hover:bg-white/5"
          >
            <img src={icon} alt="" className="size-6" />
          </button>
        ))}
      </div>
    </aside>
  );
}
