import type { EvaluationResult } from "../api";
import { VERDICT_STYLES } from "../lib/verdict";
import { CompliancePopover } from "./CompliancePopover";

export function DecisionTreeView({
  result,
  flashNodeId,
}: {
  result: EvaluationResult;
  flashNodeId: string | null;
}) {
  const verdictStyle = VERDICT_STYLES[result.verdict];

  return (
    <div className="flex flex-col">
      {result.trace.map((step) => {
        const escalated = step.result;
        const isFlashing = step.nodeId === flashNodeId;
        return (
          <div key={step.nodeId} className="relative flex gap-3 pb-4">
            <div className="flex flex-col items-center">
              <div
                className={`h-2.5 w-2.5 shrink-0 rounded-full border-2 ${
                  escalated
                    ? "border-[var(--warning)] bg-[var(--warning)]/30"
                    : "border-[var(--border)] bg-[var(--input-bg)]"
                }`}
              />
              <div className="w-px grow bg-[var(--border)]" />
            </div>
            <div
              className={`-mt-1 flex-1 rounded-[var(--radius-input)] border-[0.5px] px-3 py-2 text-xs shadow-[var(--shadow-input)] transition-all duration-500 ${
                isFlashing
                  ? "border-[var(--warning)] bg-[var(--warning)]/10"
                  : "border-[var(--border-input)] bg-[var(--input-bg)]"
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-[var(--text)]">{step.description}</span>
                <span
                  className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] font-medium ${
                    escalated ? "bg-[var(--warning)]/20 text-[var(--warning)]" : "bg-[var(--border)] text-[var(--text-dim)]"
                  }`}
                >
                  {escalated ? "triggered" : "clear"}
                </span>
              </div>
              {step.citation && (
                <div className="mt-1 text-[10px] text-[var(--text-dim)]">
                  <CompliancePopover source={step.source}>{step.citation}</CompliancePopover>
                </div>
              )}
            </div>
          </div>
        );
      })}

      <div className="flex gap-3">
        <div className="flex flex-col items-center">
          <div className="h-2.5 w-2.5 shrink-0 rounded-full border-2 border-[var(--text)] bg-[var(--text)]" />
        </div>
        <div className={`-mt-1 flex-1 rounded-[var(--radius-input)] border px-3 py-2.5 text-xs font-medium ${verdictStyle.className}`}>
          <div className="text-[10px] font-semibold uppercase tracking-wide opacity-80">{verdictStyle.label}</div>
          <div className="mt-0.5 text-[var(--text)]">{result.leafDescription}</div>
        </div>
      </div>
    </div>
  );
}
