import { useEffect, useRef, useState } from "react";
import iconMenu from "../assets/figma/icon-menu.svg";
import { computeStats, generateCandles, nextTick, randomQty } from "../lib/mockMarket";

type Row = { id: string; time: string; price: number; qty: number; up: boolean };

export function TimeAndSales({ symbol }: { symbol: string }) {
  const [rows, setRows] = useState<Row[]>([]);
  const priceRef = useRef(0);

  useEffect(() => {
    priceRef.current = computeStats(generateCandles(symbol, "1D"), symbol).price;
    setRows([]);

    const interval = setInterval(() => {
      const price = nextTick(symbol, priceRef.current);
      const up = price >= priceRef.current;
      const qty = randomQty(price);
      priceRef.current = price;
      setRows((prev) =>
        [{ id: crypto.randomUUID(), time: new Date().toLocaleTimeString(), price, qty, up }, ...prev].slice(0, 40),
      );
    }, 1200);

    return () => clearInterval(interval);
  }, [symbol]);

  return (
    <div className="flex flex-col overflow-hidden rounded-[var(--radius-card)] bg-[var(--panel)]">
      <div className="flex items-center gap-2 bg-[var(--panel-header)] px-6 py-4">
        <h2 className="flex-1 text-base font-semibold text-[var(--text)]">Time &amp; Sales</h2>
        <img src={iconMenu} alt="" className="size-4" />
      </div>

      <div className="max-h-[280px] overflow-y-auto p-6 pt-4">
        <div className="flex flex-col gap-2.5">
          {rows.length === 0 ? (
            <div className="py-6 text-center text-[10px] text-[var(--text-dim)]">Waiting for trades…</div>
          ) : (
            rows.map((row) => (
              <div key={row.id} className="flex items-center justify-between text-xs tabular-nums">
                <span className="text-[var(--text-dim)]">{row.time}</span>
                <span className={row.up ? "text-[var(--positive)]" : "text-[var(--negative)]"}>
                  {row.price >= 100 ? row.price.toLocaleString(undefined, { maximumFractionDigits: 2 }) : row.price.toFixed(4)}
                </span>
                <span className="text-[var(--text)]">{row.qty}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
