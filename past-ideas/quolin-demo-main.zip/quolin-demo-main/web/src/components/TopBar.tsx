import avatar from "../assets/figma/avatar.png";
import iconBell from "../assets/figma/icon-bell.svg";
import iconCaretDown from "../assets/figma/icon-caret-down.svg";
import iconSearch from "../assets/figma/icon-search.svg";

export function TopBar({ feedConnected }: { feedConnected: boolean }) {
  return (
    <header className="flex items-center justify-between gap-6 border-b border-[var(--border)] bg-[var(--bg)] p-4">
      <div className="flex flex-1 items-center gap-6">
        <div className="flex items-center gap-1">
          <img src={iconCaretDown} alt="" className="size-4" />
          <div className="flex items-center gap-2 rounded-2xl">
            <img src={avatar} alt="" className="size-6 rounded-full" />
            <div className="flex flex-col leading-tight">
              <span className="text-sm text-[var(--text)]">Compliance Desk</span>
              <span className="text-xs text-[var(--text-dim)]">Account: DEMO-0001</span>
            </div>
          </div>
        </div>
        <div className="h-4 w-px bg-[var(--border)]" />
        <img src={iconBell} alt="Notifications" className="size-4" />

        <div className="flex items-center gap-8">
          <div className="flex flex-col justify-center">
            <span className="text-xs text-[var(--text-dim)]">Portfolio Balance</span>
            <span className="text-sm text-[var(--text)]">$18,452,910.00</span>
          </div>
          <div className="flex flex-col justify-center">
            <span className="text-xs text-[var(--text-dim)]">Available Funds</span>
            <span className="text-sm text-[var(--text)]">$4,210,338.00</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--panel)] px-3 py-1.5 text-xs text-[var(--text-dim)]">
          <span
            className={`h-1.5 w-1.5 rounded-full ${
              feedConnected ? "bg-[var(--positive)]" : "bg-[var(--text-dim)]"
            }`}
          />
          Regulatory feed {feedConnected ? "monitoring live" : "connecting…"}
        </div>
        <div className="flex h-8 w-[225px] items-center gap-3 overflow-hidden rounded-md border-[0.5px] border-[var(--border-input)] bg-[var(--input-bg)] px-3">
          <img src={iconSearch} alt="" className="size-4" />
          <span className="text-sm text-[var(--text-dim)]">Search</span>
        </div>
      </div>
    </header>
  );
}
