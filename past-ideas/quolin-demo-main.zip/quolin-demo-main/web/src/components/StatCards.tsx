import { useEffect, useState } from "react";

type Stat = {
  label: string;
  value: number;
  prefix?: string;
  suffix?: string;
  driftPct: number;
  tone?: "positive" | "negative";
};

const INITIAL_STATS: Stat[] = [
  { label: "24h P&L", value: 128_640, prefix: "$", driftPct: 0.003, tone: "positive" },
  { label: "Open positions", value: 37, driftPct: 0 },
  { label: "Trades pending review", value: 2, driftPct: 0, tone: "negative" },
  { label: "Jurisdictions monitored", value: 6, driftPct: 0 },
];

function formatValue(stat: Stat) {
  const value = Math.round(stat.value).toLocaleString();
  return `${stat.prefix ?? ""}${value}${stat.suffix ?? ""}`;
}

export function StatCards() {
  const [stats, setStats] = useState(INITIAL_STATS);

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) =>
        prev.map((stat) =>
          stat.driftPct
            ? { ...stat, value: stat.value * (1 + (Math.random() - 0.5) * stat.driftPct) }
            : stat,
        ),
      );
    }, 2200);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="rounded-[var(--radius-card)] border border-[var(--border)] bg-[var(--panel)] px-4 py-3"
        >
          <div className="text-xs text-[var(--text-dim)]">{stat.label}</div>
          <div
            className={`mt-1 text-lg font-medium tabular-nums ${
              stat.tone === "positive"
                ? "text-[var(--positive)]"
                : stat.tone === "negative"
                  ? "text-[var(--warning)]"
                  : "text-[var(--text)]"
            }`}
          >
            {formatValue(stat)}
          </div>
        </div>
      ))}
    </div>
  );
}
