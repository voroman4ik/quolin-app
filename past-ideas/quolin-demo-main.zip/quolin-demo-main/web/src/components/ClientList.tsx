import type { Client } from "../api";
import { CLIENT_ROW_GRID, ClientRow } from "./ClientRow";

const COLUMN_LABELS = ["", "Client", "Current trade", "Verdict", "Holdings", "Regulatory sources"];

export function ClientList({
  clients,
  expandedClientId,
  onToggle,
  flashNodeId,
}: {
  clients: Client[];
  expandedClientId: string | null;
  onToggle: (id: string) => void;
  flashNodeId: string | null;
}) {
  return (
    <div className="overflow-x-auto">
      <div className="flex min-w-fit flex-col gap-3">
        <div className={`hidden gap-4 px-4 text-[10px] font-medium uppercase tracking-wide text-[var(--text-dim)] sm:grid ${CLIENT_ROW_GRID}`}>
          {COLUMN_LABELS.map((label, i) => (
            <span key={i}>{label}</span>
          ))}
        </div>
        {clients.map((client) => (
          <ClientRow
            key={client.id}
            client={client}
            isExpanded={client.id === expandedClientId}
            onToggle={() => onToggle(client.id)}
            flashNodeId={flashNodeId}
          />
        ))}
      </div>
    </div>
  );
}
