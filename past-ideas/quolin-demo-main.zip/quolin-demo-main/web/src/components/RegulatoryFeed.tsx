import iconMenu from "../assets/figma/icon-menu.svg";

export type FeedEntry = { id: string; summary: string; citation: string; time: string };

export function RegulatoryFeed({ entries }: { entries: FeedEntry[] }) {
  return (
    <div className="flex flex-col overflow-hidden rounded-[var(--radius-card)] bg-[var(--panel)]">
      <div className="flex items-center gap-2 bg-[var(--panel-header)] px-6 py-4">
        <div className="flex-1">
          <h2 className="text-base font-semibold text-[var(--text)]">Regulatory update log</h2>
          <p className="text-xs text-[var(--text-dim)]">Rule-impacting changes applied to the decision tree</p>
        </div>
        <img src={iconMenu} alt="" className="size-4" />
      </div>

      <div className="flex flex-col gap-2 p-6">
        {entries.length === 0 ? (
          <div className="rounded-[var(--radius-input)] border border-dashed border-[var(--border)] px-3 py-4 text-center text-[10px] text-[var(--text-dim)]">
            No rule-impacting changes detected yet
          </div>
        ) : (
          entries.map((entry) => (
            <div
              key={entry.id}
              className="animate-[fadeIn_0.4s_ease] rounded-[var(--radius-input)] border-[0.5px] border-[var(--warning)]/40 bg-[var(--warning)]/5 px-3 py-2 text-xs"
            >
              <div className="flex items-center justify-between text-[10px] text-[var(--text-dim)]">
                <span>{entry.citation}</span>
                <span>{entry.time}</span>
              </div>
              <div className="mt-1 text-[var(--text)]">{entry.summary}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
