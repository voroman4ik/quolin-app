import { rulesExportUrl } from "../api";

export function RuleExportCard() {
  return (
    <div className="flex items-center justify-between gap-3 rounded-[var(--radius-card)] border border-[var(--border)] bg-[var(--panel)] px-4 py-3">
      <div>
        <div className="text-sm font-medium text-[var(--text)]">Portable rule export</div>
        <div className="text-xs text-[var(--text-dim)]">Runs the exact active decision tree inside your own infrastructure</div>
      </div>
      <a
        href={rulesExportUrl()}
        download
        className="shrink-0 rounded-full border-[0.5px] border-[var(--border-input)] bg-[var(--input-bg)] px-4 py-2 text-xs font-medium text-[var(--text)] shadow-[var(--shadow-input)] hover:border-[var(--accent)]"
      >
        Download (JSON Logic)
      </a>
    </div>
  );
}
