import iconMenu from "../assets/figma/icon-menu.svg";
import type { Client } from "../api";
import { ClientList } from "./ClientList";

export function CompliancePanel({
  clients,
  expandedClientId,
  onToggleClient,
  flashNodeId,
  updateBanner,
}: {
  clients: Client[];
  expandedClientId: string | null;
  onToggleClient: (clientId: string) => void;
  flashNodeId: string | null;
  updateBanner: string | null;
}) {
  return (
    <div className="flex flex-col overflow-hidden rounded-[var(--radius-card)] bg-[var(--panel)]">
      <div className="flex items-center gap-2 bg-[var(--panel-header)] px-6 py-4">
        <div className="flex-1">
          <h2 className="text-base font-semibold text-[var(--text)]">Compliance decision engine</h2>
          <p className="text-xs text-[var(--text-dim)]">Live pre-settlement evaluation across active client relationships</p>
        </div>
        <img src={iconMenu} alt="" className="size-4" />
      </div>

      <div className="flex flex-col gap-4 p-6">
        {updateBanner && (
          <div className="rounded-[var(--radius-input)] border border-[var(--warning)] bg-[var(--warning)]/10 px-3 py-2 text-xs text-[var(--warning)]">
            {updateBanner}
          </div>
        )}

        <ClientList
          clients={clients}
          expandedClientId={expandedClientId}
          onToggle={onToggleClient}
          flashNodeId={flashNodeId}
        />
      </div>
    </div>
  );
}
