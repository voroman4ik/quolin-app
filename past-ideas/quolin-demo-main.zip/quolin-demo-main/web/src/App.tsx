import { useEffect, useState } from "react";
import type { Client, RegulatoryUpdateEvent } from "./api";
import { fetchClients, subscribeToRegulatoryFeed } from "./api";
import { CompliancePanel } from "./components/CompliancePanel";
import { MarketChart } from "./components/MarketChart";
import { RegulatoryFeed, type FeedEntry } from "./components/RegulatoryFeed";
import { RuleExportCard } from "./components/RuleExportCard";
import { Sidebar, type TabId } from "./components/Sidebar";
import { StatCards } from "./components/StatCards";
import { TimeAndSales } from "./components/TimeAndSales";
import { TopBar } from "./components/TopBar";

function App() {
  const [activeTab, setActiveTab] = useState<TabId>("dashboard");
  const [clients, setClients] = useState<Client[]>([]);
  const [expandedClientId, setExpandedClientId] = useState<string | null>(null);
  const [feedConnected, setFeedConnected] = useState(false);
  const [feedEntries, setFeedEntries] = useState<FeedEntry[]>([]);
  const [flashNodeId, setFlashNodeId] = useState<string | null>(null);
  const [updateBanner, setUpdateBanner] = useState<string | null>(null);

  useEffect(() => {
    fetchClients().then(({ clients, focusClientId }) => {
      setClients(clients);
      setExpandedClientId(focusClientId);
    });
  }, []);

  useEffect(() => {
    const unsubscribe = subscribeToRegulatoryFeed(
      (event: RegulatoryUpdateEvent) => {
        setFeedEntries((prev) => [
          {
            id: `${event.version}-${event.nodeId}`,
            summary: event.summary,
            citation: event.citation,
            time: new Date().toLocaleTimeString(),
          },
          ...prev,
        ]);
        setFlashNodeId(event.nodeId);
        setUpdateBanner(`Rule updated live: ${event.summary}`);
        setTimeout(() => setFlashNodeId(null), 3000);
        setTimeout(() => setUpdateBanner(null), 6000);

        fetchClients().then(({ clients }) => setClients(clients));
      },
      () => setFeedConnected(true),
    );
    return unsubscribe;
  }, []);

  // Presenter control: press "u" to push a live regulatory update through the
  // feed. Deliberately not a visible button - it should read as an external
  // event landing, not a canned demo trigger. Only active on the Quolin tab,
  // since that's the only place the resulting update is visible.
  useEffect(() => {
    function handleKeydown(e: KeyboardEvent) {
      if (e.key === "u" && activeTab === "quolin") {
        fetch("/api/regulatory-feed/trigger", { method: "POST" });
      }
    }
    window.addEventListener("keydown", handleKeydown);
    return () => window.removeEventListener("keydown", handleKeydown);
  }, [activeTab]);

  const expandedClient = clients.find((c) => c.id === expandedClientId) ?? null;
  const chartSymbol = expandedClient?.currentTrade.asset ?? "BTC";

  return (
    <div className="flex min-h-screen bg-[var(--bg)] text-[var(--text)]">
      <Sidebar activeTab={activeTab} onSelectTab={setActiveTab} />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar feedConnected={feedConnected} />
        <main className="flex flex-col gap-4 p-6">
          {activeTab === "dashboard" ? (
            <>
              <StatCards />
              <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
                <div className="flex flex-col gap-4 xl:col-span-2">
                  <MarketChart initialSymbol={chartSymbol} />
                </div>
                <div className="flex flex-col gap-4">
                  <TimeAndSales symbol={chartSymbol} />
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-col gap-4">
              <RuleExportCard />
              <CompliancePanel
                clients={clients}
                expandedClientId={expandedClientId}
                onToggleClient={(id) => setExpandedClientId((prev) => (prev === id ? null : id))}
                flashNodeId={flashNodeId}
                updateBanner={updateBanner}
              />
              <RegulatoryFeed entries={feedEntries} />
            </div>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;
