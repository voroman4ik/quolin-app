export type Trade = {
  id: string;
  asset: string;
  assetClass: "crypto";
  jurisdiction: string;
  counterparty: string;
  counterpartyExchange: string;
  notionalUsd: number;
  clientKycTier: 1 | 2 | 3;
  isSanctionedCounterparty: boolean;
  hasTravelRuleData: boolean;
  timestamp: string;
};

export type Verdict = "compliant" | "non_compliant" | "needs_review";

// Sourced from the CSV reference tables in /data (see server's
// complianceData.ts) - hover detail for a compliance rule: the external
// document/regulator, and (for decision-tree nodes) where it's implemented
// in this codebase.
export type ComplianceSource = {
  regimeId: string;
  regimeName: string;
  regulator: string;
  jurisdiction: string;
  legalBasisCitation: string;
  documentUrl: string;
  documentSection: string;
  documentPage: string;
  penaltySummary: string;
  notes: string;
  companyTypes: string[];
  sourceCodeFile?: string;
  sourceCodeLines?: string;
};

export type TraceStep = {
  nodeId: string;
  description: string;
  citation?: string;
  result: boolean;
  branch: "ifTrue" | "ifFalse";
  source?: ComplianceSource;
};

export type EvaluationResult = {
  verdict: Verdict;
  leafDescription: string;
  leafNodeId: string;
  trace: TraceStep[];
};

export type EvaluateResponse = {
  version: number;
  trade: Trade;
  result: EvaluationResult;
};

export type RegulatoryUpdateEvent = {
  version: number;
  nodeId: string;
  citation: string;
  summary: string;
  previous: { condition: unknown; description: string; citation?: string };
};

export type RegulatorySource = { name: string; detail: string };
export type ClientHolding = { asset: string; quantity: number; valueUsd: number };
export type ClientHistoricalTrade = {
  id: string;
  asset: string;
  side: "buy" | "sell";
  notionalUsd: number;
  timestamp: string;
  verdict: Verdict;
};
export type Client = {
  id: string;
  name: string;
  jurisdiction: string;
  primaryExchange: string;
  kycTier: 1 | 2 | 3;
  currentTradeId: string;
  currentTrade: Trade;
  currentEvaluation: EvaluationResult;
  tradeHistory: ClientHistoricalTrade[];
  holdings: ClientHolding[];
  regulatorySources: RegulatorySource[];
  applicableRules: ComplianceSource[];
};

export async function fetchClients(): Promise<{ version: number; focusClientId: string; clients: Client[] }> {
  const res = await fetch("/api/clients");
  if (!res.ok) throw new Error("Failed to load clients");
  return res.json();
}

export async function evaluateTrade(tradeId: string): Promise<EvaluateResponse> {
  const res = await fetch("/api/evaluate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ tradeId }),
  });
  if (!res.ok) throw new Error("Failed to evaluate trade");
  return res.json();
}

export function rulesExportUrl(): string {
  return "/api/rules/export";
}

export function subscribeToRegulatoryFeed(
  onUpdate: (event: RegulatoryUpdateEvent) => void,
  onConnected?: (data: { version: number }) => void,
): () => void {
  const source = new EventSource("/api/regulatory-feed/stream");
  source.addEventListener("connected", (e) => {
    onConnected?.(JSON.parse((e as MessageEvent).data));
  });
  source.addEventListener("regulatory-update", (e) => {
    onUpdate(JSON.parse((e as MessageEvent).data));
  });
  return () => source.close();
}
