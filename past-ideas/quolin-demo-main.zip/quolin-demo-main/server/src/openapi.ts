// OpenAPI 3.0 spec for the compliance demo API, served at /docs via swagger-ui-express.
export const openApiSpec = {
  openapi: "3.0.3",
  info: {
    title: "Compliance Demo API",
    version: "1.0.0",
    description: "Rule-tree evaluation and regulatory feed demo for crypto trade compliance.",
  },
  servers: [{ url: "/" }],
  paths: {
    "/api/trades": {
      get: {
        summary: "List demo trades",
        responses: {
          "200": {
            description: "Trades and the currently focused trade id",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    trades: { type: "array", items: { $ref: "#/components/schemas/Trade" } },
                    focusTradeId: { type: "string" },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/rules/tree": {
      get: {
        summary: "Get the current decision tree",
        responses: {
          "200": {
            description: "Versioned decision tree",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    version: { type: "integer" },
                    tree: { $ref: "#/components/schemas/DecisionNode" },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/evaluate": {
      post: {
        summary: "Evaluate a trade against the current decision tree",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: { tradeId: { type: "string" } },
                required: ["tradeId"],
              },
            },
          },
        },
        responses: {
          "200": {
            description: "Evaluation result",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    version: { type: "integer" },
                    trade: { $ref: "#/components/schemas/Trade" },
                    result: { $ref: "#/components/schemas/EvaluationResult" },
                  },
                },
              },
            },
          },
          "404": { description: "Unknown tradeId" },
        },
      },
    },
    "/api/clients": {
      get: {
        summary: "List clients with their current trade, live evaluation, holdings, and trade history",
        responses: {
          "200": {
            description: "Versioned client roster",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    version: { type: "integer" },
                    focusClientId: { type: "string" },
                    clients: { type: "array", items: { $ref: "#/components/schemas/Client" } },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/rules/export": {
      get: {
        summary: "Export the current decision tree compiled to JsonLogic",
        responses: {
          "200": {
            description: "JsonLogic document, returned as a file attachment",
            content: { "application/json": { schema: { type: "object" } } },
          },
        },
      },
    },
    "/api/regulatory-feed/stream": {
      get: {
        summary: "Server-sent event stream of regulatory updates",
        responses: {
          "200": {
            description: "text/event-stream of `connected` and `regulatory-update` events",
            content: { "text/event-stream": { schema: { type: "string" } } },
          },
        },
      },
    },
    "/api/regulatory-feed/trigger": {
      post: {
        summary: "Simulate an incoming regulatory update (presenter control, not linked from the UI)",
        responses: {
          "200": {
            description: "New tree version",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: { ok: { type: "boolean" }, version: { type: "integer" } },
                },
              },
            },
          },
        },
      },
    },
  },
  components: {
    schemas: {
      Trade: {
        type: "object",
        properties: {
          id: { type: "string" },
          asset: { type: "string" },
          assetClass: { type: "string", enum: ["crypto"] },
          jurisdiction: { type: "string" },
          counterparty: { type: "string" },
          counterpartyExchange: { type: "string" },
          notionalUsd: { type: "number" },
          clientKycTier: { type: "integer", enum: [1, 2, 3] },
          isSanctionedCounterparty: { type: "boolean" },
          hasTravelRuleData: { type: "boolean" },
          clientSegment: { type: "string", enum: ["retail", "institutional"] },
          hasReserveAttestation: { type: "boolean" },
          timestamp: { type: "string", format: "date-time" },
        },
      },
      RegulatorySource: {
        type: "object",
        properties: {
          name: { type: "string" },
          detail: { type: "string" },
        },
      },
      ClientHolding: {
        type: "object",
        properties: {
          asset: { type: "string" },
          quantity: { type: "number" },
          valueUsd: { type: "number" },
        },
      },
      ClientHistoricalTrade: {
        type: "object",
        properties: {
          id: { type: "string" },
          asset: { type: "string" },
          side: { type: "string", enum: ["buy", "sell"] },
          notionalUsd: { type: "number" },
          timestamp: { type: "string", format: "date-time" },
          verdict: { type: "string", enum: ["compliant", "non_compliant", "needs_review"] },
        },
      },
      Client: {
        type: "object",
        properties: {
          id: { type: "string" },
          name: { type: "string" },
          jurisdiction: { type: "string" },
          primaryExchange: { type: "string" },
          kycTier: { type: "integer", enum: [1, 2, 3] },
          currentTradeId: { type: "string" },
          currentTrade: { $ref: "#/components/schemas/Trade" },
          currentEvaluation: { $ref: "#/components/schemas/EvaluationResult" },
          tradeHistory: { type: "array", items: { $ref: "#/components/schemas/ClientHistoricalTrade" } },
          holdings: { type: "array", items: { $ref: "#/components/schemas/ClientHolding" } },
          regulatorySources: { type: "array", items: { $ref: "#/components/schemas/RegulatorySource" } },
        },
      },
      DecisionNode: {
        type: "object",
        description: "A branch (condition + ifTrue/ifFalse) or a leaf (verdict).",
      },
      EvaluationResult: {
        type: "object",
        properties: {
          verdict: { type: "string", enum: ["compliant", "non_compliant", "needs_review"] },
          leafDescription: { type: "string" },
          leafNodeId: { type: "string" },
          trace: {
            type: "array",
            items: {
              type: "object",
              properties: {
                nodeId: { type: "string" },
                description: { type: "string" },
                citation: { type: "string" },
                result: { type: "boolean" },
                branch: { type: "string", enum: ["ifTrue", "ifFalse"] },
              },
            },
          },
        },
      },
    },
  },
} as const;
