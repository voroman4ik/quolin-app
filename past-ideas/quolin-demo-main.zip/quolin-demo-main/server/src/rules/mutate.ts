import type { ConditionExpr, DecisionNode } from "./types.js";

export function findNode(tree: DecisionNode, nodeId: string): DecisionNode | null {
  if (tree.id === nodeId) return tree;
  if (tree.type === "leaf") return null;
  return findNode(tree.ifTrue, nodeId) ?? findNode(tree.ifFalse, nodeId);
}

// Mutates a branch node's condition/description/citation in place, returning
// the previous values so the caller can describe what changed.
export function applyRegulatoryUpdate(
  tree: DecisionNode,
  nodeId: string,
  patch: { condition: ConditionExpr; description: string; citation?: string },
) {
  const node = findNode(tree, nodeId);
  if (!node || node.type !== "branch") {
    throw new Error(`No branch node with id "${nodeId}"`);
  }
  const previous = {
    condition: node.condition,
    description: node.description,
    citation: node.citation,
  };
  node.condition = patch.condition;
  node.description = patch.description;
  if (patch.citation) node.citation = patch.citation;
  return { node, previous };
}
