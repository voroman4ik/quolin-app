import type { Client, RegulatorySource } from "./types.js";

const JURISDICTION_REGULATORY_SOURCES: Record<string, RegulatorySource[]> = {
  US: [
    {
      name: "OFAC SDN List",
      detail: "Sanctions screening against the OFAC Specially Designated Nationals list prior to settlement.",
    },
    {
      name: "FinCEN",
      detail: "Bank Secrecy Act / VASP reporting thresholds for domestic counterparties.",
    },
  ],
  UK: [
    {
      name: "FCA",
      detail: "FCA Cryptoasset Financial Promotions Regime, registration requirements, and the retail derivatives ban.",
    },
    {
      name: "FATF",
      detail: "FATF Recommendation 16 Travel Rule for cross-border transfers.",
    },
  ],
  SG: [
    {
      name: "MAS",
      detail: "MAS Payment Services Act Digital Payment Token licensing, AML/CFT Notice PSN02.",
    },
  ],
  AE: [
    {
      name: "FATF",
      detail: "FATF Recommendation 16 Travel Rule, applied via VARA-aligned AML guidance.",
    },
  ],
};

export const clients: Client[] = [
  {
    id: "cli-meridian-capital",
    name: "Meridian Capital Partners",
    jurisdiction: "US",
    primaryExchange: "Coinbase Prime",
    kycTier: 1,
    currentTradeId: "trd-8841",
    tradeHistory: [
      { id: "hist-8801", asset: "BTC", side: "buy", notionalUsd: 15000, timestamp: "2026-09-10T14:02:00Z", verdict: "compliant" },
      { id: "hist-8788", asset: "ETH", side: "sell", notionalUsd: 9500, timestamp: "2026-09-05T11:47:00Z", verdict: "compliant" },
      { id: "hist-8771", asset: "BTC", side: "buy", notionalUsd: 22000, timestamp: "2026-08-29T09:18:00Z", verdict: "needs_review" },
    ],
    holdings: [
      { asset: "BTC", quantity: 1.85, valueUsd: 118400 },
      { asset: "ETH", quantity: 40, valueUsd: 136000 },
      { asset: "USDC", quantity: 250000, valueUsd: 250000 },
    ],
    regulatorySources: JURISDICTION_REGULATORY_SOURCES.US,
  },
  {
    id: "cli-raffles-digital",
    name: "Raffles Digital Trust",
    jurisdiction: "SG",
    primaryExchange: "Fireblocks",
    kycTier: 3,
    currentTradeId: "trd-8842",
    tradeHistory: [
      { id: "hist-8790", asset: "ETH", side: "buy", notionalUsd: 38000, timestamp: "2026-09-11T10:33:00Z", verdict: "compliant" },
      { id: "hist-8776", asset: "BTC", side: "sell", notionalUsd: 51000, timestamp: "2026-09-07T08:15:00Z", verdict: "compliant" },
      { id: "hist-8760", asset: "SOL", side: "buy", notionalUsd: 19500, timestamp: "2026-09-01T16:04:00Z", verdict: "compliant" },
    ],
    holdings: [
      { asset: "ETH", quantity: 620, valueUsd: 2108000 },
      { asset: "BTC", quantity: 45, valueUsd: 2880000 },
      { asset: "SOL", quantity: 8000, valueUsd: 1200000 },
    ],
    regulatorySources: JURISDICTION_REGULATORY_SOURCES.SG,
  },
  {
    id: "cli-northgate-otc",
    name: "Northgate OTC Desk",
    jurisdiction: "UK",
    primaryExchange: "Kraken",
    kycTier: 2,
    currentTradeId: "trd-8843",
    tradeHistory: [
      { id: "hist-8782", asset: "BTC", side: "buy", notionalUsd: 12400, timestamp: "2026-09-09T13:20:00Z", verdict: "compliant" },
      { id: "hist-8765", asset: "ETH", side: "buy", notionalUsd: 7800, timestamp: "2026-09-02T09:50:00Z", verdict: "compliant" },
      { id: "hist-8741", asset: "XMR", side: "buy", notionalUsd: 4200, timestamp: "2026-08-25T15:11:00Z", verdict: "non_compliant" },
    ],
    holdings: [
      { asset: "XMR", quantity: 900, valueUsd: 153000 },
      { asset: "BTC", quantity: 3.2, valueUsd: 204800 },
      { asset: "ETH", quantity: 60, valueUsd: 204000 },
    ],
    regulatorySources: JURISDICTION_REGULATORY_SOURCES.UK,
  },
  {
    id: "cli-vantage-rock",
    name: "Vantage Rock Holdings",
    jurisdiction: "AE",
    primaryExchange: "Binance",
    kycTier: 2,
    currentTradeId: "trd-8844",
    tradeHistory: [
      { id: "hist-8779", asset: "USDT", side: "buy", notionalUsd: 2200, timestamp: "2026-09-08T07:40:00Z", verdict: "non_compliant" },
      { id: "hist-8752", asset: "BTC", side: "buy", notionalUsd: 1800, timestamp: "2026-08-30T12:05:00Z", verdict: "non_compliant" },
      { id: "hist-8730", asset: "USDT", side: "sell", notionalUsd: 3000, timestamp: "2026-08-20T18:22:00Z", verdict: "non_compliant" },
    ],
    holdings: [
      { asset: "USDT", quantity: 500000, valueUsd: 500000 },
      { asset: "BTC", quantity: 0.5, valueUsd: 32000 },
    ],
    regulatorySources: JURISDICTION_REGULATORY_SOURCES.AE,
  },
  {
    id: "cli-ashford-retail",
    name: "Ashford Retail Markets",
    jurisdiction: "UK",
    primaryExchange: "Kraken",
    kycTier: 2,
    currentTradeId: "trd-8845",
    tradeHistory: [
      { id: "hist-8795", asset: "BTC3L", side: "buy", notionalUsd: 4500, timestamp: "2026-09-10T16:45:00Z", verdict: "non_compliant" },
      { id: "hist-8768", asset: "BTC", side: "buy", notionalUsd: 2100, timestamp: "2026-09-03T12:30:00Z", verdict: "compliant" },
      { id: "hist-8744", asset: "ETH3L", side: "buy", notionalUsd: 3200, timestamp: "2026-08-26T10:05:00Z", verdict: "non_compliant" },
    ],
    holdings: [
      { asset: "BTC", quantity: 0.4, valueUsd: 25600 },
      { asset: "ETH", quantity: 3, valueUsd: 10200 },
    ],
    regulatorySources: JURISDICTION_REGULATORY_SOURCES.UK,
  },
  {
    id: "cli-solace-digital",
    name: "Solace Digital Assets",
    jurisdiction: "US",
    primaryExchange: "Coinbase Prime",
    kycTier: 2,
    currentTradeId: "trd-8846",
    tradeHistory: [
      { id: "hist-8797", asset: "USDC", side: "buy", notionalUsd: 55000, timestamp: "2026-09-11T08:00:00Z", verdict: "needs_review" },
      { id: "hist-8773", asset: "USDT", side: "sell", notionalUsd: 31000, timestamp: "2026-09-06T14:15:00Z", verdict: "needs_review" },
      { id: "hist-8748", asset: "BTC", side: "buy", notionalUsd: 9000, timestamp: "2026-08-27T09:40:00Z", verdict: "compliant" },
    ],
    holdings: [
      { asset: "USDC", quantity: 820000, valueUsd: 820000 },
      { asset: "USDT", quantity: 410000, valueUsd: 410000 },
      { asset: "BTC", quantity: 1.1, valueUsd: 70400 },
    ],
    regulatorySources: JURISDICTION_REGULATORY_SOURCES.US,
  },
];

export const focusClientId = "cli-meridian-capital";
