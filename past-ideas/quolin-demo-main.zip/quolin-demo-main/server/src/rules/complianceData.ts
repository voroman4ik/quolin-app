import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { parseCsv } from "./csv.js";
import type { ComplianceSource, EvaluationResult } from "./types.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// server/src/rules -> server/src -> server -> repo root -> data
const DATA_DIR = path.resolve(__dirname, "../../../data");

function readCsv(filename: string): Record<string, string>[] {
  const text = readFileSync(path.join(DATA_DIR, filename), "utf-8");
  return parseCsv(text);
}

const regimeRows = readCsv("regimes.csv");
const regimeCompanyTypeRows = readCsv("regime_company_types.csv");
const decisionNodeRows = readCsv("decision_nodes.csv");
const clientRows = readCsv("clients.csv");

const regimesById = new Map(regimeRows.map((row) => [row.id, row]));

const companyTypesByRegime = new Map<string, string[]>();
for (const row of regimeCompanyTypeRows) {
  const list = companyTypesByRegime.get(row.regime_id) ?? [];
  list.push(row.company_type);
  companyTypesByRegime.set(row.regime_id, list);
}

const companyTypesByClient = new Map<string, string[]>();
for (const row of clientRows) {
  const list = companyTypesByClient.get(row.client_id) ?? [];
  list.push(row.company_type);
  companyTypesByClient.set(row.client_id, list);
}

function toComplianceSource(
  regime: Record<string, string>,
  extra?: Partial<ComplianceSource>,
): ComplianceSource {
  return {
    regimeId: regime.id,
    regimeName: regime.regime_name,
    regulator: regime.regulator,
    jurisdiction: regime.jurisdiction,
    legalBasisCitation: regime.legal_basis_citation,
    documentUrl: regime.document_url,
    documentSection: regime.document_section,
    documentPage: regime.document_page,
    penaltySummary: regime.penalty_summary,
    notes: regime.notes,
    companyTypes: companyTypesByRegime.get(regime.id) ?? [],
    ...extra,
  };
}

const sourceByNodeId = new Map<string, ComplianceSource>();
for (const node of decisionNodeRows) {
  const regime = regimesById.get(node.regime_id);
  if (!regime) continue;
  sourceByNodeId.set(
    node.node_id,
    toComplianceSource(regime, {
      sourceCodeFile: node.source_code_file || undefined,
      sourceCodeLines: node.source_code_lines || undefined,
    }),
  );
}

export function getComplianceSourceForNode(nodeId: string): ComplianceSource | undefined {
  return sourceByNodeId.get(nodeId);
}

// Keyed by decision-tree nodeId so the frontend can look sources up directly
// off a TraceStep.nodeId without any extra indexing.
export function getAllComplianceSourcesByNode(): Record<string, ComplianceSource> {
  return Object.fromEntries(sourceByNodeId);
}

// Joins a client's company-type classifiers (data/clients.csv) against
// which company types each regime applies to (data/regime_company_types.csv),
// filtered to the client's own jurisdiction plus Global regimes - i.e. the
// "search up all the applicable rules" query, independent of whatever
// specific trade/decision-path a client's current trade happens to trigger.
export function getApplicableRulesForClient(clientId: string, jurisdiction: string): ComplianceSource[] {
  const clientTypes = companyTypesByClient.get(clientId) ?? [];
  if (clientTypes.length === 0) return [];

  const matches: ComplianceSource[] = [];
  for (const regime of regimeRows) {
    const regimeTypes = companyTypesByRegime.get(regime.id) ?? [];
    const typeMatches = regimeTypes.some((type) => clientTypes.includes(type));
    if (!typeMatches) continue;

    const jurisdictionMatches = regime.jurisdiction === jurisdiction || regime.jurisdiction === "Global";
    if (!jurisdictionMatches) continue;

    matches.push(toComplianceSource(regime));
  }
  return matches;
}

// Enriches an EvaluationResult's trace with the compliance-source detail for
// each triggered node, so DecisionTreeView can render a hover source for
// every "cascading" rule in the path without a separate frontend fetch.
export function attachComplianceSources(result: EvaluationResult): EvaluationResult {
  return {
    ...result,
    trace: result.trace.map((step) => ({
      ...step,
      source: getComplianceSourceForNode(step.nodeId),
    })),
  };
}
