import jsonLogic from "json-logic-js";
import type { DecisionNode, EvaluationResult, Trade, TraceStep } from "./types.js";

export function evaluateTrade(tree: DecisionNode, trade: Trade): EvaluationResult {
  const trace: TraceStep[] = [];
  let node = tree;

  while (node.type === "branch") {
    const result = Boolean(jsonLogic.apply(node.condition, trade));
    trace.push({
      nodeId: node.id,
      description: node.description,
      citation: node.citation,
      result,
      branch: result ? "ifTrue" : "ifFalse",
    });
    node = result ? node.ifTrue : node.ifFalse;
  }

  return {
    verdict: node.verdict,
    leafDescription: node.description,
    leafNodeId: node.id,
    trace,
  };
}
