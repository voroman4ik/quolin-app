import type { DecisionNode } from "./types.js";

// The decision tree IS the ruleset: every compliance rule is authored directly
// as a node here rather than compiled from some separate flat rule table.
// Evaluation, tree visualization, and portable export all read this same structure.
export const decisionTree: DecisionNode = {
  type: "branch",
  id: "sanctions-check",
  description: "Counterparty appears on a sanctions list",
  citation: "OFAC SDN List",
  condition: { "==": [{ var: "isSanctionedCounterparty" }, true] },
  ifTrue: {
    type: "leaf",
    id: "blocked-sanctions",
    verdict: "non_compliant",
    description: "Counterparty matches the OFAC SDN sanctions list",
  },
  ifFalse: {
    type: "branch",
    id: "restricted-asset-jurisdiction",
    description: "Privacy-coin trading restricted in this jurisdiction",
    citation: "FATF Travel Rule Guidance, Anonymity-Enhanced Coins",
    condition: {
      and: [
        { in: [{ var: "jurisdiction" }, ["US", "UK", "AU"]] },
        { in: [{ var: "asset" }, ["XMR", "ZEC"]] },
      ],
    },
    ifTrue: {
      type: "leaf",
      id: "blocked-restricted-asset",
      verdict: "non_compliant",
      description: "Privacy-coin trade is restricted in this jurisdiction",
    },
    ifFalse: {
      type: "branch",
      id: "restricted-derivative-product",
      description: "Leveraged/derivative token trade restricted for retail clients in this jurisdiction",
      citation: "FCA PS20/10 - Retail Restriction on Crypto-Derivatives",
      condition: {
        and: [
          { in: [{ var: "asset" }, ["BTC3L", "ETH3L", "BTC3S"]] },
          { "==": [{ var: "jurisdiction" }, "UK"] },
          { "==": [{ var: "clientSegment" }, "retail"] },
        ],
      },
      ifTrue: {
        type: "leaf",
        id: "blocked-derivative-restricted",
        verdict: "non_compliant",
        description:
          "Leveraged crypto-derivative token is restricted for retail clients in this jurisdiction",
      },
      ifFalse: {
        type: "branch",
        id: "stablecoin-reserve-attestation",
        description: "Stablecoin exposure exceeds the concentration threshold without a current reserve attestation",
        citation: "MiCA Title IV - E-Money Token Reserve & Attestation Requirements",
        condition: {
          and: [
            { in: [{ var: "asset" }, ["USDT", "USDC"]] },
            { ">": [{ var: "notionalUsd" }, 25000] },
            { "==": [{ var: "hasReserveAttestation" }, false] },
          ],
        },
        ifTrue: {
          type: "leaf",
          id: "review-stablecoin-attestation",
          verdict: "needs_review",
          description:
            "Enhanced due diligence required: stablecoin exposure exceeds the concentration threshold without a current reserve attestation",
        },
        ifFalse: {
          type: "branch",
          id: "kyc-notional-threshold",
          description: "Trade notional exceeds the Tier 1 KYC reporting threshold",
          citation: "Internal AML Policy 4.2 - Enhanced Due Diligence Thresholds",
          condition: {
            and: [
              { ">": [{ var: "notionalUsd" }, 10000] },
              { "<": [{ var: "clientKycTier" }, 2] },
            ],
          },
          ifTrue: {
            type: "leaf",
            id: "review-kyc-threshold",
            verdict: "needs_review",
            description:
              "Enhanced due diligence required: notional exceeds the Tier 1 KYC reporting threshold",
          },
          ifFalse: {
            type: "branch",
            id: "travel-rule-data",
            description: "Travel Rule originator/beneficiary data is missing",
            citation: "FATF Recommendation 16 (Travel Rule)",
            condition: {
              and: [
                { ">": [{ var: "notionalUsd" }, 3000] },
                { "==": [{ var: "hasTravelRuleData" }, false] },
              ],
            },
            ifTrue: {
              type: "leaf",
              id: "review-travel-rule",
              verdict: "needs_review",
              description:
                "Travel Rule originator/beneficiary data missing for a trade above the reporting floor",
            },
            ifFalse: {
              type: "leaf",
              id: "clear",
              verdict: "compliant",
              description: "Trade satisfies all active compliance rules",
            },
          },
        },
      },
    },
  },
};
