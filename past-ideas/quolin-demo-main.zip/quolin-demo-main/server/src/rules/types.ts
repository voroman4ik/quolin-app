export type Trade = {
  id: string;
  asset: string;
  assetClass: "crypto";
  jurisdiction: string;
  counterparty: string;
  counterpartyExchange: string;
  notionalUsd: number;
  clientKycTier: 1 | 2 | 3;
  isSanctionedCounterparty: boolean;
  hasTravelRuleData: boolean;
  clientSegment: "retail" | "institutional";
  hasReserveAttestation: boolean;
  timestamp: string;
};

export type Verdict = "compliant" | "non_compliant" | "needs_review";

// A json-logic-js expression, evaluated against a Trade.
export type ConditionExpr = Record<string, unknown>;

export type DecisionNode =
  | {
      type: "branch";
      id: string;
      description: string;
      citation?: string;
      condition: ConditionExpr;
      ifTrue: DecisionNode;
      ifFalse: DecisionNode;
    }
  | {
      type: "leaf";
      id: string;
      verdict: Verdict;
      description: string;
    };

// Sourced from the CSV reference tables in /data (see complianceData.ts) -
// the hover-detail for a compliance rule: where it's documented externally,
// and (for decision-tree nodes specifically) where it's implemented here.
export type ComplianceSource = {
  regimeId: string;
  regimeName: string;
  regulator: string;
  jurisdiction: string;
  legalBasisCitation: string;
  documentUrl: string;
  documentSection: string;
  documentPage: string;
  penaltySummary: string;
  notes: string;
  companyTypes: string[];
  sourceCodeFile?: string;
  sourceCodeLines?: string;
};

export type TraceStep = {
  nodeId: string;
  description: string;
  citation?: string;
  result: boolean;
  branch: "ifTrue" | "ifFalse";
  source?: ComplianceSource;
};

export type EvaluationResult = {
  verdict: Verdict;
  leafDescription: string;
  leafNodeId: string;
  trace: TraceStep[];
};

export type RegulatorySource = {
  name: string;
  detail: string;
};

export type ClientHolding = {
  asset: string;
  quantity: number;
  valueUsd: number;
};

export type ClientHistoricalTrade = {
  id: string;
  asset: string;
  side: "buy" | "sell";
  notionalUsd: number;
  timestamp: string;
  verdict: Verdict;
};

export type Client = {
  id: string;
  name: string;
  jurisdiction: string;
  primaryExchange: string;
  kycTier: 1 | 2 | 3;
  currentTradeId: string;
  tradeHistory: ClientHistoricalTrade[];
  holdings: ClientHolding[];
  regulatorySources: RegulatorySource[];
  // Populated at response time from data/clients.csv + regime_company_types.csv
  // (see complianceData.ts) - not part of the static seed data in clients.ts.
  applicableRules?: ComplianceSource[];
};
