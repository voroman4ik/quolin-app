import type { DecisionNode } from "./types.js";

// Mechanically projects the authored decision tree into a single, standalone
// JSON Logic expression. Nothing here is hand-maintained separately from
// decisionTree.ts - this is a structural derivation, so what a client runs
// after exporting is guaranteed to match what the API just evaluated.
export function compileToJsonLogic(node: DecisionNode): unknown {
  if (node.type === "leaf") {
    return { verdict: node.verdict, description: node.description };
  }
  return {
    if: [node.condition, compileToJsonLogic(node.ifTrue), compileToJsonLogic(node.ifFalse)],
  };
}
