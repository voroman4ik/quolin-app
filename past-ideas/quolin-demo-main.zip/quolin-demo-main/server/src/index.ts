import cors from "cors";
import express from "express";
import type { Response } from "express";
import swaggerUi from "swagger-ui-express";
import { decisionTree } from "./rules/decisionTree.js";
import { compileToJsonLogic } from "./rules/compile.js";
import { evaluateTrade } from "./rules/evaluate.js";
import { applyRegulatoryUpdate } from "./rules/mutate.js";
import { focusTradeId, trades } from "./rules/trades.js";
import { clients, focusClientId } from "./rules/clients.js";
import { openApiSpec } from "./openapi.js";
import {
  attachComplianceSources,
  getAllComplianceSourcesByNode,
  getApplicableRulesForClient,
} from "./rules/complianceData.js";

const app = express();
app.use(cors());
app.use(express.json());

app.use("/docs", swaggerUi.serve, swaggerUi.setup(openApiSpec));

const state = {
  tree: decisionTree,
  version: 1,
};

const sseClients = new Set<Response>();

function broadcast(event: string, data: unknown) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const client of sseClients) client.write(payload);
}

app.get("/api/trades", (_req, res) => {
  res.json({ trades, focusTradeId });
});

app.get("/api/rules/tree", (_req, res) => {
  res.json({ version: state.version, tree: state.tree });
});

app.post("/api/evaluate", (req, res) => {
  const { tradeId } = req.body as { tradeId?: string };
  const trade = trades.find((t) => t.id === tradeId);
  if (!trade) {
    res.status(404).json({ error: `Unknown tradeId "${tradeId}"` });
    return;
  }
  const result = attachComplianceSources(evaluateTrade(state.tree, trade));
  res.json({ version: state.version, trade, result });
});

app.get("/api/clients", (_req, res) => {
  const payload = clients.map((client) => {
    const currentTrade = trades.find((t) => t.id === client.currentTradeId)!;
    const currentEvaluation = attachComplianceSources(evaluateTrade(state.tree, currentTrade));
    const applicableRules = getApplicableRulesForClient(client.id, client.jurisdiction);
    return { ...client, currentTrade, currentEvaluation, applicableRules };
  });
  res.json({ version: state.version, focusClientId, clients: payload });
});

// Backs the hover popover on each cascading rule in the decision-tree trace:
// one row per live decision node, joined against data/regimes.csv, keyed by
// nodeId so the frontend can look a step's source up directly.
app.get("/api/compliance-sources", (_req, res) => {
  res.json(getAllComplianceSourcesByNode());
});

app.get("/api/rules/export", (_req, res) => {
  const compiled = compileToJsonLogic(state.tree);
  res.setHeader("Content-Disposition", `attachment; filename="decision-tree-v${state.version}.json"`);
  res.setHeader("Content-Type", "application/json");
  res.send(JSON.stringify(compiled, null, 2));
});

app.get("/api/regulatory-feed/stream", (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();
  res.write(`event: connected\ndata: ${JSON.stringify({ version: state.version })}\n\n`);

  sseClients.add(res);
  req.on("close", () => sseClients.delete(res));
});

// Not linked from the dashboard UI - this is the presenter's control to make
// a regulatory change land live, as if an external feed pushed it in.
app.post("/api/regulatory-feed/trigger", (_req, res) => {
  const { previous } = applyRegulatoryUpdate(state.tree, "kyc-notional-threshold", {
    condition: {
      and: [
        { ">": [{ var: "notionalUsd" }, 1000] },
        { "<": [{ var: "clientKycTier" }, 2] },
      ],
    },
    description:
      "Enhanced due diligence required: notional exceeds the revised Tier 1 KYC reporting threshold",
    citation: "FinCEN Advisory 2026-07 - Lowered VASP Reporting Threshold ($1,000)",
  });
  state.version += 1;

  broadcast("regulatory-update", {
    version: state.version,
    nodeId: "kyc-notional-threshold",
    citation: "FinCEN Advisory 2026-07 - Lowered VASP Reporting Threshold ($1,000)",
    summary: "VASP reporting threshold lowered from $10,000 to $1,000",
    previous,
    tree: state.tree,
  });

  res.json({ ok: true, version: state.version });
});

const port = Number(process.env.PORT ?? 4000);
app.listen(port, () => {
  console.log(`compliance demo server listening on :${port}`);
});
