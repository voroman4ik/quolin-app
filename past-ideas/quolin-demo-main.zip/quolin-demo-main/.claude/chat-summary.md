# Chat summary: crypto trade compliance tech - integration options and investor pitch

## The idea
A Droit-style compliance decision engine focused on crypto, monitoring regulatory changes across jurisdictions and using that to keep internal decision trees up to date, so trades can be checked for compliance.

## Integration/tech solutions discussed
Starting point: API and SFTP batch upload.

Additional options raised:
- **Streaming/event-based ingestion** (Kafka, Kinesis, Pub/Sub) for continuous trade flow
- **FIX protocol adapter** to plug into existing trading infrastructure
- **Embeddable SDK/client library** for low-latency, on-premises pre-trade checks
- **Portable rule export** (DMN, JSON Logic, WASM) so institutions can run checks entirely within their own infrastructure - identified as the strongest differentiator, since data never leaves the client's environment
- **Containerised/on-prem deployment** for institutions with strict data governance needs
- **Web portal/manual entry UI** for smaller institutions and as a compliance officer review interface
- **Direct exchange/custodian pull integrations** (e.g. Coinbase Prime, Fireblocks)
- **Webhooks** - discussed as a notification layer (regulatory change alerts, retrospective re-evaluation results, async verdicts), not a replacement for API/SDK, and considered less useful to prioritise immediately

Also discussed: explainability/versioning of the decision tree, a sandbox environment, alerting/workflow integrations, and latency tiering across the different modes.

## Investor pitch options considered
Narrowed the long list down to what's worth showing investors:
1. **Portable rule export** - the strongest differentiation story (runs inside client infrastructure)
2. **API + SDK together** - signals technical credibility and latency-awareness
3. **The regulatory monitoring/decision tree update pipeline itself** - the actual product, more important than any integration mode

Ruled out for the investor pitch specifically: SFTP, FIX adapters, webhooks, containerised deployment, web portal - useful for later sales conversations but not defensibility stories for investors.

## Live demo direction
Concluded that API/SDK/rule export are all invisible or abstract in a live setting. Landed on: a mock trading dashboard with a regulatory compliance box as the hero panel, showing a trade evaluate through a decision tree live, then a "simulate regulatory update" moment that ripples through the tree and flips a trade from compliant to non-compliant in real time.

A FIX adapter was considered as a way to double as both an investor demo and a real client integration demo, but was separated out: building a genuinely credible FIX adapter (real engine, real session handling, drop copy vs inline gating decision) is real engineering effort, and not the right near-term priority versus a lightweight, demonstration-focused mockup.

## Outcome
Built an interactive HTML prototype (`custos-demo.html`) of the dashboard/decision-tree/regulatory-update concept as a standalone, presentation-ready demo.

A separate existing prototype, **Quolin**, was then shared for context - a more built-out compliance decision engine (real rules engine, hash-chained audit trail, replay of historical decisions) but for adviser suitability rather than trade compliance, and with UI/demo-readiness not yet clear from its overview document.
