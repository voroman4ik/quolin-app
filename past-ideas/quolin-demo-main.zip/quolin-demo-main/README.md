# quolin-demo

Investor-demo prototype of a crypto trade compliance decision engine: a
trading dashboard with a live decision-tree evaluation panel, and a
regulatory-update event that ripples through the tree and flips a trade's
verdict in real time.

## Run it

```
npm install
npm run dev
```

- Frontend: http://localhost:5173
- API: http://localhost:4000

## Demo flow

1. The dashboard opens on trade `trd-8841` (BTC, $8,000, US), evaluated live
   against the decision tree — starts **COMPLIANT**.
2. With the dashboard focused in the browser, press **`u`** to push a live
   regulatory update (lowers the VASP reporting threshold from $10,000 to
   $1,000). This is deliberately not a UI button — it's meant to read as an
   external event landing, not a canned demo trigger.
3. The affected rule node highlights, the regulatory feed panel logs the
   update, and the trade flips to **NEEDS REVIEW** — without a page reload
   (pushed over SSE).
4. "Download rule export (JSON Logic)" exports the exact tree the API just
   evaluated, as a standalone JSON Logic file — the portability story.

## How rules are stored

There's no separate "rule table" that gets compiled into a tree — the
decision tree *is* the ruleset. Each node in
[`server/src/rules/decisionTree.ts`](server/src/rules/decisionTree.ts) is
authored directly as a JSON Logic condition plus metadata (description,
citation). The same structure is evaluated server-side, walked to render the
tree/trace in the UI, and mechanically compiled to a portable JSON Logic
file for export (`server/src/rules/compile.ts`) — so what a client runs
after export is guaranteed to match what the API just evaluated.

## Structure

- `server/` — Express + TypeScript API (decision tree, evaluation, export,
  SSE regulatory feed)
- `web/` — React + TypeScript + Vite + Tailwind dashboard
