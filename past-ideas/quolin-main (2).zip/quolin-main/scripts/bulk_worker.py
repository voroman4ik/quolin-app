"""
One pass of the bulk-evaluation queue: work every chunk waiting, then stop.

§S8 re-checks a whole book in chunks. This is what runs them — the same code an
endpoint would call, in a process nobody is waiting on. A hundred thousand pairs
is about four and a half minutes here and none of it in a request.

**One transaction per chunk.** A worker killed on the ninth keeps the eight that
finished, and its claim on the ninth expires for another worker to take. The
determinations are protected twice over: by that transaction, and by a unique
index on `decisions (run_id, client_id, asset_id)` for the case where a chunk
committed and the process died before it could say so.

**A pass per tenant, in that tenant's own transaction.** `app.tenant_id` binds
when a transaction begins, so a session reused across the loop would claim the
second tenant's chunks inside the first tenant's transaction. That mistake has
been made twice in this repository — in the access review and in the watch sweep
— and caught both times by reading output rather than by a test.

**Serial within a tenant, by design.** Determinations are hash-chained per
tenant, so two workers appending to one tenant's chain would splice it. Running
two of these at once is safe — `FOR UPDATE SKIP LOCKED` means the second takes
nothing — but it will not go faster.

Usage:

    make bulk-worker
    make bulk-worker ARGS="--run 42"

Exit codes: 0 if everything claimed completed, 1 if the pass could not run, 2 if
a chunk failed — a scheduler should alert on the third without treating it as a
crash.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from sqlalchemy import select  # noqa: E402

from app import bulk, maintenance, tenancy  # noqa: E402
from app.db import OwnerSessionLocal, SessionLocal  # noqa: E402
from app.models import EvalRun  # noqa: E402

#: Who the sweep acts as when no person asked — the same provisioned machine
#: principal `settle_packs` plans runs as.
SCHEDULE_ACTOR = "apc_bulk_sweep"


def _tenants() -> list[str]:
    """Every active firm. Raises rather than returning nothing — see below.

    Enumerated as a role holding the `quolin_maintenance` grant migration 0029
    creates, not as a superuser. Before that migration this read returned zero
    rows on any database whose owner lacked BYPASSRLS, and the worker below
    would have swept nothing and exited 0.
    """
    session = OwnerSessionLocal()
    try:
        return maintenance.active_tenant_ids(session)
    finally:
        session.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Work the bulk-evaluation queue.")
    parser.add_argument("--run", type=int, default=None, help="only this run")
    parser.add_argument(
        "--limit", type=int, default=1000, help="most chunks to work in one pass"
    )
    args = parser.parse_args()

    totals = {"chunks": 0, "done": 0, "changed": 0, "failed": 0}
    try:
        tenants = _tenants()
    except maintenance.NoActiveTenants as exc:
        print(f"bulk worker found no firms to sweep: {exc}", file=sys.stderr)
        return 1
    if not tenants:
        print(
            "bulk worker enumerated no active firms. A sweep with nothing to do "
            "on a platform with customers has not had a quiet night — it cannot "
            "see the work.",
            file=sys.stderr,
        )
        return 1

    try:
        for tenant_id in tenants:
            with tenancy.acting_as(tenant_id), tenancy.acting_as_user(SCHEDULE_ACTOR):
                session = SessionLocal()
                try:
                    tally = bulk.drain(session, run_id=args.run, limit=args.limit)
                    if not any(tally.values()):
                        continue
                    outstanding = session.scalars(
                        select(EvalRun)
                        .where(EvalRun.status.in_((bulk.PLANNED, bulk.RUNNING)))
                        .order_by(EvalRun.id)
                    ).all()
                finally:
                    session.close()

            for key in totals:
                totals[key] += tally[key]
            print(
                f"{tenant_id}: {tally['chunks']} chunk(s), {tally['done']} pairs, "
                f"{tally['changed']} changed, {tally['failed']} failed"
                + (f", {len(outstanding)} run(s) still open" if outstanding else "")
            )
    except Exception as exc:  # noqa: BLE001 — a scheduler needs one exit code
        print(f"bulk worker could not run: {exc}", file=sys.stderr)
        return 1

    print(
        f"bulk worker — {totals['chunks']} chunk(s), {totals['done']} pairs, "
        f"{totals['changed']} changed"
    )
    if totals["failed"]:
        print(
            f"{totals['failed']} pair(s) failed to evaluate; see eval_runs.note",
            file=sys.stderr,
        )
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
