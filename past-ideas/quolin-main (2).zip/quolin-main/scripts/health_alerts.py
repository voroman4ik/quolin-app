"""
Check everything §S9 alerts on, and page a person when something is wrong.

**"Alerts page a person, not a channel nobody reads."** That sentence is the
whole design. A destination is *required* when anything critical is found: with
none configured this exits non-zero and says so rather than printing into a log
and returning success, because an alerting system that silently alerts nobody is
worse than none — it produces the feeling of coverage without the coverage.

**It pages once per condition per day, and stays loud in every other way.** The
same reasoning the watch sweep's source alerts use: an alert that arrives every
ten minutes gets filtered into a folder nobody opens, and silence after the
first page is how an incident gets forgotten. So the page is sent once and the
exit code stays non-zero for as long as the condition lasts.

**A check that could not run is reported as a finding, not skipped.** A blind
spot is not an all-clear, and the failure mode of monitoring is to go quiet.

Usage:

    make health-alerts
    make health-alerts ARGS=--json

Exit codes: 0 when nothing is wrong, 1 if the checks could not run, 2 when
something is wrong — whether or not the page could be delivered.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from datetime import date
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from scripts import evidence_io  # noqa: E402

from app import (  # noqa: E402
    advance,
    alerts,
    business_time,
    maintenance,
    observability,
    pack_notices,
    source_alerts,
    tenancy,
)
from app.db import OwnerSessionLocal, SessionLocal  # noqa: E402

#: Where a page goes. A URL that reaches a human — a pager service's inbound
#: webhook, or the bridge into whatever a firm actually carries.
#:
#: Unset by default and deliberately not defaulted to a chat channel: §S9 is
#: explicit that alerts page a person, and the easiest way to satisfy that
#: sentence dishonestly is to point it at a room.
PAGER_URL = os.getenv("QUOLIN_PAGER_URL", "").strip()

#: How long the pager is given. Short: a pager that is slow is a pager that is
#: down, and the exit code carries the alert regardless.
TIMEOUT_SECONDS = 10.0


def _tenants() -> list[str]:
    """Every active firm to run the §S9 checks against.

    This one line was the worst instance of the defect migration 0029 fixes.
    On a database whose owner does not hold BYPASSRLS — which is every RDS
    master account, and `infra/` provisions an RDS master account — this
    returned nothing. The loop below then ran zero times, found zero findings,
    paged nobody and exited 0. The paging path would have reported all-clear for
    the life of the deployment, and there would have been nothing to notice.
    """
    session = OwnerSessionLocal()
    try:
        # Q-01's remaining assumption, checked before the enumeration rather
        # than diagnosed after it. Migration 0029 grants `quolin_maintenance`
        # to the account it is applied by; if migrations run as a migrator and
        # this job connects as somebody else, the grant landed on the wrong
        # role and this query returns nothing. That is already refused below —
        # but as "no active firms were visible", which sends whoever is paged to
        # look at a `tenants` table that is full.
        maintenance.assert_can_enumerate(session)
        return maintenance.active_tenant_ids(session)
    finally:
        session.close()


def _heartbeat(*, tenants_seen: int, outcome: str, detail: str = "") -> None:
    """Leave a row saying this ran, whatever it concluded.

    The other half of the same finding. Nothing distinguishes a monitor that is
    quiet because all is well from one that is quiet because it is dead — unless
    the monitor leaves a pulse. Best-effort on purpose: a heartbeat that could
    not be written must not be the thing that stops a page going out.
    """
    session = OwnerSessionLocal()
    try:
        maintenance.heartbeat(
            session,
            "health_alerts",
            tenants_seen=tenants_seen,
            outcome=outcome,
            detail=detail,
        )
        session.commit()
    except Exception as exc:  # noqa: BLE001 — a pulse must not block an alert
        print(f"the heartbeat could not be written: {exc}", file=sys.stderr)
        session.rollback()
    finally:
        session.close()


def page(findings: list[alerts.Finding], *, tenant_id: str) -> tuple[bool, str]:
    """Send one page carrying every finding. Returns whether it was delivered.

    One page rather than one per finding: somebody woken at 3am needs the whole
    picture, and five separate alerts about the same outage are how a real one
    gets lost among its own symptoms.
    """
    if not PAGER_URL:
        return False, (
            "no pager is configured (QUOLIN_PAGER_URL), so nobody was told. "
            "The exit code is the only alert this run produced."
        )

    body = json.dumps(
        {
            "tenant_id": tenant_id,
            "severity": findings[0].severity if findings else alerts.WARNING,
            "summary": findings[0].summary if findings else "",
            "findings": [finding.as_dict() for finding in findings],
        }
    ).encode()

    request = urllib.request.Request(
        PAGER_URL, data=body, headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            if response.status >= 400:
                return False, f"the pager answered HTTP {response.status}"
        return True, "paged"
    except (urllib.error.URLError, OSError) as exc:
        return False, f"the pager could not be reached: {exc}"


def main() -> int:
    parser = argparse.ArgumentParser(description="Check what is wrong and page.")
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument(
        "--no-page", action="store_true", help="check and report without paging"
    )
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    observability.configure()
    today = business_time.platform_today().isoformat()
    everything: dict[str, list[alerts.Finding]] = {}

    try:
        tenants = _tenants()
    except maintenance.NoActiveTenants as exc:
        print(f"health checks could not run: {exc}", file=sys.stderr)
        _heartbeat(tenants_seen=0, outcome=maintenance.FAULT, detail=str(exc))
        return 1
    if not tenants:
        detail = (
            "the health checks enumerated no active firms. That is not an "
            "all-clear: it is a monitor that cannot see the system it monitors."
        )
        print(detail, file=sys.stderr)
        _heartbeat(tenants_seen=0, outcome=maintenance.FAULT, detail=detail)
        return 1

    stale_sent = 0
    pack_sent = 0
    overdue_sent = 0
    try:
        for tenant_id in tenants:
            with tenancy.acting_as(tenant_id), tenancy.acting_as_user("apc_bulk_sweep"):
                session = SessionLocal()
                try:
                    found = alerts.check(session)

                    # The other half of FP3-03, and the reason it is here.
                    #
                    # The watch sweep records a breach and cannot tell anybody:
                    # it holds `WATCH_DATABASE_URL` alone, by design and by
                    # guard. Enqueueing a webhook needs the application role and
                    # the fan-out needs the list of firms — and this job already
                    # has both, opens a session per tenant already, and runs on a
                    # schedule already. Giving the sweep those credentials
                    # instead would have traded Stage 6's separation for a
                    # notification.
                    #
                    # Inside the same transaction as the check, so a tenant whose
                    # session fails is neither alerted nor marked as told.
                    stale_sent += source_alerts.fan_out(session, tenant_id)
                    # FP3-08, the same shape and the same reason: pack events
                    # are global, and only a worker that can enumerate firms can
                    # tell them all.
                    pack_sent += pack_notices.fan_out(session, tenant_id)
                    # FP3-17. A pinned firm whose review window has closed is
                    # told once a day, per overdue pack, until they advance.
                    # Here because this job already runs on a schedule, already
                    # holds the application role, and already binds each tenant
                    # in turn — the same three reasons FP3-03 put the source
                    # fan-out here.
                    overdue_sent += advance.announce_overdue(
                        session, tenant_id=tenant_id
                    )
                    session.commit()
                finally:
                    session.close()
            if found:
                everything[tenant_id] = found
    except Exception as exc:  # noqa: BLE001 — a monitor reports rather than crashes
        print(f"health checks could not run: {exc}", file=sys.stderr)
        _heartbeat(tenants_seen=len(tenants), outcome=maintenance.FAULT, detail=str(exc))
        return 1

    delivered: dict[str, str] = {}
    for tenant_id, found in everything.items():
        critical = [f for f in found if f.severity == alerts.CRITICAL]
        if critical and not args.no_page:
            sent, note = page(critical, tenant_id=tenant_id)
            delivered[tenant_id] = note if not sent else f"paged ({today})"

    report = {
        "checked": len(tenants),
        "source_stale_notified": stale_sent,
        "pack_events_notified": pack_sent,
        "review_overdue_notified": overdue_sent,
        "tenants_with_findings": sorted(everything),
        "findings": {
            tenant_id: [finding.as_dict() for finding in found]
            for tenant_id, found in everything.items()
        },
        "paging": delivered,
    }

    if args.json:
        print(json.dumps(report, indent=2))
    else:
        if stale_sent:
            print(f"source.stale — {stale_sent} notification(s) enqueued")
        if pack_sent:
            print(f"pack events — {pack_sent} notification(s) enqueued")
        if overdue_sent:
            print(
                f"pack.review_overdue — {overdue_sent} firm/pack(s) past their "
                "review window"
            )
        if not everything:
            print("health — nothing to report")
        for tenant_id, found in sorted(everything.items()):
            print(f"{tenant_id}:")
            for finding in found:
                print(f"  [{finding.severity}] {finding.summary}")
                print(f"      → {finding.action}")
            if tenant_id in delivered:
                print(f"  paging: {delivered[tenant_id]}")

    if args.evidence_out:
        evidence_io.write(
            "drills",
            "health-checks",
            report,
            passed=not everything,
            summary=(
                "Every §S9 check ran and found nothing."
                if not everything
                else f"{len(everything)} firm(s) have findings; see the record."
            ),
        )

    if not everything:
        _heartbeat(tenants_seen=len(tenants), outcome=maintenance.OK)
        return 0

    _heartbeat(
        tenants_seen=len(tenants),
        outcome=maintenance.FINDINGS,
        detail=f"{len(everything)} firm(s) with findings: {', '.join(sorted(everything))}",
    )
    undelivered = [note for note in delivered.values() if not note.startswith("paged")]
    for note in undelivered:
        print(note, file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
