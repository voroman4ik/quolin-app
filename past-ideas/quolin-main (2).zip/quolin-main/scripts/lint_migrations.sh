#!/usr/bin/env bash
# Stage 0 invariant guard: migrations may not undo invariants 1, 3, 4 and 5.
#
# This is the entry point CI and `make guard` call. The work is in
# `scripts/migration_lint.py`, and the reason it moved there is FP3-01.
#
# What this guard used to be was a set of greps over SQL spellings. Every real
# migration in this repository is alembic Python, and two independent audits
# established by execution that `op.drop_column("decisions", "prev_hash")`,
# `GRANT ALL ON decisions`, a multi-line `GRANT UPDATE,\n DELETE`, a
# `CREATE OR REPLACE FUNCTION quolin_append_only() ... RETURN NEW`, `sa.Double()`,
# `ALTER ROLE quolin_app BYPASSRLS` and any of the eight append-only tables
# missing from its five-name regex all passed it with exit 0. The repository's
# own migration 0026 downgraded by dropping both chain columns and the guard
# called the tree clean.
#
# It could have been made a better regex. It was not, because the reason it
# failed is not that the patterns were wrong: a guard that reads source text is
# guessing at what the database will do, and every one of those seven cases is a
# different way for the guess to be wrong. So this applies the migrations to a
# scratch database and reads the catalog back after each one. What it asserts is
# what the server ends up enforcing, which is the only thing an auditor is
# entitled to rely on.
#
# It needs a Postgres it may create and drop a database on. CI has one; so does
# `make up`. QUOLIN_LINT_ADMIN_URL overrides the connection, MIGRATIONS_DIR
# overrides the tree — and an absent or empty tree is a failure rather than a
# pass, which is asserted by a mutation case in `test_guard_mutations.py` rather
# than left to this comment.
#
# **Never point this at a production cluster.** It applies migrations it has been
# given no reason to trust, which is the entire point of it, and a scratch
# database bounds only some of what one can do. Roles are cluster-scoped: a
# migration containing `ALTER ROLE quolin_app BYPASSRLS` alters the real role on
# whatever server this connects to. This restores the three worker roles'
# attributes afterwards and says so when it had to — but "restored afterwards"
# is not "never happened", and on a production cluster the window between them
# is a window with row-level security switched off.
set -uo pipefail

_HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_API="$_HERE/../api"

cd "$_API" || exit 1
exec uv run python "$_HERE/migration_lint.py" "$@"
