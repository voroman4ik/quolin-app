# Shared preflight for the invariant guards.
#
# §S13's external review found `guard_no_watch_in_engine.sh` using `git grep`,
# which searches the index rather than the disk: run from an unpacked snapshot
# that is not a git checkout, it exits green having examined nothing. That is
# the worst failure a guard has, because it is indistinguishable from passing.
#
# Checking all five turned up the wider version of the same problem. None of
# them asserted that the paths they scan exist. `grep -r` over a directory that
# is not there prints nothing and returns non-zero, which every one of these
# scripts treats as "no offending lines found" — so deleting `api/app/engine`
# made the engine guards pass rather than fail.
#
# Two functions, sourced by all five.
#
#   require_paths   the files exist and are not empty, or exit non-zero
#   require_scan    the same, plus: the paths hold files this guard can read,
#                   and `SCANNED_FILES` says how many
#   repo_grep       `git grep` where there is an index, plain `grep -r` where
#                   there is not, with identical patterns and verdicts
#
# The rule underneath all three: a guard reports what it checked, and a guard
# that could not check anything fails. Silence is never a pass.
#
# **The Gate A audit found the rule held in three of the five guards that take a
# path from the environment.** `guard_no_hardcoded_region.sh` validated
# `INFRA_DIR` and never validated `SCAN_ROOT`, so `SCAN_ROOT=/tmp/nowhere`
# produced no grep matches, exited 0 and printed a success message — the exact
# defect §S13 wrote this file to end, surviving in the second path parameter of
# a guard whose first one was fixed. `guard_no_shared_passcode.sh` and
# `guard_no_naive_today.sh` each had a correct check of their own, hand-written,
# which is how the region guard came to have one for `INFRA_DIR` and not for
# `SCAN_ROOT`: three copies of a rule is three places to leave one out.
#
# So the count moves in here with the existence check, and every guard that
# scans a path calls one function.

#: Every path a guard names must exist and hold something.
#:
#: Directories are required to contain at least one regular file, because an
#: empty directory greps exactly like a missing one and means the same thing
#: here — nothing was examined.
require_paths() {
  local missing=0
  local path
  for path in "$@"; do
    if [ -d "$path" ]; then
      if [ -z "$(find "$path" -type f -print -quit 2>/dev/null)" ]; then
        echo "FAIL: $path is an empty directory — this guard checked nothing." >&2
        missing=1
      fi
    elif [ -f "$path" ]; then
      if [ ! -s "$path" ]; then
        echo "FAIL: $path is empty — this guard checked nothing." >&2
        missing=1
      fi
    else
      echo "FAIL: $path does not exist — this guard checked nothing." >&2
      missing=1
    fi
  done

  if [ "$missing" -ne 0 ]; then
    echo >&2
    echo "A guard that cannot find what it guards must fail. Passing would" >&2
    echo "report an invariant as held on a tree where it was never examined." >&2
    exit 2
  fi
}


#: Directories no guard has any business reading, in either mode.
#:
#: Q-10. The two modes did not examine the same tree. `git grep` consults the
#: index, so it never sees a virtual environment; `grep -r` reads whatever is
#: lying about, and `api/.venv` alone is 252MB of other people's source. A guard
#: whose verdict depends on what happens to be installed is not a guard — and
#: the divergence had gone unnoticed only because the test that compares the two
#: modes built its scratch tree without these directories in it.
#:
#: One list, here, because `guard_no_shared_passcode.sh` had grown its own —
#: `node_modules`, `__pycache__`, `.next`, and not `.venv`. Two lists of the
#: same thing is two lists that drift, and the one that drifts is the one that
#: lets something through.
#: `.hypothesis` joined the list for the Gate A audit's third finding, and it is
#: Q-10 a third time. Hypothesis caches every string constant it has seen across
#: the whole test suite into one file per run — so the moment a guard widened
#: from "these directories" to "the tree", it started reading a machine-written
#: index of every literal in the repository and reporting matches from it. A
#: generated cache of what the source contains is not source, and a guard whose
#: verdict depends on whether the suite has been run is not a guard.
IGNORED_DIRS=(.git .venv venv node_modules .next .terraform __pycache__ .pytest_cache .mypy_cache .ruff_cache .hypothesis)

#: The ignore list as `grep` arguments. Used by `repo_grep` below and by any
#: guard that greps a directory directly.
#:
#:   hits=$(grep -rInE "$PATTERN" "$DIR" $(grep_excludes) || true)
grep_excludes() {
  local dir
  for dir in "${IGNORED_DIRS[@]}"; do
    printf -- '--exclude-dir=%s ' "$dir"
  done
}

#: How many files the last `require_scan` counted. Read by callers for their
#: success message, so that what a guard claims to have examined is a number it
#: obtained rather than a sentence somebody wrote.
SCANNED_FILES=0

#: Every path this guard is about to scan exists, and holds files it can read.
#:
#: `require_paths` answers "is there anything here at all". This also answers
#: "is there anything here *this guard reads*", which is a different question
#: with the same failure mode: a directory of PNGs greps exactly like a missing
#: one for a guard looking at Python, and both are silence rather than a pass.
#:
#: Usage:  require_scan "<what this guard checks>" "<ext ext …>" <path>...
#:
#: Extensions without dots, space-separated. An empty extension list means every
#: file, which is what a guard scanning the whole tree wants; an extension
#: written `!md` means every file *except* that kind, for a guard that reads the
#: whole tree minus something. The count has to match what the guard's own grep
#: will read or the success message overclaims, which is the defect this
#: function exists to end rather than one to reproduce inside it.
#:
#: **Every path is required to hold something, not the set of them collectively.**
#: Summing the counts is how a guard passes with one of its two directories
#: empty — found by the mutation cases in `test_guard_mutations.py` on the first
#: version of this function, which summed.
#:
#: `IGNORED_DIRS` is pruned, so the number is the number of files the guard's
#: own grep will read. A count that included `node_modules` would be a success
#: message overclaiming by four orders of magnitude, which is this finding's
#: second half wearing the shape of its first.
#:
#: **The count is of files this guard can open**, and H5 is why that sentence is
#: worth being exact about. This counted files and claimed readability, which is
#: this file's own defect one size smaller: an unreadable file greps exactly
#: like an absent one, because `grep -r` writes a permission error to stderr —
#: which every guard here discards — and contributes no matches. A tree nobody
#: could open would have been counted and reported as examined.
#:
#: Sets `SCANNED_FILES`. Not a subshell — it exits the guard on failure, and a
#: `$(…)` call would exit the substitution instead and carry on, which is the
#: same silent pass in a new costume.
require_scan() {
  local what="$1"
  local kinds="$2"
  shift 2

  require_paths "$@"

  local prune=()
  local dir
  for dir in "${IGNORED_DIRS[@]}"; do
    if [ ${#prune[@]} -gt 0 ]; then
      prune+=(-o)
    fi
    prune+=(-name "$dir")
  done

  local wanted=()
  local unwanted=()
  local ext
  for ext in $kinds; do
    case "$ext" in
      \!*)
        if [ ${#unwanted[@]} -gt 0 ]; then
          unwanted+=(-a)
        fi
        unwanted+=(! -name "*.${ext#\!}")
        ;;
      *)
        if [ ${#wanted[@]} -gt 0 ]; then
          wanted+=(-o)
        fi
        wanted+=(-name "*.$ext")
        ;;
    esac
  done

  local find_args=()
  [ ${#wanted[@]} -gt 0 ] && find_args+=(\( "${wanted[@]}" \))
  [ ${#unwanted[@]} -gt 0 ] && find_args+=("${unwanted[@]}")

  local total=0
  local path
  local found
  for path in "$@"; do
    # **Readable, not merely present.** H5. This counted files and the docstring
    # above claimed it validated that the guard could read them — a smaller
    # version of the defect this whole file exists to end, because an
    # unreadable file greps exactly like an absent one: `grep -r` prints a
    # permission error to stderr, which every one of these guards discards, and
    # contributes no matches. A tree of files nobody can open would have been
    # counted and reported as examined.
    #
    # `-r` per file rather than `find -readable`, which is GNU-only and absent
    # on the BSD find macOS ships — a guard that behaves differently on a
    # developer's machine and in CI is a guard with two verdicts, which is Q-10.
    found=$(find "$path" \( "${prune[@]}" \) -prune -o -type f \
              "${find_args[@]}" -print 2>/dev/null \
            | while IFS= read -r file; do
                [ -r "$file" ] && printf 'x\n'
              done | wc -l | tr -d ' ')
    if [ "$found" -eq 0 ]; then
      echo "FAIL: this guard checks $what and found nothing to examine." >&2
      echo >&2
      echo "Looked in: $path" >&2
      [ -n "$kinds" ] && echo "For files of kind: $kinds" >&2
      echo >&2
      echo "A scan of nothing is not a clean scan. This is pointed at the wrong" >&2
      echo "place rather than at a tree that happens to be correct." >&2
      exit 2
    fi
    total=$((total + found))
  done

  SCANNED_FILES="$total"
}

#: Whether this tree is a git checkout at all.
in_git_work_tree() {
  git rev-parse --is-inside-work-tree >/dev/null 2>&1
}

#: `git grep -lE` where there is an index, `grep -rlE` where there is not.
#:
#: Usage: repo_grep <pattern> <path>... -- <exclude-path>...
#:
#: The excludes are spelled once here in both dialects, because a guard whose
#: two modes disagree about what to skip is a guard with two different verdicts.
repo_grep() {
  local pattern="$1"
  shift

  local paths=()
  local excludes=()
  local seen_sep=0
  local arg
  for arg in "$@"; do
    if [ "$arg" = "--" ]; then
      seen_sep=1
      continue
    fi
    if [ "$seen_sep" -eq 1 ]; then
      excludes+=("$arg")
    else
      paths+=("$arg")
    fi
  done

  if in_git_work_tree; then
    local spec=()
    local exclude
    for exclude in "${excludes[@]:-}"; do
      [ -n "$exclude" ] && spec+=(":(exclude)$exclude")
    done

    # Tracked files, and the untracked ones git is not ignoring.
    #
    # `git grep` alone reads the index, so a file nobody has committed yet is
    # invisible to it — which is every file, at the moment somebody writes it.
    # Proven by execution: `api/app/watch/zz_probe.py` containing `import
    # anthropic`, never added, left the guard exiting 0. That is §S13's finding
    # again, moved from "not a checkout" to "not yet committed".
    #
    # `--exclude-standard` is what keeps this honest in the other direction: it
    # applies .gitignore, so the untracked sweep picks up new source and not the
    # virtual environment. The non-git branch below reaches the same set from
    # the other side, with IGNORED_DIRS standing in for the ignore file.
    {
      git grep -lE "$pattern" -- "${paths[@]}" "${spec[@]:-}" 2>/dev/null || true
      local untracked
      untracked=$(git ls-files --others --exclude-standard -- "${paths[@]}" 2>/dev/null || true)
      if [ -n "$untracked" ]; then
        printf '%s\n' "$untracked" \
          | while IFS= read -r file; do
              [ -f "$file" ] && grep -lE "$pattern" "$file" 2>/dev/null
            done
      fi
    } | sort -u | _drop_excluded "${excludes[@]:-}"
    return 0
  fi

  # Not a checkout. Same patterns, same paths, same excludes — the difference
  # is only where the bytes are read from, and IGNORED_DIRS does here what
  # .gitignore does above.
  local found
  # shellcheck disable=SC2046 — the excludes must word-split into separate args.
  found=$(grep -rlE "$pattern" $(grep_excludes) "${paths[@]}" 2>/dev/null || true)
  printf '%s\n' "$found" | sed '/^$/d' | sort -u | _drop_excluded "${excludes[@]:-}"
}

#: Drop the caller's named exemptions from a list of paths on stdin.
#:
#: Shared by both branches so that "which files are allowed to match" is one
#: piece of logic rather than two — a guard whose two modes disagree about what
#: to skip is a guard with two verdicts, which is what this file exists to end.
_drop_excluded() {
  local out
  out=$(cat)
  local exclude
  for exclude in "$@"; do
    [ -n "$exclude" ] && out=$(printf '%s\n' "$out" | grep -vF "$exclude" || true)
  done
  printf '%s\n' "$out" | sed '/^$/d'
}
