"""
Process everything waiting in a tenant's file drop.

The entry point for `app/batch.py`. What a scheduler runs nightly, and what an
operator runs by hand when a firm says they have re-sent a file.

    make batch-sweep                              # the deployment's own tenant
    make batch-sweep ARGS="acme --actor apc_x"
    make batch-sweep ARGS="--drop /srv/quolin/drop"

**The drop root is configuration, not a constant.** In a deployment it is the
directory the SFTP daemon chroots each tenant into; locally it is wherever you
point it. `QUOLIN_DROP_ROOT` sets the default.

**`--actor` is required and is a machine credential.** A nightly run at 02:00
has no person behind it, so under Stage 2's rule `service.audit` refuses to
write for it — correctly, since an unattributed row is exactly what that rule
exists to prevent. The answer is that the thing acting is the `api_clients`
credential that owns the drop, and the audit trail names it.

Exit codes: 0 when every file was processed, 1 when any file failed outright,
2 when the run could not start. A file with *rejected rows* is not a failure —
that is the gate this stage is built to, and the rejects are written back beside
the file for the firm to fix.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from app import batch, maintenance, tenancy  # noqa: E402
from app.db import OwnerSessionLocal, SessionLocal  # noqa: E402



def _every_active_firm() -> list[str]:
    """Every active customer, when no tenant was named.

    `tenancy.configured_tenant()` was the default, and on a shared deployment
    that is one firm out of however many — so this job ran, reported success,
    and served nobody else. Q-01's shape exactly: an enumeration that returns
    one thing and a caller that reads it as everything.

    The docstring above once said tenants are named and not discovered, "because
    under FORCE ROW LEVEL SECURITY a query for all tenants returns the one in
    scope". That was true and stopped being true at migration 0029, which
    created the `quolin_maintenance` grant precisely so a scheduled worker can
    ask. `scripts/artefact_worker.py` and `scripts/bulk_worker.py` have
    enumerated this way since; this is the same call, with the preflight
    `scripts/health_alerts.py` has and they do not.

    `assert_can_enumerate` first, because the failure mode without it is the one
    F12 named: a connection that cannot see `tenants` returns an empty list, the
    loop runs zero times, and the job exits 0 having done nothing.
    """
    session = OwnerSessionLocal()
    try:
        maintenance.assert_can_enumerate(session)
        return maintenance.active_tenant_ids(session)
    finally:
        session.close()

def main() -> int:
    parser = argparse.ArgumentParser(description="Process a tenant's file drop.")
    parser.add_argument("tenants", nargs="*", help="Tenant ids. Defaults to the configured one.")
    parser.add_argument(
        "--drop",
        default=os.getenv("QUOLIN_DROP_ROOT", "./drop"),
        help="Root of the file drop. One directory per tenant beneath it.",
    )
    parser.add_argument(
        "--actor",
        default=os.getenv("QUOLIN_BATCH_ACTOR", ""),
        help="The api_clients id this run acts as. Required.",
    )
    parser.add_argument("--json", action="store_true", help="Machine-readable output.")
    args = parser.parse_args()

    if not args.actor:
        print(
            "--actor is required: a batch run acts as the machine credential that "
            "owns the drop, so the audit trail can name what loaded the file. Set "
            "it, or QUOLIN_BATCH_ACTOR.",
            file=sys.stderr,
        )
        return 2

    tenants = args.tenants or _every_active_firm()
    root = Path(args.drop)
    reports = []

    for tenant_id in tenants:
        # One session per tenant, for the reason every other multi-tenant loop
        # in this repository gives.
        with tenancy.acting_as(tenant_id):
            session = SessionLocal()
            try:
                results = batch.sweep(
                    session, tenant_id=tenant_id, base=root, started_by=args.actor
                )
            except Exception as exc:
                print(
                    f"sweep failed for {tenant_id}: {type(exc).__name__}: {exc}",
                    file=sys.stderr,
                )
                return 2
            finally:
                session.close()

        # Written back into the drop so the firm's own scheduler can read what
        # happened without calling an API — which is the whole reason they are
        # on files rather than HTTP.
        if results:
            (batch.drop_root(root, tenant_id) / "manifest.json").write_text(
                batch.manifest(results)
            )
        reports.append({"tenant_id": tenant_id, "files": [r.as_dict() for r in results]})

    if args.json:
        print(json.dumps(reports, indent=2))
    else:
        for report in reports:
            print(f"\ntenant {report['tenant_id']}: {len(report['files'])} file(s)")
            for result in report["files"]:
                print(
                    f"  {result['filename']:32} {result['status']:24} "
                    f"{result['rows_written']} written, {result['rows_rejected']} rejected"
                )

    failed = sum(
        1 for r in reports for f in r["files"] if f["status"] == "failed"
    )
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
