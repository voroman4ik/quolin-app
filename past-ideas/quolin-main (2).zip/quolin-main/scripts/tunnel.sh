#!/usr/bin/env bash
#
# Publishes the running demo over HTTPS so a phone can install it as a real PWA.
#
# Two tunnels, not one: the page is served over HTTPS, so any API call it makes
# must also be HTTPS or the browser blocks it as mixed content. The web tunnel
# therefore has to know the API tunnel's address before Next.js starts.
#
# Everything here is a Cloudflare quick tunnel: no account, random hostname,
# gone when this script exits.
#
# Usage — two terminals, in this order:
#
#   make api                        # terminal 1; must be listening before this runs
#   make tunnel                     # terminal 2
#   WEB_PORT=3100 make tunnel       # if something already holds :3000
#
# This starts its own Next.js on WEB_PORT, so do NOT have `make web` running —
# Next 16 permits one dev server per directory, and the pre-flight below says so
# rather than letting this look like a hang.
#
# What the phone gets is the *development* build. The service worker registers
# as /sw.js?dev=1 and treats build assets as mutable; the data path — network
# first, cache fallback, X-Quolin-From-Cache — is the same one the deployed PWA
# uses and the same one `make offline-test` exercises against a production
# build. So this proves the install and the offline behaviour on real iOS; it is
# not a test of the production bundle.
#
# Requires `brew install cloudflared`. Ctrl-C to tear everything down.
#
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WEB_PORT="${WEB_PORT:-3000}"
API_PORT="${API_PORT:-8000}"

[ "$WEB_PORT" != "$API_PORT" ] || {
  echo "WEB_PORT and API_PORT are both ${WEB_PORT}; they must differ."; exit 1
}

command -v cloudflared >/dev/null || { echo "cloudflared not installed: brew install cloudflared"; exit 1; }

curl -sf "http://localhost:${API_PORT}/health" >/dev/null \
  || { echo "No API on :${API_PORT}. Run 'make api' first."; exit 1; }

# -sTCP:LISTEN matters: a plain -i match also counts browser connections to the
# port, which would report "in use" when nothing is serving.
if lsof -nP -iTCP:"${WEB_PORT}" -sTCP:LISTEN >/dev/null 2>&1; then
  echo "Port ${WEB_PORT} is already in use. Stop that server, or set WEB_PORT."
  exit 1
fi

# A free port is no longer enough. Next 16 allows one dev server per directory,
# so `make web` on :3000 blocks this on :3100 as well — and the refusal arrives
# on the Next server's own stdout, which this script does not read until it has
# already waited sixty seconds. Reading the lock turns a minute of apparent
# hanging into one sentence. The PID check matters because a crashed server
# leaves the file behind.
DEV_LOCK="$ROOT/web/.next/dev/lock"
if [ -f "$DEV_LOCK" ]; then
  LOCK_PID="$(sed -n 's/.*"pid":\([0-9]*\).*/\1/p' "$DEV_LOCK")"
  if [ -n "$LOCK_PID" ] && kill -0 "$LOCK_PID" 2>/dev/null; then
    echo "A Next dev server is already running in web/ (pid ${LOCK_PID})."
    echo "Next allows only one per directory, so this cannot start its own."
    echo "Stop it — 'kill ${LOCK_PID}', or Ctrl-C the 'make web' terminal — and rerun."
    exit 1
  fi
fi

LOG_DIR="$(mktemp -d)"
PIDS=()

# Killing the PID of `( ... npm run dev ) &` kills the subshell, not the Next
# server underneath it. That server keeps the port, and the next run of this
# script dies on the "already in use" check above. Kill the listener too.
kill_listener() {
  local port="$1" pid
  for pid in $(lsof -nP -iTCP:"$port" -sTCP:LISTEN -t 2>/dev/null || true); do
    kill "$pid" 2>/dev/null || true
  done
}

cleanup() {
  echo ""
  echo "Shutting down tunnels..."
  for pid in "${PIDS[@]:-}"; do kill "$pid" 2>/dev/null || true; done
  kill_listener "$WEB_PORT"
  rm -rf "$LOG_DIR"
}
trap cleanup EXIT INT TERM

# cloudflared prints the assigned hostname to stderr a second or two after start.
wait_for_url() {
  local log="$1" name="$2" url=""
  for _ in $(seq 1 40); do
    url="$(grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' "$log" 2>/dev/null | head -1 || true)"
    [ -n "$url" ] && { echo "$url"; return 0; }
    sleep 1
  done
  echo "Timed out waiting for the ${name} tunnel. Log:" >&2
  cat "$log" >&2
  return 1
}

echo "Opening API tunnel..."
cloudflared tunnel --url "http://localhost:${API_PORT}" --no-autoupdate \
  > "$LOG_DIR/api.log" 2>&1 &
PIDS+=($!)
API_URL="$(wait_for_url "$LOG_DIR/api.log" API)"
echo "  API   $API_URL"

echo "Starting web against that API..."
# `next` directly, not `npm run dev --`. The package script already hardcodes
# `-p 3000`, so the npm form produced `next dev -p 3000 -p 3100` and worked only
# because the last flag wins — a coincidence, not a contract.
( cd "$ROOT/web" && NEXT_PUBLIC_API_BASE="$API_URL" npx next dev -p "$WEB_PORT" ) \
  > "$LOG_DIR/web.log" 2>&1 &
PIDS+=($!)

# Bounded: an unbounded loop here hangs silently forever when npm fails to
# start, which looks identical to a slow first compile.
web_up=""
for _ in $(seq 1 60); do
  if curl -sf "http://localhost:${WEB_PORT}" >/dev/null 2>&1; then web_up=1; break; fi
  sleep 1
done
[ -n "$web_up" ] || {
  echo "Next.js did not come up on :${WEB_PORT} within 60s. Log:" >&2
  cat "$LOG_DIR/web.log" >&2
  exit 1
}

echo "Opening web tunnel..."
cloudflared tunnel --url "http://localhost:${WEB_PORT}" --no-autoupdate \
  > "$LOG_DIR/web-tunnel.log" 2>&1 &
PIDS+=($!)
WEB_URL="$(wait_for_url "$LOG_DIR/web-tunnel.log" web)"

# The API has to be told the web tunnel's hostname, and cannot be told earlier.
#
# A quick tunnel's hostname is random and is only known once cloudflared has
# connected, which is after the API has already started — and it is different
# on every run, so it cannot be pre-registered. Without it in
# QUOLIN_ALLOWED_ORIGINS the API sends no `access-control-allow-origin`, the
# browser discards every response, and the phone shows "Cannot reach the
# decision engine" on a system that is working perfectly. This was documented
# as a known gap and left to be discovered on the phone; discovering it here,
# with the command to fix it, costs one restart.
#
# Restarting the API does not disturb its tunnel — cloudflared reconnects to
# the port — which is what makes waiting here the right shape.
cors_ok() {
  curl -s -o /dev/null -D - -H "Origin: ${WEB_URL}" \
    "http://localhost:${API_PORT}/health" 2>/dev/null \
    | grep -qi "^access-control-allow-origin: ${WEB_URL}"
}

if ! cors_ok; then
  echo ""
  echo "  The API does not yet allow ${WEB_URL}."
  echo "  Every request from the phone would be discarded by the browser."
  echo ""
  echo "  In the terminal running 'make api': Ctrl-C, then"
  echo ""
  echo "    QUOLIN_ALLOWED_ORIGINS='${WEB_URL},http://localhost:3000' make api"
  echo ""
  echo "  Waiting for it (Ctrl-C here to give up)..."
  for _ in $(seq 1 300); do
    if cors_ok; then break; fi
    sleep 1
  done
  cors_ok || {
    echo "Still refused after five minutes. Nothing further to do from here." >&2
    exit 1
  }
  echo "  API now allows the tunnel."
fi

echo ""
echo "  Open this on the phone:  $WEB_URL"
echo ""
echo "  Safari > Share > Add to Home Screen. Offline works from this URL"
echo "  because it is HTTPS. Anyone with the link can reach the demo while"
echo "  this is running, so keep it to yourself and Ctrl-C when finished."
echo ""

wait
