"""Invariant 2, asked of a running interpreter rather than of the source text.

FP3-01's lesson applied to the engine guard. `guard_engine_is_pure.sh` was a set
of greps for import lines and forbidden names, and audit G-04 established by
execution that all of these passed it with exit 0:

    from datetime import datetime as _dt; _dt.now()
    importlib.import_module("os")
    __import__("time").time()

Reproduced on this tree before rewriting: the first three, injected together into
`api/app/engine/dsl.py`, exited 0.

Every one of them is the same defect. A grep can see the name `datetime` and it
cannot see what `_dt` is bound to; it can see the string `"os"` and it cannot
see that `importlib` will import it. The question "does the engine reach the
clock" is a question about a process, so this asks a process.

**Two checks, and they answer different halves.**

`--modules` imports `app.engine` in a clean subprocess and diffs `sys.modules`
against an allow-list. That is transitive by construction: a module the engine
imports, that imports `os`, puts `os` in the set. No alias, no `importlib`, no
`__import__` and no lazy import inside a function that actually runs can hide
from it.

`--determinism` runs the engine with `time.time`, `datetime.now`, `random` and
`os.environ` replaced by objects that raise, and evaluates the corpus. Anything
that reaches for one of them raises rather than returning a plausible number.
This is the half that catches a lazy import *inside* a function, which the
module set alone would miss until that function was called.

The lexical guard is kept in front of both as a fast pre-check — it runs in
milliseconds and gives a better error message on the ordinary case — but it is
no longer the enforcement, and `test_guard_mutations.py` proves that by injecting
the three cases above and requiring a non-zero exit.

**What this still cannot see, stated rather than glossed.** Reading `sys.argv`
into a variable and never using it passes: `sys` is in every interpreter's
baseline so the module set says nothing, and a C module cannot be given a
`__getattr__` that raises on attribute access. Using the value raises —
`Refuses.__getitem__` and `__getattr__` both do — so the gap is exactly "an
impure value was fetched and then ignored", which cannot change a determination.
Measured, not assumed: of the six cases audit G-04 lists, five are caught and
this is the sixth.

The same bound applies to a function-local import in a function nothing calls.
That is not a hole so much as the definition of the property: code that does not
run cannot make a determination irreproducible. What matters is the code the
corpus reaches, and that is what `--determinism` exercises.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
API = REPO / "api"

#: How many corpus snapshots the determinism run actually evaluated, so the
#: success line can say it. A guard that reports OK without saying what it
#: examined is one nobody can tell apart from a guard that examined nothing.
_EVALUATED: list[int] = []

#: Modules `app.engine` may pull in, directly or transitively.
#:
#: Everything here is pure computation over values it is handed. The absences
#: are the point: no `os`, no `time`, no `random`, no `socket`, no `sqlalchemy`,
#: nothing under `app.` that is not `app.engine` itself.
#:
#: `datetime` **is** allowed and is the interesting entry. Parsing `2026-06-01`
#: out of a pack is arithmetic on a value; asking what day it is now is not, and
#: importing the module does not distinguish them. That distinction is what
#: `--determinism` is for.
ALLOWED_MODULES = frozenset(
    {
        "abc",
        "argparse",
        "ast",
        "base64",
        "binascii",
        "bisect",
        "builtins",
        "collections",
        "contextlib",
        "copy",
        "copyreg",
        "csv",
        "dataclasses",
        "datetime",
        "decimal",
        "enum",
        "errno",
        "functools",
        "hashlib",
        "heapq",
        "inspect",
        "io",
        "itertools",
        "json",
        "keyword",
        "linecache",
        "math",
        "numbers",
        "operator",
        "pprint",
        "re",
        "reprlib",
        "string",
        "textwrap",
        "token",
        "tokenize",
        "types",
        "typing",
        "unicodedata",
        "warnings",
        "weakref",
        "zoneinfo",
        # Pulled in by `inspect`, which the engine uses for signatures in the
        # calcs registry. All pure: bytecode disassembly, text diffing and the
        # tokenizer. Listed rather than skipped, so that if the engine ever
        # imports one of them *directly* somebody has to notice.
        "difflib",
        "dis",
        "importlib",
        "linecache",
        "opcode",
        # The interpreter's own import machinery, which arrives the moment
        # anything is loaded from a file rather than frozen into the binary.
        "codecs",
        "encodings",
        "genericpath",
        "os",  # see below
        "posixpath",
        "stat",
        "zipimport",
    }
)

#: `os` is in the list above and that looks wrong, so it is worth being explicit.
#:
#: `importlib._bootstrap_external` imports `os` to find files on disk. Every
#: Python process that loads a module from a `.py` file has `os` in
#: `sys.modules` before any of our code runs, so its presence says nothing about
#: the engine.
#:
#: What matters is whether the engine *uses* it, and that is exactly what
#: `--determinism` answers: `os.environ` and `os.urandom` are replaced with
#: objects that raise, and evaluating the corpus must not touch either. A module
#: set can say "this was loaded"; only running the code can say "this was read".
_OS_IS_THE_IMPORT_MACHINERY = True

#: Modules that are always present in a fresh interpreter, before anything of
#: ours is imported. Measured rather than listed, so a Python upgrade that adds
#: one does not read as an engine violation.
BASELINE_SCRIPT = "import sys, json; print(json.dumps(sorted(sys.modules)))"

MODULE_SCRIPT = """
import json, sys
before = set(sys.modules)
import app.engine  # noqa: F401
print(json.dumps(sorted(set(sys.modules) - before)))
"""

DETERMINISM_SCRIPT = '''
"""Evaluate the corpus with every source of non-determinism poisoned."""
import json
import os
import random
import sys
import time
from datetime import datetime


class Refuses:
    """Anything that touches this raises, loudly and by name."""

    def __init__(self, what):
        self._what = what

    def __call__(self, *a, **k):
        raise AssertionError(
            f"the engine reached {self._what}, which is invariant 2 broken: a "
            "determination that consulted it would replay differently"
        )

    def __getattr__(self, name):
        raise AssertionError(
            f"the engine reached {self._what}.{name}, which is invariant 2 "
            "broken: a determination that consulted it would replay differently"
        )

    def __getitem__(self, key):
        raise AssertionError(
            f"the engine read {self._what}[{key!r}], which is an input nobody "
            "recorded"
        )


time.time = Refuses("time.time")
time.monotonic = Refuses("time.monotonic")
time.time_ns = Refuses("time.time_ns")
random.random = Refuses("random.random")
random.randint = Refuses("random.randint")
random.choice = Refuses("random.choice")
os.environ = Refuses("os.environ")
os.urandom = Refuses("os.urandom")


class _Date(datetime):
    @classmethod
    def now(cls, tz=None):
        raise AssertionError(
            "the engine called datetime.now(), which is invariant 2 broken: "
            "`as_of` is carried in the snapshot precisely so a determination "
            "reproduces on any day it is replayed"
        )

    @classmethod
    def utcnow(cls):
        raise AssertionError("the engine called datetime.utcnow()")

    @classmethod
    def today(cls):
        raise AssertionError("the engine called datetime.today()")


import datetime as _datetime_module  # noqa: E402

_datetime_module.datetime = _Date

from app.engine import Pack, evaluate_snapshot  # noqa: E402

corpus = json.loads(sys.argv[1])
packs = json.loads(sys.argv[2])

# Read first, then poisoned. Command-line arguments are an input nobody
# recorded in the snapshot, exactly like the environment — and an engine that
# read one would replay differently depending on how it was invoked.
sys.argv = Refuses("sys.argv")

evaluated = 0
for case in corpus:
    body = packs.get(case["pack_key"])
    if body is None:
        continue
    evaluate_snapshot(Pack.from_body(body), case["snapshot"])
    evaluated += 1

print(json.dumps({"evaluated": evaluated}))
'''


def _run(script: str, *args: str) -> subprocess.CompletedProcess[str]:
    """A clean interpreter, with `api/` importable and nothing else assumed."""
    return subprocess.run(
        [sys.executable, "-c", script, *args],
        cwd=API,
        capture_output=True,
        text=True,
        env={
            "PATH": "/usr/bin:/bin:/usr/sbin:/sbin",
            "PYTHONPATH": str(API),
            "HOME": "/tmp",
        },
    )


def check_modules() -> list[str]:
    """Import the engine and read back what came with it."""
    baseline = _run(BASELINE_SCRIPT)
    if baseline.returncode != 0:  # pragma: no cover - a broken interpreter
        return [f"could not measure the interpreter baseline: {baseline.stderr}"]
    already = set(json.loads(baseline.stdout))

    result = _run(MODULE_SCRIPT)
    if result.returncode != 0:
        return [f"importing app.engine failed: {result.stderr.strip()}"]

    arrived = set(json.loads(result.stdout)) - already

    problems = []
    for name in sorted(arrived):
        # Private modules are implementation details of public ones. `_datetime`
        # is what `datetime` is; flagging it would mean listing the C
        # accelerator for every module in the allow-list.
        if name.startswith("_"):
            continue
        root = name.split(".")[0]
        if root == "app":
            # `app.engine` and its submodules only. `app.anything_else` is the
            # arrow pointing back at the application, which is how a database
            # connection gets in without anybody importing one.
            if not (name == "app" or name.startswith("app.engine")):
                problems.append(
                    f"importing app.engine pulls in {name}, which is application "
                    "code. The engine is imported by the service, never the "
                    "reverse."
                )
            continue
        if root not in ALLOWED_MODULES:
            problems.append(
                f"importing app.engine pulls in {name}. Invariant 2: the engine "
                "reads the snapshot it is handed and the pack it is given, and "
                "nothing else. If this module is genuinely pure computation, add "
                "it to ALLOWED_MODULES with a reason."
            )
    return problems


def check_determinism() -> list[str]:
    """Evaluate the corpus with the clock, randomness and environment poisoned.

    Catches what the module set cannot: an import inside a function body, which
    does not appear in `sys.modules` until that function runs.
    """
    corpus_dir = REPO / "corpus"
    packs_dir = REPO / "packs"
    if not corpus_dir.is_dir() or not packs_dir.is_dir():
        return ["no corpus/ or packs/ to evaluate; this check examined nothing"]

    # Keyed on the file stem, which is how a corpus case names its pack:
    # `"pack": "au_v1"`.
    packs = {path.stem: json.loads(path.read_text()) for path in sorted(packs_dir.glob("*.json"))}

    cases = []
    for path in sorted(corpus_dir.rglob("*.json")):
        try:
            case = json.loads(path.read_text())
        except json.JSONDecodeError:
            continue
        snapshot = case.get("snapshot")
        key = case.get("pack")
        if isinstance(snapshot, dict) and isinstance(key, str) and key in packs:
            cases.append({"snapshot": snapshot, "pack_key": key})

    if not cases:
        return [
            "no corpus case could be paired with a shipped pack, so the "
            "determinism check evaluated nothing. That is a failure, not a pass."
        ]

    result = _run(DETERMINISM_SCRIPT, json.dumps(cases), json.dumps(packs))
    if result.returncode != 0:
        tail = result.stderr.strip().splitlines()
        return [tail[-1] if tail else "the determinism run failed with no message"]

    evaluated = json.loads(result.stdout).get("evaluated", 0)
    if not evaluated:
        return [
            "the determinism run evaluated zero snapshots, so it proved nothing. "
            "A check that examined nothing is a failure, not a pass."
        ]
    _EVALUATED.append(evaluated)
    return []


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--modules", action="store_true")
    parser.add_argument("--determinism", action="store_true")
    args = parser.parse_args(argv)

    run_all = not (args.modules or args.determinism)
    problems: list[str] = []

    if run_all or args.modules:
        problems.extend(check_modules())
    if run_all or args.determinism:
        problems.extend(check_determinism())

    if problems:
        for problem in problems:
            print(f"FAIL: {problem}")
        return 1

    examined = f" ({_EVALUATED[0]} corpus snapshots)" if _EVALUATED else ""
    print(
        "OK: app.engine imports nothing outside the pure standard library, and "
        f"evaluates the corpus{examined} with the clock, randomness and "
        "environment replaced by objects that raise."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
