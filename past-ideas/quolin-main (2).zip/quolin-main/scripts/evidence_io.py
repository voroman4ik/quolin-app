"""Write a control's output somewhere an auditor can find it a year later.

The sharpest line in the external review was that **a generator is not evidence
that the control operated**. Every drill, access review, game day and scan in
this repository printed to stdout and vanished. Running them proved something to
whoever was watching the terminal and nothing to anybody else.

The other half is that a SOC 2 observation window is wall-clock. The room has to
start filling before it is needed, because there is no way to produce six months
of history in the month somebody asks for it — and a folder that appears fully
formed the week before an audit is worth less than an empty one, because it
invites the question of where it came from.

**What an artefact carries.** What ran, when, against which environment, at
which commit, who invoked it, what the result was, and a digest of its own
content. The environment matters more than it looks: a restore drill against a
laptop and one against staging are different facts, and a folder that does not
distinguish them lets the weaker one be read as the stronger.

**The digest is of the artefact, not of the run.** It detects a file edited
after the fact. It cannot detect a run that never happened — somebody with write
access to this folder can write a convincing artefact, and no amount of hashing
inside the folder fixes that. What it does is make an *alteration* visible,
which is the same claim the evidence chain makes and worth the same care not to
overstate.

Nothing here creates an artefact for a control that has not run. An empty folder
is the honest state and reads as one.
"""

from __future__ import annotations

import getpass
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_ROOT = Path(__file__).resolve().parents[1]

#: Where the room is. Contents are gitignored — an evidence artefact names
#: people and describes a specific deployment on a specific day, and a git
#: history is the wrong home for both.
ROOM = _ROOT / "evidence"

#: One folder per kind of control, so an auditor navigating the room does not
#: have to read filenames to know what they are looking at.
CATEGORIES = (
    "access-reviews",
    "drills",
    "game-days",
    "scans",
    "deployments",
    "incidents",
    "pack-signatures",
)


class UnknownCategory(ValueError):
    """A category not in `CATEGORIES`.

    Refused rather than created on demand. A misspelled folder is evidence
    filed where nobody will look for it, which is indistinguishable from
    evidence that was never filed.
    """


def _git_sha() -> str:
    """The commit this ran at, or an honest marker when there is no checkout."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=_ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        return "not-a-git-checkout"


def _dirty() -> bool:
    """Whether the tree had uncommitted changes when this ran.

    Recorded because "at commit abc123" is a weaker claim than it sounds when
    the working tree did not match it, and an auditor comparing an artefact
    against the code is entitled to know.
    """
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=_ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        return bool(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        return False


def environment() -> str:
    """Which deployment this ran against.

    `QUOLIN_ENVIRONMENT` where it is set, and `local` where it is not — never
    silently omitted. A restore drill against a laptop and one against staging
    are different facts, and an artefact that does not say which is the weaker
    of the two being read as the stronger.
    """
    return os.getenv("QUOLIN_ENVIRONMENT", "").strip() or "local"


def _invoked_by() -> str:
    """Who ran it. A login name, or CI naming itself."""
    if os.getenv("GITHUB_ACTIONS"):
        return f"github-actions:{os.getenv('GITHUB_WORKFLOW', 'workflow')}"
    for variable in ("QUOLIN_EVIDENCE_ACTOR", "SUDO_USER", "USER", "LOGNAME"):
        value = os.getenv(variable, "").strip()
        if value:
            return value
    try:
        return getpass.getuser()
    except Exception:  # noqa: BLE001 — a name we cannot read is not a failure
        return "unknown"


def _digest(body: dict[str, Any]) -> str:
    """A digest of the artefact's own content, canonical-JSON as everywhere else."""
    return hashlib.sha256(
        json.dumps(body, sort_keys=True, separators=(",", ":"), default=str).encode()
    ).hexdigest()


def stamp(now: datetime | None = None) -> str:
    """`YYYY-MM-DDTHH-MM-SSZ` — sortable, and legal in a filename on every OS."""
    moment = now or datetime.now(timezone.utc)
    return moment.astimezone(timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")


#: How many same-second collisions to work through before giving up. Far above
#: anything real — `make game-day` fires a handful of controls at once — and
#: present so that a bug which made every claim fail spins to a clear error
#: rather than for ever.
_MAX_CLAIMS = 500


def _claim(folder: Path, base: str, payload: str) -> tuple[Path, str]:
    """Take exclusive ownership of an artefact's two filenames, and write the JSON.

    F-04. The name was previously chosen with `.exists()` and then written,
    which is a check followed by a use: two processes can both pass the check
    for the same name, and the second write destroys the first artefact.

    `open(..., "x")` is `O_EXCL` — the operating system creates the file or
    tells you somebody else already did, with no window in between. The `.md` is
    claimed empty in the same round so that both halves of one artefact belong
    to one writer; `write` fills it immediately afterwards, into a file it now
    owns. A `.md` that cannot be claimed releases the `.json` and the writer
    moves to the next number, because a mismatched pair is worse than either
    file being absent.
    """
    for attempt in range(1, _MAX_CLAIMS + 1):
        name = base if attempt == 1 else f"{base}-{attempt}"
        json_path = folder / f"{name}.json"
        markdown_path = folder / f"{name}.md"
        try:
            with open(json_path, "x", encoding="utf-8") as handle:
                handle.write(payload)
        except FileExistsError:
            continue
        try:
            with open(markdown_path, "x", encoding="utf-8"):
                pass
        except FileExistsError:
            json_path.unlink(missing_ok=True)
            continue
        return json_path, name

    raise OSError(
        f"could not claim a filename for {base!r} in {folder} after "
        f"{_MAX_CLAIMS} attempts. Evidence was not filed, which is reported "
        "rather than swallowed: a control whose artefact silently went missing "
        "is the failure this module exists to prevent."
    )


def write(
    category: str,
    what: str,
    result: dict[str, Any],
    *,
    passed: bool | None = None,
    summary: str = "",
    out: Path | None = None,
    now: datetime | None = None,
) -> Path:
    """File one artefact, and return where it went.

    Two files are written: the JSON an index can walk, and a `.md` a person can
    read without a parser. The second is not decoration — the reader of an
    evidence room is often an auditor with no tooling and an afternoon, and a
    folder of raw JSON is a folder they will ask us to explain.
    """
    if category not in CATEGORIES:
        raise UnknownCategory(
            f"{category!r} is not an evidence category. Known: "
            f"{', '.join(CATEGORIES)}. Add one deliberately rather than "
            "filing where nobody will look."
        )

    moment = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    folder = (out or ROOM) / category
    folder.mkdir(parents=True, exist_ok=True)

    body: dict[str, Any] = {
        "control": what,
        "category": category,
        "ran_at": moment.isoformat(),
        "environment": environment(),
        "git_sha": _git_sha(),
        "working_tree_dirty": _dirty(),
        "invoked_by": _invoked_by(),
        "passed": passed,
        "summary": summary,
        "result": result,
    }
    body["content_sha256"] = _digest(body)

    # Two runs in the same second must not become one artefact.
    #
    # The timestamp is second-resolution because a filename is read by people,
    # and the first version stopped there — so a control run twice inside a
    # second silently overwrote its own evidence. That is precisely the failure
    # this module exists to prevent, and a test caught it by filing a pass and
    # a fail back to back and finding one artefact.
    #
    # A counter rather than finer resolution: it keeps the name readable, keeps
    # the ordering, and makes the collision visible in the folder rather than
    # hiding it behind microseconds nobody reads.
    #
    # F-04: the counter was chosen with `.exists()` and then written with
    # `write_text`, which closes the sequential collision and not the concurrent
    # one. Two processes both see a name as free, both write it, and the later
    # write silently destroys the earlier control's artefact — the exact
    # evidence the audit process relies on, with nothing left saying it existed.
    # `make game-day` fires every alert path at once, so this is ordinary rather
    # than exotic.
    #
    # `open(..., "x")` moves the claim into the operating system, where exactly
    # one process can win. The loser takes the next number, which is what the
    # counter always meant.
    #
    # **Both halves are claimed by the same writer or neither is.** The `.md` is
    # what a person opens, and a pair whose two files came from different runs
    # reads as a coherent record of something that did not happen — worse than a
    # missing file. So a `.md` that cannot be claimed releases the `.json` and
    # the writer takes the next number with both.
    base = f"{stamp(moment)}-{what}"
    payload = json.dumps(body, indent=2, default=str) + "\n"
    verdict = "not stated" if passed is None else ("passed" if passed else "FAILED")

    path, name = _claim(folder, base, payload)

    (folder / f"{name}.md").write_text(
        "\n".join(
            [
                f"# {what}",
                "",
                f"- **Ran** {moment.isoformat()}",
                f"- **Environment** {body['environment']}",
                f"- **Commit** `{body['git_sha'][:12]}`"
                + (
                    "  (working tree had uncommitted changes)"
                    if body["working_tree_dirty"]
                    else ""
                ),
                f"- **Invoked by** {body['invoked_by']}",
                f"- **Result** {verdict}",
                "",
                summary or "_No summary was given._",
                "",
                "---",
                "",
                f"Machine-readable record: `{path.name}`  ",
                f"Content digest `sha256:{body['content_sha256'][:16]}…` — "
                "`scripts/evidence_index.py` recomputes it and reports a mismatch.",
                "",
                "This artefact records that the control ran and what it returned. "
                "It does not, and cannot, prove that a run happened at all: "
                "somebody with write access to this folder could author one. What "
                "the digest catches is a file altered after it was filed.",
                "",
            ]
        )
    )
    return path


def verify(path: Path) -> tuple[bool, str]:
    """Recompute an artefact's digest. Returns whether it matches, and why not."""
    try:
        body = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        return False, f"could not be read: {exc}"

    recorded = body.pop("content_sha256", "")
    if not recorded:
        return False, "carries no digest, so it cannot be checked at all"
    if _digest(body) != recorded:
        return False, "content does not match its recorded digest"
    return True, ""
