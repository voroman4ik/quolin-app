#!/usr/bin/env bash
# Invariant 2: deterministic decisions; the frozen snapshot is the only input.
#
# §3.1 of the execution document names the enforcement for this invariant as
# "tests, plus an `import-linter` contract forbidding DB/network/clock imports
# in `engine/`". The tests exist and the property holds — the engine imports
# nothing but the standard library and its own submodules — but nothing enforced
# it, so the invariant rested on everybody who touches `engine/` remembering.
# The Audit Gate asks for every invariant to have "a CI test that fails when
# violated", and this is that test for invariant 2.
#
# A guard rather than `import-linter`, for the reason the other five are guards:
# one mechanism, one file each, no dependency that can be uninstalled, and the
# same `guard_lib.sh` refusal to pass having examined nothing.
#
# What "pure" means here, precisely. The engine may read the snapshot it is
# handed and the pack it is given, and nothing else:
#
#   * **No database.** A determination that read a row would depend on when it
#     ran, and replay in 2031 would not reproduce it.
#   * **No network.** Same reason, worse. It would also make the evaluator's
#     latency somebody else's uptime.
#   * **No clock.** This is the subtle one and the one worth the guard. `as_of`
#     is carried *in the snapshot*, deliberately, so a determination made for a
#     date reproduces on any day it is replayed. A `datetime.now()` inside the
#     engine would produce a decision that changes every time it is re-run,
#     which is invariant 5 broken silently rather than loudly.
#   * **No randomness, no environment.** Both are inputs nobody recorded.
#   * **Nothing from the application.** The engine is imported by the service,
#     never the reverse; the arrow pointing back is how a database connection
#     gets in without anyone importing one.
#
# `from datetime import date` is allowed and used: parsing `2026-06-01` out of a
# pack is arithmetic on a value, not a reading of the clock. What is forbidden
# is asking what time it is now.
#
# FP3-02 note, added after audit G-04: **the greps below are no longer the
# enforcement.** They were, and they exited 0 on `from datetime import datetime
# as _dt; _dt.now()`, on `importlib.import_module("os")` and on
# `__import__("time").time()` — reproduced on this tree. A grep can see the name
# `datetime` and cannot see what `_dt` is bound to.
#
# `scripts/engine_purity.py` runs at the end of this file and is what actually
# decides. It imports `app.engine` in a clean interpreter and diffs
# `sys.modules`, then evaluates the corpus with the clock, randomness,
# environment and argv replaced by objects that raise.
#
# The lexical checks are kept in front of it because they run in milliseconds
# and give a better message on the ordinary case — an import line somebody added
# without thinking — and because a fast pre-check that agrees with a slow
# authority costs nothing. They are a convenience now, not a control.
set -uo pipefail

# §S13: fail rather than pass when there is nothing to examine, and work the
# same outside a git checkout. See scripts/guard_lib.sh.
# shellcheck source=scripts/guard_lib.sh
. "$(dirname "$0")/guard_lib.sh"

ENGINE_DIR="${ENGINE_DIR:-api/app/engine}"

# The variable that is scanned, not a literal beside it. This read
# `require_paths api/app/engine` with `ENGINE_DIR` assigned separately on the
# next line — two spellings of one path, which is the shape the Gate A audit
# found in `guard_no_hardcoded_region.sh` where the two had come apart.
require_scan "the evaluator's purity" "py" "$ENGINE_DIR"

# Modules the engine may not import at all.
#
# `os` and `time` are named as whole modules rather than by the calls that
# matter: `os.environ` and `time.time()` are the ones with teeth, but an engine
# that has reached for either has already lost the argument, and a guard that
# allowed the import and policed the call site would be one refactor away from
# missing it.
FORBIDDEN_IMPORTS="\
^[[:space:]]*(from|import)[[:space:]]+(sqlalchemy|psycopg|psycopg2|asyncpg|alembic)\
|^[[:space:]]*(from|import)[[:space:]]+(requests|httpx|urllib|http|socket|aiohttp)\
|^[[:space:]]*(from|import)[[:space:]]+(boto3|botocore|redis|kafka)\
|^[[:space:]]*(from|import)[[:space:]]+(os|time|random|secrets|subprocess)\b\
|^[[:space:]]*from[[:space:]]+\.\.\
|^[[:space:]]*from[[:space:]]+app\b\
|^[[:space:]]*import[[:space:]]+app\b"

# Reading the clock, however it is spelled.
FORBIDDEN_CLOCK="\
\bdatetime\.now\(\
|\bdatetime\.utcnow\(\
|\.utcnow\(\
|\bdate\.today\(\
|\bdatetime\.today\(\
|\btime\.time\(\
|\btime\.monotonic\(\
|\bperf_counter\("

fail=0

if grep -rInE "$FORBIDDEN_IMPORTS" "$ENGINE_DIR"; then
  echo
  echo "FAIL: $ENGINE_DIR imports a database, a network client, the environment,"
  echo "randomness, or the application it is supposed to be independent of."
  echo
  echo "Invariant 2: the frozen snapshot is the only input to a determination."
  echo "Anything read from outside it is an input nobody recorded, and a"
  echo "decision that depends on one will not reproduce in 2031."
  fail=1
fi

if grep -rInE "$FORBIDDEN_CLOCK" "$ENGINE_DIR"; then
  echo
  echo "FAIL: $ENGINE_DIR reads the clock."
  echo
  echo "\`as_of\` travels inside the snapshot precisely so that a determination"
  echo "made for a date reproduces on any day it is replayed. A clock read here"
  echo "produces a decision that changes every time it runs — invariant 5"
  echo "broken quietly, which is the worst way for it to break."
  echo
  echo "Parsing a date out of pack content is fine: \`from datetime import date\`"
  echo "and \`date.fromisoformat(...)\` are values, not readings."
  fail=1
fi

if [ "$fail" -ne 0 ]; then
  exit 1
fi

echo "OK: $ENGINE_DIR reads only its snapshot and its pack — no database,"
echo "    network, clock, randomness, environment or application imports."

# The enforcement. Everything above is a pre-check.
_HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$_HERE/../api" || exit 1
exec uv run python "$_HERE/engine_purity.py"
