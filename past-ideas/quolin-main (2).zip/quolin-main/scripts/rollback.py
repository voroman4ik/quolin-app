"""Put the previous colour back, and time how long it took.

§S9's bad-deploy runbook opens with *roll back, then diagnose*, and the whole
reason that is a reasonable thing to ask of somebody at 3am is that rolling back
is fast and boring. §16 wants it proven under two minutes.

**It does not health-gate the target.** That is deliberate and it is the
difference between this script and `deploy.py`. The previous colour was serving
traffic a moment ago; making a rollback wait on a health check adds the one
thing a rollback cannot afford, and if the old colour has *also* died then the
answer is not to wait for it — it is that this is an outage rather than a bad
deploy, and the runbook says so.

**It is timed, and the time is filed.** A rollback nobody measured is a claim,
and "under two minutes" is a number somebody will eventually be asked to
support. The artefact records the elapsed seconds and, critically, the
environment — a rollback on a laptop and one on production are different facts,
and the second is the one §16 is asking about.

Usage:

    make rollback
    make rollback ARGS="--to blue"
    make rollback ARGS=--evidence-out

Exit codes: 0 when traffic moved back and the router answered, 1 when it could
not run, 2 when the router did not answer afterwards.
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))

from scripts import deploy, evidence_io

#: §16's target. Stated here so the artefact can say whether it was met rather
#: than leaving a reader to compare two numbers themselves.
TARGET_SECONDS = 120.0


def main() -> int:
    parser = argparse.ArgumentParser(description="Roll traffic back, and time it.")
    parser.add_argument("--to", choices=deploy.COLOURS, default=None)
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    try:
        from_colour = deploy.live_colour()
    except (OSError, RuntimeError) as exc:
        print(f"could not read the live colour: {exc}", file=sys.stderr)
        return 1

    to_colour = args.to or deploy.idle_colour()
    if to_colour == from_colour:
        print(f"{to_colour} is already serving.", file=sys.stderr)
        return 1

    # The clock starts here, at the decision, not after the setup. A rollback
    # measured from halfway through itself is a number that flatters us.
    started = time.monotonic()
    try:
        deploy.cut_over(to_colour)
    except Exception as exc:  # noqa: BLE001 — a rollback reports rather than crashes
        print(f"the router would not reload: {exc}", file=sys.stderr)
        return 1

    # The clock runs until a request from outside actually reaches the old
    # colour — not until the reload was signalled. `deploy.confirm` explains
    # why that distinction is not pedantry: asking once, immediately, reads the
    # router's previous configuration and gets the wrong answer.
    ok, serving = deploy.confirm(to_colour)
    elapsed = round(time.monotonic() - started, 2)

    result = {
        "from": from_colour,
        "to": to_colour,
        "seconds": elapsed,
        "target_seconds": TARGET_SECONDS,
        "within_target": elapsed <= TARGET_SECONDS,
        "serving": serving,
    }
    if ok:
        print(
            f"rolled back {from_colour} → {to_colour} in {elapsed:.1f}s "
            f"(target {TARGET_SECONDS:.0f}s)"
        )
    else:
        print(
            f"traffic was pointed at {to_colour}, but the router is still "
            f"answering as {serving!r}. That is an outage, not a bad deploy — "
            "see docs/runbooks/bad-deploy.md.",
            file=sys.stderr,
        )

    if args.evidence_out:
        evidence_io.write(
            "deployments",
            "rollback",
            result,
            passed=ok,
            summary=(
                f"Rolled traffic back from {from_colour} to {to_colour} in "
                f"{elapsed:.1f}s against a {TARGET_SECONDS:.0f}s target"
                + ("." if ok else ", but the router did not answer afterwards.")
                + " Timed from the decision to the router answering only as "
                f"{to_colour}. The number is about the environment named above "
                "and nothing larger: a rollback on a laptop is not a rollback "
                "on production infrastructure, and only the second answers §16."
            ),
        )
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
