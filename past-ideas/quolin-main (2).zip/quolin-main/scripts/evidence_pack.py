"""
Assemble the audit evidence folder for a window, and hash everything in it.

§S13's gate is "evidence folder complete for the audit window to date". This is
the command that makes that checkable rather than a claim somebody makes about a
shared drive.

**Evidence is a set of files with a manifest, not a folder somebody tidied.**
Every artefact in the pack is hashed and listed, so an auditor can be handed the
folder a year later and told exactly what it contained when it was assembled. A
file added afterwards is visible as a file not in the manifest; a file changed
afterwards is visible as a hash that no longer matches. `--verify` checks both.

**A control that could not be evidenced is recorded as missing, not omitted.**
The pack lists what it expected to collect and what it actually got. A folder
with four files in it and no statement of what should have been there is a folder
that looks complete.

**The sign-off names a provisioned person.** `--signed-by` is resolved against
the users table and refused if it does not match somebody who holds a role in the
tenant — the same rule the audit trail follows, for the same reason: a signature
that is a bare string names nobody, and the whole SOC 2 control is *the report
was read and signed off*, not that it was generated.

It is an attestation recorded beside a hash rather than a cryptographic
signature. The stronger form — re-authenticating through the product the way a
pack signature does — is owed and recorded in `docs/post-raise.md`.

Usage:

    make evidence-pack ARGS='--signed-by ruth.castellanos@quolin.example'
    make evidence-pack ARGS='--out evidence/2026-Q3 --signed-by ...'
    make evidence-pack ARGS='--verify evidence/2026-Q3'

Exit codes: 0 when the pack is complete, 1 when it could not be assembled, 2
when a control could not be evidenced or a hash does not match.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from sqlalchemy import select  # noqa: E402

from app import business_time, evidence, identity, tenancy  # noqa: E402
from app.db import SessionLocal  # noqa: E402
from app.models import AuditEvent, Decision  # noqa: E402

#: What a complete pack holds, and what produces each piece. Named here rather
#: than discovered from the folder, so a missing control is a finding rather
#: than a file nobody noticed was absent.
CONTROLS = {
    "access-review.md": "Quarterly access review — who holds what, and who has gone quiet",
    "access-review.json": "The same review, machine-readable, for the archive",
    "chain-verification.json": "Every determination re-hashed and the chain walked end to end",
    "replay.json": "Every determination re-evaluated against the pack of record",
    "audit-extract.json": "The audit trail for the window, as counts by action",
    "restore-drill.json": "A backup restored into a clean database and its chains verified",
}


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def _run(args: list[str], *, out: Path | None = None) -> tuple[int, str]:
    """One of this repository's own scripts, as the command line it is."""
    result = subprocess.run(
        [sys.executable, "-m", *args],
        cwd=_ROOT,
        capture_output=True,
        text=True,
    )
    if out is not None and result.stdout:
        out.write_text(result.stdout)
    return result.returncode, (result.stderr or result.stdout)[-800:]


def resolve_signer(email: str, tenant_id: str) -> dict:
    """The person signing, resolved to a row. Refused if they are not one.

    The rule the audit trail follows: an actor that is a bare string names
    nobody, and reads like a person right up until somebody asks who that is.
    """
    with tenancy.acting_as(tenant_id):
        session = SessionLocal()
        try:
            user = identity.find_by_email(session, email)
            if user is None:
                raise LookupError(
                    f"{email} is not a person in this system. A sign-off has to "
                    "name somebody who can be asked about it."
                )
            roles = identity.roles_for(session, user.id)
            if not roles:
                raise LookupError(
                    f"{email} exists but holds no role in {tenant_id}. Somebody "
                    "who cannot see the review cannot have reviewed it."
                )
            return {
                "email": user.email,
                "display_name": user.display_name,
                "user_id": user.id,
                "roles": sorted({r.role for r in roles}),
            }
        finally:
            session.close()


def collect(out: Path, tenant_id: str, since: date, until: date) -> dict[str, str]:
    """Produce every artefact. Returns what failed, keyed by filename."""
    out.mkdir(parents=True, exist_ok=True)
    problems: dict[str, str] = {}

    code, err = _run(
        ["scripts.access_review", "--out", str(out / "access-review.md")]
    )
    if code != 0:
        problems["access-review.md"] = err
    code, err = _run(["scripts.access_review", "--json"], out=out / "access-review.json")
    if code != 0:
        problems["access-review.json"] = err

    # The full chain walk, not the bounded one the dashboard uses. This is the
    # artefact an auditor is being handed; §S12's `verify_tail` is for a screen.
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user("apc_bulk_sweep"):
        session = SessionLocal()
        try:
            chain = evidence.verify_chain(session)
            actions: dict[str, int] = {}
            rows = session.scalars(
                select(AuditEvent).where(
                    AuditEvent.at >= datetime.combine(since, datetime.min.time(), timezone.utc),
                    AuditEvent.at <= datetime.combine(until, datetime.max.time(), timezone.utc),
                )
            )
            for row in rows:
                actions[row.action] = actions.get(row.action, 0) + 1
            determinations = session.scalar(
                select(Decision).where(Decision.as_of >= since, Decision.as_of <= until).limit(1)
            )
        finally:
            session.close()

    (out / "chain-verification.json").write_text(json.dumps(chain, indent=2, default=str))
    if not chain.get("verified"):
        problems["chain-verification.json"] = "the chain does not verify"

    (out / "audit-extract.json").write_text(
        json.dumps(
            {
                "window": {"from": since.isoformat(), "to": until.isoformat()},
                "actions": dict(sorted(actions.items())),
                "total": sum(actions.values()),
                "note": (
                    "Counts by action. The audit trail is append-only but is not "
                    "hash-chained, so this extract carries no arithmetic proof "
                    "that no row was removed. See docs/threat-model.md T3."
                ),
            },
            indent=2,
        )
    )
    if not actions:
        problems["audit-extract.json"] = "no audit events in the window"
    if determinations is None:
        problems["audit-extract.json"] = (
            problems.get("audit-extract.json", "") + " (and no determinations either)"
        ).strip()

    code, err = _run(["scripts.nightly_replay", "--json"], out=out / "replay.json")
    if code != 0:
        problems["replay.json"] = err

    code, err = _run(["scripts.restore_drill", "--json"], out=out / "restore-drill.json")
    if code != 0:
        problems["restore-drill.json"] = err

    return problems


def write_manifest(
    out: Path, *, tenant_id: str, since: date, until: date, signer: dict, problems: dict
) -> dict:
    files = []
    for name in sorted(CONTROLS):
        path = out / name
        files.append(
            {
                "file": name,
                "control": CONTROLS[name],
                "present": path.exists(),
                "bytes": path.stat().st_size if path.exists() else 0,
                "sha256": _hash(path) if path.exists() else None,
                "problem": problems.get(name, ""),
            }
        )

    manifest = {
        "tenant_id": tenant_id,
        "window": {"from": since.isoformat(), "to": until.isoformat()},
        "assembled_at": datetime.now(timezone.utc).isoformat(),
        "signed_off_by": signer,
        "statement": (
            "This folder is the evidence for the controls listed below, over the "
            "window stated. Each file is hashed as it was when the pack was "
            "assembled; `scripts/evidence_pack.py --verify` checks the hashes and "
            "reports anything present that the manifest does not list. The "
            "sign-off is an attestation by a named person who holds a role in "
            "this firm, recorded beside the hashes — not a cryptographic "
            "signature."
        ),
        "controls": files,
        "complete": all(f["present"] and not f["problem"] for f in files),
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2))
    return manifest


def verify(out: Path) -> int:
    manifest_path = out / "manifest.json"
    if not manifest_path.exists():
        print(f"{out} holds no manifest, so it is a folder rather than a pack.", file=sys.stderr)
        return 2

    manifest = json.loads(manifest_path.read_text())
    listed = {entry["file"] for entry in manifest["controls"]}
    problems = []

    for entry in manifest["controls"]:
        path = out / entry["file"]
        if not entry["present"]:
            problems.append(f"{entry['file']}: was missing when the pack was assembled")
            continue
        if not path.exists():
            problems.append(f"{entry['file']}: listed in the manifest and now absent")
            continue
        if _hash(path) != entry["sha256"]:
            problems.append(f"{entry['file']}: changed since the pack was assembled")

    for path in sorted(out.iterdir()):
        if path.name not in listed and path.name != "manifest.json":
            problems.append(f"{path.name}: present and not in the manifest")

    if problems:
        print(f"{out} does not verify:", file=sys.stderr)
        for problem in problems:
            print(f"  - {problem}", file=sys.stderr)
        return 2

    print(
        f"OK: {out} verifies — {len(listed)} control(s), every hash matches, "
        f"signed off by {manifest['signed_off_by']['email']} on "
        f"{manifest['assembled_at'][:10]}."
    )
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="The audit evidence folder.")
    parser.add_argument("--out", type=Path, default=None, help="where to write it")
    parser.add_argument("--from", dest="since", help="ISO date; defaults to 90 days back")
    parser.add_argument("--to", dest="until", help="ISO date; defaults to today")
    parser.add_argument("--signed-by", default="", help="the reviewer's email address")
    parser.add_argument("--verify", type=Path, default=None, help="check an existing pack")
    args = parser.parse_args()

    if args.verify is not None:
        return verify(args.verify)

    until = (
        date.fromisoformat(args.until)
        if args.until
        else business_time.platform_today()
    )
    since = date.fromisoformat(args.since) if args.since else until - timedelta(days=90)
    tenant_id = tenancy.configured_tenant()
    out = args.out or (_ROOT / "evidence" / f"{tenant_id}-{until.isoformat()}")

    if not args.signed_by:
        print(
            "--signed-by is required. The SOC 2 control is not that a report "
            "exists; it is that somebody read it and said so. A pack with no "
            "name against it evidences the generating and not the reviewing.",
            file=sys.stderr,
        )
        return 1

    try:
        signer = resolve_signer(args.signed_by, tenant_id)
    except LookupError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    problems = collect(out, tenant_id, since, until)
    manifest = write_manifest(
        out, tenant_id=tenant_id, since=since, until=until, signer=signer, problems=problems
    )

    print(f"evidence pack — {out}")
    for entry in manifest["controls"]:
        mark = "ok " if entry["present"] and not entry["problem"] else "MISSING"
        print(f"  [{mark}] {entry['file']}")
        print(f"          {entry['control']}")
        if entry["problem"]:
            print(f"          → {entry['problem'].splitlines()[-1][:160]}")
    held = ", ".join(signer["roles"])
    print(f"  signed off by {signer['display_name']} <{signer['email']}> ({held})")

    if not manifest["complete"]:
        print(
            "\nThe pack is incomplete. Every control above without a file is one "
            "an auditor will ask about, and the answer 'we ran it and did not "
            "keep it' is the same answer as 'we did not run it'.",
            file=sys.stderr,
        )
        return 2

    print("  complete")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
