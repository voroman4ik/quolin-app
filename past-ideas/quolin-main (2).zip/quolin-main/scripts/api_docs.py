"""
Write the published API contract: `docs/api/openapi.json` and a Postman collection.

Both are generated from the live application rather than maintained by hand, for
the reason every other generated artefact here is: a contract that has drifted
from the API is worse than none, because an engineer trusts it and then spends an
afternoon debugging the wrong thing.

    make api-docs           # write them
    make api-docs ARGS=--check   # fail if they are stale, which is what CI runs

The `--check` mode is the half that matters. Generating them is easy to remember
once and easy to forget forever; a check in the ladder means a change to the API
that does not regenerate the contract fails the build rather than shipping a
document that quietly describes last month's endpoints.

The collection is deliberately runnable rather than merely descriptive. S4's gate
is an external integrator onboarding a synthetic book **following only the
docs** — so the token request stores its own token into a collection variable
and every other request picks it up, which is the difference between a
collection somebody can run in an afternoon and a list of URLs.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

OUT = _ROOT / "docs" / "api"

#: A worked body per endpoint, using the seeded cast. An engineer should be able
#: to press Send rather than invent a client id first.
EXAMPLES = {
    "/v1/oauth/token": {
        "grant_type": "client_credentials",
        "client_id": "{{client_id}}",
        "client_secret": "{{client_secret}}",
    },
    "/v1/evaluations": {"client_id": "margaret-wu", "asset_id": "BTC"},
    "/v1/clients": {
        "id": "example-client",
        "name": "Example Person",
        "dob": "1985-04-02",
        "loss_capacity_band": 3,
        "assessable_portfolio_cents": 2500000,
    },
    "/v1/bulk": {
        "pairs": [
            {"client_id": "margaret-wu", "asset_id": "BTC"},
            {"client_id": "tom-askew", "asset_id": "SOL"},
        ]
    },
}


def build() -> tuple[dict, dict]:
    from app.main import app

    spec = app.openapi()
    items = []

    for path, operations in sorted(spec["paths"].items()):
        if not path.startswith("/v1"):
            continue
        for method, operation in sorted(operations.items()):
            verb = method.upper()
            if verb in {"HEAD", "OPTIONS"}:
                continue

            # The token call is the only one that carries no bearer, because it
            # is the one that produces it.
            is_token = path.endswith("/oauth/token")
            headers = [{"key": "Content-Type", "value": "application/json"}]
            if not is_token:
                headers.append(
                    {"key": "Authorization", "value": "Bearer {{access_token}}"}
                )
                if verb == "POST":
                    # Every write carries one, so the collection teaches the
                    # habit rather than describing it. `{{$guid}}` is Postman's
                    # own generator, so pressing Send twice sends two keys —
                    # which is what a caller retrying a *different* request does.
                    headers.append({"key": "Idempotency-Key", "value": "{{$guid}}"})

            request = {
                "method": verb,
                "header": headers,
                "url": {
                    "raw": "{{base_url}}" + path,
                    "host": ["{{base_url}}"],
                    "path": path.strip("/").split("/"),
                },
                "description": operation.get("summary", ""),
            }
            if verb == "POST":
                request["body"] = {
                    "mode": "raw",
                    "raw": json.dumps(EXAMPLES.get(path, {}), indent=2),
                }

            item = {"name": f"{verb} {path}", "request": request}
            if is_token:
                item["event"] = [
                    {
                        "listen": "test",
                        "script": {
                            "type": "text/javascript",
                            "exec": [
                                "// Stores the token so every other request in",
                                "// this collection picks it up automatically.",
                                "pm.collectionVariables.set('access_token',",
                                "    pm.response.json().access_token);",
                            ],
                        },
                    }
                ]
            items.append(item)

    collection = {
        "info": {
            "name": "Quolin API v1",
            "description": (
                "Generated from the live OpenAPI document. See docs/integrations.md "
                "for what each endpoint is for, and how the signing and idempotency "
                "contracts work.\n\n"
                "Set `base_url`, `client_id` and `client_secret`, run "
                "`POST /v1/oauth/token` first, and every other request will carry "
                "the token it stores."
            ),
            "schema": (
                "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
            ),
        },
        "variable": [
            {"key": "base_url", "value": "http://localhost:8000"},
            {"key": "client_id", "value": ""},
            {"key": "client_secret", "value": ""},
            {"key": "access_token", "value": ""},
        ],
        "item": items,
    }
    return spec, collection


def main() -> int:
    parser = argparse.ArgumentParser(description="Write or check the API contract.")
    parser.add_argument(
        "--check",
        action="store_true",
        help="Fail if the checked-in files are stale rather than rewriting them.",
    )
    args = parser.parse_args()

    spec, collection = build()
    files = {
        OUT / "openapi.json": json.dumps(spec, indent=2, sort_keys=True) + "\n",
        OUT / "quolin-v1.postman_collection.json": json.dumps(collection, indent=2) + "\n",
    }

    if args.check:
        stale = [
            path.name
            for path, content in files.items()
            if not path.exists() or path.read_text() != content
        ]
        if stale:
            print(
                "FAIL: the published API contract is stale: " + ", ".join(stale) + "\n"
                "Run `make api-docs`. A contract that has drifted from the API is "
                "worse than none — an engineer trusts it and debugs the wrong thing.",
                file=sys.stderr,
            )
            return 1
        print(f"OK: {', '.join(p.name for p in files)} match the application.")
        return 0

    OUT.mkdir(parents=True, exist_ok=True)
    for path, content in files.items():
        path.write_text(content)
    v1 = len([p for p in spec["paths"] if p.startswith("/v1")])
    print(f"wrote {len(files)} files — {v1} v1 paths, {len(collection['item'])} requests")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
