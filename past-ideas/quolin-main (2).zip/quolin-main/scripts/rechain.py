"""
Rebuild a tenant's evidence chain in place.

This script does the one thing the entire system is built to prevent: it edits
records in `decisions`, a table with a trigger and a revoked grant standing
against exactly that. So the first thing to say is when it is legitimate, and
the answer is narrow. A chain is a function of two things — the payload the
engine hashes, and where the chain starts. When either of those changes, every
stored hash is a hash of a rule that no longer applies, and the chain reports
itself broken. The records are intact; the arithmetic is out of date.

That is not tampering, and treating it as tampering would leave a database that
can never verify again. But the two look identical from inside Postgres, which
is why this is a separate script an operator runs deliberately rather than
something a migration does quietly on deploy.

**What it does not do, and cannot.** It recomputes hashes from the stored
fields. It never changes a field. An outcome that says BLOCK still says BLOCK
afterwards, and a decision someone had already altered stays altered — the
recomputation would simply make the altered value's hash consistent, which is
worth being blunt about: *running this over a tampered database launders the
tamper.* That is unavoidable in any re-chain tool and it is the reason for the
two guards below.

**The guards.**

* It is a dry run unless `--apply` is passed. The default output is what would
  change and by how much, which is the form in which the numbers are worth
  reading before anyone rewrites anything.
* It refuses to touch a chain that is already broken under the current rules
  unless `--force` is also passed. A chain that verifies is one where the only
  thing wrong is the rules; a chain that does not verify may have a real break
  in it, and quietly smoothing that over is the failure mode this tool has.
  `--force` exists because a database migrated across a payload change *will*
  fail verification legitimately, and it prints what it is overriding.

**Roles.** It connects as the schema owner. It has to: the application role has
UPDATE revoked on `decisions`, and the append-only trigger has to be suspended
for the duration, which only the table's owner can do. The trigger is restored
in a `finally`, and the whole rewrite for a tenant is one transaction, so an
interruption leaves the chain as it was rather than half-rebuilt.

**Tenants are named, not discovered.** There is no "every tenant" mode. Under
`FORCE ROW LEVEL SECURITY` a non-superuser owner — which is what production
runs as — can only see the tenant it has declared, so a discovery mode would
work in dev and silently do nothing in production. Naming them is honest in
both.

Usage:

    make rechain                       # dry run, the deployment's tenant
    make rechain ARGS=--apply
    uv run python -m scripts.rechain acme beta --apply

Exit codes: 0 when the chain is consistent at the end (or would be, on a dry
run), 1 when it is not or the script refused to start.
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path

# Same dual-layout dance as scripts/watch_tick.py: `api/` in the repo, flattened
# to the working directory inside the container.
_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from sqlalchemy import select, text  # noqa: E402

from app import evidence, tenancy  # noqa: E402
from app.canonical import chain_hash  # noqa: E402
from app.db import OwnerSessionLocal  # noqa: E402
from app.models import AuditEvent, ChainRechain, Decision  # noqa: E402
from app.service import audit  # noqa: E402

#: A provisioned machine principal, not a bare string.
#:
#: This was `"scripts.rechain"` — a name nothing had granted and nobody could be
#: asked about, which is the exact thing Stage 2 deleted the shared officer for.
#: `test_attribution.py` asserts every audit actor resolves to a row and had
#: never caught it, because no test had run this script's write path until
#: §S13's audit-chain backfill did.
ACTOR = "apc_rechain"


def _payload(d: Decision) -> dict:
    """The exact dict the engine hashes, by calling the engine's own function.

    Copying `evidence._hashable`'s field list here is what would make this tool
    wrong: the whole reason a re-chain is ever needed is that the list changed,
    and a tool that re-chains to a stale definition of the payload produces a
    chain that verifies against nothing.
    """
    return evidence._hashable(  # noqa: SLF001 — one calculation, one source
        tenant_id=d.tenant_id,
        client_id=d.client_id,
        asset_id=d.asset_id,
        as_of=d.as_of,
        pack_id=d.pack_id,
        pack_version=d.pack_version,
        snapshot=d.snapshot,
        rule_results=d.rule_results,
        resolution=d.resolution,
        outcome=d.outcome,
        created_at=d.created_at,
        # The schema *this row* was written under. A rechain that recomputed
        # every row under today's shape would rewrite the payload of history as
        # a side effect of fixing a chain, which is the one thing this tool must
        # not do — see Q-04 and `app/manifest.py`.
        schema=d.payload_schema,
        execution_manifest=d.manifest,
    )


def _record(
    session,
    *,
    tenant_id: str,
    table_name: str,
    by: str,
    reason: str,
    tip_before: str,
    tip_after: str,
    rows_changed: int,
) -> None:
    """Write the row and the two audit events that make a rechain an *event*.

    Both tips, because the point is reconciliation: an auditor holding an export
    from before this and one from after has every hash different, and
    `tip_before` is the only thing that lets them say "yes, this is where that
    chain ended, and here is why the numbers moved".

    The events go through `service.audit`, not `AuditEvent(...)`. This tool used
    to construct one directly and never call `link_audit`, so the row went in
    with an empty hash — and once an unlinked row after the chain tip became a
    verification failure, applying a rechain broke the audit chain it had just
    been asked to repair.

    The audit *actor* is `apc_rechain`, the provisioned principal this tool runs
    as, and not the `--by` string. `test_attribution.py` asserts that every
    actor in the trail resolves to a real user or machine row, and a person
    running this from a shell may hold no account in the tenant whose chain they
    are repairing. The human who authorised it is named in the subject and in
    `chain_rechains.by_operator`, which is where a reader looks for it.
    """
    session.add(
        ChainRechain(
            tenant_id=tenant_id,
            at=datetime.now(timezone.utc),
            table_name=table_name,
            by_operator=by,
            reason=reason,
            tip_before=tip_before,
            tip_after=tip_after,
            rows_changed=rows_changed,
        )
    )
    audit(
        session,
        "evidence.rechain.done",
        f"{table_name}: {rows_changed} row(s) rehashed by {by}. "
        f"tip {tip_before[:16]}… → {tip_after[:16]}…. Reason: {reason}",
    )


def _announce(session, *, table_name: str, by: str, reason: str, tip_before: str) -> None:
    """The event written *before* the rewrite, naming the tip it is about to leave.

    Two events rather than one, and this is the one that was missing. If the
    rewrite fails half-way — or is interrupted — the trail still says somebody
    started it, on what, and why. A record written only on success is a record
    that is absent exactly when something went wrong.
    """
    audit(
        session,
        "evidence.rechain.begin",
        f"{table_name}: about to rehash from tip {tip_before[:16]}… "
        f"by {by}. Reason: {reason}",
    )


def _rechain_tenant(
    tenant_id: str, *, apply: bool, force: bool, reason: str = "", by: str = ""
) -> bool:
    session = OwnerSessionLocal()
    try:
        anchor = evidence.ensure_anchor(session, tenant_id)
        session.commit()

        before = evidence.verify_chain(session)
        if not before["verified"] and not force:
            print(
                f"  {tenant_id}: chain does not verify (first break at decision "
                f"{before['broken_at_decision_id']}, {before['checked']} links good).\n"
                "    Refusing. A re-chain would make the break consistent rather than\n"
                "    repair it, and there is no way from in here to tell a payload\n"
                "    change from an edit. Establish which it is, then pass --force.",
                file=sys.stderr,
            )
            return False
        if not before["verified"] and force:
            print(
                f"  {tenant_id}: --force, overriding a chain that does not verify "
                f"(first break at decision {before['broken_at_decision_id']})."
            )

        decisions = list(
            session.scalars(
                select(Decision).where(Decision.tenant_id == tenant_id).order_by(Decision.id)
            )
        )

        prev = anchor.genesis_hash
        changes: list[tuple[int, str, str]] = []
        for decision in decisions:
            this = chain_hash(prev, _payload(decision))
            if decision.prev_hash != prev or decision.this_hash != this:
                changes.append((decision.id, prev, this))
            prev = this

        if not changes:
            print(
                f"  {tenant_id}: {len(decisions)} decisions, already chained to the "
                f"current rules. Nothing to do."
            )
            if apply:
                # Recorded even though nothing moved. Somebody ran the one
                # command that rewrites evidence; "did anyone rechain this
                # firm" is a question an auditor asks, and a record kept only
                # when the answer was yes-and-it-changed-something is a record
                # that cannot answer it.
                tip = decisions[-1].this_hash if decisions else ""
                with tenancy.acting_as_user(ACTOR):
                    _announce(
                        session,
                        table_name="decisions",
                        by=by,
                        reason=reason,
                        tip_before=tip,
                    )
                    _record(
                        session,
                        tenant_id=tenant_id,
                        table_name="decisions",
                        by=by,
                        reason=reason,
                        tip_before=tip,
                        tip_after=tip,
                        rows_changed=0,
                    )
                session.commit()
            return True

        print(
            f"  {tenant_id}: {len(changes)} of {len(decisions)} decisions would be "
            f"rehashed.\n"
            f"    genesis  {anchor.genesis_hash[:32]}…\n"
            f"    old tip  {(decisions[-1].this_hash)[:32]}…\n"
            f"    new tip  {prev[:32]}…"
        )
        if not apply:
            print("    Dry run. Pass --apply to write.")
            return True

        old_tip = decisions[-1].this_hash

        # Said before it happens, and committed, so an interrupted rewrite still
        # leaves the trail saying somebody started one.
        with tenancy.acting_as_user(ACTOR):
            _announce(
                session,
                table_name="decisions",
                by=by,
                reason=reason,
                tip_before=old_tip,
            )
            session.commit()

        # One transaction, and the trigger comes back in the `finally` whether
        # this commits or raises. A half-rebuilt chain is worse than no rebuild:
        # it verifies for a prefix and then breaks, which reads exactly like a
        # tamper at the point the rebuild stopped.
        session.execute(text("ALTER TABLE decisions DISABLE TRIGGER decisions_append_only"))
        try:
            for decision_id, prev_hash, this_hash in changes:
                session.execute(
                    text(
                        "UPDATE decisions SET prev_hash = :prev, this_hash = :this "
                        "WHERE id = :id AND tenant_id = :tenant"
                    ),
                    {
                        "prev": prev_hash,
                        "this": this_hash,
                        "id": decision_id,
                        "tenant": tenant_id,
                    },
                )
            # The rewrite is itself a fact about this tenant's evidence, so it
            # goes in the evidence. An auditor comparing an old export against a
            # new one will find every hash different, and these rows are the
            # answer to why — including `tip_before`, which is the half that
            # lets them reconcile the two exports rather than merely observe
            # that they differ.
            with tenancy.acting_as_user(ACTOR):
                _record(
                    session,
                    tenant_id=tenant_id,
                    table_name="decisions",
                    by=by,
                    reason=reason,
                    tip_before=old_tip,
                    tip_after=prev,
                    rows_changed=len(changes),
                )
            session.commit()
        finally:
            session.execute(text("ALTER TABLE decisions ENABLE TRIGGER decisions_append_only"))
            session.commit()

        # The rewrite went out as SQL, so the rows this session already has
        # loaded still carry the old hashes. Verifying without discarding them
        # would check the rebuild against the state it replaced and report a
        # failure that is not there — or, worse, the other way round.
        session.expire_all()
        after = evidence.verify_chain(session)
        if not after["verified"]:
            print(
                f"  {tenant_id}: FAILED — the chain still does not verify after "
                f"rebuilding (break at decision {after['broken_at_decision_id']}).",
                file=sys.stderr,
            )
            return False
        print(f"    rebuilt. {after['checked']} links verify, tip {after['tip_hash'][:32]}…")
        return True
    finally:
        session.close()



def _link_audit_tenant(
    tenant_id: str, *, apply: bool, reason: str = "", by: str = ""
) -> bool:
    """Link this tenant's unchained audit rows onto its audit chain.

    §S13 closed T3 by chaining `audit_events`. Rows written before that exist
    with an empty `prev_hash`, which is an absence rather than a break — the
    verifier counts them separately and says so. This is what turns them into
    links.

    **It rebuilds, it does not fill gaps.** The first version only wrote rows
    with an empty hash, on the reasoning that a linked row is evidence somebody
    may already have exported. That does not work and the database says so: an
    unlinked row that *precedes* a linked one has to take the genesis as its
    parent, which the linked row already holds, and the unique index refuses
    the second child. Retro-fitting a link before an existing one necessarily
    relinks everything after it.

    So this is a rebuild, in id order, from the genesis — and it carries the
    same warning the decision rebuild does: every hash after the first change
    is different afterwards, and an auditor comparing exports will see that.
    The `evidence.audit_rechain` row it writes is the answer to why.

    It still refuses to run over a chain that does not verify. Rebuilding
    around a break makes the break consistent rather than repairing it, and
    there is no way from in here to tell an edit from a payload change.
    """
    session = OwnerSessionLocal()
    try:
        evidence.ensure_anchor(session, tenant_id)
        session.commit()

        with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
            before = evidence.verify_audit_chain(session)
            if not before["verified"]:
                print(
                    f"  {tenant_id}: the audit chain does not verify (first break "
                    f"at event {before['broken_at_audit_id']}).\n"
                    "    Refusing to link. Filling gaps around a break would make "
                    "the break\n    permanent and harder to find.",
                    file=sys.stderr,
                )
                return False

            rows = list(
                session.scalars(
                    select(AuditEvent)
                    .where(AuditEvent.tenant_id == tenant_id)
                    .order_by(AuditEvent.id)
                )
            )

        if not rows:
            print(f"  {tenant_id}: no audit history.")
            return True
        if all(row.this_hash for row in rows):
            print(f"  {tenant_id}: every audit row is already linked.")
            if apply:
                tip = rows[-1].this_hash
                with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
                    _announce(
                        session,
                        table_name="audit_events",
                        by=by,
                        reason=reason,
                        tip_before=tip,
                    )
                    _record(
                        session,
                        tenant_id=tenant_id,
                        table_name="audit_events",
                        by=by,
                        reason=reason,
                        tip_before=tip,
                        # Two rows have just been appended by the calls above, so
                        # the tip has moved even though nothing was rewritten.
                        # Read after the fact rather than assumed.
                        tip_after="",
                        rows_changed=0,
                    )
                    session.commit()
                    after = evidence.verify_audit_chain(session)
                    print(f"    recorded. tip now {after['tip_hash'][:32]}…")
            return True

        # Rebuilt in id order from the genesis, which is the order the rows were
        # written in and the only order the chain can mean anything in.
        with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
            prev = evidence.audit_genesis(session)
        changes: list[tuple[int, str, str]] = []
        for row in rows:
            with tenancy.acting_as(tenant_id):
                this_hash = evidence.chain_hash(prev, evidence._audit_payload(row))
            if row.prev_hash != prev or row.this_hash != this_hash:
                changes.append((row.id, prev, this_hash))
            prev = this_hash

        already = len(rows) - len(changes)
        old_tip = next(
            (row.this_hash for row in reversed(rows) if row.this_hash), ""
        )
        print(
            f"  {tenant_id}: {len(rows)} audit row(s), {len(changes)} to write "
            f"({already} already correct); new tip {prev[:32]}…"
        )
        if not apply:
            print("    Dry run. Pass --apply to write.")
            return True

        with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
            _announce(
                session,
                table_name="audit_events",
                by=by,
                reason=reason,
                tip_before=old_tip,
            )
            session.commit()

        session.execute(
            text("ALTER TABLE audit_events DISABLE TRIGGER audit_events_append_only")
        )
        try:
            # Cleared first, then written.
            #
            # The unique index that stops two rows sharing a parent also stops a
            # rebuild writing row by row: the first row to be relinked takes the
            # genesis as its parent, and a row already holding the genesis has
            # not been moved off it yet. Postgres refuses, correctly, at the
            # statement rather than at the end.
            #
            # The index is partial — `WHERE prev_hash <> ''` — precisely so this
            # intermediate state is representable. Both passes are in one
            # transaction, so no reader ever sees the cleared state.
            for event_id, _prev, _this in changes:
                session.execute(
                    text(
                        "UPDATE audit_events SET prev_hash = '', this_hash = '' "
                        "WHERE id = :id AND tenant_id = :tenant"
                    ),
                    {"id": event_id, "tenant": tenant_id},
                )
            for event_id, prev_hash, this_hash in changes:
                session.execute(
                    text(
                        "UPDATE audit_events SET prev_hash = :prev, this_hash = :this "
                        "WHERE id = :id AND tenant_id = :tenant"
                    ),
                    {
                        "prev": prev_hash,
                        "this": this_hash,
                        "id": event_id,
                        "tenant": tenant_id,
                    },
                )
            # The rewrite is itself a fact about this tenant's evidence, so it
            # goes in the evidence — the same reason the decision rebuild writes
            # one.
            #
            # **Chained, not written unlinked.** This used to add the row with
            # an empty hash on the reasoning that the next run would pick it up.
            # Once an unlinked row after the chain tip became a verification
            # failure (Q-13), that meant the relink broke the chain it had just
            # repaired — and the check five lines below would have said so.
            # `audit()` links it onto the tip the rebuild has just written,
            # which is visible inside this transaction.
            with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
                _record(
                    session,
                    tenant_id=tenant_id,
                    table_name="audit_events",
                    by=by,
                    reason=reason,
                    tip_before=old_tip,
                    tip_after=prev,
                    rows_changed=len(changes),
                )
            session.commit()
        finally:
            session.execute(
                text("ALTER TABLE audit_events ENABLE TRIGGER audit_events_append_only")
            )
            session.commit()

        session.expire_all()
        with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
            after = evidence.verify_audit_chain(session)
        if not after["verified"]:
            print(f"  {tenant_id}: the audit chain still does not verify.", file=sys.stderr)
            return False
        print(
            f"    linked. {after['checked']} row(s) verify, "
            f"{after['unlinked']} still unlinked."
        )
        return True
    finally:
        session.close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Rebuild evidence chains per tenant.")
    parser.add_argument(
        "tenants",
        nargs="*",
        help="Tenant ids. Defaults to the tenant this deployment serves (QUOLIN_TENANT).",
    )
    parser.add_argument("--apply", action="store_true", help="Write. Otherwise a dry run.")
    parser.add_argument(
        "--table",
        choices=("decisions", "audit_events"),
        default="decisions",
        help=(
            "which chain. `decisions` rebuilds hashes; `audit_events` only "
            "fills gaps left by rows written before §S13 chained the trail."
        ),
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Rebuild even a chain that does not currently verify. Read the module note first.",
    )
    parser.add_argument(
        "--reason",
        default="",
        help=(
            "Why this rewrite is happening, in a sentence. Required with "
            "--apply: a rewrite of a firm's evidence with no stated reason is "
            "indistinguishable from the thing it looks like."
        ),
    )
    parser.add_argument(
        "--by",
        default="",
        help=(
            "The person asking for it. Required with --apply — 'the system did "
            "it' is not an answer to 'who rewrote this'."
        ),
    )
    args = parser.parse_args(argv)

    # Checked before anything is read, so a missing reason costs nothing and a
    # rewrite cannot get half-way through before somebody is asked for one.
    # Deliberately not required for a dry run: reading is not rewriting, and the
    # tool is mostly run to find out *whether* a rechain is needed at all.
    if args.apply:
        missing = []
        if not args.reason.strip():
            missing.append("--reason")
        if not args.by.strip():
            missing.append("--by")
        if missing:
            print(
                f"\nrefusing to apply: {' and '.join(missing)} required.\n"
                "  This is the one tool here that rewrites evidence, and the only\n"
                "  thing separating it from a tamper is that somebody meant it and\n"
                "  said so. Both are recorded in `chain_rechains`, which is\n"
                "  append-only, and in two audit events naming the tips either side.\n"
                "\n"
                '  make rechain ARGS="--apply --reason \'migrated across 0004\' '
                "--by you@example.com\"",
                file=sys.stderr,
            )
            return 2

    tenants = args.tenants or [tenancy.configured_tenant()]
    print(f"\nre-chain {'(apply)' if args.apply else '(dry run)'}: {', '.join(tenants)}")

    ok = True
    for tenant_id in tenants:
        # Each tenant in its own scope, because the row-level security setting
        # and the column defaults both read it — a rebuild that ran with the
        # wrong tenant in scope would write the wrong tenant into the audit row.
        with tenancy.acting_as(tenant_id):
            if args.table == "audit_events":
                ok = _link_audit_tenant(
                    tenant_id, apply=args.apply, reason=args.reason, by=args.by
                ) and ok
            else:
                ok = _rechain_tenant(
                    tenant_id,
                    apply=args.apply,
                    force=args.force,
                    reason=args.reason,
                    by=args.by,
                ) and ok

    print()
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
