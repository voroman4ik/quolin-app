#!/usr/bin/env bash
# §S11: "No code fork, no feature divergence - an infrastructure instantiation,
# not a product variant."
#
# That sentence is a promise about what `dedicated` means, and it is the kind of
# promise that decays by one reasonable-looking exception at a time. The first
# `count = var.tenancy == "dedicated" ? 1 : 0` will arrive with a good argument
# attached, and after it the shared stack and the dedicated stack are two
# products that happen to share a repository — which is exactly the thing a
# customer is told is not happening.
#
# So: `var.tenancy` may appear in tags and descriptions. It may not decide
# whether a resource exists, how many of something there are, or which branch of
# a conditional runs.
#
# The application half is the same rule from the other side: no application code
# reads the tenancy mode at all. The RLS probe takes it as an argument, because
# a probe checking "is this stack what it claims to be" has to be told what it
# claims — but nothing that serves a request may know or care.

set -euo pipefail

# §S13: fail rather than pass when there is nothing to examine, and work the
# same outside a git checkout. See scripts/guard_lib.sh.
# shellcheck source=scripts/guard_lib.sh
. "$(dirname "$0")/guard_lib.sh"

cd "$(dirname "$0")/.."

# The pre-checks below glob `infra/*.tf` and `find api/app -name '*.py'`. Both
# are globs that can match nothing, and both feed pipelines whose failure is
# swallowed — `sed` on an unmatched glob errors, `grep` then reads empty input,
# `|| true` turns that into "no offenders", and the guard prints a pass. So the
# count is asserted rather than the directory's mere existence: `require_paths`
# was true of an `infra/` holding only a README.
require_scan "tier divergence in the deployment" "tf" infra
require_scan "tier divergence in the application" "py" api/app

fail=0

# --- the infrastructure half -------------------------------------------------
#
# Comments are stripped first: this file's own explanation of the rule, and the
# notes in the Terraform that explain the same thing, must not trip it.
offenders=$(
  sed 's/#.*//' infra/*.tf \
    | grep -nE '(count|for_each)[[:space:]]*=.*var\.tenancy' || true
)
if [ -n "$offenders" ]; then
  echo "FAIL: a resource's existence depends on var.tenancy:"
  echo "$offenders"
  echo
  echo "Stage 11 promises dedicated is an instantiation of the same Terraform,"
  echo "not a variant of it. A resource that only exists in one tier is a fork."
  fail=1
fi

conditionals=$(
  sed 's/#.*//' infra/*.tf \
    | grep -nE 'var\.tenancy[[:space:]]*[=!]=' \
    | grep -viE 'tags|description' || true
)
if [ -n "$conditionals" ]; then
  echo "FAIL: infrastructure branches on var.tenancy:"
  echo "$conditionals"
  fail=1
fi

# --- the application half ----------------------------------------------------
#
# `Tenant.tier` is a label on the row — it records what a customer bought, and
# the answer to "where is our data" must not depend on which process is
# answering. Nothing may *branch* on it. Comments and docstrings are stripped
# first, because the model's own note explaining the column is not a branch.
app=$(
  find api/app -name '*.py' -print0 \
    | xargs -0 grep -nE 'QUOLIN_TENANCY|tenancy_mode|[=!]=[[:space:]]*"dedicated"|"dedicated"[[:space:]]*[=!]=' \
    | sed 's/:[[:space:]]*#.*$//' \
    | grep -E 'QUOLIN_TENANCY|tenancy_mode|"dedicated"' || true
)
if [ -n "$app" ]; then
  echo "FAIL: application code knows which tier it is running in:"
  echo "$app"
  echo
  echo "The application is identical in both tiers — that is the whole claim."
  echo "Isolation is row-level security, which is on in both. If a dedicated"
  echo "stack needs different behaviour, it is a different product and the"
  echo "sales page should say so."
  fail=1
fi

if [ "$fail" -ne 0 ]; then
  exit 1
fi

# The enforcement. Everything above is a pre-check.
#
# FP3-02 note, after audit G-06: the two greps above missed `tier != "shared"`
# (the complement), `tier in ("dedicated",)` (membership rather than equality),
# a Terraform `local` derived from `var.tenancy` via `contains()`, and anything
# under `infra/envs/` or `infra/modules/` — the infra half globbed `infra/*.tf`
# and stopped there. All four reproduced.
#
# `scripts/tier_divergence.py` follows the reference instead of matching a
# spelling: it taints every local that depends on `var.tenancy`, transitively,
# and refuses any `count` or `for_each` that reaches one.
_HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$_HERE/../api" || exit 1
exec uv run python "$_HERE/tier_divergence.py" "$@"
