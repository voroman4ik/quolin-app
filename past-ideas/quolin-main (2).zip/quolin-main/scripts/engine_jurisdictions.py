"""No jurisdiction is named in the engine — asked of the parse tree, not of a grep.

Invariant: the pack format is the product thesis. The same evaluator runs four
regimes, and the day it learns that `hk` means something is the day the fifth
regime becomes an engineering project instead of a content one.

`guard_no_jurisdiction_logic.sh` was a set of regexes for the four uppercase
codes. Audit G-05 listed six ways past it; reproduced individually on this tree,
**three of the six pass**:

    if pack_id.startswith("hk"):        -> passed   (lowercase)
    if pack_id in ("au", "sg"):         -> passed   (lowercase)
    x = 'A' + 'U'                       -> passed   (concatenated)
    if jurisdiction.lower() == "eu":    -> caught
    if jurisdiction in {"DE", "FR"}:    -> caught
    x = 'AU'                            -> caught

Worth recording precisely rather than repeating the audit's "all six": half of
that guard worked. What did not work is the half that assumed a regime code
would be written the way the pack files write it.

**So this parses instead.** Every string constant in `api/app/engine/**` that
looks like a country or regime code — two ASCII letters, in any case — is a
fault unless allow-listed. That catches lowercase, mixed case, and any code for
a regime nobody has shipped yet, which the old list could not have contained.

And separately: **every jurisdiction code in `packs/` is looked for in the
engine's AST in any casing**. That check needs no list at all — it derives what
to forbid from the content that ships, so a fifth pack extends the guard by
existing.

The concatenation case (`'A' + 'U'`) is caught because `ast` folds it: the two
halves are `Constant` nodes of one letter each, and the *joined* value is what
`ast.literal_eval` on the `BinOp` produces. Anything more elaborate than that —
`chr(65) + chr(85)` — is not caught and is not worth catching: at that point the
code is disguising itself, and a guard is not a defence against a colleague who
is actively hiding something. It is a defence against the ordinary case, which
is somebody solving a problem quickly.
"""

from __future__ import annotations

import argparse
import ast
import json
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
ENGINE = REPO / "api" / "app" / "engine"
PACKS = REPO / "packs"

#: Two ASCII letters. Deliberately case-insensitive, which is the half the
#: regex guard was missing.
CODE_SHAPED = re.compile(r"^[A-Za-z]{2}$")

#: Two-letter strings the engine legitimately contains.
#:
#: Each is a word or an identifier that happens to be two letters long, not a
#: place. Kept short: every entry is a string the guard will not look at again,
#: and a long list here is the check being turned off one convenience at a time.
ALLOWED = frozenset(
    {
        "id",
        "in",
        "is",
        "if",
        "or",
        "no",
        "on",
        "to",
        "at",
        "by",
        "of",
        "gt",
        "lt",
        "ge",
        "le",
        "eq",
        "ne",
        # A DSL key: `{"op": "and", ...}`. Not a place.
        "op",
    }
)


def _string_constants(tree: ast.AST) -> list[tuple[int, str]]:
    """Every string literal in the tree, including folded concatenations."""
    found: list[tuple[int, str]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            found.append((node.lineno, node.value))
        elif isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            # `'A' + 'U'`, folded by hand.
            #
            # `ast.literal_eval` is the obvious tool and does not work here: it
            # supports `+` only for numbers, so it raises `ValueError` on two
            # string constants and the case sails through. Found by writing the
            # mutation test, which is the argument for mutation tests.
            value = _fold_strings(node)
            if value is not None:
                found.append((node.lineno, value))
    return found


def _fold_strings(node: ast.AST) -> str | None:
    """The string a tree of literal `+` makes, or None if it is not all literals."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = _fold_strings(node.left)
        right = _fold_strings(node.right)
        if left is not None and right is not None:
            return left + right
    return None


def pack_jurisdictions() -> set[str]:
    """Every regime code the shipped content declares, lowercased.

    Derived rather than listed, so a fifth pack extends this guard by existing —
    which is the failure `test_packs.py` had a separate test for, and no longer
    needs.
    """
    codes: set[str] = set()
    for path in sorted(PACKS.glob("*.json")):
        try:
            body = json.loads(path.read_text())
        except json.JSONDecodeError:  # pragma: no cover - malformed content
            continue
        for key in ("jurisdiction", "id", "pack_id"):
            value = body.get(key)
            if isinstance(value, str) and value:
                codes.add(value.strip().lower())
        # The file stem is how a corpus case names a pack: `au_v1`.
        codes.add(path.stem.split("_")[0].lower())
    return {code for code in codes if CODE_SHAPED.match(code)}


def check(engine_dir: Path) -> list[str]:
    files = sorted(engine_dir.rglob("*.py"))
    if not files:
        raise FileNotFoundError(f"no Python files under {engine_dir}")

    shipped = pack_jurisdictions()
    problems: list[str] = []

    for path in files:
        try:
            tree = ast.parse(path.read_text())
        except SyntaxError as exc:  # pragma: no cover - a broken checkout
            problems.append(f"{path}: could not be parsed: {exc}")
            continue

        try:
            where = path.relative_to(REPO)
        except ValueError:
            # `--engine-dir` pointed outside the repository, which the mutation
            # tests do. The path is the message either way.
            where = path
        for line, value in _string_constants(tree):
            lowered = value.strip().lower()
            if lowered in ALLOWED:
                continue
            if CODE_SHAPED.match(value.strip()):
                problems.append(
                    f"{where}:{line}: the engine contains the constant {value!r}, "
                    "which is the shape of a jurisdiction code. The pack format "
                    "is the product thesis: the evaluator does not know what a "
                    "regime is called."
                )
            elif lowered in shipped:
                problems.append(
                    f"{where}:{line}: the engine contains {value!r}, which is a "
                    "regime declared by a pack in packs/."
                )

    return problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--engine-dir", default=str(ENGINE))
    args = parser.parse_args(argv)

    engine_dir = Path(args.engine_dir)
    if not engine_dir.is_dir():
        print(f"FAIL: no engine directory at {engine_dir}.")
        print()
        print("A scan of nothing is not a clean scan.")
        return 1

    try:
        problems = check(engine_dir)
    except FileNotFoundError as exc:
        print(f"FAIL: {exc}")
        return 1

    if problems:
        for problem in problems:
            print(f"FAIL: {problem}")
        return 1

    shipped = sorted(pack_jurisdictions())
    print(
        f"OK: no jurisdiction-shaped constant in {engine_dir}; "
        f"none of the {len(shipped)} regimes in packs/ ({', '.join(shipped).upper()}) "
        "is named in its parse tree, in any casing."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
