"""What each ECS task is actually given, read from the task definitions.

FP3-03 and FP3-04 both turn on the same question — *which credentials does this
process hold in production* — and both were answered wrongly by code that never
asked. The 27 August sweep added a call to the watch task that needs two
connection strings it does not have; the guard that would have caught it was a
grep for one resource name; and the test that was supposed to prove the sweep
runs in its deployed environment ran it with `{**os.environ, ...}`, which on a
developer's machine and in CI contains every connection string in the system.

So the answer lives in one place and both CI and the suite read it here.

**Parsed from `infra/compute.tf`, not maintained beside it.** A hand-kept list
of what the watch task holds is a second thing to update, and the failure mode
of forgetting is a test that passes about a deployment that no longer exists.
This is a small parser rather than `terraform show -json` on purpose: it must
run in a unit test on a laptop with no AWS credentials, no state file and no
provider plugins.

It reads the `name`, `command`, `environment` and `secrets` of every
`aws_ecs_task_definition` in the directory. It does not evaluate Terraform — the
*values* are interpolations and mostly unknowable without a plan — so it reports
the environment variable **names** each task is given, which is exactly the
question both callers ask.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
DEFAULT_INFRA = REPO / "infra"


@dataclass(frozen=True)
class Task:
    """One container definition, as the deployment declares it."""

    #: The Terraform resource name (`aws_ecs_task_definition.<this>`).
    resource: str
    #: The container's own `name` field.
    container: str
    #: What it runs, as a list of argv words. Empty means the image's own CMD.
    command: tuple[str, ...] = ()
    #: Plain environment variable names.
    environment: frozenset[str] = field(default_factory=frozenset)
    #: Names of values injected from Secrets Manager.
    secrets: frozenset[str] = field(default_factory=frozenset)

    @property
    def names(self) -> frozenset[str]:
        """Every variable name this container is given, from either source."""
        return self.environment | self.secrets


def _block(text: str, start: int) -> str:
    """The braced block beginning at or after `start`, balanced."""
    open_at = text.index("{", start)
    depth = 0
    for i in range(open_at, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[open_at : i + 1]
    raise ValueError("unbalanced braces in the task definition")


def _names(block: str, key: str) -> frozenset[str]:
    """The `name = "X"` entries inside `key = [...]`, if that list is present."""
    match = re.search(rf"\b{key}\s*=\s*\[", block)
    if match is None:
        return frozenset()

    # Balanced over brackets, because `secrets` entries contain `${...}`.
    start = match.end() - 1
    depth = 0
    for i in range(start, len(block)):
        if block[i] == "[":
            depth += 1
        elif block[i] == "]":
            depth -= 1
            if depth == 0:
                body = block[start : i + 1]
                break
    else:  # pragma: no cover - malformed terraform
        return frozenset()

    return frozenset(re.findall(r'\bname\s*=\s*"([^"]+)"', body))


def task_definitions(infra_dir: Path | str = DEFAULT_INFRA) -> dict[str, Task]:
    """Every `aws_ecs_task_definition` in the directory, keyed by resource name.

    Raises `FileNotFoundError` when the directory is absent and `ValueError`
    when it holds none — both of which are failures rather than empty results,
    for the reason F12 gave the migration linter: a check that examined nothing
    must not report a pass it did not earn.
    """
    infra = Path(infra_dir)
    if not infra.is_dir():
        raise FileNotFoundError(f"no infrastructure directory at {infra}")

    found: dict[str, Task] = {}
    for path in sorted(infra.rglob("*.tf")):
        text = path.read_text()
        for match in re.finditer(
            r'resource\s+"aws_ecs_task_definition"\s+"([A-Za-z0-9_-]+)"', text
        ):
            resource = match.group(1)
            block = _block(text, match.end())

            container = ""
            name_match = re.search(r'\bname\s*=\s*"([^"]+)"', block)
            if name_match:
                container = name_match.group(1)

            # The container's own `command`, not the health check's. A
            # `healthCheck` block carries a `command` too, and reading that one
            # made the API task report its liveness probe as its entrypoint —
            # which matters because FP3-04's allow-list is keyed on what a task
            # runs.
            outer = re.sub(r"healthCheck\s*=\s*\{[^}]*\}", "", block, flags=re.S)
            command: tuple[str, ...] = ()
            command_match = re.search(r"\bcommand\s*=\s*\[([^\]]*)\]", outer)
            if command_match:
                command = tuple(re.findall(r'"([^"]*)"', command_match.group(1)))

            found[resource] = Task(
                resource=resource,
                container=container,
                command=command,
                environment=_names(block, "environment"),
                secrets=_names(block, "secrets"),
            )

    if not found:
        raise ValueError(f"{infra} holds no aws_ecs_task_definition resources")
    return found


def environment_for(resource: str, infra_dir: Path | str = DEFAULT_INFRA) -> dict[str, str]:
    """A plausible process environment for one task, and *only* its variables.

    Values are placeholders except where the caller overrides them: the point of
    this is the **set of names**, because the defect it exists to catch is a
    process reaching for a variable the deployment never gives it.

    Used by the watch sweep's subprocess test, which previously ran with
    `{**os.environ, ...}` — inheriting `DATABASE_URL` and `APP_DATABASE_URL`
    from the developer's shell and so proving the sweep works in an environment
    production does not provide.
    """
    tasks = task_definitions(infra_dir)
    if resource not in tasks:
        raise KeyError(
            f"no aws_ecs_task_definition named {resource!r} in {infra_dir}; "
            f"found {sorted(tasks)}"
        )
    return {name: "" for name in sorted(tasks[resource].names)}
