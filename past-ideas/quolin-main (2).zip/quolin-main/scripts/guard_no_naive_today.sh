#!/usr/bin/env bash
# A business date is the firm's, and a timestamp is UTC. FP3-05.
#
# Two rules, one guard, because they are the same mistake with two spellings.
#
#   * `date.today()` is the *process's* local calendar date. On ECS that is UTC,
#     and for a Sydney firm it is the previous day for ten hours of every working
#     morning. Reproduced: at 09:30 Sydney a local operator asking for a
#     determination `as_of` today was refused `as_of_in_the_future`, the console
#     default recorded yesterday, and a pack effective today did not begin
#     governing that firm until 10:00 local. `app/business_time.py` answers this
#     properly, and every caller goes through it.
#
#   * `datetime.now()` with no timezone is a naive datetime. Q-03 fixed the ones
#     that existed; nothing stopped the next one. Every timestamp in this
#     codebase is `datetime.now(timezone.utc)`.
#
# A rule that twenty-nine call sites have to remember is not a rule. This is
# what makes it one.
#
# Mutation cases in `api/tests/test_guard_mutations.py`: each spelling injected
# into a copy of the tree, a missing target directory, and SCAN_DIRS pointing at
# nothing. Every one of them must exit non-zero.
set -uo pipefail

# §S13: fail rather than pass when there is nothing to examine. This guard had
# its own correct copy of that check, which is the Gate A audit's third finding
# — three copies of one rule is three places to leave one out, and the place it
# was left out was `guard_no_hardcoded_region.sh`'s second path parameter.
# shellcheck source=scripts/guard_lib.sh
. "$(dirname "${BASH_SOURCE[0]}")/guard_lib.sh"

_HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
_ROOT="$(cd "$_HERE/.." && pwd)"
SCAN_DIRS="${SCAN_DIRS:-$_ROOT/api/app $_ROOT/scripts}"

fail=0

# Unquoted on purpose: SCAN_DIRS is a space-separated list of paths, and the
# greps below split it the same way.
# shellcheck disable=SC2086
require_scan "business dates taken from the container clock" "py" $SCAN_DIRS
scanned="$SCANNED_FILES"

# The one file allowed to ask the operating system what day it is, and the one
# place the answer is turned into a firm's business date.
ALLOWED='api/app/business_time.py'

# `date.today()` anywhere else.
hits=$(grep -rnE '\bdate\.today\(\)' --include='*.py' $SCAN_DIRS 2>/dev/null \
  | grep -v "$ALLOWED" \
  | grep -vE ':[0-9]+: *#' \
  | grep -vE '^\s*[^:]+:[0-9]+:\s*(#|\*|`)' \
  | grep -vE ':[0-9]+:.*(FP3-05|`date\.today\(\)`)' || true)

if [ -n "$hits" ]; then
  echo "$hits"
  echo
  echo "FAIL: a business date is being taken from the container's clock."
  echo "Use business_time.business_today(session) for a firm's date, or"
  echo "business_time.platform_today() for work that is nobody's in particular."
  fail=1
fi

# A business date spelled as a timestamp. `datetime.now(timezone.utc).date()`
# is `date.today()` with more steps, and the first version of this guard did not
# see it — `watch/sources.py` and `adoption.py` both had one, and the suite
# running under `TZ=Australia/Sydney` is what found them rather than the guard.
derived=$(grep -rnE '\.now\([^)]*\)\.date\(\)|utcnow\(\)\.date\(\)' \
  --include='*.py' $SCAN_DIRS 2>/dev/null \
  | grep -v "$ALLOWED" \
  | grep -vE ':[0-9]+: *#' || true)

if [ -n "$derived" ]; then
  echo "$derived"
  echo
  echo "FAIL: a business date taken from a timestamp. .date() on a UTC instant"
  echo "is the container's calendar day with extra steps — use"
  echo "business_time.business_today(session, now=...) instead."
  fail=1
fi

# A naive `datetime.now()` — no argument at all.
# The last filter drops lines whose content begins with a quote — a string
# continuation. `scripts/engine_purity.py` contains the sentence "the engine
# called datetime.now()" inside the message it raises when the engine does, and
# a guard that cannot tell a call from a description of a call makes the file
# explaining the rule fail the rule.
naive=$(grep -rnE '\bdatetime\.now\(\s*\)' --include='*.py' $SCAN_DIRS 2>/dev/null \
  | grep -v "$ALLOWED" \
  | grep -vE ':[0-9]+: *#' \
  | grep -vE ":[0-9]+: *[\"']" || true)

if [ -n "$naive" ]; then
  echo "$naive"
  echo
  echo "FAIL: a naive datetime.now(). Every timestamp here is"
  echo "datetime.now(timezone.utc) — see Q-03."
  fail=1
fi

if [ "$fail" -ne 0 ]; then
  exit 1
fi

echo "OK: $scanned Python files; every business date goes through"
echo "    business_time, and every timestamp carries a timezone."
