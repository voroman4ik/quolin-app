#!/usr/bin/env bash
# Stage 2: the shared passcode is deleted, not disabled.
#
# The distinction is the whole point of this guard. A passcode behind a feature
# flag, an unset environment variable, or a branch nobody takes is still a
# second way in — it survives review because it looks inert, and it comes back
# the first time somebody needs a quick demo login. The gate for this stage is
# therefore not "the passcode is off". It is that the code path does not exist,
# and that a grep is what proves it.
#
# Scope is running code and deployment configuration: the API, the suite, the
# web client, Terraform, Fly, the Makefile and CI. Prose is deliberately out of
# scope. `docs/spec-changes.md` is an append-only record of what the product
# used to be and must keep saying "one shared passcode" about the phases where
# that was true; a guard that forced history to be rewritten would be asking
# the repository to lie.
set -uo pipefail

# §S13: fail rather than pass when there is nothing to examine, and work the
# same outside a git checkout. See scripts/guard_lib.sh.
# shellcheck source=scripts/guard_lib.sh
. "$(dirname "$0")/guard_lib.sh"

require_paths api/app web


# Identifiers, not the English word. "passcode" appearing in a comment that
# explains what was removed is the guard working as intended; `QUOLIN_PASSCODE`
# appearing anywhere is a live path.
PATTERN='QUOLIN_PASSCODE|configured_passcode|check_passcode|AuthNotConfigured|"passcode"|'"'"'passcode'"'"'|\bpasscode\s*[:=]'

# The whole repository, minus documentation. FP3-02, audit G-07.
#
# This used to be a hand-written list of eleven directories, and the two it did
# not name are the two that mattered: `web/public`, which holds the service
# worker, and `web/e2e`. A guard scoped by a list somebody typed protects
# exactly the places that person thought of, and the shared passcode's whole
# history is that it survived in the places nobody was looking.
#
# `test_guard_mutations.py` is excluded for the same reason this file excludes
# itself: it *writes* `QUOLIN_PASSCODE` into a temp tree in order to prove this
# guard refuses it. Widening the scan to the whole repository made the guard
# fail on the test that proves the guard works.
#
# `docs/` stays out, deliberately and as before: writing down what was removed
# and why is the change log doing its job, and a guard that refuses to let the
# history be described is one people route around.
SCAN_ROOT="${SCAN_ROOT:-.}"

# Existence and a non-zero file count, through `guard_lib.sh` rather than
# through the two blocks that used to be here. The Gate A audit's third finding
# is that three guards each had their own correct copy of this — which is how
# `guard_no_hardcoded_region.sh` came to have one for its first path parameter
# and none for its second. One implementation, called by everything that scans.
require_scan "a shared-passcode code path" "py ts tsx js tf yml" "$SCAN_ROOT"
scanned="$SCANNED_FILES"

present=("$SCAN_ROOT")

# The ignore list comes from guard_lib.sh rather than being spelled here. This
# line used to name `node_modules`, `__pycache__` and `.next` and not `.venv`,
# which is Q-10's second half: two lists of the same thing drift, and the one
# that drifts is the one that lets something through.
# shellcheck disable=SC2046 — the excludes must word-split into separate args.
hits=$(grep -rInE "$PATTERN" "${present[@]}" \
         $(grep_excludes) \
         --exclude-dir=docs \
         --exclude-dir=evidence \
         --exclude-dir=artefacts_out \
         --exclude='*.md' \
         --exclude="$(basename "$0")" \
         --exclude=test_guard_mutations.py \
       || true)

if [ -n "$hits" ]; then
  echo "$hits"
  echo
  echo "FAIL: a shared-passcode code path is still present."
  echo
  echo "Stage 2 replaced it with per-user accounts: app/identity.py decides who"
  echo "somebody is, app/auth.py mints the session, and every action in the audit"
  echo "trail names a person. A passcode alongside that is not a fallback, it is"
  echo "an unattributed way in — and the audit trail cannot say who used it."
  echo
  echo "Delete the path rather than disabling it. If you are documenting the"
  echo "history, docs/ is out of scope for this guard on purpose."
  exit 1
fi

echo "OK: no shared-passcode code path in $scanned source files across the"
echo "    whole tree — sign-in is per-user throughout."
