#!/usr/bin/env python3
"""Assert what a migration does to the database, not what its source says.

The linter this replaces was a regex over SQL spellings, and every real
migration in this repository is alembic Python. FP3-01 established by execution
that all of the following passed it with exit 0:

    op.drop_column("decisions", "prev_hash")
    op.execute("GRANT ALL ON decisions TO quolin_app;")
    op.execute("GRANT UPDATE,\\n DELETE ON decisions TO quolin_app;")
    op.execute("CREATE OR REPLACE FUNCTION quolin_append_only() ... RETURN NEW")
    op.add_column("decisions", sa.Column("amt", sa.Double()))
    op.execute("ALTER ROLE quolin_app BYPASSRLS;")
    op.execute("GRANT UPDATE, DELETE ON chain_anchors TO quolin_app;")

Three separate reasons, and they are the reason this is not another regex. The
grep wanted the SQL spelling `drop column` and alembic writes `drop_column`. It
wanted `update` and `delete` on one line and SQL does not care about lines. And
its table list was five names hand-typed in 2026 against an append-only set that
has since grown to thirteen — a list that has to be maintained in step with the
schema by somebody remembering to, which is the class of control this repository
exists to argue against.

So this asserts the deployed fact. It builds a scratch database, walks the
migration chain one revision at a time, and after every step reads the catalog
back and compares it to the step before:

  * `information_schema.role_table_grants` — a new UPDATE, DELETE or TRUNCATE
    grant to a non-owner role on an append-only table.
  * `pg_trigger` — an append-only trigger removed or disabled.
  * `pg_proc` — the body of a trigger function changed. `CREATE OR REPLACE
    FUNCTION quolin_append_only() ... RETURN NEW` leaves every trigger object in
    place and every one of them now permits the write, which is the most
    valuable single line an attacker could land in a migration and the one the
    old linter was least able to see.
  * `information_schema.columns` — a float, double or money column on a
    protected table, or a dropped `prev_hash` / `this_hash` / `chain_*`.
  * `pg_policy` and `pg_class.relforcerowsecurity` — a policy dropped, or FORCE
    row-level security turned off, on a tenant-scoped table.
  * `pg_roles.rolbypassrls` — still false for all three worker roles. A role
    with BYPASSRLS turns every policy in the database into a comment.

Then it runs each downgrade and diffs it the same way, because the repository's
own migration 0026 downgraded by dropping both chain columns and the old linter
called the tree clean.

The protected table list is read from `models.APPEND_ONLY_TABLES` at runtime,
and is unioned with every table actually carrying an append-only trigger, so a
table protected in the database but missing from the model constant is still
covered. Nothing here is hand-maintained.

Usage:

    scripts/lint_migrations.sh            # the shell entry point CI runs
    python scripts/migration_lint.py      # same thing, directly

`MIGRATIONS_DIR` points it at a different tree, which is what the mutation tests
in `api/tests/test_guard_mutations.py` use to inject a violation and assert this
refuses it.
"""

from __future__ import annotations

import argparse
import hashlib
import os
import sys
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

REPO = Path(__file__).resolve().parents[1]
API_DIR = REPO / "api"

#: Columns whose loss makes the evidence readable and unverifiable, which is
#: worse than either. `chain_` catches the anchor columns without naming each.
CHAIN_COLUMN_PREFIXES = ("prev_hash", "this_hash", "chain_")

#: Invariant 3: money is an integer count of cents and proportions are integer
#: basis points. `numeric` is exact and still refused — it is how a decimal
#: amount gets in, and the invariant is about the representation, not the error.
FLOAT_TYPES = frozenset(
    {"double precision", "real", "numeric", "money", "float", "decimal"}
)

#: The writes an append-only table must never accept from a worker role.
FORBIDDEN_PRIVILEGES = frozenset({"UPDATE", "DELETE", "TRUNCATE"})

#: The roles that serve requests and run workers. None of them owns the schema,
#: and none of them may acquire BYPASSRLS.
WORKER_ROLES = ("quolin_app", "quolin_watch", "quolin_maintenance")

#: Functions whose body is load-bearing. A change to one of these is a change to
#: what the database enforces, however routine the migration looks.
GUARDED_FUNCTIONS = ("quolin_append_only",)

#: Revisions permitted to change a guarded function's body, each with the digest
#: that change is expected to produce. A migration that legitimately needs to
#: rewrite `quolin_append_only` adds itself here, and the review of that line is
#: the review of the change. An empty allow-list means no migration may.
FUNCTION_BODY_ALLOWLIST: dict[str, dict[str, str]] = {}


@dataclass(frozen=True)
class Catalog:
    """Everything this linter knows how to compare, read back from the server."""

    tables: frozenset[str]
    grants: frozenset[tuple[str, str, str]]
    triggers: dict[tuple[str, str], str]
    function_digests: dict[str, str]
    columns: dict[tuple[str, str], str]
    policies: frozenset[tuple[str, str]]
    force_rls: dict[str, bool]
    enable_rls: dict[str, bool]
    owners: dict[str, str]
    bypass_rls: dict[str, bool]
    trigger_protected: frozenset[str]


@dataclass
class Report:
    """What the walk found, and enough of where to act on it."""

    failures: list[str] = field(default_factory=list)
    steps: int = 0
    downgrade_steps: int = 0
    irreversible: int = 0

    def fail(self, revision: str, direction: str, message: str) -> None:
        self.failures.append(f"{revision} ({direction}): {message}")


def _capture(conn: Any) -> Catalog:
    """Read the catalog. Every question this linter asks is answered here."""
    from sqlalchemy import text

    tables = frozenset(
        r[0]
        for r in conn.execute(
            text(
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema = 'public' AND table_type = 'BASE TABLE'"
            )
        )
    )

    grants = frozenset(
        (r[0], r[1], r[2].upper())
        for r in conn.execute(
            text(
                "SELECT table_name, grantee, privilege_type "
                "FROM information_schema.role_table_grants "
                "WHERE table_schema = 'public' AND grantee = ANY(:roles)"
            ),
            {"roles": list(WORKER_ROLES)},
        )
    )

    triggers = {
        (r[0], r[1]): r[2]
        for r in conn.execute(
            text(
                "SELECT c.relname, t.tgname, t.tgenabled "
                "FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid "
                "JOIN pg_namespace n ON n.oid = c.relnamespace "
                "WHERE NOT t.tgisinternal AND n.nspname = 'public'"
            )
        )
    }

    # The body as the server stores it, hashed. Comparing the text itself would
    # make the failure message a wall of plpgsql; the digest is the claim.
    function_digests = {
        r[0]: hashlib.sha256(r[1].encode()).hexdigest()
        for r in conn.execute(
            text(
                "SELECT p.proname, p.prosrc FROM pg_proc p "
                "JOIN pg_namespace n ON n.oid = p.pronamespace "
                "WHERE n.nspname = 'public' AND p.proname = ANY(:names)"
            ),
            {"names": list(GUARDED_FUNCTIONS)},
        )
    }

    columns = {
        (r[0], r[1]): r[2]
        for r in conn.execute(
            text(
                "SELECT table_name, column_name, data_type "
                "FROM information_schema.columns WHERE table_schema = 'public'"
            )
        )
    }

    policies = frozenset(
        (r[0], r[1])
        for r in conn.execute(
            text(
                "SELECT c.relname, p.polname FROM pg_policy p "
                "JOIN pg_class c ON c.oid = p.polrelid "
                "JOIN pg_namespace n ON n.oid = c.relnamespace "
                "WHERE n.nspname = 'public'"
            )
        )
    )

    # Three separate flags, and a migration can undo the protection through any
    # of them. FORCE off exempts the table owner from every policy; ENABLE off
    # switches policies out of the plan for everybody; and an owner change hands
    # the table to a role that can drop the trigger and the policies both.
    rls = list(
        conn.execute(
            text(
                "SELECT c.relname, c.relforcerowsecurity, c.relrowsecurity, "
                "pg_get_userbyid(c.relowner) FROM pg_class c "
                "JOIN pg_namespace n ON n.oid = c.relnamespace "
                "WHERE n.nspname = 'public' AND c.relkind = 'r'"
            )
        )
    )
    force_rls = {r[0]: bool(r[1]) for r in rls}
    enable_rls = {r[0]: bool(r[2]) for r in rls}
    owners = {r[0]: r[3] for r in rls}

    bypass_rls = {
        r[0]: bool(r[1])
        for r in conn.execute(
            text("SELECT rolname, rolbypassrls FROM pg_roles WHERE rolname = ANY(:roles)"),
            {"roles": list(WORKER_ROLES)},
        )
    }

    # A table is protected because the database protects it, not because a
    # constant says so. This is what stops the model list and the schema drifting
    # apart without the guard noticing.
    trigger_protected = frozenset(
        table for (table, name) in triggers if name.endswith("_append_only")
    )

    return Catalog(
        tables=tables,
        grants=grants,
        triggers=triggers,
        function_digests=function_digests,
        columns=columns,
        policies=policies,
        force_rls=force_rls,
        enable_rls=enable_rls,
        owners=owners,
        bypass_rls=bypass_rls,
        trigger_protected=trigger_protected,
    )


def compare(
    before: Catalog,
    after: Catalog,
    *,
    append_only: frozenset[str],
    tenant_scoped: frozenset[str],
    revision: str,
    direction: str,
    report: Report,
) -> None:
    """Diff two catalog captures against the invariants.

    Every rule is scoped to tables present in *both* states. A migration that
    creates a table and its downgrade that drops it are the same statement read
    in two directions, and neither is a violation; what is a violation is a
    table that survives the migration with its protection removed.
    """
    protected = (append_only | before.trigger_protected | after.trigger_protected) & (
        before.tables & after.tables
    )
    common = before.tables & after.tables

    # 1. A worker role gaining UPDATE, DELETE or TRUNCATE on evidence.
    for table, grantee, privilege in sorted(after.grants - before.grants):
        if table in protected and privilege in FORBIDDEN_PRIVILEGES:
            report.fail(
                revision,
                direction,
                f"grants {privilege} on append-only {table} to {grantee}. "
                "Invariant 4: a correction is a new appended row, not an edit "
                "to a row that is already hash-chained.",
            )

    # 2. An append-only trigger removed, or disabled in place.
    for (table, name), enabled in sorted(before.triggers.items()):
        if table not in common or not name.endswith("_append_only"):
            continue
        if (table, name) not in after.triggers:
            report.fail(
                revision,
                direction,
                f"drops trigger {name} on {table}, which still exists. "
                "Invariant 4 is enforced by that trigger.",
            )
        elif after.triggers[(table, name)] == "D" and enabled != "D":
            report.fail(
                revision,
                direction,
                f"disables trigger {name} on {table}. A disabled trigger reads "
                "as protection in a catalog dump and enforces nothing.",
            )

    # 3. A guarded trigger function rewritten. The trigger object survives and
    #    the enforcement is gone, so nothing else in this list would notice.
    allowed = FUNCTION_BODY_ALLOWLIST.get(revision, {})
    for name, digest in sorted(before.function_digests.items()):
        new = after.function_digests.get(name)
        if new is None:
            report.fail(
                revision, direction, f"drops function {name}(), which enforces append-only."
            )
        elif new != digest and allowed.get(name) != new:
            report.fail(
                revision,
                direction,
                f"changes the body of {name}() (digest {digest[:12]} -> "
                f"{new[:12]}). If that is intended, add the revision and the new "
                "digest to FUNCTION_BODY_ALLOWLIST with a reason.",
            )

    # 4a. A float, double or money column anywhere on a protected table.
    for (table, column), data_type in sorted(after.columns.items()):
        if table not in protected:
            continue
        if (table, column) in before.columns:
            continue
        if data_type.lower() in FLOAT_TYPES:
            report.fail(
                revision,
                direction,
                f"adds {table}.{column} as {data_type}. Invariant 3: money is "
                "integer cents and proportions are integer basis points.",
            )

    # 4b. A chain column dropped from a table that still exists.
    for (table, column) in sorted(before.columns):
        if table not in common or (table, column) in after.columns:
            continue
        if column.startswith(CHAIN_COLUMN_PREFIXES):
            report.fail(
                revision,
                direction,
                f"drops {table}.{column}. Invariant 5: replay proves nothing if "
                "the chain it verifies against is gone.",
            )

    # 5. A policy dropped, or FORCE row-level security turned off.
    for table, policy in sorted(before.policies - after.policies):
        if table in common and table in tenant_scoped:
            report.fail(
                revision,
                direction,
                f"drops policy {policy} on tenant-scoped {table}. Invariant 1 "
                "is the only thing separating two customers' rows.",
            )
    for table, forced in sorted(before.force_rls.items()):
        if table in common and table in tenant_scoped and forced:
            if not after.force_rls.get(table, False):
                report.fail(
                    revision,
                    direction,
                    f"un-forces row-level security on {table}. Without FORCE the "
                    "table owner is exempt from every policy on it.",
                )
    for table, enabled in sorted(before.enable_rls.items()):
        if table in common and table in tenant_scoped and enabled:
            if not after.enable_rls.get(table, False):
                report.fail(
                    revision,
                    direction,
                    f"disables row-level security on {table}. The policies are "
                    "still in the catalog and no longer in any query plan, which "
                    "is the worst of the three states to read a dump in.",
                )

    # 7. A protected table handed to another role. The owner can drop the
    #    trigger and every policy on it, so an OWNER TO is every other rule in
    #    this list granted at once, deferred.
    for table, owner in sorted(before.owners.items()):
        if table not in common or table not in (protected | tenant_scoped):
            continue
        if after.owners.get(table) != owner:
            report.fail(
                revision,
                direction,
                f"changes the owner of {table} from {owner} to "
                f"{after.owners.get(table)}. The owner can drop the trigger and "
                "the policies that are the enforcement.",
            )

    # 6. A worker role acquiring BYPASSRLS.
    for role, bypass in sorted(after.bypass_rls.items()):
        if bypass and not before.bypass_rls.get(role, False):
            report.fail(
                revision,
                direction,
                f"gives {role} BYPASSRLS, which switches off every policy in the "
                "database for it.",
            )


def standing(catalog: Catalog, append_only: frozenset[str], report: Report) -> None:
    """What the schema ends up enforcing, asked as a question about the end state.

    Every other rule in this file is a delta: it compares two catalog captures
    and objects to the difference. That is the right shape for "a migration
    weakened something" and it is blind to "this was never right in the first
    place" — a grant present since the baseline appears in both captures and so
    appears in neither diff.

    FP3-10 is exactly that. Migration 0001 grants UPDATE and DELETE to
    `quolin_app` on every table created after it, by default privilege, and
    revokes them on the append-only ones by name. `chain_rechains` — the table
    recording who rewrote a firm's evidence hashes — was added by 0034 with a
    SELECT grant and no revoke, so the application role could UPDATE and DELETE
    the record of chain rewrites, and only the trigger stood between it and a
    silent one. No migration weakened anything; the weakness arrived with the
    table.

    So this asks the end state directly, and it is the check that would have
    caught it on the day 0034 merged.
    """
    protected = (append_only | catalog.trigger_protected) & catalog.tables
    for table, grantee, privilege in sorted(catalog.grants):
        if table in protected and privilege in FORBIDDEN_PRIVILEGES:
            report.fail(
                "head",
                "standing",
                f"{grantee} holds {privilege} on append-only {table}. The trigger "
                "refuses the write today; the grant is the second, independent "
                "statement of the same rule and it is missing.",
            )

    # And the two lists agreeing is itself part of the end state. A table the
    # database protects and the model constant does not is a table every
    # parametrised test over APPEND_ONLY_TABLES silently skips.
    for table in sorted(catalog.trigger_protected - append_only):
        report.fail(
            "head",
            "standing",
            f"{table} carries an append-only trigger and is not in "
            "models.APPEND_ONLY_TABLES. Every test parametrised over that "
            "constant skips it.",
        )
    for table in sorted((append_only & catalog.tables) - catalog.trigger_protected):
        report.fail(
            "head",
            "standing",
            f"{table} is in models.APPEND_ONLY_TABLES and carries no append-only "
            "trigger. The constant claims an enforcement the database does not have.",
        )


def _role_attributes(url: str) -> dict[str, bool]:
    from sqlalchemy import create_engine, text

    engine = create_engine(url)
    try:
        with engine.connect() as conn:
            return {
                r[0]: bool(r[1])
                for r in conn.execute(
                    text(
                        "SELECT rolname, rolbypassrls FROM pg_roles "
                        "WHERE rolname = ANY(:roles)"
                    ),
                    {"roles": list(WORKER_ROLES)},
                )
            }
    finally:
        engine.dispose()


def _restore_roles(url: str, expected: dict[str, bool]) -> list[str]:
    """Put back any role attribute a migration changed under us.

    Roles are cluster-scoped and databases are not. A scratch database contains
    everything a migration does to a table and nothing it does to a role, so
    `ALTER ROLE quolin_app BYPASSRLS` inside a migration under test lands on the
    *real* roles, shared with every other database on that server.

    This was not a hypothetical. The mutation case for exactly that statement
    was written, run, and left `quolin_app` and `quolin_watch` holding BYPASSRLS
    on the development cluster — the test proving the guard catches the change
    made the change, and the guard reported OK because by then the roles had
    already been altered before the "before" capture of the next run. Found by
    reading `pg_roles` after the case failed for the wrong reason.

    So the attributes are captured before the walk and put back after it,
    whatever happened in between.
    """
    from sqlalchemy import create_engine, text

    restored = []
    engine = create_engine(url, isolation_level="AUTOCOMMIT")
    try:
        with engine.connect() as conn:
            for role, bypass in expected.items():
                now = conn.execute(
                    text("SELECT rolbypassrls FROM pg_roles WHERE rolname = :r"),
                    {"r": role},
                ).scalar()
                if now is not None and bool(now) != bypass:
                    clause = "BYPASSRLS" if bypass else "NOBYPASSRLS"
                    conn.execute(text(f'ALTER ROLE "{role}" {clause}'))
                    restored.append(role)
    finally:
        engine.dispose()
    return restored


def _scratch_database(admin_url: str, name: str) -> None:
    from sqlalchemy import create_engine, text

    engine = create_engine(_with_database(admin_url, "postgres"), isolation_level="AUTOCOMMIT")
    with engine.connect() as conn:
        conn.execute(text(f'DROP DATABASE IF EXISTS "{name}" WITH (FORCE)'))
        conn.execute(text(f'CREATE DATABASE "{name}"'))
    engine.dispose()


def _drop_database(admin_url: str, name: str) -> None:
    from sqlalchemy import create_engine, text

    engine = create_engine(_with_database(admin_url, "postgres"), isolation_level="AUTOCOMMIT")
    with engine.connect() as conn:
        conn.execute(text(f'DROP DATABASE IF EXISTS "{name}" WITH (FORCE)'))
    engine.dispose()


def _with_database(url: str, name: str) -> str:
    head, _, _ = url.rpartition("/")
    return f"{head}/{name}"


def _revisions(migrations_dir: Path) -> list[Any]:
    """Every revision in the tree, base first."""
    from alembic.config import Config
    from alembic.script import ScriptDirectory

    config = Config()
    config.set_main_option("script_location", str(migrations_dir))
    script = ScriptDirectory.from_config(config)
    return list(reversed(list(script.walk_revisions())))


def lint(
    migrations_dir: Path,
    database_url: str,
    *,
    admin_url: str,
    check_downgrades: bool = True,
    since: str | None = None,
) -> Report:
    """Walk the tree a revision at a time, in both directions, diffing as it goes."""
    from alembic import command
    from alembic.config import Config
    from sqlalchemy import create_engine

    from app.models import APPEND_ONLY_TABLES, TENANT_SCOPED_TABLES

    append_only = frozenset(APPEND_ONLY_TABLES)
    tenant_scoped = frozenset(TENANT_SCOPED_TABLES)

    config = Config()
    config.set_main_option("script_location", str(migrations_dir))
    config.set_main_option("sqlalchemy.url", database_url.replace("%", "%%"))

    report = Report()
    scratch = database_url.rpartition("/")[2]
    engine = create_engine(database_url)
    revisions = _revisions(migrations_dir)

    def snapshot() -> Catalog:
        with engine.connect() as conn:
            return _capture(conn)

    # `--since` applies everything up to a known-good revision in one step and
    # examines only what comes after it. The full walk from base is what CI runs
    # on this repository; the mutation tests in `test_guard_mutations.py` add one
    # sacrificial revision to a copy of this tree and care only about that one,
    # and making them re-diff thirty-five known-good migrations each would buy
    # nothing but a slower suite.
    baseline: Catalog | None = None
    if since is not None:
        names = [r.revision for r in revisions]
        if since not in names:
            raise SystemExit(f"--since {since} is not a revision in {migrations_dir}")
        command.upgrade(config, since)
        baseline = snapshot()
        revisions = revisions[names.index(since) + 1 :]

    try:
        snapshots = [baseline if baseline is not None else snapshot()]

        for revision in revisions:
            command.upgrade(config, revision.revision)
            after = snapshot()
            compare(
                snapshots[-1],
                after,
                append_only=append_only,
                tenant_scoped=tenant_scoped,
                revision=revision.revision,
                direction="upgrade",
                report=report,
            )
            snapshots.append(after)
            report.steps += 1

        # Only meaningful over a walk that started at base; with `--since` the
        # end state includes migrations this run never examined.
        if since is None:
            standing(snapshots[-1], append_only, report)

        if not check_downgrades:
            return report

        # 0026's downgrade dropped both chain columns and the regex linter
        # called the tree clean, so the reverse direction is not optional.
        #
        # Each downgrade is tested on its own rather than as one walk from head
        # to base. Twelve of these migrations refuse to downgrade at all — they
        # raise, deliberately, because reversing them would mean dropping
        # evidence — and a single walk stops dead at the first one. The first
        # version of this guard did exactly that and reported "35 upgrade and 1
        # downgrade steps", having never reached 0026: the guard rewritten to
        # catch a specific counter-example, still not reaching it. So an
        # irreversible migration is a barrier this steps around by rebuilding
        # the scratch database at the revision below it and carrying on down.
        index = len(revisions) - 1
        at = len(revisions) - 1  # the revision the scratch database is holding
        floor = 0 if since is None else 0

        while index >= floor:
            revision = revisions[index]
            target = revision.down_revision or "base"
            if isinstance(target, tuple):  # a merge point; not this tree's shape
                break

            if at != index:
                engine.dispose()
                _scratch_database(admin_url, scratch)
                engine = create_engine(database_url)
                command.upgrade(config, revision.revision)
                at = index

            try:
                command.downgrade(config, target)
            except NotImplementedError:
                # Declared irreversible on purpose. That is the protection
                # working, so it is counted rather than reported.
                report.irreversible += 1
                index -= 1
                continue
            except Exception as exc:  # pragma: no cover - a broken downgrade
                report.fail(
                    revision.revision, "downgrade", f"raised {type(exc).__name__}: {exc}"
                )
                index -= 1
                continue

            at = index - 1
            compare(
                snapshots[index + 1],
                snapshot(),
                append_only=append_only,
                tenant_scoped=tenant_scoped,
                revision=revision.revision,
                direction="downgrade",
                report=report,
            )
            report.downgrade_steps += 1
            index -= 1
    finally:
        engine.dispose()

    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--migrations-dir",
        default=os.getenv("MIGRATIONS_DIR") or str(API_DIR / "migrations"),
    )
    parser.add_argument(
        "--admin-url",
        default=os.getenv("QUOLIN_LINT_ADMIN_URL")
        or os.getenv("DATABASE_URL")
        or "postgresql+psycopg://quolin:quolin@localhost:5433/quolin",
        help="A connection able to CREATE DATABASE. Its database name is not used.",
    )
    parser.add_argument("--no-downgrades", action="store_true")
    parser.add_argument(
        "--since",
        default=None,
        help=(
            "Apply everything up to this revision in one step and examine only "
            "what follows it. The full walk from base is the default."
        ),
    )
    args = parser.parse_args(argv)

    migrations_dir = Path(args.migrations_dir)

    # An absent or empty target is a failure, never a pass. A guard that reports
    # OK having examined nothing is worse than no guard, because somebody reads
    # the OK. This is the same reasoning F12 applied to the old linter and it is
    # asserted by a mutation case rather than left to this comment.
    if not migrations_dir.is_dir():
        print(f"FAIL: no migrations directory at {migrations_dir}.")
        print()
        print("This guard applies migrations to a scratch database and reads the")
        print("catalog back. It found nothing to apply, which means it is pointed")
        print("at the wrong place rather than that the migrations are clean.")
        return 1

    versions = migrations_dir / "versions"
    candidates = list(versions.glob("*.py")) if versions.is_dir() else []
    if not candidates:
        print(f"FAIL: {migrations_dir} holds no migrations.")
        print()
        print("A scan of zero migrations is not a clean scan.")
        return 1

    sys.path.insert(0, str(API_DIR))
    scratch = f"quolin_lint_{uuid.uuid4().hex[:12]}"
    scratch_url = _with_database(args.admin_url, scratch)

    # Set before `app.db` is imported anywhere: it reads DATABASE_URL at import
    # time and alembic's env.py takes the owner URL from it. Without this the
    # walk would apply migrations to whatever database the caller was pointed
    # at, which for a developer running this locally is the one with their data
    # in it.
    os.environ["DATABASE_URL"] = scratch_url

    try:
        _scratch_database(args.admin_url, scratch)
    except Exception as exc:
        print(f"FAIL: could not create the scratch database {scratch}: {exc}")
        print()
        print("This guard needs a Postgres it may create and drop a database on.")
        print("Set QUOLIN_LINT_ADMIN_URL to a connection that can.")
        return 1

    roles_before = _role_attributes(_with_database(args.admin_url, "postgres"))
    try:
        report = lint(
            migrations_dir,
            scratch_url,
            admin_url=args.admin_url,
            check_downgrades=not args.no_downgrades,
            since=args.since,
        )
    finally:
        restored = _restore_roles(
            _with_database(args.admin_url, "postgres"), roles_before
        )
        _drop_database(args.admin_url, scratch)
        if restored:
            print(
                "NOTE: a migration under test altered "
                f"{', '.join(restored)}; the previous attributes were put back. "
                "Roles are cluster-scoped, so a scratch database does not "
                "contain that change."
            )

    if report.failures:
        for failure in report.failures:
            print(f"FAIL: {failure}")
        print()
        print(f"{len(report.failures)} violation(s) across {report.steps} upgrade "
              f"and {report.downgrade_steps} downgrade steps.")
        return 1

    print(
        f"OK: {report.steps} upgrade and {report.downgrade_steps} downgrade steps "
        f"applied to a scratch database ({report.irreversible} migrations decline "
        "to downgrade at all); no append-only grant, trigger, trigger function, "
        "chain column, policy, FORCE RLS setting or role attribute was weakened."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
