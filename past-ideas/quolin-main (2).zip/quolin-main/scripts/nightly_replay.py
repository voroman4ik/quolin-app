"""
Re-evaluate every decision on file and report any that no longer reproduce.

Invariant 5 running as a service rather than as a promise. The suite already
replays the seeded decisions on every commit, which proves the mechanism works
against the data we control. This proves it still works against the data a
customer has accumulated — including the decisions made under pack versions
nobody has looked at for a year, and under DSL versions the engine has since
moved past.

    make nightly-replay                     # the deployment's own tenant
    make nightly-replay ARGS="--json"       # for an alerting pipeline
    make nightly-replay ARGS="acme beta"
    make nightly-replay ARGS="--inject"     # prove the alarm is wired up

**Exit codes are the alert.** 0 when everything reproduced, 1 when anything did
not, 2 when the run could not be completed. A monitor watching this only has to
watch the exit code, which is the least that can go wrong between a mismatch and
somebody hearing about it.

**`--inject` is the point of the whole thing.** A nightly job that has never
failed is indistinguishable from a nightly job that cannot fail, and the
execution document asks for the alert to be demonstrated on a deliberately
injected mismatch rather than assumed. With this flag the script alters one
decision's stored outcome in memory — never in the database — replays it, and
expects to catch it. If it does not, the alarm is broken and the script says so
loudly. Run it the first time the job is deployed, and any time somebody doubts
it.

**It reads. It never writes.** Not even to fix a decision it finds wrong: a
determination on file is a record of what was decided, and a nightly job that
rewrote one would be destroying the evidence it exists to check. What it finds,
a person acts on.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# Same dual-layout dance as scripts/watch_tick.py: `api/` in the repo, flattened
# to the working directory inside the container.
_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from scripts import evidence_io  # noqa: E402
from sqlalchemy import select  # noqa: E402

from app import crypto, evidence, observability, packs_repo, service, tenancy  # noqa: E402
from app.db import SessionLocal  # noqa: E402
from app.models import Decision  # noqa: E402


def _replay_one(session, decision: Decision) -> dict:
    """One decision, re-evaluated against the pack of record.

    `evidence.replay` rather than `service.replay`, deliberately: the service
    version writes an audit row, and a nightly sweep over a hundred thousand
    decisions would put a hundred thousand rows in the audit trail describing
    nothing a person did. The chain is verified once for the whole run instead.
    """
    pack = packs_repo.by_version(
        session, decision.pack_id or "AU", decision.pack_version
    )
    others = service._other_packs(session, decision)
    return evidence.replay(decision, pack, others)


def _check_tenant(tenant_id: str, *, inject: bool) -> dict:
    with tenancy.acting_as(tenant_id):
        session = SessionLocal()
        try:
            # Ids first, rows one at a time. `decisions.snapshot` is
            # `EncryptedJSON`, so SQLAlchemy decrypts while *materialising* the
            # row — and `list(session.scalars(...))` materialises all of them
            # before the loop below, outside every handler this function has.
            #
            # A forged row therefore ended the whole run with
            # "nightly replay could not run", on a tenant whose other four
            # thousand determinations were never looked at, at the exact moment
            # somebody was writing to the evidence table by hand. Loaded here,
            # each row's failure is one recorded mismatch and the sweep
            # continues — which is the treatment every other unreplayable
            # decision already got.
            ids = list(session.scalars(select(Decision.id).order_by(Decision.id)))
            mismatches = []
            replayed = 0

            for decision_id in ids:
                try:
                    decision = session.get(Decision, decision_id)
                except Exception as exc:
                    mismatches.append(
                        {
                            "decision_id": decision_id,
                            "problem": (
                                "could not be read at all: "
                                f"{type(exc).__name__}: {exc}. A determination "
                                "whose stored bytes will not decode was not "
                                "written by this application."
                            ),
                        }
                    )
                    session.rollback()
                    continue
                if decision is None:
                    continue
                replayed += 1

                try:
                    result = _replay_one(session, decision)
                except Exception as exc:
                    mismatches.append(
                        {
                            "decision_id": decision.id,
                            "as_of": decision.as_of.isoformat(),
                            "pack": f"{decision.pack_id} v{decision.pack_version}",
                            "problem": f"could not be replayed: {type(exc).__name__}: {exc}",
                        }
                    )
                    continue
                if not result["match"]:
                    mismatches.append(
                        {
                            "decision_id": decision.id,
                            "as_of": decision.as_of.isoformat(),
                            "pack": f"{decision.pack_id} v{decision.pack_version}",
                            "stored": result["stored_outcome"],
                            "replayed": result["replayed_outcome"],
                            "differences": result["differences"],
                        }
                    )

            # Written down, not only returned. The exit code tells a scheduler
            # something is wrong tonight; this is what `alerts.replay_mismatches`
            # reads tomorrow, and what somebody looks at during the incident.
            # A determination that no longer reproduces has no acting person, so
            # it belongs in `security_events` rather than the audit trail.
            for mismatch in mismatches:
                observability.record(
                    session,
                    kind=observability.REPLAY_MISMATCH,
                    detail=json.dumps(mismatch, default=str)[:2000],
                )
            if mismatches:
                session.commit()

            # Wrapped, which it was not. `verify_chain` returns a graded verdict
            # for every row-level problem now, so a tamper arrives here as a
            # report rather than as the end of a run with a whole book left to
            # check. What is left to catch is the unexpected.
            #
            # `NoChainAnchor` and the two crypto configuration errors are
            # **not** caught, deliberately. Those mean the check could not run,
            # `main` below turns them into exit 2 — the code this job's own
            # documentation gives to "could not run" — and grading them here
            # would report a tenant with no chain anchor as a tenant whose chain
            # is broken. Those are different sentences and one of them names an
            # incident that did not happen.
            try:
                chain = evidence.verify_chain(session)
            except (evidence.NoChainAnchor, crypto.KeysNotConfigured, crypto.NoDataKey):
                raise
            except Exception as exc:  # noqa: BLE001 — a report, not a crash
                chain = {
                    "verified": False,
                    "tenant_id": tenant_id,
                    "reason": "COULD_NOT_VERIFY",
                    "detail": f"{type(exc).__name__}: {exc}",
                }

            injected = None
            if inject and ids:
                first = session.get(Decision, ids[0])
                if first is not None:
                    injected = _prove_the_alarm_works(session, first)

            return {
                "tenant_id": tenant_id,
                "decisions": len(ids),
                "replayed": replayed,
                "mismatches": mismatches,
                "chain": chain,
                "injected": injected,
            }
        finally:
            session.close()


def _prove_the_alarm_works(session, decision: Decision) -> dict:
    """Break one decision in memory, replay it, and expect to be caught.

    In memory and never committed — `session.expunge` detaches the row before it
    is altered, so nothing can be flushed by accident. `decisions` is append-only
    at the database level in any case, which is a second line rather than a
    reason to be careless with the first.
    """
    stored = decision.outcome
    wrong = "ALLOW" if stored != "ALLOW" else "BLOCK"

    session.expunge(decision)
    decision.outcome = wrong
    try:
        result = _replay_one(session, decision)
        caught = not result["match"]
    except Exception:
        # A decision that will not replay at all is also caught — that is the
        # other half of what this job watches for.
        caught = True
    finally:
        decision.outcome = stored

    return {
        "decision_id": decision.id,
        "changed_outcome_to": wrong,
        "caught": caught,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Re-evaluate every decision on file and report any that no longer reproduce."
    )
    parser.add_argument("tenants", nargs="*", help="Tenant ids. Defaults to the configured one.")
    parser.add_argument("--json", action="store_true", help="Machine-readable output.")
    parser.add_argument(
        "--inject",
        action="store_true",
        help="Also alter one decision in memory and confirm the mismatch is caught.",
    )
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    tenants = args.tenants or [tenancy.configured_tenant()]

    try:
        # One session per tenant, inside `_check_tenant`. `app.tenant_id` binds
        # when a transaction begins, so a session reused across the loop would
        # read the first tenant's decisions under every subsequent heading —
        # the same trap `app/access_review.py` documents at length.
        reports = [_check_tenant(t, inject=args.inject) for t in tenants]
    except Exception as exc:
        print(f"nightly replay could not run: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(reports, indent=2, default=str))
    else:
        for report in reports:
            _print(report)

    failed = any(r["mismatches"] or not r["chain"]["verified"] for r in reports)
    alarm_broken = any(
        r["injected"] is not None and not r["injected"]["caught"] for r in reports
    )
    if alarm_broken:
        print(
            "\nFAIL: an injected mismatch was NOT detected. This job cannot tell you "
            "when a decision stops reproducing, which is the only thing it is for.",
            file=sys.stderr,
        )
        return 1
    if args.evidence_out:
        evidence_io.write(
            "drills",
            "nightly-replay",
            report,
            passed=not report["mismatches"]
            and (report["injected"] is None or report["injected"]["caught"]),
            summary=(
                f"{report.get('replayed', 0)} determination(s) re-evaluated against "
                "the pack of record; "
                + (
                    "every one reproduced exactly."
                    if not report["mismatches"]
                    else f"{len(report['mismatches'])} did NOT reproduce."
                )
            ),
        )

    return 1 if failed else 0


def _print(report: dict) -> None:
    print(f"\ntenant {report['tenant_id']}: {report['decisions']} decision(s)")
    chain = report["chain"]
    # The reason, when there is one. "BROKEN" alone sends somebody to
    # chain-mismatch.md with nothing to look for; "BROKEN at #4201
    # (UNDECRYPTABLE_SNAPSHOT)" tells them which of that runbook's three
    # branches they are in before they open it.
    state = "verified" if chain["verified"] else "BROKEN"
    if not chain["verified"]:
        where = chain.get("broken_at_decision_id")
        reason = chain.get("reason", "")
        state += (f" at #{where}" if where is not None else "") + (
            f" ({reason})" if reason else ""
        )
    print(f"  chain      {state} ({chain.get('checked', 0)} links)")
    if chain.get("detail"):
        print(f"             {chain['detail']}")

    if report["mismatches"]:
        print(f"  mismatches {len(report['mismatches'])} — invariant 5 is not holding:")
        for row in report["mismatches"]:
            detail = row.get("problem") or (
                f"stored {row['stored']}, replayed {row['replayed']}"
            )
            # A row that could not be read at all has no pack and no `as_of` —
            # reading them off it is what a report about unreadable rows must
            # not do.
            where = (
                f" ({row['pack']}, {row['as_of']})"
                if row.get("pack") and row.get("as_of")
                else ""
            )
            print(f"    decision {row['decision_id']}{where}: {detail}")
    else:
        print("  mismatches none — every decision on file still reproduces exactly")


    if report["injected"] is not None:
        got = report["injected"]
        state = "caught" if got["caught"] else "NOT CAUGHT"
        print(
            f"  injected   decision {got['decision_id']} forced to "
            f"{got['changed_outcome_to']} — {state}"
        )


if __name__ == "__main__":
    raise SystemExit(main())
