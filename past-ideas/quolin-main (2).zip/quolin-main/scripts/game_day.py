"""
Fire every alert path on purpose, and check that each one actually fires.

§S9's gate: *every alert path fires in a game-day test*. The point is not that
the code compiles — the tests cover that — but that the whole path works on a
real system: the condition is created, the check notices, and the alert says
something a person woken at 3am can act on.

**Each condition is created for real.** A failed sign-in is a failed sign-in, a
dead webhook delivery is a delivery that has exhausted its attempts. Nothing is
mocked, because the thing being tested is the join between the system's real
state and the query that watches it — which is exactly what a mock removes.

**Everything is undone afterwards, except what cannot be.** `security_events` is
append-only, so the rows this leaves are permanent and say `game day` in their
detail. That is the correct trade: a drill that could erase its own evidence
would be a drill against a system that is not the one running in production.

**It is safe to run against staging and refuses to run against production.** A
game day that created a genuine broken chain in a customer's database would be
an incident rather than a drill.

Usage:

    make game-day
    make game-day ARGS=--json

Exit codes: 0 if every path fired, 1 if the drill could not run, 2 if a path
stayed silent — which is the interesting failure, because it means an alert
somebody is relying on does not work.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from scripts import evidence_io  # noqa: E402
from sqlalchemy import select, text  # noqa: E402

from app import alerts, auth, observability, tenancy  # noqa: E402
from app.db import OwnerSessionLocal, SessionLocal  # noqa: E402
from app.models import ArtefactJob, WebhookDelivery, WebhookEndpoint  # noqa: E402

#: Written into every row this drill creates, so that anybody reading the
#: security log afterwards can tell a drill from an incident without having to
#: remember when the drill was.
MARKER = "game day"


class DrillRefused(RuntimeError):
    """The drill will not run here."""


def _refuse_in_production() -> None:
    environment = os.getenv("QUOLIN_ENVIRONMENT", "dev").strip().lower()
    if environment in ("prod", "production"):
        raise DrillRefused(
            "This drill creates failed sign-ins, a dead webhook delivery and a "
            "deep queue on purpose. Against production that is an incident, not "
            "a drill. Run it against staging."
        )


def _fire_auth_anomaly(session, tenant_id: str) -> None:
    """Enough failed sign-ins against one account to cross the threshold.

    Written with `auth.record_failure` — the call the login handler makes, into
    the table it writes to. This drill used to fabricate `security_events` rows
    instead, and passed every time against a check that could not fire on a real
    sign-in: that table needs a tenant and `/auth/login` cannot have one, so
    every genuine failure was discarded. §S12 found it. A drill that supplies its
    own input through a path production does not use proves the drill works.
    """
    user_id = session.scalar(select(text("id")).select_from(text("users")).limit(1))
    for _ in range(alerts.AUTH_FAILURES_PER_ACCOUNT):
        auth.record_failure(session, "198.51.100.7", user_id=str(user_id))
    session.commit()


def _fire_rls_denial(session) -> None:
    """A query refused by row-level security, recorded the way the real path
    records it."""
    observability.record(
        session,
        kind=observability.RLS_DENIED,
        source_ip="198.51.100.7",
        detail=f"{MARKER}: a query reached for another tenant's rows",
    )
    session.commit()


def _fire_replay_mismatch(session) -> None:
    observability.record(
        session,
        kind="replay.mismatch",
        detail=f"{MARKER}: determination #0 did not reproduce",
    )
    session.commit()


def _fire_dead_letter(session) -> WebhookDelivery | None:
    """One delivery that has given up.

    Created against a throwaway endpoint so the drill cannot mark a customer's
    real delivery dead — which would be an outage dressed as a test.
    """
    from app import webhooks
    from app.identity import new_id

    endpoint = WebhookEndpoint(
        id=new_id("whe"),
        url="https://game-day.invalid/nowhere",
        label=f"{MARKER} endpoint",
        secret=webhooks.new_secret(),
        events=[],
        status="active",
    )
    session.add(endpoint)
    session.flush()

    delivery = WebhookDelivery(
        # Explicit, because a delivery id is an opaque string rather than a
        # sequence — the same reason a credential id is.
        id=new_id("whd"),
        endpoint_id=endpoint.id,
        event="decision.recorded",
        subject=f"{MARKER}",
        payload={"note": MARKER},
        status="dead",
        attempts=webhooks.MAX_ATTEMPTS,
        last_error=f"{MARKER}: endpoint never answered",
    )
    session.add(delivery)
    session.commit()
    return delivery


def _fire_queue_depth(session) -> list[int]:
    """Enough queued documents to cross the threshold.

    Rows rather than real jobs: the check counts what is waiting, and a thousand
    genuine renders would take twenty minutes and prove nothing extra.
    """
    from app.artefacts import queue

    made = []
    for index in range(alerts.QUEUE_DEPTH):
        job = ArtefactJob(
            kind="tmd",
            params={"decision_id": "0", "note": MARKER},
            fingerprint=queue.fingerprint("tmd", {"game_day": index}),
            subject=f"{MARKER} {index}",
            status="queued",
        )
        session.add(job)
        made.append(job)
    session.commit()
    return [job.id for job in made]


def _clear_queue(job_ids: list[int]) -> None:
    if not job_ids:
        return
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text("DELETE FROM artefact_jobs WHERE id = ANY(:ids)"), {"ids": job_ids}
        )
        owner.commit()
    finally:
        owner.close()


def _clear_dead_letter(delivery_id: str | None) -> None:
    if delivery_id is None:
        return
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text("DELETE FROM webhook_deliveries WHERE id = :id"), {"id": delivery_id}
        )
        owner.execute(
            text("DELETE FROM webhook_endpoints WHERE label = :label"),
            {"label": f"{MARKER} endpoint"},
        )
        owner.commit()
    finally:
        owner.close()


#: What the drill fires, and which alert kind each one must produce. Written as
#: a table so the gate is legible: this is the list of paths §S9 says must fire.
EXPECTED = (
    ("a brute-force attempt", "auth.failures_against_account"),
    ("a row-level-security denial", "rls.denied"),
    ("a replay mismatch", "replay.mismatch"),
    ("a dead webhook delivery", "webhook.dead_letters"),
    ("a queue nobody is draining", "queue.deep"),
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Fire every alert path on purpose.")
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    observability.configure()
    try:
        _refuse_in_production()
    except DrillRefused as exc:
        print(str(exc), file=sys.stderr)
        return 1

    tenant_id = tenancy.configured_tenant()
    job_ids: list[int] = []
    delivery_id: str | None = None

    try:
        with tenancy.acting_as(tenant_id), tenancy.acting_as_user("apc_bulk_sweep"):
            session = SessionLocal()
            try:
                _fire_auth_anomaly(session, tenant_id)
                _fire_rls_denial(session)
                _fire_replay_mismatch(session)
                delivery = _fire_dead_letter(session)
                delivery_id = delivery.id if delivery is not None else None
                job_ids = _fire_queue_depth(session)

                found = alerts.check(session)
            finally:
                session.close()
    except Exception as exc:  # noqa: BLE001 — a drill reports rather than crashes
        print(f"game day could not run: {exc}", file=sys.stderr)
        _clear_queue(job_ids)
        _clear_dead_letter(delivery_id)
        return 1

    fired = {finding.kind for finding in found}
    results = [
        {"condition": condition, "alert": kind, "fired": kind in fired}
        for condition, kind in EXPECTED
    ]
    silent = [row for row in results if not row["fired"]]

    _clear_queue(job_ids)
    _clear_dead_letter(delivery_id)

    if args.json:
        print(json.dumps({"results": results, "findings": [f.as_dict() for f in found]}, indent=2))
    else:
        print("game day — every alert path, fired on purpose\n")
        for row in results:
            mark = "fired" if row["fired"] else "SILENT"
            print(f"  {mark:>6}  {row['condition']:<32} → {row['alert']}")
        print()
        for finding in found:
            if finding.kind in {kind for _c, kind in EXPECTED}:
                print(f"  [{finding.severity}] {finding.summary}")
                print(f"           {finding.action}")
        print(
            f"\n  The security_events rows this drill wrote say {MARKER!r} and stay: "
            "the table is append-only, which is the point of it."
        )

    if args.evidence_out:
        evidence_io.write(
            "game-days",
            "game-day",
            {"fired": fired, "silent": silent},
            passed=not silent,
            summary=(
                f"{len(fired)} alert path(s) fired on purpose; "
                + (
                    "every one was caught."
                    if not silent
                    else f"{len(silent)} did NOT fire."
                )
            ),
        )

    if silent:
        print(
            f"{len(silent)} alert path(s) did not fire: "
            + ", ".join(row["alert"] for row in silent),
            file=sys.stderr,
        )
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
