"""
Rewrap every tenant's data key under a new master key.

**What rotation means here, and what it does not.** Each tenant has one data
key, and every name, date of birth, snapshot and document is sealed under it.
`tenant_keys` holds that key wrapped by a master key the deployment holds. This
script unwraps each row under the current master key and rewraps it under a new
one. Nothing else changes: not one byte of ciphertext is rewritten, no hash is
recomputed, and the data keys themselves are the same keys they were.

That is a deliberate choice and worth defending, because "rotate the keys" is
usually read as "re-encrypt the data". Re-encrypting would mean rewriting every
row of `decisions` — an append-only table of evidence — to change nothing an
auditor can observe. It would mean suspending append-only across the whole
table for the duration, and a chain that verified before and after with every
stored snapshot rewritten in between. The thing rotation is actually for is a
master key that has been exposed or has simply aged, and rewrapping answers
that completely: the exposed key no longer opens anything.

Rotating a *data* key is a different operation with a different justification —
one customer, after a breach on their side — and it does mean rewriting their
evidence. It is not this script, and it should not quietly become this script.

**Why running processes survive it.** `app/crypto.py` caches unwrapped data
keys for the life of the process and never invalidates them. Under a rewrap
that cache stays correct, because the data key it holds is unchanged. So the
window between rewrapping and restarting with the new master key is safe for
processes already running — but *not* for one that starts in it, which would
read the old master key and fail to unwrap. Hence the order in the runbook:
rewrap, then set the secret. See docs/deployment.md.

**It is a dry run unless `--apply`.** The dry run unwraps and rewraps in memory
and checks the result opens again, so it proves both keys are right before
anything is written.

Usage:

    export NEW_MASTER_KEY="$(make master-key)"
    make rotate-keys                        # dry run
    make rotate-keys ARGS=--apply

Exit codes: 0 when every named tenant is wrapped under the new key, 1 otherwise.
"""

from __future__ import annotations

import argparse
import base64
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

# Same dual-layout dance as scripts/watch_tick.py: `api/` in the repo, flattened
# to the working directory inside the container.
_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from cryptography.exceptions import InvalidTag  # noqa: E402

from app import crypto, tenancy  # noqa: E402
from app.db import OwnerSessionLocal  # noqa: E402
from app.models import AuditEvent, TenantKey  # noqa: E402

ACTOR = "scripts.rotate_keys"
NEW_KEY_ENV = "NEW_MASTER_KEY"


def _read_new_key() -> bytes:
    """The key being rotated to, checked as strictly as the one in force.

    A rotation that wrote a short or mistyped key would leave a database nothing
    can open, and would leave it in exactly the state that looks like success.
    """
    raw = os.getenv(NEW_KEY_ENV, "")
    if not raw:
        raise SystemExit(
            f"{NEW_KEY_ENV} is not set. Generate one with `make master-key` and "
            f"export it:\n\n    export {NEW_KEY_ENV}=\"$(make master-key)\"\n"
        )
    try:
        key = base64.b64decode(raw, validate=True)
    except Exception as exc:
        raise SystemExit(f"{NEW_KEY_ENV} is not valid base64.") from exc
    if len(key) != crypto.KEY_BYTES:
        raise SystemExit(
            f"{NEW_KEY_ENV} decodes to {len(key)} bytes; {crypto.KEY_BYTES} are required."
        )
    if key == crypto.master_key():
        raise SystemExit(
            f"{NEW_KEY_ENV} is the key already in force. Rotating to the same "
            "key would record a rotation that did not happen."
        )
    return key


def _rewrap(wrapped: bytes, tenant_id: str, old: bytes, new: bytes) -> bytes | None:
    """The rewrap, or None if this row is already under the new key.

    Uses the envelope's own primitives rather than `crypto.wrap`, which reads
    the master key from the environment — this is the one place in the system
    that legitimately holds two master keys at once.

    Detecting the already-rotated case is what makes a second run safe. An
    operator who is unsure whether the first one committed should be able to run
    it again, rather than having to find out by reading the table.
    """
    aad = crypto._wrap_aad(tenant_id)  # noqa: SLF001 — see above
    try:
        data_key = crypto._open(old, bytes(wrapped), aad)  # noqa: SLF001
    except InvalidTag:
        try:
            crypto._open(new, bytes(wrapped), aad)  # noqa: SLF001
        except InvalidTag:
            raise SystemExit(
                f"The data key for tenant {tenant_id!r} opens under neither the "
                f"current {crypto.MASTER_KEY_ENV} nor {NEW_KEY_ENV}. Stopping "
                "before writing anything: one of the two keys is wrong, and "
                "guessing which would risk sealing this row shut permanently."
            ) from None
        return None

    rewrapped = crypto._seal(new, data_key, aad)  # noqa: SLF001
    # Opened again before it is offered for writing. AES-GCM will not produce a
    # ciphertext that fails its own tag, so this is really a check that `new` is
    # the key the caller thinks it is — cheap, and the alternative to finding
    # out on the next restart.
    assert crypto._open(new, rewrapped, aad) == data_key  # noqa: S101, SLF001
    return rewrapped


def _rotate_tenant(tenant_id: str, old: bytes, new: bytes, *, apply: bool) -> bool:
    session = OwnerSessionLocal()
    try:
        row = session.get(TenantKey, tenant_id)
        if row is None:
            print(
                f"  {tenant_id}: no row in tenant_keys. Either the tenant does "
                "not exist or it was never provisioned; nothing to rotate.",
                file=sys.stderr,
            )
            return False

        rewrapped = _rewrap(row.wrapped_key, tenant_id, old, new)
        if rewrapped is None:
            print(f"  {tenant_id}: already wrapped under {NEW_KEY_ENV}. Nothing to do.")
            return True

        print(f"  {tenant_id}: rewraps so far {row.rewraps}, verified against the new key.")
        if not apply:
            print("    Dry run. Pass --apply to write.")
            return True

        row.wrapped_key = rewrapped
        row.rewraps = row.rewraps + 1
        row.rewrapped_at = datetime.now(timezone.utc)
        # Which master key wrapped a tenant's data key is a fact about that
        # tenant's evidence, and the only durable record that the rotation
        # happened at all — the row itself looks identical either way.
        session.add(
            AuditEvent(
                tenant_id=tenant_id,
                actor=ACTOR,
                action="keys.rewrap",
                subject=f"data key rewrapped under a new master key (rewrap {row.rewraps})",
            )
        )
        session.commit()
        print("    rewrapped.")
        return True
    finally:
        session.close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Rewrap tenant data keys under a new master key.")
    parser.add_argument(
        "tenants",
        nargs="*",
        help="Tenant ids. Defaults to the tenant this deployment serves (QUOLIN_TENANT).",
    )
    parser.add_argument("--apply", action="store_true", help="Write. Otherwise a dry run.")
    args = parser.parse_args(argv)

    old = crypto.master_key()
    new = _read_new_key()

    tenants = list(args.tenants) or [tenancy.configured_tenant()]

    # The platform key is always rotated, whether or not anyone named it, and it
    # is not optional. It is not a customer — it is the key every enrolled second
    # factor is sealed under — but it is wrapped by the same master key as every
    # other row in `tenant_keys`, so a rotation that skipped it would succeed,
    # report success, and leave one row still wrapped under a key the operator is
    # about to retire. The failure would surface as every user with a second
    # factor being unable to sign in, hours later, with nothing in the rotation
    # output to suggest why. Naming it here is cheap; remembering to name it on
    # the command line is not something to rely on.
    if crypto.PLATFORM_TENANT not in tenants:
        tenants.append(crypto.PLATFORM_TENANT)

    print(f"\nrotate keys {'(apply)' if args.apply else '(dry run)'}: {', '.join(tenants)}")

    ok = True
    for tenant_id in tenants:
        # Scoped per tenant: row-level security governs `tenant_keys` like every
        # other tenant table, and the audit row is stamped from the same setting.
        with tenancy.acting_as(tenant_id):
            ok = _rotate_tenant(tenant_id, old, new, apply=args.apply) and ok

    if ok and args.apply:
        print(
            f"\nNow set {crypto.MASTER_KEY_ENV} to the new value wherever this "
            "deployment reads it, and restart. Until you do, a process that "
            "starts will not be able to open any tenant's data key. "
            "docs/deployment.md has the order."
        )
    print()
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
