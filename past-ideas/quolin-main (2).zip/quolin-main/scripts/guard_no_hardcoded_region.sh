#!/usr/bin/env bash
# Stage 0: region is a variable everywhere.
#
# Sydney is the default because the first buyers are Australian. It is a
# default, not an assumption — a European customer under GDPR, or an APRA
# conversation that lands on data residency, changes one variable rather than
# grepping a Terraform tree for a region string somebody typed inline eighteen
# months earlier. The execution document asks for exactly this check.
#
# The single legitimate occurrence is the default on `variable "region"`.
#
# Two things audit G-07 found, both fixed then.
#
# **`INFRA_DIR=/tmp/does-not-exist` exited 0** with "nothing to check", while
# this file's own header — and `guard_lib.sh`, which it sources — say an absent
# target is a failure.
#
# **It scanned only `infra/`.** `ap-southeast-2` was hardcoded in three places
# outside it, and the worst was `models.py`: it was the *default for every new
# tenant row*, so a European customer created through the API was recorded as
# Sydney-resident.
#
# Two more the Gate A audit found, and they are the same two again.
#
# **`SCAN_ROOT` was never validated.** G-07's fix checked `INFRA_DIR` and left
# the second path parameter — added by the same commit, used unchecked on the
# grep line — with no check at all. `SCAN_ROOT=/tmp/nowhere` yielded no matches
# and printed a success message. Validation for every path input now comes from
# `require_scan` in `guard_lib.sh`, so there is one implementation of the rule
# rather than one per parameter.
#
# **And the scan still was not what the message said.** It read `.tf`,
# `.tfvars`, `.hcl` and `.py` under three directories, while the header above
# claimed the whole repository. Widened rather than narrowed, because the claim
# was the right one and the coverage was not: it now reads every text file in
# the tree, which turned up three region literals in `api/migrations` that no
# version of this guard had ever looked at. Those are exempted by name, with
# their reasons, rather than by exempting the directory — a migration written
# next year that hardcodes a real customer's region is exactly what this is for.
set -uo pipefail

# §S13: fail rather than pass when there is nothing to examine, and work the
# same outside a git checkout. See scripts/guard_lib.sh.
# shellcheck source=scripts/guard_lib.sh
. "$(dirname "$0")/guard_lib.sh"

INFRA_DIR="${INFRA_DIR:-infra}"
SCAN_ROOT="${SCAN_ROOT:-.}"

# Both of them, through one function. `INFRA_DIR` is checked separately from
# `SCAN_ROOT` even though the default puts the first inside the second, because
# they are independent parameters and either can be pointed somewhere empty.
require_scan "hardcoded AWS regions in the deployment" "tf tfvars hcl" "$INFRA_DIR"
infra_files="$SCANNED_FILES"
# `!md` because the grep below excludes Markdown, and a count that included
# it would let a directory of documentation read as a scanned tree.
require_scan "hardcoded AWS regions anywhere in the tree" "!md" "$SCAN_ROOT"
tree_files="$SCANNED_FILES"

# Every current AWS region prefix. Deliberately broad: the point is to catch a
# region string, not to validate that it is a real one.
REGION_PATTERN='\b(af|ap|ca|cn|eu|il|me|sa|us)-(north|south|east|west|central|northeast|northwest|southeast|southwest|gov-east|gov-west)-[0-9]\b'

# The places a region literal legitimately appears, each with its reason. Kept
# as a list of paths rather than a marker comment on each line, so that adding
# one is a visible edit to this guard rather than a comment somebody appends.
#
#   business_time.py  — a map from region to business timezone. The regions are
#                       the keys; a map about regions cannot avoid naming them.
#   new_stack.py      — a `--region` command-line default. That *is* the
#                       variable, in the tool that writes a stack's tfvars.
#   load_model.py     — synthetic tenants for a load test. Not a customer, and
#                       the model has to put something in a required column.
#   api/tests/        — fixtures. A region in a test is not a deployment fact
#                       and is read at runtime by nobody; several of these files
#                       write one deliberately, including the mutation suite
#                       that proves this guard refuses one.
#   0002_tenants.py   — the demo firm's row, created by the migration that made
#   0007_identity.py    the table. A data migration runs with no tfvars and the
#   0039_business_...   column is required, so the value has to be a literal;
#                       these three are the only migrations that write one, and
#                       a fourth is a finding rather than a precedent.
EXEMPT='api/app/business_time\.py|scripts/new_stack\.py|scripts/load_model\.py|guard_no_hardcoded_region|^\./api/tests/|/api/tests/|migrations/versions/0002_tenants\.py|migrations/versions/0007_identity\.py|migrations/versions/0039_business_timezone\.py'

# The whole tree, minus documentation and the artefacts of running it.
#
# `docs/` and `*.md` stay out for the reason the passcode guard keeps them out:
# writing down which region something was in, and why, is the change log doing
# its job, and a guard that refuses to let history be described is one people
# route around. `evidence/` and `artefacts_out/` are output, not source.
#
# shellcheck disable=SC2046 — the excludes must word-split into separate args.
hits=$(grep -rInE "$REGION_PATTERN" "$INFRA_DIR" "$SCAN_ROOT" \
         $(grep_excludes) \
         --exclude-dir=docs \
         --exclude-dir=evidence \
         --exclude-dir=artefacts_out \
         --exclude='*.md' \
         --exclude="$(basename "$0")" \
         2>/dev/null \
       | grep -v 'variables\.tf:.*default *= *"ap-southeast-2"' \
       | grep -vE ':[0-9]+: *(#|//|\*)' \
       | grep -vE "$EXEMPT" \
       | sed 's|^\./||' \
       | sort -u \
       || true)

if [ -n "$hits" ]; then
  echo "$hits"
  echo
  echo "FAIL: a region is hardcoded."
  echo "Region is var.region. The only place a region literal belongs is the"
  echo "default on that variable — everything else reads it, including the"
  echo "dedicated single-tenant stacks Stage 11 deploys from this same module."
  echo
  echo "If one of these is legitimate, add it to EXEMPT in this file with its"
  echo "reason. An exemption is a visible edit to the guard; a comment on the"
  echo "line is not."
  exit 1
fi

echo "OK: no hardcoded region in $tree_files file(s) under $SCAN_ROOT"
echo "    (including $infra_files Terraform file(s) under $INFRA_DIR), outside"
echo "    documentation and the exemptions this guard names — region is"
echo "    var.region in the deployment and a required column on the tenant row."
