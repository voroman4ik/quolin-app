"""
§S12's numbers, measured end to end against twenty firms at once.

    interactive evaluations   p99 < 500ms end-to-end
    dashboard interactive     p99 < 1s
    PDF                       p99 < 5s
    bulk runs not starving interactive traffic

The four are measured differently on purpose, because they fail differently.

**End to end means over HTTP.** `tests/test_benchmarks.py` already measures the
evaluator as a function and holds it to 50ms; that number stays true while the
endpoint around it does something quadratic. Everything here goes through the
same door a browser uses — middleware, row-level security, session lookup,
serialisation — because that is what 500ms is a budget for.

**Twenty firms, concurrently, each as its own signed-in person.** One tenant
driven twenty times measures one tenant's working set. Twenty tenants means
twenty sets of policies evaluated, twenty chains, and a cache that cannot hold
all of it — which is the state a shared deployment is actually in.

**p99, not the mean.** A determination happens while somebody waits. A mean of
40ms with a p99 of 3s is a system that feels broken to one user in a hundred,
and the mean reports it as healthy.

**Starvation is measured as a comparison, not as an absolute.** "Interactive p99
under load" is a number with no meaning on its own — it depends on the machine.
What means something is interactive p99 *with a bulk sweep running* against the
same figure without one, on the same machine, minutes apart. The threshold is a
ratio, and the ratio is what a customer experiences as "the system goes away
when somebody runs a report".

Usage:

    make load-test                       # against a local API and load model
    make load-test ARGS="--seconds 60 --workers 20"
    make load-test ARGS=--json

Exit codes: 0 when every budget is met, 1 when the test could not run, 2 when a
budget was missed.
"""

from __future__ import annotations

import argparse
import http.client
import json
import os
import statistics
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]

#: §S12's budgets, in milliseconds. Stated here rather than in the assertions so
#: that a change to one is a change to a named constant somebody has to justify.
BUDGET_MS = {
    "evaluate": 500.0,
    "dashboard": 1000.0,
    "pdf": 5000.0,
}

#: How much slower interactive traffic may get while a bulk sweep runs. Not 1.0:
#: a sweep is real work on the same database and some contention is honest.
#: Beyond this it is not contention, it is starvation — the queue in front of
#: the person waiting is somebody else's batch.
STARVATION_RATIO = 2.0

PREFIX = "load-"

#: How many times one request will rebuild its connection before giving up.
#: Three, which covers a closed keep-alive and a moment of backlog and does not
#: cover a server that has stopped answering.
RECONNECT_ATTEMPTS = 3
PASSWORD = os.getenv("QUOLIN_LOAD_PASSWORD", "load model not a real one")
TIMEOUT_SECONDS = 60.0


class Unreachable(Exception):
    pass


@dataclass
class Samples:
    name: str
    millis: list[float] = field(default_factory=list)
    errors: int = 0
    lock: threading.Lock = field(default_factory=threading.Lock)

    def record(self, ms: float, ok: bool) -> None:
        with self.lock:
            if ok:
                self.millis.append(ms)
            else:
                self.errors += 1

    def percentile(self, p: float) -> float:
        if not self.millis:
            return float("nan")
        ordered = sorted(self.millis)
        index = min(len(ordered) - 1, int(round(p / 100 * len(ordered) + 0.5)) - 1)
        return ordered[max(0, index)]

    def summary(self) -> dict:
        return {
            "name": self.name,
            "count": len(self.millis),
            "errors": self.errors,
            "p50": round(self.percentile(50), 1),
            "p95": round(self.percentile(95), 1),
            "p99": round(self.percentile(99), 1),
            "max": round(max(self.millis), 1) if self.millis else None,
            "mean": round(statistics.mean(self.millis), 1) if self.millis else None,
        }


class Session:
    """One signed-in person at one firm, on one kept-alive connection.

    Deliberately `http.client` rather than `urllib`. urllib opens a new TCP
    connection per request and closes it, which does two things to a load test:
    it puts a connection setup inside every latency sample, and at a few hundred
    requests a second it exhausts the machine's ephemeral ports and the *client*
    starts failing. The first version of this file did exactly that and reported
    `[Errno 49] Can't assign requested address` — a number about macOS, filed
    under the API's name.

    A browser keeps its connection. So does this.
    """

    def __init__(self, base: str, email: str) -> None:
        parsed = urllib.parse.urlparse(base)
        self.host = parsed.hostname or "localhost"
        self.port = parsed.port or (443 if parsed.scheme == "https" else 80)
        self.https = parsed.scheme == "https"
        # Q-05: an unsafe method that does not say where it came from is refused
        # before anything happens. This harness holds a session cookie like a
        # browser does, so it identifies itself like one — with the origin it
        # was pointed at, which the middleware accepts as its own.
        self.origin = f"{parsed.scheme}://{parsed.netloc}"
        self.email = email
        self.cookies: dict[str, str] = {}
        self.clients: list[str] = []
        self._local = threading.local()

    @property
    def conn(self):
        """One connection per calling thread.

        A single connection shared by twenty threads would serialise them on the
        wire and measure a queue this application does not have.
        """
        existing = getattr(self._local, "conn", None)
        if existing is None:
            existing = (
                http.client.HTTPSConnection(self.host, self.port, timeout=TIMEOUT_SECONDS)
                if self.https
                else http.client.HTTPConnection(self.host, self.port, timeout=TIMEOUT_SECONDS)
            )
            self._local.conn = existing
        return existing

    def _drop(self) -> None:
        conn = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None

    def _once(self, method: str, path: str, data: bytes | None, headers: dict):
        started = time.perf_counter()
        self.conn.request(method, path, body=data, headers=headers)
        response = self.conn.getresponse()
        payload = response.read()
        ms = (time.perf_counter() - started) * 1000
        for header in response.headers.get_all("Set-Cookie") or []:
            name, _, rest = header.partition("=")
            self.cookies[name.strip()] = rest.split(";", 1)[0]
        if "application/json" in (response.headers.get("content-type") or ""):
            return ms, response.status, json.loads(payload or b"null")
        return ms, response.status, payload

    def call(self, method: str, path: str, body: dict | None = None):
        """One request, retried through a dropped keep-alive.

        A server closes idle keep-alive connections; uvicorn does it after five
        seconds. Under contention a thread's connection can sit idle past that
        and the next request arrives at a socket the server has already closed,
        which surfaces as `Remote end closed connection without response`. A
        browser reconnects and carries on, and so does this.

        The first version of this file aborted the entire run on one of those,
        which threw away a thirty-second measurement because of a five-second
        timeout. The opposite mistake would be worse: retrying forever turns a
        server that has fallen over into a slow but successful run. So it is a
        small fixed number of attempts, and a request that still fails is
        reported by the caller as an error rather than swallowed.
        """
        data = json.dumps(body).encode() if body is not None else None
        headers = {"Connection": "keep-alive", "Origin": self.origin}
        if data is not None:
            headers["Content-Type"] = "application/json"
        if self.cookies:
            headers["Cookie"] = "; ".join(f"{k}={v}" for k, v in self.cookies.items())

        last: Exception | None = None
        for attempt in range(RECONNECT_ATTEMPTS):
            try:
                return self._once(method, path, data, headers)
            except (http.client.HTTPException, OSError, TimeoutError) as exc:
                last = exc
                self._drop()
                if attempt + 1 < RECONNECT_ATTEMPTS:
                    time.sleep(0.05 * (attempt + 1))
        raise Unreachable(f"{method} {path}: {last}")

    def sign_in(self) -> None:
        _, status, _ = self.call(
            "POST", "/auth/login", {"email": self.email, "password": PASSWORD}
        )
        if status != 200:
            raise Unreachable(
                f"{self.email} could not sign in (HTTP {status}). Has the load "
                "model been generated? `make load-model`."
            )

    def load_clients(self, limit: int) -> None:
        _, status, body = self.call("GET", "/clients")
        if status != 200 or not isinstance(body, list):
            raise Unreachable(f"{self.email}: GET /clients returned {status}")
        self.clients = [c["id"] for c in body][:limit]
        if not self.clients:
            raise Unreachable(f"{self.email} has no clients — is the model built?")


def sessions_for(base: str, tenants: int, clients_each: int) -> list[Session]:
    out = []
    for n in range(1, tenants + 1):
        session = Session(base, f"operator@{PREFIX}{n:02d}.quolin.example")
        session.sign_in()
        session.load_clients(clients_each)
        out.append(session)
    return out


def _one_request(session: Session, client: str, choice: int, samples: dict) -> None:
    """One unit of the mix: four determinations, one dashboard, one document."""
    if choice < 4:
        ms, status, _ = session.call(
            "POST", "/evaluate", {"client_id": client, "asset_id": "BTC"}
        )
        samples["evaluate"].record(ms, status == 200)
    elif choice == 4:
        ms, status, _ = session.call("GET", "/dashboard")
        samples["dashboard"].record(ms, status == 200)
    else:
        # A document is three calls, and the budget covers all three: the
        # determination it is about, the render, and the download. §S12's "PDF
        # < 5s" is what somebody experiences between pressing Generate and
        # holding a file, not the render in isolation.
        ms, status, body = session.call(
            "POST", "/evaluate", {"client_id": client, "asset_id": "ETH"}
        )
        if status != 200 or not isinstance(body, dict):
            samples["pdf"].record(ms, False)
            return
        ms, status, artefact = session.call(
            "POST", "/artefacts/tmd", {"decision_id": body["id"]}
        )
        total = ms
        if status == 200 and isinstance(artefact, dict):
            ms, status, _ = session.call("GET", artefact["download_url"])
            total += ms
        samples["pdf"].record(total, status == 200)


def drive(
    sessions: list[Session],
    samples: dict[str, Samples],
    *,
    seconds: float,
    workers: int,
    stop: threading.Event,
) -> None:
    """Every worker picks a firm, does one of the three things, records it."""
    deadline = time.monotonic() + seconds

    def one(worker: int) -> None:
        rotation = worker
        while time.monotonic() < deadline and not stop.is_set():
            session = sessions[rotation % len(sessions)]
            rotation += 1
            client = session.clients[rotation % len(session.clients)]
            choice = rotation % 6
            which = "evaluate" if choice < 4 else ("dashboard" if choice == 4 else "pdf")
            try:
                _one_request(session, client, choice, samples)
            except Unreachable:
                # Counted, not fatal. A request the client could not complete
                # even after reconnecting is a real failure and belongs in the
                # report — but one of them must not destroy a thirty-second
                # measurement. Errors are a budget of their own below.
                samples[which].record(0.0, False)

    with ThreadPoolExecutor(max_workers=workers) as pool:
        list(pool.map(one, range(workers)))


def fresh() -> dict[str, Samples]:
    return {name: Samples(name) for name in ("evaluate", "dashboard", "pdf")}


def main() -> int:
    parser = argparse.ArgumentParser(description="§S12's load test.")
    parser.add_argument("--base-url", default="http://localhost:8000")
    parser.add_argument("--seconds", type=float, default=30.0)
    parser.add_argument("--workers", type=int, default=20)
    parser.add_argument("--tenants", type=int, default=20)
    parser.add_argument("--clients", type=int, default=40, help="per firm, sampled")
    parser.add_argument(
        "--bulk-workers", type=int, default=2, help="workers draining the sweep"
    )
    parser.add_argument(
        "--no-contention",
        action="store_true",
        help="skip the bulk-versus-interactive comparison",
    )
    parser.add_argument("--json", action="store_true")
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    try:
        sessions = sessions_for(args.base_url, args.tenants, args.clients)
    except Unreachable as exc:
        print(f"the load test could not start: {exc}", file=sys.stderr)
        return 1

    stop = threading.Event()

    # --- baseline -----------------------------------------------------------
    quiet = fresh()
    try:
        drive(sessions, quiet, seconds=args.seconds, workers=args.workers, stop=stop)
    except Unreachable as exc:
        print(f"the deployment went away mid-test: {exc}", file=sys.stderr)
        return 1

    report: dict[str, object] = {
        "base_url": args.base_url,
        "tenants": args.tenants,
        "workers": args.workers,
        "seconds": args.seconds,
        "quiet": {name: s.summary() for name, s in quiet.items()},
        "budgets_ms": BUDGET_MS,
    }

    failures: list[str] = []
    for name, budget in BUDGET_MS.items():
        got = quiet[name].percentile(99)
        if not quiet[name].millis:
            failures.append(f"{name}: nothing was measured")
        elif got > budget:
            failures.append(f"{name}: p99 {got:.0f}ms over the {budget:.0f}ms budget")
        if quiet[name].errors:
            failures.append(f"{name}: {quiet[name].errors} request(s) failed")

    # --- the same traffic, with a sweep running underneath it ---------------
    if not args.no_contention:
        busy = fresh()

        # A run per firm, planned through the API so the pairs are real, then
        # real workers draining them. Planning alone would prove nothing: `POST
        # /runs` enumerates pairs and returns, and the minutes of work that
        # actually contend for the database are the worker's.
        # The runs this invocation planned, by id. Not a before-and-after sum
        # over `GET /runs`: that returns the hundred most recent, so on a
        # database where the test has been run a few times the window slides
        # and the difference is meaningless. The first version of this also read
        # the response as a list when it is an object with a `runs` key, so it
        # measured zero every time — and reported a contention ratio anyway.
        # Every run a worker could claim from during this window: the ones
        # already open on this database, plus the ones planned here.
        #
        # Not just the ones planned here — that was the second version, and it
        # reported zero while the machine was visibly under load, because
        # `bulk.drain` claims the oldest chunk anywhere and a database that has
        # run this test before has older runs still open. And not a
        # before-and-after sum over `GET /runs` either, which was the first
        # version: that returns the hundred most recent, so twenty new runs push
        # twenty old ones out of view and the difference measures the window
        # moving. A fixed set of ids, resolved once.
        watched: list[tuple[Session, int]] = []
        for session in sessions:
            _, status, listing = session.call("GET", "/runs")
            if status == 200 and isinstance(listing, dict):
                watched.extend(
                    (session, int(run["id"]))
                    for run in listing.get("runs", [])
                    if run.get("status") in ("planned", "running")
                )

        planned = 0
        for session in sessions:
            _, status, run = session.call(
                "POST", "/runs", {"trigger": "manual", "note": "load test"}
            )
            if status == 202 and isinstance(run, dict) and run.get("id"):
                watched.append((session, int(run["id"])))
                planned += 1

        def pairs_done() -> int:
            """Pairs completed across the runs a worker could have claimed from."""
            total = 0
            for session, run_id in watched:
                _, status, run = session.call("GET", f"/runs/{run_id}")
                if status == 200 and isinstance(run, dict):
                    total += int(run.get("pairs_done") or 0)
            return total

        before_pairs = pairs_done()
        if not planned:
            print(
                "no bulk run could be planned, so contention was never applied. "
                "Reporting that rather than a comparison against nothing.",
                file=sys.stderr,
            )
            return 1

        workers = [
            subprocess.Popen(  # noqa: S603 — a fixed command, no shell
                [sys.executable, "-m", "scripts.bulk_worker", "--limit", "100000"],
                cwd=str(_REPO),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=os.environ.copy(),
            )
            for _ in range(args.bulk_workers)
        ]
        try:
            drive(sessions, busy, seconds=args.seconds, workers=args.workers, stop=stop)
        except Unreachable as exc:
            print(f"the deployment went away under contention: {exc}", file=sys.stderr)
            return 1
        finally:
            for worker in workers:
                worker.terminate()
            for worker in workers:
                worker.wait(timeout=30)

        # How much bulk work actually happened. Without this the contention
        # figure is a comparison against nothing: workers that started, found
        # no claimable chunk and idled would produce a flattering ratio and an
        # entirely truthful-looking report.
        worked = pairs_done() - before_pairs

        still_working = [w for w in workers if w.returncode not in (0, -15)]
        report["bulk"] = {
            "runs_planned": planned,
            "runs_watched": len(watched),
            "workers": args.bulk_workers,
            "pairs_completed_during_the_window": worked,
            "worker_exits": [w.returncode for w in workers],
        }
        if worked <= 0:
            failures.append(
                "no bulk pairs were completed while interactive traffic ran, so "
                "the contention figure below compares against no contention at all"
            )
        if still_working:
            failures.append(
                f"{len(still_working)} bulk worker(s) exited unexpectedly, so the "
                "contention figure below was measured against less load than intended"
            )

        report["under_bulk"] = {name: s.summary() for name, s in busy.items()}

        quiet_p99 = quiet["evaluate"].percentile(99)
        busy_p99 = busy["evaluate"].percentile(99)
        ratio = busy_p99 / quiet_p99 if quiet_p99 else float("inf")
        report["starvation"] = {
            "quiet_p99_ms": round(quiet_p99, 1),
            "under_bulk_p99_ms": round(busy_p99, 1),
            "ratio": round(ratio, 2),
            "limit": STARVATION_RATIO,
        }
        if ratio > STARVATION_RATIO:
            failures.append(
                f"bulk starves interactive: evaluate p99 went from "
                f"{quiet_p99:.0f}ms to {busy_p99:.0f}ms ({ratio:.1f}x, "
                f"limit {STARVATION_RATIO}x)"
            )
        for name in BUDGET_MS:
            if busy[name].errors:
                failures.append(
                    f"{name}: {busy[name].errors} request(s) failed while a "
                    "sweep ran — a sweep must not take the API away"
                )
        if busy["evaluate"].percentile(99) > BUDGET_MS["evaluate"]:
            failures.append(
                f"evaluate breaks its budget while a sweep runs: "
                f"p99 {busy_p99:.0f}ms over {BUDGET_MS['evaluate']:.0f}ms"
            )

    report["failures"] = failures

    if args.json:
        print(json.dumps(report, indent=2))
    else:
        print(f"load test — {args.tenants} firms, {args.workers} workers, {args.seconds:.0f}s each")
        for label, key in (("quiet", "quiet"), ("under bulk", "under_bulk")):
            block = report.get(key)
            if not block:
                continue
            print(f"  {label}:")
            for name, s in block.items():  # type: ignore[union-attr]
                budget = BUDGET_MS[name]
                mark = "ok " if s["p99"] <= budget else "OVER"
                print(
                    f"    [{mark}] {name:<10} n={s['count']:<5} "
                    f"p50 {s['p50']:>7.1f}  p95 {s['p95']:>7.1f}  "
                    f"p99 {s['p99']:>7.1f}  (budget {budget:.0f}ms)"
                    + (f"  errors={s['errors']}" if s["errors"] else "")
                )
        if "bulk" in report:
            b = report["bulk"]  # type: ignore[assignment]
            print(
                f"  bulk: {b['runs_planned']} planned of {b['runs_watched']} open, "  # type: ignore[index]
                f"{b['workers']} worker(s), "  # type: ignore[index]
                f"{b['pairs_completed_during_the_window']} pair(s) completed under load"  # type: ignore[index]
            )
        if "starvation" in report:
            s = report["starvation"]  # type: ignore[assignment]
            print(
                f"  contention: evaluate p99 {s['quiet_p99_ms']}ms → "  # type: ignore[index]
                f"{s['under_bulk_p99_ms']}ms ({s['ratio']}x, limit {s['limit']}x)"  # type: ignore[index]
            )
        print()
        for failure in failures:
            print(f"  FAIL {failure}")
        if not failures:
            print("  every §S12 budget met")

    return 2 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
