"""
Send the webhook deliveries that are due, and report what happened.

The other half of `app/webhooks.py`. Nothing in a request path opens a socket —
a determination must not fail or wait because a customer's case system is slow —
so enqueueing and sending are separate, and this is the sending.

    make deliver-webhooks                  # the deployment's own tenant
    make deliver-webhooks ARGS="--json"
    make deliver-webhooks ARGS="acme beta"
    make deliver-webhooks ARGS="--dry-run" # what would be sent, sending nothing

Run it on a short cycle — a minute is right. The backoff in `webhooks.py` is
what spaces out retries; this only asks "is anything due".

**Exit codes.** 0 when everything due was attempted, 1 when a delivery
dead-lettered on this run, 2 when the run could not complete. A dead letter is
an exit code rather than a log line because it is the one outcome somebody has
to act on: a customer's endpoint has been failing for half an hour and they are
not being told things they think they are being told.

**Tenants are named, not discovered**, the same constraint `rechain.py` and
`access_review.py` carry: under FORCE ROW LEVEL SECURITY a query for "all
tenants" returns the one in scope, so a discovery mode would work in development
and silently deliver nothing in production.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from app import maintenance, tenancy, webhooks  # noqa: E402
from app.db import OwnerSessionLocal, SessionLocal  # noqa: E402



def _every_active_firm() -> list[str]:
    """Every active customer, when no tenant was named.

    `tenancy.configured_tenant()` was the default, and on a shared deployment
    that is one firm out of however many — so this job ran, reported success,
    and served nobody else. Q-01's shape exactly: an enumeration that returns
    one thing and a caller that reads it as everything.

    The docstring above once said tenants are named and not discovered, "because
    under FORCE ROW LEVEL SECURITY a query for all tenants returns the one in
    scope". That was true and stopped being true at migration 0029, which
    created the `quolin_maintenance` grant precisely so a scheduled worker can
    ask. `scripts/artefact_worker.py` and `scripts/bulk_worker.py` have
    enumerated this way since; this is the same call, with the preflight
    `scripts/health_alerts.py` has and they do not.

    `assert_can_enumerate` first, because the failure mode without it is the one
    F12 named: a connection that cannot see `tenants` returns an empty list, the
    loop runs zero times, and the job exits 0 having done nothing.
    """
    session = OwnerSessionLocal()
    try:
        maintenance.assert_can_enumerate(session)
        return maintenance.active_tenant_ids(session)
    finally:
        session.close()

def main() -> int:
    parser = argparse.ArgumentParser(description="Deliver due webhooks.")
    parser.add_argument("tenants", nargs="*", help="Tenant ids. Defaults to the configured one.")
    parser.add_argument("--json", action="store_true", help="Machine-readable output.")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Report what is due without sending it or recording an attempt.",
    )
    args = parser.parse_args()

    tenants = args.tenants or _every_active_firm()
    reports = []

    for tenant_id in tenants:
        # One session per tenant. `app.tenant_id` binds when a transaction
        # begins, so a session reused across the loop would deliver the first
        # tenant's queue under every subsequent heading — the trap
        # `app/access_review.py` documents at length, and the one that printed
        # one firm's staff under another firm's name before it was found.
        with tenancy.acting_as(tenant_id):
            session = SessionLocal()
            try:
                if args.dry_run:
                    would_send: list = []
                    pending = webhooks.due(session)
                    tally = {"attempted": 0, "delivered": 0, "dead": 0, "retrying": 0}
                    for delivery in pending:
                        would_send.append(
                            {"event": delivery.event, "subject": delivery.subject}
                        )
                    session.rollback()
                    reports.append(
                        {"tenant_id": tenant_id, "due": would_send, **tally}
                    )
                else:
                    tally = webhooks.run_once(session)
                    reports.append({"tenant_id": tenant_id, **tally})
            except Exception as exc:
                print(
                    f"webhook delivery failed for {tenant_id}: "
                    f"{type(exc).__name__}: {exc}",
                    file=sys.stderr,
                )
                return 2
            finally:
                session.close()

    if args.json:
        print(json.dumps(reports, indent=2))
    else:
        for report in reports:
            if args.dry_run:
                print(f"\ntenant {report['tenant_id']}: {len(report['due'])} due")
                for item in report["due"]:
                    print(f"  {item['event']:24} {item['subject']}")
                continue
            print(
                f"\ntenant {report['tenant_id']}: "
                f"{report['attempted']} attempted, "
                f"{report['delivered']} delivered, "
                f"{report['retrying']} retrying, "
                f"{report['dead']} dead"
            )
            if report["dead"]:
                print(
                    "  A delivery has been dead-lettered. The endpoint has been "
                    "failing for around half an hour, and the customer is not "
                    "receiving things they believe they are receiving."
                )

    dead = sum(r.get("dead", 0) for r in reports)
    return 1 if dead else 0


if __name__ == "__main__":
    raise SystemExit(main())
