#!/usr/bin/env bash
# Phase 4 invariant: no watch path reaches the evaluator.
#
# The watch service reads gazettes and proposes changes. If any of it could be
# reached from a determination, the system would stop being a compliance tool
# and become an unreviewed robot writing regulation — and the honest parts of it
# would lose their credit along with that one.
#
# Two directions, both checked:
#   1. api/app/engine must not import api/app/watch, or any of its modules.
#   2. api/app/watch must not import the evaluator's entry points. Reading the
#      Pack *type* would be defensible; calling `evaluate` from a watch path is
#      the thing this guard exists to stop.
#
# Stage 6 adds a fourth and fifth check, and they are about the deployment
# rather than the source. §S6 asks for the separation to stop being a property
# of our code and become a property of what runs: the watch task connects as a
# role that cannot write a pack, and holds no encryption key at all. Both are
# one careless Terraform edit from being untrue, and neither would fail a test.
set -uo pipefail

# §S13: fail rather than pass when there is nothing to examine, and work the
# same outside a git checkout. See scripts/guard_lib.sh.
# shellcheck source=scripts/guard_lib.sh
. "$(dirname "$0")/guard_lib.sh"


ENGINE_DIR="${ENGINE_DIR:-api/app/engine}"
WATCH_DIR="${WATCH_DIR:-api/app/watch}"
SCAN_ROOT="${SCAN_ROOT:-.}"
fail=0

# Every path this guard reads, and the file counts behind its verdict. It has
# always validated the two it names; `api` and `scripts` were passed to
# `repo_grep` below and checked only for existence, and the whole-tree sweep in
# check 4 had no path parameter at all until the Gate A audit gave it one.
require_scan "the evaluator/watch boundary" "py" "$ENGINE_DIR" "$WATCH_DIR"
require_scan "model clients outside the watch service" "py ts tsx js" \
  "$SCAN_ROOT/api" "$SCAN_ROOT/scripts" "$SCAN_ROOT/web"

# 1. Engine -> watch, in any import spelling.
if grep -rInE "^[[:space:]]*(from|import)[[:space:]].*\bwatch\b" "$ENGINE_DIR"; then
  echo
  echo "FAIL: $ENGINE_DIR imports the watch service."
  echo "A determination must not be reachable from a gazette reader."
  fail=1
fi

# 2. Watch -> evaluator entry points.
if grep -rInE "^[[:space:]]*(from|import)[[:space:]].*\b(engine|service)\b" "$WATCH_DIR"; then
  echo
  echo "FAIL: $WATCH_DIR imports the engine or the service layer."
  echo "Watch code proposes content; it never evaluates."
  fail=1
fi

# 3. The signature gate is a single condition in a single place. If `publish`
#    grows a second way in, or someone writes to the packs table from another
#    watch module, this catches it.
writers=$(grep -rInE "PackRow\(|Pack\(" "$WATCH_DIR" | grep -v "drafts.py" || true)
if [ -n "$writers" ]; then
  echo "$writers"
  echo
  echo "FAIL: a watch module other than drafts.py constructs a pack row."
  echo "Publication goes through watch/drafts.py::publish, which checks the signature."
  fail=1
fi

# 4. A model client is imported in exactly one file.
#
#    §S6: summarisation and classification run inside watch only. The credential
#    is the real boundary — core-api is given none — but a model call written
#    into a request path would be a model in the determination path waiting for
#    somebody to set an environment variable, and that is not a thing to leave
#    lying about. See docs/llm-boundary.md.
model_clients=$(repo_grep "^[[:space:]]*(import|from)[[:space:]]+anthropic" \
  api web scripts \
  -- \
  api/app/watch/assist.py \
  api/tests/test_llm_boundary.py)
if [ -n "$model_clients" ]; then
  echo "$model_clients"
  echo
  echo "FAIL: a model client is imported outside api/app/watch/assist.py."
  echo "Summarisation and classification run inside the watch service only."
  fail=1
fi

# 5 and the ECS half of 6 have moved to `scripts/guard_task_credentials.sh`.
#
#    Both were `awk` over `infra/compute.tf` scoped to a literal resource name,
#    and audit G-02 found what that costs: renaming
#    `aws_ecs_task_definition "watch"` made the range empty, and an empty range
#    is a pass. The health and comparison tasks matched no range at all and were
#    therefore checked by nothing, while each holds the owner connection and the
#    master key.
#
#    Worse, both were deny-lists — they refused the specific credentials
#    somebody had already thought of. `DATABASE_URL` in the *API* task was on
#    nobody's list, which is why it survived thirteen stages and two fix-packs
#    until FP3-04.
#
#    The replacement parses every task definition, keys an allow-list on each
#    container's command rather than on its resource name, and fails on any
#    variable that is not authorised for that job. Mutation cases in
#    `api/tests/test_guard_mutations.py` include the rename, the model
#    credential in each of the previously unchecked tasks, and the owner
#    connection returning to the API.
#
# 6. The watch task connects as the watch role, and only as the watch role.
#    `database_url` is the schema owner and `app_database_url` is the role that
#    serves requests; either one in this task definition would hand a gazette
#    reader the ability to write rule content, which is the thing migration 0014
#    exists to withhold.
#
#    Kept here as well as in the credential guard, deliberately. This is the
#    §S6 statement in the file that carries the rest of the watch separation,
#    and a reader auditing that boundary should find it here rather than being
#    sent somewhere else for the last third of it.
WATCH_TASK=$(awk '/resource "aws_ecs_task_definition" "watch"/,/^}/' infra/compute.tf)
if [ -z "$WATCH_TASK" ]; then
  echo "FAIL: no watch task definition in infra/compute.tf."
  echo "§S6 requires the watch service to be deployed separately."
  fail=1
else
  if ! echo "$WATCH_TASK" | grep -q "watch_database_url"; then
    echo "FAIL: the watch task does not use watch_database_url."
    fail=1
  fi
  if echo "$WATCH_TASK" | grep -qE ":(database_url|app_database_url)::"; then
    echo "$WATCH_TASK" | grep -nE ":(database_url|app_database_url)::"
    echo
    echo "FAIL: the watch task holds a connection string that can write packs."
    echo "The only publish path is the signature endpoint in core-api."
    fail=1
  fi

  # 7. No encryption key in the watch environment. The sweep touches no
  #    encrypted column — not a client name, not a decision snapshot, not a
  #    webhook secret — so a compromised watch task holding the master key would
  #    be handing away everything it has no need of.
  if echo "$WATCH_TASK" | grep -qE "master_key|QUOLIN_MASTER_KEY|tenant_data"; then
    echo "$WATCH_TASK" | grep -nE "master_key|QUOLIN_MASTER_KEY|tenant_data"
    echo
    echo "FAIL: the watch task is given an encryption key."
    echo "It reads publications and writes drafts. It decrypts nothing."
    fail=1
  fi
fi

if [ "$fail" -ne 0 ]; then
  exit 1
fi

echo "OK: $ENGINE_DIR does not import $WATCH_DIR, $WATCH_DIR does not evaluate,"
echo "    the watch task connects as a role that cannot write a pack, and no"
echo "    model client or credential exists outside the watch service."
