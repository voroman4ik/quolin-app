#!/usr/bin/env bash
# Definition of done §11: no jurisdiction logic in engine code.
# Jurisdiction names, pack identifiers and rule ids belong in /packs.
# Prose mentioning "jurisdiction" is fine; branching on it is not.
#
# The list of codes below is the list of jurisdictions the system carries
# content for. Adding a pack means adding its code here: a guard that only
# knows about the first jurisdiction stops being a guard the moment there is
# a second one.
#
# FP3-02 note, added after audit G-05: **the regexes below are no longer the
# enforcement.** Reproduced individually on this tree, three of the six cases
# the audit listed passed them — `pack_id.startswith("hk")`, `pack_id in ("au",
# "sg")` and `'A' + 'U'`. The other three were caught, so half of this worked;
# what did not is the half that assumed a regime code would be written the way
# the pack files write it.
#
# `scripts/engine_jurisdictions.py` runs at the end of this file and decides.
# It parses the engine and refuses any two-letter string constant in any case,
# and separately looks for every code declared in `packs/` — so a fifth pack
# extends the guard by existing rather than by somebody remembering to add it
# here.
set -uo pipefail

# §S13: fail rather than pass when there is nothing to examine, and work the
# same outside a git checkout. See scripts/guard_lib.sh.
# shellcheck source=scripts/guard_lib.sh
. "$(dirname "$0")/guard_lib.sh"

ENGINE_DIR="${ENGINE_DIR:-api/app/engine}"

# The variable that is scanned rather than a literal beside it — see the same
# note in `guard_engine_is_pure.sh`.
require_scan "jurisdiction logic in the evaluator" "py" "$ENGINE_DIR"

CODES="AU|HK|SG|EU"
Q="[\"']"

PATTERN="\
\bif\b.*\bjurisdiction\b\
|\bjurisdiction[[:space:]]*==\
|\bpack_id[[:space:]]*==\
|${Q}(${CODES})${Q}\
|\b(${CODES})-[A-Z]+-[0-9]+"

if grep -rInE "$PATTERN" "$ENGINE_DIR"; then
  echo
  echo "FAIL: jurisdiction-specific logic found in $ENGINE_DIR."
  echo "That belongs in a pack under /packs, not in engine code."
  exit 1
fi

echo "OK: $ENGINE_DIR contains no jurisdiction-specific logic ($CODES)."

# The enforcement. Everything above is a pre-check.
_HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$_HERE/../api" || exit 1
exec uv run python "$_HERE/engine_jurisdictions.py" "$@"
