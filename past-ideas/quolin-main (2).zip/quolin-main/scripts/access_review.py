"""
Emit the quarterly access-review report.

The SOC 2 control is not "access is correct". It is *the report was generated,
read, and signed off*, on a cadence, with the decisions recorded. So the thing
this script optimises is the cost of producing one: a single command, no
arguments needed, output that is already the document rather than the raw
material for one.

    make access-review                          # the deployment's own tenant
    make access-review ARGS="--json"            # for an evidence archive
    make access-review ARGS="acme beta"         # several, one report
    make access-review ARGS="--inactive-days 30"

Written to a file when you pass `--out`, which is what the quarterly run does —
the report is evidence, and evidence that only ever existed in a terminal
scrollback is evidence nobody can produce a year later.

**Tenants are named, not discovered**, the same constraint `scripts/rechain.py`
carries and for the same reason: under `FORCE ROW LEVEL SECURITY` a query for
"every tenant" returns the one in scope, so a discovery mode would work in
development and silently review nothing in production.

**It connects as the application role, not the owner.** Every other script here
takes the owner because it has to write something the application may not. This
one reads, and reading as the application means the report contains exactly what
the product's own policies allow a tenant's review to contain — which is the
property that makes it worth anything as evidence. A report assembled by a
connection that bypassed row-level security would prove nothing about row-level
security.

**It changes nothing.** No grant is revoked and no account suspended. Removing
somebody's access is a decision with a name against it, and this is not where
that decision gets made.

Exit codes: 0 when a report was produced, 1 when it could not be. Deliberately
*not* 1 for findings — a review that failed a build is a review people learn to
make empty, and every finding here is a question rather than a defect.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# Same dual-layout dance as scripts/watch_tick.py: `api/` in the repo, flattened
# to the working directory inside the container.
_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from scripts import evidence_io  # noqa: E402

from app import access_review, tenancy  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Emit the quarterly access-review report.")
    parser.add_argument(
        "tenants",
        nargs="*",
        help="Tenant ids to review. Defaults to the deployment's configured tenant.",
    )
    parser.add_argument(
        "--inactive-days",
        type=int,
        default=access_review.DEFAULT_INACTIVE_DAYS,
        help="How long without an action makes a grant worth asking about.",
    )
    parser.add_argument("--json", action="store_true", help="Machine-readable output.")
    parser.add_argument("--out", type=Path, help="Write to this file instead of stdout.")
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    tenants = args.tenants or [tenancy.configured_tenant()]

    # One session per tenant, which `collect_all` is responsible for. Doing it
    # here instead is how the first version of this script printed the demo
    # firm's staff under the neighbour's heading — see that function's note.
    reviews = access_review.collect_all(tenants, inactive_days=args.inactive_days)

    if args.json:
        body = json.dumps([access_review.to_dict(r) for r in reviews], indent=2) + "\n"
    else:
        body = access_review.render(reviews)

    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(body)
        total = sum(len(r.findings) for r in reviews)
        # To stderr, so that `--out` with a redirect still produces a clean file
        # and the operator still sees whether there is anything to read.
        print(
            f"wrote {args.out} — {len(reviews)} tenant(s), {total} finding(s)",
            file=sys.stderr,
        )
    else:
        print(body, end="")

    total = sum(len(r.findings) for r in reviews)
    if args.evidence_out:
        evidence_io.write(
            "access-reviews",
            "access-review",
            {
                "tenants": [r.tenant_id for r in reviews],
                "findings": {
                    r.tenant_id: [
                        {
                            "kind": f.kind,
                            "severity": f.severity,
                            "subject": f.subject,
                            "detail": f.detail,
                        }
                        for f in r.findings
                    ]
                    for r in reviews
                },
                "inactive_days": args.inactive_days,
            },
            # Deliberately not a pass/fail. Every finding here is a question for
            # a person — "this account has gone quiet" is not a defect — and an
            # artefact that graded them would turn the review into a build step
            # somebody makes empty.
            passed=None,
            summary=(
                f"{len(reviews)} tenant(s) reviewed, {total} finding(s) raised "
                "for a person to decide on."
            ),
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
