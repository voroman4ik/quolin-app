#!/usr/bin/env bash
# Every ECS task holds exactly the credentials its job needs. FP3-04, audit G-02.
#
# The shell entry point `make guard` and CI call. The work is in
# `scripts/guard_task_credentials.py`, and the reason it is an allow-list keyed
# on each container's command — rather than a grep for one resource name, which
# is what check 5 of `guard_no_watch_in_engine.sh` was — is in that file's
# docstring.
#
# Plain `python3`, not `uv run`, and that is deliberate: this parses Terraform
# with nothing but the standard library, and the CI job that owns the
# infrastructure checks has OpenTofu and no Python project set up. A guard that
# needs the API's virtualenv to read a `.tf` file is a guard that runs in one
# job and could have run in the right one.
#
# INFRA_DIR points it at a different tree. A missing or empty one is a failure
# rather than a pass, asserted by a mutation case in `test_guard_mutations.py`.
set -uo pipefail

_HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$_HERE/guard_task_credentials.py" "$@"
