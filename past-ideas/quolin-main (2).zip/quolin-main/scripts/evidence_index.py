"""Walk the evidence room, check every artefact, and say what is missing.

This is the thing to hand an auditor first. A folder of JSON answers "what do
you have"; it does not answer "what should you have and where are the holes",
and the second question is the one an assessment turns on.

Three properties, and the third is the one that took thinking about.

**Every artefact's digest is recomputed.** A file edited after it was filed is
reported as altered rather than read as evidence. That does not prove a run
happened — somebody with write access here could author a convincing artefact —
and the output says so, because an index that implied otherwise would be making
exactly the overstatement this room exists to avoid.

**Cadence is checked against a stated expectation, not inferred.** A control
that should run weekly and last ran in April is a gap; a control that has never
run is a different gap and reads differently. Both are reported. Inferring the
expectation from the file dates would mean a control that quietly stopped
looked compliant, because its own history would define the standard.

**A gap is not a failure of this script.** It exits non-zero when an artefact is
*damaged*, because that is a fact about the room. It exits zero with gaps listed
when a control has simply not run, because that is a fact about the programme
and the person reading needs to see it rather than have the report refuse to
render. The distinction matters when the honest state is an empty folder.

Usage:

    make evidence-index
    make evidence-index ARGS=--json

Exit codes: 0 when every artefact present is intact, 1 when the room could not
be read, 2 when an artefact is damaged or missing its digest.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))

from scripts import evidence_io  # noqa: E402

#: How often each control is expected to produce evidence, and why.
#:
#: Stated here rather than inferred from what is in the folder. A control that
#: quietly stopped would otherwise look compliant, because its own history would
#: be the standard it was measured against.
#:
#: `None` means no cadence is claimed — the control runs when something happens
#: rather than on a clock, and its absence is not a gap. An incident folder that
#: is empty is good news.
CADENCE_DAYS: dict[str, int | None] = {
    "access-review": 90,
    "restore-drill": 90,
    "game-day": 90,
    "nightly-replay": 1,
    "secret-scan": 7,
    "isolation-probe": 30,
    "smoke-test": 30,
    "load-test": 7,
    "health-checks": 1,
    "comparison-report": 7,
    "deploy": None,
    "rollback": None,
    "incident": None,
    "pack-signature": None,
}

#: Controls that are expected to exist at all. A category with no artefacts and
#: no expectation is fine; one that should have run and never has is a hole.
EXPECTED = tuple(name for name, days in CADENCE_DAYS.items() if days is not None)


def _artefacts(room: Path) -> list[tuple[Path, dict]]:
    out = []
    for path in sorted(room.rglob("*.json")):
        try:
            out.append((path, json.loads(path.read_text())))
        except (OSError, json.JSONDecodeError):
            out.append((path, {}))
    return out


def build(room: Path, *, now: datetime | None = None) -> dict:
    now = now or datetime.now(timezone.utc)
    found = _artefacts(room)

    damaged: list[dict] = []
    by_control: dict[str, list[dict]] = defaultdict(list)

    for path, body in found:
        ok, why = evidence_io.verify(path)
        relative = str(path.relative_to(room))
        if not ok:
            damaged.append({"file": relative, "why": why})
            continue
        by_control[str(body.get("control", "unknown"))].append(
            {
                "file": relative,
                "ran_at": body.get("ran_at"),
                "environment": body.get("environment"),
                "passed": body.get("passed"),
                "git_sha": (body.get("git_sha") or "")[:12],
            }
        )

    controls = {}
    gaps: list[dict] = []
    for control, runs in sorted(by_control.items()):
        runs.sort(key=lambda r: r["ran_at"] or "")
        newest = runs[-1]
        cadence = CADENCE_DAYS.get(control)
        overdue = None
        if cadence is not None and newest["ran_at"]:
            age = now - datetime.fromisoformat(newest["ran_at"])
            overdue = max(0, (age - timedelta(days=cadence)).days)
            if overdue > 0:
                gaps.append(
                    {
                        "control": control,
                        "why": "overdue",
                        "days_overdue": overdue,
                        "last_ran": newest["ran_at"],
                    }
                )
        controls[control] = {
            "runs": len(runs),
            "oldest": runs[0]["ran_at"],
            "newest": newest["ran_at"],
            "cadence_days": cadence,
            "days_overdue": overdue,
            # Named rather than summed. "Ran nine times" and "ran nine times and
            # failed twice" are different rooms.
            "failed_runs": [r["file"] for r in runs if r["passed"] is False],
            "environments": sorted({r["environment"] for r in runs if r["environment"]}),
        }

    for control in EXPECTED:
        if control not in by_control:
            gaps.append(
                {
                    "control": control,
                    "why": "never run",
                    "days_overdue": None,
                    "last_ran": None,
                }
            )

    return {
        "room": str(room),
        "built_at": now.isoformat(),
        "artefacts": len(found),
        "damaged": damaged,
        "controls": controls,
        "gaps": sorted(gaps, key=lambda g: g["control"]),
        "statement": (
            "This index recomputes each artefact's digest and reports anything "
            "altered since it was filed. It cannot show that a run happened: "
            "somebody with write access to this folder could author an artefact, "
            "and no hashing inside the folder changes that. Gaps are listed "
            "rather than failed, because a control that has not run is a fact "
            "about the programme and needs reading, not suppressing."
        ),
    }


def render(index: dict) -> str:
    lines = [f"evidence room — {index['room']}", ""]
    if not index["artefacts"]:
        lines.append("  Empty. No control has filed evidence yet, which is the")
        lines.append("  honest state until one runs — see docs/evidence.md.")
    for control, state in index["controls"].items():
        cadence = (
            f"every {state['cadence_days']}d"
            if state["cadence_days"]
            else "on occurrence"
        )
        mark = "FAILED" if state["failed_runs"] else "ok"
        lines.append(
            f"  [{mark:^6}] {control:<20} {state['runs']:>3} run(s)  {cadence:<14} "
            f"newest {(state['newest'] or '—')[:19]}  "
            f"[{', '.join(state['environments']) or 'unstated'}]"
        )
    if index["damaged"]:
        lines += ["", "  damaged:"]
        lines += [f"    {d['file']}: {d['why']}" for d in index["damaged"]]
    if index["gaps"]:
        lines += ["", "  gaps:"]
        for gap in index["gaps"]:
            detail = (
                "never run"
                if gap["why"] == "never run"
                else f"{gap['days_overdue']}d overdue (last {gap['last_ran'][:19]})"
            )
            lines.append(f"    {gap['control']:<20} {detail}")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Navigate the evidence room.")
    parser.add_argument("--room", type=Path, default=evidence_io.ROOM)
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    args = parser.parse_args()

    if not args.room.exists():
        print(
            f"{args.room} does not exist. The room is committed as a structure "
            "even when empty — see evidence/README.md.",
            file=sys.stderr,
        )
        return 1

    index = build(args.room)
    print(json.dumps(index, indent=2) if args.json else render(index))

    if index["damaged"]:
        print(
            f"\n{len(index['damaged'])} artefact(s) do not match their recorded "
            "digest. Either the file was edited after it was filed, or it was "
            "written by something that is not this tooling. Both are worth "
            "establishing before the room is handed to anybody.",
            file=sys.stderr,
        )
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
