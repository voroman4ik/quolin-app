"""
Prove the tamper-evidence, against the real stored records, without writing.

A green "chain verified" tick is worth nothing to a compliance audience if it
has never been seen to fail. Anyone can render a tick. This is the step in the
demo script that makes the claim checkable in the room.

There are two separate guarantees and they are usually conflated, so the script
demonstrates them one at a time:

  1. **Append-only.** Two independent locks, and step 2 shows both. The
     application role has UPDATE and DELETE revoked on `decisions`, so a
     request is refused on privileges before it reaches anything else; and the
     table carries a Postgres trigger that raises on any UPDATE or DELETE, so
     the owning role is refused too. Neither involves application code. Between
     them they stop an application bug, a careless operator, and an attacker
     holding the application's own credentials.

  2. **Hash-chained.** Both locks bind someone going through Postgres; whoever
     can drop a trigger and re-grant a privilege can get past them. What they
     cannot do is make the numbers agree afterwards, because each decision's
     hash covers the previous decision's hash. Step 3 takes a real stored
     determination, changes one field, recomputes the hash exactly as the
     engine would, and shows it no longer matches what is on the record.

The second point deserves saying out loud in the room: the chain does not
prevent tampering. It makes tampering *detectable after the fact*, which is the
property an auditor actually wants, and it is a weaker and more honest claim
than what people usually assume when they see the word "hash".

**This script writes nothing.** Step 2's two UPDATEs each run inside a
transaction that is always rolled back — and in any case both are refused
before they can apply. Step 3 is pure arithmetic on values read out of the
database. You can run this against a live demo mid-meeting and the worst it can
do is print.

That is a deliberate trade. Showing the badge on the evidence screen actually
turn red would mean committing a corrupted row, which means either disabling the
integrity trigger on the demo database or leaving behind a poisoned record that
only `make seed` can clear — neither of which belongs in a script you might run
minutes before presenting. The red state of that badge is covered by the test
suite instead (`api/tests/test_evidence_chain.py`), and if you want it on screen,
`docs/demo-script.md` describes doing it against a scratch copy.

Usage:

    make tamper-demo

Exit codes: 0 when both guarantees held, 1 when either did not — which would be
a real defect, not a demo problem.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Same dual-layout dance as scripts/watch_tick.py: `api/` in the repo, flattened
# to the working directory inside the container.
_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from sqlalchemy import select, text  # noqa: E402

from app import evidence, tenancy  # noqa: E402
from app.canonical import chain_hash  # noqa: E402
from app.db import SessionLocal, owner_engine  # noqa: E402
from app.models import Decision  # noqa: E402


def _refusal(attempt, undo) -> str | None:
    """Run an edit that must be refused. Returns the refusal, or None if it went through."""
    try:
        attempt()
        undo()
        return None
    except Exception as exc:  # noqa: BLE001 — any refusal is the good outcome
        undo()
        return str(exc).strip().splitlines()[0]


def _payload(d: Decision, **overrides) -> dict:
    """
    The exact dict the engine hashes, so the recomputation below is the real
    calculation rather than a lookalike. Kept in step with `evidence._hashable`
    by calling it, not by copying its field list.
    """
    fields = dict(
        # The shape *this row* was hashed under. Recomputing a schema-2 row
        # under schema 1 produces a hash that does not match and a script that
        # reports the chain as already broken — which is what happened, and is a
        # frightening thing to be told by a demo. See Q-04 and `app/manifest.py`.
        schema=d.payload_schema,
        execution_manifest=d.manifest,
        tenant_id=d.tenant_id,
        client_id=d.client_id,
        asset_id=d.asset_id,
        as_of=d.as_of,
        pack_id=d.pack_id,
        pack_version=d.pack_version,
        snapshot=d.snapshot,
        rule_results=d.rule_results,
        resolution=d.resolution,
        outcome=d.outcome,
        created_at=d.created_at,
    )
    fields.update(overrides)
    return evidence._hashable(**fields)  # noqa: SLF001 — one calculation, one source


def main() -> int:
    # This is not a request and has no cookie, so it names a tenant the way the
    # deployment does. Without it, row-level security correctly shows this
    # script an empty database and the demo reports there is nothing to tamper
    # with — which is the guarantee working, and a confusing thing to watch.
    with tenancy.acting_as(tenancy.configured_tenant()):
        return _demonstrate()


def _demonstrate() -> int:
    session = SessionLocal()
    try:
        # --- 1. the chain verifies right now ------------------------------
        before = evidence.verify_chain(session)
        if not before["verified"]:
            print(
                "tamper demo refused: the chain does not verify before we start.\n"
                f"  broken at decision {before.get('broken_at_decision_id')}\n"
                "  Run `make seed` to rebuild the demo database, then try again.",
                file=sys.stderr,
            )
            return 1
        print(
            f"\n1.  Chain verifies — {before['checked']} records, "
            f"tip {before['tip_hash'][:16]}…"
        )

        # A BLOCK is the interesting victim: a refused trade quietly
        # reclassified as an approved one is the edit somebody would want.
        target = session.scalars(
            select(Decision).where(Decision.outcome == "BLOCK").order_by(Decision.id)
        ).first()
        if target is None:
            print("tamper demo refused: no BLOCK decision to work with.", file=sys.stderr)
            return 1

        # --- 2. the database refuses an ordinary edit, twice --------------
        # Both attempts run inside transactions that are rolled back
        # regardless, and both are refused before anything is applied.
        edit = text("UPDATE decisions SET outcome = 'ALLOW' WHERE id = :id")

        as_app = _refusal(lambda: session.execute(edit, {"id": target.id}), session.rollback)
        if as_app is None:
            print(
                "\ntamper demo FAILED: the application role rewrote a decision.\n"
                "  UPDATE is supposed to be revoked on `decisions` for this role.",
                file=sys.stderr,
            )
            return 1

        with owner_engine.connect() as conn:
            as_owner = _refusal(lambda: conn.execute(edit, {"id": target.id}), conn.rollback)
        if as_owner is None:
            print(
                "\ntamper demo FAILED: the append-only trigger did not fire.\n"
                "  The owning role rewrote a decision. The guarantee this script\n"
                "  exists to demonstrate is not in place on this database.",
                file=sys.stderr,
            )
            return 1

        print(f"\n2.  Postgres refuses to edit decision {target.id}, at two levels.")
        print(f"      as the application role   {as_app}")
        print(f"      as the owner of the table {as_owner}")
        print(
            "\n      The first is a revoked grant, the second a trigger. They are\n"
            "      independent: revoking the grant would not help if the trigger\n"
            "      were dropped, and the trigger would not help if the application\n"
            "      ran as a role that could drop it. The application runs as\n"
            "      neither the owner nor a superuser, which is why the first\n"
            "      refusal is the one a request actually meets."
        )

        # --- 3. and the hash would not agree even if it had ----------------
        stored = target.this_hash
        recomputed = chain_hash(target.prev_hash, _payload(target))
        forged = chain_hash(target.prev_hash, _payload(target, outcome="ALLOW"))

        if recomputed != stored:
            print(
                "\ntamper demo FAILED: the stored hash does not match the stored\n"
                "  record even before tampering. The chain is already broken.",
                file=sys.stderr,
            )
            return 1
        if forged == stored:
            print(
                "\ntamper demo FAILED: changing the outcome did not change the\n"
                "  hash. Tamper-evidence has regressed — a real defect.",
                file=sys.stderr,
            )
            return 1

        print("\n3.  Suppose someone switched it off and wrote BLOCK → ALLOW anyway.")
        print(f"      hash on the record          {stored[:32]}…")
        print(f"      recomputed, as stored       {recomputed[:32]}…  match")
        print(f"      recomputed, outcome=ALLOW   {forged[:32]}…  does not match")
        print(
            f"\n      Decision {target.id} is one of {before['checked']}. Every later record's\n"
            f"      hash is computed over this one, so the break does not stay local —\n"
            f"      /evidence/verify walks the chain and names the first record that\n"
            f"      no longer adds up."
        )
        print(
            "\n      The chain does not prevent the edit. It makes the edit\n"
            "      impossible to hide, which is the property an auditor wants."
        )
        return 0

    except Exception as exc:  # noqa: BLE001 — one exit code for a demo prop
        session.rollback()
        print(f"\ntamper demo failed: {exc}", file=sys.stderr)
        return 1
    finally:
        session.close()


if __name__ == "__main__":
    raise SystemExit(main())
