"""Every ECS task holds exactly the credentials its job needs, and no others.

FP3-04, and it closes audit G-02.

What this replaces was check 5 of `guard_no_watch_in_engine.sh`: a grep for the
literal resource name `"watch"` in `infra/compute.tf`, followed by assertions
about the text of that one block. Three things were wrong with it and the third
is the one that matters.

  * It was vacuous on a rename. `aws_ecs_task_definition "watch"` becoming
    `"watch_sweep"` made the grep find nothing, and finding nothing was a pass.
  * It checked one task. The health and comparison tasks were checked by
    nothing at all, and each of those holds `DATABASE_URL` and the master key.
  * It could only ever catch what somebody had already thought to forbid. The
    watch task was checked for two specific connection strings because those
    two were the known danger. `DATABASE_URL` in the *API* task was not on
    anybody's list, so no guard mentioned it, and it sat there through thirteen
    stages and two fix-packs.

So this is an allow-list rather than a deny-list, keyed on what each container
runs. A task gaining a credential nobody authorised fails without anybody having
predicted which credential it would be — which is the only shape of this guard
that could have caught FP3-04 before an audit did.

Adding a variable to a task means adding it here, in the same change, where the
reason for it is reviewed. That is the cost, and it is the point.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))

from scripts.task_environment import Task, task_definitions  # noqa: E402

#: What every container gets regardless of what it runs. Neither is a secret and
#: both are needed to log and to reach AWS at all.
COMMON = frozenset({"AWS_REGION", "QUOLIN_ENVIRONMENT"})

#: The permitted variable set per task, keyed on the container's command.
#:
#: Keyed on the command rather than on the resource name, so that renaming
#: `aws_ecs_task_definition "watch"` does not silently stop this checking it —
#: which is exactly how check 5 of the old guard became vacuous. A task whose
#: command is not listed here is a failure, not a pass: a new task nobody has
#: reviewed the credentials of is the case this exists for.
ALLOWED: dict[tuple[str, ...], frozenset[str]] = {
    # The request-serving API. **No `DATABASE_URL`** — FP3-04. The owner role
    # owns every append-only trigger, is exempt from FORCE row-level security,
    # and is what rewrites evidence hashes. Nothing in the request path uses it,
    # the container runs no migration at start, and it was sitting in the
    # environment of the first process an attacker reaches.
    (): COMMON
    | {
        "APP_DATABASE_URL",
        "ARTEFACT_BUCKET",
        "QUOLIN_ALLOWED_ORIGINS",
        "QUOLIN_COOKIE_SECURE",
        "QUOLIN_MASTER_KEY",
        "QUOLIN_TENANT_KEY_ARN",
        # FP3-02. Which proxies may be believed about the caller's address.
        "QUOLIN_TRUSTED_PROXY_CIDRS",
    },
    # The watch sweep. One connection string, and it is not one that can write a
    # pack or read a customer's row. The model credential lives here and only
    # here: §S6's boundary is that a determination is never one environment
    # variable away from a model.
    ("python", "-m", "scripts.watch_tick"): COMMON
    | {"ANTHROPIC_API_KEY", "WATCH_DATABASE_URL", "WATCH_MODE"},
    # The health checks, which are also the `source.stale` fan-out since
    # FP3-03. Holds the owner connection because it enumerates firms through
    # `maintenance`, which is what migration 0029 exists for.
    ("python", "-m", "scripts.health_alerts"): COMMON
    | {
        "APP_DATABASE_URL",
        "DATABASE_URL",
        "QUOLIN_MASTER_KEY",
        "QUOLIN_PAGER_URL",
    },
    ("python", "-m", "scripts.comparison_report", "--json"): COMMON
    | {"APP_DATABASE_URL", "DATABASE_URL", "QUOLIN_MASTER_KEY"},
    # The asynchronous execution tier. Each of these serves every firm, so each
    # holds the owner connection for `maintenance.active_tenant_ids` and for
    # nothing else — under FORCE row-level security a query for "all tenants"
    # returns the one in scope, and migration 0029's `quolin_maintenance` grant
    # is what admits the enumeration. The same trade `health` and `comparison`
    # above already make.
    #
    # None of them holds `ANTHROPIC_API_KEY` or `WATCH_DATABASE_URL`; `CONFINED`
    # below says so independently, which is the point of saying it twice.
    ("python", "-m", "scripts.deliver_webhooks"): COMMON
    | {"APP_DATABASE_URL", "DATABASE_URL", "QUOLIN_MASTER_KEY"},
    # Plus the bucket a rendered document is filed in. The API holds the same
    # variable and neither writes anywhere else.
    ("python", "-m", "scripts.artefact_worker"): COMMON
    | {"APP_DATABASE_URL", "ARTEFACT_BUCKET", "DATABASE_URL", "QUOLIN_MASTER_KEY"},
    ("python", "-m", "scripts.bulk_worker"): COMMON
    | {"APP_DATABASE_URL", "DATABASE_URL", "QUOLIN_MASTER_KEY"},
    ("python", "-m", "scripts.settle_packs"): COMMON
    | {"APP_DATABASE_URL", "DATABASE_URL", "QUOLIN_MASTER_KEY"},
}

#: Credentials that may appear in exactly the tasks named, and nowhere else.
#: A second statement of the same rule, and deliberately redundant: the
#: allow-list above says what each task may hold, and this says what each of
#: these may be held by. A new task added to `ALLOWED` with a model credential
#: in it would pass the first check and fail this one.
CONFINED: dict[str, frozenset[tuple[str, ...]]] = {
    "ANTHROPIC_API_KEY": frozenset({("python", "-m", "scripts.watch_tick")}),
    "WATCH_DATABASE_URL": frozenset({("python", "-m", "scripts.watch_tick")}),
}


def check(infra_dir: Path | str) -> list[str]:
    """Every task's credential set against the allow-list. Empty means clean."""
    tasks: dict[str, Task] = task_definitions(infra_dir)
    problems: list[str] = []

    for resource, task in sorted(tasks.items()):
        permitted = ALLOWED.get(task.command)
        if permitted is None:
            problems.append(
                f"{resource}: runs {list(task.command) or '<the image CMD>'}, which "
                "is not in the allow-list. A new task is a new set of credentials "
                "for somebody to review — add it to ALLOWED in "
                "scripts/guard_task_credentials.py with a reason."
            )
            continue

        for name in sorted(task.names - permitted):
            problems.append(
                f"{resource}: holds {name}, which its job does not need. "
                f"Permitted: {sorted(permitted)}."
            )

        for name, allowed_commands in sorted(CONFINED.items()):
            if name in task.names and task.command not in allowed_commands:
                problems.append(
                    f"{resource}: holds {name}, which is confined to "
                    f"{sorted(list(c) for c in allowed_commands)}."
                )

    return problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--infra-dir", default=os.getenv("INFRA_DIR") or str(REPO / "infra")
    )
    args = parser.parse_args(argv)

    try:
        problems = check(args.infra_dir)
    except FileNotFoundError:
        # An absent target is a failure, never a pass. `guard_no_hardcoded_region.sh`
        # exited 0 with "nothing to check" in exactly this case while its own
        # header said it should fail — see G-07.
        print(f"FAIL: no infrastructure directory at {args.infra_dir}.")
        print()
        print("This guard reads the ECS task definitions. It found none, which")
        print("means it is pointed at the wrong place rather than that the tasks")
        print("are clean.")
        return 1
    except ValueError as exc:
        print(f"FAIL: {exc}")
        print()
        print("A scan of zero task definitions is not a clean scan.")
        return 1

    if problems:
        for problem in problems:
            print(f"FAIL: {problem}")
        print()
        print(
            "Every task holds exactly the credentials its command needs. The "
            "owner connection, the master key and the model credential are each "
            "confined to the jobs that genuinely use them."
        )
        return 1

    count = len(task_definitions(args.infra_dir))
    print(
        f"OK: {count} ECS task definition(s); each holds only the credentials its "
        "command is allow-listed for, and the owner connection, master key and "
        "model credential are confined to the tasks that need them."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
