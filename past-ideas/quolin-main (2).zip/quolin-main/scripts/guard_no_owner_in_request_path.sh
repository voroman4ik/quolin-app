#!/usr/bin/env bash
# Nothing that serves a request reaches for the schema owner. FP3-04, Gate A.
#
# `DATABASE_URL` is the role that owns every table, owns every append-only
# trigger, bypasses FORCE row-level security, and is what `scripts/rechain.py`
# rewrites evidence hashes with. FP3-04 removed it from the request-serving ECS
# task and wrote `app/owner_only.py`, which refuses to import without it — so
# that code reaching for the owner in a process that has no business holding one
# fails at import rather than three frames into a request.
#
# **Four rules, and the count is the finding.** Each round of this closed the
# spelling that had just been used and left the shape:
#
#   three names -> three names plus the door -> the door with a three-file
#   allow-list -> the door, the key, and the neighbours who hold both.
#
# What that sequence says is written down in `docs/spec-changes.md` and it is
# worth reading before adding a fifth: a lexical guard cannot enforce a
# structural boundary, and the structural boundary that does exist is the
# credential the request-serving task is not given. This file is a coupling
# check that fails on a laptop and in CI, where that credential is present and
# the boundary is therefore not enforced by anything else.
#
# *Rule 1 — the connection may not be named.* `OwnerSessionLocal`,
# `owner_engine`, `OWNER_DATABASE_URL`. This is the check the Gate A audit asked
# for and it caught the defect it was written for: `main.py`'s `/admin/users`
# imported `OwnerSessionLocal` **from `app.db` directly**, inside the handler, so
# `owner_only`'s import guard was never involved.
#
# *Rule 2 — the door may not be opened either, and this is B2.* The follow-up
# audits ran the obvious way past rule 1:
#
#     from app import owner_only
#     owner_only.active_tenant_ids()
#
# Not one of the three names appears, so the guard exited 0. So the token
# `owner_only` is forbidden in application code, not the three names it wraps.
#
# *Rule 3 — the key may not be held, and this is F2.* Rules 1 and 2 forbid the
# door and three names for what is behind it. Neither forbade
#
#     import os, sqlalchemy
#     e = sqlalchemy.create_engine(os.environ["DATABASE_URL"])
#
# which reaches the same role with none of the four tokens above. A module that
# can build its own engine does not need anyone's door, so `DATABASE_URL`,
# `create_engine` and `psycopg.connect` are forbidden under `api/app` except in
# `db.py`, which constructs the engines because something has to. `owner_only.py`
# asked `os.getenv("DATABASE_URL")` itself and now asks `db.OWNER_URL_WAS_SUPPLIED`
# — one file names the key.
#
# *Rule 4 — and not through the neighbours.* `api/seed` and `scripts` sit beside
# `api/app` on `sys.path` in this suite and in the built image, and both
# re-export the owner at module scope: `seed/seed.py` line 21 is
# `from app.db import OwnerSessionLocal, owner_engine`, and every worker under
# `scripts/` does the same. So
#
#     import seed.seed
#     seed.seed.OwnerSessionLocal()
#
# reaches the owner from a request-path module while naming neither the
# connection nor the door. Those packages hold the owner deliberately — that is
# what a worker is — which is exactly why nothing under `api/app` may import
# them.
#
# **What may name either, and why.**
#
#   db.py          constructs the engines and the sessionmakers, and is now the
#                  only file that names the key. Something has to.
#   owner_only.py  is the locked door itself.
#
# `auth.py` was a third and is not one any more — F2. It held
# `_reset_rate_limit_for_tests`, which disables an append-only trigger and
# deletes from `auth_attempts` as the owner. Only the suite ever called it, and
# the argument for leaving it here was that forty test call sites named it. But
# `auth` is imported by everything that serves a request, so what the allow-list
# was keeping open was invariant 4 and the login rate limit, reachable from any
# handler, for the convenience of a caller that is not in the request path at
# all. It is `conftest.reset_rate_limit_for_tests` now and the call sites moved
# mechanically. `source_alerts.py` was a fourth and went the same way in B2, for
# the same reason: a door nobody in the request path needs is one fewer door.
#
# The allow-list is now the two structural files and nothing else, which is the
# smallest it can be while `db.py` exists.
#
# A name added to either allow-list is a change to the boundary and is reviewed
# as one. `test_guard_mutations.py` mutates each door to prove the list is not a
# hole, and `api/tests/test_no_request_reaches_the_schema_owner.py` is the AST
# twin of all four rules — with its own mutation cases, because until F3 it had
# none and its detection branches could be deleted without a test noticing.
#
# The scan is by name rather than by call graph on purpose. A call graph would
# be a better answer and a worse guard: it would need to be right about dynamic
# imports, and the defects it exists to catch were a plain `from .db import
# OwnerSessionLocal` written inside a function and a plain `from app import
# owner_only` written at module scope.
set -uo pipefail

# §S13: fail rather than pass when there is nothing to examine.
# shellcheck source=scripts/guard_lib.sh
. "$(dirname "$0")/guard_lib.sh"

APP_DIR="${APP_DIR:-api/app}"

require_scan "the schema owner in the request path" "py" "$APP_DIR"

# Rule 1: the names that reach the owner connection. All three, because the
# second and third are how somebody gets to the first without spelling it.
NAMES='OwnerSessionLocal|owner_engine|OWNER_DATABASE_URL'
NAMES_EXEMPT='api/app/db\.py|api/app/owner_only\.py'

# Rule 2: the module that holds them. Any spelling — `from app import
# owner_only`, `from .owner_only import x`, `import app.owner_only`, an
# attribute access, or the dotted path as a string for `import_module`.
DOOR='owner_only'
DOOR_EXEMPT='api/app/db\.py|api/app/owner_only\.py'

# Rule 3: the key, and the two ways to turn it into a connection without going
# past rules 1 and 2. `DATABASE_URL` unqualified, which also catches
# `APP_DATABASE_URL` and `WATCH_DATABASE_URL` — no request-path module has any
# business naming a connection string of any role.
KEY='DATABASE_URL|create_engine|psycopg\.connect'
KEY_EXEMPT='api/app/db\.py'

# Rule 4: the sibling packages, which hold the owner because that is their job.
# Import statements in every spelling, plus the dotted path as a string, which
# is how `importlib.import_module` reaches one.
#
# No exemption list, and that is not an omission: `api/app` has no legitimate
# reason to import either package, so there is nothing to except. A file added
# here would be a new door, reviewed as one.
SIBLINGS='(from|import)[[:space:]]+(seed|scripts)(\.|[[:space:]]|$)|["'"'"'](seed|scripts)\.'

# Prose is not code. A guard that refused to let its own history be written down
# is one people route around — the same rule `guard_no_shared_passcode.sh`
# applies to `docs/`. Two filters, and they are deliberately narrow:
#
#   - a line whose first non-space character starts a comment or a docstring
#   - a line naming the thing in backticks, which is how every reference in a
#     docstring in this tree is written
#
# The AST twin has no need of either, because it reads the parse tree and a
# string in a docstring is not a reference. That is why there are two of them.
_prose() {
  grep -vE ':[0-9]+:[[:space:]]*(#|\*|")' \
    | grep -vE ':[0-9]+:.*`[^`]*('"$1"')[^`]*`'
}

# shellcheck disable=SC2046 — the excludes must word-split into separate args.
name_hits=$(grep -rInE "$NAMES" "$APP_DIR" $(grep_excludes) 2>/dev/null \
              | _prose "$NAMES" \
              | grep -vE "$NAMES_EXEMPT" \
              || true)

# shellcheck disable=SC2046
door_hits=$(grep -rInE "$DOOR" "$APP_DIR" $(grep_excludes) 2>/dev/null \
              | _prose "$DOOR" \
              | grep -vE "$DOOR_EXEMPT" \
              || true)

# shellcheck disable=SC2046
key_hits=$(grep -rInE "$KEY" "$APP_DIR" $(grep_excludes) 2>/dev/null \
             | _prose "$KEY" \
             | grep -vE "$KEY_EXEMPT" \
             || true)

# shellcheck disable=SC2046
sibling_hits=$(grep -rInE "$SIBLINGS" "$APP_DIR" $(grep_excludes) 2>/dev/null \
                 | _prose "$SIBLINGS" \
                 || true)

if [ -n "$name_hits" ] || [ -n "$door_hits" ] || [ -n "$key_hits" ] \
   || [ -n "$sibling_hits" ]; then
  [ -n "$name_hits" ] && echo "$name_hits"
  [ -n "$door_hits" ] && echo "$door_hits"
  [ -n "$key_hits" ] && echo "$key_hits"
  [ -n "$sibling_hits" ] && echo "$sibling_hits"
  echo
  echo "FAIL: the schema owner is reachable from the request path."
  echo
  echo "That role owns every append-only trigger, is exempt from FORCE"
  echo "row-level security, and is what rewrites evidence hashes. FP3-04 took it"
  echo "out of the request-serving task, so in the deployment this does not"
  echo "escalate — it fails to connect, because db.py falls back to a hardcoded"
  echo "localhost:5433. The bypass is reachable exactly where the owner"
  echo "connection happens to be lying about, which is a laptop and the suite."
  echo
  echo "Importing app.owner_only counts. It is a locked door and not a safe"
  echo "wrapper: what is behind it is the owner connection, and a request-path"
  echo "module that opens it has reached the owner however politely."
  echo
  echo "Naming DATABASE_URL, create_engine or psycopg.connect counts. A module"
  echo "that can build its own engine does not need anyone's door."
  echo
  echo "Importing seed or scripts counts. Both re-export the owner at module"
  echo "scope, because holding it is what a worker is for — which is precisely"
  echo "why nothing under api/app may import one."
  echo
  echo "If a request genuinely needs owner privileges, it does not: move the"
  echo "operation out of the request path into a script or a scheduled task,"
  echo "and say why in docs/spec-changes.md."
  exit 1
fi

echo "OK: $SCANNED_FILES file(s) under $APP_DIR. The schema owner is named only"
echo "    in db.py, which constructs it and is the one file that names the key,"
echo "    and owner_only.py, which is the door — and nothing under api/app opens"
echo "    that door or imports the packages that hold the owner themselves."
