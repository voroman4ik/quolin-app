"""
Fill the ciphertext columns migration 0005 added, for rows written before it.

Migration 0005 adds an empty `*_cipher` column beside each column that is
becoming encrypted. Migration 0006 drops the plaintext and renames the
ciphertext into its place, and refuses to run while any of those columns is
still empty. This script is what happens in between: it reads each plaintext
value, seals it under the tenant's data key, and writes it to the column beside
it. It changes no value — what comes back out of `decisions.snapshot` after
0006 is byte-for-byte what went in, which is the only reason the hash chain
still verifies afterwards.

**Why this is a script and not the second half of 0005.** `decisions` is
append-only: a trigger and a revoked grant stand against UPDATE, and
`scripts/lint_migrations.sh` fails any migration that disables a trigger. That
rule is worth more than the convenience of one fewer step. Suspending
append-only over a table of evidence is something an operator does deliberately,
with the act recorded in `audit_events` — the pattern `scripts/rechain.py` set,
and this follows it rather than inventing a second way to do the same thing.

**It is needed once, and only on a database that already held rows.** In dev and
in CI, `make seed` builds the schema by running every migration against empty
tables and then writes ciphertext from the first row onward, so there is nothing
here to do. This exists for a deployment carrying real records across the
change.

**Tenants are named, not discovered**, for the reason `scripts/rechain.py`
gives: under `FORCE ROW LEVEL SECURITY` an owner that is not a superuser sees
only the tenant it has declared, so a discovery mode would work in dev and
silently do nothing where it mattered.

Usage:

    make encrypt-existing                      # dry run, the deployment's tenant
    make encrypt-existing ARGS=--apply
    uv run python -m scripts.encrypt_existing acme beta --apply

Exit codes: 0 when every column is filled (or would be, on a dry run), 1 when
the schema is not in a state this can act on or a write failed.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

# Same dual-layout dance as scripts/watch_tick.py: `api/` in the repo, flattened
# to the working directory inside the container.
_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from sqlalchemy import text  # noqa: E402
from sqlalchemy.orm import Session  # noqa: E402

from app import crypto, tenancy  # noqa: E402
from app.db import OwnerSessionLocal  # noqa: E402
from app.models import AuditEvent, Client, Decision  # noqa: E402

ACTOR = "scripts.encrypt_existing"
CIPHER = "_cipher"

#: The trigger that has to stand down for the `decisions` rewrite, by name.
APPEND_ONLY_TRIGGER = "decisions_append_only"


def _targets() -> list[tuple[str, str, Any]]:
    """Every encrypted column, read off the models rather than listed here.

    The migrations spell the same list out longhand, and say why: a migration is
    a record of what was run and must not change meaning when the code does.
    This script is the opposite kind of artefact. It runs against today's models
    and must encrypt exactly the columns today's models expect to be encrypted,
    so deriving the list is what keeps it from filling a column nobody reads or
    missing one everybody does.
    """
    found = []
    for model in (Client, Decision):
        for column in model.__table__.columns:
            if isinstance(column.type, crypto._Encrypted):  # noqa: SLF001
                found.append((model.__tablename__, column.name, column.type))
    return found


def _column_types(session: Session, table: str) -> dict[str, str]:
    rows = session.execute(
        text(
            "SELECT column_name, data_type FROM information_schema.columns "
            "WHERE table_schema = current_schema() AND table_name = :t"
        ),
        {"t": table},
    )
    return {name: kind for name, kind in rows}


def _encrypt_column(
    session: Session, table: str, column: str, kind: Any, *, apply: bool
) -> bool:
    """Fill one column's ciphertext. Returns False only on a state it cannot act on."""
    columns = _column_types(session, table)
    cipher = f"{column}{CIPHER}"

    if cipher not in columns:
        if columns.get(column) == "bytea":
            print(f"    {table}.{column}: already encrypted (0006 has run).")
            return True
        print(
            f"    {table}.{column}: no {cipher} column. Migration 0005 has not "
            "run against this database — run `make migrate` first.",
            file=sys.stderr,
        )
        return False

    rows = list(
        session.execute(
            text(
                f"SELECT id, {column} FROM {table} "  # noqa: S608 — names from the models
                f"WHERE {cipher} IS NULL ORDER BY id"
            )
        )
    )
    if not rows:
        print(f"    {table}.{column}: nothing outstanding.")
        return True

    print(f"    {table}.{column}: {len(rows)} rows to encrypt.")
    if not apply:
        return True

    for row_id, value in rows:
        # Through the column type itself, so that what this writes and what the
        # application writes cannot diverge. A snapshot encoded even slightly
        # differently here would decrypt to a dict that no longer hashes to the
        # value on its own record, and replay would fail on evidence that was
        # never touched.
        sealed = kind.process_bind_param(value, session.get_bind().dialect)
        session.execute(
            text(
                f"UPDATE {table} SET {cipher} = :sealed WHERE id = :id"  # noqa: S608
            ),
            {"sealed": sealed, "id": row_id},
        )
    return True


def _encrypt_tenant(tenant_id: str, *, apply: bool) -> bool:
    session = OwnerSessionLocal()
    try:
        # The key first, and committed before anything is sealed under it. A run
        # that encrypted rows and then failed to store the key would have
        # destroyed the data it was asked to protect.
        crypto.ensure_key(session, tenant_id)
        session.commit()

        print(f"  {tenant_id}:")

        ok = True
        # Append-only stands down for the duration and comes back in the
        # `finally`, whether this commits or raises.
        session.execute(text(f"ALTER TABLE decisions DISABLE TRIGGER {APPEND_ONLY_TRIGGER}"))
        try:
            for table, column, kind in _targets():
                ok = _encrypt_column(session, table, column, kind, apply=apply) and ok
            if ok and apply:
                session.add(
                    AuditEvent(
                        tenant_id=tenant_id,
                        actor=ACTOR,
                        action="evidence.encrypt_existing",
                        subject="plaintext columns sealed under this tenant's data key",
                    )
                )
            session.commit()
        finally:
            session.execute(text(f"ALTER TABLE decisions ENABLE TRIGGER {APPEND_ONLY_TRIGGER}"))
            session.commit()

        if not ok:
            return False
        if apply:
            print("    done. `make migrate` will now complete 0006.")
        else:
            print("    Dry run. Pass --apply to write.")
        return True
    finally:
        session.close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Encrypt rows written before the encrypted columns existed."
    )
    parser.add_argument(
        "tenants",
        nargs="*",
        help="Tenant ids. Defaults to the tenant this deployment serves (QUOLIN_TENANT).",
    )
    parser.add_argument("--apply", action="store_true", help="Write. Otherwise a dry run.")
    args = parser.parse_args(argv)

    tenants = args.tenants or [tenancy.configured_tenant()]
    print(f"\nencrypt existing {'(apply)' if args.apply else '(dry run)'}: {', '.join(tenants)}")

    ok = True
    for tenant_id in tenants:
        # Each tenant in its own scope: the row-level security setting, the
        # additional data every value is sealed with, and the tenant stamped on
        # the audit row all read it.
        with tenancy.acting_as(tenant_id):
            ok = _encrypt_tenant(tenant_id, apply=args.apply) and ok

    print()
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
