"""
One pass of the artefact queue: render everything waiting, then stop.

§S7 moves rendering off the request path. This is what runs it — the same code
the API would have called, in a process nobody is waiting on. A hundred queued
documents take a hundred renders' worth of time here and none of it in a
request, which is the gate.

**One transaction per document.** A worker killed on the ninety-ninth keeps the
ninety-eight that finished, and its claim on the ninety-ninth expires so another
worker picks it up. Rendering is idempotent — the same inputs produce the same
bytes and update the same artefact row — so a job that runs twice costs a render
and changes nothing.

**A pass per tenant, in that tenant's own transaction.** `app.tenant_id` binds
when a transaction begins, so a session reused across the loop would claim the
second tenant's jobs inside the first tenant's transaction. That is not a
hypothetical: it was written that way once in the access review and once in the
watch sweep, and caught both times by reading output rather than by a test.

Usage:

    make artefact-worker
    uv run python -m scripts.artefact_worker --limit 50

Exit codes: 0 if everything that was claimed rendered, 1 if the pass could not
run, 2 if at least one document failed — a scheduler should alert on the third
without treating it as a crash.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from app import maintenance, tenancy  # noqa: E402
from app.artefacts import queue, runner  # noqa: E402
from app.db import OwnerSessionLocal, SessionLocal  # noqa: E402
from app.main import _aggregate  # noqa: E402


def _tenants() -> list[str]:
    """Every active customer, read before any tenant is bound.

    Admitted by the `quolin_maintenance` grant migration 0029 creates rather
    than by the owner happening to hold BYPASSRLS, which is an attribute an RDS
    master account does not have.
    """
    session = OwnerSessionLocal()
    try:
        return maintenance.active_tenant_ids(session)
    finally:
        session.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Render queued artefacts.")
    parser.add_argument(
        "--limit",
        type=int,
        default=100,
        help="most documents to render per tenant in one pass",
    )
    args = parser.parse_args()

    totals = {"done": 0, "failed": 0}
    try:
        tenants = _tenants()
    except maintenance.NoActiveTenants as exc:
        print(f"artefact worker found no firms: {exc}", file=sys.stderr)
        return 1
    if not tenants:
        print(
            "artefact worker enumerated no active firms. A render queue with no "
            "firms to drain is a worker that cannot see its work, not an empty "
            "queue.",
            file=sys.stderr,
        )
        return 1

    try:
        for tenant_id in tenants:
            with tenancy.acting_as(tenant_id):
                session = SessionLocal()
                try:
                    tally = runner.drain(
                        session, aggregate=_aggregate, limit=args.limit
                    )
                    outstanding = queue.depth(session)
                finally:
                    session.close()

            totals["done"] += tally["done"]
            totals["failed"] += tally["failed"]
            if tally["done"] or tally["failed"] or outstanding[queue.QUEUED]:
                print(
                    f"{tenant_id}: {tally['done']} rendered, {tally['failed']} failed, "
                    f"{outstanding[queue.QUEUED]} still queued"
                )
    except Exception as exc:  # noqa: BLE001 — a scheduler needs one exit code
        print(f"artefact worker could not run: {exc}", file=sys.stderr)
        return 1

    print(f"artefact worker — {totals['done']} rendered, {totals['failed']} failed")
    if totals["failed"]:
        # Distinct from 1: the pass ran. A document failed, which is a thing to
        # look at, and not the same as the worker being unable to start.
        print(
            f"{totals['failed']} document(s) failed to render; see artefact_jobs.last_error",
            file=sys.stderr,
        )
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
