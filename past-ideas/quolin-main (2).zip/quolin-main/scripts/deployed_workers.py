#!/usr/bin/env python3
"""The operating table, the schedules and the scheduler's IAM policy agree.

`docs/deployment.md` states the rule in its own words: *"Anything added to that
table needs adding to `aws_iam_role_policy.watch_scheduler` in the same
change."* Two of five rows violated it, and the document beside them explains
exactly why nobody noticed:

> a task definition missing from the list produces a schedule that exists and
> is denied every time it fires, which nothing validates and nobody sees.

A rule stated in prose is a rule enforced by whoever remembers it. This is the
mechanical form, and it checks the agreement in every direction it can drift:

  1. **A scheduled task must be in the policy.** The failure is silent — the
     schedule exists, EventBridge is denied on every firing, and nothing in a
     plan or a log says so. `aws_cloudwatch_metric_alarm.schedule_never_fired`
     is the runtime half of this; this is the build half, and it is better
     because it fires before the deploy rather than five minutes after.

  2. **A task in the policy must be scheduled.** Permission to run something
     nothing runs is permission nobody reviewed the need for.

  3. **A scheduled task must be in the operating table**, so that a job exists
     in the deployment and not in the document an operator reads at 3am.

  4. **A row in the operating table must be scheduled, or say it is not.** A row
     saying `make settle` runs daily, in a deployment where nothing runs it, is
     the finding this exists to close. A row may be marked deferred — the
     `DEFERRED` marker — and then it must carry a reason, because "not deployed"
     with no explanation is indistinguishable from an omission.

**The link between a table row and a task is the module it runs**, resolved
through the Makefile rather than by matching names. `make health-alerts` is
`python -m scripts.health_alerts` in the Makefile and
`["python", "-m", "scripts.health_alerts"]` in the task definition, and neither
of those is a name somebody typed twice. A guard that matched
`aws_ecs_task_definition "health"` against the string `health-alerts` would be a
guard that a rename makes vacuous, which is the defect
`scripts/guard_task_credentials.py` was written to replace.

Usage:

    scripts/deployed_workers.py
    scripts/deployed_workers.py --json

Exit codes: 0 when the four agree, 1 when they do not, 2 when the check could
not run — a missing table, an unreadable Makefile. A check that examined nothing
is not a pass; see `scripts/guard_lib.sh` for the same rule.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))

from scripts.task_environment import task_definitions  # noqa: E402

#: The heading the operating table sits under, and the marker a row uses to say
#: it is deliberately not deployed.
TABLE_HEADING = "### The scheduled jobs"
DEFERRED = "DEFERRED"


def module_of(command: tuple[str, ...]) -> str | None:
    """The `scripts.X` a `python -m` command runs, ignoring its arguments.

    The module and not the argv, because the deployed comparison task passes
    `--json` and `make comparison-report` does not — the same job, formatted for
    a log rather than for a person. Comparing full command lines would have
    failed on that and taught whoever hit it to loosen the check.
    """
    for i, word in enumerate(command):
        if word == "-m" and i + 1 < len(command):
            return command[i + 1]
    return None


def make_targets(makefile: Path) -> dict[str, str]:
    """Every `make` target that runs a script, and the module it runs.

    Read from the recipe rather than from the target's name: `make settle` runs
    `scripts.settle_packs`, and a check that assumed the two matched would be a
    check that a rename makes vacuous.
    """
    text = makefile.read_text()
    found: dict[str, str] = {}
    target = None
    for line in text.splitlines():
        header = re.match(r"^([a-z][a-z0-9-]*):", line)
        if header:
            target = header.group(1)
            continue
        if not line.startswith("\t"):
            target = None
            continue
        if target is None:
            continue
        module = re.search(r"-m\s+(scripts\.[A-Za-z0-9_]+)", line)
        if module and target not in found:
            found[target] = module.group(1)
    return found


def operating_table(deployment_md: Path) -> list[dict[str, str]]:
    """Every row of the operating table, as `{command, cadence, deferred, row}`."""
    text = deployment_md.read_text()
    if TABLE_HEADING not in text:
        raise ValueError(
            f"{deployment_md} has no {TABLE_HEADING!r} section, so there is no "
            "operating table to check anything against."
        )
    after = text.split(TABLE_HEADING, 1)[1]
    # Up to the next heading of the same level or higher.
    after = re.split(r"\n#{1,3} ", after, maxsplit=1)[0]

    rows = []
    seen: dict[str, str] = {}
    for line in after.splitlines():
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if len(cells) < 2 or not cells[0].startswith("`make "):
            continue
        command = cells[0].strip("`").removeprefix("make ").strip()
        if command in seen:
            # H4. Two rows for one command is a document that says two things
            # about the same job — a cadence changed in one place and not the
            # other, most likely — and the checks below read it into a
            # dictionary, where the second silently replaced the first. An
            # operator at 3am reads whichever row their eye lands on.
            raise ValueError(
                f"the operating table has two rows for `make {command}`:\n"
                f"  {seen[command]}\n  {line.strip()}\n"
                "One job, one row. Two rows say two things about the same job "
                "and this check would have read only the second."
            )
        seen[command] = line.strip()
        rows.append(
            {
                "command": command,
                "cadence": cells[1],
                "deferred": DEFERRED in line,
                "row": line.strip(),
            }
        )
    if not rows:
        raise ValueError(
            f"the operating table under {TABLE_HEADING!r} holds no rows. A check "
            "that examined nothing must not report a pass."
        )
    return rows


def scheduled_and_permitted(infra_dir: Path) -> tuple[dict[str, str], set[str]]:
    """What is actually deployed: scheduled modules, and the policy's list.

    Returns `{module: resource}` for every task definition an
    `aws_cloudwatch_event_target` points at, and the set of resource names the
    scheduler policy names.
    """
    tasks = task_definitions(infra_dir)
    text = "\n".join(path.read_text() for path in sorted(infra_dir.rglob("*.tf")))

    targeted = set(
        re.findall(
            r"task_definition_arn\s*=\s*aws_ecs_task_definition\.([A-Za-z0-9_-]+)\.arn",
            text,
        )
    )
    policy_block = re.search(
        r'resource\s+"aws_iam_role_policy"\s+"watch_scheduler"(.*?)\n\}\n',
        text,
        flags=re.S,
    )
    if policy_block is None:
        raise ValueError(
            "no aws_iam_role_policy.watch_scheduler in the infrastructure. The "
            "rule this check enforces is stated against that resource by name."
        )
    permitted = set(
        re.findall(
            r"aws_ecs_task_definition\.([A-Za-z0-9_-]+)\.arn_without_revision",
            policy_block.group(1),
        )
    )

    scheduled: dict[str, str] = {}
    for resource in sorted(targeted):
        task = tasks.get(resource)
        module = module_of(task.command) if task else None
        if module is None:
            continue
        if module in scheduled:
            # H4. This used to be a bare assignment, so a second schedule for
            # the same module overwrote the first and the report described one
            # of them. Two schedules for one job is either a duplicate nobody
            # meant or two cadences fighting each other, and both are things to
            # be told about rather than to have collapsed.
            raise ValueError(
                f"aws_ecs_task_definition.{resource} and "
                f"aws_ecs_task_definition.{scheduled[module]} both run {module} "
                "on a schedule. One job with two schedules runs twice at "
                "cadences nothing reconciles, and the operating table can "
                "describe only one of them."
            )
        scheduled[module] = resource
    return scheduled, permitted


def check(
    *, infra_dir: Path, makefile: Path, deployment_md: Path
) -> tuple[list[str], dict]:
    """Every disagreement, as sentences. Empty means the four agree."""
    problems: list[str] = []

    targets = make_targets(makefile)
    rows = operating_table(deployment_md)
    scheduled, permitted = scheduled_and_permitted(infra_dir)
    tasks = task_definitions(infra_dir)

    targeted_resources = set(scheduled.values())

    # 1 and 2: the schedules and the policy.
    for module, resource in sorted(scheduled.items(), key=lambda kv: kv[1]):
        if resource not in permitted:
            problems.append(
                f"aws_ecs_task_definition.{resource} is scheduled and is not in "
                "aws_iam_role_policy.watch_scheduler. That is a schedule that "
                "exists and is denied every time it fires — nothing in a plan "
                f"says so. It runs {module}."
            )
    for resource in sorted(permitted - targeted_resources):
        problems.append(
            f"aws_iam_role_policy.watch_scheduler permits "
            f"aws_ecs_task_definition.{resource} and nothing schedules it. "
            "Permission to run something nothing runs is permission nobody "
            "reviewed the need for."
        )

    # 3 and 4: the schedules and the operating table.
    documented: dict[str, dict[str, str]] = {}
    for row in rows:
        module = targets.get(row["command"])
        if module is None:
            problems.append(
                f"the operating table names `make {row['command']}`, which is "
                "not a Makefile target that runs a script. The table and the "
                "deployment are linked by the module a target runs, so a row "
                "naming nothing runnable cannot be checked against anything."
            )
            continue
        if module in documented:
            # H4, the second collapse and the more interesting one. The rows
            # here have *different commands* and resolve to the same module —
            # two `make` targets running one script, documented as if they were
            # two jobs. This was `documented[module] = row`, so the first was
            # dropped: a row could be marked DEFERRED and a second row for the
            # same script could claim it runs nightly, and whichever came last
            # decided what this check believed.
            problems.append(
                f"the operating table documents {module} twice — as "
                f"`make {documented[module]['command']}` and as "
                f"`make {row['command']}`. Every check below links a row to the "
                "deployment through the module its target runs, so two rows for "
                "one module is two answers to every question this asks. Give "
                "the job one row."
            )
            continue
        documented[module] = row

    for module, resource in sorted(scheduled.items(), key=lambda kv: kv[1]):
        row = documented.get(module)
        if row is None:
            problems.append(
                f"aws_ecs_task_definition.{resource} runs {module} on a "
                "schedule and is not in docs/deployment.md's operating table. A "
                "job that exists in the deployment and not in the document "
                "somebody reads at 3am is a job nobody knows to look at."
            )
        elif row["deferred"]:
            problems.append(
                f"the operating table marks `make {row['command']}` as "
                f"{DEFERRED} and aws_ecs_task_definition.{resource} schedules "
                "it. One of the two is wrong and the document is the one an "
                "operator believes."
            )

    for module, row in sorted(documented.items()):
        if module in scheduled:
            continue
        if row["deferred"]:
            # Deferred is allowed and must be explained. "Not deployed" with no
            # reason beside it is indistinguishable from an omission, which is
            # the thing this check exists to make impossible.
            if len(row["row"].split(DEFERRED, 1)[1].strip(" |")) < 20:
                problems.append(
                    f"`make {row['command']}` is marked {DEFERRED} in the "
                    "operating table with no reason beside it. A deferral "
                    "without a reason reads exactly like an omission."
                )
            continue
        problems.append(
            f"the operating table says `make {row['command']}` runs "
            f"{row['cadence']!r}, and nothing in infra/ schedules "
            f"{module}. That is the finding this check exists to close: "
            f"a job the document promises and the deployment does not run. "
            f"Deploy it, or mark the row {DEFERRED} with the reason."
        )

    report = {
        "tasks": sorted(tasks),
        "scheduled": dict(scheduled),
        "permitted": sorted(permitted),
        "documented": sorted(row["command"] for row in rows),
        "deferred": sorted(row["command"] for row in rows if row["deferred"]),
        "problems": problems,
    }
    return problems, report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--infra-dir", default=str(REPO / "infra"))
    parser.add_argument("--makefile", default=str(REPO / "Makefile"))
    parser.add_argument("--deployment", default=str(REPO / "docs" / "deployment.md"))
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    try:
        problems, report = check(
            infra_dir=Path(args.infra_dir),
            makefile=Path(args.makefile),
            deployment_md=Path(args.deployment),
        )
    except (FileNotFoundError, ValueError) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(report, indent=2))
    elif problems:
        for problem in problems:
            print(f"FAIL: {problem}")
            print()
    else:
        print(
            f"OK: {len(report['scheduled'])} scheduled task(s) — "
            f"{', '.join(sorted(report['scheduled'].values()))} — each in the "
            "scheduler policy and in docs/deployment.md's operating table"
            + (
                f"; {len(report['deferred'])} row(s) deferred with a reason: "
                f"{', '.join(report['deferred'])}."
                if report["deferred"]
                else "."
            )
        )

    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
