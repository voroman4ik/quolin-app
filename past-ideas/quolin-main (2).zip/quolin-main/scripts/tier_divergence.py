"""Shared and dedicated are the same system with different variables.

Stage 11's claim is that a dedicated stack is an *instantiation* of the same
Terraform, not a variant of it, and that the application is identical in both.
Isolation is row-level security, which is on in both tiers.

`guard_no_tier_divergence.sh` was two greps and audit G-06 named four ways past
them. Reproduced: all four pass.

    tier != "shared"                      # the complement, not the literal
    tier in ("dedicated",)                # membership, not equality
    local derived from var.tenancy        # the branch is one name away
    the same under infra/envs/ or modules # only infra/*.tf was scanned

The first two are the same defect: the guard looked for `== "dedicated"` and a
branch can be written round it without trying. The third is the interesting one
— `count = local.is_dedicated ? 1 : 0` mentions neither `var.tenancy` nor a tier
name, and `local.is_dedicated = contains(["dedicated"], var.tenancy)` is where
the fork actually is.

**So this follows the reference rather than matching a spelling.**

  * Every tier literal, and every comparison against one, in `api/app` and in
    the whole of `infra/**` rather than `infra/*.tf`.
  * Every `local` whose expression mentions `var.tenancy`, transitively: a local
    referring to a tainted local is tainted.
  * Any `count` or `for_each` referring to `var.tenancy` **or to a tainted
    local**, which is the case the greps could not reach.

Not `tofu show -json`, deliberately. That needs `init`, a provider download and
a plan, so a guard built on it runs in one CI job and not on a laptop — and this
has to be cheap enough that people run it before pushing.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]

#: What a customer can buy. Both literals, so their complements are covered too.
TIERS = ("shared", "dedicated")

#: The variable the whole question turns on.
TENANCY = "var.tenancy"

#: Lines in `infra/` that mention `var.tenancy` legitimately: the declaration
#: itself and its own validation block.
INFRA_ALLOWED = re.compile(r'variable\s+"tenancy"|condition\s*=|error_message\s*=')

#: A `local` assignment: `  name = <expression>`, inside a `locals {}` block.
LOCAL_ASSIGNMENT = re.compile(r"^\s*([a-zA-Z_][a-zA-Z0-9_-]*)\s*=\s*(.+)$")


def _strip_comments(text: str) -> str:
    """Terraform and Python both use `#`. A note explaining the rule is not a branch."""
    return "\n".join(re.sub(r"#.*$", "", line) for line in text.splitlines())


def tainted_locals(infra: Path) -> set[str]:
    """Local values that depend on `var.tenancy`, followed to a fixed point."""
    assignments: dict[str, str] = {}
    for path in sorted(infra.rglob("*.tf")):
        text = _strip_comments(path.read_text())
        for block in re.finditer(r"locals\s*\{(.*?)\n\}", text, re.S):
            for line in block.group(1).splitlines():
                match = LOCAL_ASSIGNMENT.match(line)
                if match:
                    assignments[match.group(1)] = match.group(2)

    tainted = {name for name, expr in assignments.items() if TENANCY in expr}
    changed = True
    while changed:
        changed = False
        for name, expr in assignments.items():
            if name in tainted:
                continue
            if any(f"local.{other}" in expr for other in tainted):
                tainted.add(name)
                changed = True
    return tainted


def check_infra(infra: Path) -> list[str]:
    problems: list[str] = []
    files = sorted(infra.rglob("*.tf"))
    if not files:
        raise FileNotFoundError(f"no Terraform under {infra}")

    tainted = tainted_locals(infra)

    for path in files:
        where = path.relative_to(infra.parent) if infra.parent in path.parents else path
        for number, line in enumerate(_strip_comments(path.read_text()).splitlines(), 1):
            if not line.strip():
                continue

            # A resource whose existence depends on the tier, directly or through
            # any number of locals.
            if re.search(r"\b(count|for_each)\s*=", line):
                if TENANCY in line:
                    problems.append(
                        f"{where}:{number}: a resource's existence depends on "
                        f"{TENANCY}. Dedicated is the same Terraform with "
                        "different variables; a resource that exists in one tier "
                        "only is a fork."
                    )
                for name in sorted(tainted):
                    if f"local.{name}" in line:
                        problems.append(
                            f"{where}:{number}: a resource's existence depends on "
                            f"local.{name}, which is derived from {TENANCY}. "
                            "The branch is one name away from the variable, "
                            "which is exactly where a grep stops looking."
                        )

            # A comparison against the variable, in either direction.
            if re.search(rf"{re.escape(TENANCY)}\s*[=!]=|[=!]=\s*{re.escape(TENANCY)}", line):
                if not INFRA_ALLOWED.search(line):
                    problems.append(
                        f"{where}:{number}: infrastructure branches on {TENANCY}."
                    )

    return problems


def check_app(app: Path) -> list[str]:
    problems: list[str] = []
    files = sorted(app.rglob("*.py"))
    if not files:
        raise FileNotFoundError(f"no Python under {app}")

    # Both literals and both directions. The old guard looked for `"dedicated"`
    # alone, so `tier != "shared"` — the same branch, written the other way
    # round — passed it.
    comparisons = [
        re.compile(rf'[=!]=\s*["\']{tier}["\']') for tier in TIERS
    ] + [
        re.compile(rf'["\']{tier}["\']\s*[=!]=') for tier in TIERS
    ] + [
        # `tier in ("dedicated",)` and `tier not in {"shared"}`.
        re.compile(rf'\bin\s*[\(\[\{{][^)\]}}]*["\']{tier}["\']') for tier in TIERS
    ]
    environment = re.compile(r"QUOLIN_TENANCY|tenancy_mode")

    for path in files:
        for number, line in enumerate(_strip_comments(path.read_text()).splitlines(), 1):
            stripped = line.strip()
            if not stripped or stripped.startswith(('"""', "'''", "#", "*", ":")):
                continue
            if environment.search(line) or any(p.search(line) for p in comparisons):
                problems.append(
                    f"{path.relative_to(app.parent.parent)}:{number}: application "
                    "code knows which tier it is running in — "
                    f"{stripped[:70]}. The application is identical in both "
                    "tiers; that is the whole claim."
                )
    return problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--infra-dir", default=str(REPO / "infra"))
    parser.add_argument("--app-dir", default=str(REPO / "api" / "app"))
    args = parser.parse_args(argv)

    infra, app = Path(args.infra_dir), Path(args.app_dir)
    for name, path in (("infrastructure", infra), ("application", app)):
        if not path.is_dir():
            print(f"FAIL: no {name} directory at {path}.")
            print()
            print("A scan of nothing is not a clean scan.")
            return 1

    try:
        problems = check_infra(infra) + check_app(app)
    except FileNotFoundError as exc:
        print(f"FAIL: {exc}")
        return 1

    if problems:
        for problem in problems:
            print(f"FAIL: {problem}")
        print()
        print(
            "Stage 11 promises dedicated is an instantiation of the same "
            "Terraform, not a variant of it. If a dedicated stack genuinely "
            "needs different behaviour, it is a different product and the sales "
            "page should say so."
        )
        return 1

    tainted = tainted_locals(infra)
    note = f" ({len(tainted)} local(s) derived from {TENANCY}, none gating a resource)"
    print(
        "OK: shared and dedicated differ by variables only — no tier branches in "
        f"{infra} or {app}{note if tainted else ''}."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
