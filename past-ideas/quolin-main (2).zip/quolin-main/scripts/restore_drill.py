"""
Restore the database into a clean one and verify the evidence chain in it.

§S9: *a backup that has not been restored is a hope*, and the gate is that the
restore drill passes **with chains verified**. That second half is what makes
this a drill rather than a file-copy test: a backup that restores into a
database whose hash chain does not verify has restored bytes and lost the thing
those bytes were for.

**Chain verification is the success criterion, not a step in it.** A restore
that completes and leaves a chain that does not verify is a failed restore, and
this exits non-zero for it.

**It measures itself.** §S9 sets RTO 4h and RPO 15min as targets "measured by
the drill, recorded for SOC 2". What is measured here is the restore itself —
dump, create, load, verify — which is the part of an RTO that this repository
can honestly measure. The rest of a real RTO is detection, decision and DNS, and
it is dishonest to report those from a laptop; the drill says so in its output
rather than quietly counting the easy part as the whole.

**It never touches the database it read from.** The restore goes into a database
named for the drill, which is dropped afterwards unless `--keep` says otherwise.

Usage:

    make restore-drill
    make restore-drill ARGS="--keep --json"

Exit codes: 0 if the restore completed and the chain verified, 1 if the drill
could not run, 2 if the chain did not verify in the restored copy — which is the
finding the drill exists to produce.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse, urlunparse

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from scripts import evidence_io  # noqa: E402
from sqlalchemy import create_engine, func, select, text  # noqa: E402

from app import evidence, observability, tenancy  # noqa: E402
from app.db import APP_DATABASE_URL, OWNER_DATABASE_URL  # noqa: E402
from app.models import Decision, Tenant  # noqa: E402

#: Where the restored copy goes. Named so that finding it in a database listing
#: answers the question of what it is without anybody having to ask.
DRILL_DB = "quolin_restore_drill"

#: The targets §S9 sets. Recorded beside the measurement so the output is
#: readable without the specification open.
RTO_TARGET_SECONDS = 4 * 60 * 60
RPO_TARGET_SECONDS = 15 * 60

#: The container Postgres runs in locally, used when `psql` is not on the host.
#:
#: Not a fallback for convenience: running the tools *inside* the server's own
#: container means the drill uses exactly the pg_dump that matches the server,
#: which is the pairing operations would use and the one where version skew
#: cannot quietly corrupt a restore. A developer without libpq installed still
#: gets a real drill rather than a skipped one.
CONTAINER = os.getenv("QUOLIN_DB_CONTAINER", "quolin-db")


def _psql_url(url: str, database: str) -> str:
    """The same server, a different database, in libpq's own URL form."""
    parsed = urlparse(url.replace("postgresql+psycopg://", "postgresql://"))
    return urlunparse(parsed._replace(path=f"/{database}"))


def _run(command: list[str], **kwargs) -> subprocess.CompletedProcess:
    return subprocess.run(command, capture_output=True, text=True, **kwargs)


def _have(tool: str) -> bool:
    return _run(["which", tool]).returncode == 0


def _container_is_up() -> bool:
    result = _run(["docker", "ps", "--filter", f"name={CONTAINER}", "--format", "{{.Names}}"])
    return result.returncode == 0 and CONTAINER in result.stdout


def _tooling() -> tuple[list[str], str]:
    """How to reach Postgres's own tools, and how the URL must look to them.

    Two ways, and the second is not a lesser one. Where `psql` is on the host,
    use it. Where it is not — a laptop running Postgres in a container, which is
    this repository's own development setup — run the tools *inside* that
    container, which pairs each tool with exactly the server version it belongs
    to. Version skew between `pg_dump` and the server is one of the ways a
    restore silently loses something.
    """
    if _have("pg_dump") and _have("psql"):
        return [], "host"
    if _have("docker") and _container_is_up():
        return ["docker", "exec", "-i", CONTAINER], "container"
    raise RuntimeError(
        "Neither pg_dump/psql on PATH nor a running Postgres container "
        f"({CONTAINER}). The drill shells out to Postgres's own tools on "
        "purpose: restoring with anything other than what operations would use "
        "proves something about our code rather than about the backup."
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Restore into a clean database and verify.")
    parser.add_argument("--keep", action="store_true", help="leave the restored copy behind")
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    observability.configure()
    source_url = os.getenv("DATABASE_URL", OWNER_DATABASE_URL)
    admin_url = _psql_url(source_url, "postgres")
    drill_url = _psql_url(source_url, DRILL_DB)

    prefix, how = _tooling()
    if how == "container":
        # Inside the container the server is local, whatever the host's port
        # mapping says.
        def inside(url: str) -> str:
            return (
                url.replace(":5433", ":5432")
                .replace("@localhost", "@127.0.0.1")
                .replace("postgresql+psycopg://", "postgresql://")
            )

        admin_url = inside(_psql_url(source_url, "postgres"))
        drill_url = inside(_psql_url(source_url, DRILL_DB))
        source_for_dump = inside(source_url)
    else:
        source_for_dump = source_url.replace("postgresql+psycopg://", "postgresql://")

    started = time.monotonic()
    steps: list[dict] = []

    def step(name: str, command: list[str], **kwargs) -> subprocess.CompletedProcess:
        at = time.monotonic()
        result = _run(prefix + command, **kwargs)
        steps.append(
            {
                "step": name,
                "seconds": round(time.monotonic() - at, 2),
                "ok": result.returncode == 0,
            }
        )
        if result.returncode != 0:
            raise RuntimeError(f"{name} failed: {result.stderr.strip()[:400]}")
        return result

    try:
        # What the source holds, so the restored copy can be compared against it
        # rather than merely inspected. A restore that silently dropped half the
        # determinations would verify a shorter chain perfectly well.
        # Counted per tenant, through the *application* role — the same lens the
        # restored copy is read through below.
        #
        # As the owner this was wrong in a way that looked right: `quolin` is a
        # superuser and bypasses row-level security, so every tenant's count came
        # back as the whole table and five tenants summed to five times the
        # truth. Both sides of a comparison have to be measured the same way, or
        # the comparison is between two different questions.
        from app.db import OwnerSessionLocal, SessionLocal

        with tenancy.acting_as(tenancy.configured_tenant()):
            probe = OwnerSessionLocal()
            try:
                tenants = list(probe.scalars(select(Tenant.id).order_by(Tenant.id)))
            finally:
                probe.close()

        expected = 0
        newest = None
        for tenant_id in tenants:
            with tenancy.acting_as(tenant_id):
                probe = SessionLocal()
                try:
                    expected += probe.scalar(
                        select(func.count()).select_from(Decision)
                    ) or 0
                    latest = probe.scalar(
                        select(Decision.created_at).order_by(Decision.id.desc()).limit(1)
                    )
                    if latest and (newest is None or latest > newest):
                        newest = latest
                finally:
                    probe.close()

        drop = f'DROP DATABASE IF EXISTS "{DRILL_DB}"'
        step("drop any previous drill copy", ["psql", admin_url, "-c", drop])
        step(
            "create the clean database",
            ["psql", admin_url, "-c", f'CREATE DATABASE "{DRILL_DB}"'],
        )

        # Ownership and grants included, deliberately. Dropping them makes the
        # dump easier to load and produces a copy that is not the database that
        # was backed up: no grants means the application role cannot read it,
        # and a restore nobody can connect to as the application is not a
        # restore. It also hides the finding below.
        dump = step("dump the source", ["pg_dump", source_for_dump])
        loaded = _run(
            prefix + ["psql", drill_url, "-v", "ON_ERROR_STOP=1", "-q"],
            input=dump.stdout,
        )
        steps.append(
            {"step": "load into the copy", "seconds": None, "ok": loaded.returncode == 0}
        )
        if loaded.returncode != 0:
            raise RuntimeError(f"load failed: {loaded.stderr.strip()[:400]}")

        # The success criterion. Verified *in the restored copy*, connecting to
        # it directly, because verifying the original would prove nothing about
        # the backup.
        # Verified **as the application role**, not as the owner.
        #
        # This is the single most important line in the drill, and it was wrong
        # first. `quolin` is a superuser, and a superuser bypasses row-level
        # security entirely — so verifying as the owner reads every tenant's
        # determinations as one undifferentiated set. The chain check would then
        # walk four customers' chains spliced together and report whatever it
        # found, on a database whose isolation had not been tested at all.
        #
        # The application role is not a superuser, holds no BYPASSRLS, and does
        # not own the tables. Reading the restored copy as it is what makes
        # "the chains verify" mean the thing it is supposed to mean.
        restored = create_engine(
            _psql_url(APP_DATABASE_URL, DRILL_DB).replace(
                "postgresql://", "postgresql+psycopg://"
            ),
            future=True,
        )
        chains: dict[str, dict] = {}
        empty: list[str] = []
        found = 0

        # Asserted rather than assumed: if the role the drill verifies as could
        # bypass row-level security, everything below would be theatre.
        with create_engine(
            _psql_url(APP_DATABASE_URL, DRILL_DB).replace(
                "postgresql://", "postgresql+psycopg://"
            ),
            future=True,
        ).connect() as probe_conn:
            attributes = probe_conn.execute(
                text(
                    "SELECT rolsuper, rolbypassrls FROM pg_roles "
                    "WHERE rolname = current_user"
                )
            ).one()
            if attributes.rolsuper or attributes.rolbypassrls:
                raise RuntimeError(
                    "the role verifying the restore can bypass row-level "
                    "security, so every tenant's determinations would be read "
                    "as one chain. Verify as the application role."
                )
        try:
            from sqlalchemy.orm import Session as RawSession

            with RawSession(restored) as session:
                for tenant_id in tenants:
                    # The chain is per tenant, so it is verified per tenant. A
                    # single pass over every row would splice four customers'
                    # chains together and call the result verified.
                    #
                    # Both halves of the tenant have to be set: the Postgres
                    # setting that row-level security reads, *and* the process
                    # context that `verify_chain` reads to know whose tip it is
                    # comparing against. Setting only the first one gets as far
                    # as the query and then raises.
                    session.execute(
                        text("SELECT set_config('app.tenant_id', :t, false)"),
                        {"t": tenant_id},
                    )
                    with tenancy.acting_as(tenant_id):
                        held = session.scalar(
                            select(func.count()).select_from(Decision)
                        ) or 0
                        found += held
                        if not held:
                            # A tenant with no determinations has no chain to
                            # verify — the platform tenant is one, and so is a
                            # customer who has been provisioned and has not
                            # started. Reporting "no anchor" as a failed restore
                            # would fail every drill forever, for a database
                            # that is in exactly the state it should be in.
                            empty.append(tenant_id)
                            continue
                        chains[tenant_id] = evidence.verify_chain(session)
        finally:
            restored.dispose()
    except Exception as exc:  # noqa: BLE001 — a drill reports rather than crashes
        print(f"restore drill could not run: {exc}", file=sys.stderr)
        return 1
    finally:
        if not args.keep:
            _run(
                prefix
                + ["psql", admin_url, "-c", f'DROP DATABASE IF EXISTS "{DRILL_DB}"']
            )

    elapsed = time.monotonic() - started
    broken = {t: c for t, c in chains.items() if not c.get("verified")}
    complete = found == expected
    # The freshest determination in the copy against now: the closest thing to
    # an RPO this drill can honestly measure, since it restores from a dump
    # taken at the moment it ran rather than from a snapshot with real lag.
    staleness = (
        (datetime.now(timezone.utc) - newest).total_seconds() if newest else None
    )

    report = {
        "restored_database": DRILL_DB,
        "seconds": round(elapsed, 2),
        "rto_target_seconds": RTO_TARGET_SECONDS,
        "within_rto": elapsed <= RTO_TARGET_SECONDS,
        "rpo_target_seconds": RPO_TARGET_SECONDS,
        "determinations_expected": expected,
        "determinations_restored": found,
        "complete": complete,
        "chains": {
            t: {"verified": c.get("verified"), "checked": c.get("checked")}
            for t, c in chains.items()
        },
        "verified": not broken and complete,
        "no_evidence": sorted(empty),
        "steps": steps,
        "measures": (
            "The elapsed time is the restore itself: dump, create, load, verify. "
            "A real recovery-time objective also contains detection, the decision "
            "to fail over, and DNS — none of which a drill on one machine can "
            "measure, and none of which is counted here."
        ),
    }

    if args.json:
        print(json.dumps(report, indent=2, default=str))
    else:
        print(f"restore drill — into {DRILL_DB}\n")
        for entry in steps:
            seconds = f"{entry['seconds']}s" if entry["seconds"] is not None else "—"
            print(f"  {'ok' if entry['ok'] else 'FAILED':>6}  {entry['step']:<30} {seconds:>8}")
        print()
        print(f"  determinations   {found} restored of {expected}")
        for tenant_id, chain in sorted(chains.items()):
            state = "verified" if chain.get("verified") else "NOT VERIFIED"
            print(f"  chain {tenant_id:<10} {state} ({chain.get('checked')} records recomputed)")
        for tenant_id in sorted(empty):
            print(f"  chain {tenant_id:<10} nothing to verify — holds no determinations")
        print()
        print(f"  restore took     {elapsed:.1f}s against a {RTO_TARGET_SECONDS // 3600}h target")
        if staleness is not None:
            print(f"  newest record    {staleness / 60:.0f} minutes old at restore time")
        print(f"\n  {report['measures']}")

    if args.evidence_out:
        evidence_io.write(
            "drills",
            "restore-drill",
            report,
            passed=complete and not broken,
            summary=(
                f"Restored into a clean database; {found} of {expected} "
                "determinations present, "
                + (
                    "every chain in the copy verified."
                    if not broken
                    else "chains did NOT verify: " + ", ".join(sorted(broken))
                )
            ),
        )

    if not complete:
        print(
            f"the copy holds {found} determinations and the source holds {expected}",
            file=sys.stderr,
        )
        return 2
    if broken:
        print(
            "the chain does not verify in the restored copy: "
            + ", ".join(sorted(broken)),
            file=sys.stderr,
        )
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
