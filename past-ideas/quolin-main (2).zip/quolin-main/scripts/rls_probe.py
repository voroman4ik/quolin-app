"""
Prove tenant isolation is armed on a specific database, without writing to it.

§S11's gate asks that a dedicated stack pass "the full smoke + RLS suite
(trivially - one tenant - but run it)". `api/tests/test_rls.py` is that suite and
it is the right thing to run against a stack that holds nothing yet: it
provisions a second tenant and proves neither can see the other, which is the
only way to prove isolation properly.

It is the wrong thing to run against a stack that has been handed over. It
writes, and what it writes is a fake customer inside a real customer's database.

So this exists as well: the same guarantees checked by inspection rather than by
experiment, writing nothing, safe to run against production on a Tuesday
afternoon. It answers a narrower question — "is the machinery switched on here"
rather than "does it work" — and the two are used at different times. The
runbook says which, and when.

What it checks, and why each one is a way isolation has actually been lost
somewhere before:

1. The application role is not a superuser and cannot bypass row-level
   security. A superuser walks past every policy in this file silently — Stage 9
   found a restore drill that verified as the owner and therefore proved
   nothing.
2. Every policed table has row-level security **enabled and forced**. Merely
   enabled exempts the table's owner, which is the same hole wearing a hat.
3. Every policed table has at least one policy. Enabled-and-forced with no
   policy denies everything, which is fail-closed and also broken; it is worth
   telling those two apart before a customer does.
4. A connection that has set no tenant sees nothing. Fail-closed is the property
   the whole design rests on, and it is one `USING (true)` away from gone.
5. A connection claiming a tenant that does not exist sees nothing.
6. Optionally, with the owner's connection string: the number of tenants matches
   what this deployment claims to be. A "dedicated" stack holding two customers
   is a sales claim that has quietly stopped being true.

Usage:

    make rls-probe
    APP_DATABASE_URL=... DATABASE_URL=... python -m scripts.rls_probe --tenancy dedicated

Exit codes: 0 when isolation is armed, 1 when the probe could not run, 2 when
something is wrong.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from scripts import evidence_io  # noqa: E402
from sqlalchemy import create_engine, text  # noqa: E402

from app.models import PLATFORM_TABLES, TENANT_SCOPED_TABLES  # noqa: E402

#: The same classification the suite uses, imported rather than restated. Two
#: copies of this list would agree until somebody added a table.
POLICED = list(TENANT_SCOPED_TABLES) + list(PLATFORM_TABLES)

#: A tenant id that cannot exist. Used to check that claiming a tenant is not
#: the same as being one.
NOBODY = "no-such-tenant-probe"


def _finding(results: list, name: str, ok: bool, note: str) -> bool:
    results.append((name, ok, note))
    return ok


def probe(app_url: str, owner_url: str, tenancy: str) -> list[tuple[str, bool, str]]:
    results: list[tuple[str, bool, str]] = []
    engine = create_engine(app_url, pool_pre_ping=True)

    with engine.connect() as conn:
        who = conn.execute(text("select current_user")).scalar_one()
        role = conn.execute(
            text(
                "select rolsuper, rolbypassrls from pg_roles where rolname = :r"
            ),
            {"r": who},
        ).one()
        _finding(
            results,
            "the application role cannot bypass isolation",
            not role.rolsuper and not role.rolbypassrls,
            f"{who}: superuser={role.rolsuper}, bypassrls={role.rolbypassrls}",
        )

        state = {
            name: (enabled, forced)
            for name, enabled, forced in conn.execute(
                text(
                    "select relname, relrowsecurity, relforcerowsecurity "
                    "from pg_class where relname = any(:names)"
                ),
                {"names": POLICED},
            ).all()
        }
        missing = [t for t in POLICED if t not in state]
        unprotected = [t for t in POLICED if state.get(t, (False, False)) != (True, True)]
        _finding(
            results,
            "every policed table exists",
            not missing,
            f"{len(state)}/{len(POLICED)} present"
            + (f"; absent: {missing}" if missing else ""),
        )
        _finding(
            results,
            "row-level security is enabled and forced everywhere",
            not unprotected,
            "all tables enabled and forced"
            if not unprotected
            else f"not enabled and forced on: {unprotected}",
        )

        with_policies = {
            name
            for (name,) in conn.execute(
                text("select distinct tablename from pg_policies where tablename = any(:names)"),
                {"names": POLICED},
            ).all()
        }
        without = [t for t in POLICED if t in state and t not in with_policies]
        _finding(
            results,
            "every policed table has a policy",
            not without,
            "all tables carry at least one policy"
            if not without
            else f"forced with no policy, so denying everything: {without}",
        )

    # Fail-closed, checked on connections of their own. `app.tenant_id` binds at
    # transaction begin, so each of these opens its own — reusing one would
    # read whatever the previous transaction set and quietly pass.
    for label, setting in (
        ("a connection with no tenant sees nothing", None),
        ("a connection claiming a tenant that does not exist sees nothing", NOBODY),
    ):
        with engine.connect() as conn:
            if setting is not None:
                conn.execute(
                    text("select set_config('app.tenant_id', :t, false)"), {"t": setting}
                )
            visible = {}
            for table in TENANT_SCOPED_TABLES:
                if table not in state:
                    continue
                count = conn.execute(
                    text(f"select count(*) from {table}")  # noqa: S608 — from a fixed list
                ).scalar_one()
                if count:
                    visible[table] = count
            _finding(
                results,
                label,
                not visible,
                "nothing visible" if not visible else f"visible anyway: {visible}",
            )

    if owner_url:
        owner = create_engine(owner_url, pool_pre_ping=True)
        with owner.connect() as conn:
            tenants = conn.execute(text("select count(*) from tenants")).scalar_one()
        expected_one = tenancy == "dedicated"
        _finding(
            results,
            "the tenant count matches what this deployment claims to be",
            (tenants == 1) if expected_one else tenants >= 1,
            f"tenancy={tenancy}, {tenants} tenant(s)"
            + (
                " — a dedicated stack holding more than one customer is a claim "
                "that has stopped being true"
                if expected_one and tenants != 1
                else ""
            ),
        )
    else:
        _finding(
            results,
            "the tenant count matches what this deployment claims to be",
            False,
            "not checked: the owner's connection string was not given, and the "
            "application role cannot count tenants it cannot see. A check that "
            "could not run is a blind spot, not an all-clear.",
        )

    return results


def main() -> int:
    parser = argparse.ArgumentParser(description="Prove isolation is armed here.")
    parser.add_argument(
        "--tenancy",
        default=os.getenv("QUOLIN_TENANCY", "shared"),
        choices=["shared", "dedicated"],
        help="what this deployment claims to be",
    )
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    app_url = os.getenv("APP_DATABASE_URL", "")
    owner_url = os.getenv("DATABASE_URL", "")
    if not app_url:
        print(
            "APP_DATABASE_URL is not set. This probe must connect as the "
            "application role — connecting as the owner would bypass every "
            "policy it is here to check, and report success.",
            file=sys.stderr,
        )
        return 1

    try:
        results = probe(app_url, owner_url, args.tenancy)
    except Exception as exc:  # noqa: BLE001 — a probe reports rather than crashes
        print(f"the probe could not run: {exc}", file=sys.stderr)
        return 1

    failed = [name for name, ok, _ in results if not ok]
    if args.json:
        print(
            json.dumps(
                {
                    "tenancy": args.tenancy,
                    "checks": [
                        {"name": n, "passed": ok, "note": note} for n, ok, note in results
                    ],
                    "failed": failed,
                },
                indent=2,
            )
        )
    else:
        print(f"rls probe — tenancy={args.tenancy}")
        for name, ok, note in results:
            print(f"  [{'ok ' if ok else 'FAIL'}] {name}")
            print(f"         {note}")
        print(f"  {len(results) - len(failed)}/{len(results)} passed")

    if args.evidence_out:
        evidence_io.write(
            "drills",
            "isolation-probe",
            {
                "tenancy": args.tenancy,
                "checks": [
                    {"name": n, "passed": ok, "note": note} for n, ok, note in results
                ],
                "failed": failed,
            },
            passed=not failed,
            summary=(
                f"{len(results) - len(failed)}/{len(results)} isolation checks "
                f"passed against a {args.tenancy} deployment."
            ),
        )
    return 2 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
