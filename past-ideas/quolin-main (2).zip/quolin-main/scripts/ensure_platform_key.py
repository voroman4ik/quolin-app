"""
Create the `_platform` data key on a database that already holds rows.

Migration 0007 inserts the reserved `_platform` tenant. It does not create that
tenant's data key, for the reason 0005 gives at length: key material never comes
from a migration, because a migration is a frozen snapshot that must never be
edited again, and a copy of the envelope made inside one would drift from the
one the application uses the first time the envelope changed.

In dev and in CI there is nothing here to do — `make seed` rebuilds from empty
and calls `crypto.ensure_key` for both the demo tenant and this one. This script
is for a deployment carrying real records across Stage 2, where the seed does
not run and the first attempt to enrol a second factor would otherwise fail with
`NoDataKey`.

Idempotent. Run it twice and the second run reports the key that already exists;
it never replaces one, because replacing it would make every enrolled second
factor permanently unreadable.

Usage:

    make platform-key            # report only
    make platform-key ARGS=--apply

Exit codes: 0 when the key exists (or would be created, on a report-only run),
1 when the schema is not ready or the write failed.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Same dual-layout dance as scripts/encrypt_existing.py: `api/` in the repo,
# flattened to the working directory inside the container.
_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from app import crypto, tenancy  # noqa: E402
from app.db import OwnerSessionLocal  # noqa: E402
from app.models import Tenant, TenantKey  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--apply",
        action="store_true",
        help="create the key. Without it, this only reports what it would do.",
    )
    args = parser.parse_args(argv)

    # Scoped to the platform tenant, not to a customer. `tenant_keys` is under
    # forced row-level security, so this is what makes the row reachable at all
    # — and it is why the script cannot accidentally write a key for anyone else.
    with tenancy.acting_as(crypto.PLATFORM_TENANT):
        session = OwnerSessionLocal()
        try:
            if session.get(Tenant, crypto.PLATFORM_TENANT) is None:
                print(
                    f"no {crypto.PLATFORM_TENANT!r} tenant row. Migration 0007 "
                    "creates it; run `alembic upgrade head` first.",
                    file=sys.stderr,
                )
                return 1

            if session.get(TenantKey, crypto.PLATFORM_TENANT) is not None:
                print(f"{crypto.PLATFORM_TENANT}: key already present, nothing to do")
                return 0

            if not args.apply:
                print(f"{crypto.PLATFORM_TENANT}: would create a data key (--apply to do it)")
                return 0

            crypto.ensure_key(session, crypto.PLATFORM_TENANT)
            session.commit()
            print(f"{crypto.PLATFORM_TENANT}: data key created")
            return 0
        finally:
            session.close()


if __name__ == "__main__":
    raise SystemExit(main())
