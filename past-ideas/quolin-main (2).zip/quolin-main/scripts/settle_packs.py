"""
Move packs whose date has arrived, and tell each tenant what that means for them.

Two transitions nobody performs. A draft becomes effective because a date
arrived, and an earlier version is superseded because a later one took over —
neither has a person behind it, and a state that changed silently at midnight
with no row to show for it would be a hole in the middle of the transition log.

    make settle                 # the deployment's own tenant
    make settle ARGS=--dry-run  # what would move, moving nothing
    make settle ARGS="acme beta"

Run it daily, after midnight in the deployment's region. It is idempotent and
works out what *should* have happened by now rather than what changed since it
last ran — so a sweep that was missed for a week catches up rather than skipping
the states nobody was there to record.

**It does not advance a pinned tenant.** It notices, which opens their window;
taking the version is theirs to do. A sweep that advanced them because a deadline
passed would be pinning in name only, and pinning is the answer to "how do you
control vendor changes?".

Exit codes: 0 always, unless the run could not complete (2). Nothing here is a
failure — a day with no moves is the normal case.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from app import advance, bulk, maintenance, tenancy  # noqa: E402

#: Who a scheduled settle acts as. A provisioned machine principal for the
#: reason Stage 6 established: an audit actor has to resolve to a row somebody
#: can be asked about, and this script now plans re-checks that write them.
SCHEDULE_ACTOR = "apc_bulk_sweep"
from app.db import OwnerSessionLocal, SessionLocal  # noqa: E402
from app.watch import lifecycle  # noqa: E402



def _every_active_firm() -> list[str]:
    """Every active customer, when no tenant was named.

    `tenancy.configured_tenant()` was the default, and on a shared deployment
    that is one firm out of however many — so this job ran, reported success,
    and served nobody else. Q-01's shape exactly: an enumeration that returns
    one thing and a caller that reads it as everything.

    The docstring above once said tenants are named and not discovered, "because
    under FORCE ROW LEVEL SECURITY a query for all tenants returns the one in
    scope". That was true and stopped being true at migration 0029, which
    created the `quolin_maintenance` grant precisely so a scheduled worker can
    ask. `scripts/artefact_worker.py` and `scripts/bulk_worker.py` have
    enumerated this way since; this is the same call, with the preflight
    `scripts/health_alerts.py` has and they do not.

    `assert_can_enumerate` first, because the failure mode without it is the one
    F12 named: a connection that cannot see `tenants` returns an empty list, the
    loop runs zero times, and the job exits 0 having done nothing.
    """
    session = OwnerSessionLocal()
    try:
        maintenance.assert_can_enumerate(session)
        return maintenance.active_tenant_ids(session)
    finally:
        session.close()

def main() -> int:
    parser = argparse.ArgumentParser(description="Settle pack lifecycle states.")
    parser.add_argument("tenants", nargs="*", help="Tenant ids. Defaults to the configured one.")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Report what would move without moving it.",
    )
    parser.add_argument("--json", action="store_true", help="Machine-readable output.")
    args = parser.parse_args()

    tenants = args.tenants or _every_active_firm()
    reports = []

    for tenant_id in tenants:
        # One session per tenant. `app.tenant_id` binds when a transaction
        # begins, so a session reused across the loop would settle the first
        # tenant's drafts under every subsequent heading.
        # A provisioned machine principal, not the bare string "schedule".
        # Planning a re-check writes audit rows, and an actor that resolves to
        # nothing is the bar Stage 2 deleted the shared placeholder officer for.
        with tenancy.acting_as(tenant_id), tenancy.acting_as_user(SCHEDULE_ACTOR):
            session = SessionLocal()
            try:
                moved = lifecycle.settle(session)
                # Captured before the sweep so that only versions noticed *now*
                # trigger a re-check. `advance.sweep` is idempotent and returns
                # the rows it already had, so planning from all of them would
                # queue a fresh sweep of the whole book every time this script
                # ran — which it does every day.
                before_sweep = datetime.now(timezone.utc)
                noticed = advance.sweep(session, tenant_id=tenant_id)
                staged = advance.pending(session)

                # §S8's first trigger: a version becoming effective re-checks
                # the book. What kind of run depends on the tenant's advance
                # policy — an auto tenant's determinations really do move, and a
                # pinned tenant gets the preview their review window is for.
                # See `bulk.on_pack_effective`.
                swept = []
                for row in (r for r in noticed if r.noticed_at >= before_sweep):
                    run = bulk.on_pack_effective(
                        session,
                        tenant_id=tenant_id,
                        jurisdiction=row.jurisdiction,
                        version=row.pack_version,
                        requested_by=SCHEDULE_ACTOR,
                    )
                    if run is not None:
                        swept.append(
                            {
                                "run_id": run.id,
                                "jurisdiction": row.jurisdiction,
                                "version": row.pack_version,
                                "dry_run": run.dry_run,
                                "pairs": run.pairs_total,
                            }
                        )

                # §S8's third trigger: a regime whose pack asks for a periodic
                # review, and has not had one within its own cadence.
                for code in bulk.periodic_due(session):
                    review = bulk.periodic_review(
                        session, jurisdiction=code, requested_by=SCHEDULE_ACTOR
                    )
                    if review is None:
                        # This tenant advises in no client in that regime. Not
                        # an error and not worth a row.
                        continue
                    swept.append(
                        {
                            "run_id": review.id,
                            "jurisdiction": code,
                            "version": None,
                            "dry_run": False,
                            "pairs": review.pairs_total,
                        }
                    )

                if args.dry_run:
                    session.rollback()
                else:
                    session.commit()

                reports.append(
                    {
                        "tenant_id": tenant_id,
                        "became_effective": moved["effective"],
                        "superseded": moved["superseded"],
                        "versions_noticed": len(noticed),
                        "sweeps_planned": swept,
                        "awaiting_review": [
                            {
                                "jurisdiction": s["jurisdiction"],
                                "version": s["pack_version"],
                                "days_left": s["days_left"],
                                "overdue": s["overdue"],
                            }
                            for s in staged
                        ],
                    }
                )
            except Exception as exc:
                session.rollback()
                print(
                    f"settle failed for {tenant_id}: {type(exc).__name__}: {exc}",
                    file=sys.stderr,
                )
                return 2
            finally:
                session.close()

    if args.json:
        print(json.dumps(reports, indent=2))
    else:
        for report in reports:
            print(f"\ntenant {report['tenant_id']}{' (dry run)' if args.dry_run else ''}")
            print(f"  became effective  {report['became_effective']}")
            print(f"  superseded        {report['superseded']}")
            waiting = report["awaiting_review"]
            if waiting:
                print(f"  awaiting review   {len(waiting)}:")
                for item in waiting:
                    when = (
                        "OVERDUE"
                        if item["overdue"]
                        else f"{item['days_left']} day(s) left"
                    )
                    print(f"    {item['jurisdiction']} v{item['version']:<3} {when}")
            else:
                print("  awaiting review   none")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
