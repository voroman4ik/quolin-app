"""
Stand up the files for a new dedicated stack, or check the ones that exist.

§S11's target is "a new dedicated stack from IaC in under one day". Most of that
day is RDS creating an instance, and none of it should be spent deciding which
network range this customer gets — that decision is where the quiet mistake
lives. Two stacks with overlapping CIDRs apply cleanly, run fine, and break the
day somebody routes between them, when both hold customer data and neither can
be renumbered without downtime.

So the allocation comes out of a written register (`infra/envs/allocations.md`),
this script is what writes to it, and `--check` verifies the register and the
`envs/` directory still agree. CI runs `--check`, which means the register
cannot quietly drift from what is deployed.

It writes two files and nothing else:

    infra/envs/<slug>.tfvars        what this stack is
    infra/envs/<slug>.backend.hcl   where its state lives

The state key is per stack for the reason the note in `versions.tf` gives: one
bucket and one key would make dedicated a fork rather than a parameterisation.
It does not run Terraform. Somebody reads the generated file, then applies it.

Usage:

    python -m scripts.new_stack --slug acme --zone-id Z0123456789ABCDEFGHIJ
    python -m scripts.new_stack --check

Exit codes: 0 when it worked, 1 when it could not, 2 when `--check` found a
disagreement.
"""

from __future__ import annotations

import argparse
import ipaddress
import re
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]

#: The real register. Overridable by `--envs` for one reason only: a checker
#: that has only ever been run against a valid register is indistinguishable
#: from one that always says yes, and `api/tests/test_stack_allocation.py`
#: points this at fixtures where the ranges really do overlap.
ENVS = _ROOT / "infra" / "envs"

#: Where dedicated stacks are allocated from: 10.32.0.0 – 10.47.255.255, sixteen
#: /16s. It starts above our own environments (staging 10.10, production 10.20)
#: and above the reserved example (10.30) on purpose — a customer stack must
#: never be handed a range that collides with something we run, and the cheapest
#: way to guarantee that is for the pool not to contain them.
POOL = ipaddress.ip_network("10.32.0.0/12")
PREFIX = 16

#: The bucket holding every stack's state. One bucket, one key per stack — the
#: bucket is ours, the key is the customer's.
STATE_BUCKET = "quolin-terraform-state"
STATE_LOCK_TABLE = "quolin-terraform-locks"

ROW = re.compile(r"^\|\s*([a-z0-9-]+)\s*\|\s*([0-9./]+)\s*\|\s*(\w+)\s*\|\s*(\w+)\s*\|(.*)\|\s*$")


def register_path() -> Path:
    return ENVS / "allocations.md"


def read_register() -> list[dict]:
    path = register_path()
    if not path.exists():
        raise SystemExit(f"{path} is missing — it is the allocation record.")
    rows = []
    for line in path.read_text().splitlines():
        match = ROW.match(line)
        if match and match.group(1) != "Slug":
            rows.append(
                {
                    "slug": match.group(1),
                    "cidr": match.group(2),
                    "tenancy": match.group(3),
                    "status": match.group(4),
                    "note": match.group(5).strip(),
                }
            )
    return rows


def next_free(rows: list[dict]) -> ipaddress.IPv4Network:
    taken = {ipaddress.ip_network(row["cidr"]) for row in rows}
    for candidate in POOL.subnets(new_prefix=PREFIX):
        if not any(candidate.overlaps(other) for other in taken):
            return candidate
    raise SystemExit(f"no free /{PREFIX} left in {POOL}. Widen the pool deliberately.")


def check() -> int:
    """The register and `envs/` still agree. Run in CI."""
    rows = read_register()
    problems: list[str] = []

    seen: dict[str, str] = {}
    for row in rows:
        if row["slug"] in seen:
            problems.append(f"{row['slug']} appears twice in the register")
        seen[row["slug"]] = row["cidr"]

    networks = [(row["slug"], ipaddress.ip_network(row["cidr"])) for row in rows]
    for i, (slug_a, net_a) in enumerate(networks):
        for slug_b, net_b in networks[i + 1 :]:
            if net_a.overlaps(net_b):
                problems.append(f"{slug_a} ({net_a}) overlaps {slug_b} ({net_b})")

    # Every tfvars file is registered, and every registered stack has one. The
    # example is exempt in one direction only: it is registered so its range is
    # reserved, and it has no `.tfvars` because it is not a stack.
    on_disk = {
        path.name.removesuffix(".tfvars")
        for path in ENVS.glob("*.tfvars")
        if not path.name.endswith(".example")
    }
    for slug in sorted(on_disk - set(seen)):
        problems.append(
            f"infra/envs/{slug}.tfvars exists with no row in the register — "
            "its network range was allocated from memory"
        )
    for row in rows:
        if row["slug"] not in on_disk and row["status"] not in ("example", "retired"):
            problems.append(
                f"{row['slug']} is registered as {row['status']} but has no "
                f"infra/envs/{row['slug']}.tfvars"
            )

    # The declared CIDR has to be the allocated one. A tfvars edited by hand is
    # how the register becomes fiction.
    for slug in sorted(on_disk & set(seen)):
        text = (ENVS / f"{slug}.tfvars").read_text()
        declared = re.search(r'vpc_cidr\s*=\s*"([^"]+)"', text)
        if declared and declared.group(1) != seen[slug]:
            problems.append(
                f"{slug}.tfvars declares {declared.group(1)} but the register "
                f"allocated {seen[slug]}"
            )

    if problems:
        print("the network register and infra/envs/ disagree:", file=sys.stderr)
        for problem in problems:
            print(f"  - {problem}", file=sys.stderr)
        return 2

    print(f"OK: {len(rows)} stack(s) registered, no overlapping ranges, envs/ agrees.")
    return 0


def create(slug: str, *, zone_id: str, region: str, note: str) -> int:
    if not re.fullmatch(r"[a-z][a-z0-9-]{1,20}", slug):
        print(
            f"{slug!r} is not a usable slug. It becomes the subdomain, the "
            "database identifier and the log group prefix, so it is lowercase "
            "alphanumeric with hyphens, 2-21 characters.",
            file=sys.stderr,
        )
        return 1

    rows = read_register()
    existing = next((row for row in rows if row["slug"] == slug), None)
    if existing is not None:
        print(
            f"{slug} is already in the register with {existing['cidr']}. "
            "A range is never reused, including by the same customer twice.",
            file=sys.stderr,
        )
        return 1

    tfvars = ENVS / f"{slug}.tfvars"
    if tfvars.exists():
        print(f"{tfvars} already exists.", file=sys.stderr)
        return 1

    cidr = next_free(rows)

    tfvars.write_text(
        f'''# A dedicated single-tenant stack for {slug}, from the same root module that
# deploys staging and production. There is no separate codebase and no feature
# flag: this file plus its own database and keys is the whole of what
# "dedicated" means.
#
# Allocated by scripts/new_stack.py and recorded in envs/allocations.md. Do not
# edit vpc_cidr by hand — `scripts/new_stack.py --check` compares the two and
# fails when they disagree.

environment = "{slug}"
tenancy     = "dedicated"

vpc_cidr = "{cidr}"
region   = "{region}"

# The organisation's hosted zone. This stack writes one record into it and owns
# nothing else about it; the certificate is issued and validated by the apply.
dns_zone_id = "{zone_id}"

postgres_instance_class = "db.t4g.medium"
postgres_multi_az       = true

backup_retention_days = 35

# One task. See the note on api_desired_count in variables.tf — login rate
# limiting is per-process, and raising this halves the effective lockout.
api_desired_count = 1
'''
    )

    (ENVS / f"{slug}.backend.hcl").write_text(
        f'''# State for the {slug} stack. One bucket, one key per stack: the bucket is
# ours, the key is this customer's.
#
#   tofu init -backend-config=envs/{slug}.backend.hcl -reconfigure

bucket         = "{STATE_BUCKET}"
key            = "stacks/{slug}/terraform.tfstate"
region         = "{region}"
dynamodb_table = "{STATE_LOCK_TABLE}"
encrypt        = true
'''
    )

    lines = register_path().read_text().rstrip().splitlines()
    why = note or "Allocated by scripts/new_stack.py."
    lines.append(f"| {slug} | {cidr} | dedicated | planned | {why} |")
    register_path().write_text("\n".join(lines) + "\n")

    print(f"allocated {cidr} to {slug}")
    print(f"  infra/envs/{slug}.tfvars")
    print(f"  infra/envs/{slug}.backend.hcl")
    print(f"  registered in {register_path()}")
    print()
    print("Read the tfvars, then follow docs/runbooks/dedicated-stack.md.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Files for a new dedicated stack.")
    parser.add_argument("--slug", help="the customer slug: becomes the subdomain")
    parser.add_argument("--zone-id", default="", help="the organisation's Route53 zone")
    parser.add_argument("--region", default="ap-southeast-2")
    parser.add_argument("--note", default="", help="one line for the register")
    parser.add_argument(
        "--check", action="store_true", help="verify the register against infra/envs/"
    )
    parser.add_argument(
        "--envs", default="", help="a different envs directory (tests use this)"
    )
    args = parser.parse_args()

    if args.envs:
        global ENVS
        ENVS = Path(args.envs)

    if args.check:
        return check()
    if not args.slug:
        parser.error("--slug is required unless --check is given")
    return create(args.slug, zone_id=args.zone_id, region=args.region, note=args.note)


if __name__ == "__main__":
    raise SystemExit(main())
