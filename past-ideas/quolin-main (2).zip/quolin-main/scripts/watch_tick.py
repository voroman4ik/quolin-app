"""
One scheduled sweep of the watch sources.

Freshness on `/currency` is derived from when each source was last checked, not
stored, so it decays on its own. With nothing running this, every regime drifts
to STALE — which is the screen telling the truth about a deployment nobody is
operating, but it means the demo shows a system in the state you would least
like to present.

This is what a scheduler runs. It does the same work `POST /watch/poll` does,
without going through HTTP, so it needs no session and no credentials: a cron job
holding the shared credential would be a copy of the secret sitting in a
scheduler's configuration for no reason.

**It runs in replay mode unless told otherwise.** In replay it reads
`fixtures/watch_events.json` and no regulator is contacted; what that proves is
that the cadence machinery works, and nothing it writes should be described as
if the monitoring were real. `WATCH_MODE=live` reaches the publishers that
declare a readable feed in pack content, respects each source's cadence, and
records a named failure against any source it could not read.

**A source past its own failure threshold pages the specialist who owns it**,
and the sweep exits non-zero for as long as one is in breach. Not only on the
sweep that first noticed: an alert fires once per outage so it does not become
noise, but the exit code stays bad until the source answers again, because
silence after the first page is how an outage gets forgotten.

Usage:

    make watch-tick
    uv run python -m scripts.watch_tick

Exit codes are meaningful, so a scheduler can alert on them: 0 for a completed
sweep with every source answering, 1 for a sweep that could not run, and 2 for a
sweep that ran while at least one source is unreachable — a distinction worth
having, because the second is our problem and the third is a publisher's.
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

# In the repository the app package is under `api/`; in the container the
# Dockerfile flattens `api/` to the working directory, so `api/` is not there.
# Both layouts are real deployments of this script, so it finds the one it is in
# rather than assuming.
_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from app import business_time, source_alerts, tenancy  # noqa: E402
from app.db import WATCH_DATABASE_URL, WatchSessionLocal  # noqa: E402
from app.models import ApiClient  # noqa: E402
from app.watch import poll, sources  # noqa: E402

#: Who the audit row for a page is attributed to.
#:
#: A machine principal that the seed provisions, not a string. A sweep has no
#: person behind it, and Stage 2 refuses an unattributed audit row rather than
#: inventing one — but "attributed" in this repository means *resolves to a row
#: somebody provisioned and the access review will ask about*, which is a higher
#: bar than "not blank". The shared placeholder officer Stage 2 deleted cleared
#: the lower bar and was removed anyway. This was written as the bare string
#: "schedule" first, and `test_attribution` caught it within the hour.
SCHEDULE_ACTOR = "apc_watch_sweep"

#: The tenant whose transaction the sweep's audit rows are written in. Watch
#: sources are platform-level — every customer is served by the same monitoring
#: — but an audit row belongs to somebody, and the operating tenant is who.
PLATFORM_TENANT = "demo"


def main() -> int:
    # The watch role, not the application role. §S6: the only path to the `packs`
    # table is the signature endpoint in core-api, and from here that is not a
    # rule anybody follows — it is a privilege Postgres does not grant. See
    # `api/migrations/versions/0014_watch_role.py` and `test_watch_role.py`.
    session = WatchSessionLocal()
    try:
        mode = sources.mode()
        # `on` is the as-at date the pack set is resolved against, not a filter on
        # the events themselves. A sweep asks "which sources do the packs in force
        # *today* declare", so today is the only defensible answer here — passing
        # anything else would poll a source list from a version of the rules that
        # is not the one currently binding.
        result = poll.poll(session, business_time.platform_today())
        # Committed before paging, and that ordering is load-bearing. `app.tenant_id`
        # and `app.user_id` are bound when a transaction *begins*, so entering the
        # tenancy context around a transaction that is already open sets nothing:
        # the audit row below is then written with no tenant in scope and row-level
        # security refuses it. The poll's own work is finished at this point, so
        # ending its transaction here costs nothing and starts the next one inside
        # the context. Written the other way round first, and caught by running it.
        session.commit()

        # Paging writes an audit row, and an audit row needs somebody to belong
        # to. The sweep is not a person, and Stage 2 refuses to invent one — so
        # it says plainly that the schedule did this.
        with tenancy.acting_as(PLATFORM_TENANT), tenancy.acting_as_user(SCHEDULE_ACTOR):
            if session.get(ApiClient, SCHEDULE_ACTOR) is None:
                # Refused rather than downgraded to an unattributed row, and
                # rather than skipping the page quietly. An alert nobody can be
                # asked about is not better than no alert; an alert that was
                # never sent because the credential was missing is a thing the
                # exit code should say out loud.
                raise RuntimeError(
                    f"the sweep credential {SCHEDULE_ACTOR!r} does not exist in "
                    f"tenant {PLATFORM_TENANT!r}. Provision it (`make seed` does, "
                    "for the demo) — a sweep must not write audit rows naming "
                    "something nobody provisioned."
                )
            paged = source_alerts.page(session)
            breaches = source_alerts.open_breaches(session)
            session.commit()

        # And then the customers — recorded here, sent elsewhere.
        #
        # `page` above tells the specialist who owns the source that their feed
        # is dark (§S6). The firms whose determinations rest on that regime's
        # content also have to be told it is going stale (§S4's "freshness
        # alerts"), and **this process cannot be what tells them**.
        #
        # FP3-03. The previous line here was
        #
        #     source_alerts.notify_tenants(source_alerts.all_tenant_ids(), breaches)
        #
        # which reads correctly and cannot run. `all_tenant_ids` opened
        # `OwnerSessionLocal` (`DATABASE_URL`) and `notify_tenants` opened
        # `SessionLocal` (`APP_DATABASE_URL`); this task holds
        # `WATCH_DATABASE_URL` and `guard_no_watch_in_engine.sh` check 6 fails
        # the build if it holds either of the others. In production both engines
        # fell back to `db.py`'s hardcoded `localhost:5433`, where nothing
        # listens, so the sweep raised after paging and before its summary —
        # every run, for as long as anything was in breach. Green on a laptop
        # and in CI, because both have all three connection strings.
        #
        # The separation is not an obstacle to work around. It is Stage 6: this
        # task must not hold a credential that can write a pack or read a
        # customer's data, and sending a webhook is not worth trading that for.
        #
        # So the sweep writes what it saw with the credential it has, and
        # `scripts/health_alerts.py` — which already holds the application role
        # and already enumerates firms through `maintenance` — fans it out.
        recorded = source_alerts.record_breaches(session, breaches)
        session.commit()

        checked = result.get("sources_checked", 0)
        found = result.get("new_events", 0)
        seen = result.get("already_seen", 0)
        tiers = result.get("by_tier", {})

        print(f"watch tick — mode={mode}")
        # Printed so an operator can see which credential did this without
        # reading the deployment. A sweep running as the application role would
        # work, and would have quietly given up the separation this stage exists
        # to establish.
        print(f"  connected as     {WATCH_DATABASE_URL.split('://')[-1].split(':')[0]}")
        print(f"  sources checked  {checked}")
        print(f"  new events       {found}")
        # Printed even when it is the only non-zero number. A steady state of
        # "0 new, 9 already seen" is a sweep that ran and found nothing changed,
        # which looks identical to a sweep that silently did nothing unless the
        # second number is on the page.
        print(f"  already seen     {seen}")
        for tier, count in sorted(tiers.items()):
            print(f"    {tier:<24} {count}")

        # Said on every run, in the log a scheduler keeps. A log line that
        # reads "watch tick ok" for six months is how a fixture quietly becomes
        # something people believe is a feed.
        for gap in result.get("no_adapter", []):
            # A backlog item, printed at a different volume from an outage. It
            # is our content that is missing, not their website that is down.
            print(f"  no adapter       {gap['source_id']}: {gap['reason']}")
        for failure in result.get("failures", []):
            print(
                f"  UNREACHABLE      {failure['source_id']}: {failure['reason']} "
                f"({failure['consecutive']} in a row)"
            )
        for page in paged:
            print(f"  PAGED            {page['message']}")
        # Printed even when it is zero, for the reason the "already seen" line
        # above is: a sweep that recorded nothing because nothing was stale and
        # one that recorded nothing because the path is broken read identically
        # unless the number is on the page.
        #
        # "recorded" rather than "notified" because that is what this process
        # did. Saying "tenants notified 3" here would have been the sweep
        # claiming an outcome that happens in another task, which is how the
        # previous version read right up until somebody deployed it.
        print(f"  breaches recorded {recorded}")

        if mode == sources.REPLAY:
            print("  source: fixtures/watch_events.json — no regulator was contacted")

        if breaches:
            # Every sweep, not only the one that paged. A scheduler watching exit
            # codes is the thing that keeps an outage visible after the alert
            # everybody has already scrolled past.
            print(
                f"  {len(breaches)} source(s) in breach: "
                + ", ".join(f"{b['source_id']} ({b['owner'] or 'unowned'})" for b in breaches),
                file=sys.stderr,
            )
            return 2
        return 0
    except poll.LiveModeUnavailable as exc:
        # Not a crash. WATCH_MODE=live is a configuration that this build
        # cannot satisfy, and the scheduler should report that clearly rather
        # than retrying forever against an adapter that does not exist.
        print(f"watch tick refused: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001 — a scheduler needs one exit code
        session.rollback()
        print(f"watch tick failed: {exc}", file=sys.stderr)
        return 1
    finally:
        session.close()


if __name__ == "__main__":
    raise SystemExit(main())
