"""
Twenty firms with real books, so §S12 has something production-shaped to measure.

§S12's load model is "20 tenants, realistic book sizes". A benchmark against the
seeded demo — one firm, two hundred clients — measures a system that no customer
will ever run, and every number it produces is flattering for the wrong reason:
the working set fits in cache, the chain is forty links long, and every index is
a rounding error.

Three things this generator does that a quicker one would not:

**It writes through the real path.** Every determination goes through
`service.evaluate`, so the hash chain is real, the encryption is real and the
audit rows are real. Bulk-inserting rows with a precomputed chain would be much
faster and would measure a database this application does not have.

**Twenty people, all in the firm the deployment serves.** The first version gave
each firm its own operator and pointed twenty sessions at one API, and that is
what found §S12's worst defect: a person whose only grant was in `load-07`
signed in to a deployment serving `demo` and was handed the role, after which
every screen showed them demo's book. `identity.roles_for` now filters by tenant
explicitly and those sign-ins are refused, which is correct and means the load
test cannot drive twenty tenants through one deployment.

That is not a limitation of the test. `tenancy.configured_tenant` says it out
loud — "one deployment, one tenant, still" — so twenty tenants is what the
*tables* hold, and twenty sessions in the served firm is what the concurrency
is. Both halves matter and they are different things: the data volume is what
makes every index, every row-level-security predicate and every query plan
realistic, and the sessions are what make the contention real.

**Books differ between firms.** Same generator, different seed per tenant, so
the twenty are not twenty copies of one query plan. A load test where every
tenant holds identical data measures a cache, not a database.

Generation is slow on purpose — it is the real write path, and determinations
chain serially within a tenant. Run it once; the load test runs against what it
left behind.

Usage:

    make load-model                       # 20 × 500 clients × 4 decisions
    make load-model ARGS="--tenants 4 --clients 50 --decisions 2"
    make load-model ARGS=--drop           # remove what a previous run made

Exit codes: 0 when the model is in place, 1 when it could not be built.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
import time
from datetime import date, timedelta
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from faker import Faker  # noqa: E402
from sqlalchemy import select, text  # noqa: E402

from app import (  # noqa: E402
    business_time,
    crypto,
    evidence,
    identity,
    packs_repo,
    service,
    tenancy,
)
from app.db import OwnerSessionLocal, SessionLocal  # noqa: E402
from app.models import Client, Tenant, UserRole  # noqa: E402

#: Load tenants are named so they cannot be confused with a customer, and so
#: `--drop` can find every one of them without a list.
PREFIX = "load-"

#: The password every generated operator shares. These accounts exist in a
#: development database that is rebuilt by `make seed`, and the load test needs
#: to sign in as twenty of them; a per-account password would be twenty secrets
#: in a file for no gain. It is not the seed's password, so a copy-paste from
#: here never works against the demo firm.
PASSWORD = "load model not a real one"

#: The firm the API under test is pointed at, and where every generated
#: operator holds their grant. Its book is what traffic actually reads; the
#: other nineteen firms are there to make the tables the size a real deployment
#: has to serve.
SERVING_TENANT = f"{PREFIX}01"

#: What each firm advises in. Kept to AU for the load model: the point is volume
#: through one hot path, and four regimes would spread it across four packs and
#: measure something more flattering than production.
JURISDICTIONS = ["AU"]

ASSETS = ["BTC", "ETH", "SOL"]

LOSS_BAND_WEIGHTS = [(1, 12), (2, 28), (3, 34), (4, 18), (5, 8)]
CRYPTO_PCT = [0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 8, 9, 13, 18, 24]

FIXTURES = _ROOT / "fixtures"


def _weighted(rng: random.Random, weights: list[tuple[int, int]]) -> int:
    return rng.choice([value for value, weight in weights for _ in range(weight)])


def tenant_ids(count: int) -> list[str]:
    return [f"{PREFIX}{n:02d}" for n in range(1, count + 1)]


def operator_email(tenant_id: str) -> str:
    return f"operator@{tenant_id}.quolin.example"


def provision(tenant_id: str, index: int) -> None:
    """A firm: the row, its key, its chain anchor, and one person who works there."""
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "INSERT INTO tenants "
                "(id, name, region, tier, status, stage, config, created_at) "
                "VALUES (:id, :name, 'ap-southeast-2', 'shared', 'active', "
                "'full', :config, now()) ON CONFLICT (id) DO NOTHING"
            ),
            {
                "id": tenant_id,
                "name": f"Load Firm {index:02d}",
                "config": json.dumps({"jurisdictions": JURISDICTIONS}),
            },
        )
        owner.commit()

        # Key and anchor, as the owner: the same three pieces every other path
        # that makes a tenant assembles by hand. There is still no single
        # "provision a tenant" call — this is the fourth copy of it, which is
        # recorded in docs/post-raise.md and is more visible every time.
        with tenancy.acting_as(tenant_id), tenancy.acting_as_user("apc_bulk_sweep"):
            crypto.ensure_key(owner, tenant_id)
            evidence.ensure_anchor(owner, tenant_id)
            owner.commit()

            user = identity.find_by_email(owner, operator_email(tenant_id))
            if user is None:
                user = identity.create_user(
                    owner,
                    email=operator_email(tenant_id),
                    display_name=f"Operator {index:02d}",
                )
            identity.set_password(owner, user, PASSWORD)
            owner.commit()

        # Granted in the served firm, not in this one — see the note at the top
        # of this file. A grant in `load-07` is worth nothing against a
        # deployment serving `load-01`, which is the whole point of the check
        # this found.
        with tenancy.acting_as(SERVING_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            already = owner.scalars(
                select(UserRole).where(
                    UserRole.tenant_id == SERVING_TENANT,
                    UserRole.user_id == user.id,
                    UserRole.role == "operator",
                )
            ).first()
            if already is None:
                identity.grant_role(
                    owner, user_id=user.id, role="operator", granted_by="load-model"
                )
            owner.commit()
    finally:
        owner.close()


def write_book(tenant_id: str, *, clients: int, seed: int, today: date) -> dict:
    """The firm's clients, and their custody positions."""
    rng = random.Random(seed)
    faker = Faker("en_AU")
    Faker.seed(seed)
    positions: dict[str, dict] = {}

    with tenancy.acting_as(tenant_id), tenancy.acting_as_user("apc_bulk_sweep"):
        session = SessionLocal()
        try:
            existing = session.scalar(select(Client.id).limit(1))
            if existing is not None:
                return {}

            for n in range(1, clients + 1):
                client_id = f"{tenant_id}-c{n:05d}"
                assessed = rng.random() > 0.11
                portfolio = rng.randrange(400_000, 40_000_000, 10_000)
                crypto_cents = portfolio * rng.choice(CRYPTO_PCT) // 100
                session.add(
                    Client(
                        id=client_id,
                        name=faker.name(),
                        scenario="load",
                        jurisdiction="AU",
                        dob=today - timedelta(days=rng.randint(18 * 365, 74 * 365)),
                        client_category="retail",
                        knowledge_assessed=assessed,
                        knowledge_date=(
                            today - timedelta(days=rng.randint(20, 1100))
                            if assessed
                            else None
                        ),
                        loss_capacity_band=_weighted(rng, LOSS_BAND_WEIGHTS),
                        vulnerability_flag=rng.random() < 0.045,
                        assessable_portfolio_cents=portfolio,
                        prior_crypto_purchases=0 if rng.random() < 0.18 else rng.randint(1, 24),
                        structural_acks=[],
                        default_trade_amount_cents=rng.randrange(50_000, 900_000, 5_000),
                    )
                )
                positions[client_id] = {
                    "crypto_value_cents": crypto_cents,
                    "holdings": (
                        [{"asset_id": "BTC", "value_cents": crypto_cents}]
                        if crypto_cents
                        else []
                    ),
                }
                if n % 200 == 0:
                    session.commit()
            session.commit()
        finally:
            session.close()
    return positions


def merge_positions(new: dict) -> None:
    """Custody, for everybody the model just invented.

    Merged into the same fixture `make seed` writes, so a determination against
    a generated client reads a real holding rather than `none_on_file` — the
    concentration rules are half the engine's work, and a book where every
    client holds nothing exercises the cheap branch of them.

    **This edits a tracked file, and the edit is not meant to be committed.**
    `fixtures/positions.json` is generated by `make seed` and checked in as the
    demo's custody; ten thousand load-model holdings do not belong in the
    repository. `make seed` puts it back, and so does `git checkout` — but
    anybody running this before a commit should know it moved.
    """
    if not new:
        return
    path = FIXTURES / "positions.json"
    current = json.loads(path.read_text()) if path.exists() else {}
    current.update(new)
    path.write_text(json.dumps(current, indent=2, sort_keys=True) + "\n")


def write_history(tenant_id: str, *, per_client: int, seed: int, today: date) -> int:
    """Determinations, through the real path, so the chain and the audit are real."""
    if per_client <= 0:
        return 0
    rng = random.Random(seed + 1)
    written = 0

    with tenancy.acting_as(tenant_id), tenancy.acting_as_user("apc_bulk_sweep"):
        session = SessionLocal()
        try:
            shelf = packs_repo.active_all(session, today)
            tenant = session.get(Tenant, tenant_id)
            client_ids = list(session.scalars(select(Client.id).order_by(Client.id)))
            for client_id in client_ids:
                for _ in range(per_client):
                    service.evaluate(
                        session,
                        client_id=client_id,
                        asset_id=rng.choice(ASSETS),
                        as_of=today - timedelta(days=rng.randint(0, 400)),
                        shelf=shelf,
                        tenant=tenant,
                    )
                    written += 1
                session.commit()
        finally:
            session.close()
    return written


def explain_no_drop() -> int:
    """Why there is no `--drop`, and what to do instead.

    The first version of this script had one. It deleted the tenants and
    everything hanging off them, and it failed on the first table it reached:
    `audit_events` is append-only, by trigger *and* revoked grant, and the
    database does not know or care that these particular rows are scaffolding.

    That is the mechanism working. A load model writes real determinations
    through the real path — that is the whole reason its numbers mean anything —
    and real determinations are evidence. Something that could delete them on
    request would be a hole in invariant 4 with a friendly flag on it, and the
    argument for adding one would sound exactly like this one does.

    So the reset is the blunt one: rebuild the schema.
    """
    print(
        "There is no --drop, and the reason is worth reading.\n"
        "\n"
        "The load model writes real determinations through the real path, which\n"
        "is why its numbers mean anything. Those land in append-only tables —\n"
        "audit_events and decisions — enforced by trigger and by revoked grant.\n"
        "A flag that deleted them would be a hole in invariant 4 with a friendly\n"
        "name on it.\n"
        "\n"
        "To start over:  make seed     (rebuilds the schema, then reseeds)\n"
        "To add to it:   run this again — it skips a firm that already has a book.",
        file=sys.stderr,
    )
    return 1


def main() -> int:
    parser = argparse.ArgumentParser(description="A production-shaped load model.")
    parser.add_argument("--tenants", type=int, default=20)
    parser.add_argument("--clients", type=int, default=500, help="per tenant")
    parser.add_argument("--decisions", type=int, default=4, help="per client")
    parser.add_argument(
        "--drop", action="store_true", help="explains why there is no drop"
    )
    args = parser.parse_args()

    today = business_time.platform_today()

    if args.drop:
        return explain_no_drop()

    started = time.monotonic()
    total_clients = total_decisions = 0
    positions: dict[str, dict] = {}

    for index, tenant_id in enumerate(tenant_ids(args.tenants), start=1):
        provision(tenant_id, index)
        book = write_book(
            tenant_id, clients=args.clients, seed=20260825 + index, today=today
        )
        positions.update(book)
        total_clients += len(book)
        print(f"  {tenant_id}: {len(book)} client(s)", flush=True)

    # Written before the determinations, so every evaluation below reads the
    # holdings this run invented rather than `none_on_file`.
    merge_positions(positions)

    for index, tenant_id in enumerate(tenant_ids(args.tenants), start=1):
        made = write_history(
            tenant_id, per_client=args.decisions, seed=20260825 + index, today=today
        )
        total_decisions += made
        print(f"  {tenant_id}: {made} determination(s)", flush=True)

    elapsed = time.monotonic() - started
    print()
    print(
        f"load model — {args.tenants} tenant(s), {total_clients} client(s), "
        f"{total_decisions} determination(s) in {elapsed:.0f}s"
    )
    print(f"  sign in as {operator_email(tenant_ids(1)[0])} / {PASSWORD!r}")
    print()
    print(
        f"  Point the API at {SERVING_TENANT} before load testing — every operator\n"
        f"  holds their grant there, and a grant in another firm is refused:\n"
        f"    cd api && QUOLIN_TENANT={SERVING_TENANT} uv run uvicorn app.main:app "
        "--port 8020 --workers 3"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
