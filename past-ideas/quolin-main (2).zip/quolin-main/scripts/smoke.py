"""
Prove a deployment works, from outside it, over HTTP.

§S11 asks that a dedicated stack come up from clean IaC and pass "the full smoke
+ RLS suite". This is the smoke half — the RLS half is `scripts/rls_probe.py`,
which talks to the database rather than the API.

It walks the three taps the product is demonstrated with, in order, against the
seeded cast, because "the deployment works" is a claim about that sequence and
not about whether the endpoints return 200. Check, Replay, Generate: the engine
refuses and says why, a determination from a year ago reproduces exactly with
its chain intact, and a real PDF comes out of the other end.

Three things worth stating about how it is built:

**Standard library only.** It runs from a laptop against a stack that has just
come up, before anything is installed anywhere, and against a stack whose Python
environment is none of its business. `urllib` is enough.

**It writes, and says so before it does.** Tap one records a determination. On a
new stack that is the point; on a stack holding a customer's evidence it is a
row in their chain, so `--check` stops after the read-only half. The default is
the read-only half.

**A tap it cannot run is a failure, not a skip.** If the seeded cast is absent
the sequence cannot be walked, and reporting that as "passed, nothing to do"
would make this script useless exactly when a deploy has gone wrong. Pass
`--no-cast` to assert only what does not need it, deliberately.

Usage:

    make smoke BASE=https://acme.quolin.example
    QUOLIN_SMOKE_PASSWORD=... python -m scripts.smoke --base-url ... --write

`--write` signs in as a named person, and since F8 the roles that write evidence
require a second factor — so that account has an authenticator and this needs
its secret. `QUOLIN_SMOKE_TOTP_SECRET`, or `--totp-secret`. It is only asked for
if the deployment says the account needs one, so a stack whose operator has no
factor still works without it.

Exit codes: 0 when every check passed, 1 when the deployment could not be
reached at all, 2 when a check failed.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import http.cookiejar
import json
import os
import ssl
import struct
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

#: Straight out of docs/demo-script.md, and the same three names
#: api/tests/test_three_tap.py uses. If those diverge, one of the two is wrong
#: and somebody should have to notice.
BLOCKING_CLIENT = "tom-askew"
BLOCKING_ASSET = "SOL"
REPLAY_CLIENT = "harold-bell"

TIMEOUT_SECONDS = 30.0


class Failed(Exception):
    """A check that did not pass. Carries the sentence a person needs."""


class Unreachable(Exception):
    """The deployment could not be reached at all — a different kind of bad."""


class Client:
    """The smallest HTTP client that can hold a session cookie."""

    def __init__(self, base_url: str, *, insecure: bool = False) -> None:
        self.base = base_url.rstrip("/")
        self.jar = http.cookiejar.CookieJar()
        handlers: list[urllib.request.BaseHandler] = [
            urllib.request.HTTPCookieProcessor(self.jar)
        ]
        if insecure:
            # Only for a stack whose certificate has not been issued yet. It is
            # a flag rather than a fallback so that "TLS is not working" can
            # never be something this script decides to tolerate on its own.
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            handlers.append(urllib.request.HTTPSHandler(context=context))
        self.opener = urllib.request.build_opener(*handlers)

    def request(
        self, method: str, path: str, body: dict | None = None, *, raw: bool = False
    ) -> tuple[int, object, dict]:
        url = f"{self.base}{path}"
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        if data is not None:
            req.add_header("Content-Type", "application/json")
        # Q-05: an unsafe method that does not say where it came from is refused
        # by the API before anything happens. This script holds a session cookie
        # like a browser does, so it says so like a browser does — the base URL
        # it was pointed at, which the middleware accepts as its own origin.
        # A tool that changes state should be willing to identify itself.
        req.add_header("Origin", self.base)
        try:
            with self.opener.open(req, timeout=TIMEOUT_SECONDS) as response:
                payload = response.read()
                # Lower-cased on the way in. HTTP header names are
                # case-insensitive and uvicorn sends them lowercase, so a
                # lookup for "Content-Type" silently returns None — which read
                # as "the PDF check failed" against a response that was a
                # perfectly good PDF.
                headers = {k.lower(): v for k, v in response.headers.items()}
                if raw:
                    return response.status, payload, headers
                return response.status, json.loads(payload or b"null"), headers
        except urllib.error.HTTPError as exc:
            payload = exc.read()
            try:
                parsed: object = json.loads(payload or b"null")
            except json.JSONDecodeError:
                parsed = payload[:400].decode("utf-8", "replace")
            return exc.code, parsed, {k.lower(): v for k, v in exc.headers.items()}
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            raise Unreachable(f"{method} {url}: {exc}") from exc

    def get(self, path: str, **kw):
        return self.request("GET", path, **kw)

    def post(self, path: str, body: dict | None = None, **kw):
        return self.request("POST", path, body, **kw)


def check(results: list[tuple[str, bool, str]], name: str, ok: bool, note: str) -> bool:
    results.append((name, ok, note))
    return ok


def read_only_checks(client: Client, results: list) -> None:
    """Everything provable without writing a row into somebody's evidence."""
    status, health, _ = client.get("/health")
    check(
        results,
        "the API answers",
        status == 200,
        f"GET /health returned {status}",
    )
    packs = (health or {}).get("packs") if isinstance(health, dict) else None
    check(
        results,
        "rule content is loaded",
        bool(packs),
        f"{packs} packs in force"
        if packs
        else "no packs in force — the deployment came up unseeded",
    )

    status, public, _ = client.get("/status")
    chain = (public or {}).get("evidence_chain") if isinstance(public, dict) else None
    check(
        results,
        "the status page can answer",
        status == 200,
        f"evidence chain: {chain}",
    )
    # "nothing recorded yet" is the correct answer on a stack that has just come
    # up. "NOT VERIFIED" is never acceptable and is what this check exists for.
    check(
        results,
        "the evidence chain is not broken",
        chain in ("verified", "nothing recorded yet"),
        f"the status page reports {chain!r}",
    )

    # The schema is deliberately behind a session — see the note above
    # PUBLIC_PATHS in api/app/main.py. Asserted from outside because a
    # deployment that accidentally opened it would look healthy on every other
    # check here while handing an unauthenticated caller the whole API surface.
    status, _, _ = client.get("/openapi.json")
    check(
        results,
        "the schema is not readable without a session",
        status in (401, 403),
        f"GET /openapi.json returned {status}, expected 401 or 403",
    )

    # An unauthenticated request for somebody's data must be refused. Asserted
    # from outside because this is the one guarantee a customer can check
    # themselves, and a deployment that got its middleware wrong would otherwise
    # look healthy on every check above.
    status, _, _ = client.get("/clients")
    check(
        results,
        "unauthenticated requests are refused",
        status in (401, 403),
        f"GET /clients without a session returned {status}, expected 401 or 403",
    )


def totp_now(secret: str, *, at: int | None = None) -> str:
    """The six-digit code an authenticator app would be showing.

    Standard library only, like the rest of this file: it runs against a stack
    that has just come up, from a machine where nothing is installed. RFC 6238
    with the defaults every authenticator uses — SHA-1, thirty-second steps,
    six digits.
    """
    # Stripped before it is re-padded: an authenticator secret gets copied
    # around with and without its `=` tail, and padding an already-padded one
    # produces `binascii.Error: Incorrect padding` rather than a code.
    trimmed = secret.strip().upper().rstrip("=")
    key = base64.b32decode(trimmed + "=" * (-len(trimmed) % 8))
    counter = int(at if at is not None else time.time()) // 30
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    code = struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF
    return f"{code % 1_000_000:06d}"


def _detail(body: object) -> str:
    """The server's own sentence, appended to a failure note.

    `POST /auth/login as … returned 401` is what this said before, and it cost a
    whole CI round trip to discover that the 401 meant "that code was already
    spent" rather than "those details are wrong". A smoke test that reports a
    status and withholds the reason is a smoke test somebody has to reproduce by
    hand.
    """
    if isinstance(body, dict):
        detail = body.get("detail")
        if isinstance(detail, str) and detail:
            return f" — {detail}"
        if isinstance(detail, dict) and detail.get("message"):
            return f" — {detail['message']}"
    return ""


def _present_a_code(
    client: Client, email: str, password: str, secret: str
) -> tuple[int, object, dict]:
    """Sign in with a one-time code, once more on the next step if it is refused.

    A TOTP code is one-time *per time step*: `identity.check_second_factor`
    records the step it accepted and `totp.verify` refuses anything at or below
    it. That is the control working — a code read over somebody's shoulder is
    spent — and it is also why this needs a second attempt.

    In CI the whole pytest suite signs in as this same person immediately
    before, and the last of those sign-ins leaves the current step spent. The
    smoke step then computes a code for that same thirty-second window and is
    refused, which looks exactly like a broken deployment and is not one.

    So: wait for the next step and try once. Bounded by construction — one step
    is thirty seconds — and it is what a person does when their authenticator
    shows a code that has just been used.
    """
    status, body, headers = client.post(
        "/auth/login", {"email": email, "password": password, "code": totp_now(secret)}
    )
    if status != 401:
        return status, body, headers

    # To just past the next step boundary, so the code is certainly from a step
    # above the one that was spent.
    time.sleep(30 - (time.time() % 30) + 1)
    return client.post(
        "/auth/login", {"email": email, "password": password, "code": totp_now(secret)}
    )


def sign_in(
    client: Client, email: str, password: str, results: list, totp_secret: str = ""
) -> bool:
    """Sign in as a person, presenting a second factor if one is asked for.

    The code is not sent on the first attempt, deliberately — that is what the
    web client does, and for the reason `api.login` gives: whether an account
    holds a second factor is only knowable after the password has checked out,
    because an endpoint that answered sooner would be an account-enumeration
    oracle. Asking first and answering second means this walks the same path a
    person does.

    F8 is why this exists. `operator` joined `MFA_REQUIRED_ROLES` — it is the
    role that produces evidence, and a phished password was the whole credential
    — so the seeded operator this script signs in as now has an authenticator,
    and a password-only sign-in is refused 401. That refusal is the control
    working; what was missing was any way for this script to do what a real
    operator now does.
    """
    status, body, headers = client.post(
        "/auth/login", {"email": email, "password": password}
    )

    if status == 401 and headers.get("x-quolin-mfa") == "required":
        if not totp_secret:
            check(
                results,
                "a named person can sign in",
                False,
                f"{email} holds a role that requires a second factor and no "
                "authenticator secret was given. Set QUOLIN_SMOKE_TOTP_SECRET "
                "(or pass --totp-secret) to the secret for this account.",
            )
            return False
        status, body, headers = _present_a_code(client, email, password, totp_secret)

    ok = check(
        results,
        "a named person can sign in",
        status == 200,
        f"POST /auth/login as {email} returned {status}{_detail(body)}",
    )
    if not ok:
        return False
    status, session, _ = client.get("/auth/session")
    who = (session or {}).get("user", {}).get("email") if isinstance(session, dict) else None
    return check(
        results,
        "the session names the person",
        who == email,
        f"the session says {who!r}",
    )


def three_taps(client: Client, results: list) -> None:
    """Check, Replay, Generate — the sequence the product is demonstrated with."""
    # --- tap one: the machine refuses, and says why -------------------------
    status, decision, _ = client.post(
        "/evaluate", {"client_id": BLOCKING_CLIENT, "asset_id": BLOCKING_ASSET}
    )
    if status != 200 or not isinstance(decision, dict):
        raise Failed(
            f"tap one: POST /evaluate returned {status}. "
            f"Is the demo cast seeded on this deployment? {decision!r}"
        )
    check(
        results,
        "tap one — the engine refuses",
        decision.get("outcome") == "BLOCK",
        f"{BLOCKING_CLIENT} / {BLOCKING_ASSET} came back {decision.get('outcome')}",
    )
    reasons = decision.get("reasons") or []
    check(
        results,
        "tap one — the refusal is explained",
        bool(reasons) and all(r.get("reason_plain_english") for r in reasons),
        f"{len(reasons)} reasons, each with a sentence"
        if reasons
        else "no reasons came back with the refusal",
    )

    # --- tap two: a determination from last year reproduces exactly ---------
    status, history, _ = client.get(
        "/decisions?" + urllib.parse.urlencode({"client_id": REPLAY_CLIENT})
    )
    if status != 200 or not history:
        raise Failed(f"tap two: no history for {REPLAY_CLIENT} (HTTP {status})")
    oldest = min(history, key=lambda d: d["as_of"])
    status, replay, _ = client.post(f"/decisions/{oldest['id']}/replay")
    if status != 200 or not isinstance(replay, dict):
        raise Failed(f"tap two: replay returned {status}")
    check(
        results,
        "tap two — a year-old determination reproduces exactly",
        replay.get("match") is True and not replay.get("differences"),
        f"replayed {oldest['id']} under pack v{oldest.get('pack_version')}: "
        f"match={replay.get('match')}",
    )
    check(
        results,
        "tap two — the record it reproduced from is unaltered",
        bool((replay.get("chain") or {}).get("verified")),
        f"chain verified: {(replay.get('chain') or {}).get('verified')}",
    )

    # --- tap three: the document comes out ----------------------------------
    status, artefact, _ = client.post(
        "/artefacts/tmd", {"decision_id": decision["id"]}
    )
    if status != 200 or not isinstance(artefact, dict):
        raise Failed(f"tap three: POST /artefacts/tmd returned {status}")
    status, pdf, headers = client.get(artefact["download_url"], raw=True)
    check(
        results,
        "tap three — a real document comes out",
        status == 200
        and isinstance(pdf, bytes)
        and pdf.startswith(b"%PDF")
        and headers.get("content-type") == "application/pdf",
        f"{artefact.get('title')!r}, {len(pdf) if isinstance(pdf, bytes) else 0} bytes",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Prove a deployment works.")
    parser.add_argument("--base-url", required=True, help="https://<stack>/")
    parser.add_argument(
        "--email", default=os.getenv("QUOLIN_SMOKE_EMAIL", ""), help="who to sign in as"
    )
    parser.add_argument(
        "--write",
        action="store_true",
        help="walk the three taps, which records a determination",
    )
    parser.add_argument(
        "--no-cast",
        action="store_true",
        help="assert only what does not need the seeded demo cast",
    )
    parser.add_argument(
        "--insecure", action="store_true", help="skip certificate verification"
    )
    parser.add_argument(
        "--totp-secret",
        default="",
        help=(
            "the authenticator secret for --email, if that account holds a role "
            "requiring a second factor. Defaults to QUOLIN_SMOKE_TOTP_SECRET."
        ),
    )
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    password = os.getenv("QUOLIN_SMOKE_PASSWORD", "")
    # F8 put `operator` in MFA_REQUIRED_ROLES, so the account this script signs
    # in as holds an authenticator. Read from the environment beside the
    # password and for the same reason: a factor belongs to a deployment, not to
    # a file in this repository.
    totp_secret = args.totp_secret or os.getenv("QUOLIN_SMOKE_TOTP_SECRET", "")
    client = Client(args.base_url, insecure=args.insecure)
    results: list[tuple[str, bool, str]] = []
    started = time.monotonic()

    try:
        read_only_checks(client, results)

        if args.write and not args.no_cast:
            if not args.email or not password:
                raise Failed(
                    "--write needs --email and QUOLIN_SMOKE_PASSWORD. The three "
                    "taps are performed by a named person, because every one of "
                    "them writes an audit row attributed to somebody."
                )
            if sign_in(client, args.email, password, results, totp_secret):
                three_taps(client, results)
        elif args.write:
            check(
                results,
                "the three taps",
                True,
                "not walked: --no-cast was passed deliberately",
            )
    except Unreachable as exc:
        print(f"the deployment could not be reached: {exc}", file=sys.stderr)
        return 1
    except Failed as exc:
        results.append(("a check could not run", False, str(exc)))

    elapsed = time.monotonic() - started
    failed = [name for name, ok, _ in results if not ok]

    if args.json:
        print(
            json.dumps(
                {
                    "base_url": args.base_url,
                    "seconds": round(elapsed, 2),
                    "checks": [
                        {"name": n, "passed": ok, "note": note}
                        for n, ok, note in results
                    ],
                    "failed": failed,
                },
                indent=2,
            )
        )
    else:
        print(f"smoke — {args.base_url}")
        for name, ok, note in results:
            print(f"  [{'ok ' if ok else 'FAIL'}] {name}")
            print(f"         {note}")
        print(
            f"  {len(results) - len(failed)}/{len(results)} passed in {elapsed:.1f}s"
        )
        if not args.write:
            print(
                "  read-only: the three taps were not walked. Pass --write on a "
                "stack whose evidence chain you are allowed to add a row to."
            )

    return 2 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
