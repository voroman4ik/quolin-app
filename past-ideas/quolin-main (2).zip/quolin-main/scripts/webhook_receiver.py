"""A receiver that checks our signatures, so an integration can be tried locally.

Two audiences, and the second is the reason this is committed rather than a
snippet in a ticket.

**Us.** `make webhook-receiver` gives the delivery worker somewhere real to send
to — a socket, an HTTP status, a body arriving over a network — which the stub
sender in the test suite deliberately is not. The retry path, the dead-letter
path and the signature can all be exercised end to end without a customer.

**A customer's engineer.** This is a working implementation of the check they
have to write. `docs/webhooks.md` describes the algorithm; this file *is* the
algorithm, in eighty lines, and the two cannot drift because the verification
below calls the same function the product signs with.

**It refuses anything it cannot verify, and says which part failed.** A receiver
that logged "invalid signature" and moved on is a receiver whose operator cannot
tell a clock-skew problem from a wrong secret, and those have different fixes.

Usage:

    make webhook-receiver                       # :4000, prints what arrives
    make webhook-receiver ARGS="--port 4010 --secret <the endpoint's secret>"
    make webhook-receiver ARGS="--fail 500"     # to exercise retry and dead-letter

Nothing here is a production receiver. It holds one secret in a process
argument, keeps no record, and answers every path the same way.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from app import webhooks  # noqa: E402

#: The header the product sends the signature in. Imported rather than
#: restated, so a receiver written from this file cannot be reading a header
#: name the product stopped sending.
SIGNATURE_HEADER = webhooks.SIGNATURE_HEADER


class Receiver(BaseHTTPRequestHandler):
    secret: str = ""
    fail_with: int = 0
    seen: int = 0

    def do_POST(self) -> None:  # noqa: N802 — BaseHTTPRequestHandler's spelling
        length = int(self.headers.get("content-length", "0"))
        body = self.rfile.read(length).decode("utf-8", "replace")
        signature = self.headers.get(SIGNATURE_HEADER, "")

        Receiver.seen += 1
        arrived = datetime.now(timezone.utc).isoformat(timespec="seconds")

        if not signature:
            self._answer(400, "no signature header — refused unread")
            print(f"[{arrived}] REFUSED  no {SIGNATURE_HEADER} header")
            return

        if not self.secret:
            # Deliberately still refused. A receiver that accepted unverified
            # bodies "because it is only a test" is the shape of the mistake
            # that reaches production, and this file is read as an example.
            self._answer(400, "this receiver was started with no secret")
            print(f"[{arrived}] REFUSED  no secret configured — cannot verify")
            return

        if not webhooks.verify(self.secret, body, signature):
            self._answer(401, "signature did not verify")
            print(
                f"[{arrived}] REFUSED  signature did not verify.\n"
                "           Either the secret is wrong, the body was altered in "
                "transit, or\n           the timestamp is outside the tolerance "
                "— check the clock first."
            )
            return

        if self.fail_with:
            self._answer(self.fail_with, "failing on purpose")
            print(f"[{arrived}] FAILED   answering {self.fail_with} on purpose")
            return

        try:
            payload = json.loads(body)
            event = payload.get("event", "?")
            subject = payload.get("subject", "")
        except json.JSONDecodeError:
            event, subject = "?", "(body is not JSON)"

        self._answer(200, "ok")
        print(f"[{arrived}] ok       {event}  {subject}")

    def _answer(self, code: int, message: str) -> None:
        body = json.dumps({"status": code, "detail": message}).encode()
        self.send_response(code)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args: object) -> None:
        """Silence the default access log; the lines above are the useful ones."""


def main() -> int:
    parser = argparse.ArgumentParser(description="Receive and verify our webhooks.")
    parser.add_argument("--port", type=int, default=4000)
    parser.add_argument(
        "--secret",
        default="",
        help="the endpoint's signing secret; without it every delivery is refused",
    )
    parser.add_argument(
        "--fail",
        type=int,
        default=0,
        metavar="STATUS",
        help="answer this status instead of 200, to exercise retry and dead-letter",
    )
    args = parser.parse_args()

    Receiver.secret = args.secret
    Receiver.fail_with = args.fail

    if not args.secret:
        print(
            "No --secret given. Every delivery will be refused with a 400, which "
            "is the honest answer for a receiver that cannot verify anything — "
            "and is not a useful test of delivery. Pass the endpoint's secret.",
            file=sys.stderr,
        )

    server = HTTPServer(("127.0.0.1", args.port), Receiver)
    print(
        f"listening on http://127.0.0.1:{args.port} — "
        + (f"answering {args.fail}" if args.fail else "verifying signatures")
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print(f"\nstopped after {Receiver.seen} delivery attempt(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
