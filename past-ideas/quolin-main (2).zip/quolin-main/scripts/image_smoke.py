#!/usr/bin/env python3
"""Every deployed command, run in the image that is deployed.

The Gate A audit's fourth finding is that all three scheduled tasks in
`infra/compute.tf` ran `["python", "-m", "scripts.…"]` against an image whose
dependencies live in `/app/.venv`, so each one died on its first third-party
import. That silently disabled the entire monitoring tier — including the health
job that would have reported the outage, and the heartbeat written so a dead
monitor can be told from a quiet one.

**The test that should have caught it could not, and the reason is the point.**
`test_the_watch_sweep_runs_in_its_deployed_environment.py` reconstructs the
task definition's environment variables faithfully and then runs the sweep under
`sys.executable` — the suite's own virtualenv, where every dependency is
present. Its assertions about *which engines are opened* are real and are kept.
Its assertion that the sweep runs is about the wrong interpreter, and no amount
of care with the environment can fix that: the defect is the interpreter.

So this exists, and it does the one thing a unit test cannot. It reads the task
definitions, builds the image, and runs each task's exact command inside it.

Three checks per task, in the order they fail in production:

  1. `command[0]` resolves on the image's PATH. A task whose entrypoint is not
     an executable is dead before any of its code runs.
  2. Every module in `python -m <module>` imports cleanly. This is where the
     finding actually bit — the module's own imports, at the top of the file,
     before `main()` is ever called.
  3. The image's `python` is the virtualenv's. Checked separately from (2)
     because it can hold while (2) fails and the diagnosis is different: (2)
     failing with the right interpreter means a missing dependency, and this
     failing means the convention has come apart again.

Usage:

    make image-smoke                 # build and check
    python scripts/image_smoke.py --image quolin/api:sha   # an image already built

Exit codes: 0 when every deployed command runs, 1 when one does not, 2 when the
check could not be performed at all — no docker, no task definitions. A check
that could not run is not a pass; see `scripts/guard_lib.sh` for the same rule.
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO))

from scripts.task_environment import Task, task_definitions  # noqa: E402

#: What the entrypoint convention says. Asserted rather than assumed: the whole
#: finding is that `infra/compute.tf` and `api/Dockerfile` had drifted about
#: which interpreter runs a scheduled task, and a check that took either one's
#: word for it would have drifted with them.
VENV_BIN = "/app/.venv/bin"


def build(dockerfile: Path, context: Path) -> str:
    """Build the image and return its id."""
    result = subprocess.run(
        ["docker", "build", "-q", "-f", str(dockerfile), str(context)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print("the image would not build:", file=sys.stderr)
        print(result.stdout, file=sys.stderr)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(1)
    return result.stdout.strip().splitlines()[-1]


def _run(image: str, argv: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["docker", "run", "--rm", "--entrypoint", argv[0], image, *argv[1:]],
        capture_output=True,
        text=True,
    )


def _modules(task: Task) -> list[str]:
    """The modules a `python -m X` command names, if it is one."""
    argv = list(task.command)
    found = []
    for i, word in enumerate(argv):
        if word == "-m" and i + 1 < len(argv):
            found.append(argv[i + 1])
    return found


def check(image: str, tasks: dict[str, Task]) -> list[str]:
    """Every failure, as sentences. Empty means every deployed command runs."""
    problems: list[str] = []

    where = _run(image, ["sh", "-c", "command -v python"])
    resolved = where.stdout.strip()
    if not resolved.startswith(VENV_BIN):
        problems.append(
            f"`python` in this image resolves to {resolved or '(nothing)'}, not "
            f"{VENV_BIN}/python. The entrypoint convention has come apart: every "
            "command that does not wrap itself will run against an interpreter "
            "with none of this project's dependencies."
        )

    for name, task in sorted(tasks.items()):
        if not task.command:
            # The image's own CMD, checked by (1) above and by the healthcheck.
            continue

        found = _run(image, ["sh", "-c", f"command -v {task.command[0]}"])
        if found.returncode != 0 or not found.stdout.strip():
            problems.append(
                f"{name}: `{task.command[0]}` is not on the PATH of the image "
                f"this task runs. Its full command is {list(task.command)}."
            )
            continue

        for module in _modules(task):
            result = _run(
                image,
                [
                    "python",
                    "-c",
                    f"import importlib; importlib.import_module({module!r})",
                ],
            )
            if result.returncode != 0:
                last = (result.stderr.strip().splitlines() or ["(no output)"])[-1]
                problems.append(
                    f"{name}: `{' '.join(task.command)}` does not import in the "
                    f"built image — {last}. This task would start, fail on an "
                    "import, and stop; nothing in EventBridge distinguishes that "
                    "from a task that ran."
                )

    return problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--image", help="an image already built; otherwise one is built here"
    )
    parser.add_argument("--dockerfile", default=str(REPO / "api" / "Dockerfile"))
    parser.add_argument("--context", default=str(REPO))
    parser.add_argument("--infra-dir", default=str(REPO / "infra"))
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    if shutil.which("docker") is None:
        print(
            "FAIL: docker is not available, so no deployed command was run.\n\n"
            "This check exists because the suite cannot see the defect it "
            "catches: the suite's interpreter has every dependency and the "
            "image's did not. Skipping it reports a pass nothing earned.",
            file=sys.stderr,
        )
        return 2

    try:
        tasks = task_definitions(args.infra_dir)
    except (FileNotFoundError, ValueError) as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 2

    image = args.image or build(Path(args.dockerfile), Path(args.context))
    problems = check(image, tasks)

    report = {
        "image": image,
        "tasks": sorted(tasks),
        "problems": problems,
    }
    if args.json:
        print(json.dumps(report, indent=2))
    elif problems:
        for problem in problems:
            print(f"FAIL: {problem}")
    else:
        print(
            f"OK: {len(tasks)} deployed command(s) resolve and import in the built "
            f"image — {', '.join(sorted(tasks))}."
        )

    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
