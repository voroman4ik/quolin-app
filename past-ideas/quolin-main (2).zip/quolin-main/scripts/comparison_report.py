"""
The weekly comparison: what we decided, what their system decided, and why.

§S10 runs a firm in shadow for a while, and the whole point of that period is
this report. It is weekly because that is the cadence a compliance officer can
actually absorb — a daily divergence feed is noise, a monthly one is archaeology.

Three decisions worth stating, because each one could have gone the flattering
way:

**A shadow tenant with nothing to compare exits non-zero.** Shadow mode that
nobody is comparing is just a switched-off system with extra steps. Zero
comparable pairs in a week is not "no divergences" — it is the comparison not
happening, and it should be as loud as a disagreement.

**The report is recorded in the audit trail when it runs.** A weekly number a
customer repeats in a meeting needs a row saying when it was computed and over
what window. Otherwise the only version of it is a screenshot.

**It does not grade the divergences.** `app/comparison.py` explains why *our*
side decided what it did and stops there, and this script does not add a verdict
on top. A system that graded its own disagreements would grade them in its own
favour, which is the one thing shadow mode cannot afford to be seen doing.

Usage:

    make comparison-report
    make comparison-report ARGS="--json"
    make comparison-report ARGS="--since 2026-08-01 --until 2026-08-31"

Exit codes: 0 when every tenant that should have a comparison has one, 1 if the
report could not be produced, 2 when a tenant in shadow or limited had nothing
comparable in the window.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date, timedelta
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT / "api" if (_ROOT / "api").is_dir() else _ROOT))

from scripts import evidence_io  # noqa: E402

from app import (  # noqa: E402
    adoption,
    business_time,
    comparison,
    maintenance,
    observability,
    tenancy,
)
from app.db import OwnerSessionLocal, SessionLocal  # noqa: E402
from app.service import audit  # noqa: E402

#: Who the scheduled run acts as. The same provisioned account the other
#: scheduled jobs use, because `audit()` refuses a bare string and an audit
#: trail whose actor is "system" answers nobody's question.
SCHEDULE_ACTOR = "apc_bulk_sweep"

#: One week, because that is the cadence the report is named for.
WINDOW_DAYS = 7

#: The stages where a comparison is expected to exist. A firm at `pilot` has not
#: started; a firm at `full` has stopped running an incumbent alongside us.
COMPARING = (adoption.SHADOW, adoption.LIMITED)


def _tenants() -> list[tuple[str, str]]:
    """Every active firm and where it sits on the adoption ladder.

    Read through the `quolin_maintenance` grant migration 0029 creates. Before
    it, this returned nothing on a database whose owner lacked BYPASSRLS, and
    the weekly shadow comparison — the thing a firm in shadow mode is running us
    for — would have reported an empty week, every week.
    """
    session = OwnerSessionLocal()
    try:
        return [
            (tenant.id, adoption.stage_of(tenant))
            for tenant in maintenance.active_tenants(session)
        ]
    finally:
        session.close()


def _report(tenant_id: str, *, since: date, until: date) -> dict[str, object]:
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(SCHEDULE_ACTOR):
        session = SessionLocal()
        try:
            report = comparison.compare(session, since=since, until=until)
            audit(
                session,
                "comparison.report",
                (
                    f"{since.isoformat()}..{until.isoformat()} — "
                    f"{report['compared']} compared, {report['diverged']} diverged"
                ),
            )
            session.commit()
        finally:
            session.close()
    return report


def _render(tenant_id: str, stage: str, report: dict) -> None:
    """Print the report the way the officer reading it needs it: rate, then rows."""
    rate = report["agreement_rate"]
    window = report["window"]
    print(f"{tenant_id} [{stage}] {window['from']} .. {window['to']}")
    if rate is None:
        print("  nothing was comparable in this window.")
    else:
        print(
            f"  agreement {rate * 100:.1f}% over {report['compared']} pairs "
            f"({report['agreed']} agreed, {report['diverged']} diverged)"
        )
    if report["only_ours"] or report["only_theirs"]:
        print(
            f"  coverage: {report['only_ours']} only ours, "
            f"{report['only_theirs']} only theirs, "
            f"{report['unmapped_outcomes']} of theirs unreadable"
        )
    for row in report["divergences"]:
        print(
            f"  {row['client_id']} / {row['asset_id']} ({row['as_of']}): "
            f"we said {row['ours']}, they said {row['theirs']} "
            f"(their word: {row['theirs_raw']})"
        )
        print(f"      {row['explanation']}")
    if report["truncated"]:
        print("  (more divergences than shown; raise --limit or narrow the window)")


def main() -> int:
    parser = argparse.ArgumentParser(description="The weekly shadow comparison.")
    parser.add_argument("--json", action="store_true", help="machine-readable output")
    parser.add_argument("--since", help="ISO date; defaults to seven days back")
    parser.add_argument("--until", help="ISO date; defaults to today")
    parser.add_argument(
        "--tenant", help="one tenant, rather than every active one", default=""
    )
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    observability.configure()
    until = (
        date.fromisoformat(args.until)
        if args.until
        else business_time.platform_today()
    )
    since = (
        date.fromisoformat(args.since)
        if args.since
        else until - timedelta(days=WINDOW_DAYS)
    )
    if since > until:
        print("--since is after --until", file=sys.stderr)
        return 1

    try:
        found = _tenants()
    except maintenance.NoActiveTenants as exc:
        print(f"the comparison could not be produced: {exc}", file=sys.stderr)
        return 1
    if not found:
        print(
            "no active firms were enumerated at all. A weekly comparison that "
            "compares nobody is a broken report, not a quiet week.",
            file=sys.stderr,
        )
        return 1

    try:
        wanted = [
            (tenant_id, stage)
            for tenant_id, stage in found
            if not args.tenant or tenant_id == args.tenant
        ]
        reports = {
            tenant_id: (stage, _report(tenant_id, since=since, until=until))
            for tenant_id, stage in wanted
        }
    except Exception as exc:  # noqa: BLE001 — a scheduled report reports its own failure
        print(f"the comparison could not be produced: {exc}", file=sys.stderr)
        return 1

    # A firm mid-adoption with nothing comparable is the finding. Collected
    # before printing so the exit code covers every tenant, not the last one.
    silent = [
        tenant_id
        for tenant_id, (stage, report) in reports.items()
        if stage in COMPARING and not report["compared"]
    ]

    if args.json:
        print(
            json.dumps(
                {
                    "window": {"from": since.isoformat(), "to": until.isoformat()},
                    "reports": {
                        tenant_id: {"stage": stage, **report}
                        for tenant_id, (stage, report) in reports.items()
                    },
                    "not_comparing": silent,
                },
                indent=2,
            )
        )
    else:
        if not reports:
            print("no active tenants to compare")
        for tenant_id, (stage, report) in sorted(reports.items()):
            _render(tenant_id, stage, report)

    if args.evidence_out:
        evidence_io.write(
            "drills",
            "comparison-report",
            {
                "window": {"from": since.isoformat(), "to": until.isoformat()},
                "not_comparing": silent,
                "firms": sorted(reports),
            },
            passed=not silent,
            summary=(
                f"{len(reports)} firm(s) compared over "
                f"{since.isoformat()}..{until.isoformat()}; "
                + (
                    "every firm mid-adoption had something to compare."
                    if not silent
                    else f"{len(silent)} in shadow had nothing comparable."
                )
            ),
        )

    for tenant_id in silent:
        print(
            f"{tenant_id} is in shadow but nothing was comparable this week — "
            "either their outcomes are not being ingested, or the firm has "
            "stopped sending us cases.",
            file=sys.stderr,
        )
    return 2 if silent else 0


if __name__ == "__main__":
    raise SystemExit(main())
