"""
Look for credentials in the tree and in the history, and refuse to be quiet.

§S13 asks for dependency and secret scans clean. The dependency half is
`pip-audit` and `npm audit`, which are somebody else's databases. This half is
ours, and the design decision that matters is what "clean" is allowed to mean.

**Nothing is silenced without a reason attached.** This repository deliberately
commits three credentials — a development master key, the demo firm's password
and the load model's — and every one of them is written to say so in its own
value: `quolin-dev-key-not-a-secret-0001`. They are listed below with why. A
scanner tuned until it is quiet is a scanner that will be quiet about the next
one too, so an unexplained match is a failure and the fix is to explain it here
or to remove it.

**It reads git history, not only the working tree.** A key deleted in the commit
after it was added is still in the repository, still in every clone, and still
the thing to rotate. `--history` walks every blob; the default is the tree,
because that is what runs on every push and history does not change under you.

**Entropy is not used.** A high-entropy string in a test fixture is a hash, and a
scanner that flags hashes gets ignored within a week. This looks for the shapes
credentials actually have — provider prefixes, PEM headers, connection strings
with a password in them — and accepts that it will miss a bare token nobody can
recognise.

Usage:

    make scan-secrets
    make scan-secrets ARGS=--history

Exit codes: 0 when nothing unexplained was found, 1 when the scan could not run,
2 when something was.
"""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))

from scripts import evidence_io  # noqa: E402

#: What a credential looks like. Named, so a finding says what it thinks it
#: found rather than printing a regex at somebody.
PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("AWS access key id", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("AWS secret access key", re.compile(r"aws_secret_access_key\s*=\s*\S{20,}")),
    ("private key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("GitHub token", re.compile(r"gh[pousr]_[0-9A-Za-z]{36,}")),
    ("Slack token", re.compile(r"xox[baprs]-[0-9A-Za-z-]{10,}")),
    ("OpenAI-style key", re.compile(r"sk-[A-Za-z0-9_-]{32,}")),
    ("Anthropic key", re.compile(r"sk-ant-[A-Za-z0-9_-]{20,}")),
    ("Google API key", re.compile(r"AIza[0-9A-Za-z_-]{35}")),
    ("Stripe key", re.compile(r"[rs]k_live_[0-9A-Za-z]{20,}")),
    ("JSON web token", re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.")),
    # A connection string carrying a password that is not one of ours.
    (
        "database URL with a password",
        re.compile(r"postgres(?:ql)?(?:\+\w+)?://[^:\s/]+:(?!quolin|quolin_app|quolin_watch)[^@\s]{6,}@"),
    ),
]

#: Deliberately committed, each with the reason. A match is only allowed when
#: the line contains one of these strings.
#:
#: Every one of them says what it is inside the value itself, which is the point:
#: a development key that could be mistaken for a real one is a development key
#: somebody eventually deploys.
ALLOWED: dict[str, str] = {
    "quolin-dev-key-not-a-secret-0001": (
        "the development master key, decoded. `make seed` writes ciphertext and "
        "the suite reads it back, so it has to be the same everywhere. A hosted "
        "deployment takes its key from Secrets Manager and `make deploy-check` "
        "refuses without one."
    ),
    "cXVvbGluLWRldi1rZXktbm90LWEtc2VjcmV0LTAwMDE=": (
        "the same key, base64 — the form the Makefile and CI pass it in."
    ),
    "demo password not a real one": (
        "the seeded demo staff's password. The demo firm exists to be signed "
        "into in a meeting."
    ),
    "load model not a real one": (
        "the load model's operators. §S12's twenty sessions have to sign in, and "
        "twenty separate passwords in a file would be twenty secrets for nothing."
    ),
    "quolin:quolin@localhost": (
        "the local development database, in docker-compose and the defaults "
        "beside it. It listens on localhost and holds seeded fiction."
    ),
    "nobody:nobody@127.0.0.1:1/nothing": (
        "not a credential but a decoy, and the decoy is the test. "
        "tests/test_the_watch_sweep_runs_in_its_deployed_environment.py puts "
        "this in DATABASE_URL before running the watch sweep, so that a future "
        "change reading the variable directly rather than through `app.db` "
        "fails loudly instead of quietly succeeding against the developer's own "
        "server. Port 1 has nothing listening and the database is called "
        "`nothing`; the point is that connecting with it is impossible. Allowed "
        "as the exact string rather than by loosening the pattern, so a real "
        "DSN carrying a real password on any other line still fails this scan."
    ),
    "{role}:{PROBE_PASSWORD}@": (
        "not a credential but the f-string that builds one: "
        "tests/test_worker_tenant_enumeration.py derives a probe URL from the "
        "owner's so host and port stay in step. The password it interpolates is "
        "`quolin_probe`, a role the test itself CREATEs and DROPs against the "
        "local database, and the pattern's lookahead already exempts our own "
        "`quolin*` roles by name — it cannot see this one only because the value "
        "arrives through a placeholder. Allowed as the exact interpolation rather "
        "than by loosening the pattern, so a real connection string carrying a "
        "real password on any other line still fails this scan."
    ),
}

SKIP_DIRS = {
    ".git", "node_modules", ".venv", ".next", ".terraform", "__pycache__",
    ".pytest_cache", ".ruff_cache", "dist", "build",
}

SKIP_SUFFIXES = {
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".pdf", ".woff", ".woff2",
    ".ttf", ".otf", ".zip", ".gz", ".lock",
}


def allowed(line: str) -> str:
    for value, reason in ALLOWED.items():
        if value in line:
            return reason
    return ""


def scan_text(where: str, text: str) -> list[tuple[str, str, str]]:
    findings = []
    for number, line in enumerate(text.splitlines(), start=1):
        if allowed(line):
            continue
        for name, pattern in PATTERNS:
            if pattern.search(line):
                findings.append((f"{where}:{number}", name, line.strip()[:120]))
    return findings


def scan_tree() -> list[tuple[str, str, str]]:
    findings = []
    for path in _ROOT.rglob("*"):
        if not path.is_file():
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        if path.suffix.lower() in SKIP_SUFFIXES:
            continue
        # This file is a list of what credentials look like. Scanning it finds
        # every pattern it contains, which is not a finding about the repository.
        if path.resolve() == Path(__file__).resolve():
            continue
        try:
            text = path.read_text(errors="ignore")
        except OSError:
            continue
        findings.extend(scan_text(str(path.relative_to(_ROOT)), text))
    return findings


def scan_history() -> list[tuple[str, str, str]]:
    """Every blob this repository has ever held.

    A credential removed in the next commit is still in the history, still in
    every clone, and still the thing to rotate. Slow, so it is opt-in and runs
    on a schedule rather than on every push.
    """
    revs = subprocess.run(
        ["git", "rev-list", "--all"], cwd=_ROOT, capture_output=True, text=True, check=True
    ).stdout.split()

    findings = []
    seen: set[str] = set()
    for rev in revs:
        listing = subprocess.run(
            ["git", "ls-tree", "-r", rev],
            cwd=_ROOT, capture_output=True, text=True, check=True,
        ).stdout
        for line in listing.splitlines():
            try:
                meta, name = line.split("\t", 1)
                blob = meta.split()[2]
            except (ValueError, IndexError):
                continue
            if blob in seen or Path(name).suffix.lower() in SKIP_SUFFIXES:
                continue
            seen.add(blob)
            content = subprocess.run(
                ["git", "cat-file", "-p", blob],
                cwd=_ROOT, capture_output=True, text=True, errors="ignore",
            ).stdout
            findings.extend(scan_text(f"{rev[:8]}:{name}", content))
    return findings


def main() -> int:
    parser = argparse.ArgumentParser(description="Look for committed credentials.")
    parser.add_argument(
        "--history", action="store_true", help="every blob, not only the tree"
    )
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    try:
        findings = scan_history() if args.history else scan_tree()
    except subprocess.CalledProcessError as exc:
        print(f"the scan could not run: {exc}", file=sys.stderr)
        return 1

    if findings:
        print("credentials found:", file=sys.stderr)
        for where, name, line in findings:
            print(f"  {where}: {name}", file=sys.stderr)
            print(f"    {line}", file=sys.stderr)
        print(
            "\nIf one of these is deliberate, add it to ALLOWED in this file with "
            "the reason. Do not widen a pattern to make a finding go away: the "
            "next one will be real.",
            file=sys.stderr,
        )
        if args.evidence_out:
            evidence_io.write(
                "scans",
                "secret-scan",
                {
                    "scope": "history" if args.history else "tree",
                    "findings": [
                        {"where": w, "kind": k, "line": line} for w, k, line in findings
                    ],
                },
                passed=False,
                summary=f"{len(findings)} credential(s) found.",
            )
        return 2

    scope = "every blob in the history" if args.history else "the working tree"
    print(
        f"OK: no credentials in {scope}, beyond the "
        f"{len(ALLOWED)} development values listed with reasons in this file."
    )
    if args.evidence_out:
        evidence_io.write(
            "scans",
            "secret-scan",
            {
                "scope": "history" if args.history else "tree",
                "findings": [],
                "allowed_values": len(ALLOWED),
            },
            passed=True,
            summary=(
                f"No credentials in {scope}, beyond the {len(ALLOWED)} "
                "development values allowlisted with reasons."
            ),
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
