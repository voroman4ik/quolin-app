"""Cut traffic over to the other colour, and refuse to if it is not healthy.

§S9 asks for blue-green with instant rollback and §16 wants the rollback proven
in under two minutes. Proving it needs a deployed environment; building and
exercising the mechanism does not, and this is the mechanism.

**The health gate is the whole point.** A cutover that moves traffic and *then*
checks is a deploy that takes an outage to discover — the check has to happen
against the new colour while the old one is still serving, so a failure costs
nothing but the deploy. That ordering is the difference between blue-green and
a restart with extra steps.

**It refuses rather than proceeding on a partial answer.** A revision that
answers `/health` but reports the wrong revision id has not started the code we
think it has; one that answers slowly is one whose first real request will be
slower still. Both block. The failure mode this avoids is a deploy that
"succeeded" onto a container running last week's image.

**It records what it did.** Every cutover and every refusal files an evidence
artefact — §16's assessor asks how deploys are controlled, and "there is a
script" is not the answer to that question. See `docs/evidence.md`.

This drives docker compose, which is a laptop and not production. The shape is
the same as the ECS task-set swap in `infra/compute.tf`, and the numbers it
produces are about this machine. `docs/runbooks/rollback.md` says so where
somebody might otherwise quote them.

Usage:

    make bluegreen-up                 # bring the pair and the router up
    make cutover                      # cut to whichever colour is idle
    make cutover ARGS="--to green"
    make cutover ARGS=--dry-run       # health-check the idle colour, change nothing

Exit codes: 0 on a completed cutover, 1 when it could not run, 2 when the health
gate refused.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_ROOT))

from scripts import evidence_io

#: Where the router reads its live colour from.
ACTIVE = _ROOT / "infra" / "compose" / "active.conf"

COLOURS = ("blue", "green")

#: What the router answers on.
ROUTER = "http://127.0.0.1:8080"

#: How long a colour is given to become healthy before the gate gives up.
#:
#: Sixty seconds: long enough for a container that is genuinely starting —
#: WeasyPrint's fontconfig warm-up alone is several — and short enough that a
#: broken revision is known about before somebody wanders off.
HEALTH_TIMEOUT_SECONDS = 60.0

#: How often the gate asks.
POLL_SECONDS = 1.0


def _compose(*args: str, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["docker", "compose", "--profile", "bluegreen", *args],
        cwd=_ROOT,
        capture_output=True,
        text=True,
        check=check,
    )


def active_conf(colour: str) -> str:
    """The whole contents of the file the router reads.

    Header included, and written in full on every cutover on purpose: this file
    is committed so the router has something to start from, and a `write_text`
    that emitted only the upstream line silently deleted the explanation the
    first time anybody ran a drill. Somebody reading the repository a month
    later would find one cryptic line and no way to know what maintains it.
    """
    return (
        "# Which colour the router sends traffic to. Rewritten in full by\n"
        "# scripts/deploy.py and scripts/rollback.py, and read back by them to\n"
        '# answer "what is live right now" — so editing it by hand desyncs the\n'
        "# file from the running router until the next reload. Committed as blue;\n"
        "# `make bluegreen-up` resets it and reloads. See docs/runbooks/rollback.md.\n"
        f"upstream active {{ server api-{colour}:8000; }}\n"
    )


def live_colour() -> str:
    """Which colour the router is pointed at right now."""
    text = ACTIVE.read_text()
    for colour in COLOURS:
        if f"api-{colour}:8000" in text:
            return colour
    raise RuntimeError(
        f"{ACTIVE} names no known colour. It is rewritten by this script and "
        "by rollback.py; an unrecognised value means somebody edited it by hand."
    )


def idle_colour() -> str:
    return COLOURS[0] if live_colour() == COLOURS[1] else COLOURS[1]


def _ask(url: str, timeout: float = 3.0) -> tuple[int, dict]:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            return response.status, json.loads(response.read() or b"{}")
    except urllib.error.HTTPError as exc:
        return exc.code, {}
    except (urllib.error.URLError, OSError, TimeoutError, json.JSONDecodeError):
        return 0, {}


def health_gate(colour: str, *, port: int, timeout: float | None = None) -> dict:
    """Ask the new colour whether it is ready, before any traffic reaches it.

    Returns what it found rather than a bare bool: a refusal an operator can act
    on says *how* it failed, and "never answered" and "answered as the wrong
    revision" have different fixes.
    """
    deadline = time.monotonic() + (
        timeout if timeout is not None else HEALTH_TIMEOUT_SECONDS
    )
    last: dict = {"reason": "never answered"}
    attempts = 0

    while time.monotonic() < deadline:
        attempts += 1
        status, body = _ask(f"http://127.0.0.1:{port}/health")
        if status == 200:
            # It answers. Now: is it the code we just deployed? A container
            # still running the previous image answers exactly like a healthy
            # new one, which is how a deploy silently does nothing.
            reported = str(body.get("revision", "")) or "unreported"
            if reported not in (colour, "unreported"):
                last = {
                    "reason": f"answered as revision {reported!r}, expected {colour!r}",
                    "attempts": attempts,
                }
                break
            return {
                "healthy": True,
                "attempts": attempts,
                "revision": reported,
                "packs": body.get("packs"),
            }
        last = {"reason": f"HTTP {status}" if status else "no answer", "attempts": attempts}
        time.sleep(POLL_SECONDS)

    return {"healthy": False, **last}


def cut_over(colour: str) -> None:
    """Point the router at a colour and signal it to reload.

    A reload, not a restart: nginx finishes in-flight requests against the old
    worker, which is what makes a cutover invisible to somebody mid-request.

    This returns as soon as the signal is *sent*. It is not the moment traffic
    moves — see `confirm`, which is the moment that counts.
    """
    ACTIVE.write_text(active_conf(colour))
    _compose("exec", "-T", "router", "nginx", "-s", "reload")


#: How many consecutive clean answers count as "traffic has moved".
#:
#: Not one. See `confirm`.
CONFIRM_STREAK = 5

#: Spacing between those answers. Five at this spacing is about a second of the
#: router answering only as the new colour, which is long enough to have
#: outlived the reload's overlap and short enough not to pad a rollback time.
CONFIRM_PAUSE = 0.2


def confirm(
    colour: str,
    *,
    timeout: float = 15.0,
    streak: int = CONFIRM_STREAK,
    pause: float = CONFIRM_PAUSE,
) -> tuple[bool, str]:
    """Wait until the router answers *only* as the new colour.

    **Both halves of this were learned by running the drill, and both times the
    script had already reported success.**

    First: `nginx -s reload` signals the master and returns. The cutover on
    2026-08-26 reported success in 0.1s while the router was demonstrably still
    serving the previous colour — a green deploy log over an unchanged system,
    which is worse than a failure because nobody looks twice at it. So the
    signal is not the event; the router answering as the new colour is.

    Second, and less obvious: *one* such answer is not the event either. A
    graceful reload starts new workers before the old ones finish, and for a
    short window both accept from the shared listening socket. The rollback
    immediately after reported a confirmed 0.2s — and the next request through
    the router returned 504 from an old worker still trying the container we had
    just stopped. A confirmation that can be satisfied by whichever worker
    happens to answer first is not a confirmation.

    So it takes a run: `streak` consecutive answers as the target colour, any
    other answer resetting the count. The elapsed time a rollback is judged on
    runs to the end of that run, which is the first moment the claim "traffic is
    on the previous revision" is true of every request rather than of one.
    """
    deadline = time.monotonic() + timeout
    serving = "unreported"
    clean = 0

    while time.monotonic() < deadline:
        status, body = _ask(f"{ROUTER}/health", timeout=3.0)
        if status == 200:
            serving = str(body.get("revision", "")) or "unreported"
            # `unreported` is accepted: a deployment whose containers do not set
            # QUOLIN_REVISION cannot be checked this way, and refusing would
            # make the script unusable there rather than more careful.
            if serving in (colour, "unreported"):
                clean += 1
                if clean >= streak:
                    return True, serving
            else:
                clean = 0
        else:
            clean = 0
            serving = f"HTTP {status}" if status else "no answer"
        time.sleep(pause)

    return False, serving


def main() -> int:
    parser = argparse.ArgumentParser(description="Blue-green cutover, health gated.")
    parser.add_argument("--to", choices=COLOURS, default=None, help="target colour")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="run the health gate and change nothing",
    )
    parser.add_argument(
        "--timeout", type=float, default=HEALTH_TIMEOUT_SECONDS, metavar="SECONDS"
    )
    parser.add_argument(
        "--evidence-out",
        action="store_true",
        help="file the result in evidence/ as a dated, hashed artefact",
    )
    args = parser.parse_args()

    try:
        from_colour = live_colour()
    except (OSError, RuntimeError) as exc:
        print(f"could not read the live colour: {exc}", file=sys.stderr)
        return 1

    to_colour = args.to or idle_colour()
    if to_colour == from_colour:
        print(
            f"{to_colour} is already live. A cutover to the colour already "
            "serving is a reload with a misleading name.",
            file=sys.stderr,
        )
        return 1

    # Each colour publishes its own port for the gate to reach directly. The
    # point of checking the container rather than the router is that the router
    # is still sending everybody to the old colour.
    port = 8081 if to_colour == "blue" else 8082
    started = time.monotonic()
    gate = health_gate(to_colour, port=port, timeout=args.timeout)
    elapsed = time.monotonic() - started

    result = {
        "from": from_colour,
        "to": to_colour,
        "health": gate,
        "seconds": round(elapsed, 2),
        "dry_run": args.dry_run,
    }

    if not gate["healthy"]:
        print(
            f"refusing to cut over to {to_colour}: {gate.get('reason')}\n"
            f"  {from_colour} is still serving. Nothing moved.",
            file=sys.stderr,
        )
        if args.evidence_out:
            evidence_io.write(
                "deployments",
                "deploy",
                result,
                passed=False,
                summary=(
                    f"Refused to cut over from {from_colour} to {to_colour}: "
                    f"{gate.get('reason')}. Traffic never moved."
                ),
            )
        return 2

    if args.dry_run:
        print(f"{to_colour} is healthy. Dry run — {from_colour} is still serving.")
        return 0

    try:
        cut_over(to_colour)
    except subprocess.CalledProcessError as exc:
        print(f"the router would not reload: {exc.stderr or exc}", file=sys.stderr)
        return 1

    moved, serving = confirm(to_colour)
    total = round(time.monotonic() - started, 2)
    result["seconds"] = total
    result["confirmed"] = moved
    result["serving"] = serving

    if not moved:
        print(
            f"the router was pointed at {to_colour} and reloaded, but it is "
            f"still answering as {serving!r}. Traffic has not moved; do not "
            "record this as a completed deploy.",
            file=sys.stderr,
        )
        if args.evidence_out:
            evidence_io.write(
                "deployments",
                "deploy",
                result,
                passed=False,
                summary=(
                    f"Reloaded the router towards {to_colour}, but it was still "
                    f"serving {serving!r} {total:.1f}s later."
                ),
            )
        return 2

    print(
        f"cut over {from_colour} → {to_colour} in {total:.1f}s "
        f"(health gate passed on attempt {gate['attempts']}, "
        "confirmed through the router)"
    )
    if args.evidence_out:
        evidence_io.write(
            "deployments",
            "deploy",
            result,
            passed=True,
            summary=(
                f"Cut traffic from {from_colour} to {to_colour} in {total:.1f}s, "
                f"after the health gate passed on attempt {gate['attempts']}. "
                "Confirmed by asking the router, not by the reload returning."
            ),
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
