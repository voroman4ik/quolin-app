# Post-raise backlog

Ideas that are explicitly **out of scope** for the prototype. Nothing here goes
into code before the freeze. Adding to this file is the approved way to say yes
to a good idea without saying yes to building it now.

## Deliberately deferred

| Item | Why it is out |
|---|---|
| ~~Real authentication, SSO, roles~~ | **Superseded by Product Stage 2** — per-person identity, password and TOTP, OIDC single sign-on (`app/oidc.py`), roles granted per tenant, and separation of duties on overrides. The shared passcode is not disabled but deleted, and `scripts/guard_no_shared_passcode.sh` fails the build if a code path for one reappears |
| ~~Multi-tenancy~~ | **Superseded by Product Stage 1** — per-tenant rows, Postgres row-level security enabled *and* forced on every policed table, per-tenant encryption keys and a per-tenant evidence chain. `api/tests/test_rls.py` and `make rls-probe` assert it. One deployment still serves one tenant (`tenancy.configured_tenant`); a tenant switcher is below |
| ~~Second jurisdiction pack~~ | **Superseded by v2 phase 3** — three more regimes now ship, added with no change to the engine and guarded by CI. They are labelled `ILLUSTRATIVE` because what was deferred was consultant time, not engineering time. See `docs/jurisdictions-spec.md` |
| Commercial business-rules engine | The custom evaluator is dependency-free and fully explainable. The pack format is engine-agnostic, so migration is content-preserving |
| ~~Regulator returns generation~~ | **Superseded by v2 phase 2a** — returns and override register extracts are now generated from real recorded decisions, pack-templated. See `docs/reporting-spec.md` |
| Real CRM / custody / queue integrations | All three sit behind typed interfaces (`ClientProvider`, `PositionsProvider`, `QueueSink`) — swap implementations, not call sites |
| Charts, dark mode, settings screen, websockets | Scope creep with no bearing on the demo moment |
| Native mobile app | The PWA installs to the home screen and opens full-screen. A native build buys nothing for a demo |

## Deferred during v2

- ~~**Automated regression test for the offline path.**~~ **Done.** Playwright
  in `web/e2e/`, run by `make offline-test` and by CI. It starts and stops real
  servers rather than intercepting requests, because request interception does
  not reach a service worker — a test built that way would pass against an app
  with no worker at all. Six sabotage checks confirm it fails when the marker,
  the banner, the chain badge or either engine-dependent control stops working.
- **Verdict palette is not verified against a contrast checker.** REFER moved
  from `#8A6420` to `#9A5400` to stop colliding with the bronze accent; the new
  pair was reasoned about rather than measured, and no screen has been run
  through a colour-blindness simulator. The glyphs on the verdict banner mean a
  determination never rests on hue alone, which is the part that actually
  matters, but the tints themselves deserve a proper audit.
- **The audit export is not tamper-evident.** `audit_events` is append-only by
  trigger but is not hash-chained, so the CSV carries no arithmetic proof that
  no row was removed. This is stated on the response header, on the reporting
  screen and in both period PDFs rather than papered over, but the honest fix is
  to chain `audit_events` the way `decisions` are chained. That is a schema and
  write-path change, not a reporting change, which is why it was not folded into
  phase 2a.
- **Returns are generated, never lodged.** No submission endpoint, no lodgement
  calendar, no deadline tracking. A real return goes somewhere; this one is a
  document a human downloads. Nothing on screen suggests otherwise.
- **Period documents are not themselves in the evidence chain.** An `artefacts`
  row records that a document was generated, and the audit trail records who
  asked for it, but the PDF's own bytes are not hashed. Two documents generated
  a minute apart from the same period are indistinguishable in the record.
- **No position import.** A client CSV carries no holdings, and custody stays
  `fixtures/positions.json` until a real `PositionsProvider` replaces it. The
  consequence is not hidden: an imported client has no custody record, and that
  is said on the client screen, on `/integrations`, and on every import response.
  The reason it is deferred rather than bolted on is that inventing positions for
  an imported book would make the concentration figures look real, which is worse
  than a stated absence.
- **No file-upload endpoint.** The CSV arrives as text in a JSON body; the screen
  reads the chosen file in the browser and posts its contents. Fine for a book of
  a few hundred rows, wrong for a real one.
- **No column mapping or dialect detection.** The header must use the exact
  names in `docs/import-spec.md`. Every institution's export will disagree with
  them, and mapping is a UI problem worth solving properly rather than guessing
  at with fuzzy header matching.
- **No delete.** Import creates and updates. Removing a client is not an import
  operation, and doing it properly means deciding what happens to the decisions
  already recorded against them — which is a policy question, not a code one.

- **No jurisdiction selector on the reporting screen.** `/reports/periods` and
  `/reports/preview` both accept a `jurisdiction` parameter and default to the
  firm's own licence; the screen does not offer the choice. This is a deliberate
  narrowing rather than an oversight — a return is filed with a single
  regulator, so a screen that let an officer flick between regimes while
  composing one would invite filing a document under the wrong one. The right
  design is per-regime reporting scoped by which licence the officer holds,
  which is an access-control question the prototype does not answer.

- **Rationale prose carries raw scale values.** "SG 500 against AU 1000; HK
  2000" reads with the numbers in their stored units, while every other surface
  now renders `5.00%` / `10.00%` / `20.00%`. The prose is generated inside the
  resolver and is therefore inside the decision hash, so rewording it would make
  every existing cross-border decision fail replay. The fix is a migration that
  re-renders historic rationales and re-chains from the first affected decision
  — correct, and not something to do in the week before a raise.

- **Illustrative content is not diffable against a reviewed version.** When the
  HK, SG and EU packs are eventually reviewed, nothing in the system will show
  what the reviewer changed. Pack diffing already exists between versions of the
  same regime and would carry this for free once each regime has a second
  version; it is listed here so that the first review is not a silent overwrite.

- **Coverage gaps are stated but not tracked.** A client domiciled in a regime
  with no pack is flagged on their own screen and on every decision, but nothing
  answers "which regimes does our book need that we do not hold?". That is the
  question a compliance officer would actually ask of the shelf, and it is a
  small aggregation over client residency and domicile — deferred only because
  it is a new screen rather than a change to an existing one.

## Deferred during Product Stage 1

- **Ciphertext is bound to its tenant and its column, but not to its row.** The
  additional authenticated data is `quolin:v1:{tenant}:{table}.{column}`, so a
  sealed value cannot be moved to another customer or another field without
  failing authentication. It *can* be moved between two rows of the same column
  within one tenant — swapping two clients' names would decrypt cleanly. Doing
  it needs write access to the database as the owning role, which is the same
  access that could drop the policies outright, so this is not the weakest link
  today. The fix is to add the primary key to the AAD, which is easy for
  `clients` and awkward for `decisions`, where the identifier is assigned by the
  same INSERT that writes the ciphertext. Worth doing when there is a reason to
  touch the encryption format anyway.
- **The master key comes from the environment rather than from KMS.** The
  envelope is real — per-tenant data keys, stored wrapped, unwrapping key held
  outside the database — but the outer key is a secret in `fly secrets` rather
  than a key that never leaves a hardware module. Swapping it is two functions
  in `app/crypto.py` and no change to any stored ciphertext. It is deferred
  because the AWS account the S0 Terraform describes has not been created, not
  because the design resists it. The reasoning is in `docs/spec-changes.md`
  under Stage 1.
- **Nothing proves a backup is restorable.** Encryption at rest raises the cost
  of getting recovery wrong: a restored database without the matching master key
  is not a degraded system, it is an empty one. There is no drill, and a
  restore procedure nobody has executed is the same kind of paragraph the
  rotation script was written to stop being.

## Deferred during Product Stage 2

- **`MFA_REQUIRED_ROLES` is declared and enforced nowhere.** `app/models.py`
  names the four roles that can approve an override, sign rule content or grant
  another person a role, with a docstring explaining why each demands a second
  factor — and nothing reads the constant. Enforcing it at sign-in is a small
  change and was deliberately not made during a stage about gates: it is a scope
  addition, and it would lock out every seeded demo account, none of which has a
  factor enrolled. The quarterly access review reports each person holding one of
  those roles without one, and says in the finding that it is the only place the
  constant is checked. Enforce it when the demo accounts can be enrolled first.
- **An identity provider cannot provision.** A `sub` this deployment has never
  seen is refused rather than turned into an account. Just-in-time provisioning
  is what enterprise customers eventually ask for, and it is deferred rather than
  missed: an IdP that could create users *and* their roles would make a
  misconfigured directory group at the customer's end able to mint approvers, and
  would make the access-review report a description of that group rather than of
  who the firm decided to admit. Doing it properly means a group-to-role mapping
  the firm configures and the review can print.
- **One deployment serves one tenant, so a consultant cannot switch firms.**
  `user_roles` is per tenant and a person may hold roles at several, which is the
  arrangement §S2 asks for — but the session's tenant comes from the deployment,
  so a consultant signs in to whichever instance they are pointed at. A tenant
  switcher is a different feature: it needs a per-request tenant choice validated
  against that person's grants, and every audit row and RLS setting to follow it.
- **Rate limiting is in-process.** `app/auth.py` counts failed attempts in a
  dictionary, so a restart clears them and two instances do not share them. This
  is stated in `docs/deployment.md` rather than papered over. For a
  single-instance deployment it is the honest amount of machinery; a
  multi-instance one needs Redis, and a database table would serialise every
  login attempt through Postgres to fake it.
- **Nothing expires a `quolin_support` grant on its own.** The role is designed
  to be time-boxed and `user_roles.expires_at` is read at every permission check,
  so a lapsed grant stops working at the moment it lapses rather than at the next
  sweep. But nothing *requires* an expiry to be set when the grant is written —
  the access review reports an unbounded one as its loudest finding, which is a
  detection rather than a prevention.

## Deferred during Product Stage 3

- **Nothing checks that a rule compares matching units.** Every calc declares one
  — `post_trade_crypto_bps` is basis points, `post_trade_crypto_cents` is cents —
  and every threshold's name states one by convention. Nothing compares the two.
  A rule checking a bps figure against a cents threshold is wrong by a factor of
  ten thousand while reading perfectly sensibly, and it is exactly the mistake a
  specialist authoring content would make. The unit is already recorded on each
  calc; what is missing is a declared unit on each threshold and a validator rule
  that refuses a comparison across them. Deferred because it needs a change to
  every pack's threshold block, which is content the specialist should be
  authoring by then anyway.
- **A specialist cannot run the validator without the repository.** `make seed`
  and the publish endpoint both check a pack, so a fault is caught before content
  goes live — but a consultant drafting a pack in a text editor has no way to
  ask "is this valid" short of committing it. The messages were written for that
  person and they cannot yet read them. The S5 authoring workbench is where this
  belongs rather than a second command-line tool nobody installs.
- **The engine has no mutation testing.** The property suite caught one
  tautological test in this stage, by hand, because a deliberate mutation was
  tried against it. That worked and it does not scale: the honest way to know
  whether a test suite can fail is to break the code on purpose and see, and
  `mutmut` or `cosmic-ray` over `app/engine` would answer it for every test
  rather than for the one somebody thought to check. Worth doing before the SOC 2
  window closes, since "our tests pass" is a claim an auditor may reasonably ask
  us to evidence.
- **The corpus has no case from a real customer.** Every entry in `corpus/` comes
  from the demo cast or was written by hand to pin a boundary. The most valuable
  entries will be the ones taken from a determination a real firm disputed, and
  there are none yet because there are no real firms. Add the first one the day
  there is.

## Deferred during Product Stage 4

- **Custody read adapters, blocked on there being customers.** §S4 says to select
  vendors by the first customers' actual stacks. There are none, so naming two
  would be inventing the input the decision is meant to be made from. The
  interface is unchanged and the half that does not depend on it is built:
  positions by batch or manual attestation, with the source recorded in the
  snapshot. Pick the vendors from the first two signed customers' stacks and
  record the choice in `docs/spec-changes.md`, which is what §S4 asks for.
- **Large uploads are synchronous.** The API import and the batch sweep both
  process in the request or the run. A 32 MB ceiling keeps that bounded, and the
  file drop is already the asynchronous path in practice — a firm drops a file
  and a scheduler picks it up. What is missing is an upload that returns a run id
  immediately and processes behind it, which matters at the size where a firm
  would rather poll than hold a connection. It needs a worker, and there is no
  worker pool yet.
- **PGP and SFTP are described, not deployed.** `docs/integrations.md` states the
  per-tenant chroot and encryption at rest, and `app/batch.py` handles everything
  that happens once a file has landed. The transport itself is server
  configuration nobody has stood up, because there is no staging to stand it up
  on. Gated on the same Terraform everything else is.
- **Mapping transforms cover money, booleans and case, and nothing else.** The
  two obvious gaps are date formats — a firm sending `DD/MM/YYYY` has to convert
  before dropping — and enumeration mapping, where their `HIGH`/`MED`/`LOW`
  becomes our 1–5 band. Both are common. Neither was built because the closed
  list is the point: every addition is a thing that runs between a customer's
  book and a regulated determination, so each one should be added deliberately
  with its own tests rather than in a batch.
- **There is no console for credentials, webhook endpoints or mappings.** All
  three are created directly against the database today. A tenant administrator
  should be able to issue a credential, see the secret once, register an endpoint
  and roll its signing secret without us — and the access review already reports
  a credential with no expiry or no recorded owner, which is a finding nobody can
  currently act on without asking us. This is the most customer-visible gap left
  in the stage.
- **Idempotency keys are never swept.** They expire after 24 hours in the sense
  that a key older than that is ignored, but the rows stay. An unbounded table of
  every write ever made is a second copy of the decision history with none of its
  guarantees. A nightly delete of anything past the window is a few lines, and
  belongs with whatever job runs `purge_expired` for sessions.

## Deferred during Product Stage 5

- **The predicate editor is read-only, on purpose.** The workbench renders each
  rule's condition as a sentence and lets a specialist edit thresholds,
  provenance and metadata — but not the predicate itself. Every determination is
  made through the DSL, so the way to let a non-programmer author one is a
  structured builder that can only produce valid trees, with the field
  vocabulary and its units in front of them. A free-text box over JSON would be
  faster to build and would put a syntax error between a client and a
  regulator. This is the largest single piece of the workbench still owed.
- **`make settle` is a command, not a scheduled job.** The two transitions
  nobody performs — published becoming effective, effective becoming superseded
  — are recorded by a sweep that is safe to run twice and catches up if it was
  missed. Nothing runs it on a schedule yet. It belongs with the other periodic
  jobs (`purge_expired`, webhook delivery, the nightly replay) behind whatever
  runner S9 stands up, and until then a state can sit un-recorded for as long as
  nobody types the command.
- **A decline notifies nobody.** A pinned tenant that refuses a version writes a
  row with a required reason, which is the thing worth escalating — and then it
  sits in the database. There is no route to the specialist who authored the
  content, no queue, no view of "versions our customers have refused". The
  reason was made mandatory precisely because somebody should read it.
- **Advance policy is per tenant, not per jurisdiction.** A firm operating in AU
  and SG takes both regimes on the same terms. That is probably wrong for a
  multi-regime customer: the desk that reviews an AU threshold change is not the
  desk that reviews an SG one, and one of them may be ready when the other is
  not. The row already carries the jurisdiction, so this is a policy lookup
  change rather than a schema one.
- **The artefact preview picks its own sample.** It renders against the most
  recent determination in the regime, or the most recent period with data. A
  specialist checking how a long product name wraps, or how a zero-count return
  reads, cannot choose the case — and those are exactly the cases that break a
  template. Letting them pick a determination, or supplying a small set of
  deliberately awkward ones, is the useful version.
- **A draft carries no reviewer assignment.** IN_REVIEW records that content is
  waiting on a signatory, which makes "how long has this been sitting with us"
  answerable in aggregate, but not *whose* it is. With four specialists that is
  a conversation; with forty it is a queue nobody owns.

## Deferred during Product Stage 6

- **Three of the four regulators have no feed adapter.** ESMA publishes RSS and
  is polled live. ASIC, MAS and the SFC expose nothing machine-readable at the
  URLs their packs name — so those sources are reported as content gaps on every
  live sweep and are, in practice, still checked by a person. The work is not
  code: somebody has to find each regulator's feed, or decide that scraping a
  landing page is acceptable and own what happens when its markup changes.
  Written as a gap rather than papered over, because a `live` badge on a source
  nobody is actually reading would be the worst outcome available.
- **A page is an audit row and an exit code, not a page.** Nothing sends an
  email, opens an incident, or wakes anybody. The specialist owner is named in
  the record and on the screen; whoever runs the scheduler sees exit code 2.
  Wiring that to a real paging service belongs with S9's alerting, and doing it
  earlier would mean choosing a vendor before there is an on-call rota to page.
- **Tenants are not told when a source behind their regime goes dark.**
  `source.stale` has a producer now and `notify_tenants` is written, but nothing
  calls it on a schedule: the sweep pages us and the customer sees it on their
  currency screen if they look. A firm paying for monitoring should probably be
  told without having to look.
- **The model assist is off in every environment.** The code path, the retention
  table, the escalation rule and the guards are all built and tested, and no
  environment holds a credential. Turning it on is a decision with a running
  cost attached, and it should be made with a specialist watching the first few
  hundred classifications rather than by setting an environment variable.
- **A tenant's regimes are set by editing config directly.** There is no screen
  for it, which is the same gap the credentials and webhook endpoints have. A
  tenant administrator changing which regimes they are licensed in is a
  perfectly ordinary act that currently requires us.
- **The footer's pack count is the shelf, not the customer.** It reads "4 packs"
  on a screen listing three regimes, because the count comes from the product's
  own inventory rather than from this tenant's licences. Not wrong, and mildly
  confusing on a customer-facing page.
- **Feed parsing covers Atom and RSS 2.0 and nothing else.** A regulator
  publishing JSON Feed, or an HTML page with structured data, needs a new
  adapter. That is the right shape — each format is a thing that runs between a
  regulator and a determination and should be added deliberately — but it is
  worth knowing the list is two long.

## Deferred during Product Stage 7

- **Disclosures and acknowledgement records are not built, and the reason is not
  the template.** An acknowledgement record asserts that a client saw something
  and agreed to it. This product has no source of truth for that — no
  client-facing capture, no signature, no timestamp anybody could point at — and
  a document asserting a client acknowledged a disclosure, generated from
  nothing, would be the worst artefact in this repository. What is needed first
  is the capture: a disclosure presented, a response recorded, and the response
  in the evidence chain. The document is the easy part and comes after.
- **The periodic decision summary is the distribution return under another
  title.** Same figures, different framing — a board reads one and a regulator
  the other. A pack can declare it today with no code change, which is what
  Stage 7's scope work bought; what it needs is a specialist deciding what a
  board should be told, which is not an engineering question.
- **Nothing runs the artefact worker on a schedule.** `make artefact-worker` is
  a command. Month-end returns are the case that wants a schedule, and it
  belongs with the other periodic jobs behind whatever runner S9 stands up —
  alongside `make settle`, the watch sweep and webhook delivery, all of which
  are in the same position.
- **A failed job is visible and nobody is told to look.** `artefact.failed`
  reaches a customer's webhook endpoint, and the queue screen shows it. Neither
  pages anybody here, which is S9's alerting rather than this stage's.
- **Documents are not swept.** Every regenerated document writes a new sealed
  file named by its content hash, and the superseded one stays on disk. Correct
  while the old bytes might still be the ones a regulator holds — and unbounded.
  A retention policy needs somebody to decide how long a superseded document is
  worth keeping, which is a question for a compliance officer.
- **The queue has no priority.** A month-end batch of five hundred returns is
  claimed before an officer's single urgent document if it was queued first.
  Oldest-first is right for a backlog and wrong for that case, and the fix — a
  priority column, or a second lane — should wait until somebody has actually
  been made to wait.

## Deferred during Product Stage 8

- **One tenant's sweep cannot use more than one worker.** Determinations are
  hash-chained per tenant, so appends are serial by construction. At 383 pairs
  per second a hundred-thousand-pair book is four and a half minutes, which is
  fine — and a firm ten times that size is forty-five, which is not. The honest
  options are a chain per book segment, or a batched append that hashes a block
  of determinations together. Both change what the chain means, so neither is a
  performance tweak to be done in a hurry.
- **A delta report is capped at 400 rows in the document.** The full list is in
  the run record and the API returns two thousand, but a sweep that moved five
  thousand clients produces a PDF that says so and lists the first four hundred.
  A regulator asking for all of them gets a spreadsheet, which is a different
  artefact nobody has asked for yet.
- **Nothing routes a delta report to anyone.** It renders on request and is
  announced by `bulk.completed`. A pinned tenant's review window is the case
  that will want it pushed — "your preview is ready, you have eleven days" — and
  that belongs with whatever notification work Stage 9's alerting brings.
- **A profile change re-checks a client, but nothing calls it.** The trigger is
  built and tested; the client-update path does not invoke it, because Stage 8
  has no screen that edits a profile and the importer's semantics for "changed"
  need deciding first — a nightly drop that restates every field is not a
  hundred thousand profile changes.
- **The periodic review has no calendar.** It is due when its cadence has
  elapsed since the last one, which means the first review of a regime happens
  the first time the sweep runs rather than on a date somebody chose. A firm
  will want "the first business day of the quarter", and that is a scheduling
  feature rather than a cadence one.

## Deferred during Product Stage 9

- **The bad-deploy rollback has never been performed.** The infrastructure is
  written and the runbook assumes it: CodeDeploy blue-green, automatic rollback
  on the 5xx alarm, the previous task set held for an hour. Nobody has staged a
  bad deploy and timed the rollback, because there is no environment to stage it
  in. Until somebody does, "under two minutes" is a design intent rather than a
  measurement, and §S9's gate is not met.
- **Log aggregation is a retention setting, not a destination.** Logs are
  structured JSON on stdout with a 365-day CloudWatch retention, which is what
  §S9's twelve months means in practice — but nothing ships them to a system
  somebody searches during an incident. The line between "we keep logs" and "we
  can find the request a customer is asking about" is a log platform nobody has
  chosen.
- **The pager has no rota.** `QUOLIN_PAGER_URL` reaches whatever is on the other
  end of it. Who is on call, how escalation works when they do not answer, and
  what happens at 3am on a public holiday are all questions a pager service
  answers and a URL does not.
- **Alert thresholds have never been calibrated against real traffic.** Ten
  failed sign-ins against one account, a thousand queued documents — both are
  reasoned rather than observed. The first month with a real customer will move
  them, and the way to find out is a period where alerts fire and somebody
  records whether each was worth waking for.
- **The restore drill restores from a dump it takes itself.** That proves the
  data survives a round trip and the chains verify afterwards — which is the
  part that matters most — but it does not exercise RDS point-in-time recovery,
  the thing that would actually be used. A drill against a real PITR restore
  needs an AWS account and belongs with the first one.
- **Nothing tests the alerts end to end from a customer's point of view.** The
  game day proves each path fires; it does not prove a page arrives on somebody's
  phone, which is the only test that matters and needs a real pager integration.

## Deferred during Product Stage 10

- **The comparison report is a console and JSON report, not a rendered
  document.** §S10's gate asks that divergences be readable unaided, and the
  content is — rule, reason, a sentence, worst disagreement first. But the thing
  a compliance officer forwards to their head of risk is a PDF with a period on
  it, and Stage 7's artefact machinery is right there. It was not wired up
  because the artefact scopes are client, run and period, and a week is none of
  those; adding a weekly scope is a change to the artefact model, not a
  formatting job.
- **Divergences are classified by hand.** `incumbent_outcomes` carries a
  `classification` column with `our_defect` / `their_process_gap` / `untriaged`,
  and nothing sets it but a person. That is deliberate — see the spec-changes
  note on why the system does not grade its own disagreements — but the workflow
  around it (who triages, on what cadence, and what happens to a confirmed
  defect) is a process nobody has designed.
- **Ingesting the incumbent's outcomes assumes somebody exports a file.** There
  is a vocabulary map so a firm's own words (`approved`, `knocked back`) become
  outcomes, and unrecognised words are reported rather than guessed. What there
  is not is any connector: the first customer will hand over a spreadsheet, and
  the shape of that spreadsheet will be a surprise.
- **No per-rung rate limits.** `limited` restricts *which* cases go live, not how
  many. A firm that moves to `limited` and then routes its entire book through
  the named segment is fully live by another name. A cap per rung is the obvious
  guard and belongs with real traffic to calibrate against.
- **Onboarding is instrumented for one firm at a time.** `GET /adoption` reports
  the days from contract to shadow for the firm asking. The number §S10's target
  is actually about — the median across every firm onboarded this quarter — has
  no home yet, because there is no cross-tenant reporting surface and building
  one is a decision about who is allowed to see across customers.
- **A firm cannot be put back to `pilot` from the product.** Retreat down the
  ladder works and is recorded, but `POST /adoption` is the only path to it and
  it is a `tenant_admin` action. Pulling a firm back during an incident is
  something an operator should be able to do at 3am without the firm's own
  admin, and that is an operator surface nobody has built.

## Deferred during Product Stage 11

- **No stack has ever been applied.** Everything in
  `docs/runbooks/dedicated-stack.md` is written against the Terraform that would
  execute it, and the two acceptance checks in it run on every CI push — against
  the development database and a locally started API. Nothing has touched AWS,
  because there is no AWS account. The gate's "under one day" is therefore a
  target, not a measurement, and the first real execution is owed alongside the
  staging deploy and the PITR drill, which are blocked on the same thing.
- **There is still no single "provision a tenant" call.** Creating one means the
  tenant row, its data key and its chain anchor, assembled by hand from the same
  three pieces in `api/seed/seed.py`, the Stage 10 test fixture, and step 4 of
  the dedicated-stack runbook. Three copies of a procedure that must not drift.
  It was noted in Stage 10 as a thing to fix before the first customer; standing
  up a stack is the moment it stops being a note.
- **Nothing enforces that a dedicated stack holds one tenant.** The RLS probe
  checks it and will say so, but it is a check somebody runs rather than a
  constraint the database holds. Enforcing it properly means either a per-stack
  migration — which is the fork Stage 11 exists to avoid — or a configured
  tenant pin the application refuses to serve outside, which is a behaviour
  difference between tiers and needs deciding rather than assuming.
- **No fleet view.** Each stack is its own Terraform state, its own database and
  its own everything, which is the point — and it means "which stacks are on
  which image tag", "which are behind on migrations" and "which have not had a
  restore drill this quarter" have no answer. With two stacks that is a spread-
  sheet; with twenty it is an outage nobody sees coming.
- **The tear-down is a documented procedure, not a script.** `tofu destroy` is
  one line; the four things around it — take the final dump, honour the
  contractual retention term, retire the range, remove the tfvars — are prose in
  a runbook. Every one of them is a thing somebody does at the end of a
  commercial relationship, which is exactly when attention is elsewhere.
- **The certificate path has one silent failure mode.** A validation record
  written into a zone that does not serve the domain never validates, and
  Terraform waits rather than failing. The runbook says to check the zone id
  first when the apply hangs, which is a person remembering a sentence rather
  than the tooling refusing a wrong zone up front.
- ~~**`api_desired_count` is still 1, in every tier.**~~ **Superseded, and it was
  wrong when written.** Login rate limiting reads `auth_attempts` from the
  database, so it was already shared across instances — a second task does not
  halve the lockout. `prod.tfvars` now sets `api_desired_count = 3`. What
  remains is the honest version: three is a number that met a budget on one
  developer machine, with no autoscaling rule and no measurement of where the
  next knee is. Left visible rather than deleted because this entry was quoted
  in `README.md` and `docs/deployment.md` as a current limitation for several
  stages after it stopped being true.

## Deferred during Product Stage 12

- **The numbers have never been measured on staging.** §S12's gate asks for the
  load targets on staging with production-shaped volumes; these were measured on
  a development machine against a model this repository generates. That makes
  them evidence about the shape of the system and not about a deployment's
  latency. Blocked on the same missing AWS account as §S2's access review and
  §S3's nightly replay.
- **One deployment still serves one tenant.** `tenancy.configured_tenant` pins
  it, so the load test drives twenty sessions in one firm against tables holding
  twenty. A shared deployment serving many firms concurrently needs sign-in to
  resolve the tenant from the person's grants — which is the tenant switcher
  already deferred, and is now also a scale question rather than only a
  convenience one.
- **`api_desired_count` is 3 because 3 met the budgets, not because 3 is right.**
  There is no autoscaling rule, no measurement of where the next knee is, and no
  load shedding: past the thread limiter, requests queue rather than being
  refused. A 503 with a `Retry-After` beats a request that arrives in ninety
  seconds, and nothing issues one.
- **PDF rendering still happens inside a request.** §S7 built a queue and a
  worker so a hundred documents would not block the API, and `/artefacts/tmd`
  renders inline anyway because the demo's third tap is a document appearing.
  It is several hundred milliseconds of CPU during which that process serves
  nobody, and it is the single largest consumer under load. Moving it behind the
  queue is a change to what the third tap feels like, which is a product
  decision rather than a performance one.
- **The bounded chain check is a weaker claim than the badge suggests.**
  `evidence.verify_tail` proves the last fifty links and the tip; it cannot prove
  nothing was altered a year ago. The result says `scope: "tail"` and the full
  walk runs nightly, but the screen's chain badge does not yet distinguish the
  two, so a reader sees the same tick for both. The badge should say which check
  it is reporting.
- **Queue priority has two levels and no ageing.** A batch queued on Monday
  behind a steady trickle of interactive work waits for a gap. The claim is
  ordered rather than filtered, so a gap is enough — but nothing promotes a job
  because it has been waiting, and under genuinely continuous interactive load
  that is a starvation the other way.
- **The load model cannot be deleted.** It writes real determinations into
  append-only tables, which is why its numbers mean anything and why `--drop`
  does not exist. Starting over means rebuilding the schema. That is correct and
  it makes the model awkward to use on a database anybody cares about.
- **Nothing measures the API's memory.** Three processes each hold WeasyPrint's
  fontconfig state and a connection pool, and `api_memory` is 1024MB reasoned
  from "a document is held whole while rendering". Whether three tasks fit the
  instance they are scheduled on has been calculated and not observed.
- **Auth attempts accumulate forever.** The table is append-only and nothing
  prunes it. That is the right default for security evidence and it is unbounded
  growth on the login path, which is the one table an attacker can make large.

## Deferred during Product Stage 13

- **No penetration test has been performed.** §S13's gate is "zero open
  pen-test findings above low", and there are no findings because there has been
  no test. `docs/threat-model.md` is an internal review by the people who wrote
  the code, and it says so. This is the single largest owed item in the plan.
- **The audit trail is still not hash-chained.** Named as T3 in the threat model
  and the largest unmitigated item in it. `audit_events` is append-only but
  carries no arithmetic proof that no row was removed, which is stated on the
  export and in the evidence pack rather than papered over.
- **An operator reading a customer's data leaves no record.** The owning
  database role bypasses row-level security by definition. Nothing stops it and
  nothing logs it; database-level audit logging is not configured.
- **The chain can still be rewritten by whoever can re-chain it.** The hash
  chain makes an edit impossible to hide *unless* the editor also recomputes
  everything after it, and `scripts/rechain.py` does exactly that because a
  legitimately broken chain has to be repairable. Anchoring in something outside
  our control — a transparency log, a counterparty, a notary — is what closes
  it.
- **The evidence sign-off is an attestation, not a signature.** `--signed-by`
  resolves to a provisioned person holding a role, and records their name beside
  the file hashes. The stronger form is what pack signing already does:
  re-authenticate through the product and capture the content hash against the
  session. That needs the evidence pack to be a product surface rather than a
  script.
- ~~**The offline path is still verified only by hand.**~~ **Closed**, and it
  found something. Serving a *production* build to drive the tests showed every
  dynamic route requesting the record `undefined`: `params` is a Promise in Next
  16 and six page components read it synchronously. `npm run build` compiles
  that without complaint, and the demo and `make tunnel` both run `next dev`, so
  nothing had ever exercised a production-built detail screen. What remains by
  hand is the phone: a real iOS install over HTTPS, which no runner reaches.
- **Dependency review is advisory-driven only.** `pip-audit` and `npm audit`
  catch what is already published. There is no lockfile-diff review, no
  vendoring and no package allowlist, so a compromised patch release of
  something already trusted lands on the next install.
- **Nothing scans for secrets outside this repository.** The scan covers the
  tree and the git history. Credentials in CI logs, in a developer's shell
  history, or in the Terraform state file — which holds the generated database
  password by design — are outside it.
- **The evidence pack is assembled on demand, not on a schedule.** A quarterly
  control that depends on somebody remembering to run a command is a control
  that has a gap the quarter somebody is on leave.

## Deferred during the external review fix-pack

- **Recording a manual verification is not a product surface.** A source
  declared `MANUAL` carries the date somebody last looked, and nothing in the
  product lets them say so — the seed asserts a date so the state is visible and
  testable. A person confirming they checked a publication is a screen and an
  endpoint, and until they exist a real deployment's manual sources drift to
  STALE and stay there, which is honest and unhelpful.
- **A page digest cannot say what changed.** It raises a queue item saying the
  page moved, which is the signal the triage tiers take, and a human then opens
  the page. Diffing the extracted text and showing what moved would turn that
  into a reviewable item rather than an errand.
- **Nothing rate-limits the sweep per publisher.** The cadence keeps a source
  from being read more often than its pack asks, and there is no backoff if a
  publisher starts refusing us, beyond the failure counter that pages an owner
  after three. A polite watcher that is being blocked should slow down, not keep
  knocking at the same rate.
- **The audit chain is verified on request, not on a schedule.**
  `GET /evidence/verify` walks it and the evidence pack files the result, but
  nothing checks it nightly the way the determination replay is checked. A
  forged audit row would be found whenever somebody next looked.
- **`rechain.py` rewrites hashes an auditor may already hold.** That is
  unavoidable for a repair tool and it means an export taken before a re-chain
  cannot be compared with one taken after, except through the
  `evidence.rechain` audit row that records why. Anchoring outside our own
  database is what would close it, and is already listed under T1.

## Deferred during Part A

- **No dual-secret window for webhook rotation.** One secret per endpoint means
  rotating it is a brief period of failed-and-retried deliveries rather than a
  seamless cutover. Accepting two secrets for an overlap is the standard answer
  and is not built; `docs/webhooks.md` tells a customer's engineer so rather
  than letting them discover it during a rotation.
- **A firm cannot manage its own webhook endpoints.** Adding, rotating and
  disabling one is something we do for them. The delivery machinery is real; the
  self-service around it is not.
- **Webhook delivery is not ordered.** Retries mean a failed earlier event can
  arrive after a successful later one. Documented rather than fixed, because
  ordering across retries needs a per-endpoint sequence and a receiver willing
  to hold a gap.
- **The evidence room's digests are self-attesting.** An artefact records that a
  control ran and catches its own alteration; it cannot show a run happened,
  because whoever can write the folder can write an artefact. Signing artefacts
  with a key the writer does not hold, or filing them somewhere we cannot edit,
  is the stronger version.

## Worth doing early after the raise

- Pack authoring from scratch. Stage 5 built the workbench and the draft
  lifecycle — create, edit, validate, submit, sign, publish, reject — so a
  consultant amends rule content on screen rather than in a text editor. What is
  missing is starting a regime from nothing: today a draft begins from the pack
  in force or from a watch event, which is the right default and is not the
  first-jurisdiction case.
- Pack signing with a **cryptographic key**. Stage 5 made the signature real in
  every other sense — the signatory is the person holding the session rather
  than a name in the request body, their `pack_signatory` grant has to name that
  draft's jurisdiction, a credential must have been presented in the last few
  minutes, and the content hash is captured. What it is not is a signature
  anybody outside this system can verify without trusting our database.
- Decision-level access control. Per-officer audit identity landed in Stage 2 —
  every action names the account that took it — but *which decisions* a given
  officer may see is still tenant-wide rather than per book or per client.
- ~~Backfill / bulk evaluation for a whole book, with progress and a report.~~
  **Superseded by Product Stage 8** — `app/bulk.py`, chunked and resumable, with
  per-run stats and a delta report. What remains is scheduling policy: a sweep
  is triggered by a pack becoming effective or by hand, and nobody has decided
  what a firm's standing re-check cadence should be.
- Positions from real custody, including intraday revaluation.
