# The evidence room

What proves a control operated is a dated artefact somebody filed when it ran —
not the script that would run it, and not a paragraph describing what it does.
The external review put it in one line: **a generator is not evidence**.

This document is what to read before handing the room to an auditor, and what to
read when deciding whether the room is in good order.

## Why it has to start now

A SOC 2 observation window is wall-clock. There is no way to produce six months
of history in the month somebody asks for it, and a folder that appears fully
formed the week before an assessment is worth less than an empty one — it
invites the question of where it came from.

So the room accumulates from today, and the honest state of a control that has
not run is an empty folder. Nothing here writes an artefact for a control that
did not operate.

## What is in an artefact

Every artefact is a pair: a `.json` an index can walk and a `.md` a person can
read without tooling. Both carry:

| Field | Why it is there |
|---|---|
| `control` | Which control ran |
| `ran_at` | When, in UTC |
| `environment` | **Which deployment.** A drill against a laptop and one against staging are different facts, and a room that does not distinguish them lets the weaker be read as the stronger |
| `git_sha` and `working_tree_dirty` | Which code, and whether the tree matched it |
| `invoked_by` | Who ran it, or which CI workflow |
| `passed` | The verdict, or `null` where a verdict would be wrong — an access-review finding is a question for a person, not a defect |
| `result` | Whatever the control returned |
| `content_sha256` | A digest of the artefact itself |

## What the digest does and does not prove

It shows that an artefact was **altered after it was filed**.

It does not show that a run happened. Somebody with write access to this folder
could author a convincing artefact, and no amount of hashing inside the folder
changes that. `scripts/evidence_index.py` says so in its own output, because an
index that implied otherwise would be making exactly the overstatement this room
exists to avoid.

The stronger version — artefacts signed by the environment that produced them,
or filed somewhere we cannot write — is a real improvement and is not built.

## Cadence

`CADENCE_DAYS` in `scripts/evidence_index.py` states how often each control is
expected to produce evidence. It is **stated, not inferred from the folder**: a
control's own history cannot be the standard it is measured against, or one that
quietly stopped a year ago would look perfectly regular.

| Control | Expected | Why that interval |
|---|---|---|
| `nightly-replay`, `health-checks` | daily | They run on a schedule; a missing day is a scheduler that stopped |
| `secret-scan`, `load-test`, `comparison-report` | weekly | Weekly is what CI runs and what a firm in shadow reads |
| `isolation-probe`, `smoke-test` | monthly | Cheap, read-only, and the answer changes slowly |
| `access-review`, `restore-drill`, `game-day` | quarterly | The cadence the control itself is written around |
| `deploy`, `rollback`, `incident`, `pack-signature` | on occurrence | No clock. An empty `incidents/` is good news, not a hole |

A control past its cadence is reported as a gap with the number of days. A
control that has never run is reported differently, because "stopped" and "never
started" are different conversations.

**Gaps do not fail the index.** It exits non-zero when an artefact is *damaged*,
because that is a fact about the room. A gap is a fact about the programme, and
the person reading needs to see it rather than have the report refuse to render.

## Filing evidence

Every generator takes `--evidence-out`:

```bash
make access-review  ARGS=--evidence-out
make restore-drill  ARGS=--evidence-out
make game-day       ARGS=--evidence-out
make scan-secrets   ARGS="--history --evidence-out"
make nightly-replay ARGS=--evidence-out
make rls-probe      ARGS=--evidence-out
make evidence-index
```

Set `QUOLIN_ENVIRONMENT` when running against anything that is not a developer
machine. Unset, it files as `local`, which is correct today and will be wrong
the day staging exists.

## Retention

Artefacts are kept indefinitely and are never edited. If one is wrong, file a
new one — the room is append-only by convention, the same way the evidence
tables are append-only by trigger, and for the same reason.

Contents are gitignored. An artefact names people and describes one deployment
on one day; a repository somebody clones is the wrong place to distribute
either. The folders themselves are committed so the room exists in a fresh
checkout.

## Handing it to an auditor

1. `make evidence-index` — the map. What exists, what is damaged, where the
   gaps are.
2. `make evidence-pack ARGS='--signed-by <reviewer>'` — a hashed, manifested
   bundle for one window, with a named sign-off.
3. `docs/threat-model.md` — the controls' reasoning, including what it cannot
   tell you.

Say plainly which artefacts were produced against a developer machine. As of
this writing, that is all of them.
