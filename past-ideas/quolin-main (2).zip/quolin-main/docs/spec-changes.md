# Spec changes

Change control: the build spec changes only by agreement between Daniel and Vova,
recorded here as a dated note. Verbal scope changes don't exist.

---

### 2026-08-31 — a wider one-time-code window, and the two guards that keep it on a laptop

A demo driven from a terminal and a browser at once loses to a thirty-second
code: it expires between the window you copy it in and the window you paste it
in. The fix asked for was a wider window. The thing worth recording is not the
width — it is what the width was allowed to be gated on.

**The window is one constant, and it is not a library parameter.**
`app/totp.py` is written out rather than imported (RFC 4226 and 6238, checked
against the published vectors in `tests/test_totp.py`), so there is no
`valid_window` argument to pass and no dependency's default to reason about.
The whole window is `SKEW_STEPS`, read once at import from
`QUOLIN_TOTP_WINDOW_STEPS`, consumed by the loop in `verify`.

**Widening it is a downgrade of the factor, stated in those terms.** Each step
is another thirty seconds in which a code read over a shoulder, left on a
screen, or captured in transit is still accepted. Ten steps — what
`.env.example` sets — is a five-minute replay window on the second factor. That
is a fine trade on a laptop nobody is attacking and an indefensible one
anywhere else, so the question the change had to answer was not "is this safe"
but "what makes it impossible for this to be somewhere it is not safe".

**Absence is the safe configuration, which is what makes the guards cheap.**
Unset, empty, mistyped and negative all fall back to one step. So a deployment
is correctly configured exactly when the variable is not there, and both guards
can check for presence rather than for a value:

- Fly: `make deploy-check` refuses while the variable appears in
  `fly secrets list`. Presence is the whole test and that is not a half-check —
  `fly secrets list` prints digests and never values, so a value comparison was
  never available, and it is also not needed.
- ECS: nothing new was written. `scripts/guard_task_credentials.py` is an
  allow-list of the variables each task may hold, and the variable is
  deliberately not on it, so a task definition that gains it fails `make guard`
  without anybody having predicted this particular variable. That is the
  property FP3-04 bought and this is the first change to collect on it.

Both were verified by mutation rather than by reading: the variable was put in
the API task definition and the guard failed; a stub `flyctl` reported it as a
secret and `deploy-check` refused, with the variable absent it passed.

**Fails to the safe value, does not fail to start.** A typo returns one step and
logs why. The alternative — refusing to boot because a developer wrote `ten` —
puts a parse error in the login path of every deployment to protect a laptop.

**Capped at twenty steps.** `verify` walks every step in the window, so the knob
is also a work multiplier; an unbounded value turns one login attempt into as
many HMACs as it likes.

**`.env.example` documents the shell form, because nothing loads that file.**
`make api` and `make test` take the environment from the shell, and the compose
API services are behind the `bluegreen` profile — a cutover rehearsal, not the
dev server. A line in a file nothing reads would have looked like a setting and
behaved like a comment.

Verified: full suite green (3611 passed, 13 skipped) both with and without the
variable exported — the standards test in `test_totp.py` is now pinned to the
default so a developer who exported it for a demo does not then watch RFC
conformance fail. `make guard`, `ruff` and `mypy` clean. A two-minute-old code
validates with the window widened and is refused without it, asserted in a real
subprocess with a real clock so the environment read itself is under test.

Not done, and recorded rather than fixed here: `QUOLIN_WEBHOOK_ALLOW_PRIVATE`
(`app/webhooks.py`) is the same shape of local-only escape hatch — it disables
the SSRF check on webhook targets — and has the ECS half of this protection by
the same allow-list and no Fly half at all. `deploy-check` says nothing about
it.

---

### 2026-08-29 — the enforcement layer: a binding nothing would break is not a binding

Two audits, both dated 2026-08-29, reviewed the attestation-binding sweep
recorded in the entry below. Both confirmed it: all four content-attesting
routes are genuinely bound, executed and attacked over HTTP with a full matrix —
stale hash, bare POST, empty string, whitespace, case, prefixed, re-read-then-
attest — and every one refused or accepted correctly. No fifth sibling exists;
every identity column in `models.py` was traced to its writer. Both previously
recorded caveats were handled.

One gap survived, and it was found by executing rather than by reading.

**The census tests the classification, not the recorder.** Two things were
injected into a scratch copy of this tree and the whole suite stayed green:

1. a route classified `binds=False` with a plausible five-word reason. The
   census asks for a reason and cannot ask whether it is true.
2. a route classified `binds=True`, with a `*_content_hash` field added to its
   Pydantic model, **whose handler never read the field.** The schema assertion
   passed because the field existed. Nothing looked at the recorder.

So a future route could carry `signed_content_hash: str = Field(min_length=1)`
for show, compare nothing, and sit in the same table as the four that enforce.
The census's own docstring says the thing that has to be true — *"reclassifying
it would have to break this"* — and says it about the classification layer. This
round extends it to the enforcement layer.

The second injection is the one that matters, and it is the fifth restatement of
the same defect: a record that *looks* like an attestation and is not one. F1's
row named a reviewer who had not read the bytes. This one would be a census row
naming a binding that does not bind. Same shape, one level up.

---

#### Item 1 — four HTTP enforcement probes, and a registry that makes them a rule

`api/tests/test_a_binding_nothing_would_break_is_not_a_binding.py`. One probe per
`binds=True` route, each over HTTP against the real recorder, each carrying one
draft through **both** outcomes:

| Route | Wrong hash | Asserted unwritten after the refusal | Right hash |
|---|---|---|---|
| `POST …/second-review` | 409 | `second_reviewer_user_id`, `second_reviewer`, `second_reviewed_at`, `second_reviewed_content_hash`, status still `DRAFT` | 200, reviewer and hash recorded |
| `POST …/sign` | 409 | `signed_by`, `signed_by_user_id`, `signed_at`, `signed_qualification_ref`, `content_hash`, status still `DRAFT` | 200, status `SIGNED`, hash is what was read |
| `POST …/approve-publication` | 409 | no `publication_approvals` row for the draft, status still `SIGNED` | 200, one approval, hash is what was read |
| `POST …/publish` | 409 | `published_by_user_id`, `published_pack_id`, status still `SIGNED` | 200, status `PUBLISHED`, pack allocated |

Three things about the shape, each of which is a way a probe like this goes
wrong:

**Both halves, on one draft.** Refusal alone cannot tell a working binding from
a route that refuses everything, and a check that blocks the ordinary path is a
check somebody removes on a Friday. The same person, the same draft, the same
session: refused for a stale screen, accepted the moment they re-read.

**The column, not only the status code.** A recorder that answered 409 and wrote
the row anyway would pass a status assertion and fail the only thing that
matters. Read from the row through the owner connection rather than from
`view()` — `view()` is a projection with opinions, and asking it whether a
signature happened is asking the code that would have to be wrong for the write
to have happened.

**`second-review` had no HTTP probe at all.** It was the first route bound (F1)
and the census file reaches it only in-process, through
`drafts.record_second_review`. Its 409 mapping, its payload wiring and the field
name the route forwards were never attacked from outside. They are now.

**The registry.** `@probes(method, path)` files each probe against a census
entry at import time, and the walking test
`test_every_route_that_claims_to_bind_has_an_http_enforcement_probe` reads
`CENSUS` — imported from the census file, not copied — and fails if a `binds=True` entry has no probe. That is what turns "four routes
happen to be probed" into "no route can claim a binding without proving it". It
also refuses an orphaned probe registered against a route the census no longer
calls bound, checks that each probe's body names the path it is filed under, and
checks that each asserts both a refusal and a success.

`test_the_probes_are_tests_pytest_will_actually_run` closes the last gap:
`@probes` returns the function unchanged, so a probe renamed out of pytest's
convention would still register, still satisfy the walking test, and never run.

**Tests for the tests.** Each of the four recorders was reverted in turn — the
call to `_the_bytes_that_were_read` replaced by `content_hash(draft.body)`,
which is B1's shape and the defect this sequence is about — and each time
**exactly that route's probe failed and the other three passed.** The census
file's schema test passed on every one of the four reversions, which is the
finding this file answers. Every failure landed on the refusal assertion, since
a recorder that has stopped comparing answers 200 and the probe never reaches
its column checks; those checks are for the other shape, a route that refuses
with the right code and writes anyway.

The registry was mutated too. Removing one `@probes` registration fails the
walking test naming the route. Swapping two registrations initially **passed** —
`inspect.getsource` hands back the decorator line, so the path check was
satisfied by the registration it was supposed to be checking. `_body_of` strips
decorators before the check; the swap fails now. It is recorded here rather than
quietly fixed because it is the same defect as the one this round is about: a
check that appears to verify something and is satisfied by the thing it is
verifying.

#### Item 2 — the GET-provenance boundary, recorded

`WRITE_METHODS` is `{POST, PUT, PATCH, DELETE}` and the census is over that set
only. This was a scope decision nobody had written down, and "we only checked
write methods" is exactly the sentence a diligence engineer asks about.
`docs/threat-model.md` records it under T10, in the same register as the
authorship-model limit.

Two corrections to the finding as it was reported, both from executing the
enumeration rather than reading it:

* **`GET /audit/export` writes nothing.** It reads `audit_events` and returns
  CSV. It is the route people assume writes a row, which is why the entry says
  so explicitly.
* **Five GET routes write a person's name, not two.** `/clients/{id}`,
  `/decisions/{id}` and `/artefacts/{id}/pdf` write through
  `service.audit_read` — FP3-14's answer to thirty audit calls covering no GET
  at all — `/audit/certificate` writes through `service.audit`, and
  `/auth/oidc/callback` writes a session row and an audit event and is a GET
  only because the OAuth redirect makes it one.

The reasoning is the entry's substance: provenance answers *who asked*,
attestation answers *who vouched for these bytes*. Only the second has a window,
because only the second has content that can move between the reading and the
claim. Binding a GET to a content hash would not be a weaker control; it would
be a meaningless one. And the boundary is stated in terms of what a route
records rather than which verb it uses, so a future GET that starts writing
something attestation-shaped is caught by a person reading the paragraph.

**The optional widening was considered and not done**, and the reason is
recorded rather than left as silence. Enumerating GET routes in the census means
classifying forty-nine further routes to record that forty-four write nothing,
and the check that would make it mechanical — asking which endpoints call
`service.audit` — is static analysis of `api/app` source from a test, which
`test_no_test_reads_source.py` forbids without an allow-list entry, on an
allow-list whose own test says it must not grow. So this catch is a human one,
and the threat model says so rather than implying otherwise.

---

**Verified here.**

- Full suite: **3589 passed, 13 skipped, 0 failed.** The baseline was 3576
  passed with the same 13 skipped. The thirteen new are six tests in the new
  file plus the seven parametrisations two meta-tests generate over it — six
  from `test_a_test_asserts_what_its_name_claims` and one from
  `test_no_test_reads_source`. The node-id diff was taken both ways to confirm
  nothing else moved.
- The four reversions above, each run against the new file and against the
  census file's schema test.
- The two registry mutations above.
- All ten guards pass, in a git checkout and in a copy of the tree with no
  `.git` in it. `test_guard_mutations.py` and
  `test_no_request_reaches_the_schema_owner.py` pass, which is every guard path
  parameter mutated. The migration linter passes. `test_three_tap.py` passes.
  `make lint`, `make typecheck`, `make api-docs-check` and
  `make deployed-workers` pass.

**What has not been verified.**

- Everything above was executed against a live database on this machine. None of
  it has run in the deployment, and CI has not run this branch.
- The GET boundary is enforced by a person reading a paragraph, not by a test.
  That is stated in the threat-model entry and it is the weaker half of this
  round.
- The first injection the audit found — a false `binds=False` reason — is still
  not mechanically catchable and is not claimed to be. A reason can be honest
  and wrong; what the census refuses is silence. Nothing here changes that.
- The authorship limit is recorded and **not** closed. An operator holding
  `pack_signatory` can still rewrite and sign a draft somebody else created.
- Nothing from `docs/post-raise.md` was touched, and no feature was added.

---
### 2026-08-29 — F1's own defect on the sibling route, and the census that ends the sequence

F1 bound a second review to the bytes the reviewer read. It was scoped to the
route that was reported. The auditor moved one step sideways and ran the same
attack through `POST /watch/drafts/{id}/sign`, on this tree, twice:

    signatory GET   /watch/drafts/{id}    current_content_hash 9a9c23ed…  threshold 1000
    author    PATCH /watch/drafts/{id}    max_crypto_concentration_bps -> 9999      200
    signatory POST  /watch/drafts/{id}/sign  {note: 'I read it.'}                   200

    row: status=signed  content_hash 25f0cbd8…  body carries 9999

Reproduced here before anything was written: the signatory read `df02b3fb…`
and the row records `7ac57d02…` with the threshold at 9999, signed by them.
And it publishes, because `SignedBytesChanged` guards signature → publication
and nothing guarded reading → signature.

Four rounds have now closed the reported case and been beaten one route along.
The defect is not `SignRequest`. It is a class: **an identity recorded against
content nobody proved that person saw.** So this round enumerates the class
first, classifies every member, binds the unbound ones in one pass, and adds a
test that walks the census — so that a seventh attestation route added in six
months fails CI until it binds.

---

#### Step 1 — the census

Every state-changing route in the application, and whether it records a human
identity against content. Forty-five routes; the test in
`test_an_attestation_is_of_the_bytes_the_attester_saw.py` holds the same list as
data and fails if the application's route table and this table disagree in
either direction.

Three outcomes only, as asked. No fourth category and no "probably fine".

**BOUND — the attester says which bytes, and the server compares.**

| Route | Identity written | Bound by |
|---|---|---|
| `POST /watch/drafts/{id}/second-review` | `second_reviewer`, `second_reviewer_user_id`, `second_reviewed_content_hash` | F1 — `reviewed_content_hash` required, `ReviewedBytesMoved` |
| `POST /watch/drafts/{id}/sign` | `signed_by`, `signed_by_user_id`, `signed_qualification_ref`, `content_hash` | **this round** — `signed_content_hash` required, `SignedBytesMoved` |
| `POST /watch/drafts/{id}/approve-publication` | `publication_approvals.approved_by`, `.content_hash` | **this round** — `approved_content_hash` required, `ApprovedBytesMoved` |
| `POST /watch/drafts/{id}/publish` | `published_by_user_id`, and the publisher counts as one of the two approvals | **this round** — `published_content_hash` required, `ApprovedBytesMoved` |

**BOUND ALREADY, BY IMMUTABILITY — the content cannot move between the read and
the attestation, so there is no window to bind.**

| Route | Identity written | Why there is no window |
|---|---|---|
| `POST /decisions/{id}/override` | `overrides.approver`, `.approved_by` | The attested object is a `decisions` row. `decisions` and `overrides` are append-only by trigger (migration 0001) and the row is in the hash chain. The bytes an approver read cannot be edited by anyone, through any route or any shell. |
| `POST /advances/{id}/take` | `tenant_advances.advanced_by` | The attested object is `(jurisdiction, pack_version)`. `packs` is append-only by the same trigger, and `watch.drafts.publish` is the only writer. A version's bytes are fixed the moment it exists. |
| `POST /advances/{id}/decline` | `tenant_advances.advanced_by` | As above. |

A hash field on these three would be ceremony: it would compare a value to
itself across a gap nothing can cross. Recorded rather than added.

**ATTESTS TO NOTHING CONTENT-SHAPED — a note, a status change, a request, or an
authorisation about a person rather than about a body.**

| Route | Identity written | Why it is not an attestation to content |
|---|---|---|
| `POST /watch/drafts` | `created_by`, `created_by_user_id` | Authorship of content the author wrote. Nothing was shown to them to attest to; this is the act the other bindings defend against. |
| `PATCH /watch/drafts/{id}` | audit actor only | An edit. Same. |
| `POST /watch/drafts/{id}/validate` | nothing | Reads, writes nothing. |
| `POST /watch/drafts/{id}/submit` | `submitted_by` | A state change: "this is ready for somebody to look at". It makes no claim about the content, and `IN_REVIEW` puts nothing in front of anybody. |
| `POST /watch/drafts/{id}/reject` | `rejected_by`, `rejected_by_user_id` | See below — binding this one would be **harmful**, not merely unnecessary. |
| `POST /watch/events/{id}/triage` | audit actor only | Queue workflow on `watch_events`, which is not rule content. |
| `POST /adoption` | `tenant_stages.signed_by`, `.signed_by_user_id` | A rung on the adoption ladder. A stage change with no body. |
| `POST /admin/users` | `users.created_by` | Provisioning a person. |
| `POST /admin/users/{id}/roles` | `user_roles.granted_by` | Authorising a permission. A decision about a person, not about a body. |
| `POST /admin/roles/{id}/revoke` | `user_roles.revoked_by` | As above. |
| `POST /admin/users/{id}/suspend`, `…/reinstate` | audit actor | As above. |
| `POST /artefacts/{kind}`, `POST /artefacts/batch` | `artefacts.generated_by`, `artefact_jobs.requested_by` | Provenance of a *request*. "Who asked for this document", not "who vouches for it". The document's own `content_hash` is computed over bytes this process produced. |
| `POST /runs` | `eval_runs.requested_by` | Provenance of a request. |
| `POST /import/clients`, `POST /v1/clients` | `import_runs.requested_by` | Provenance of a request. |
| `POST /returns`, `POST /reports/overrides`, `POST /comparison/ingest` | none | Render and ingest; no identity is written against a body. |
| `POST /evaluate`, `POST /v1/evaluations`, `POST /v1/bulk` | `decisions.decided_by` | Who ran a determination. Deliberately outside the hash — invariant 2 says the frozen snapshot is the only input and the operator is not one. Running a check is not vouching for its content. |
| `POST /decisions/{id}/replay`, `/v1/…/replay` | none | Reproduces; writes no attestation. |
| `PATCH /tenant/advance-policy` | audit actor | A setting. |
| `POST /watch/poll`, `POST /webhooks/deliveries/{id}/redeliver` | none | Machine acts. |
| `POST /auth/*` (login, logout, reauth, mfa/enrol, mfa/verify, set-password, reset, revoke-all), `POST /v1/oauth/token` | session rows | Authentication. No content. |

**The two entries that need their reasoning written out, because the one-line
answer is misleading.**

*`POST /watch/drafts/{id}/reject` — binding it would be harmful.* A rejection is
content-shaped in the sense that it is about a draft, and the instinct is to
bind it for symmetry. Do not. A reviewer who reads bad content and moves to
refuse it would be met with 409 the moment its author edited anything, and would
have to re-read the author's *new* version before being allowed to say no to it
— which hands the author a way to keep a rejection off their draft by editing it
whenever one is attempted. The asymmetry is the reason: every other attestation
in this table can put content in front of a firm, and a rejection cannot.
`REJECTED` is terminal (`lifecycle.TRANSITIONS[REJECTED] == ()`), so a rejection
recorded against bytes that moved is at worst a note filed against a slightly
different draft, and never a name on content somebody is relying on. Left
unbound, deliberately.

*`POST /currency/sources/{id}/verify` — the content is not ours to hash.*
`source_verifications.verified_by` is a named signatory attesting to what a
regulator had published on a date. This is a real attestation to real content
and it is held to the signature's bar — a `pack_signatory` grant for that
jurisdiction, and a second factor. But the bytes are on somebody else's website.
There is nothing in this system that is what they read, so a hash would either
be of a body we did not fetch or of a `watch_sources` row that is configuration
rather than the thing attested to. What binds it instead is `verified_on` plus
`attachment_ref`, which point at what they looked at. Recorded as attesting to
content we do not hold, not as bound and not as needing binding.

*Outside the route table:* `scripts/evidence_pack.py --signed-by` writes a named
person into `manifest.json` beside the SHA-256 of every file in the pack. There
is no read-to-attest window because the hashes are computed in the same process
invocation that records the sign-off — the signer cannot have been shown an
earlier version, because no earlier version was assembled. The separate and real
weakness is that the sign-off is a CLI argument rather than a re-authenticated
session; that is already owed in `docs/post-raise.md` and is not touched here.

---

#### Step 2 — what the census changed about the diagnosis

Three of the four bindings in the first table were missing, not one. `sign` was
reported. `approve-publication` and `publish` were found by the census and are
the same defect: both take **no request body at all**, so the attester has no
way to say what they read even if they wanted to, and
`PublicationApproval.content_hash` was computed at POST time — the exact shape
B1 had. The window is wider than the signature's, because it spans the
signature: a publisher reads a draft at `IN_REVIEW`, its author edits it, a
signatory signs the edited body, and the publisher approves and publishes bytes
they never saw. `edit_draft` refuses a `SIGNED` draft and `SignedBytesChanged`
catches an out-of-band edit after the signature, so the *late* half of that
window was already shut; the half before the signature was not.

That is the thing scoping to the reported route would have missed for a fifth
time.

---

#### Step 3 — the bindings

One comparison, in one place. `_the_bytes_that_were_read` takes the draft, what
the caller says it read, and which refusal to raise; compares exactly; and
returns the hash it computed, so every recorder writes the column from the row
rather than from the request. `record_second_review` was rewritten onto it and
its behaviour is unchanged, which the F1 tests still assert.

| | Request field | Recorder argument | Refusal | Route |
|---|---|---|---|---|
| second review | `reviewed_content_hash` | required kwarg | `ReviewedBytesMoved` | 409 |
| signature | `signed_content_hash` | required kwarg | `SignedBytesMoved` | 409 |
| approval | `approved_content_hash` | required kwarg | `ApprovedBytesMoved` | 409 |
| publication | `published_content_hash` | required kwarg | `ApprovedBytesMoved` | 409 |

Every field is `Field(min_length=1)` with no default, for the reason
`SignRequest` has no `signatory`: a caller that may omit it is attesting to
whatever is on the row now. Every comparison is `!=` on the exact string, with
no truthiness branch — empty, blank and malformed all fail as wrong values,
because a caller with nothing to compare has not said these bytes were read.

`SignedBytesMoved` is a sibling of `ReviewedBytesMoved` and not of
`SignedBytesChanged`, and the three now name the three windows exactly:

| Window | Refusal | Who it is addressed to |
|---|---|---|
| read → second review | `ReviewedBytesMoved` | the reviewer, about their screen |
| read → signature | `SignedBytesMoved` | the signatory, about their screen |
| second review → signature | `ReviewedBytesChanged` | the author, about their draft |
| read → approval/publication | `ApprovedBytesMoved` | the approver, about their screen |
| signature → publication | `SignedBytesChanged` | the publisher, about the draft |

`ApprovedBytesMoved` covers both publication routes because they are one
attestation made by two people: `publish`'s own docstring says pressing publish
counts as an approval, so a separate class would be two names for one claim.

In `publish`, the read-binding is checked **after** `SignedBytesChanged`. If a
draft's body moved out of band and the publisher read the moved body, their hash
matches the row and `SignedBytesChanged` is the true and more serious finding;
checking the read-binding first would report a stale screen for a tampered
draft.

The workbench sends `current_content_hash` from the draft it rendered on both
screens it has. `api.signDraft` and `api.publishDraft` now take it as a required
argument rather than an optional one, so a caller that forgets does not compile.

*A finding on the way past, and it had to be fixed for the binding to be
possible at all.* `POST …/approve-publication` and `POST …/publish` are held to
`quolin_operator`, and `GET /watch/drafts/{id}` was held to the firm roles only.
So a platform publisher holding no firm role got **403 from the route that shows
a draft and 200 from the route that puts it in front of every customer on the
platform** — the two people who decide what governs every firm could not read
what they were deciding on. Verified: a publisher holding only `quolin_operator`
approved and published a draft they had been refused sight of.

It is also what makes the binding satisfiable: `current_content_hash` is emitted
by that route and nowhere else, so a publisher who cannot read a draft cannot say
what they read. The read is now `STAFF | {quolin_operator}` — added rather than
substituted, which is the shape and the argument `GET /admin/users` already uses:
`quolin_operator` is not a firm role, and it is the role that acts on this.
`test_reading_is_open_to_the_firm_and_writing_is_not` still holds, because the
firm's own roles were not narrowed.

---

#### Step 4 — the test that ends the sequence

`test_an_attestation_is_of_the_bytes_the_attester_saw.py` holds the census above
as data and asserts four things:

1. Every `POST`/`PATCH`/`PUT`/`DELETE` route the application serves appears in
   the census. A new route fails the test until somebody classifies it.
2. Every census entry still names a route that exists, so the list cannot rot
   into a description of a previous version of the app.
3. Every entry classified as binding content has a **required** body field whose
   name ends `_content_hash`, typed `str` with `min_length >= 1` and no default
   — read off the route's own Pydantic model, not off a list of field names kept
   somewhere else.
4. Every entry *not* classified as binding content carries a written reason. An
   empty reason fails, so "probably fine" cannot be committed.

The reported sequence is asserted over HTTP end to end: the signatory reads, the
author edits, the signature is refused with 409, and the row is checked to hold
no signature, no signatory, no account, no qualification and no hash. The
ordinary read-then-sign still returns 200. A hash from a superseded version is
refused; empty, blank, whitespace, a prefix of the real value and the real value
with a suffix are each refused rather than treated as matching. The self-signed
path, which already carries `reviewed_content_hash`, still behaves correctly with
both bindings on the row at once.

The two the census found are asserted over HTTP too, and their sequence is
deliberately one where **the signature is sound**: the signatory reads the edit
and signs what they were shown, and the approver and publisher are still refused,
because their window opened before the signature did. Closing the signature's own
window would not have closed theirs — which is the argument for a census rather
than a fifth targeted fix, stated as a test. A bare POST to either route is 422,
which is the original request shape now refused.

---

#### The two caveats

**`docs/deployment.md:221` — closed with a check, not recorded.**
`fly postgres attach` sets `DATABASE_URL` on the API, and that is the schema
owner: it owns every table and every append-only trigger, is exempt from FORCE
row-level security, and is what `scripts/rechain.py` uses to rewrite evidence
hashes. FP3-04 removed it from the ECS task and `guard_task_credentials.py` keeps
it out there; nothing checked the other deployment target, and the documentation
told the operator to put it back.

Fly is demo-only, so no production tenant sat behind it — a statement about blast
radius rather than about the control. `make deploy-check` now refuses to deploy
while `DATABASE_URL` is set on `quolin-api`, and also runs
`guard_task_credentials.sh`, so "is this safe to deploy" has one answer rather
than one per platform. The grep is anchored, because `APP_DATABASE_URL` and
`WATCH_DATABASE_URL` both end in the name and an unanchored one would fail on the
correct configuration — the shape of guard that gets deleted the first time it
cries wolf.

The documentation was the other half. It now says to unset it and set
`APP_DATABASE_URL` instead, and the seed step — which was
`fly ssh console -C "… seed.seed"`, and only worked because the credential was on
the machine — runs over `fly proxy` from the operator's own machine, which is
where the owner credential belongs.

**`api/app/db.py:112` — recorded in `docs/threat-model.md`, not closed.**
`owner_engine` is still built at module scope, and `OWNER_DATABASE_URL` still
falls back to `localhost:5433` when `DATABASE_URL` is unset, so on a developer's
machine the object exists and points at a real database.

What stands between a request-path module and the owner today is lexical and
enforced in CI: `guard_no_owner_in_request_path.sh` and its AST twin forbid any
module under `api/app` from naming `OwnerSessionLocal`, `owner_engine` or
`OWNER_DATABASE_URL` outside `db.py`, and from naming `DATABASE_URL`,
`create_engine` or `psycopg.connect` anywhere but `db.py`. `owner_only.py` raises
`ImportError` at load when no owner connection was supplied. In deployment the
variable is absent and there is no Postgres at `localhost:5433`, so the fallback
is an address rather than an escalation.

Laziness would add a runtime refusal over the same set of names the guard already
refuses, and would buy exactly one thing: catching a module that reaches the
engine through a name the AST cannot see — `getattr(db, "Owner" + "SessionLocal")`
— on a laptop. That is a deliberate evasion by somebody who can also edit the
guard.

The cost is what makes it a separate change. `owner_engine` is used as an object
in ten files (`.connect()`, `.begin()`, `inspect(...)`), `OwnerSessionLocal` is
called in 283 places across 77, and the name `owner_engine` is what the guard, its
AST twin and `test_guard_mutations.py`'s fixtures all key on. Turning it into a
function rewrites the guards F2 and F3 hardened last round; turning it into a
`__getattr__` proxy makes the file that *is* the credential boundary harder to
read, which is the property the guard exists to protect. Doing either in the same
pass as a four-route security fix is how a good change breaks a better one. The
threat model now says plainly that the boundary is enforced in deployment and in
CI, and is a convention on a laptop.

---

#### Not done

No new features, and nothing from `docs/post-raise.md`. In particular the
evidence pack's sign-off is still a CLI argument rather than a re-authenticated
session; that is a real weakness, it is already owed there, and it is not this
round's.

---

#### What was run, and what has not been

Executed against a live database on this machine, on a tree reseeded first so
that nothing here rests on state a previous run left behind:

- **The three findings were reproduced before anything was written.** The
  signature: the signatory read `df02b3fb…` and the row recorded `7ac57d02…`
  with the threshold at 9999, signed under their name. The two publication
  routes: an approver and a publisher both read `de76abf5…` (threshold 1000)
  and their accounts went onto `3bc4e54a…` (threshold 9999), which published as
  AU v167.
- **And re-run after.** The signature is 422 with no hash and 409 with a stale
  one; both publication routes are 422 bare and 409 stale, and 200 when the
  attester re-reads and approves what is actually there.
- Full suite: **3576 passed, 13 skipped, 0 failed.** The baseline was 3488 with
  14 skipped; this file adds 88 tests, and the skip that became a pass is one of
  the three data-dependent ones in
  `test_replay_compares_what_the_entry_says_it_compares.py`, which skip or run
  according to the shape of the seeded decision they pick.
- All ten guards pass, in a git checkout and in a copy of the tree with no
  `.git` in it. `test_guard_mutations.py` and
  `test_no_request_reaches_the_schema_owner.py` pass, which is every guard path
  parameter mutated. The migration linter passes. The three-tap demo regression
  passes. `make api-docs-check` and `make deployed-workers` pass.
- `make seed` was run end to end, which exercises the three new required
  arguments through the seed's own signature, approval and publication.

Not verified:

- **`make deploy-check`'s new refusal has not been run against Fly.** It needs
  `flyctl` and a logged-in account, neither of which is available here. The
  shell construct itself was tested against both fixtures — a secrets listing
  containing `DATABASE_URL`, which it refuses, and one containing only
  `APP_DATABASE_URL` and `WATCH_DATABASE_URL`, which it passes.
- None of this has run in a deployment, and CI has not run this branch.
- The authorship limit from the last round is unchanged and still recorded
  rather than closed: an operator holding `pack_signatory` may still rewrite and
  sign a draft somebody else created. The bindings added here do not touch it —
  such a person reads the draft, edits it, re-reads and signs what they now see,
  all truthfully. They bind *what* was attested to, not *whose seat* is
  protected.

---

### 2026-08-28 — Gate A, the last engineering round: three findings and one sequence ended

Three items survived the Gate A close, and all three were verified against this
tree before anything was written. Each is fixed with a test that fails when the
fix is reverted. The fourth item was recorded rather than closed, which is what
was asked for it.

| Item | Finding | Status |
|---|---|---|
| F1 | A review binds to the row at POST time, not to the bytes the reviewer read | FIXED |
| F2 | The guard forbids the door and allows the key, and the neighbours hold both | FIXED — allow-list now empty of anything but the two structural files |
| F3 | The AST twin, which is the only layer catching two spellings, had no mutation cases | FIXED |
| — | "Author" means creator, not writer | RECORDED in `docs/threat-model.md`, not closed |

---

**F1 — the review is of the bytes the reviewer read.**

B1 bound a second review to content. It took the hash **when the approval
arrived**, which is not the moment the reviewer read anything, and the gap
between those two moments is the reviewer's reading time — minutes, for a rule
pack. An author holding `operator` can edit inside it:

    the reviewer opens the draft and reads
    max_crypto_concentration_bps = 1000
      -> the author PATCHes it to 9999
      -> the reviewer POSTs their approval
      -> the author signs their own draft

200, signed by the author, with the reviewer's account on content they never
saw. Every B1 check passed and each of them was right about what it asked:
`record_second_review` hashed the body it found, `sign` compared that hash to
the same body, and the CHECK compared two columns that agreed. Both sides of
every comparison came from the author's edit. That is B1's own outcome reached
through the ordinary workbench routes, and the auditor executed it.

*One field, three touch points.* `drafts.view` returns `current_content_hash` of
the body it rendered. `SecondReviewRequest.reviewed_content_hash` is required,
with `min_length=1` and no default. `record_second_review` takes it as a
required keyword and raises `ReviewedBytesMoved` when it does not equal
`content_hash(draft.body)` — compared, with no "empty means unchanged" branch,
because a caller with nothing to compare has not said these bytes were read. The
column is still written from the row rather than from the request, so it is
always a hash this process computed over this body.

*Two refusals, and they are not the same refusal.* `ReviewedBytesChanged` tells
an **author** that their draft moved after the review, so they may not sign it.
`ReviewedBytesMoved` tells a **reviewer** that what they are approving is not
what they were shown — a warning about their screen, not a refusal of their
authority. `test_the_two_refusals_are_told_apart` asserts which one each caller
meets, so collapsing them would be visible.

*The tests.*
`api/tests/test_a_review_is_of_the_bytes_the_reviewer_read.py` walks the attack
over HTTP and asserts nothing is written — no reviewer, no hash, no signature,
status still `draft`. Beside it: read-then-approve unchanged still succeeds and
the author can then sign; a hash from a superseded version is refused; empty,
blank, nonsense, a prefix of the real hash and the real hash with a suffix are
each refused; and a request omitting the field is a 422 rather than a default.
Reverting the comparison fails nine of the twelve. Weakening it to
`if submitted and submitted != current` — which reads as defensive and is the
bug — fails the empty case alone, which is the case that check invites.

---

**F2 — the allow-list is empty, and the key and the neighbours are closed too.**

Three rounds had gone: three names, then three names plus the door, then the
door with a three-file allow-list. Three things were still open.

*The allow-list entry was the biggest of them.* `auth.py` was exempted so
`_reset_rate_limit_for_tests` could clear `auth_attempts`, which is append-only
to the application role by grant and by trigger. What sat behind that exemption
disables the trigger as the schema owner and deletes every row — **invariant 4,
and the login rate limit with it, reachable from any handler**, because `auth` is
imported by everything that serves a request. Its only caller was the suite. The
argument for leaving it was that forty test call sites named it, which is a fact
about diffs and not about what is enforced.

It is `conftest.reset_rate_limit_for_tests` now; sixty call sites across
twenty-nine files moved mechanically in this commit; and `auth.py` is off both
allow-lists. The shell guard's list is `db.py` and `owner_only.py`, the two
structural files. The AST twin's is empty, because a docstring is not a
reference to a parser. `test_the_removed_door_cannot_be_reopened_quietly` puts
the import back and asserts the guard fails — a removed exemption that would
still pass on the code it existed for is a deletion of the documentation and not
of the opening.

*The key.* Rules 1 and 2 forbade the door and three names for what is behind it,
and neither forbade `create_engine(os.environ["DATABASE_URL"])` — the same role,
none of those tokens, no door involved. `DATABASE_URL`, `create_engine` and
`psycopg.connect` are now forbidden under `api/app` except in `db.py`, which
constructs the engines. `owner_only.py` read the variable itself and now asks
`db.OWNER_URL_WAS_SUPPLIED`, so exactly one file names the key.

*The neighbours.* `api/seed` and `scripts` are importable from `api/app` in this
suite and in the built image, and both re-export the owner at module scope —
`seed/seed.py` line 21 is `from app.db import OwnerSessionLocal, owner_engine`,
and every worker under `scripts/` does the same. `import seed.seed;
seed.seed.OwnerSessionLocal()` reached the owner naming neither the connection
nor the door. Importing either package from `api/app` is now forbidden outright,
with no allow-list, because nothing there needs either.

Every rule is in both layers, and F3's test is what enforces that.

*One thing observed and left.* `owner_only.active_tenant_ids` now has no caller
anywhere in the tree — every worker enumerates through
`maintenance.active_tenant_ids` on its own owner session. That is the shape B2
deleted `source_alerts.all_tenant_ids` for, and it is left here on purpose:
what made that one worth deleting was *where it sat*, in a request-path module.
This is the door itself. Recorded in `owner_only.py` so the observation is not
lost.

---

**On the sequence, because it was asked directly.**

Four rounds of this guard have each closed the spelling last used and kept the
shape. The question put was whether owner access can be made *structurally*
unreachable from request code, and the answer is worth being exact about rather
than answering with a fifth pattern list.

**It already is, in the deployment, and the mechanism is not a guard.** The
request-serving task is not given `DATABASE_URL`. `owner_only` refuses to
import; `db.py`'s owner engine points at a hardcoded `localhost:5433` that
resolves to nothing; `create_engine` has no URL to be handed. Every spelling
above fails there, including the ones nobody has thought of.
`scripts/guard_task_credentials.py` and
`test_the_api_is_not_given_the_owner_connection_in_the_first_place` are what
enforce it, and they are assertions about the task definition rather than about
the code.

**Inside a process that holds the credential, nothing can.** That is the suite
and a developer's laptop, where the API code and the test code are one Python
process and the credential is legitimately present because the suite needs it.
No in-process mechanism survives contact with a caller who wanted to bypass a
lexical guard: an import hook is uninstallable, a module `__getattr__` is
readable through `sys.modules`, a capability object handed to a session can be
constructed by anyone who can `import`. Each would be a taller fence in the same
field.

So the honest description, now written into the guard, the twin and
`docs/threat-model.md` T9: **this is a coupling check, not the boundary.** What
it buys is that an unintended coupling fails in CI, on the machine where the
credential is present. What it does not buy is safety against somebody who means
it, and it never did.

The one structural change that would extend the credential boundary to the
laptop is removing `db.py`'s hardcoded owner fallback and constructing
`owner_engine` lazily, so that a process without `DATABASE_URL` cannot obtain an
owner connection by any route rather than merely failing to connect. It is
**not** done here: `owner_engine` is bound by three `event.listens_for`
decorators at module scope, the seed, the migrations, the workers and this suite
all depend on the current construction, and it would not change the suite —
which is where the reachable version of every finding in this sequence has
lived. It is recorded as the next structural step rather than performed as an
unreviewed one.

---

**F3 — the backstop is the layer that had no mutation cases.**

Removing the `Attribute`, `Name` and `Constant` branches from `_opens_the_door`
was observed to produce a clean run. `test_guard_mutations.py` injected seven
spellings for the shell guard and none for the AST twin — and the twin is the
only layer that catches two of them, so the untested layer was the backstop.
The one test that tripped when `DOOR` was renamed asserted that both layers exit
0 on a clean tree, which is agreement on a *pass*: two checks that do nothing
agree perfectly.

`test_the_shell_guard_says_the_same_thing` is replaced by
`test_both_layers_refuse`, a table of twenty-four spellings — every rule, every
spelling — each run through the AST detectors **and** through the shell guard,
with both asserted to refuse. The guard is pointed at a scratch `APP_DIR` rather
than a copy of the tree, which is the parameter it already takes and avoids the
half-gigabyte-per-case problem this file's own docstring records.
`test_both_layers_pass_on_a_module_that_does_none_of_it` is the other half, and
it also keeps the table honest: a harness that tripped the guards by itself
would make every row pass for the wrong reason.

Each branch was then removed and the failure observed: `Attribute`, `Name` and
`Constant` fail one case each; renaming `DOOR` fails nine; dropping the key rule
fails five; dropping the sibling rule fails four.

`test_guard_mutations.py` keeps its own cases for the new rules, injected into
`main.py` in a copy of the real tree rather than a scratch directory — a
different claim, and worth both: there the exemption patterns are matched
against real paths, so a rule that accidentally exempted `api/app/main.py` would
pass the twin's cases and fail these.

*And the new test immediately found a divergence.* The AST twin matched
`DATABASE_URL` by exact name while the shell guard greps for the substring, so
`os.environ["APP_DATABASE_URL"]` was refused by one layer and allowed by the
other — the shape this defect has taken three times, caught this time by the
thing built to catch it. The twin now matches the whole identifier against
`(?:[A-Z][A-Z0-9_]*_)?DATABASE_URL`, which is the same set the grep sees and
still not a match for a docstring that mentions the name.

---

**Deviations, and one finding whose prescribed remedy had no target.**

*F1 said "update the workbench client to send the hash it received". There is no
workbench client for this route.* `POST /watch/drafts/{id}/second-review` has no
call site in `web/` — the client has `signDraft` and no `secondReviewDraft`, and
no second-review screen exists. Nothing was invented to fill the gap. The field
is typed on `PackDraft` in `web/lib/types.ts` with a note saying nothing sends it
yet, so that the screen which does get built binds to it rather than discovers
it, and `docs/api/openapi.json` is regenerated.

*The view field is `current_content_hash`, not `content_hash`.*
`PackDraft.content_hash` already means something else — the bytes that were
**signed** — and the history screen renders it under "what was signed". Two
hashes of two different bodies under one name on one screen is how a client
sends the wrong one.

*Rule A's allow-list went from seven to eight, deliberately.*
`test_no_request_reaches_the_schema_owner.py` has always parsed `api/app`; it
passed Rule A only because `_targets_application_code` reads a nine-line window
around each `read_text()` and no comment in those windows happened to say
`app/`. Refactoring two parse calls into one helper moved it beside a comment
that does. The exemption was in force and unwritten, which is the state an
allow-list exists to end, so it is written down and the ceiling raised in the
same commit — as that test's own docstring asks.

*H5's environment caveat was already handled and is now legible.*
`require_scan`'s readability test is `[ -r ]`, which is true for root, so the
mode-000 mutation case would pass vacuously in a root CI container. The
`skipif(os.geteuid() == 0)` was already there; its reason now says what the skip
costs, so a root runner's skip line explains that the readability check is
unasserted on it.

---

**What has not been verified.**

- Every claim above was executed against a live database on this machine. None
  of it has run in the deployment.
- The full suite, all ten guards in and out of a git checkout, every guard path
  parameter mutated, the migration linter and the three-tap demo regression are
  green here. CI has not run this branch.
- The authorship limit is recorded and **not** closed. An operator holding
  `pack_signatory` can still rewrite and sign a draft somebody else created.
- Nothing from `docs/post-raise.md` was touched, and no feature was added.

---

### 2026-08-28 — Gate A close: the two blockers, and six hardening items

Two further independent audits attacked the merged fix-pack rather than reading
it. Both provisioned a database and ran against the live system. Six of the eight
fixes survived attack; two Gate A criteria were still open, and **both audits
found the first one independently, by different methods**.

Every finding below was verified against this tree before anything was written.
Two were wrong or partly wrong and are recorded as such rather than quietly
rescoped, and one prescribed remedy was rejected in favour of a better one. Those
are in *Deviations* at the end.

| Item | Finding | Status |
|---|---|---|
| B1 | A second review is not bound to the content it reviewed | FIXED |
| B2 | The owner-session guard forbids three names, not the class | FIXED |
| H1 | A legacy row is an accidental 500 | FIXED — the finding's premise was wrong and its conclusion was not |
| H2 | Fix 4's guarantee depends on a CI job nothing asserted | FIXED, with a deviation |
| H3 | Two tests oversell what they check | FIXED, and the sweep is mechanical now |
| H4 | Duplicate rows collapse silently; a summary overstated | FIXED |
| H5 | Two guard/sweep semantics weaker than stated | FIXED |
| H6 | A container that stops with no exit code pages nobody | FIXED |

---

**B1 — a review attests to bytes, and the signature checks which bytes.**

The hole migration 0049 closed is genuinely closed: authorship is persisted,
`sign` refuses author-signs-own, and `pack_drafts_signature_is_independent`
enforces it past Python. What 0049 recorded about the escape hatch was *who*
reviewed and *when*, and never *what*. So:

    author cuts a draft
      → an independent, qualified signatory records their read
      → the author edits the body
      → the author signs their own draft

`sign` asked only whether `second_reviewer_user_id` was populated, and it still
was. The CHECK asked the same question of the same three columns and was
satisfied for the same reason. One audit ran this and reported
`SIGNED_BY_AUTHOR: True · REVIEWER_STILL_SET · BODY_HAS_ATTACK: True`. The
signature blessed bytes nobody independent had seen, and every downstream record
— the published pack body, `pack_publications`, the artefact's
evidence-integrity table — carried the reviewer's name as if they had read it.

The principal needs `operator` and `pack_signatory`: an operator may edit a
draft and a signatory may sign one. That pairing is the S5 gate item's own
description of the workbench workflow, so this is the ordinary path and not a
corner case.

*The pattern was one function away.* `sign` records `content_hash(draft.body)`
and `publish` re-checks it, refusing `SignedBytesChanged` — F4, the window
*after* the signature. Nothing mirrored it onto the window *before*. Both
windows are now the same guarantee either side of the attestation.

*Three layers, because each answers a different question.* Migration 0050 adds
`second_reviewed_content_hash`, captured in `record_second_review` over the same
canonical form the signature hashes. `sign` refuses `ReviewedBytesChanged` when
an author's own signature leans on a review of different bytes — and refuses a
review that carries no hash at all, because a row that cannot say which bytes
were read cannot support the claim that they were.
`main.edit_draft` clears the reviewer, the name, the timestamp and the hash on
any change to the body, through `drafts.invalidate_second_review` — a function
in the domain layer rather than four assignments in a route, because a caller
that changes a body outside HTTP has invalidated the review just as thoroughly.

*And at the database, consistent with how 0049 handled authorship.*
`pack_drafts_self_signature_reviewed_these_bytes` says a row whose signer is its
author must carry a reviewed hash equal to the signed hash. It compares two
columns rather than hashing anything, so it binds a writer that never went
through Python. `NOT VALID`, for 0049's reason exactly: every review recorded
between the two migrations named a person and no hash, and validating would mean
inventing a hash for content that may since have moved — asserting about the
past the very thing this exists to stop asserting. What those rows are is a
query, and it is in the migration and in the runbook.

*The test that matters is the one that did not exist.* `review → sign` had a
test. `edit → sign` had a test. The pair walked in that order had none — the
same shape as the Stage 6 defect recorded in `sign`'s own comment, where signing
and submitting each had tests and nothing walked the pair.
`test_a_review_is_bound_to_the_content_it_reviewed.py` walks it, in Python and
over HTTP, alongside: review → sign unchanged still succeeds; review → edit →
re-review → sign succeeds; an independent signer is unaffected; and the database
refuses the row. Each fix was reverted individually and the corresponding test
observed to fail.

*One test had to change, and it is worth saying why.*
`test_the_database_refuses_it_too` asserted that the server's refusal names
`pack_drafts_signature_is_independent`. A self-signature with no reviewer now
violates *both* constraints over those columns, and Postgres reports whichever
it evaluates first — which turned out to be the new one. The write is refused
either way; what was brittle is naming one. It asserts against
`drafts.LEGACY_CONSTRAINTS` instead, the same tuple
`refusal_for_a_violating_row` maps to a typed 409, so a constraint renamed in a
future migration and not added there fails in both places rather than only the
second.

*One thing worth recording about the two layers over HTTP.* Through the route,
an author who edits after review meets `SelfAuthoredSignature` rather than
`ReviewedBytesChanged` — the edit has already cleared the review, so there is no
review to be stale. `ReviewedBytesChanged` is the layer that answers when a body
moves without going through `edit_draft`: a shell, a racing request, a future
caller. Both refuse; the tests assert which, so removing the invalidation and
leaning on the hash alone would be visible.

`docs/threat-model.md` T10 records the change.

---

**B2 — the guard forbids the class, and one door was deleted rather than widened.**

`guard_no_owner_in_request_path.sh` and its AST twin keyed on three strings:
`OwnerSessionLocal`, `owner_engine`, `OWNER_DATABASE_URL`. Both audits walked
past the same way, and one ran it:

    from app import owner_only
    owner_only.active_tenant_ids()

No connection named, the schema owner reached, exit 0 — on the exact case
`owner_only.py`'s own docstring says it cannot prevent, while the fix presented
the guard as what did. In the deployment a runtime `ImportError` mitigates it,
because the API task holds no `DATABASE_URL`; the environment where it works is
a laptop and the suite, which is the environment the original FP3-04 defect was
reachable in and where CI runs. Gate A asks that a guard fail loudly rather than
pass vacuously, and this one passed vacuously.

*Closed as a class.* Both the grep guard and the AST test now forbid reaching
`app.owner_only` from anything under `api/app`, in every spelling —
`from app import owner_only`, `from . import owner_only`,
`from .owner_only import x`, `import app.owner_only`, an attribute access, and
the dotted path as a string for `importlib.import_module`.
`test_guard_mutations.py` injects all seven and asserts the guard fails on each.

*The allow-list is one file, and it used to be two.* `auth.py` holds
`_reset_rate_limit_for_tests`, which only the suite calls and genuinely cannot go
through the application connection — `auth_attempts` is append-only to that role
by grant *and* by trigger. Its import sits inside the function, so importing
`auth`, which everything serving a request does, does not reach the owner.

`source_alerts.all_tenant_ids` was the second and is **deleted**. It was a pure
delegation to `owner_only`, left behind when FP3-03 moved the enumeration out of
the watch sweep, and nothing had called it since: every worker enumerates through
`maintenance.active_tenant_ids` on its own owner session, in `scripts/`, which is
not the request path. An unreachable owner-privileged callable sitting in a
request-path module is this finding's own shape ready-made, so it went rather
than being allowlisted. A door nobody uses is one fewer door.

*Each remaining door is mutated.* `test_each_allowed_door_is_a_door_and_not_a_hole`
asserts every allowlisted file is still doing the thing it was exempted for — an
entry whose reason has quietly stopped holding is an opening nobody notices,
because the guard's verdict does not change when the reason does. The AST rule
asserts the same in the opposite direction: an exemption that reaches nothing is
reported so it can be deleted.

*What this is not.* It is a lexical boundary, not a structural one. The
finding's stronger suggestion — put the owner-backed callables behind an
interface a request-scoped session cannot obtain — would be better and is not
what was built: `owner_only` already refuses to import without `DATABASE_URL`,
which is the structural half that works in the deployment, and the lexical half
is what works on a laptop. Deleting the one dead callable narrowed the surface
to a single function only the suite calls, which is as close to structural as a
deletion gets. `docs/threat-model.md` T9 records both the change and the limit.

---

**H1 — a legacy row is a refusal that names itself.**

The finding claimed the publish route does not map `IntegrityError`. *Partially
wrong*: `IntegrityError` is imported in `main.py` and handled at two sites — the
client CSV import (F5) and `POST …/approve-publication` for
`uq_one_approval_each`. Neither is the publish path and neither is the sign
path, so the conclusion held even though the premise did not.

`NOT VALID` is not "never checked". Postgres re-checks a CHECK on any UPDATE to
the row it touches, and publication updates `pack_drafts` —
`published_by_user_id`, `proposed_version`, the status transition. So a draft
signed under the older rules and then published made Postgres raise correctly
and made the route answer 500 with a traceback, naming neither the draft nor the
rule and reading as a broken deployment rather than as a refusal.

Both routes map it to `PredatesTheConstraint`, which names the draft, names the
constraint and points at `docs/runbooks/legacy-draft-rows.md`. Matched on the
constraint name rather than on the exception type: a duplicate pack version under
migration 0031's UNIQUE is a different incident with a different answer, and a
handler that swallowed every `IntegrityError` would turn a genuine collision into
a sentence about legacy rows. It is re-raised untouched.

The runbook says what to do — raise a fresh draft and take it through the
workflow — and, at more length, what not to do. Dropping the constraint, writing
a reviewer's account into the row so that it will publish (which would name
somebody as having read content they have never seen, in a document that goes to
the customer), and publishing through the schema owner, which does not work
because a CHECK binds the owner like everybody else.

`test_a_legacy_draft_row_is_refused_and_not_a_500.py` builds the row as the
owner — there is no way to reach the state through the application any more,
which is the point — takes it through publication over HTTP, and asserts 409
with the draft, the constraint and the runbook in the message. Its teardown is a
repair rather than a delete, because `pack_draft_transitions` is append-only and
removing the draft would leave its history pointing at nothing.

---

**H2 — the guarantee rests on a CI job, so the CI job is asserted.**

`scripts/image_smoke.py` is the only thing here that runs a deployed command
against the image that will run it. It needs docker, so it cannot live in
`pytest` — and nothing read `.github/workflows/ci.yml` to check the step was
still there. Three ways it could stop being a check without stopping being
present: deleted, marked `continue-on-error`, or made conditional so that "did
not run" and "ran and passed" look identical.
`test_the_image_smoke_actually_runs_in_ci` fails on all three. The script's own
answer to a missing docker was already exit 2 rather than a skip.

`pyyaml` is declared in the dev group rather than relied on transitively through
`uvicorn[standard]`: a test whose imports depend on what an unrelated extra
happens to pull in is a test that disappears when that extra changes.

*Deviation on the second half — see below.*

---

**H3 — a test name is a claim, and one of them was not backed.**

`test_an_ordinary_hash_mismatch_still_reads_as_one` asserted that a *clean* chain
verifies and carries no reason code. Worth asserting; not what the name said. The
`HASH_MISMATCH` ⁄ `UNDECRYPTABLE_SNAPSHOT` distinction it promised was tested in
`test_evidence_chain.py`, and would have gone on reading as covered in the tamper
file if that had ever stopped being true.

Both halves are done rather than either. The test that only checks the clean
chain is renamed to `test_a_verifying_chain_carries_no_reason_at_all`, and a new
test beside it makes the distinction where the name is — a row that decrypts and
does not hash, asserted to read `HASH_MISMATCH`, in the file about the verifier's
verdicts under tamper.

*And the sweep is mechanical now.* Reading every name against its body is a
reading exercise and it was done; what a rule can enforce is the shape that makes
the failure total, which is **a test that asserts nothing at all** — such a test
passes for any behaviour, so its name is the only claim it makes.
`test_a_test_asserts_what_its_name_claims.py` (Rule B, beside Rule A's
`test_no_test_reads_source.py`) walks all 1,328 test functions. It found six
with no assertion; all six are legitimate — the refusal is a call that raises —
and each is on a seven-entry allow-list with the call named. Assertions reached
through a helper in the same module count, and `raise AssertionError` counts.

---

**H4 — duplicates are reported, and one summary is corrected.**

`scripts/deployed_workers.py` collapsed modules into dictionaries —
`documented[module] = row`, `scheduled[module] = resource` — so a second row or a
second schedule for one job silently replaced the first and the report described
one of them. Three detections now, with the third being the one that had no
marker at all: two rows with the *same command*; two rows with different commands
that resolve to the *same module*, which reads as two jobs and is one; and two
task definitions running one module on two schedules, which runs the job twice at
cadences nothing reconciles. A fourth test asserts the real tree has none of
them, because three detectors that never fire are three detectors nobody notices
have broken.

*`docs/deployment.md` was already correct and is unchanged.* Line 695 marks
`batch-sweep` DEFERRED with a sound reason — no EFS mount, no drop bucket, no
SFTP, so a nightly task would read an empty directory inside its own container
and report success every morning. What overstated the position was the fix-pack's
own summary line, which read "one of five deferred" in a table of things marked
FIXED. It now reads "four deployed, one deferred with reason", and Fix 6's
heading says the same rather than saying it three paragraphs later.

---

**H5 — two claims narrowed to what is true, and one list inverted.**

`require_scan` in `scripts/guard_lib.sh` counted files and its docstring claimed
it had validated that the guard could read them. That is this file's own defect
one size smaller: an unreadable file greps exactly like an absent one, because
`grep -r` writes its permission error to stderr — which every guard here
discards — and contributes no matches. It tests readability now, with `-r` per
file rather than `find -readable`, which is GNU-only and absent on the BSD find
macOS ships; a guard with two verdicts by platform is Q-10 again. Two mutation
cases: a directory of mode-000 files fails, a readable one still scans.

`CUSTOMER_FACING` in `test_customer_documentation_does_not_outrun_the_code.py`
was a hand-kept list of eleven filenames, so a new customer-facing document was
outside the sweep until somebody remembered — which is the enforcement
`docs/deployment.md`'s prose rule had before `deployed_workers.py` replaced it.
The list is inverted: every top-level `docs/*.md` is swept unless `INTERNAL`
exempts it *with a reason*, so a new document is checked the moment it exists.
Three exemptions, each explained and each asserted to name a file that is really
there. `docs/runbooks/` and the generated `docs/api/` are out of scope and the
constant says why.

---

**H6 — the task that stopped without ever running.**

`task_stopped_badly` matches `containers.exitCode = [{"anything-but": 0}]`, and
an EventBridge field filter requires the field to be present. A container that
never ran has no exit code: an image that will not pull, a task that cannot be
placed, a secret ARN the execution role may not read.
`schedule_never_fired` does not cover it either — it reads `FailedInvocations`,
which counts EventBridge failing to *start* the task, and EventBridge succeeded:
`RunTask` was accepted and the failure happened afterwards, inside ECS. So a
scheduled job could execute no line of code and page nobody.

`aws_cloudwatch_event_rule.task_never_started` matches `exitCode` **absent** and
says so in its own words — there are no application logs to read, because
nothing ran. A second rule rather than a widened first one: the pattern language
cannot express "absent OR non-zero" in one field filter, and the two incidents
want different sentences anyway. Both rules are named in
`aws_sns_topic_policy.pager_accepts_events`, and a test asserts it — a rule
missing from that policy fires and is refused by SNS with nothing saying so,
which is the scheduler-policy failure in a new place.

---

## Deviations, and the two findings that were wrong

1. **H4's documentation claim was wrong and `docs/deployment.md` is untouched.**
   The deferral reason for `batch-sweep` is correct and complete. What
   overstated was the fix-pack summary, and that is what changed.

2. **H1's premise was wrong and its conclusion was not.** `IntegrityError` *is*
   imported and handled in `main.py`, at two sites. Neither covers publish or
   sign, so the 500 was real. Recorded rather than rescoped silently.

3. **H2's prescribed remedy is rejected; the alternative is better.** The
   finding asks that the unit test reject a bare interpreter, which means
   spelling `/app/.venv/bin/python` in every task definition. `api/Dockerfile`
   argues against that at length and is right: a prefix has to be remembered at
   every call site — an ECS override, a `docker run`, a shell in a running
   container, a healthcheck — and putting the virtualenv on PATH makes the
   *default* correct. It would also put an image's internal layout into
   Terraform, which is a second pair of files that must agree about what
   `python` means: the class of defect Fix 4 was about.

   What was actually weak is that the two halves of the agreement lived in two
   tests that never mentioned each other, so deleting one left the other
   permitting a bare `python` for no stated reason. The test that permits the
   bare name now asserts the PATH guarantee *in the same test*, and the
   entrypoint allow-list drops from three names to one: nothing uses `sh` or
   `uv` as a task entrypoint, and permission nobody needs is what
   `deployed_workers.py` refuses about the scheduler policy.

4. **B2's stronger suggestion — a structural boundary — is not what was built,
   and the limit is recorded.** `owner_only` refusing to import without
   `DATABASE_URL` is the structural half and it works in the deployment; the
   guard is the lexical half and it works on a laptop. Deleting
   `source_alerts.all_tenant_ids` narrowed the surface to one function that only
   the suite calls, which is as close to structural as a deletion gets. T9 in
   `docs/threat-model.md` says what remains open.

5. **B1's two halves are both implemented and neither is redundant.** Over HTTP
   the invalidation fires first, so the hash check looks unreachable from the
   route. It is not unreachable from a shell, a racing request or a future
   caller that writes `draft.body` without going through `edit_draft`, which is
   precisely the class F4 exists for one window later.

## Not done, and why

Nothing was deferred. No feature was added and nothing was taken from
`docs/post-raise.md`.

## What has not been verified in this environment

The two Terraform changes — `aws_cloudwatch_event_rule.task_never_started` and
the widened SNS topic policy — are validated (`tofu validate`, `tofu fmt`) and
asserted by tests that read `infra/`. **They have not been applied to AWS and
have never fired.** No claim is made that this alert has paged anybody; what is
claimed is that the rule exists, matches the absent-exit-code shape, and is
permitted to publish to the pager. `make game-day` fires the alert paths that can
be fired locally and does not cover an ECS task state change, which needs ECS.

---

### 2026-08-28 — Gate A audit, eight findings

Two independent external audits assessed this repository against §16.1. One read
code; the other provisioned Postgres, seeded it and attacked the running system.
Every finding below was verified against this tree before any of it was written,
and the deviations are in their own section rather than left implicit.

| Fix | Finding | Status |
|-----|---------|--------|
| 1 | Pack signing separation of duties is unenforceable | FIXED |
| 2 | Malformed rule identifiers crash validation and evade duplicate detection | FIXED |
| 3 | Required CI guard passes vacuously | FIXED |
| 4 | Every deployed scheduled task crashes at import | FIXED |
| 5 | The chain verifier fails unsafe under tamper | FIXED, with a correction to the finding |
| 6 | The asynchronous execution tier is deployed nowhere | FIXED — four deployed, one deferred with reason |
| 7 | Request handler uses the owner database session | FIXED |
| 8 | Customer-facing documentation promises infrastructure that does not exist | FIXED |

---

**Fix 1 — a draft has an author, and a signature that is not the author's own.**
`pack_drafts` recorded `signed_by`, `signed_by_user_id` and `signed_at` and no
author field at all, so §3.2's separation could be neither enforced nor
evidenced. `test_lifecycle.py` asserted the opposite in as many words.

`publish` already refused a publisher who signed, and that is a different check.
Publication is the second pair of eyes on a *signature*; this is the second pair
on the *content*. A publisher who did not sign still cannot check rule content
they never read — what they can check is that a named specialist attested to it,
and if that specialist wrote it, the review chain is one person long.

Migration 0049 adds `created_by_user_id` (NOT NULL), `created_by`,
`second_reviewer_user_id`, `second_reviewer`, `second_reviewed_at`, and a CHECK
constraint making signer-is-author-with-no-independent-reviewer unrepresentable.

*The backfill is two different answers, deliberately.* `pack_draft_transitions`
records every draft's creation with `by_actor`, and `publish` has always read
that row to fill `pack_publications.drafted_by`. Where it names somebody, that
*is* the author and the migration uses it. Where it is null — the seed, the
offline scripts — nothing in the database knows, and the row is stamped
`UNKNOWN_PRE_MIGRATION`: obviously not a person, and impossible to confuse with
a `usr_` or `apc_` id. The **display name** is the sentinel on every
pre-migration row even where the account is known, because no display name was
ever recorded and writing an account id into a column printed as a name is the
FP3-26 walkthrough's own finding committed on purpose.

*The constraint is `NOT VALID`, and that is the honest position.* It enforces on
every row written from now on and asserts nothing about rows written before it
existed. This repository's own suite has been signing self-authored drafts for
thirteen stages, so there are databases holding violating rows — the dev
database has two, `usr_lifecycle_test` authoring and signing. Validating would
either fail the migration on those databases or require rewriting the backfill
until nothing violated, which is manufacturing a clean history. The rows stand,
and what they are is now a query.

*The escape hatch, and why it exists.* A firm with one specialist for a regime
would otherwise be unable to change its rules at all, and the failure mode of a
rule nobody can satisfy is not compliance — it is the specialist writing the
draft and a colleague signing it having read nothing, which is the same
single-reader review with a second name on it and reads as correct. So
`drafts.record_second_review` and `POST /watch/drafts/{id}/second-review` record
an independent read by another `pack_signatory` **for that regime**, by the
account in scope, before the signature. The reviewer's grant is re-read at
signature time rather than trusted from the recorded row: a withdrawn
qualification is a reason the author may no longer sign their own work.

*One thing worth recording about reachability.* `POST /watch/drafts` requires
`operator` or `approver` and signing requires `pack_signatory`, so over HTTP the
forbidden path needs somebody holding both — which is exactly the S5 gate item's
own description of the workflow ("the AU specialist authoring and signing a real
pack in the workbench"), not a corner case. The direct-call path and a shell
were unbounded, which is why the constraint matters as much as the check.

Author, signer and second reviewer are surfaced on the draft view, in
`pack_publications` — whose `drafted_by` carried an account id in a column every
reader takes for a name — in the published pack body, and in the artefact's
evidence-integrity table, printed only where the pack records them so a document
about older content does not acquire a blank line claiming it had no author.

---

**Fix 2 — a malformed rule identifier is a fault, not a crash or a wrong answer.**
`validate` tested `rule_id in seen_ids` against the raw value and stored
`str(rule_id)`. Two defects in one line and both real: a list-valued `rule_id`
raised `TypeError: unhashable type` where §S3 requires a validation fault, so
`evidence.replay` could not classify it as `PACK_INVALID_AT_REPLAY`; and two
rules numbered `1` never collided, because `1 in {"1"}` is False, so a pack
loaded with one of its two rules invisible in the evidence.

*Fixed by type-checking rather than by normalising both sides,* which is a
deviation from the obvious reading of the finding. Normalising would remove the
crash and keep the second defect in a new form: `1` and `"1"` would become one
rule id, so a pack could name a rule two ways and the evidence would key on
whichever spelling the author used. A rule id is a string.

`reason_code` had the identical shape — `not in pack.reason_codes` hashes the
raw value, `_suggest(str(reason_code), …)` normalised for the message only — and
gets the same treatment.

*The audit of the rest of the file, so the next reader does not repeat it.*
`on_fail not in OUTCOMES` looks identical and is safe: `OUTCOMES` is a tuple, so
`in` compares with `==` and never hashes. `_check_term` and `_shape_of`
normalise once with `str(...)` and then use the normalised value for both the
lookup and the message, which is the correct form of the same pattern.
`_lookup_tables_cover_every_class` reaches `entry.get("class")` on values
`Pack.from_body` has already established are mappings. Two real instances, two
that read like them and are not.

---

**Fix 3 — every guard validates every path it is pointed at, and says what it
read.** `guard_no_hardcoded_region.sh` validated `INFRA_DIR` and never validated
`SCAN_ROOT`, which was added by the same commit and used unchecked on the grep
line. That is audit G-07's defect surviving in the second parameter of the guard
whose first one G-07 fixed.

The reason it survived is that the rule had three hand-written copies —
`guard_no_shared_passcode.sh` and `guard_no_naive_today.sh` each had a correct
one of their own. Three copies is three places to leave one out. `require_scan`
in `guard_lib.sh` is the single implementation and answers both questions: the
path exists, and it holds files this guard can actually read. A directory of
Markdown greps exactly like a missing one.

*Two defects in the first version of that function, both found by the new
mutation cases.* It summed counts across paths, so a guard passed with one of
its two directories empty; and it counted files `grep` would never read, so the
success message overclaimed by four orders of magnitude — this finding's second
half reproduced inside its own fix. `.hypothesis` joins `IGNORED_DIRS` for the
reason `.venv` is there: it is a machine-written cache of every string literal
in the repository, and a widened guard started reporting matches out of it.

*The scan is widened rather than the message narrowed,* because the header's
claim of repository coverage was the right one. It reads every text file in the
tree now, which turned up three region literals in `api/migrations` no version
of this guard had looked at. They are exempted **by name with their reasons**
rather than by exempting the directory, so a fourth is a finding rather than a
precedent. `api/tests/` is exempted as a directory: a region in a fixture is not
a deployment fact and several of those files write one deliberately, including
the suite that proves this guard refuses one.

`PATH_PARAMETERS` in `test_guard_mutations.py` enumerates every path a guard
takes from the environment and gives each two cases — pointed at nothing, and
pointed at a real directory holding nothing readable. Thirteen fail before the
fix.

---

**Fix 4 — every deployed scheduled task ran an interpreter the image does not
have.** All three task definitions overrode the image's CMD with a bare
`["python", "-m", "scripts.…"]`; dependencies live in `/app/.venv` and a bare
`python` was the base image's. Every scheduled task died on its first
third-party import, which silently disabled the whole monitoring tier —
including the health job that would have reported the outage and the heartbeat
written so a dead monitor can be told from a quiet one.

*A third defect, found by verifying the fix rather than by reading.* There was
no `.dockerignore`, so `COPY api/ /app/` copied a developer's macOS virtualenv
over the Linux one `uv sync` had just built. That is why the API worked and the
tasks did not: the API's `uv run` noticed the mismatch and rebuilt the
virtualenv at every container start, repairing the image on the way past.
Removing the wrapper without a `.dockerignore` would have moved the failure from
the tasks to the API. Three defects, each hiding the next.

The convention is the image's PATH — `/app/.venv/bin` on it, so `python` is the
virtualenv's for the CMD, the healthcheck, every task override and a shell in a
running container. PATH rather than a wrapper because a wrapper has to be
remembered at every call site, and three task definitions are the proof.

*A correction to the finding.* The removed fallback's reduced package set was
described as missing `pyotp`, `authlib` and `argon2`. `pyotp` and `authlib` are
not dependencies of this project at all — TOTP is fifteen lines of HMAC in
`app/totp.py` checked against published vectors, and the JWT library is `pyjwt`.
What the fallback actually omitted was `alembic`, `cryptography`, `argon2-cffi`,
`pyjwt`, `anthropic` and the rest. The substance stands; the names did not.

*The test that should have caught this is narrowed to what it can support.*
`test_the_watch_sweep_runs_in_its_deployed_environment.py` reconstructs the task
environment faithfully and runs under `sys.executable`, where every dependency
is present. Its DSN assertions are FP3-03's and are kept; its claim that the
sweep *runs* is about the wrong interpreter and no care with the environment can
reach that. `scripts/image_smoke.py` does what a unit test cannot: it reads the
task definitions, builds the image, resolves each command's entrypoint inside it
and imports every `-m` module. Run against the pre-fix Dockerfile it reports all
three tasks failing on `ModuleNotFoundError: No module named 'sqlalchemy'`.

*And alerting, because EventBridge reports success when `RunTask` is accepted.*
`schedule_never_fired` alarms on `FailedInvocations` per rule — the shape an IAM
omission takes, which is a schedule that exists and is denied on every firing.
`task_stopped_badly` sends a container's non-zero exit, with the group and the
stopped reason, to the pager. Deliberately unfiltered by exit code: a job that
exits 2 because something is wrong and a task that dies on an import both need a
person, and the operating table is what tells them apart once somebody reads.

---

**Fix 5 — the chain verifier answers under tamper instead of going quiet.**

*A correction to the finding, which changes the fix's shape and not its
substance.* The `ValueError` did **not** escape `alerts.check`: that function
has had a blanket per-check handler since it was written, so the exception
became an `alerts.check_failed` finding — CRITICAL, exit 2. The exit-code
contract was already right. What was wrong was the sentence: *"the
chain_integrity check could not run — fix the check before trusting the absence
of the alerts it produces"* instead of *"the evidence chain does not verify at
determination #4,201, stop issuing artefacts, follow chain-mismatch.md"*. An
actionable instruction pointing at monitoring code while the evidence is being
altered is worse than a wrong severity, because somebody follows it.
`scripts/nightly_replay.py` was exactly as reported: no wrapper, and the run
died.

`verify_chain` reads the columns and decodes the snapshot itself, one row at a
time, inside a handler. Every row-level fault is a graded verdict naming the
decision and the tenant, with a reason code — `HASH_MISMATCH`,
`UNDECRYPTABLE_SNAPSHOT`, `ROW_UNREADABLE`. `NoChainAnchor` still raises: it is
not a row-level problem and `alerts.chain_integrity` reports it with its own
instruction.

*And the inverse, found by running the fix.* Its first run, in a shell with no
`QUOLIN_MASTER_KEY`, confidently reported that decision 1 had been tampered
with. `KeysNotConfigured` and `NoDataKey` are re-raised rather than graded —
they say this process cannot decrypt anything, not that a row is forged — and
arrive as `chain.unverifiable`. Reporting a configuration failure as tampering
is the same misdiagnosis pointing the other way.

`nightly_replay` also loaded every decision before its per-decision handler, so
one forged row ended a run with four thousand determinations left to check.

*Two existing tests were passing for the wrong reason and are rewritten.* Both
altered an ORM object without flushing — `decisions` refuses UPDATE by trigger
and by revoked grant — so `verify_chain` walked the identity map and reported on
an object the test process had altered. Comfortable in that direction and
dangerous in the other: a session holding a cached copy of a row an attacker
then altered would have verified against the copy and reported the chain intact.

`docs/runbooks/chain-mismatch.md` says which question each reason code asks;
`docs/threat-model.md` T1 records the change.

---

**Fix 6 — four of the five asynchronous workers are deployed, one is deferred
with its reason, and the rule is enforced.** Five scripts appeared in the
Makefile and in zero Terraform files. This heading said "the asynchronous
execution tier is deployed" until the Gate A close corrected it: the deferral
was recorded twice below and in the operating table, and the summary line above
it still read as five. A summary that has to be read to the end before it stops
overstating is a summary that overstates.

*Scheduled tasks rather than an always-on worker service, and the code decided
it.* All five are one-shot: they run a pass, report a tally and exit with a code
their own docstrings document. `deliver_webhooks.py` says "run it on a short
cycle — a minute is right"; `settle_packs.py` says "run it daily, after midnight
in the deployment's region". A daemon would grow its own timer, and that timer
would be a second place where cadence lived — the argument the watch sweep
already makes. The cost is stated rather than hidden: a Fargate task takes tens
of seconds to start, so a webhook is delivered in about a minute and a half, not
"within seconds", and Fix 8 corrects the document that said otherwise.

*Deviation: `batch_sweep` is deferred, with the reason in the operating table.*
It reads a directory tree per tenant, and this deployment has no EFS mount, no
drop bucket and no SFTP server. A nightly task would read an empty directory
inside its own container forever and report success every morning — a job
represented as operating that has never operated on anything, which is precisely
what this audit is about. `make restore-drill` is recorded the same way, and
both rows carry their reasons.

*Three of the five would have served one firm and reported success.*
`deliver_webhooks`, `settle_packs` and `batch_sweep` defaulted to
`tenancy.configured_tenant()`. Their docstrings said tenants are named and not
discovered "because under FORCE row-level security a query for all tenants
returns the one in scope" — which stopped being true at migration 0029, whose
`quolin_maintenance` grant exists precisely so a scheduled worker can ask. They
enumerate now, with the `assert_can_enumerate` preflight `health_alerts` has and
`artefact_worker` and `bulk_worker` still lack. That is why each of the four
deployed tasks holds `DATABASE_URL`, and `scripts/guard_task_credentials.py` is
where the trade is reviewed.

*And the rule that would have caught two of them is mechanical now.*
`docs/deployment.md` already stated it in prose, which is a rule enforced by
whoever remembers it. `scripts/deployed_workers.py` reads the table, the
Makefile, the schedules and the policy and fails when any of the four disagrees,
in both directions. It links a row to a task through the **module** the target
runs rather than by matching names, so a rename cannot make it vacuous — and
keying on the module rather than the whole argv is deliberate, because the
deployed comparison task passes `--json` and `make comparison-report` does not.

---

**Fix 7 — a request handler uses the connection a request is entitled to.**
`GET /admin/users` imported `OwnerSessionLocal` from `app.db` inside the handler.

*It bought nothing.* The handler justified the owner read on the ground that
`users` is a platform table invisible until `app.user_id` names the row. That is
`user_self`, and it had already stopped being the whole story: migration 0047
re-pointed `user_reachable` at `tenant_members`, which is exactly the roster
this handler lists. Every person it enumerates is visible to the firm's own
connection — asserted, not argued: all 251 demo members resolve through a
tenant-scoped session. **No migration was needed.**

*It was also broken in production, which nothing said.* FP3-04 removed
`DATABASE_URL` from the request-serving task and `db.py` falls back to a
hardcoded `localhost:5433`, so in the deployment this did not escalate — the
user-administration screen returned 500. The bypass was reachable exactly where
the owner connection happens to be lying about, which is a laptop and the suite.

*And `owner_only.py` could not stop it.* That module refuses to import without
`DATABASE_URL` so the mistake fails loudly, and its own docstring names the
hole: "importing this from anything a request can reach is a mistake this cannot
prevent". The import went around it to `app.db`.
`scripts/guard_no_owner_in_request_path.sh` is what prevents it: no module under
`api/app` may name `OwnerSessionLocal`, `owner_engine` or `OWNER_DATABASE_URL`
except `db.py`, which constructs them, and `owner_only.py`, which is the door.
The guard is a grep so CI can run it with no Python project set up; the test
beside it is an AST walk so that a comment describing the defect is not a match,
and the two are asserted to agree. `docs/threat-model.md` T9 records it.

---

**Fix 8 — a capability this system does not have is not described in the present
tense.** `docs/integrations.md` told an engineer at a customer that *"you get an
SFTP account, chrooted to your own directory"* and *"at rest, files are
PGP-encrypted"*. There is no Transfer Family resource, no sshd and no PGP
handling anywhere in this repository, and `api/app/batch.py`'s own comment
defers to "server configuration described in `docs/integrations.md`" — to the
document that claims it exists. Neither file was lying alone; together they said
something untrue.

The drop section describes the intended shape and says, above it, that none of
it is built and what to do instead. Two more corrections fell out of the sweep:
webhook latency, which the summary table gave as "within seconds" and which Fix
6's cadence makes about a minute and a half; and the retry table, whose 30-second
first backoff is a floor the scheduler cannot beat.

*The endpoint that document sends a customer to check was missing the edge.*
§6 says "`/integrations` in the product lists every external edge … read it
before you assume something is live", and the batch file drop — the largest edge
in the document — had no entry at all. An unlabelled boundary reads exactly like
an integrated one, which is what `app/integrations.py`'s own docstring says it
exists to prevent. It is there now, as `local`: real behaviour, really executed,
wholly inside this deployment rather than reaching the counterparty it eventually
would, which is that status's definition verbatim.

*The sweep is mechanical and runs in both directions.*
`test_customer_documentation_does_not_outrun_the_code.py` requires every section
of a customer-facing document that mentions an unbuilt capability to say so in
that section — not a ban on the word, because describing a shape you intend to
build is legitimate; what is refused is describing it beside the things that are
built, in the same voice. And each entry carries a pattern that must match
nothing in `infra/` and `api/`, so the day Transfer Family is deployed the file
fails and asks for the documents to be corrected the other way. A hand-kept list
of "things we have not built" otherwise becomes a list of things we used not to
have built.

*One thing that finding taught about writing this kind of check.* `"would be"`
was on the marker list and let the original document through: the section
describing SFTP as delivered also said "a shared directory **would be** one
customer able to read another's book" — a sentence about a risk, not a deferral.
Found by running the new file against the pre-fix document, where it passed. A
marker has to be a phrase that can only mean "this does not exist yet".

---

## Deviations, and why

1. **Fix 1's CHECK constraint is `NOT VALID`.** Validating it would fail the
   migration on every database holding a self-signed draft — which includes this
   one — or require a backfill written until nothing violated. Enforced on every
   future write; silent about the past, which is where the violations are.

2. **Fix 2 type-checks rather than normalising.** Normalising both sides fixes
   the crash and leaves `1` and `"1"` as one rule id, which is the duplicate
   defect in a new costume.

3. **Fix 5's finding was wrong about one thing** and it is recorded above: the
   exception did not escape `alerts.check`, and the exit code was already
   correct. The damage was the instruction, not the code.

4. **Fix 6 deploys four of five.** `batch_sweep` reads storage that does not
   exist; deploying it would create a job that reports success every morning
   having read an empty directory. Deferred in the operating table with the
   reason and with what it needs.

5. **Fix 4's finding named two packages this project does not use.** `pyotp` and
   `authlib` are not dependencies; TOTP is written in-house and the JWT library
   is `pyjwt`. The fallback's omissions were real and were other packages.

6. **Fix 7 needed no migration.** The finding asks for a refactor "to the
   intended scoped connection model", and migration 0047 had already built it —
   the handler was written against the policy as it stood before 0047 landed.

## Found on the way past, and unrelated to the eight

* **`test_adoption_ladder.py`'s two onboarding tests counted back from today**
  while `adoption.onboarding` measures from the *first* transition into shadow,
  and `tenant_stages` is append-only. Green while the table was young, red the
  first morning after the database was more than a day old — the same shape as
  the profile-change defect in the fix-pack 3 entry below. They read the date
  the metric will actually use now.

* **Two chain tests were passing for the wrong reason**, recorded under Fix 5.

* **Fix 5's own new test broke the demo chain, and the three-tap regression
  caught it.** `test_the_nightly_replay_reports_a_forged_row_rather_than_dying`
  has to work against a *committed* row, because `_check_tenant` opens its own
  session — so the first version committed the forgery into the demo firm and
  deleted it afterwards. Its `this_hash` is sixty-four zeros;
  `evidence._tip_hash` is `ORDER BY id DESC LIMIT 1`, so a determination
  recorded while the forgery was present took those zeros as its `prev_hash`,
  and the cleanup then left a legitimate row pointing at nothing. `decisions` is
  append-only: there is no repair, and `make seed` was the only way out. It
  would have done the same in CI.

  Found because `test_three_tap.py` asserts `replay["chain"]["verified"]`, which
  is the one place the demo's own chain is checked end to end — the standing
  obligation earning its keep. The forgery now goes into a firm of its own whose
  `status` is not `active`, so `maintenance.active_tenants` skips it and its
  permanently broken chain pages nobody. A test that damages the evidence chain
  to prove the evidence chain works is the wrong trade at any odds.

* **The seed cut its two watch drafts with no author**, which migration 0049
  refuses. They record the watch service, because that is what cut them — both
  are raised from watch events — and it is the case where the human signature
  has to be independent, which the HK draft then demonstrates.

* **The sweep benchmark asserted a product budget on somebody else's hardware,
  and the first fix for it was wrong.** Recorded in full because the wrong
  answer was reached first and the evidence that overturned it is the useful
  part.

  CI failed it at 165.5 pairs/s against a required 167. The previous CI run had
  passed the same assertion twice, under two timezones, so the first reading was
  "noise around a passing median" and the fix was to take the best of three
  attempts — a floor being a claim about what the code *can* do, and contention
  only ever making it look slower. That change was checked against a simulated
  regression before being kept, and it was still the wrong fix.

  **The next run failed all three: 159, 123, 150.** The test's own message says
  what that means — "every one of them missed, which contention does not
  explain" — so the median on that hardware is *below* the bar, not the tail.

  **Measured head to head before touching anything else.** A worktree at
  `fixpack-3` and this branch, same machine, same database, interleaved: base
  ran at a median of 305 then 278 pairs/s; this branch at 351. The branch that
  failed CI is **faster than its own base**. Nothing here touches `bulk.drain`,
  the shelf pinning or the baseline lookup, and now that is measured rather than
  argued. A GitHub runner sharing two vCPUs with a Postgres service container
  runs the sweep at 120–170, which straddles 167.

  So the defect is that a build check was set at the *product* budget on
  hardware that cannot be relied on to clear it. `test_benchmarks.py` — which
  owns the same hundred-thousand-in-ten-minutes number — had already settled
  this: "a fixed budget with a wide margin fails only when something has changed
  by an order of magnitude, which is the only change worth failing a build
  over", and "a benchmark that cries wolf is a benchmark somebody deletes". This
  one had a margin of zero and ran in the main suite.

  It follows that file's convention now: skipped unless `QUOLIN_BENCHMARKS` is
  set, run in CI's dedicated benchmarks step, the product budget **printed**
  against the measured rate, and a smoke floor of 50 pairs/s asserted.

  **The threshold was not lowered — the assertion was moved to where it belongs.**
  The specific regressions the old failure message told a reader to check are
  already guarded next door by `test_a_sweep_does_not_re_read_the_shelf_for_every_pair`,
  which counts round trips, and whose docstring records that the timing
  assertion *could not* catch them anyway: "removing the pinned shelf costs a
  third of the throughput and the wall-clock assertion still passed on a fast
  machine". There is no floor that both survives a GitHub runner and catches a
  threefold regression, because on that hardware the two overlap. A query count
  for the shape of the work, a wide floor for catastrophe.

* **`test_guard_mutations.py` copied seven hundred megabytes per test case, and
  it filled a disk.** `tree()`'s ignore list omitted `.terraform`, which
  `tofu init` fills with about that much in provider plugins — so every one of
  the seventy-odd cases copied it, pytest keeps three runs, and a laptop that
  had run the suite a dozen times held a hundred and sixty-nine gigabytes of
  temporary trees. The copies then started failing, and it arrived as twenty
  `ERROR`s in a file about guards, describing nothing about guards.

  Two changes, and the second is the one that should have been true from the
  start. `.terraform`, `.hypothesis` and `drop` join the ignore list, which is
  now the same set `guard_lib.sh` keeps the guards away from and for the same
  reason. And **a case that does not modify the tree no longer copies it** —
  guards are read-only by construction, and `test_every_guard_still_passes_on_the_real_tree`
  was saying so in its name while copying anyway. Twenty copies a run instead of
  seventy-five, at six megabytes each instead of seven hundred: the file runs in
  eleven seconds where it took three and a half minutes.

  Fix-pack 3's own lesson, arriving from a new direction: green until something
  accumulates.

* **There was no `.dockerignore`**, recorded under Fix 4. The production image
  was shipping a developer's macOS virtualenv.

---

### 2026-08-28 — Fix-pack 3, Tier 4 completed without browser tests

Supersedes the two **NOT DONE** rulings in the entries below, on instruction:
*"finish FP3-12 and FP3-26 without the Playwright tests."* Those entries are
corrected in place rather than deleted, per the standing rule about not
rewriting history.

| Ref | Finding | Status |
|-----|---------|--------|
| FP3-12 | No enrolment screen; every 401 signs the person out | FIXED — no browser test |
| FP3-26 | Route families with no web client | FIXED — no browser test |
| FP3-17 | Console banner, the outstanding third of an otherwise-fixed finding | FIXED — no browser test |

**What "no browser test" means here, precisely.** Playwright's browser still
does not launch in this environment. The screens are written, they typecheck,
and `npm run build` compiles all twenty routes in a production build — which is
the check that caught the `params`-is-a-Promise defect on every dynamic route
last time, so it is not nothing. What is missing is a test that drives one of
these screens as the role that would use it. Nobody should read the entries
below as saying otherwise, and the README self-assessment says the same.

The half that *is* proved is the contract the client is written against, and it
is proved through the API a browser talks to:
`test_a_confined_session_can_be_told_so_and_can_get_out.py` and
`test_the_console_can_read_what_it_administers.py`.

---

**FP3-12(a) — a locked door with the key on the other side.** A session holding
one of `MFA_REQUIRED_ROLES` with no verified second factor may reach four paths
and nothing else. `POST /auth/mfa/enrol` was one of them and had no screen
anywhere, so a firm's first approver signed in successfully and then got 403 on
every page, with the instruction buried in a JSON body they would never see.

`AuthGate` now has a fifth state between signed-out and signed-in, and renders
enrolment instead of the app — not a banner, because the app behind a banner
does not work and the person would be reading four error states at once.

`/auth/session` answers a new `mfa_required`, computed by the same
`mfa.locked_out` the middleware enforces with. **The client deliberately holds
no copy of `MFA_REQUIRED_ROLES`**: a duplicated policy list drifts, and the
direction it drifts is the dangerous one — a role added on the server would be
enforced by the middleware and unknown to the client, which is a privileged
account seeing 403s nothing can explain.

**FP3-12(b) — the careful reviewer was the one punished.** Every 401 was
answered identically: destroy the offline cache, show the lock screen. Four
routes return a 401 that means "confirm your password", not "you are signed
out", and they carry `X-Quolin-Reauth: required` to say so. So a signatory who
actually read the draft before signing it lost the draft, the cache and the
session — and somebody who signed without reading did not. `withReauth` catches
that 401, asks in place, and retries the **original** request once. Retried once
and not in a loop: a second stale-credential error immediately after a
successful `/auth/reauth` is not a stale credential, it is something wrong.

**FP3-12(c) — decided: raise the default, 5 → 15 minutes.** The brief offered
two options and asked for one, with the reasoning recorded.

*Rejected: restart the window when the draft is opened for signing.*
`authenticated_at` means *a credential was presented* and `last_seen_at` means
*the browser is still there*; the split is the entire mechanism. Moving the
first on a page load would make opening a draft count as proving you are
present, silently, on a GET, with no credential anywhere near it — which is
precisely the unattended-machine case the split exists to catch.

*Chosen: fifteen minutes.* The old constant's own comment claimed five was "long
enough to read the draft that is about to be signed", and that was untrue about
the thing being signed — a pack draft is a rule document with a diff, a
validation report and a preview. What five minutes enforced in practice was a
habit of signing first and reading afterwards, which inverts the purpose. Not
longer than fifteen, because past about a quarter of an hour "the person who
authenticated is still the person acting" stops being a claim the timestamp
supports. Any finite value is survivable only because of (b): an expired window
now costs a dialog rather than the draft.

Tested behaviourally rather than against the constant: ten minutes signs, twenty
is refused with the header, and re-authenticating in place lets the same act
through on the same cookie.

---

**FP3-26 — seven screens, and one new route.** Delta reports (`/runs`,
`/runs/{id}/deltas`, with CSV export), the document queue (`/artefacts/jobs`,
failures visible and re-askable, download), user administration and invitation,
the rule-version policy toggle, the chain certificate on the evidence room, the
adoption rung on the dashboard, and source attestation history on the currency
screen.

**One route was added, and the brief permits exactly this on condition it is
said out loud.** `GET /admin/users` did not exist. Five write routes did —
provision, grant, revoke, suspend, reinstate — and nothing could list the people
they act on, so a user-administration screen genuinely could not be built. It is
scoped by `user_roles`, so somebody who holds no grant in this firm is not
listed even though the `users` row exists; that is the same rule
`access_review.collect` applies, and the reason a consultant serving three firms
appears in three rosters and not a fourth.

**It does not check credential freshness, and every write on the same screen
does.** `_provisioning_principal` demands a recent credential because "an
unattended screen must not be able to *do* either" — create an account, hand
over a role. Reading who already holds what is not one of those acts, and
requiring freshness for it would mean the screen could not open until somebody
retyped a password, which teaches people to retype passwords whenever a screen
asks. A test stales the credential and asserts the read answers while the write
refuses with the header.

**Two additive fields, neither of them new surface.** `queue.view` now returns
the job's `params`, so the queue screen's retry is the original request repeated
rather than English parsed out of `subject`. `/auth/session` returns
`credential_fresh_minutes`, so the re-authentication dialog states the real
window instead of a number written into the copy that stops being true when the
environment variable moves.

**The CSV is built in the browser and says so.** A second endpoint producing the
same report would be a second implementation that could disagree with the
screen, and `/audit/export` is already the route for "a file the engine attests
to". The move filter is deliberately **not** applied to the file: a CSV quietly
holding a subset because of a dropdown somebody forgot they touched is the kind
of evidence that gets a firm into trouble.

**The chain certificate is excluded from the service worker cache** (worker
v7). The endpoint refuses to cache it server-side because "a stored 'verified'
is a claim about a moment that has passed", and a worker serving yesterday's
certificate would reintroduce exactly that — worse than the audit export the
worker already excludes, because this one downloads as a signed-looking
statement.

**An eighth screen was necessary and is not in the brief: `/invite`.** FP3-11
gave provisioning an invitation token and `/auth/set-password` a way to spend
it. The token came back as JSON to an administrator running curl and there was
nowhere to send the person. An invitation somebody has to paste into a terminal
is FP3-11's original defect wearing a different hat, so the administration
screen hands over a link and this is what the link opens. It sits outside
`AuthGate` — the person arriving has no session and cannot get one, which is
what they are there to fix — and the token travels in the URL **fragment**,
which is not sent to the server, not written into access logs and not put in a
`Referer` header. It is removed from the address bar as soon as it is read.

**Routes still without a screen are listed in the README** under *What the
console does not reach*, with who calls each. `/auth/sessions` +
`/auth/revoke-all` and `/webhooks/deliveries` + redelivery are recorded there as
DEFERRED with reasons.

---

**One pre-existing test defect, fixed on the way past.** Two helpers in
`test_a_profile_change_rechecks_that_client.py` took the newest forty
profile-change runs and filtered them by note **in Python**. Once the database
held more than forty of them, the runs under test fell out of the window — so
the run a test had just created evicted an older match instead of adding to it,
and `before + 1` failed. It passed for eleven stages and failed the first time
the suite ran against a database with enough history, which is the same shape as
every other defect this fix-pack found: green because nothing had accumulated
yet. Filtered in SQL before the limit, and the limit removed rather than raised,
because a raised limit is the same defect with a larger number in front of it.

---

**Walked in a real browser, and it found four defects.** Playwright does not run
here; a person driving Chrome does. Every screen was opened as the role that
would use it, with the API live, and the walkthrough is the reason this entry
does not simply say "the screens compile".

*The people screen offered four buttons to somebody who could use none of them.*
The read was widened to `STAFF` deliberately and the writes belong to
`quolin_operator`, so a firm's own operator could compose an act and be refused
at the end of it. A control that exists to produce a 403 is worse than no
control, which is the same argument `useEngineReachable` already makes about
POSTs while the engine is unreachable.

*The same screen printed `granted by usr_3FT6FW8AcS5hIT-m`.* That line exists to
answer "who did this", and an opaque id answers it only for whoever can query
the database.

*The invitation page said "Nothing to accept" against a live link.* The token was
read in an effect that also cleared the fragment, and React's development
double-invocation had the second pass read the emptied hash and overwrite a good
token with null. Moving the read to a lazy `useState` initialiser did not fix it
either — the page is prerendered, so hydration keeps the server's null.

*And that page never removed the token from the address bar.* The whole argument
for putting it in the fragment is that it stays out of logs and headers; it said
nothing about the screen, and the credential sat in the URL, the browser history
and every screenshot. `history.replaceState` is undone by the App Router's own
history sync during hydration, and `router.replace(pathname)` does not treat a
hash-only difference as a navigation. Both were tried and the fragment was still
there two seconds later, polled. It now clears and verifies until it is gone.

*Two things that looked like defects and were not.* The offline banner appearing
on a live engine was fallout from unregistering the service worker mid-session,
and did not recur on a normal load. `GET /packs/TT` and `/packs/TU` answering 503
is test residue in the demo database — `packs` is append-only, so regimes the
suite invented persist until `make seed`.

**FIXED — belonging to a firm is not the same fact as holding a role in it.**
Migration 0047. Found by the walkthrough, then confirmed by
`test_the_trail_names_only_actors_that_exist` failing. First recorded here as
DECISION-REQUIRED with a guard on the screen; that entry is superseded and the
guard is gone.

`users` has no `tenant_id` and cannot have one — a consultant compliance officer
serves three firms and is one human — so migration 0007 answered "which people
may this firm see?" with `user_reachable`: the ones it has granted a role to.
Right shape, wrong predicate. `user_roles` was carrying two facts at once: *this
person belongs to this firm*, and *this person may do X here*. Revoking
authorisation is an ordinary act somebody performs on a Tuesday. Revoking
identity is not, and it is what actually happened — the row was deleted, the
person stopped resolving for that tenant, and `audit_events`, append-only, went
on naming them as the actor of things they did. FP3-13 had already settled the
principle and built suspension so that off-boarding did not have this effect;
revoking the last grant went around it.

A second sequence reached the same state with no revocation at all:
`identity.invitation.consumed` names the invited person as its actor, correctly,
at a moment when they hold nothing.

**Membership is now its own create-only table**, written by `identity
.ensure_member`, and the three `_reachable` policies — on `users`,
`user_identities` and `mfa_credentials` — read it. `grant_role` writes the
membership itself rather than trusting call sites, because a grant without one
is a person holding a role in a firm that cannot see them, which fails closed in
the worst direction. Provisioning writes one too, which is what closes the
invitation window.

*Three things it deliberately does not do.* It does not weaken isolation — the
same fail-closed `EXISTS` against a tenant-scoped table, only the table changed,
and two tests assert a neighbouring firm can still neither read a named row nor
enumerate the set. It does not touch the authorisation path: `roles_for`, `rbac`
and `access_review` read `user_roles` exactly as before, and a test asserts a
revoked role stops authorising. And there is no un-join, because an un-join is
the bug.

*The rejected alternative* was to keep revoked grants as soft-deleted rows and
match those. That puts "is this grant live?" into every query that reads the
table, and the failure mode of missing one is a revoked role that still
authorises — the worst possible way to get this wrong. The chosen shape cannot
get it wrong at all, because membership confers nothing.

*The backfill repairs the past as well as the future.* It reads `user_roles` for
everybody currently granted **and `audit_events` for everybody who ever acted**;
without the second clause the migration would fix the next revocation and leave
every existing orphan exactly where it is.

*The test that should have caught this had been passing since Stage 2.*
`test_a_grant_can_be_revoked_and_the_revocation_is_recorded` provisions
somebody, grants one role, revokes it, and asserted that the grant was gone and
the revocation was chained. All true, and it never asked whether the person was
still someone the firm could name — and the person it provisions never acts, so
no audit row named them and nothing downstream noticed either. Recorded because
"a test existed and asserted one half of what the act does" is a more useful
thing to know about this codebase than "no test existed".

It asserts the other half now — the person still resolves, and their account
status is untouched, because revocation is about what somebody may do and
suspension is how somebody leaves. Strengthened where the act happens rather
than only in the new file, since that test is where the next person will look;
checked failing against the pre-0047 predicate before being kept.

*And CI disproved the guarantee this entry originally claimed, within the hour.*
0047 put `ensure_member` inside `grant_role` and I wrote that a grant therefore
could not exist without the membership it implies. True of callers that use
`grant_role`; two fixtures in `test_rls.py` construct `UserRole` directly,
because they predate the split. On a database built from zero those grants had
no membership and the person holding them was invisible to the firm that had
granted them — which is the worst shape this can fail in, because the grant
still authorises. Migration 0048 moves the rule into an `AFTER INSERT` trigger
on `user_roles`, where no ORM insert, raw statement or future call site can go
around it, and `ensure_member` stays in `grant_role` as the second independent
statement of the same rule.

**It passed here and failed in CI for the reason this document keeps writing
down.** A developer machine stops having a database built from zero after the
first run; the memberships those fixtures needed had been left behind by 0047's
backfill on an existing database. The fix was verified by dropping the schema,
re-seeding and running the whole suite against nothing — and a second defect of
the same family fell out of it: a cross-tenant test in the new file depended on
the `neighbour` tenant, which is created by a fixture in `test_rls.py` and
therefore did not exist yet under collection order. It creates its own now.
Depending on another module's fixture is depending on collection order, and I
wrote it in the file that exists to say so.

*Two guards caught the two things I forgot*, which is the point of having them:
`test_every_table_is_classified_one_way_or_the_other` refused an unclassified
table, and the migration linter refused an append-only trigger on a table
missing from `APPEND_ONLY_TABLES`.

*And it had a consequence I had not thought of, found the same way.* The
administration screen listed grant-holders, so revoking somebody's last role
made them vanish from the very screen that would re-grant it or suspend them —
an act that quietly removed its own undo. `GET /admin/users` now lists the
firm's *members*, and somebody holding nothing appears with an empty `roles`,
which is a true statement about them.

Eleven tests in
`test_a_firm_can_still_resolve_somebody_who_has_left.py`. Four of them fail
against the old policy and were checked doing so, by repointing `user_reachable`
at `user_roles` in the live database and re-running; the other six assert the
properties that must *not* change and pass either way, which is what makes them
worth having.

*And one screen had never been seen with data in it.* `eval_deltas` was empty, so
a dry-run sweep was performed to fill it — which is what surfaced the two
rendering defects in the commit above.

---

**FP3-17's banner.** On every screen, not dismissible, naming the regime, the
superseding version and the days overdue. Not dismissible because the state
lasts until somebody takes or declines the version — a dismiss button would let
a firm turn off the notice without changing the fact, and the fact is that
determinations being made right now carry a stamp saying they were made on
superseded rules. Reads `GET /advances`, which already carried every field.

**Suite: 1643 passed, 11 skipped, under `TZ=UTC` and `TZ=Australia/Sydney`.**
Twelve guards green, including the migration linter's walk of 47 upgrade steps
against a scratch database. `make nightly-replay` verifies 7,649 decisions and
reproduces every one. Web: `tsc --noEmit` clean, `npm run build` compiles twenty
routes. **Playwright: 0 specs run — the browser does not launch here.** Every
screen was instead opened by hand in Chrome against a live engine, as the role
that would use it; the four defects that found are above.

---

### 2026-08-28 — Fix-pack 3, Tier 5 and the last of Tier 3

| Ref | Finding | Status |
|-----|---------|--------|
| FP3-17 | Pinned tenants notified after effectivity | FIXED — ~~banner outstanding~~ banner done 2026-08-28 |
| FP3-26 | Fifteen route families with no web client | ~~**NOT DONE** — Playwright~~ → FIXED 2026-08-28, see the entry above |
| FP3-27 | Publication is authorised by a tenant-local row | FIXED |

**FP3-17.** `advance.notice` was reachable only from `advance.sweep`, which
selects `effective_from <= today` — so a pinned firm learned a new version
existed **on the day it was already governing everybody on auto**. Publication
calls `notice` now, so the window precedes the change.

The overdue behaviour is exactly as decided: the window stays `PENDING`, nothing
auto-advances, nothing refuses a determination. What changes is that the state
is impossible to miss and impossible to deny — a daily webhook, a daily chained
audit event, and `pack_review_overdue` on every determination made in the
period, naming the pack, the superseding version and the days overdue.

Additive by construction and verified rather than argued: the field is added in
`service` after the snapshot is built, never in the engine — an engine that read
a tenant's advance state would break invariant 2 — and `make nightly-replay`
reproduces every decision on file. A test asserts no seeded determination grew
the field.

*Two bugs of mine, both caught by tests already in the repository.*
`announce_overdue` caught the duplicate-insert `IntegrityError` and called
`session.rollback()`, which discards the **caller's** transaction — the audit
event written moments earlier vanished, and the "one event per day" test found
zero. It is a savepoint now. And the overdue lookup ran once per pair:
`test_a_sweep_does_not_re_read_the_shelf_for_every_pair` caught it at 7.7
queries per pair against a budget of 7. Resolved once per chunk beside the
shelf, for the second reason that test gives — a window closing mid-run would
leave part of the book carrying the field and the rest not.

**FP3-27.** `quolin_operator` is granted through `user_roles`, which is
tenant-scoped; `packs` is global. **A capability whose target is every tenant
was authorised by a row belonging to one**, so compromise of a single firm's
role set reached every firm's regulatory content. Q-12 saw that publishing is
Quolin's act and expressed it as "a role only we grant"; the storage never
caught up, and a role is a row.

`platform_publishers` has **no `tenant_id` column**, and that absence is the
control: a table with no tenant column cannot be written by a tenant-scoped
grant and needs no policy to say so. The brief offered a `tenant_id IS NULL` row
in `user_roles` as an alternative — that would be a row invisible to its own
table's policy and therefore governed by whatever the next `WHERE` clause said,
which is the shape of every cross-tenant read there has ever been.

Only the owner may write it, there is no route that grants it, and a test
asserts there never is: a route would put the platform's most consequential
capability behind that route's own RBAC, which is the indirection the finding is
about.

**Dual control**: three distinct humans — the signer attests, two platform
publishers each decide it should go live. Pressing publish counts as one
approval, `uq_one_approval_each` stops two clicks from one person counting as
two, and the count is not configurable. The test for that sets four plausible
environment variables and reloads the module rather than reading the source,
because Rule A applies to the rules this fix-pack wrote as much as to anything
else.

The named holders are Volodymyr Romanenko and Su-Lee Oei, in the seed and in the
migration. **The seed publishes through them now**: it used to publish as the
tenant administrator, through a direct call no API route can make, so the demo
data was built by a path no real publication takes.

*Four of my own test defects, found by running it.* A probe that copied "the
newest draft" and got one another test had deliberately malformed. A probe that
granted somebody every role and committed, which made the access review fail by
finding a real conflict it had itself planted. Two skip-on-absence branches. And
a `getsource` assertion violating Rule A.

**FP3-26 — NOT DONE.** Seven console screens, each requiring a Playwright test
that drives it as the role that would use it. Playwright's browser does not
launch in this environment; the detail is in the entry above. The routes they
would consume all exist and are covered by API tests.

> **Corrected 2026-08-28.** This ruling was superseded on instruction — the
> screens were built without the Playwright specs. Playwright still does not run
> here, so the "no browser test" half of the sentence above stands; the "not
> done" half does not. See the Tier 4 entry at the top of this file.

**Suite: 1614 passed, 11 skipped, under `TZ=UTC` and `TZ=Australia/Sydney`.**
Twelve guards green. `make nightly-replay` reproduces every decision on file.

---

### 2026-08-28 — Fix-pack 3: where this prompt was wrong against the code

Recorded because the brief asked for it, and because pushing back here rather
than silently doing something different is the whole point of the section.

**FP3-05's line number.** The brief cites the region default at `models.py:178`.
On this tree it is line 225. The finding itself was exactly right and worse than
stated: it was not merely a hardcoded region, it was the default for every
tenant row created through the API.

**FP3-05's business-date fix could not stop at `date.today()`.** The brief names
that spelling and a guard for it. Two of the sites that mattered spell a
business date `datetime.now(timezone.utc).date()` instead — `verify_manually`
and `adoption.onboarding` — and were invisible to both the brief's list and the
first version of the guard. The dual-timezone CI run found them on its first
execution.

**G-05's "six ways past the guard" is three.** Reproduced individually:
`pack_id.startswith("hk")`, `pack_id in ("au", "sg")` and `'A' + 'U'` passed;
`jurisdiction.lower() == "eu"`, `jurisdiction in {"DE", "FR"}` and `x = 'AU'`
were caught. Half of that guard worked. Recorded because "all six" and "three of
six" imply different things about whether anybody was paying attention.

**FP3-10's reconciliation has a third answer, and the brief offers two.** It
asks whether `artefacts` should be append-only in the model or dropped from the
linter's list. Neither: `renderer.py` re-renders an existing document in place,
which is §S7's design, so it is not append-only — and `content_hash` is not
unconditionally write-once either, because a return regenerated after more
determinations land legitimately has different bytes. What is true is narrower
and more useful: the same *inputs* must produce the same *bytes*, which was
resting on one application-level `if` and now has a trigger. Two wrong guesses
before reading `renderer.py` properly; both are in the Tier 1 entry.

**FP3-18's "check first that no seeded client trips it" fails.** Five
determinations already carry a future-dated knowledge assessment. The brief
implies the check will pass; it does not, and the five rows are left alone
rather than rewritten.

**FP3-23's fix needs a schema change the brief does not mention.** Making
comparison outcomes append-only is impossible while `ix_incumbent_one_per_pair`
exists — migration 0021 enforces exactly one row per (client, asset, date). The
index is dropped, with its original reasoning quoted and answered.

**FP3-01's instruction to allow-list or rewrite 0026's downgrade has a third
option, and the repository already uses it.** Twelve migrations decline to
reverse at all. 0026 is the thirteenth and 0003 — which no audit named — is the
fourteenth.

**"Delete the three `read_text()` wiring tests" understates the problem.** Rule
A's mechanical check found five more files doing it, four of them legitimately:
static analysis where the code's shape *is* the claim. The allow-list separates
those from the banned kind and is expected to shrink.

**FP3-04's guard could not be a deny-list, which is what the brief describes.**
"Assert each task's secret set against an allow-list keyed on the container
command" is what was built, and it is right — but the reason it is right is that
`DATABASE_URL` in the API task was on nobody's deny-list for thirteen stages.
The brief's own wording gets there; it is worth saying why the distinction is
the whole finding.

**One thing the brief asked for that would have made the code worse.** FP3-20
offers "freeze the walk order in the DSL spec with a corpus case that pins it"
as an alternative to the set comparison. It also says to prefer the set, which
is what was done — but pinning the walk order would have made `inputs_read`'s
ordering a documented guarantee, and a determination's evidence would then
depend for ever on an implementation detail of `evaluate_condition`.

---

### 2026-08-28 — Fix-pack 3 (merged audits), Tiers 3 and 4

| Ref | Finding | Status |
|-----|---------|--------|
| FP3-11 | A real customer cannot obtain a password | FIXED |
| FP3-12 | Nobody can enrol an authenticator; the signatory is logged out on Sign | **NOT DONE** — see below |
| FP3-13 | No suspend route; off-boarding is N revokes and no statement | FIXED |
| FP3-14 | No read is audited | FIXED |
| FP3-15 | Duplicate batch drops are silently re-imported | FIXED |
| FP3-16 | Nothing records its own duration; attestation history never shown | FIXED |
| FP3-17 | Pinned tenants are notified after effectivity, not before | FIXED (console banner outstanding) |
| FP3-18 | A future-dated knowledge fact is accepted | FIXED |
| FP3-19 | `dsl_version` truncated; lookup keys are Python spellings | FIXED |
| FP3-20 | Replay bound to evaluator walk order | FIXED |
| FP3-21 | `batch.manifest()` is never called | **NOT PRESENT** |
| FP3-22 | The `_deciding_rule()` regression test passes vacuously | **NOT PRESENT** |
| FP3-23 | `comparison.ingest()` updates in place | FIXED |
| FP3-24 | `_replay_order()` falls back to alphabetical sort | **NOT PRESENT** |
| FP3-25 | Region default on tenant rows | FIXED (in Tier 2) |

**FP3-11 — the first customer's first user could never sign in.**
`identity.set_password` had two callers, the seed and the load model. `POST
/admin/users` creates, in its own docstring, "a person, created with no way to
sign in yet", and there was no invite, set-password or reset route; OIDC does
not provision. Every account that works today works because the seed gave it a
password, which is a demo rather than a product.

Provisioning mints a single-use, expiring, hashed token, returned once and never
stored. The policy is checked *before* the token is spent, because the failure
mode of a password rule is people locking themselves out by trying to obey it.
Both public routes refuse expired, already-used and never-ours with one message.
Tested end to end through the API alone, ending in a sign-in with a second
factor — an invite flow that stopped at "has a password" would hand a privileged
person a credential that cannot reach their work.

**Stated rather than implied: this repository sends no email.** The reset row is
written and an operator hands the link over. Smaller than having no reset; it is
here rather than left to be discovered.

*Two bugs of mine.* The first draft ran `check_rate_limit` outside the tenancy
scope, so the transaction opened with `app.tenant_id = ''` and **every valid
link was told it was invalid** — the same defect F2 fixed in `/v1/oauth/token`,
written again in the next public route. And `consume` needed `_scope_to_user`,
because `users` is invisible until `app.user_id` names the row.

**FP3-13 — there was no way to end somebody's access.** `user.status` was
checked at sign-in and set by nothing but the seed: the control existed and
could not be used. Off-boarding meant N revocations, which leaves the trail
recording that grants went rather than that a person left, and leaves any
browser they had open working until its cookie expires.

One act: status, every live session, one chained audit event with the reason.
Roles are deliberately *not* revoked — somebody back from leave should return to
what they had, and an access review reading a suspended account's grants is
reading something true. `reinstate` exists because a suspension nobody can undo
is one nobody uses, and one people avoid using is one that does not happen when
somebody actually leaves.

**FP3-14 — forty GET routes, thirty audit calls, none of them on a GET.**
`/clients/{id}` returns a name, a date of birth and contact details to anybody
holding `viewer`, and nothing recorded it. Three resources are audited — client
detail, decision snapshot, artefact download — plus any request under a
`quolin_support` grant, which `docs/` describes as "every access logged" and was
logged nowhere. **Not forty routes**, and there is a test asserting the
dashboard writes nothing: a trail nobody reads is where a real access hides.

**FP3-16 — both halves were dead.** `observability.timed` was written for "a
sweep, a render, a restore drill" and had no callers, so §S9's slow-operation
alerting had no signal. `watch.sources.verifications` was written, tested and
reached by nothing — for a `MANUAL` source the attestation *is* the monitoring,
and a green badge nobody can look behind is an opinion.

**FP3-18 — checked first, and the check failed.** Five seeded determinations
already carry a future-dated knowledge assessment:
`knowledge_assessed_days_ago` of -22, -45, -112, -178 and -191. In every one
`created_at` equals `as_of`, so these are not backdated reconstructions — the
engine accepted an assessment dated later than the day it ran.

The corpus case pins what the number does and the answer is the finding: **-1
day evaluates to ALLOW with no failing rules**, because every currency rule
reads a negative as comfortably inside its window. Those five rows are left
exactly as they are; `ClientUpsert` refuses the write.

**FP3-19 — checked first, and nothing moved.** All five shipped packs declare an
integer `dsl_version`, so refusing non-integers changes no behaviour. `2.9` no
longer becomes 2 and `True` no longer becomes 1. Lookup keys canonicalise to
JSON spellings with the Python spelling still accepted, so a specialist writing
`{"true": ...}` stops meeting a `PackError` at evaluation on content that had
already been signed.

**FP3-20 — replay was bound to the evaluator's walk order.** `inputs_read` is
built by walking the predicate and was compared by list equality, so any
refactor that reordered resolution would make every determination on file fail
to reproduce with the outcome unchanged — and the runbook says to treat a replay
mismatch as a possible tamper. **A tidy-up inside the evaluator would have
produced a platform-wide security incident containing no security event.**

Compared as a set keyed on `(kind, ref, value)`. Checked first: all **12,311**
seeded decisions replay with no mismatch, and a changed *value* is still a
mismatch, with its own test — otherwise the fix would have bought
reproducibility by no longer checking.

Audit C-05 confirmed and **documented rather than fixed**: `and` evaluates every
branch, so a null-guard cannot be written. Short-circuiting would drop the
skipped branches out of `inputs_read`, which is stored on every determination
ever made. That is an additive DSL v3 change, not a v2 repair, and
`docs/dsl-spec.md` §5 now carries the worked example.

**FP3-23 — the number a sale closes on was editable in place.** Reproduced:
`ingest` did `existing.outcome = mapped` and `incumbent_outcomes` had no
append-only trigger and no revoked grants. "We agree with you 97% of the time"
was movable in either direction by the application role, with no chain alarm —
the one figure in this system not protected the way every other one is.

A restatement is a new row and readers take the latest. 0021's unique index had
to go, and its reasoning is worth keeping: "a second opinion nobody can choose
between" solved the reader's problem by making the writer destructive, and
"nobody can choose" is answered by choosing.

**FP3-21, 22 and 24 are NOT PRESENT**, and each describes a state that has
already been fixed rather than one that exists.

* `batch.manifest()` **is** called, by `scripts/batch_sweep.py:88`, which writes
  it into the drop root. Report 1's reference to "the manifest" as existing
  output was right.
* `_deciding_rule`'s test (`test_bulk_evaluation.py:324`) asserts against real
  determinations and requires a non-empty set of cross-border cases decided by
  another regime's rule — **it cannot pass vacuously**, and its own docstring
  says that is how the first version of it passed.
* `_replay_order` (`evidence.py:495`) re-derives the order from the frozen
  snapshot through `applicable_codes` and `match_packs`; the only `sorted(...)`
  is the tail of codes the derivation does not reach, which is a missing pack
  and is deliberate. F3 fixed exactly this claim.

The third report's profile holds: three of its five claims describe the tree
before fix-pack 3 rather than the tree it was given.

---

### 2026-08-28 — Fix-pack 3: what is NOT done, and why

Two findings are not implemented and are not deferred on their merits. Both are
web work whose acceptance criterion this environment cannot meet.

**FP3-12 (MFA enrolment screen, in-place re-authentication dialog) and FP3-26
(seven console screens) — NOT DONE.**

Both require Playwright tests that "drive it as the role that would use it in
production, and assert on rendered content". **Playwright cannot run here.**
Verified rather than assumed: `playwright --version` reports 1.56.1 and the
browser is installed at `chromium-1194`, but a headless launch fails with
`Executable doesn't exist at .../chromium_headless_shell-1194/chrome-mac/
headless_shell` and a headed launch closes immediately with `Target page,
context or browser has been closed`. The 27 August entry records the same
symptom — "extracts an incomplete bundle in this environment, repeatedly, across
clean retries".

Writing seven screens and a set of browser specs that have never been executed
would be the shape of finding this whole fix-pack is about: work that looks
complete and has never been run. The API surface each screen consumes exists and
FP3-12's server side is already in place — `/auth/mfa/enrol`, `/auth/mfa/verify`
and `/auth/reauth` all work and are covered by API tests, including the full
invite-to-second-factor journey added for FP3-11.

**FP3-17 and FP3-27 are now done**, and the entry below records them. What
remains of FP3-17 is its console banner, which shares the Playwright blocker
above; the webhook, the daily chained audit event and the field on every
determination are all in place and tested.

---

### 2026-08-27 — Fix-pack 3 (merged audits), Tier 2: guards that did not guard

Rule B: every guard gets mutation cases, in `api/tests/test_guard_mutations.py`.
Writing them established that four of six guards were largely decorative — and
that one audit claim was overstated, which is recorded rather than repeated.

| Guard | Audit | What passed it | Status |
|-------|-------|----------------|--------|
| `lint_migrations.sh` | A.1 | seven alembic violations | FIXED (FP3-01) |
| `guard_engine_is_pure.sh` | G-04 | aliased clock, `importlib`, `__import__` | FIXED |
| `guard_no_jurisdiction_logic.sh` | G-05 | **three of six**, not six | FIXED |
| `guard_no_watch_in_engine.sh` | G-02/03 | a renamed resource | FIXED (FP3-04) |
| `guard_no_tier_divergence.sh` | G-06 | all four cases | FIXED |
| `guard_no_hardcoded_region.sh` | G-07 | a missing target directory | FIXED |
| `guard_no_shared_passcode.sh` | G-07 | anything outside eleven directories | FIXED |

**The engine purity guard was greps for import lines.** `from datetime import
datetime as _dt; _dt.now()`, `importlib.import_module("os")` and
`__import__("time").time()` all exited 0 — reproduced by injecting all three
into `dsl.py`. A grep sees the name `datetime` and cannot see what `_dt` is
bound to.

`scripts/engine_purity.py` imports `app.engine` in a clean subprocess and diffs
`sys.modules`, which is transitive by construction, then evaluates the corpus
with `time.time`, `datetime.now`, `random`, `os.environ` and `sys.argv` replaced
by objects that raise. Fourteen snapshots, and the count is printed, because a
guard that reports OK without saying what it examined is indistinguishable from
one that examined nothing.

Injected into `dsl.resolve` rather than into a new function, deliberately: an
import inside a function nothing calls cannot make a determination
irreproducible. **One case is still not caught** and the docstring says so
rather than implying otherwise — binding `sys.argv` to a variable and never
using it. `sys` is in every interpreter's baseline and a C module cannot be
given a raising `__getattr__`; *using* the value raises. Five of G-04's six.

**The jurisdiction guard: the audit said all six cases passed and three did.**
`pack_id.startswith("hk")`, `pack_id in ("au", "sg")` and `'A' + 'U'` got
through; the three written in uppercase were caught. Half of that guard worked,
and what did not is the half assuming a regime code would be spelled the way the
pack files spell it.

It parses now, and refuses any two-letter string constant in any case —
including codes for regimes nobody has shipped, which no list could have
contained. Separately it derives every jurisdiction in `packs/` and looks for
each in the engine's AST, so **a fifth pack extends the guard by existing**;
`test_packs.py`'s hand-maintained companion check is retired.

*Worth recording:* `'A' + 'U'` survived my first rewrite too. `ast.literal_eval`
supports `+` only for numbers, so it raises `ValueError` on two string constants
and the case sailed through. Found by writing the mutation test, which is the
argument for mutation tests.

**The tier guard missed all four of G-06's cases.** `tier != "shared"` is the
same branch as `== "dedicated"` written the other way round, and the guard
looked only for the literal. `count = local.is_dedicated ? 1 : 0` mentions
neither `var.tenancy` nor a tier name — the fork is one name away, in the
`locals` block, which is exactly where a grep stops looking.

`scripts/tier_divergence.py` taints every local that depends on `var.tenancy`,
transitively to a fixed point, and refuses any `count`/`for_each` reaching one.
A tainted local that gates nothing is allowed, with its own test: a guard that
refused it would be one people route around, and the next thing they route
around is a `count`.

**The region guard exited 0 on a missing directory** with "nothing to check",
while its own header said an absent target is a failure. And it scanned
`infra/` only, so it never saw the one that mattered:
`models.py:225`'s `region` default. **A European customer created through the
API was recorded as Sydney-resident by a keyword argument** — a data-residency
answer given silently. The column is required now, and five tests that created
tenants without one were updated, which is the change making itself visible.

*Where the prompt was wrong:* it cites `models.py:178`; on this tree it is line
225.

**The passcode guard scanned eleven hand-typed directories**, and the two it did
not name were `web/public` and `web/e2e`. Widening it to the tree found
something better than either: **`.env.example` still told whoever set up a
deployment to invent a shared passcode**, thirteen stages after Stage 2 deleted
the code path. Nothing read the variable; what it did was instruct, in the file
everybody copies first.

**Three test defects, and a deletion.**

`test_audit_chain.py` skipped when every tenant had an anchor and
`test_a_rechain_is_itself_evidenced.py` skipped when no rechain was on file —
so both vanished on a fully migrated database, which is what a deployment is.
Each manufactures its dangerous state now, inside a transaction that is rolled
back. `test_the_unreviewed_permit_is_not_application_writable.py` committed
without reading the value back, asserting that a write did not *raise* rather
than that it landed; it reads through a second session and restores the value,
because `advance_policy` decides which pack governs the demo firm and leaving it
flipped would move determinations in other files.

`test_rls.py`'s twenty-odd `skipif(not TENANCY_LANDED)` marks are kept and given
one test of their own. The gate was correct when Stage 1 was being built; its
failure mode is that the entire isolation suite disappears into "20 skipped",
which nobody reads in a run of sixteen hundred.

`test_guards_cannot_be_vacuous.py` is deleted. Reachability is a real property
and a much weaker one than refusing a violation — and G-04 through G-07 are four
guards that were reachable, ran, printed OK, and had nothing behind them.

**Suite after Tier 2: 1551 passed, 11 skipped. 39 mutation cases.**

---

### 2026-08-27 — Fix-pack 3 (merged audits), Tier 1: FIXED entries that were not

Five findings, and the thing they have in common is that `spec-changes.md` said
each was done. Every one reproduced.

| Ref | Finding | Status |
|-----|---------|--------|
| FP3-06 | `Pack.is_production_grade` has no caller | FIXED |
| FP3-07 | `replay` compares less than the F10 entry says | FIXED |
| FP3-08 | `pack.staged` / `pack.published` reach only the publisher's tenant | FIXED |
| FP3-09 | The three tests that stand in for behaviour | FIXED |
| FP3-10 | Append-only assertions cover 4 of 13 tables; `chain_rechains` has no revoke | FIXED |

**FP3-06.** Zero callers. The entry said it "answers the loader's question";
`packs_repo._usable` compared `content_status == REVIEWED` and stopped there, so
the "three layers" were two. The missing half is the one a status column cannot
express — a pack can be `REVIEWED` and signed by `[unsigned]`. The database
refused that pairing, so it was never exploitable through a normal write path;
what it meant is that the application had no opinion and one `DROP CONSTRAINT`
stood between a firm and unsigned content. `_usable` calls
`Pack.from_body(row.body).is_production_grade` now.

*Two mistakes writing the test, both instructive.* It committed the sacrificial
row and tried to re-add the CHECK afterwards — which Postgres refuses, because
the committed row violates it, and `packs` is append-only so the row could not
be deleted either. That left the constraint off the development database and a
bad row in `packs`; both were repaired by hand with the owner-only
disable-trigger pattern, and the test now does everything in one transaction it
rolls back. Then it used the demo firm, which holds
`illustrative_content_permitted` — so `_may_use_unreviewed` returned before any
filtering and the refusal never fired. **It would have passed against the
unfixed code.** It uses `reviewed-probe`, a firm that is acting and holds no
permit.

**FP3-07.** `evidence.record` stores `results` and `not_applicable`; `replay`
read the first and never touched the second. F10's justification — "compared
field-by-field by `evidence.replay`" — was false about the very list it argued
from. What that missed is real: a rule whose applicability moves changes *which*
rules ran without changing the outcome of the ones that did, so replay
reproduced the outcome, reported nothing, and the determination on file went on
saying a rule was out of scope while today's content says it is in.

Checked before changing anything, as the standing rule requires: **all 6457
seeded decisions replay with no mismatch**, and `make nightly-replay
ARGS=--inject` still catches a forced outcome. Nothing on file moved.

Compared as a **set**, not a list — the stored value is built by walking the
pack's rules in order, and a pack edit reordering two unchanged rules would
otherwise be reported as tampering. Absent is not a difference either, so
determinations predating F10 do not become a tampering alert across a customer's
whole history. Both false claims in this document are corrected in place above,
with dated notes rather than deletions.

**FP3-08.** Both events went through `webhooks.endpoints_for`, an RLS-scoped
query, inside the publisher's own tenant transaction. Packs are global;
`quolin_operator` is Quolin's own role granted inside a tenant. So the only firm
that could ever receive `pack.staged` or `pack.published` was whichever tenant
the publisher happened to be acting in — **which is not a customer**. §S4's
staged-pack notice and §S5's "tenants notified" gate had never fired for
anybody, and it was missed for the reason `source.stale` was: the producer
exists, is called, and writes rows, so nothing reads as unwired.

Same two-step as FP3-03: the endpoints record a `pack_events` row, the worker
that can enumerate firms fans it out per regime. The API could not do it itself
even if it should — FP3-04 removed its owner connection.

**A separate table from `source_breaches`, and not for tidiness.** One table
with an `event` column would serve both, and the watch role holds INSERT on
`source_breaches` — so a shared table would let a compromised sweep announce a
publication that never happened to every customer on the platform. There is a
test asserting the watch role is refused.

**FP3-09.** Four tests, and `api/tests/test_no_test_reads_source.py` so Rule A
is mechanical rather than intentional. The `report_c` one is the sharpest
example: `assert "WatchSessionLocal" in sweep` stayed green while the sweep grew
calls opening both the application *and* the owner engine, because the string
was still in the file. The profile-change one asserted `"on_pack_effective" in
settle_packs.read_text()`, and that module's own comment "See
`bulk.on_pack_effective`." sits four lines above the call.

Rule A walks `api/tests/` with `ast` and fails on any `read_text(`/`getsource(`
aimed at `api/app/` or `scripts/`. Eight allow-list entries, each with a reason,
in two kinds: tests that read source in order to **change** it and then assert
on what the changed thing did, and tests doing static analysis where the code's
shape **is** the claim — the engine's import graph, jurisdiction constants, no
float division in `calcs.py`. Those are what the guards themselves do. The
banned third kind is on neither list: grepping for a name to prove a call
happens. The ceiling is expected to fall in Tier 2.

**FP3-10.** Both parametrised tests listed four names against thirteen protected
tables. The `chain_rechains` revoke landed with FP3-01, which is where the new
guard found it — and found it in a place no source-reading guard could have: the
grant arrived from 0001's `ALTER DEFAULT PRIVILEGES`, not from any `GRANT`
statement anybody wrote.

Widening the parametrisation turned a silent gap into five red tests, because
five of the thirteen tables are empty in a fresh seed. "The condition under test
is absent" is neither a reason to skip nor a reason to fail: a disposable row is
built from `information_schema` inside a rolled-back transaction, foreign keys
satisfied from real parents. `UPDATE t SET id = id` also assumed every table has
an `id` — `chain_anchors` is keyed on `tenant_id` — so the primary key is
discovered now.

**`artefacts` took three attempts, and the first two were guesses.** Append-only
first: sixteen tests went red, because `renderer.py` re-renders an existing
document and updates the row, which is §S7's design. `content_hash`
unconditionally write-once second: still wrong, because a return regenerated
after more determinations land in its window legitimately has different bytes.
Reading `renderer.py` rather than guessing again, the rule is that the hash may
not change **when the inputs did not** — §S7's determinism gate, resting on one
application-level `if`. Migration 0041 gives it the second lock. So the model
list and the schema were right and the linter's regex was wrong, and
`test_artefacts_is_deliberately_not_append_only` states that as an assertion,
because a comment recording a decision is a comment somebody deletes.

**Suite after Tier 1: 1542 passed, 12 skipped.**

---

### 2026-08-27 — Fix-pack 3 (merged audits), Tier 0: five criticals

Three independent audits of tree `04dcd63c`, merged and triaged. Tier 0 is the
set that means the system cannot be deployed as described. Every one reproduced.

| Ref | Finding | Status |
|-----|---------|--------|
| FP3-01 | The migration linter cannot read alembic | FIXED |
| FP3-02 | The only rate limit is keyed on an attacker-supplied header | FIXED |
| FP3-03 | The `source.stale` fix cannot run in the deployed watch task | FIXED |
| FP3-04 | The request-serving API task holds the schema-owner DSN | FIXED |
| FP3-05 | Every business date is the container's UTC calendar date | FIXED |

**FP3-01 — the linter was reading source text about a database.** Reproduced by
execution: seven injected violations, every one written the way alembic writes
it, all exited 0. `op.drop_column("decisions", "prev_hash")` because the grep
wanted the SQL spelling `drop column`; a multi-line `GRANT UPDATE,\n DELETE`
because SQL does not care about lines; `CREATE OR REPLACE FUNCTION
quolin_append_only() ... RETURN NEW`, which leaves every trigger object in place
and removes what they do; and write grants on any of the eight append-only
tables missing from a five-name regex typed by hand against a set that has since
grown to thirteen.

It applies migrations to a scratch database now and reads the catalog back —
grants, triggers, trigger-function body digests, column types, chain columns,
policies, FORCE and ENABLE row security, table ownership, `rolbypassrls` — then
runs each downgrade and diffs it the same way.

Three things that found, which no amount of better regex would have:

* **0026's downgrade dropped both audit-chain columns.** The decision recorded
  here: it refuses now rather than being allow-listed. Twelve migrations in this
  tree already decline to reverse for the same class of reason, so refusing is
  the repository's existing idiom rather than a new one invented for this.
* **0003's downgrade dropped every tenant-isolation policy** and disabled
  row-level security on every tenant-scoped table. *Nobody reported this one.*
  It was found on the run written to catch 0026, which is the argument for the
  approach rather than for the finding: a guard that asserts the deployed fact
  finds what nobody thought to list.
* **`quolin_app` held UPDATE and DELETE on `chain_rechains`** — the table
  recording who rewrote a firm's evidence hashes. No migration granted it. It
  arrived from 0001's `ALTER DEFAULT PRIVILEGES`, which grants all four on every
  table created after it and revokes them on the append-only ones *by name*;
  0034 added the table, wrote `GRANT SELECT` believing that narrowed something,
  and was never added to the revoke list. **No line of SQL anywhere in the tree
  says so — only the catalog does.** Migration 0036 revokes it.

That last one is FP3-10's schema half, landed here because the guard cannot be
green on its own tree without it. Tier 1 does the rest of FP3-10.

`models.APPEND_ONLY_TABLES` claimed eleven tables against a database enforcing
thirteen; `auth_attempts` and `source_verifications` are added, and the linter
fails if the constant and the triggers ever disagree again.

*Two things worth recording about writing it.* The first downgrade walk stopped
at the first irreversible migration and reported "35 upgrade and 1 downgrade
steps" — the guard rewritten for a counter-example it still could not reach. It
rebuilds around each barrier now. And the `BYPASSRLS` mutation case altered the
real cluster roles, because roles are cluster-scoped and a scratch *database*
does not contain them: the test proving the guard catches the change made the
change. The linter captures and restores those attributes and says when it had
to, and the entry point carries a warning never to point it at production.

**FP3-02 — the rate limit bucket was the caller's to choose.** `_client_ip` took
`X-Forwarded-For.split(",")[0]`, and its docstring said that was "the position
the edge appends the real client at". A proxy *appends*: the real client is
last. Reproduced in the shape an ALB produces — eight failed sign-ins with no
header reached 429, thirty with a rotating `X-Forwarded-For: 10.0.0.<n>, <real
address>` reached nothing at all, and `auth_attempts` recorded thirty distinct
attacker-chosen addresses. **Zero tests in the suite sent that header**, which
is why it survived two fix-packs: every rate-limit test used the default client
address, where the code was correct.

Nothing parses the header now. uvicorn runs with `--proxy-headers
--forwarded-allow-ips` set from `var.vpc_cidr` in the task definition and read
by the Dockerfile's CMD — one value, two readers. **`'*'` is not a laxer setting,
it is the defect**: uvicorn's own `get_trusted_client_address` returns the first
forwarded entry when every proxy is trusted, and there is a test asserting that
against uvicorn's middleware rather than against our configuration.

`main` and `v1` each held their own copy of the parsing, wrong the same way;
both use `app/client_address.py`. Per-account and per-second-factor counters
were added, because resolving the address stops an attacker *choosing* it and
does nothing about a spray from a botnet — five for codes against twelve for
passwords, since six digits in one live window is a smaller space and a wrong
code means the password has already leaked. The raw header is kept in its own
column, named so nothing reads it as provenance, and **not backfilled**: there
is no way to tell which old rows were honest, and copying them across would
manufacture the provenance this removes.

**FP3-03 — the `source.stale` producer could not run where it was deployed.**
The 27 August sweep wired it as `notify_tenants(all_tenant_ids(), breaches)`
inside `scripts/watch_tick.py`. `all_tenant_ids` opens the owner connection and
`notify_tenants` opens the application connection; the watch ECS task holds
`WATCH_DATABASE_URL` alone and guard check 6 *fails the build* if it is given
either of the others. Both fell back to `db.py`'s hardcoded `localhost:5433`, so
the sweep raised on every run with a source in breach — and `all_tenant_ids()`
is an *argument*, so it was evaluated whether or not anything was stale.

Proved by instrumenting `engine.connect` rather than by reading the file: the
old call opens `owner_engine`, the new sweep opens `watch_engine` and nothing
else.

The separation is Stage 6 and is not something to widen for a notification. The
sweep writes `source_breaches` with the credential it has; `health_alerts.py`,
which already holds the application role and already enumerates firms through
`maintenance`, fans out. `source_breach_notices` carries the idempotency in the
schema, and the watch role is refused INSERT on it — a compromised sweep must
not be able to mark every breach as already told. `all_tenant_ids` had the exact
Q-01 shape, no `assert_can_enumerate` and no `NoActiveTenants`, and now delegates
to `maintenance`.

Three test defects went with it. The `read_text()` wiring assertion is gone. The
subprocess test that ran the real script passed `{**os.environ, ...}` — every
connection string on the machine — and now uses the deployed set, parsed from
`infra/compute.tf` by `scripts/task_environment.py`, one place CI and the suite
share. And `_a_source` set `enabled` but never `alerted_at`, so a row left paged
by an earlier run made the paging test fail on the *first* page; found by
running the sweep by hand while reproducing this.

*Worth stating, because it bounds a claim:* a replay sweep cannot produce a real
breach — `sources.sync` disables any source no pack declares, and every declared
one is re-checked and reset on each replay run. So the assertion that the sweep
writes the breach row lives in the one test that produces a genuine connection
failure, against a dead proxy.

**FP3-04 — the owner connection sat in the process an attacker reaches first.**
`DATABASE_URL` owns every table and every append-only trigger, is exempt from
FORCE row-level security, and is what `rechain.py` uses to rewrite evidence
hashes. Inside `api/app` it had two users: a test helper and one watch-path
enumerator FP3-03 moved out. The container runs no migration at start.

The comment justifying it — "without this the API would fall back to the owner
connection" — was wrong twice: the variable *is* the owner connection, and what
`db.py` falls back to is a hardcoded localhost.

Removed. Both helpers moved into `app/owner_only.py`, which raises `ImportError`
while loading if `DATABASE_URL` was not supplied. `db.py` keeps its dev default
— `owner_engine` is built at module scope and bound by three `event.listens_for`
decorators, so making it lazy would be a large change to the transaction
machinery for a check that belongs somewhere narrower — but now records
`OWNER_URL_IS_A_GUESS` and says what that default cost.

**Closes audit G-02.** Check 5 of `guard_no_watch_in_engine.sh` was `awk` scoped
to a literal resource name: renaming `aws_ecs_task_definition "watch"` made the
range empty and an empty range was a pass; the health and comparison tasks
matched no range at all and were checked by nothing. Worse, it was a *deny*-list
— it refused the credentials somebody had already thought of, and
`DATABASE_URL` in the API task was on nobody's list. `guard_task_credentials.sh`
is an allow-list keyed on each container's **command**, so a rename changes
nothing about what is checked. Stdlib-only and plain `python3`, so it runs in
the infra CI job that owns the other infrastructure checks.

**FP3-05 — every business date was the container's calendar day.** Q-03 fixed
the timestamps and they are right. The business date was never asked about.
Reproduced at 2026-08-27T23:30Z — 09:30 on the 28th in Sydney: a Sydney operator
asking for a determination `as_of` their today was refused
`as_of_in_the_future`, the console default recorded yesterday, and a pack
effective on the 28th did not begin governing that firm until 10:00 local.

`tenants.business_timezone`, backfilled `Australia/Sydney` — confirmed against
the data rather than the brief, since all fifteen seeded tenants are
`ap-southeast-2`. A column rather than a key in `config`, because `quolin_app`
holds `UPDATE (config)` and moving this retrospectively would change which pack
version governed a day's determinations. One `business_today(session)`, a
separately-named `platform_today()` for work that is nobody's in particular, all
34 call sites converted, and `guard_no_naive_today.sh`.

**CI now runs the suite twice, `TZ=UTC` and `TZ=Australia/Sydney`, and it earned
its place on the first run.** It found two sites the guard had missed, both
spelling a business date as `datetime.now(timezone.utc).date()`:
`verify_manually` told a Sydney specialist recording this morning's check that
the date was in the future, and `adoption.onboarding` subtracted a date-string
from a timestamp, so the same seven weeks read as 49 days or 48 depending on the
hour the stage change landed. The guard covers that spelling now.

Four tests were updated because their assertions encoded the defect: they took
"today" from the runner's clock while the application took it from the same
wrong place, so nothing disagreed. Each records the superseded reasoning in
place. **No seeded decision's stored `as_of` changes** — `evidence.replay` reads
no clock and nothing here rewrites a row; asserted rather than argued.

*Where this prompt was wrong, and one error of mine.* The brief said the region
default lives at `models.py:178`; it is line 209 on this tree. And the first
version of the FP3-05 test used London for the westward contrast — London is
UTC+1 in August, so it is already the 28th there too. The test refused it, the
assertion was wrong rather than the code, and the probe is New York. Worth
leaving written down: "UTC and London are the same date" is exactly the
assumption a guard against timezone errors should not rest on.

**Suite after Tier 0: 1399 passed, 4 skipped, under both `TZ=UTC` and
`TZ=Australia/Sydney`.** All guards green, including the two new ones.

---

### 2026-08-27 — Review against the execution document, and a dead-code sweep

A full read of the repository against `quolin-prototype-to-product.html`, plus a
sweep for code that stages left behind. Three things were built and never
connected, one invariant was true but unenforced, and five things were dead.

**What is built.** Every stage S0–S13 has code, tests and a wired CI gate, and
the test suite maps onto the stage list almost file for file. Spot-checked
against the gates rather than the prose: the RLS suite, per-tenant chains and
per-tenant keys (S1); SSO/OIDC, MFA, RBAC, SoD, access review and the deleted
shared passcode with a guard proving it (S2); the DSL spec, `dsl_version`, calcs
registry, property suite, a 14-case golden corpus, fuzz and benchmarks and the
nightly replay (S3); `/v1` with OAuth2, idempotency, cursor pagination,
published OpenAPI and Postman, webhooks, the batch gateway and versioned
mappings (S4); the full draft lifecycle, workbench, signing with content hash
and advance policy (S5); watch on its own DB role with the guard to prove it,
and the LLM boundary document (S6); the artefact worker and returns (S7); bulk
and delta reports (S8); logging, alerting, backups, restore drill, blue-green,
five runbooks and a status page (S9); the adoption ladder and comparison reports
(S10); the dedicated tier from the same Terraform (S11); the load model and load
test (S12); the hardening artefacts and evidence room (S13).

**Three things were written, documented, tested and never called.** This is one
pattern, and it is the same one F1 was:

* `bulk.on_profile_change` — §S8 names three triggers that re-check a book.
  `on_pack_effective` and `periodic_review` are wired into
  `scripts/settle_packs.py`. The third had no caller anywhere. Now fires from
  `v1.upsert_client`, gated on the decision-relevant diff so a nightly re-send
  of an unchanged book plans nothing.
* `source_alerts.notify_tenants` and `all_tenant_ids` — `source.stale` is
  declared in `webhooks.EVENTS`, subscribable, and named in §S4's webhook list.
  Its producer existed and nothing called it, so a customer could subscribe and
  never be told. Now fires from `scripts/watch_tick.py`, which was already
  computing the breaches and telling only the specialist owner.
* Invariant 2's enforcement — §3.1 names an `import-linter` contract forbidding
  DB/network/clock imports in `engine/`. The engine is clean; nothing checked
  it. `scripts/guard_engine_is_pure.sh` now does, and the Audit Gate's "a CI
  test that fails when violated" is satisfied for all seven invariants.

**Five things were dead and are gone.** `_dry_run_sender` (superseded by an
inline `--dry-run`), `models.append_only_trigger` (migrations write the SQL
directly), three unused web exports, and `scripts/add_watch_blocks.py` (a
one-shot whose output is committed content).

**Two things that look dead and are not**, recorded so the next sweep does not
remove them: `evidence._forget_chain_state` is a `@sa_event.listens_for`
listener that clears per-transaction chain state — invisible to both vulture and
grep, and deleting it would corrupt the audit chain. `crypto.forget_keys` and
`auth._reset_rate_limit_for_tests` have no production callers and are cache
invalidation a real operator needs; only tests exercise them today.

**Known gaps against the document, unchanged and declared.** Custody read
adapters (§S4 asks for two; only `FixturePositionsProvider` exists, and
`/integrations` labels it honestly as awaiting replacement) and SAML (§S2 wants
the capability present; only OIDC is built). Both are content for the vendor
decision rather than missing engineering, and neither is a silent gap — the
integrations screen states the first one to anybody who looks.

**The CSV importer now fires it too**, after the granularity question was
answered: one run over the changed subset, not one per row. A firm re-loading a
book of nine thousand where forty moved wants a single re-check of forty, and
forty runs would be forty rows somebody has to open to discover they are all the
same import.

`bulk.on_profiles_changed` is the plural form and `on_profile_change` is now it
with a list of one, so both write paths mean the same thing rather than being
two call sites that drift. The trigger condition is identical on both — the
before/after diff over the columns the engine reads — so an unchanged re-import
plans nothing, and the import's audit row gained a count of how many rows moved
a decision-relevant fact.

Planned before the commit, inside the import's own transaction. The endpoint's
promise is all-or-nothing, and a run planned for rows a later failure rolled back
would be a re-check of a state that never existed. Tested: a preview
(`commit=false`) plans nothing, and a file refused for a bad row plans nothing.

---

### 2026-08-27 — The smoke test and a code that was already spent

The second CI round on the same step, and the cause was a control working
exactly as designed.

A TOTP code is one-time *per time step*: `identity.check_second_factor` records
the step it accepted and `totp.verify` refuses anything at or below it. A code
read over somebody's shoulder is spent, which is the point.

In CI the whole pytest suite signs in as the seeded operator immediately before
the smoke step, dozens of times, and the last of those leaves the current step
spent. The smoke step then computes a code for that same thirty-second window
and is refused — which reads as a broken deployment and is not one. Locally it
passed because the run was preceded by a re-seed, and a fresh credential has
`last_used_counter` at zero.

`sign_in` now waits for the next step and tries once more. Bounded by
construction — one step is thirty seconds — and it is what a person does when
their authenticator is showing a code they have just used. Reproduced locally by
running the suite and the smoke step back to back the way CI does: refused
before, and afterwards the run takes ten seconds and passes, the extra time
being the wait.

**And the failure said nothing.** `POST /auth/login as … returned 401` was the
entire report, so a status that meant "that code was already spent" was
indistinguishable from one that meant "those details are wrong" — which is what
cost the round trip. The note now carries the server's own sentence. A smoke test
that reports a status and withholds the reason is one somebody has to reproduce
by hand.

---

### 2026-08-27 — No privileged account could sign in through the web client

Found by CI, chasing the offline regression, and it is the most serious thing in
this pack. It is **product code, not a test**, and it predates fix-pack 3.

`POST /auth/login` answers `401` with `X-Quolin-MFA: required` when an account
owes a second factor. `web/lib/api.ts` branches on exactly that header to throw
`MfaRequired`, which is what makes `AuthGate` reveal the six-digit field instead
of rendering a failure. The engine cannot say sooner that an account has a
factor without becoming an account-enumeration oracle, so **that header is the
mechanism**, not a hint about it.

`CORSMiddleware` was configured with `allow_origins`, `allow_credentials`,
`allow_methods` and `allow_headers`, and **no `expose_headers`**. Only the
CORS-safelisted response headers are readable by cross-origin JavaScript;
everything else comes back `null`. The web client and the engine are different
sites — that is the whole reason the session cookie is `SameSite=None` — and it
is true in development too, where the client is on :3000 and the engine on :8000.

So the branch never fired anywhere. What a privileged person actually saw:
"Enter the six-digit code from your authenticator app." rendered as an **error**,
their password cleared, and no field to type a code into. Every one of
`approver`, `pack_signatory`, `tenant_admin` and `quolin_support` was locked out
of the user interface, on every deployment, since second factors were enforced.

**Why nothing caught it.** Every role that required a factor is one the browser
suite never signs in as. The offline regression signs in as the operator, and
the operator had no factor — until F8 gave them one, at which point the only
browser test in the repository walked straight into it. The API suite could not
see it either: `TestClient` reads response headers directly, because it is not a
browser and has no same-origin policy to enforce. **A test that is not a browser
cannot find a bug that only browsers have.**

Fixed by exposing the headers this API sends as signals to the client:
`X-Quolin-MFA`, `X-Quolin-Reauth` — the same mechanism for credential freshness,
listed before a client reads it rather than after — and `X-Quolin-Request-Id`,
which every response carries and which the error messages tell people to quote
to support.

Asserted at the response a browser receives rather than against the middleware's
arguments, because a list that is configured and a header that arrives are
different claims and only the second one matters. A companion test walks both
steps of the sign-in in order, since a readable header is worth nothing if the
code that follows it is refused.

**Verified in a real browser**, because that is the only place this bug exists:
Chrome against the dev servers, service worker cleared. `fetch` now reports
`x-quolin-mfa: required` among its readable headers; the form reveals the
six-digit field with no error; entering a generated code signs in; and the
dashboard renders `Chain verified · 45 records` — the exact string the offline
spec asserts.

---

### 2026-08-27 — Fix-pack 3: F8's blast radius, found by CI

Two checks failed on the pull request, and both were the same defect of mine.

**F8 was right; two automated callers had not been told.** Adding `operator` to
`MFA_REQUIRED_ROLES` means the seed enrols an authenticator for the demo
operator, and a password-only sign-in as that person is refused 401 with
`X-Quolin-MFA: required`. That refusal is the control working. What was missing
was any way for the two automated paths that sign in *as that person* to do what
a real operator now does:

* `scripts/smoke.py` — `[FAIL] a named person can sign in … returned 401`, so the
  three taps never ran.
* `web/e2e/offline.spec.ts` — the form asked for a code, the spec never filled
  one, and the dashboard's `Chain verified` badge never appeared.

Neither is product code. The web client already handles the second factor
properly — `AuthGate` reveals the code field on `MfaRequired` — and the engine's
behaviour is correct in both cases.

**Why the local run did not catch it.** Neither path is in `pytest`. The smoke
step needs a live server on :8010 and the offline spec needs a built Next app
and a real browser, and the pack was verified with `pytest`, the guards, and
`make nightly-replay`. That is the same shape of mistake this whole pack is
about — verifying the mechanism that changed rather than the path a caller
travels — one level out, in the tooling rather than the product. Both are now
run locally before pushing.

**What changed.** `smoke.py` grows `totp_now` and a second sign-in attempt,
mirroring the web client: no code on the first request, because whether an
account holds a factor is only knowable after the password checks out — an
endpoint that answered sooner would be an account-enumeration oracle. A missing
secret is reported as "set `QUOLIN_SMOKE_TOTP_SECRET`" rather than as a bare 401,
because a tool that was not given a factor and a broken deployment have entirely
different first moves. The secret is read from the environment, since a factor
belongs to a deployment and not to a file in this repository; CI passes the
seeded operator's, which the seed derives deterministically from the address.

`servers.ts` grows the same arithmetic in TypeScript, deriving the secret from
the operator's address rather than pasting a literal, so changing that address
cannot leave a stale constant behind.

**A second implementation of RFC 6238, and a test that they agree.**
`scripts/smoke.py` is standard-library-only on purpose — it runs from a laptop
against a stack that has just come up — so it cannot import `app.totp`. Two
implementations that must agree forever drift silently, and the failure mode is a
smoke test refused at sign-in against a perfectly healthy deployment. They are
checked against each other at fixed instants, so the assertion does not depend on
which side of a thirty-second boundary the suite runs on. Writing that test found
a real bug in the new helper: it re-padded an already-padded base32 secret and
raised `binascii.Error` instead of returning a code.

**One race of my own, caught by reading rather than by running.** The first
version of the e2e branch asked `isVisible()` immediately after the click.
`isVisible()` answers straight away, so on a slow paint it would report false,
the code step would be skipped, and the failure would look exactly like the one
being fixed. It waits for whichever of the code field or the dashboard badge
arrives first, then branches.

**Not verified locally, and stated rather than glossed:** the offline spec itself.
Playwright's browser download extracts an incomplete bundle in this environment —
repeatedly, across clean retries — so the DOM interaction is the one piece CI
verified rather than this machine. What *was* verified here: TypeScript
typechecks; the TS and Python code generators agree with `app.totp` at fixed
instants; the two-step login was walked against a live server over HTTP (401 with
`x-quolin-mfa: required`, then 200 with a code); and the spec's locators were
checked against `AuthGate.tsx` — the label reads exactly "Six-digit code" and the
submit button keeps its "Sign in" name.

---

### 2026-08-27 — Fix-pack 3: every finding, and the caller audit

**Status of every finding in the pack.**

| Ref | Finding | Status |
|-----|---------|--------|
| CI | `scan-secrets` false positive on an interpolated probe URL | FIXED |
| F1 | Pinned advance policy never reached the evaluator | FIXED |
| F2 | Non-browser integrations refused at the token endpoint | FIXED |
| F3 | Cross-border replay order-dependent | FIXED |
| F4 / F-02 | Publish did not verify the signed content hash | FIXED |
| F4 residual | Signed hash not rebuildable from the published pack | DEFERRED — decision 4 |
| F-03 | Malformed packs crashed before validation | FIXED |
| F-04 | Evidence artefact naming raceable | FIXED |
| F5 | `clients.id` existence oracle — cause disclosure | FIXED |
| F5 | `clients.id` composite key and squatting denial | DEFERRED — decision 2 |
| F6 | Null fact → 500 blaming the pack | FIXED (handling half) |
| F6 | Null-fact semantics | DEFERRED — decision 3 |
| F7 | `as_of` caller-controlled and unbounded | FIXED |
| F8 | `operator` exempt from MFA | FIXED |
| F9 | Client fact rewrites left no before-values | FIXED |
| F10 | Applicability not recorded | FIXED (engine half) |
| F10 | Zero applicable rules yield ALLOW | DEFERRED — decision 5 |
| F11 | `_may_use_unreviewed` failed open | FIXED |
| F12 | `lint_migrations.sh` could pass vacuously | FIXED |
| F12 | `pg_has_role` preflight in `health_alerts` | FIXED |
| — | Jinja2 `SandboxedEnvironment` | FIXED |
| — | Author ≠ signatory | DEFERRED — decision 1 |
| — | Illustrative pack loader in `bulk.py` | NOT PRESENT |

**Caller audit.** Every function, method and column added or changed, with its
production call sites. Nothing in this pack has zero.

| Added or changed | Production callers |
|------------------|--------------------|
| `advance.taken_versions` | `packs_repo.active_all`; `advance.effective_version_for` |
| `advance.newest_taken` | `packs_repo.active_all`; `advance.effective_version_for` |
| `advance.effective_version_for` (was uncalled — this is F1) | `packs_repo._pin_for` ← `packs_repo.active` |
| `packs_repo._pinned_row` | `packs_repo.active`; `packs_repo.active_all` |
| `packs_repo._pin_for` | `packs_repo.active` |
| `packs_repo._may_use_unreviewed` (changed) | `packs_repo._usable`; `packs_repo.active_all` |
| `main._refuse_cross_site` (changed) | `main.require_session` middleware |
| `evidence._replay_order` | `evidence.replay` ← `service.replay`, `scripts/nightly_replay.py` |
| `drafts.SignedBytesChanged` | raised in `drafts.publish`; caught in `main.publish_draft` |
| `pack_publications.signed_content_hash` | written by `drafts.publish`; migration 0035 |
| `Pack.from_body` (changed) | `packs_repo` ×5, `main` ×3, `service`, `evidence`, seed |
| `evidence_io._claim` | `evidence_io.write` ← 11 scripts |
| `v1.CLIENT_REFUSED` | `v1.upsert_client`; `main.import_clients` |
| `v1.unusable_facts` | `v1.request_evaluation`; `main.evaluate` |
| `v1.check_as_of` | `v1.request_evaluation`; `main.evaluate` |
| `v1.BACKDATED_ACTION` | `v1.request_evaluation`; `main.evaluate` |
| `v1.as_of_reason` / `EvaluateRequest.as_of_reason` | both evaluate handlers |
| `v1.DECISION_RELEVANT_COLUMNS`, `v1._fact_diff` | `v1.upsert_client` |
| `MFA_REQUIRED_ROLES` (changed) | `mfa.roles_requiring_a_second_factor`, `access_review`, seed |
| `maintenance.holds_the_maintenance_grant` | `maintenance.assert_can_enumerate` |
| `maintenance.assert_can_enumerate` | `scripts/health_alerts.py` |
| `evaluate.APPLICABILITY`, `rule_applies(reads=…)` | `evaluate.evaluate_snapshot` |
| `service._applicability` | `service.decision_view` |
| `renderer._env` (changed to sandboxed) | every artefact render |

---

### 2026-08-27 — Fix-pack 3: where the brief was wrong against the code

Recorded because the brief asked for it, and because each is a place where doing
exactly what was asked would have produced a worse change.

**There is no git repository.** The brief's first deliverable is a branch
`fixpack-3` with one commit per finding. `quolin-main/` is an unpacked tree with
no `.git` at all, so there was no history to branch from and no baseline to diff
against. A repository was initialised, the tree as received committed as
`Baseline: quolin-main tree as received (fix-pack 2 state)`, and `fixpack-3` cut
from it. Every commit below is therefore diffable against that baseline, but the
history before it does not exist — `make scan-secrets ARGS=--history` is
scanning a history one commit deep, which is worth knowing when reading its
"clean" verdict.

**`quolin-review3.patch` was not supplied.** Not in the repository root, not
anywhere in the tree, and not alongside the prompt. Tier 0 and Tier 1 were
implemented from the descriptions, as the brief directs in that case. Nothing
was applied from a patch and nothing was reviewed against one; the reviewer's
claimed 1,182 passed could not be checked.

**The CI failure was not where the job name suggests.** "API — lint, types,
suite, guards" failing reads as lint, types or the suite. All three were green
on the first run — ruff clean, mypy clean on 60 files, 1173 passed and 4 skipped.
The failure was at that job's *fourteenth* step, `make scan-secrets
ARGS=--history`, on a false positive. See the Tier 0 entry.

**The local baseline was red for an unrelated reason, and it was my own fault.**
Twenty-three tests failed on this machine with `cannot load library
'libgobject-2.0-0'` — WeasyPrint's system libraries, which CI installs with
`apt-get` and macOS does not put where `dlopen` looks.

The repository already handles this: the Makefile sets
`DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib` on twelve targets, `test` and
`api` among them, and a previous stage recorded adding it to `make test` for
exactly this symptom. The failures came from running `uv run pytest` directly
instead of `make test`. Recorded as a correction rather than a finding, because
the first version of this note read as though the gap were in the repository.

One genuine wrinkle, since it cost time later: `nohup` strips `DYLD_*`. It is a
SIP-protected binary, so macOS clears those variables when exec'ing it —
`DYLD_… make api` works and `DYLD_… nohup uv run uvicorn` silently does not,
which looks like an artefact bug rather than a launch method. Use the Makefile
targets.

**F1's brief describes the pin one way and the correct semantics are another.**
It says "a taken version newer than the one in force is not yet effective — the
shelf wins". Read as written and applied to "the newest version taken", that
moves a firm which took v2 and then a future-dated v4 onto **v3**, which they
never looked at — the pin pushing a firm forward, which is the one direction it
must never fail. `advance.newest_taken` ignores anything above the version in
force, so the answer is the newest version the firm has both taken *and* seen
become effective. There is a test for it. This was found by implementing, not by
reading.

**F1's suggested test scenario would have contaminated the suite.** The brief
asks to "insert a v3 effective today" against the demo firm. `packs` is
append-only with no DELETE grant, so a test pack cannot be removed at teardown,
and a regime effective today joins the shelf every other tenant reads —
`test_crossborder.py` asserts today's shelf is exactly `{AU, HK, SG, EU}` and is
right to. The scenario runs in its own regime instead, dated in the past with its
windows closed, which also makes it the honest test of the "read by number
because superseding closed the window" semantic. A test in the new file asserts
neither test regime reaches today's shelf.

**F1's suggested outcome pair does not occur for the reason expected.** A tighter
concentration cap gives `REFER`/`REFER` rather than `ALLOW`/`BLOCK` for a client
custody has never heard of: `FixturePositionsProvider` answers `none_on_file`,
the snapshot carries `custody_known: False`, and the concentration rule has no
reading to compare. Both versions then agree, and a test whose two versions agree
cannot see a pin. The probe clients are given a custody record holding *zero* —
a reading rather than an absence — which is what makes the cap the thing under
test.

**F-03's two reviewers were both right, and the brief's own note is the useful
one.** Confirmed by execution: the classification works for a pack that parses
and fails validation, and never runs for one that fails to parse. Worth
restating because it is the general shape — `validate` takes a `Pack`, so
anything that stops `from_body` succeeding bypasses every classification
downstream of it, including `main.engine_validate`'s 422.

**F5 cannot be described as closing the oracle, and the brief's own scoping says
why.** Catching `IntegrityError` and answering 409 removes the *cause*
disclosure — the 500, the constraint name in the logs, any difference between "a
neighbour holds this" and anything else the database declines. It does not remove
the *availability* signal, because a caller has to be told whether their write
landed. That needs the composite key, which the brief correctly defers. The
change log and a passing test both say so, rather than letting "F5 — FIXED" imply
more than was done.

**F7 named only `api/app/v1.py`.** The console path takes the same `as_of` and
reaches the same evaluator. Fixing only the integration path would have left the
firm's own staff — signed in as named people — holding a dial their integration
no longer has.

**F10's brief asks for applicability to be recorded; recording it in the obvious
place would break every stored decision.** `rules_not_applicable` is stored on
every decision row and compared field-by-field by `evidence.replay`, so widening
it, or adding to any per-rule `inputs_read`, makes every determination on file
fail to reproduce — which the chain-mismatch runbook says to treat as tampering.
It is a new top-level key that `evidence.record` does not read, recomputed by the
view from the frozen snapshot.

> **Corrected 2026-08-27 (FP3-07).** The sentence above is wrong where it says
> `rules_not_applicable` was "compared field-by-field by `evidence.replay`". It
> was stored and **not** compared: `replay` read `rule_results["results"]` and
> never touched `rule_results["not_applicable"]`. The conclusion the sentence
> supports — do not widen the stored list — still holds and was still the right
> call, but it was argued from a comparison that was not happening.
>
> The comparison exists now, as a set rather than a list, so a pack edit that
> reorders two unchanged rules is not reported as tampering. Checked before
> changing anything, as the standing rule requires: all 6457 seeded decisions
> replay with no mismatch, and `make nightly-replay ARGS=--inject` still catches
> a forced outcome. Nothing on file moved. The claim is now true.

**F8 and F12 each required updating a test that asserted the opposite,
deliberately and with reasons attached.** Neither was deleted; both were rewritten
to state the superseded reasoning and why it expired. They are named in the Tier 2
entry. This is the category the brief's standing rules are most alert to, so it
is called out rather than buried in a diff.

**One out-of-scope claim was checked once, as directed.** There is no
illustrative pack loader in `api/app/bulk.py` reading `packs/{id}.json` from
disk: that module contains no filesystem access of any kind and reads rule
content only through `packs_repo`. Recorded **NOT PRESENT**. The other five false
claims were not re-checked, as instructed.

**One pre-existing flaky test.**
`test_bulk_evaluation.py::test_the_sweep_rate_is_fast_enough_for_a_hundred_thousand_pairs`
measures ~180 pairs over ~1.2 seconds against a 167 pairs/second budget. It
failed three times across roughly a dozen full-suite runs and passes in isolation
every time, including immediately after each failure. Neither F1 nor F3 touches
the per-pair loop — `active_all` is resolved once per chunk and passed in as
`shelf` — so this is machine noise on a short sample, not a regression. It was
not "fixed", because widening a budget to quieten a test is how a budget stops
meaning anything; it is recorded here so the next person to see it red knows it
is known.

---

### 2026-08-27 — Fix-pack 3: decisions requested

These are recorded rather than implemented. Each is a question the project has
to answer, not a defect a fix pack can settle, and each is written here so it is
visible rather than forgotten.

**1. Pack author/signatory separation.** `drafts.py` permits signing straight
from `DRAFT`, with a comment stating that a signatory authoring their own
content need not hand it to themselves first, and `test_lifecycle.py` asserts
that behaviour. One reviewer reads the plan's Stage 2 as requiring
author ≠ signatory and calls this a critical gap; the code treats it as a
deliberate design choice. The control that exists today is **publisher ≠
signer**, enforced by `SelfReview` and tested. This is a conflict between the
plan and the implementation and has to be resolved by the project. *Nothing was
changed and no test was deleted in this pack.*

**2. The composite client key.** `(tenant_id, id)` on `clients`, with a
composite foreign key from `decisions`. This is what actually closes F5 — both
the residual existence signal and the squatting denial, where a second bank
whose CRM ids collide with an existing customer's cannot load its book at all.
It is DDL on the evidence table and its append-only trigger, and needs its own
migration review. Fix-pack 3 closed only the cause disclosure; see the Tier 1
entry.

**3. What a present-but-null fact means.** `POST /v1/clients` accepts
`knowledge_assessed: true` with `knowledge_date: null`; the CSV importer refuses
exactly that pair. Two ways to close it, and they are different kinds of change:
either a present-but-null field refers as `DATA_MISSING` under DSL v2 (a
semantics change, additive), or `POST /v1/clients` refuses the row as the
importer already does (an API contract change). Fix-pack 3 mapped the resulting
failure to 422 and left the two intake paths disagreeing, with a test asserting
that they still do.

**4. What a signature covers.** The signed content hash cannot be rebuilt from
the published pack, because `publish` overwrites `version`, `signed_by`,
`signed_at` and `content_status`, which the signed body carried as inherited
placeholders. After F4 the two hashes can be *compared*; they cannot be
*recomputed* by a third party holding only the pack. Making it rebuildable
changes what a signature covers and invalidates every `content_hash` on file.

**5. Zero applicable rules.** `worst_of(..., default=ALLOW)` means an asset class
no rule names produces ALLOW. Should it REFER instead? That is a content
question for the specialists rather than an engine change — the engine cannot
know whether silence means "permitted" or "nobody has written this rule yet".
Fix-pack 3 left the default alone and made the applicability visible, so the
question can at least be asked against real determinations.

---

### 2026-08-27 — Fix-pack 3, Tier 2

**F8 — `operator` was exempt from MFA. FIXED.** `MFA_REQUIRED_ROLES` named every
role that *authorises* and missed the one that *records*. An operator evaluates,
imports a book, runs bulk sweeps, generates artefacts and override reports,
ingests comparisons and redelivers webhooks; none of those has a second person on
the path, so a phished password is the whole credential and what it buys is the
ability to mint determinations in a firm's own hash chain under a real name. The
seed already enrols anybody the policy names, so it needed no change — asserted
by a test, because if that stopped being true every operator session in the demo
would be locked and it would look like a bug in the policy.

Two existing tests asserted the old behaviour and were **updated rather than
deleted**, both with the superseded reasoning written down:
`test_an_unprivileged_role_is_untouched` now uses `viewer`, because its job is to
hold the line against the policy widening to everybody and that needs a role
genuinely outside it; and `test_separation_of_duties.py`'s second-factor helpers
were made symmetric. That second one is worth naming: `_give_second_factor` was
already idempotent and returned early when a factor existed, while
`_remove_second_factor` deleted unconditionally. With `operator` privileged the
pair became asymmetric, so the teardown stripped the *seeded* operator's factor
and every later sign-in as that person in the same run landed in a locked
session — the exact cross-test residue that helper's own comment warns about,
with the sign flipped. Four files failed only in a full run and passed alone; it
took a bisect to find.

**F7 — `as_of` was caller-controlled and unbounded. FIXED.** A future date is
refused outright: forward-dating does not select a pack, it rewrites the client,
because `age_years` and `knowledge_assessed_days_ago` are both derived from
`as_of`. A past date is allowed and needs a stated reason, because backdating is
real work — a determination reconstructed for a complaint, a period re-filed —
and what it must not be is anonymous. A distinct audit action,
`v1.evaluation.backdated`, carries the date and the reason.

*Two deviations from the brief, both deliberate.* It asked for the action to be
written when the selected pack is not the one in force; this writes it whenever
`as_of` is in the past, which is a superset — backdating that happens to land on
the same pack still changes the client facts derived from the date, and a rule
that fired only sometimes would be harder to reason about. And it named only
`api/app/v1.py`; the console path takes the same field and reaches the same
evaluator, so it shares the check. Fixing only the integration path would leave
the firm's own staff holding a dial their integration no longer has.

**F9 — client fact rewrites left no before-values. FIXED.** An update wrote one
audit row reading `(updated)`. The before/after for decision-relevant columns now
goes into the audit event's `subject`, which is inside the audit hash chain
migration 0026 added — recorded there rather than beside it, because a record of
the change that is itself editable is the shape of the finding rather than a fix
for it. Only the columns the engine reads: a corrected spelling is not what this
records, and a diff carrying every field would bury the three that move outcomes.
Empty when nothing decision-relevant moved, so a nightly full-book re-send does
not bury the rows that matter.

**F6 — a null fact was a 500 blaming the pack. FIXED, handling half only.**
Reproduced: `POST /evaluate` answered 500 with `'lte' cannot compare None with
730`, naming the rule pack for a record the API itself had accepted. Both
interactive paths now map `PackError` to 422 through one shared message that
points at the client record and keeps the underlying detail after it. The
semantics question is decision 3 above; the two intake paths still disagree,
deliberately, with a test asserting they do.

**F11 — the unreviewed gate failed open. FIXED.** `_may_use_unreviewed` answered
`True` with no tenant bound. The reasoning — no firm in scope means a script or a
screen — is sound and the direction is wrong: an unbound tenant is the absence of
evidence either way, and every caller that decides binds one. It uses
`current_tenant()` now, which raises, as the rest of §S11 does. Screens are
untouched because they never came through it.

**F10 — no applicable rule yields ALLOW. Engine change done; the default left
alone.** `rule_applies` records what it consulted under a distinct
`applicability` provenance kind, and `decision_view` carries it, so a reason card
can show why a rule was in or out. **Additive by construction:**
`rules_not_applicable` is stored on every decision and compared by
`evidence.replay`, so widening it would make every determination on file fail to
reproduce. `evidence.record` reads exactly two keys out of the evaluation, so a
third is invisible to storage and to the chain, and the view recomputes it from
the frozen snapshot. Verified by replaying the seeded book and by
`make nightly-replay ARGS=--inject`: 4679 links, no mismatches. The ALLOW default
is decision 5.

> **Corrected 2026-08-27 (FP3-07).** "compared by `evidence.replay`" was not
> true when this was written — the list was stored and never read back. See the
> longer note against the same claim in the entry above. It is compared now, and
> nothing on file changed as a result.

**Jinja2 sandbox — FIXED.** `renderer._env` is a `SandboxedEnvironment`, keeping
`select_autoescape(["html"])`. Exploitability today is low because every template
ships in this repository — but §S7's stated design is that return formats are
pack content, and `artefact_templates` already lives in the pack body. The day a
template arrives as content, a plain environment turns rule content into code
execution, through the pack workflow, which nobody would review as a security
change. Tests assert the sandbox refuses both halves of the standard `__class__`
walk rather than merely that it is configured.

**F12 hygiene — FIXED, both halves.** `lint_migrations.sh` resolved its default
path relative to the working directory, so from `api/` it looked for
`api/api/migrations`, found nothing, printed "nothing to lint" and exited 0. CI
runs it from the root so it was never wrong there — but a guard whose verdict
depends on where it was invoked passes vacuously somewhere, and this repository
already tests for that category. It resolves from its own location now, and an
absent or empty directory is a failure. The test asserting the old behaviour was
updated with the Stage 0 reasoning that has since expired.

And `maintenance.assert_can_enumerate` is a `pg_has_role` preflight, called by
`health_alerts` before it enumerates. Migration 0029 grants `quolin_maintenance
TO current_user`, which assumes the account running alembic is the account the
workers connect as. That failure was never silent — `NoActiveTenants` already
refuses to let an empty enumeration read as success — but it was *misdiagnosed*:
whoever is paged reads "no active firms were visible" and goes to look at a
`tenants` table that is full. The preflight names the cause and prints the
`GRANT` that fixes it.

Suite after Tier 2: **1298 passed, 4 skipped.**

---

### 2026-08-27 — Fix-pack 3, Tier 1

**F3 — cross-border replay was order-dependent. FIXED.**

`resolve_across` is order-sensitive by construction, and legitimately so:
`rules_not_applicable`, the `binding` and `evaluated_not_binding` lists inside
each dimension, and every rationale sentence are built by walking the
evaluations as they arrive. Recording walked `applicable_codes` order —
licensee, residency, domicile. Replay walked `sorted(stored_others.items())`.

Reproduced before fixing: 2 of the 18 licensee/residency/domicile combinations
over `{HK, SG, DE}` failed to reproduce, with the stored rationale reading
`SG 500; HK 2000; EU 1500` against a replayed `SG 500; EU 1500; HK 2000`. Both
are the case the report named — the residency code sorting after the domicile
code, with the EU pack answering for DE.

The seed's only three-regime client is HK/SG, which sorts the same both ways, so
the corpus, the property suite and the nightly replay were blind to it together.
`docs/runbooks/chain-mismatch.md` says to treat a replay mismatch as a security
incident, so the first three-regime customer would have paged the on-call team
as a tampering event.

The order is re-derived from the frozen snapshot rather than read back, because
`other_jurisdictions` is jsonb and jsonb does not preserve object key order. It
is a function of three frozen facts, matched to packs the way recording matched
them — through `covers_states`. Anything recorded that the codes do not reach is
appended rather than dropped, sorted so the tail is deterministic, which keeps a
missing pack visible as a difference instead of silently skipped.

**No stored decision changed and nothing was rehashed.** A test replays every
seeded cross-border decision and asserts each still reproduces;
`make nightly-replay ARGS=--inject` reports 2423 links verified, no mismatches,
injected mismatch caught.

**F4 / F-02 — publish did not verify the signed content hash. FIXED.**

`sign` recorded `content_hash(draft.body)`; `publish` computed a second hash over
a body it had just mutated and compared it to nothing, taking `status == SIGNED`
as proof the bytes had not moved. `pack_drafts` is mutable working state by
design and `main.edit_draft` refuses on status without taking a row lock, so the
window is real rather than theoretical.

`publish` now raises `SignedBytesChanged`, mapped to 409 beside `NotSigned` and
`SelfReview` and for the same reason: the permissions are right and the draft's
state is not. Checked before the version is allocated, so a refusal burns no
version number and writes nothing.

Migration 0035 adds `pack_publications.signed_content_hash`, nullable, written at
publication. The signed hash previously lived only on the mutable row it was
meant to protect. Not backfilled: every publication already on file has no honest
value, and inventing one would mean writing to rows that table's trigger exists
to protect. The trigger is untouched and the migration linter passes.

**Deliberately NOT fixed, and listed rather than left implied.** The signed hash
still cannot be *rebuilt* from the published pack alone, because `publish`
overwrites `version`, `signed_by`, `signed_at` and `content_status`, which the
signed body carried as inherited placeholders. It can now be compared; it cannot
be recomputed by a third party holding only the pack. Making it rebuildable
changes what a signature covers and invalidates every `content_hash` on file —
decision 4 below. A test asserts the two hashes still differ, so nobody reads
this fix as more than it is.

**F-03 — malformed packs crashed before validation. FIXED.**

`date.fromisoformat`, `int(dsl_version)` and the direct indexing of `pack_id`,
`version`, `thresholds`, `asset_classes` and `rules` all raised raw `ValueError`,
`TypeError`, `KeyError` or `AttributeError`.

**The two reviewers who disagreed about this were both right.** `evidence.replay`
classifies a pack that fails to *validate* as `PACK_INVALID_AT_REPLAY`, counts it
and carries on. A pack that fails to *parse* never reached that classification,
because `validate` takes a `Pack` that `from_body` must already have built. One
reviewer tested a semantically invalid but parseable pack and saw the
classification work; the other tested a structurally malformed one and saw it
bypassed. A stored historical pack with `effective_from="not-a-date"` ended a
nightly replay that had a whole book left to check.

`from_body` validates shape and type before constructing and answers `PackError`
naming the offending field — including for a body that is not a JSON object at
all, which a `jsonb` column can hold and on which every `.get()` raised
`AttributeError`. Two property tests assert nothing else escapes: one over
pack-shaped dictionaries, one over arbitrary JSON. `dsl_version` keeps `int()`
coercion rather than a strict type check, so a pack that has always said `"1"` as
a string goes on loading.

The endpoint half is closed too, which the report named and which is the same
hole one layer up: `main.publish_draft` and `main.edit_draft` both called
`engine_validate(EnginePack.from_body(...))`, so their 422 was unreachable for
exactly the bodies that most needed it and they answered 500 instead.

**F-04 — evidence artefact naming was raceable. FIXED.**

The name was chosen with `.exists()` and then written with `write_text` — a check
followed by a use. A1 closed the sequential collision and left the concurrent
one: two processes both see a name as free, both write it, and the later write
destroys the earlier control's artefact with nothing saying it existed. The
digest check cannot catch it, because the survivor is a complete and correct
artefact of the run that won.

`open(..., "x")` moves the claim into the operating system. Both halves are
claimed together — a pair whose two files came from different runs reads as a
coherent record of something that did not happen, which is worse than a missing
file — and a bounded retry raises rather than spinning.

Reproduced before fixing, and a race so reproduced honestly: twelve concurrent
writers at a fixed timestamp failed intermittently across three runs (lost
artefacts, then a file that would not verify), and pass six runs in a row after.

**F5 — the cross-tenant existence oracle on `clients.id`. FIXED, narrowly, as
scoped.**

Both upsert paths now catch `IntegrityError`, roll back and answer 409 with one
shared message naming no constraint, no table, no tenant and no holder.

**What this closes is the cause disclosure, not the availability signal**, and
the distinction is worth stating because "the oracle is fixed" would overclaim.
A caller can still tell a refused write from an accepted one, because that is
the answer the endpoint exists to give — and under a platform-wide primary key
that still means learning whether an id is in use somewhere. What is gone is the
500, the constraint name in the logs and the error tracker, and any difference
between "another firm holds this" and anything else the database declines.
Closing the rest needs the composite key, which is decision 2 below and is DDL on
the evidence table. A passing test asserts the residual, so that when the
composite key lands it fails and gets deleted.

The squatting denial — a second bank whose CRM ids collide cannot load its book —
is untouched and is the same decision.

**NOT PRESENT.** The remaining claim the brief asked to be checked once: there is
no illustrative pack loader in `api/app/bulk.py` reading `packs/{id}.json` from
disk. That module contains no filesystem access of any kind — no `open`, no
`Path`, no `read_text`, no `.json` — and reads rule content only through
`packs_repo`.

Suite after Tier 1: **1250 passed, 4 skipped.**

---

### 2026-08-27 — Fix-pack 3, Tier 0: the CI failure, and two criticals from fix-pack 2

**The CI failure, first, because remediation on a red baseline cannot tell a new
regression from the existing one.**

`API — lint, types, suite, guards` was failing at its *No credentials committed*
step — `make scan-secrets ARGS=--history`, rung fourteen of that job — and not
at lint, types or the suite. Those three were green: ruff clean, mypy clean on
60 files, 1173 passed and 4 skipped.

The finding was `api/tests/test_worker_tenant_enumeration.py:57`, and it is a
false positive:

```python
return f"postgresql+psycopg://{role}:{PROBE_PASSWORD}@{tail}"
```

The `database URL with a password` pattern carries a negative lookahead
exempting our own development roles by name — `quolin`, `quolin_app`,
`quolin_watch`. The value here is `quolin_probe`, a role that file CREATEs and
DROPs against the local database, so it belongs to that family. The lookahead
never sees it, because the password arrives through an f-string placeholder
rather than as a literal.

Closed through the mechanism `scan_secrets.py` documents for exactly this — an
`ALLOWED` entry with the reason attached — and keyed on the exact interpolation
`{role}:{PROBE_PASSWORD}@` rather than by loosening the pattern. That file's own
instruction is *"Do not widen a pattern to make a finding go away: the next one
will be real."* A real connection string carrying a real password on any other
line still fails the scan. Tree and history both clean afterwards.

**F1 — the pinned advance policy never reached the evaluator. FIXED.**

Verified as reported: `advance.effective_version_for` had zero callers anywhere
in `api/app`. It appeared only in `test_watch_to_uat.py` and `test_lifecycle.py`.

Q-15 landed the write path — notice, advance, decline — and the read path it
feeds was never wired. Every determination read the newest effective pack:
`POST /evaluate`, `POST /v1/evaluations`, the periodic sweep, the
profile-change sweep and the dashboard. Only `on_pack_effective` honoured the
pin, and only as a dry run. A firm that chose `pinned` and was shown a
fourteen-day review window had its live determinations recorded and hash-chained
under a version it had not taken.

The pin is applied where the shelf is assembled — `packs_repo.active` and
`packs_repo.active_all` — so the service, every bulk trigger and the dashboard
read the same version rather than three layers each deciding separately. Three
semantics, each a decision rather than an implementation detail:

* A taken version above the one in force is not yet effective; the shelf wins.
* An older taken version is read by number, because superseding may have closed
  its window and the effective-date query cannot return it.
* A pinned version an acting firm may not use raises `NoReviewedPackAvailable`
  rather than promoting them to the signed version above it.

**One thing was found while implementing that the brief did not describe.** A
firm may be noticed about and take a version *before* its date arrives — that is
what a review window is for. Reading the pin as "the newest version taken" then
moves a firm that took v2 and then a future-dated v4 onto v3, which they never
looked at: the pin pushing a firm forward, which is the one direction it must
never fail. `advance.newest_taken` therefore ignores anything above the version
in force, and the answer is the newest version the firm has both taken and seen
become effective. There is a test for it.

The fix is a no-op until a firm actually takes a version — `tenant_advances` is
empty on a seeded database, so no seeded determination and no stored decision
changes. Nothing was rehashed.

`advance.taken_versions` is the batch form `active_all` reads, one query for the
whole shelf rather than one per regime on the interactive path.
`effective_version_for` delegates to it and is now called by `active()`.

**F2 — every non-browser integration was refused at the token endpoint. FIXED.**

Verified as reported: `_refuse_cross_site` exempted on
`has_bearer and not has_cookie`, which is the same statement as "no cookie" for
every request except the one that matters. `POST /v1/oauth/token` carries no
bearer — it is how a bearer comes to exist — and a server-to-server client sends
no `Origin`. So the request fell past the exemption, failed the origin check and
was refused 403 before its credential was read.

This is Q-17's failure — *no integration could authenticate at all* —
reintroduced one tier up by Q-05, in the same fix pack. Neither
`docs/api/openapi.json` nor the Postman collection mentions an `Origin`
requirement, so nobody building against it would have sent one.

Forgery works through ambient credentials, and a request carrying no session
cookie has none to attach. The check now asks about the cookie directly; the
bearer special case was a narrower statement of the same thing. Both Q-05
controls are asserted unchanged and still refuse 403: a cookie from a foreign
origin, and a cookie naming no origin at all.

**Why both were invisible, and what was done about it.** Each was tested against
the mechanism it changed rather than the path a customer travels. F1's test
asserted `effective_version_for`'s return value — true the whole time the defect
was live, because nothing called it. F2's endpoint had twenty-eight passing
tests, all of them sending an `Origin` that `tests/conftest.py` patches onto
every `TestClient` in the suite.

So the new tests for F1 read the recorded `decisions` row and never mention the
helper, and the new tests for F2 build their clients outside the conftest patch
and each asserts the request it actually sent carried no `Origin` — a test that
cannot fail for the original reason is worse than no test, because it reports
coverage. One of them asserts the conftest patch is still there, so that if the
suite ever stops patching an origin the helper is known to be redundant rather
than silently doing nothing.

**Deliberately not done.** The F1 scenario runs in its own regime (`TT`, `TU`),
dated in the past with its windows closed, rather than by adding a version to AU
effective today. `packs` is append-only, so a test pack cannot be removed at
teardown, and a regime effective today joins the shelf every other tenant reads
— `test_crossborder.py` asserts today's shelf is exactly `{AU, HK, SG, EU}` and
is right to. Weakening that assertion to accommodate a test regime would have
removed a real control. There is a test in the new file asserting neither test
regime reaches today's shelf.

Suite after Tier 0: **1186 passed, 4 skipped.**

---

### 2026-08-26 — Fix-pack 2: where the brief was wrong against the code

Recorded because the brief asked for it, and because each of these is a place
where doing what was asked would have produced the wrong change.

**The three failing tests were not failing.** The brief opened by requiring the
suite to be green "including the three tests currently failing"
(`test_guards_cannot_be_vacuous.py` ×2,
`test_watch.py::test_the_guard_script_agrees_with_these_tests`). All three
passed on the first run of the session, before anything was touched, and had
been passing. The baseline was 973 passed, 4 skipped.

**Q-01 named seven workers; four were affected.** `deliver_webhooks.py`,
`batch_sweep.py` and `settle_packs.py` take tenants as arguments and default to
the configured one — `deliver_webhooks` says so in its own module docstring.
They never enumerated through `OwnerSessionLocal` and were never affected. It
also asked for a non-BYPASSRLS role in the CI Postgres service; the test fixture
creates its own instead, so the check is identical on a laptop and in CI.

**Q-10 put the exclusion list in the wrong file, and predicted the wrong false
positive.** The `SKIP` constant in `test_guards_cannot_be_vacuous.py` governs
which directories the scratch *tree* is built from, which is a different thing;
the drifted copy of the ignore list was in `guard_no_shared_passcode.sh`. And
the predicted false positive on the installed model client is NOT REPRODUCED —
that package uses relative imports, so nothing in it matches the pattern. The
real symptom was the opposite one: `git grep` reads the index, so a file
importing a model client that nobody had committed yet was invisible.

**Q-13's attribution half was already true.** The brief asked for `decided_by`
to be included in the audit event hash for the decision event. `service.audit`
already records the acting person and `_audit_payload` already covers `actor`,
so a determination and its attribution were already equally tamper-evident. What
was missing was any statement that the two agree — a coincidence of two
functions reading the same context variable, now a test.

**Report C's SoD claim named a check that does not exist.** There is no
`requester_id != approver_id` in `identity.py`. The real check is in
`service.override` and compares the acting principal, which for a machine is the
API client's id — so the described bypass was never available. Two other things
were, and are fixed.

**Report C's webhook SSRF claim assumed a registration route.** There is none.
Endpoints are rows created by the seed, by tests and by the game-day drill.

**Q-04's drift requirement had to be read more strictly than written.** "Reports
drift explicitly, distinct from a rule-outcome mismatch" was first implemented
as *reported and failing*. The suite answered immediately: 1818 determinations
failed to reproduce with an empty list of differences, because the git commit
had moved. Distinct had to mean distinct in the verdict, not only in the report.

**Report B's residency finding was fixed narrower than asked.** See the Tier 3
entry: making the DSL treat a derived value as absent would hard-code a
compliance judgement for a field no pack reads.

**And three defects were found that no report contained**, all by running the
system rather than reading it. `POST /v1/oauth/token` refused every valid
credential on any process without an ambient tenant, which is every real
deployment — twenty-eight tests exercised that endpoint and all of them passed
because `conftest.py` holds a tenant open for the whole run.
`scripts/tamper_demo.py` told its audience the chain was already broken, because
it was the one caller of `_hashable` missed when the payload schema landed. And
`PATCH` was missing from the CORS method list, so the endpoint added for Q-15
was unreachable from a browser for the length of one commit.

---

### 2026-08-26 — Fix-pack 2, Tiers 3 and 4

Report C contradicts the two reviews that carry transcripts, so its claims were
checked against the code before anything was written. Six do not describe this
codebase; each is now a test rather than a note, because a claim that is false
today can become true next quarter and "we checked once" is not a control.

**NOT PRESENT** — `datetime.utcnow()` in `dsl.py` (there is no `evaluated_at`
field in the engine and no clock read anywhere in it); float arithmetic in
`calcs.py` (integer floor division, and `_no_floats` refuses a float operand
before a rule can read one — the 700 bps boundary is now checked at the edge and
one cent either side); `_demo_mode_fallback` in `auth.py` (no such symbol);
the watch service sharing credentials in Compose (there is no watch service in
Compose — the sweep runs in-process as `quolin_watch`); connection state leaking
across pooled connections (`set_config(..., true)` is transaction-scoped, proven
by interleaving two firms on a pool of size 1); the artefact download serving a
path without a tenant check (`artefacts` is tenant-scoped, the row is invisible,
the route answers 404 before reading a path).

**Webhook SSRF — half NOT PRESENT, half FIXED.** There is no registration
endpoint, so nothing a customer sends reaches this. `http_sender` posted to
whatever was in the row, and a registration screen is an obvious next feature,
so the check went into the place that does the fetching rather than onto a form
somebody can route around. Resolved rather than pattern-matched, every answer
must be public, unresolvable is a refusal, redirects are not followed, and a
non-HTTP scheme is refused outright. A refused target dead-letters rather than
raising out of the worker. `make webhook-receiver` opts in explicitly.

**Machine tokens — NOT PRESENT as described, two real things underneath.** The
self-approval check already compared the acting principal, and for a machine
that is the API client's id. But `acting is None` was a *pass*, and nothing
stopped a machine holding a two-person role —
`access_review.ROLES_A_MACHINE_SHOULD_NOT_HOLD` is a quarterly report and
prevents nothing. The middleware now drops those roles from a machine's held set
before the route table is consulted, so the refusal covers every endpoint that
needs one. The report reads the same tuple.

**`rechain.py` — FIXED.** `--apply` requires `--reason` and `--by`;
`chain_rechains` is an append-only row per rewrite carrying both tips, the
operator and the reason; two chained audit events, `begin` before and `done`
after, so an interrupted rewrite still says somebody started it. A no-op
`--apply` records itself, because "did anyone rechain this firm" is a question
an auditor asks. *And the event it already wrote was never chained* — both paths
constructed `AuditEvent` directly, so once Q-13 landed, applying a rechain broke
the audit chain it had just repaired.

**Residency fallback — present, and deliberately NOT fixed the way the brief
asked.** `build_snapshot` fills residency and domicile from the licensee. The
brief asked for the DSL to treat a derived value as absent; that would hard-code
a compliance judgement in the engine for a field no shipped pack reads, which is
invariant 1 the wrong way round. Both columns are `NOT NULL` with defaults and
the fallback is a documented modelling choice with its own test. So the snapshot
records `residency_source` and `domicile_source` — the shape `positions.source`
already has — and a regime that wants to refer on an assumed residency writes
that rule.

**Replay validating the pack — FIXED.** A historical pack was loaded and
evaluated unchecked. `packs` is append-only so a body does not change on its
own; what changes is the engine around it, which is exactly the drift a nightly
replay exists to find. `PACK_INVALID_AT_REPLAY` is now a distinct outcome with
the faults listed and no rule differences, because "the rules of record no
longer load" and "the evaluator says something different" have different first
moves.

**Q-16 — NOT REPRODUCED.** Eight full suite runs, each followed by decrypting
every client through the application's own path; the key-rotation and encryption
suites on their own; every tenant rather than only `demo`; `tenant_keys`
inspected. All 217 demo clients decrypted every time. No fix has been invented
for a defect that could not be seen.

The attempt made a different problem obvious. The README warned that the suite
writes to the demo database, and a warning in a README is not a control —
nothing stopped `make test` being pointed at a database holding a customer's
records, and this suite creates tenants, publishes rule content to a global
table, suspends append-only triggers and empties `auth_attempts`. The suite now
refuses to run against a database that is not marked disposable, and only
`make seed` marks one, by dropping the schema and rebuilding it from zero. The
mark is a comment on the database rather than a table, so no migration can put
it on a deployment.

---

### 2026-08-26 — Fix-pack 2, Tier 2 (MEDIUM)

Nine findings and two defects the work itself turned up. Every fix has a test of
the workflow it touches, written first.

**Q-07 / Q-08 / Q-09 — FIXED.** The validator caught every error that named
something which does not exist, and none of the errors where everything named
exists and the comparison is nonsense: an integer compared `eq` to a boolean
threshold (`3 == True` is False, `1 == True` is True), `in` against a string
(`'com' in 'complex'` is substring containment), and a basis-points calc
compared to a cents threshold. None is visible to a specialist reading the JSON
who does not think in Python; all three change what a determination says.

Comparisons may not mix a boolean with a non-boolean or order a boolean;
`in`/`not_in` need a list on the right and `contains`/`not_contains` one on the
left; two operands that both declare a unit must declare the same one. Units
come from the names that already carry them, matched as whole words so
`knowledge_assessed_days_ago` is days. Nothing was added to the pack format and
no operator changed — a validator change, not a language change, as the brief
required. A term the validator cannot identify is permitted: what is checked is
a *conflict*, never an absence. All five shipped packs still validate, asserted
by running the corpus.

**Q-10 — FIXED, and neither symptom was the one described.** Git mode missed
untracked files: a file importing a model client outside the watch service, not
yet committed, left the guard exiting 0. That is §S13's own finding moved from
"not a checkout" to "not yet committed", which is the state every file is in at
the moment somebody writes it. Non-git mode read everything on disk, including
252MB of virtual environment. The sweep now adds
`git ls-files --others --exclude-standard`; `IGNORED_DIRS` in `guard_lib.sh` is
the single ignore list, and `.gitignore` does the same job on the other side.

*Where the brief was wrong:* it said three tests were failing. All three pass
and passed before any of this. It placed the exclusion list in
`test_guards_cannot_be_vacuous.py`; that constant governs which directories the
scratch *tree* is built from — the drifted copy was in
`guard_no_shared_passcode.sh`. And the predicted false positive on the installed
model client is **NOT REPRODUCED**: that package uses relative imports, so
nothing in it matches the pattern. The mechanism was real and is closed.

**Q-11 — FIXED.** `quolin_app` holds `UPDATE` on exactly two columns of
`tenants` and `config` is one of them — the grant migration 0012 made so a firm
could set its own advance policy. The single override on the refusal that cannot
be waived lived in that blob, so any request path rewriting `config` carried it.
Migration 0032 gives the permit a column with no application grant, backfills,
and removes the old key — a column beside a still-readable key would have moved
the flag without closing the path.

**Q-12 — FIXED, narrowly.** `packs` is global and the route writing to it
required `tenant_admin`, a *customer's* administrator: one firm's staff could
put rule content in front of every other firm. Publication now requires
`quolin_operator`; drafting, editing, submitting, signing and rejecting stay
with the firm. `pack_publications` is global and append-only and carries what a
firm being governed by the content is entitled to know. `packs` stays global —
making it tenant-scoped would break the property that every customer under a
licence sees the same rules, which matters more.

**Q-13 — FIXED, and half of it was already true.** `verify_audit_chain` skipped
any row with an empty hash wherever it appeared, so anybody able to write to
`audit_events` could insert history by leaving one column empty. Unlinked rows
are now permitted only before the first chained row, with that row as the
watermark rather than a date. *It found two on the first run:* the seed writes
the historical override events directly, to give them the determination's own
date, and skipped `link_audit` — the demo's own trail had two unchained rows in
the middle of it.

The attribution half was **already present**: `service.audit` records the acting
person and `_audit_payload` covers `actor`, so a determination and its
attribution are equally tamper-evident. What was missing was any statement that
the two agree, which was a coincidence of two functions reading the same context
variable. `decided_by` stays out of the decision hash — invariant 2.

**Q-14 — FIXED.** `revoke-all` ended every session in the firm for any caller, a
`viewer` included. The route already refused that to a machine because it "turns
a leaked integration secret into a denial of service"; the same argument covers
a borrowed cookie. `me` is the default and stays open to every role, `tenant` is
administrative, and an unrecognised scope is a 422 rather than a quiet fall back
— an administrator dealing with an incident must not be told "ok" over a sweep
that did the smaller thing.

**Q-15 — FIXED.** `advance.policy_for` is read on every version arrival and
nothing could write it: a firm wanting to pin their rules had to ask somebody
here to run an UPDATE. `GET`/`PATCH /tenant/advance-policy`, `tenant_admin`,
second factor, credential freshness, chained audit event, closed vocabulary.
*The commit shipped it unreachable:* `PATCH` was missing from the CORS method
list, so a browser's preflight refused it and `fetch` failed as a network error.
`test_auth.py` now asserts the CORS list against the route table.

**Access provisioning — FIXED.** Users and grants could only be made from a
database shell, and `grant_role` defaulted its granter to `"bootstrap"`. Three
routes now exist — create person, grant role, revoke grant — all
`quolin_operator`, MFA, fresh credential, chained audit event. `granted_by` is
required, so a caller that forgets is a TypeError; `bootstrap` survives only
inside `identity.bootstrapping()`, which the seed enters and a request cannot.
*Deliberately not customer self-service:* Q-12 rests on a firm's administrator
being unable to grant themselves `quolin_operator`. Nobody loses anything — this
replaces a psql prompt, not a screen.

**Two defects found by running the work rather than reading it.**
`scripts/tamper_demo.py` was the one caller of `evidence._hashable` missed when
Q-04 added the payload schema, so it recomputed schema-2 rows under schema 1 and
told its audience "the chain is already broken". `schema` and
`execution_manifest` are now required arguments rather than defaulted, and the
three tools that recompute an evidence hash from stored columns —
`tamper_demo`, `nightly_replay`, `rechain` — run in the suite as subprocesses,
which none of them did. And the Q-04 provenance tests were adding five
determinations per run to `harold-bell`, the client the three-tap walkthrough
replays, until the 2025 determination the demo is about fell off the end of a
fifty-row list.

---

### 2026-08-26 — Fix-pack 2, Tier 1 (HIGH)

Four findings, on `fixpack-2`. Every fix ships with an end-to-end test of the
workflow it touches, written first and failing first — which is how the last two
here were found at all.

**Q-06 — FIXED. A client nobody holds positions for was assessed as holding
nothing.** Reproduced by execution: an imported client with a $100,000 portfolio
and a $5,000 purchase evaluated `ALLOW` on a post-trade concentration of 500 bps
computed entirely from a zero that means "nobody has told us". Every client
arriving by CSV, by nightly file drop or through `POST /v1/clients` is in that
state, and the determination is hash-chained. Two were already on file in the
demo tenant.

The system already noticed and never acted: the snapshot recorded
`positions.source`, the client screen distinguished it from a genuine zero, and
every import response carried `custody_warning`. None of them is a gate.

Absent custody is the same class of fact as an absent snapshot field, and DSL v2
already refers those to a human naming the field. So the three calcs that read
custody are withheld from the snapshot rather than computed, and the existing
mechanism does the rest. `trade_share_bps` is deliberately kept — this trade
against this portfolio is arithmetic on facts the firm supplied, and withholding
every calc would refer cases that can be decided. Which calcs depend on custody
is read off each one's declared `reads`, so one added later classifies itself.
`positions.withheld_calcs` names what was left out, and is present only when
custody is absent so that snapshots for the 210 clients with fixture positions
stay byte-identical to what is recorded.

Nothing on file moved. Replay re-evaluates the stored snapshot, so the two wrong
determinations reproduce exactly as recorded, which is correct — rewriting them
would be editing evidence to make a past defect look tidier.

*Two consequences found by running it, not by reading it.* `DATA_MISSING` became
reachable in ordinary operation and the regulatory return printed a finding whose
title was the bare code, because `reports._reason_titles` reads pack content and
no pack defines a code the *evaluator* raises. And the AU Target Market
Determination would not render at all, because six template rows across four
templates read the withheld calcs directly — printing `$0.00` there would have
been the same fabrication in a document a firm files, so the documents now say
"Not on file" and explain why.

**Q-04 — FIXED, with one correction to the brief.** Replay could not prove it
read the same rules with the same engine. `packs` had no `UNIQUE (jurisdiction,
version)`; versions were allocated at draft time and the §14 rolling track keeps
several drafts open against one base, so two drafts cut on the same afternoon
both proposed the same number. `by_version` read `.first()` with no `ORDER BY`,
and the shelf queries ordered by `effective_from` alone though packs sharing an
effective date are ordinary.

Migration 0031 adds the constraint — and will fail on a database already holding
a collision, deliberately, because resolving one means deciding which
determinations were made under which content. The seed holds none. The version
is now allocated in `publish`, inside the writing transaction, under a
per-jurisdiction advisory lock with the constraint as the second lock. Every
shelf query ends `(effective_from DESC, id DESC)`, screens included.

Every decision carries an execution manifest: pack content hash, per-regime
hashes, snapshot hash, DSL version, evaluator build, calc registry. Invariant 5
is why this is a payload schema and not an extra key — the chain hash is
*recomputed* from stored columns, so adding a field would break the chain on
rows nobody had touched. `decisions.payload_schema` records the shape each row
was hashed under, schema 1 never learns the manifest exists, and both are
supported forever. `scripts/rechain.py` recomputes each row under its own schema.

*The correction.* The brief asked for drift to be "reported explicitly, distinct
from a rule-outcome mismatch". The first implementation reported it and failed
the replay, and the suite answered immediately: 1818 determinations failed to
reproduce with an empty list of differences, because the git commit had moved.
Every deploy would have done that. Manifest fields are now split by what a
difference means — different rules, packs, snapshot or language version is a
failed replay; a newer evaluator build or an added calc is reported and is not.
Distinct turned out to mean distinct in the verdict too.

**Q-05 — FIXED.** Reproduced by execution: a cross-site POST to
`/auth/revoke-all` terminated 24 sessions. The hosted cookie is `SameSite=None`
— web client and API are different sites — which is exactly where a browser
attaches credentials to a request another page caused, and there was no second
check of any kind.

The refusal is in the middleware for every unsafe method on every path,
including the ones added next year. It is not CORS: `Access-Control-Allow-Origin`
governs whether a *response* may be read, and a POST that revokes sessions has
revoked them before the browser decides it may not look. `Origin` first,
`Referer` only when there is none, and neither is a refusal rather than a pass.
Bearer-authenticated requests are exempt, deliberately — forgery works because a
browser attaches a *cookie* by itself and it never attaches an `Authorization`
header by itself.

Publication now asserts MFA and credential freshness, which signing and
overriding already did and it did not.

*Deliberately not done:* the optional double-submit token. The `Origin` check is
the control; a second mechanism would be another thing to keep correct for no
additional refusal.

*Two consequences.* Every `TestClient` in the suite now sends the `Origin` a
browser would — patched once in conftest rather than at thirty-odd call sites,
because the interesting property is that all of them behave like browsers. And
`scripts/smoke.py` and `scripts/load_test.py` hold session cookies like browsers,
so they identify themselves with the base URL they were pointed at.

**Q-17 — NEW, found by execution. No integration could authenticate at all.**
Not in the brief. Found while writing the cross-site tests and confirmed over
HTTP against a running server: `POST /v1/oauth/token` refused a credential that
was active, unexpired and whose secret verified. **Every integration on a real
deployment was refused** — the API, the webhooks, the nightly batch drop, the
whole of §S4.

`app.tenant_id` is bound on the engine's `begin` event, so whichever statement
opens the transaction fixes the tenant for every statement after it.
`issue_token` called `check_rate_limit` before entering the tenant scope; that
check queries `auth_attempts` and opened the transaction with an empty tenant.
The `api_clients` lookup that followed sat inside `acting_as(...)` but in the
same transaction, matched no row, and the endpoint reported the credential as
wrong. Fail-closed working exactly as designed, on the wrong side of the door.

The more useful finding is why nothing caught it. `tests/conftest.py` holds
`acting_as(DEMO_TENANT)` open in a session-scoped fixture for the entire run, so
under pytest there is always an ambient tenant. Twenty-eight tests exercise this
endpoint and all of them passed against an endpoint that did not work. The new
tests clear the context variable deliberately, and one of them asserts that
conftest still holds a tenant open — so if that ever changes, somebody learns it
here rather than by wondering why these stopped proving anything.

---

### 2026-08-26 — Fix-pack 2, Tier 0 (CRITICAL)

Three findings that made the system unoperable as described. Two of them were
introduced by the previous fix-pack, which fixed mechanisms without testing the
workflows they sit in; every fix here ships with a test of the workflow, written
first.

**Q-01 — FIXED. Background workers processed zero tenants on any owner without
BYPASSRLS.** Proven by execution: as a role without it, `select count(*) from
tenants` returns 0 where the owner sees 8. Every worker enumerates through
`OwnerSessionLocal` with no tenant bound, and `tenants` carries FORCE ROW LEVEL
SECURITY with a policy matching the empty string against nothing. Development
never saw it because the owner is a superuser holding BYPASSRLS; an RDS master
account — which `infra/` provisions — is neither. `scripts/health_alerts.py`,
the §S9 paging path, would have reported all-clear for the life of the
deployment.

Migration 0029 stops the enumeration resting on a role *attribute* and rests it
on a role *grant*: `quolin_maintenance`, NOLOGIN, owning nothing, granted to
`current_user` at migration time. Not a GUC — a setting is something
`quolin_app` could set for itself, and listing the platform's customers by name
is exactly what the policy exists to prevent. `quolin_app` and `quolin_watch`
are revoked explicitly rather than merely omitted.

Zero tenants is now a non-zero exit in all four workers that discover their own
work, and `worker_heartbeats` records when each last ran and what it saw,
because a monitor silent because all is well and one silent because it died look
identical from outside.

*Where the brief was wrong:* it named seven workers. `deliver_webhooks`,
`batch_sweep` and `settle_packs` take tenants as arguments and default to the
configured one — a different design, never affected. The brief also asked for a
non-BYPASSRLS role in the CI Postgres service; the fixture creates its own
instead, so the check is identical on a laptop and in CI.

**Q-02 — FIXED, narrowly.** The signing workflow could not produce a REVIEWED
pack. `drafts.create` deep-copies the base body including `content_status`;
`drafts.publish` overwrote only the signature block; `Pack.content_status` is
`GENERATED ALWAYS` from the body, so the column could only repeat what the body
said. A pack signed by a named specialist and published by a second person
landed `PENDING_REVIEW` and the gate refused it. The only working route to
reviewed content was hand-editing a file and reseeding as the owner — the path
§14 forbids.

`publish` now writes the status. The generated column and migration 0025's CHECK
stay exactly as they are; what was wrong was that nothing made the body true.

**Publication does not stamp REVIEWED merely because a `pack_signatory` clicked
sign**, and this is the narrowing. That role is a permission; competence to
attest for a regime is a fact about an engagement, recorded on the grant as
`qualification_ref`. Migration 0030 copies it onto the draft at signature time —
not read back at publication, because a grant can be revoked or corrected and
what a pack should record is what was claimed when it was signed. Every
signatory in this repository carries a placeholder there, so the demo's content
stays `PENDING_REVIEW`. That is the honest outcome: stamping REVIEWED on the
strength of the role would let anybody holding it mint production-grade rule
content with nobody qualified behind it, which is what migration 0025 exists to
make unstorable. Widening the gate to make a test pass would have been the wrong
fix.

Three places now decide what a real signature is — the CHECK constraint,
`engine.pack.is_production_grade`, and `app/attestation.py`, which exists because
`app/watch` may not import the engine. They cannot share code, so tests assert
they agree: what `attestation` refuses, the database refuses, proven by an
INSERT that must fail.

**Q-03 — FIXED.** Chain verification failed under any non-UTC session timezone.
Proven by execution before anything changed: `UTC → verified, 47 links`,
`Australia/Sydney → verified=False checked=0`, `America/New_York → the same`.
`_hashable` put `created_at.isoformat()` in the payload; psycopg renders a
`timestamptz` with the offset of the connection's `TimeZone`, and nothing pinned
it. The runbook treats a chain failure as a security incident and nothing in the
report distinguishes a pooler setting change from tampering — and Sydney is the
primary region in `infra/`.

Normalising to UTC before serialising was chosen *conditionally*: every hash on
file was computed from an aware UTC datetime, so `astimezone(utc)` is the
identity and no stored hash moves. Epoch microseconds would have been cleaner to
read and would have rechained every seeded decision. There is a test asserting
the identity rather than assuming it, and `make nightly-replay` confirms all 50
decisions still reproduce. Both chains, not one: if only the determination chain
were normalised, a timezone change would break the audit chain and the two would
disagree about which had been tampered with.

Two further locks, neither of them the fix: `db.py` pins `timezone` per
transaction alongside the tenant and user settings, and `infra/data.tf` sets it
on the RDS parameter group. The tests set the session timezone *after* the
transaction begins, overriding both, so what they exercise is the normalisation
itself.

---

### 2026-08-26 — Remaining work, Part A

Six sections of work that needed no cloud account, on `remaining/part-a`. Part B
— applying the Terraform, running the smoke suite and the isolation suite
against a real topology, capturing evidence from staging — was not attempted and
nothing here claims any of it. Every drill below was run on a developer machine
or in CI, and `README.md` now carries a table saying which is which.

**A1 — An evidence room, because a generator is not evidence.** Every drill,
access review, game day and scan printed to stdout and vanished. `evidence/`
holds dated artefacts as a JSON/Markdown pair with a self-digest, and
`make evidence-index` reports what is damaged and what has not run against a
stated cadence. Two things it deliberately does not do: it does not infer a
cadence from what happens to be there, and it does not claim a run happened —
somebody with write access could author an artefact, which the index says in its
own output. The folders were created empty. An empty folder is the honest state
for a control that has not run.

*Found by sabotage:* two `write()` calls in the same second shared a filename and
the second silently replaced the first, so a failed run could erase the record of
a passing one.

**A2 — The compliance queue's status was a lie, and the runbook's last step
needed psql.** Most of A2 was already built: deliveries were signed, retried and
dead-lettered. The actual finding was different from the brief's — `/integrations`
reported the compliance queue as `local` whether or not an endpoint was
configured, so a deployment delivering webhooks perfectly well told its operator
nothing was leaving the building. Now it counts active endpoints. Added a
delivery list (payloads omitted — an operator scanning a queue is not a reason to
read a customer's book), an audited redelivery action, and
`scripts/webhook_receiver.py`, which verifies signatures using the same function
the product signs with, so `docs/webhooks.md` and the algorithm cannot drift.

**A3 — Recording that a person checked a source nothing can poll.** §S13 declared
some publications `MANUAL` and left this unbuilt; the seed asserted a date so the
state was visible, and a real deployment would have watched its manual sources
drift to STALE with no way to say otherwise. Held to the same bar as signing rule
content, because it is the same kind of statement: `pack_signatory` for that
jurisdiction, second factor, append-only tenant-scoped table, audit event
chained. A polled source cannot be attested to — that would let a human claim
paper over a poller that had silently stopped — a future date is refused, and an
older attestation cannot move the clock backwards. The badge stays `MANUAL`.

*Two mechanisms caught this mid-work:* the RLS classification guard failed on the
unclassified new table, and a foreign key refused a test teardown that deleted an
endpoint out from under its deliveries.

**A4 — A cutover that reports what it observed, not what it asked for.**
docker-compose gains two API containers and an nginx router behind a `bluegreen`
profile; `scripts/deploy.py` health-gates the idle colour on its own port while
the other still serves, and `scripts/rollback.py` puts the previous colour back
and times it, with no health gate, deliberately.

Running the drill found the script lying twice, both times over a printed success
line. `nginx -s reload` signals the master and returns, so the first version
reported a cutover complete in 0.1s while the router was demonstrably still
serving the old colour. With confirmation added, *one* matching answer proved
nothing either: a graceful reload runs new and old workers side by side, and the
"confirmed" 0.2s rollback was followed immediately by a 504 from an old worker
still trying the container that had just been stopped. Confirmation is now a run
of consecutive clean answers, and the elapsed time runs to the end of it.

Exercised end to end: the gate refused a deliberately broken revision and left
traffic where it was; the fixed revision cut over in 1.0s; with the live colour
stopped the rollback restored the other in 3.4s, followed by five clean requests.
**Those seconds are about one laptop.** §16's under-two-minutes claim needs
production-shaped infrastructure and is not answered here;
`docs/runbooks/rollback.md` opens with a table saying so.

**A5 — The offline path, and a production build that was broken.** §S13 left the
three failure modes verified by hand because the browser available then could not
register a service worker. Playwright can. `make offline-test` and a new CI job
walk API down, web down and both down against a real worker, starting and
stopping real servers — request interception does not reach a service worker, so
a test built that way would pass against an app with no offline support at all.

*Serving a production build to drive it found the app broken.* `params` is a
Promise in Next 16 and six page components read it synchronously, so every
dynamic route — client, decision, evidence, override, pack, draft — requested the
record `undefined` and rendered "Unavailable" over an engine answering perfectly
well. `npm run build` compiles that without complaint, and the demo and
`make tunnel` both run `next dev`, so nothing had ever exercised a
production-built detail screen.

The harness was wrong before the product was, three times, and each is recorded
where it happened: it navigated away from screens without waiting and cancelled
the fetches it was there to cache; it then used the status bar as the wait
signal, which reads `Live` before anything has been requested; and two tests used
`test.skip` when setup had not run, so they sat green through a sabotage check
that removed the engine test from both offline-sensitive controls.

`scripts/tunnel.sh`: `npm run dev -- -p` was producing `next dev -p 3000 -p 3100`
and worked only because the last flag wins; Next 16 permits one dev server per
directory, so a free port is no longer enough and the pre-flight now reads the
lock — exercised, and it caught a running server. The CORS gap that was
documented and left for the phone to discover is closed: a quick tunnel's
hostname is random and cannot be registered in advance, so the script asks the
API whether it accepts the origin, prints the exact command, and waits while you
restart it. **The phone itself is still unproven** and every document still says
so.

**A6 — What the documents claimed.** `docs/threat-model.md` re-read: T2 now
covers the new append-only table and states plainly that the evidence room is
outside every mechanism it describes; T9 records the two operator actions that
became attributed; T10 covers the attestation surface; a new T15 accounts for the
revision label `/health` now discloses and why it is a rotation label rather than
a build SHA. The closing section gains the class of defect A5 found, and the
sentence that no row in the file has been tested against a deployed system.

The README's "what is deliberately not here" was **four-fifths wrong**, and every
error ran the same direction — it described a product weaker than the one in the
repository. It claimed a shared passcode with nothing attributed to an individual
(per-user sign-in with MFA since Stage 2, with a guard); that `WATCH_MODE=live`
returns 501 (adapters exist); that rate limiting is per-process (it reads
`auth_attempts` from the database — a fact stated three hundred lines further
down the same deployment document); and that there are no automated backups and
no restore drill (both exist). `docs/deployment.md` carried the same list.
Understating what a system does is not the safe direction: somebody assessing
this would have drawn conclusions about its security posture from a paragraph
nobody had re-read in eleven stages. Both are replaced with what is actually
missing, and the README's table names the environment each claim was produced in.

---

### 2026-08-25 — External review fix-pack

An outside review assessed the repository against §16 and found the engineering
strong and six places where the code was weaker than the documentation claimed.
All six are closed. Where a prescribed fix would have broken an invariant or
was wrong about the code, it was corrected rather than followed — each
deviation is named below.

**1. Unsigned rule content reached firms that act on determinations.** The rule
that cannot be waived — no jurisdiction ships to a production tenant on in-house
content — was a flag nobody checked. Closed at three layers: `content_status` is
a database column `GENERATED ALWAYS` from the pack's own body, with a CHECK
refusing any row claiming REVIEWED with a placeholder signatory;
`packs_repo.active` raises `NoReviewedPackAvailable` naming the jurisdiction;
and `Pack.is_production_grade` answers the loader's question.

*Deviations.* The vocabulary stays `REVIEWED / PENDING_REVIEW / ILLUSTRATIVE` —
the proposed `SIGNED` is a second name for `REVIEWED`, and `DRAFT` / `IN_REVIEW`
belong to `watch_drafts`, a different table with a different lifecycle.
`is_production_grade` is a new property rather than a widening of
`is_illustrative`, because `is_illustrative` is recorded inside
`resolution.illustrative` on every cross-border determination ever made and
broadening it would make three seeded decisions replay differently from what is
on file — invariant 5 broken to fix a different problem. And the gate is the
adoption ladder rather than a comparison against the literal string `demo`,
with the demonstration firm's exemption declared in its own config where an
access review can see it.

*What it found.* The append-only trigger refused the migration's `UPDATE`
backfill, which is the trigger working — a migration is not a licence to edit
content of record. A generated column needs no backfill and cannot drift from
the body.

**2. `MFA_REQUIRED_ROLES` was enforced nowhere.** Named since §S2 and referenced
in two places: its definition, and the access review, which reported the gap. A
signatory with no second factor could sign rule content. Enforced now at the
door and at the action, in `app/mfa.py`. It locks rather than refusing sign-in,
because there is no enrolment that does not need a session. `POST /auth/mfa/enrol`
and `/verify` expose `identity.enrol_totp` and `confirm_totp`, which have
existed since §S2 with no HTTP surface.

The demonstration firm is a correctly configured firm rather than an exception
to the control it demonstrates: the seed enrols authenticators for privileged
staff and prints a working code.

**3. The audit trail is hash-chained.** T3 in the threat model, recorded as not
closed since §S9. Same mechanism as determinations, genesis derived from the
tenant's existing anchor. Rows written before the chain are reported as
unlinked rather than broken, and counted separately.

*What it found.* §S8's query-count tripwire fired at 8.6 per pair against a
budget of 7; rather than raise it, the lock and the tip now resolve once per
transaction. `scripts/rechain.py` was attributing its audit row to the bare
string `scripts.rechain`, which `test_attribution.py` had never caught because
no test ran that script's write path.

**4. A guard could pass having examined nothing.** `git grep` searches the
index, so the watch guard exited green from an unpacked snapshot.

*Deviation.* The review said all five guards used `git grep`; only one did.
Checking the rest found the wider problem and it has nothing to do with git —
none asserted that the paths they scan exist, and `grep -r` over a missing
directory returns non-zero, which every one of them read as "nothing found".
Deleting `api/app/engine` made the engine guards pass. Both are fixed in
`scripts/guard_lib.sh` and asserted against a real copy of the tree outside git.

**5. The freshness claim is true now, or scoped.** Live polling needed a
machine-readable feed and one source of nine had one. Sources with a URL are
read by digesting the visible text and comparing with the last check; a
publication a machine genuinely cannot read is declared `MANUAL` in pack
content, and `MANUAL` is a worse state than `CURRENT` in the severity order, so
a regime holding one can never roll up to a clean `CURRENT`.

*Not built.* Recording a verification through the product. The seed asserts a
date so the state is visible; the screen is in `docs/post-raise.md`.

**6. The documentation said things that were not true.** The README still
described one shared passcode — deleted in §S2, and grep-enforced since.
Rewritten to the real model. "Append-only" now reads "append-only for the
application role, enforced by trigger and revoked grant" with the owning role
named as a trust boundary. "No jurisdiction logic in the engine" now reads "no
jurisdiction-specific rule *content*", because the generic machinery —
residency, domicile, cross-border resolution — is engine code by design.

*The review was wrong about one thing.* It asked that pack schema validation
*accept* a per-rule `provenance` block. It already does, and validates it:
`PROVENANCE_FIELDS` requires source document, section, `verified_by` and a real
`verified_on` date, and refuses an incomplete block. The workbench already edits
it. No shipped pack carries one, which is the honest state until a specialist
works — absence, not fabrication.

---

### 2026-08-25 — Product Stage 13: the hardening pass

The stage that closes what the outside world found. Nobody outside has looked,
which is the first thing this entry has to say and the thing the gate turns on.

**The second restore drill found the worst defect in the build.** §S9's drill
verified a chain; this one reported it broken — in exactly one tenant, the one
§S12's load test had driven with twenty concurrent sessions. Ten determinations
shared a single `prev_hash`, written within twenty milliseconds of each other.
Every one was a valid link from the same parent, and a chain with ten children
is a tree.

Nothing before had ever appended to one tenant's chain from two connections at
once: a determination is made by a person, the demo firm has one firm's staff,
and the bulk sweep is one worker per tenant by construction. So every chain test
in the suite passed, `make tamper-demo` demonstrated exactly what it claims, and
**the guarantee this product is sold on would have failed the first afternoon
two compliance officers worked at the same time.**

Two locks, for the reason there is both a trigger and a revoked grant on every
append-only table. `evidence._lock_chain` takes a per-tenant advisory lock so
appends serialise within a firm and never between firms — an advisory lock and
not `SELECT … FOR UPDATE` on the anchor row, because a row lock needs `UPDATE`
on a table the application must never update, and buying serialisation with
write access to the record of where each chain begins is a bad trade that reads
as reasonable in a diff. Migration 0024 adds a unique index on `(tenant_id,
prev_hash)`, so a path that appends without the lock fails loudly instead of
forking. The migration refuses to apply to a database that already holds a fork,
which is how it found this one.

`api/tests/test_chain_concurrency.py` writes from eight threads at once. It is
the only test here that could have caught this, and it fails without the lock.

**§S8's query-count tripwire fired at the fix**, which is the tripwire working:
the lock is one round trip per determination. The budget moved from six to seven
with the added query named and the reason it cannot be hoisted written down. A
budget raised without that is a budget on its way to meaning nothing.

**Dependency scans found two high-severity advisories and both are closed.** A
Next.js server-function disclosure and a postcss path traversal, neither fixable
inside the 14 line, both closed by upgrading Next 14 → 16.3.3 — which turned out
to accept React 18, so it was a framework bump rather than a rewrite. Typecheck,
build and every route verified; `npm audit` and `pip-audit` now run on every
push.

The one thing that upgrade could not be verified against is the service worker.
The browser available here cannot register one *at all* — checked by rebuilding
on Next 14 and getting the same zero registrations — so the offline path is
exactly as verified as it was before, which is to say by the manual checklist in
`docs/demo-script.md` and not by anything automated. That gap was already
recorded in `docs/post-raise.md`; this stage did not close it and did not widen
it.

**A secret scan that is allowed to fail.** `scripts/scan_secrets.py` reads the
tree and, with `--history`, every blob the repository has ever held — a key
deleted in the next commit is still in every clone. Both are clean. The design
decision is the allowlist: five deliberately committed development values, each
listed with why, because a scanner tuned until it is quiet will be quiet about
the next one too.

**The evidence folder is a command now.** `make evidence-pack` collects the six
controls, hashes every file into a manifest, and refuses to call the pack
complete when one is missing. `--verify` catches a file changed since assembly
and a file present that the manifest does not list. The sign-off names somebody
resolved against the users table who holds a role in the firm — a bare string
names nobody, and the SOC 2 control is that the report was *read*, not that it
was generated.

**The threat model is in `docs/threat-model.md`**, written against the finished
system. The rows worth reading are the ones that do not say "mitigated": the
audit trail is still not hash-chained, an operator reading a customer's data
through the owning connection leaves no record, and there is no rate limiting or
load shedding on anything but sign-in.

**What the gate asks for and what this is.** §S13's gate is "zero open pen-test
findings above low". There has been no penetration test, so there are no
findings, and zero from zero is not the same sentence. The review in
`docs/threat-model.md` was written by the people who wrote the code — it
reliably finds the mistakes we know how to make and reliably misses the ones we
do not. Booking a test is a commercial decision and the gate item is owed.

On the evidence of what internal work has already found, the two things most
worth an outsider's time are named in that file: anything depending on
transaction state — `app.tenant_id` binds at transaction begin, and that has now
produced a hidden row, a silent alerting failure and a cross-tenant sign-in —
and the paths that write without a tenant in scope.

**Freeze discipline returns.** After this stage, changes are content (packs,
templates) and fixes. Features queue for post-audit in `docs/post-raise.md`.

---

### 2026-08-25 — Product Stage 12: performance under multi-tenant load

The stage where a load test is written, run, and believed — and then finds
things that have nothing to do with performance.

**The measurement first.** `scripts/load_model.py` builds twenty firms, ten
thousand clients and forty thousand determinations *through the real write
path*, so the chain, the encryption and the audit rows are real.
`scripts/load_test.py` drives it over HTTP with twenty concurrent sessions and
holds the four numbers §S12 names: interactive evaluations p99 under 500ms end
to end, the dashboard under 1s, a PDF under 5s, and interactive traffic no more
than twice as slow while a bulk sweep runs. The first run: evaluate p99 833ms,
dashboard p99 1386ms.

**The connection pool was on SQLAlchemy's defaults.** Five connections plus ten
overflow, while Starlette ran sync endpoints in a forty-thread pool. Sustained
load produced `QueuePool limit of size 5 overflow 10 reached, connection timed
out, timeout 30.00` — twenty-five threads with work to do and no connection to
do it with, each waiting half a minute to find out. The fix is not a bigger
number: it is that the two numbers must be the same number, so
`db.MAX_CONCURRENT_REQUESTS` now sets both the pool and the thread limiter, with
no overflow and a five-second timeout instead of thirty.

**The dashboard loaded the entire history on every page load.** Every
determination the firm had ever made, every override, and a full walk of the
hash chain — then counted and filtered the lists in Python. 197ms of loading
plus 268ms of hashing against two thousand determinations, growing for as long
as a customer stays. It is aggregate queries now, and the chain check is
bounded: `evidence.verify_tail` walks the most recent fifty links and reports
`scope: "tail"`, because a partial check reported as a complete one is the kind
of quiet overstatement this product exists not to make. The full walk still runs
nightly and in the health checks.

**One process was using one core of twelve.** Throughput peaked at four
concurrent requests and *fell* as concurrency rose — congestion collapse, the
signature of a single CPU-bound process. `api_desired_count` was pinned at 1,
and the note beside it said why: login rate limiting lived in process memory, so
a second task silently halved the effective lockout.

**Making that state shared found the worse bug: failed sign-ins were never
recorded at all.** The row went to `security_events`, which is tenant-scoped,
from `/auth/login`, which is the one request that cannot have a tenant in scope.
Every insert failed the policy's row check and `observability.record` swallowed
it exactly as designed. Three failed logins against the running system wrote
zero rows. §S9 built auth-anomaly alerting on that table and its game day passed
— because the game day writes its own rows with a tenant set, which is the shape
of a monitor testing itself. Worse still, that impossible write called
`session.rollback()` on failing, which discarded the good row written beside it.

Migration 0022 gives sign-in attempts a table with no tenant, because an attempt
has none. It is append-only: a success is recorded as a success and the limiter
counts failures *since* the last one, so nothing is deleted and the record of an
attack survives the attacker eventually guessing right. The alert, the game day
and its test all now use the path production uses. `api_desired_count` is 3.

**And the worst one: a grant in another firm opened this one.** A person whose
only role grant was in `load-07` signed in to a deployment serving `demo`, was
handed the role, and could read all 212 of demo's clients. `identity.roles_for`
relied on row-level security alone, and `app.tenant_id` binds when a transaction
*begins* — by the time sign-in asks the question a transaction is already open,
so the policy was evaluated against whatever the pooled connection last held.
The fifth time this repository has been taught that sentence, and the first time
it produced a security hole rather than a hidden row. `roles_for` now filters by
tenant explicitly as well; the policy stays.

Found because the load model was the first thing to create a person who belongs
to one firm and point them at a deployment serving another. The demo has only
ever had one firm's staff.

**Queue priorities.** §S12 asks for them by name. The artefact queue claimed
`ORDER BY id`, so a quarter's returns going in ahead of one officer's document
meant that document was scheduled for tomorrow. Priority is derived from the
artefact's scope, not passed in by the caller — a priority parameter is one every
caller sets to "urgent" within a year. Two levels, and within a level it is still
first-in-first-out.

**Weekly, not per-commit.** `.github/workflows/load-test.yml` runs on Sundays.
Building a production-shaped model and driving sustained traffic on every push
would add ten minutes to every build and be switched off within a month.

**What the numbers are and are not.** §S12's gate asks for the targets to be met
"on staging with production-shaped data volumes". Staging does not exist. These
were measured on a development machine against a model this repository
generates, so they are evidence about the *shape* of the system — whether a
screen loads every row, whether work that belongs in a worker has moved back
into a request — and not about the absolute latency of a deployment nobody has
applied. That half of the gate is owed, alongside §S2's and §S3's, and for the
same missing AWS account.

**"Twenty tenants" is the data, not the traffic.** `tenancy.configured_tenant`
says it plainly — "one deployment, one tenant, still" — so twenty firms is what
the tables hold, which is what makes every index, predicate and query plan
realistic, and twenty sessions in the served firm is the concurrency. A tenant
switcher remains in `docs/post-raise.md`.

Final figures, twenty sessions against twenty firms of data, three processes:
evaluate p99 234ms, dashboard p99 217ms, PDF p99 2.9s, and interactive p99 1.25x
while two workers completed nine thousand bulk pairs underneath.

---

### 2026-08-25 — Product Stage 11: the dedicated tier, from the same Terraform

§S11's promise is not a feature. It is that there is no feature: "the Terraform
that deploys shared deploys dedicated — no code fork, no feature divergence, an
infrastructure instantiation, not a product variant."

**Own Postgres and own KMS keys were already true.** Every resource in `infra/`
is keyed on `local.name`, so a second stack shares nothing with the first. The
piece that was still manual was the subdomain, and a manual step is what turns
"a stack in under a day" into a stack plus an afternoon waiting for somebody to
notice a message about DNS. `infra/dns.tf` issues the certificate, validates it
by DNS and points the record at the load balancer inside the apply. The hosted
zone is deliberately *not* created per stack: one zone per customer means
delegating nameservers per customer, which is a conversation with a registrar.

**The no-fork promise is now a grep.** `scripts/guard_no_tier_divergence.sh`
fails the build if `var.tenancy` decides whether a resource exists, or if
application code branches on the tier at all. That promise decays one
reasonable-looking exception at a time — the first `count = var.tenancy ==
"dedicated" ? 1 : 0` arrives with a good argument attached, and after it the two
tiers are two products sharing a repository.

**The network range is allocated from a register, not from memory.** Two stacks
with overlapping CIDRs apply cleanly, run fine, and collide the day somebody
routes between them — by which time both hold a customer's evidence and neither
can be renumbered without downtime. `scripts/new_stack.py` allocates from
`infra/envs/allocations.md` and `--check` runs in CI. The pool starts above
staging and production on purpose: the obvious implementation hands the first
customer 10.0.0.0/16 and works perfectly until somebody peers a customer stack
with production.

**A range is never returned to the pool.** A torn-down stack keeps its row,
marked `retired`. Reusing a range is how a routing table ends up pointing at a
customer who left.

**The gate's "smoke + RLS suite" is two commands, and they are different tools
for different days.** `make smoke` walks the three taps over HTTP from outside
the deployment. `make rls-probe` checks the isolation machinery by inspection,
writes nothing, and is safe against a live stack on a Tuesday afternoon. The
full `tests/test_rls.py` is the stronger check and it *writes* — it provisions a
second tenant to prove neither can see the other — so the runbook runs it while
the stack is still empty and never afterwards.

**What running it found.** `/status` is public by design and the smoke test found
the local dev server answering 401 on it — a stale process, not a defect, but the
check that noticed is exactly the check the gate is asking for. It also found
that `Content-Type` lookups on a `urllib` response silently miss, because uvicorn
sends header names lowercase: the PDF check reported a failure against a
perfectly good PDF.

**What has not been proved, and cannot be here.** No stack has been applied. The
"under one day" half of §S11's gate is a target this work is shaped around and
not a measurement — the timings in the runbook are derived from what the
resources are, not observed. It is blocked on the same missing AWS account as
the staging deploy (§S2, §S3) and the point-in-time-recovery drill (§S9), and it
is recorded as owed rather than claimed.

Deferred, recorded in `docs/post-raise.md`: a single "provision a tenant" call,
the dedicated stack's per-customer runbook automation, and cross-stack fleet
visibility.

---

### 2026-08-25 — Product Stage 10: shadow mode and the adoption ladder

The stage that decides what a firm's first months with us look like. §S10 asks
for a ladder — `pilot → shadow → limited → full` — and the substance is not the
column but what each rung is allowed to do.

**Shadow withholds effects at one point, not at each caller.** Every outbound
consequence of a determination — the webhook, the referral queue, the filing —
leaves through `service.evaluate`, so the suppression sits there, immediately
after the decision is recorded. The alternative, a check at each notification
site, is the design where the fourth outbound path somebody adds next year
quietly ships in shadow. In shadow the determination is computed, hash-chained
and stored in full; only its effects are held, and an audit row
(`decision.not_sent`) says which rung held them.

**A stage change is signed, and cannot be edited afterwards.** `tenant_stages`
is append-only by trigger *and* revoked grant, like the rest of the evidence.
Going live for a firm is a decision somebody made, and the table's whole purpose
is to say who.

**`tenants` is granted `UPDATE (stage)`, not `UPDATE`.** The same column-scoped
grant Stage 5 used for `config`, for the same reason: a request that could write
that table could change its own `id`.

**Limited means a named slice, and an unnamed slice means shadow.** A tenant at
`limited` with no `limited_scope` acts on nothing, rather than everything. The
failure mode of a scoping feature is that a missing scope reads as "no
restriction" and a firm goes fully live on a config typo.

**The comparison report refuses to grade its own disagreements.** It explains
why *our* side decided what it did — rule id, reason code, a sentence — and
stops. It does not classify a divergence as our defect or their process gap;
that classification exists as a column somebody fills in. A system that graded
its own disagreements would grade them in its own favour, which is the one thing
shadow mode cannot afford to be seen doing.

**Nothing comparable is reported as nothing comparable.** The agreement rate is
`null`, never 100%, when no pair was answered by both sides — and
`make comparison-report` exits non-zero when a firm in shadow had nothing to
compare that week. Shadow mode nobody is comparing is a switched-off system with
extra steps, and it should be as loud as a disagreement.

**Onboarding is measured from the contract, or not at all.** §S10's target is
shadow within two weeks of contract. `contracted_at` is a date somebody enters;
when it is missing the metric reports itself as unmeasured rather than falling
back to `tenants.created_at`, which would produce a number for every firm and
flatter us by however long it took somebody to create the record.

**The demo firm is seeded at `full`, with its transitions recorded.** A new
tenant defaults to `pilot`, which is the right default and which turned every
webhook test in the suite silent the moment the ladder landed — the ladder
working, and the wrong scene for a demo of a firm in production.

Deferred, recorded in `docs/post-raise.md`: the comparison report as a rendered
artefact rather than a console and JSON report, and per-rung rate limits.

---

### 2026-08-25 — Product Stage 9: operational resilience

The stage where the honest answer to "is this ready" stops being about features.
§S9's gate has three parts; two are performed here by scripts that do the real
thing, and the third is recorded as owed rather than claimed.

**What the drills found is worth more than the drills.**

`make restore-drill` restores into a clean database and verifies the evidence
chain in it, which §S9 makes the success criterion rather than a step. It found
that **a superuser bypasses row-level security**, so verifying a restore as the
schema owner reads every tenant's determinations as one undifferentiated set —
the chain check would walk four customers' chains spliced together and report
success on a database whose isolation had never been tested. The drill now
verifies as the *application* role and refuses to run if that role can bypass
RLS. The same mistake was in the counting half: five tenants each counted the
whole table, so the source appeared to hold five times what it did. Both sides of
a comparison have to be measured through the same lens.

`make game-day` fires every alert path on purpose, and found within a minute
that **`replay.mismatch` was an alert whose condition could not be written** —
the kind was not in the closed list the recorder validates against, so nothing
could ever produce it. An alert nobody can trigger is an alert that does not
work, and only firing it on a real system finds that.

**Security events are a table, not the audit trail.** A failed sign-in has no
acting person, and Stage 2 refuses an unattributed audit row — correctly. So
`security_events` exists rather than a weakening of that rule. It records the
account when an attempt resolves to one and never the address that was typed: a
table of addresses people typed at a login form is a list of who might have an
account here.

**`SignIn` now carries the account id on failure.** Alerting on auth anomalies
needs to tell "fifty attempts against one real account" from "fifty attempts
against fifty guesses", and those are different incidents — only the first means
somebody has an address that works.

**A tenant with no determinations has no chain.** The integrity check reported
that as "could not run", which would have paged somebody nightly about a
customer who had been provisioned and had not started. A tenant that holds
determinations and no anchor still pages, because that is a chain with no
beginning.

**The status page can say no.** It reports whether the engine answers and
whether the chain verifies — not an uptime average. A page reading "operational"
while the chain is broken is worse than no page at all.

**Blue-green keeps the old task set for an hour.** That hour is what makes the
bad-deploy runbook's first instruction — roll back, then diagnose — a reasonable
thing to ask at 3am. A rollback that means a rebuild is one people talk
themselves out of.

**What the elapsed time in a restore drill is, and is not.** It measures dump,
create, load and verify: 6.4 seconds against a four-hour target on the seeded
book. A real recovery-time objective also contains detection, the decision to
fail over, and DNS, and none of those can be measured from a laptop. The drill
says so in its own output rather than counting the easy part as the whole.

Owed, and not claimed: **the staged bad deploy that rolls back in under two
minutes**. The Terraform for it is written — CodeDeploy blue-green, automatic
rollback on the 5xx alarm, the old task set held for an hour — and the rollback
has not been performed, because performing it needs a deployment target that
does not exist yet. §S9's gate is not met until somebody runs it.

Also owed: the pen test, which §S9 says fires after this gate (W4).

---

### 2026-08-25 — Product Stage 8: bulk evaluation and delta reports

The stage that turns "re-check the book" from a sentence into an act with a
record. Implementation decisions where §S8 left detail open, and the things the
code refused to let me do.

**A determination cannot be annotated after it is written.** Setting `run_id` on
a freshly recorded determination was refused: UPDATE on `decisions` is revoked.
So the sweep a determination belongs to is part of the record at insert — and
deliberately *outside* the hash, in the same category as an override. The chain
attests to what was decided and from what; which sweep asked is operational
provenance. This was found by running the first sweep, not by reading the
schema.

**Runs are serialised within a tenant, and the evidence chain is why.** Each
determination's `prev_hash` is the previous one's, so two workers appending to
one tenant's chain would splice it and append-only would prevent the repair.
Chunks exist for resumability and progress; parallelism is across tenants, where
the chains are separate. That is a real ceiling on throughput and it is the
price of the guarantee that makes the evidence worth having.

**Idempotency is stated twice.** One transaction per chunk, so a worker killed
mid-chunk leaves nothing half-written; and a *partial* unique index on
`decisions (run_id, client_id, asset_id)` for the case the transaction cannot
cover — a chunk that committed and a process that died before it could say so.
Partial, because determinations made by hand carry no run and must not be unique
per client and asset: a client is assessed for the same asset many times, which
is most of what a history screen shows.

**A sweep is one event, not a hundred thousand.** Bulk evaluation suppresses the
per-determination webhook and the referral-queue entry, and announces itself once
with the deltas. Otherwise a single act by a customer becomes a webhook storm
through their case system and two hundred queue items that are all the same
news. The audit row is still written per determination: what was done is never
optional, however it was asked for.

**A sweep pins its shelf, and that is a consistency decision before a speed
one.** Resolving the packs in force once per chunk rather than per pair means a
version published halfway through cannot leave part of the book on v4 and the
rest on v5 — which would produce a delta report describing two changes at once
with no way to separate them.

**A pinned tenant gets a dry run, not a sweep.** Stage 5 gives them a window to
check a new version against their own book before it applies. Recording
determinations under a pack they have not adopted would put evidence in their
chain contradicting the version they are actually on. So the pack-effective
trigger forks on advance policy: an auto tenant's book is re-checked and
recorded, a pinned tenant's is previewed. A dry run is the *real* evaluation
inside a savepoint that is then rolled back — not a second compute-only path,
because two paths that must agree forever drift, and the one nobody runs in
anger is the one that drifts.

**The review cadence is pack content.** `periodic_review_days` — 90 for AU and
HK, 180 for EU and SG — because how often a book should be re-examined is a fact
about a regime rather than a number in our scheduler. A pack that declares none
is not reviewed periodically, which is a legitimate answer rather than a default
to invent.

**The delta report is a document, and its scope is pack content too.** Stage 7
put a document's scope in `artefact_scopes`; this adds a third value, `run`,
beside `period` and `decision`. The first version of this hardcoded a
`RUN_KINDS` tuple and bolted a parallel mechanism onto a codebase that already
had the right one.

**The benchmark.** §S8 asks for a 100k-pair batch "within benchmark" without
saying what the benchmark is. Ten minutes — 167 pairs per second — because a
whole-book re-check is a scheduled, off-request act that somebody starts and
comes back to. Measured on a real book rather than extrapolated: 383 pairs per
second, so a hundred thousand pairs is about four and a half minutes. Two
changes account for most of it, and both are asserted so a later refactor cannot
quietly undo them: the shelf pinned per chunk, and one baseline query per chunk
rather than one per pair.

That second one was a real defect rather than a tuning opportunity. The first
version read every historical determination for the chunk's clients and reduced
in Python — correct, and quietly unbounded: a client assessed daily for two
years brings back seven hundred rows to answer one question. It surfaced as a
benchmark that sank as the test database filled, which is how it would have been
noticed in production a year late.

**Four tests that could not fail.** Each gate proof was checked by breaking the
code deliberately, and most did not catch it. The lease test scaled its own kill
with the constant it was testing. The delta test could not see a baseline
compared against the run's own output, because that case only exists on
resumption. The benchmark could not see the shelf being re-read, because speed is
the wrong instrument for "this query now runs five hundred times" — that is now a
count of database round-trips. And with the baseline lookup returning nothing at
all, every delta test still passed, because a sweep of an unchanged book has no
deltas and `{} == {}` proves nothing; one now forces a change and insists the
report names exactly that client.

**The deciding rule is found across every applicable regime.** A cross-border
determination is BLOCK because *some* applicable pack said so, and it is
routinely not the licensee's own — every AU rule passes and Hong Kong's
loss-capacity rule is what bit. Reading only the governing pack's results
returned a delta report that said a client moved to BLOCK with no rule beside
it, which is precisely the question a regulator asks next.

Open, owed by others: nothing new. The illustrative-content caveat on `/packs`
applies to `periodic_review_days` like everything else in them.

---

### 2026-08-24 — Product Stage 7: artefacts and returns at scale

The stage where documents stop being something the API does while a caller waits,
and start being things that can be accounted for.

**A document is a function of the facts, and nothing else.** §S7's gate is that a
regenerated return is byte-identical for the same period and pack version, which
is a claim about the *absence* of every hidden input a renderer usually has.
WeasyPrint 69 turned out to embed no creation date, no modification date and no
document id — checked rather than assumed, and asserted in a test so a version
bump that starts stamping the clock fails loudly. The remaining hidden input was
ours: `Generated 24 August 2026 at 12:03 UTC` in the footer. It is gone. The
document says what it is *of*; when it was produced is recorded against the
artefact row, which is where a fact about the act of producing it belongs.

**The font timestamp is pinned, and finding out why took four attempts.**
WeasyPrint subsets embedded fonts through HarfBuzz, and HarfBuzz stamps the
current time into the `modified` field of every subset's TrueType `head` table.
So two renders of *identical* markup that straddle a second boundary differ — by
one byte, inside a compressed stream, in a font nobody wrote. On a fast machine
both renders land in the same second, so it reproduced only on CI, and three
earlier explanations (a later override, differing glyph coverage, the platform's
font stack) were each consistent with the symptom and none was it.
`SOURCE_DATE_EPOCH` is the reproducible-builds convention both HarfBuzz and
fontTools honour; it is set to zero at import, before anything renders, because
the libraries read it when they subset. Zero rather than a plausible date: a
synthetic timestamp that looks real invites somebody to read meaning into it.

Two things came out of the investigation and are worth keeping. The determinism
test now renders *several real documents*, including an overridden and a
cross-border one — the first version rendered a paragraph and passed on Linux
while every real document failed, and the second rendered the newest
determination, which happens to be a plain ALLOW. And `NotDeterministic` now
reports which PDF object differs, decompresses both streams, and says whether
the content or only its compression changed; "different bytes" is not a lead.

**Branding is an input to the bytes, and the figures are too.** Both were found
by tests failing that were expected to pass. A firm that changes its trading name
legitimately produces a different document from the same determination; so does a
return regenerated after another determination landed in the period —
`AU:2026-Q1:all` names a *query*, not a result. Without somewhere to record what
the bytes were a function of, "the renderer started reading the clock" and "the
inputs changed" are the same observation. Hence `inputs_hash` beside
`content_hash`, and a `NotDeterministic` refusal only when the inputs really were
identical.

**Tenant branding is a name and contact details and nothing else.** Statutory
titles stay pack content: a firm that could retitle its own Target Market
Determination would be filing a document whose name it invented. Tested against a
tenant config that tries.

**A hundred documents is not a request.** The queue is a Postgres table, per
§S7's "no Redis/Kafka until measured need", and that is not a compromise:
`FOR UPDATE SKIP LOCKED` is exactly the claim primitive, row-level security
already prevents claiming across tenants, and the job and the artefact commit
together — which no broker offers, and without which "rendered but still pending"
is a state somebody reconciles by hand. Measured: 100 accepted in 0.216s with
`/health` answering in 6ms behind a full queue, drained in 19.8s. The test
asserts the structural claim — the renderer is replaced with one that raises —
because a timing assertion would test this machine's load.

**One document stays synchronous.** Somebody is watching a screen, three hundred
milliseconds is a spinner, and the three-tap demo's third tap is that path.

**The worker renders as the person who asked**, not as itself. "Who generated
this document" means who wanted it. Scheduled renders with no requester are
attributed to a provisioned machine principal, for the reason Stage 6 learned
about bare strings that name nobody.

**`artefact.ready` and `artefact.failed`.** §S7 asks for returns delivered to
console and webhook; the console half is the queue screen. The failure event
matters more and fires only once retrying has stopped — announcing a failure and
then producing the document teaches an integration to ignore us.

**The certificate and the export make different claims, deliberately.** The CSV
is `audit_events`: append-only at the database level and not hash-chained. The
certificate is `decisions`: every link recomputed from the tenant's anchor when
asked. Recomputed rather than stored, because a stored "verified" is a claim
about a moment that has passed and the moment it goes stale is the moment it
matters. A broken chain is a 200 with `verified: false` — the endpoint worked and
the answer is the finding; an error status would put the most important result
this system can produce into somebody's retry logic.

**Which documents exist is content.** §S7's own words are "return formats are
pack content, engineering is the pipeline", and it was not true: a kind was a
tuple in the renderer and a list in the API. A pack now declares
`artefact_scopes` beside its templates and titles, and a pack that says nothing
keeps the behaviour it had.

**`artefacts/render.py` became `renderer.py`.** The package exports a function
called `render`, which shadowed the module — `artefacts.render` meant one or the
other depending on how you reached it, including for pytest's own monkeypatch
resolution.

Three defects found by running it:

1. A failed render rolled back the attempt counter with the work, so a job that
   could never succeed would have retried forever. The claim is now committed
   before the work starts, which also ends the row lock.
2. `POST /artefacts/batch` was shadowed by `POST /artefacts/{kind}`, which
   matches first and answers 422 about a missing `decision_id`.
3. `make artefact-worker` failed all hundred jobs with a dlopen error: the
   target did not set the library path WeasyPrint needs on macOS.

Open, owed: two of the documents §S7 lists are not built. Disclosures and
acknowledgement records need a source of truth for the acknowledgement itself —
a client-facing capture flow this product does not have — and inventing a record
of a client agreeing to something would be the worst thing in this repository. A
periodic decision summary is, in content, the distribution return under a
different title; a pack can declare it today without a code change, and what it
needs is a specialist deciding what it should say. Both are recorded in
`post-raise.md`.

---

### 2026-08-24 — Product Stage 6: watch to production

The stage where the watch service stops being a demonstration of cadence
machinery and becomes something a firm could rely on — and, more importantly,
where three claims that were previously arguments about code become properties
of the deployment.

**Live mode reaches publishers that say how to be read.** A source's `url` is a
landing page: what a human opens. Live polling needs a feed, so a source
declares one in pack content or it has no adapter. ESMA's is declared because it
was fetched and parsed before being written down; ASIC, MAS and the SFC expose
no feed at the URLs their packs name, so those sources are reported as *content
gaps* rather than outages. That distinction is the whole design: paging a
specialist because we never wrote the adapter would be telling them their
network is broken when it is our backlog.

**A failed check is not a check.** `last_checked_at` is not advanced by a
timeout. A source dark for a month showing as freshly checked is the single most
misleading thing the currency screen could say.

**A source that has gone dark is never shown as CURRENT.** Freshness is derived
from the last *successful* check, so a source that failed yesterday still sits
inside its cadence — on a monthly source that is a green badge on a dead feed
for a month. Found by looking at the screen, not by a test failing.

**Alerting fires once per outage and stays loud in every other way.** An alert
every ten minutes is one that gets filtered into a folder nobody opens; silence
after the first page is how an outage gets forgotten. So the page is sent once,
the breach keeps showing on the screen, and the sweep keeps exiting non-zero
until the source answers. Three exit codes rather than two: 0 for a clean sweep,
1 for a sweep that could not run, 2 for one that ran while a publisher is down —
the second is ours and the third is theirs.

**Source owners are role addresses, not people.** `content-au@quolin.example`
rather than a named specialist. A named person leaves and the alert still has to
land; a regime's monitoring is owned by a desk. The addresses are illustrative
like everything else in `/packs`.

**The watch service has its own database role, and it cannot write a pack.**
Not "does not" — `quolin_watch` is not granted INSERT, UPDATE or DELETE on
`packs`, so Postgres refuses before any code of ours is consulted. This replaces
three good arguments (a guard script, a signature check, an import boundary),
each of which is a statement about code that somebody with a shell can edit.
`test_watch_role.py` proves it by connecting as the role, and asserts the three
attributes that would make every grant decorative — superuser, BYPASSRLS, table
ownership — because a role with BYPASSRLS reads exactly like one being filtered.

**The watch task holds no encryption key.** The sweep touches no encrypted
column, so a compromised watch task cannot read a client name, a decision
snapshot or a webhook secret even holding a database connection.

**A scheduled task rather than a daemon.** Cadence is pack content; a
long-running service would need its own timer, and that timer would be a second
place for cadence to live and disagree.

**The guard script became a deployment fact**, as §S6 asks. It now fails if the
watch task carries an owner or application connection string, if it is given an
encryption key, if it disappears from the infrastructure, if a model client is
imported outside `assist.py`, or if the API task is handed a model credential.
Every one of those was verified to fail it.

**The LLM boundary is a code path, a credential and a grant.** A model
summarises a publication and says whether it looks relevant. Its entire
authority is `assist.apply`, which returns a boolean and a sentence — there is
nowhere in that signature for a tier or an outcome to go. The tier is computed
from pack vocabulary, written, and *then* the model is asked. Uncertainty
escalates and never settles: no confidence score makes an item quieter, because
a false positive costs thirty seconds and a missed rule change costs a
remediation programme. Every call is retained in full in an append-only table.
`docs/llm-boundary.md` is the page for a diligence reader; it names the files.

**Confidence is stored as whole percent, an integer.** Invariant 3 is about
money and basis points, but the habit is worth keeping where it costs nothing —
and the exact value the model returned is in the retained output verbatim, which
is the copy that matters.

**The currency screen is scoped to the regimes a customer is licensed in**,
declared in tenant config rather than derived from their book: a firm licensed
in Singapore with no Singaporean clients yet still needs to know when the MAS
changes something. A tenant that has declared nothing sees everything — not
nothing, because a screen reporting perfect currency while watching no regimes
is the worst answer available. The demo firm is AU/HK/SG, which is what makes
the scoping visible rather than theoretical.

**A machine principal for the scheduled sweep.** Its audit rows named the string
"schedule" first, which is not blank and names nobody — the bar Stage 2 deleted
the shared placeholder officer for. `test_attribution` caught it within the
hour. The sweep is now a provisioned `api_clients` row whose secret is hashed
from a value that is thrown away: nameable and reviewable, holding nothing
anybody could present.

Three defects found by running things rather than by the suite:

1. The sweep entered the tenancy context around a transaction that had already
   begun, so `app.tenant_id` was never bound and row-level security refused the
   audit row a page writes. Every outage would have gone unannounced. The test
   that now covers it runs the real script.
2. `drafts.sign` refused any status but DRAFT while the lifecycle table has
   always allowed SIGNED from IN_REVIEW — so the submit step Stage 5 added made
   a draft unsignable through the workbench. Signing had tests; submitting had
   tests; nothing walked the pair.
3. `test_webhooks.py` froze its clock at a hardcoded instant that happened to be
   today's date. It passed all morning and six tests began failing at noon UTC,
   for reasons that had nothing to do with webhooks. Replacing it with an
   import-time `now()` moved the failure rather than fixing it.

Open, owed: the AU specialist authoring and signing a real AU pack version
end-to-end in the workbench (W2 × S5) remains outstanding from the previous
stage. Live polling reaches one real regulator; the other three need feed URLs
that somebody has verified, which is content work rather than code.

---

### 2026-08-24 — Product Stage 5: pack lifecycle and the workbench

The stage that turns "a draft has a status" into a content pipeline four
specialists can live in. Three of the four gate items are met in code and
verified by tests; the fourth is the AU specialist's to perform and is now
unblocked.

**Six states, not the five §S5 names, and the extra one is Stage 2's doing.**
The document lists DRAFT → IN_REVIEW → SIGNED → EFFECTIVE → SUPERSEDED. Stage 2
split signing from publication, because a signatory who can put their own
signature into force is one person agreeing with themselves. So PUBLISHED sits
between SIGNED and EFFECTIVE: signed content is attested, published content is
scheduled, effective content governs. Collapsing them to match the document
would undo the two-person rule the previous stage exists for, which is the
wrong way round — the spec named the states before separation of duties was
built.

**The transition log is append-only in the database, not by convention.**
`pack_draft_transitions` has the same trigger-plus-revoked-grant treatment as
`decisions` and `audit_events`. "Who moved this, when, from what to what" is
worth nothing if a later row can be edited to say something else.

**Two states nobody performs.** EFFECTIVE and SUPERSEDED happen because a date
arrived. A state that changed silently at midnight with no row to show for it
would be a hole in the middle of an otherwise complete log, so `make settle`
records them, works out what should have happened by now rather than what
changed since it last ran, and is safe to run twice.

**A signature attests to bytes, not to a version number.** `sign()` captures
`content_hash` — SHA-256 over the canonically serialised body. "They signed v4"
stops being an answer the moment somebody asks what changed between the
signature and what went live.

**Pinned is the default advance policy, and that is the safe choice rather than
the convenient one.** §S5 requires per-tenant `auto` or `pinned + UAT window`.
A firm that has not chosen has not agreed to rule content changing under them
without a look, and an unrecognised value in config is read as pinned rather
than auto — a typo must not be the reason a firm's rules moved. The window is
14 days by default: a fortnightly compliance meeting plus a few days.

**An overdue window does not advance itself.** The countdown going red is a
prompt, not a timer on somebody else's decision. A version that applied itself
because nobody clicked would be pinning in name only.

**The policy is copied onto each advance row rather than read back from the
tenant.** A firm that switched from pinned to auto last month did not thereby
change what happened in March. Deriving it from the current setting would let a
report rewrite its own history.

**Declining requires a note and is not a fork.** The reason is the whole value —
it is the thing that gets escalated. What a decline is not is a private copy of
the rules: there is one pack, and a firm that will not take a version stays on
what they have and has a conversation to have.

**Provenance is all four fields or none.** §S5 asks for source document,
section, verified-by and date recorded as data rather than comments. The
validator refuses a partial set, because three fields out of four reads as
sourced and is not — the missing one is always the one somebody would have
checked.

**The rule editor is read-only over predicates, deliberately.** The workbench
renders conditions as sentences, and thresholds, provenance and metadata are
editable. Free-text predicate editing is not built: the DSL is the thing every
determination is made through, and a screen that lets a non-programmer author
one needs a structured builder rather than a text box. Recorded in
`post-raise.md` rather than half-built here.

**Live validation caught a gap the test suite had not.** Typing `5.5` into a
threshold field produces the *string* `"5.5"`, which the float check could not
see. The validator now rejects a numeric-looking string in a numeric position
as well as an actual float — invariant 3 is about the value, not about its
Python type.

**The artefact preview renders HTML and stores nothing.** Invariant 8 makes
artefact titles and templates pack content, so a specialist can change what a
regulator receives without touching a rule. The preview runs the draft's own
templates against a real determination — placeholder text would show the
template's shape and hide every question worth asking. Nothing is written: a
preview that left an `Artefact` row behind would put an unsigned pack's output
into the evidence store, indistinguishable from one somebody meant to keep. The
PDF pipeline is not re-run for it, because nobody is filing a preview.

**`tenants.config` gained a column-scoped grant rather than a blanket one.**
Migration 0002 revoked UPDATE on `tenants` deliberately: a request that could
update that table could change its own `id`. Advance policy lives in `config`,
so 0012 grants `UPDATE (config)` and nothing else. Verified both ways — writing
`config` is allowed, writing `id` or `name` is still refused.

**Migration 0012 refuses to downgrade.** It creates an append-only trigger, and
the migration linter refuses a downgrade that drops one — correctly. Following
0001's precedent, `downgrade()` raises.

Verified rather than assumed, per the gate: future-dated effectivity already
worked (`test_a_future_dated_pack_changes_nothing_today`), and signing already
required a fresh credential per Stage 2.

Open, owed: **the AU specialist authoring and signing a real AU pack version
end-to-end in the workbench** (wall-clock convergence point W2 × S5). The path
is built and exercised by tests and by hand; what is missing is the specialist
doing it on real content. Until then every number in `/packs` stays labelled
illustrative.

---

### 2026-08-24 — Product Stage 4: integrations

The stage where the typed interfaces the prototype mocked get implementations a
customer's engineer can connect to. Three of the four gate items are met; the
fourth is Vova's to perform and is now unblocked.

**A machine is a principal, and a confined one.** An OAuth2 client-credentials
grant has no person behind it — nobody typed a password, nobody can be asked what
they meant — so `api_clients` is its own table rather than a row in `users`.
Putting machines in the staff list would have put entries in the quarterly access
review that no reviewer could answer questions about, and made "every action is
attributable to a person" quietly false.

- **One session table, two kinds of principal.** A JWT was the obvious wrong
  answer: it cannot be revoked without building the server-side list
  `auth_sessions` already is. A separate `api_sessions` table was the tempting
  wrong answer: it would have duplicated expiry-on-read, the idle timeout, token
  hashing and `revoke-all`, and the machine copy is the one nobody notices has
  gone stale. So: one nullable column, and `revoke-all` now revokes integrations
  too — which is what a customer would assume that button did.
- **What a machine may not do.** Nothing in the route table gives a credential
  `approver`, `pack_signatory` or `tenant_admin`. Those cover acts a regulator
  wants a name against, and a machine cannot be asked why it approved an
  override. Stage 2 spent a whole stage making every action attributable; a
  machine principal that could approve its own override would have undone it.
- **`/auth/revoke-all` refuses a machine outright.** It is open to every role
  because somebody whose credential has just leaked needs it before they can find
  an administrator — a decision about *people*. An integration doing it would
  sign every employee out, turning a leaked integration secret into a denial of
  service. The check is in the handler rather than the route table for the same
  reason the separation-of-duties rules are: the table classifies by role, and
  this is a fact about what kind of principal is asking.
- **A credential that has acted is never deleted.** Stage 2's rule about users,
  unchanged: the audit trail names it, and a trail with a dangling actor is worse
  than one naming something retired. The foreign key on `auth_sessions` states
  the real revocation order — tokens first, then the credential.

**`include_router` would have shipped `/v1` invisible to every guard.** This
version of FastAPI wraps an included router in an `_IncludedRouter` rather than
flattening its routes into `app.routes`, and every guard here reads a flat table:
the default-deny middleware's `_matched_route`, `_declared_routes`, the RBAC boot
check, and the generated walk in `test_auth.py`. All four saw nothing. Twelve
endpoints would have served traffic while absent from the permissions table and
skipped by the test that exists to catch exactly that. Caught because the route
count came back zero. The routes are appended directly now, with the reasoning
written where the next person will hit it.

**Webhooks: out of band, signed, and dead-lettered visibly.** `enqueue` writes
rows and returns; nothing in a request path opens a socket, because a
determination must not fail or wait because a customer's case system is down.
Six attempts over about half an hour, then the delivery stays in the log marked
`dead` with its last error — a silently dropped alert is worse than one that
never existed, because the customer believes they are being told.

- The timestamp is inside the signed material rather than beside it. A signature
  over the body alone is replayable forever by anyone who captures one, which for
  a decision webhook means replaying last year's ALLOW at a case system today.
- **A notification can never fail the thing that caused it.** The decision has
  been written to an append-only chain; telling somebody is a separate obligation.
  If enqueueing raised, a determination already recorded would appear to fail to
  its caller, and the client would retry and record it twice. Caught, and audited
  rather than swallowed — a notification nobody was told about and nobody recorded
  failing is how a customer discovers months later that they were never told.

**Batch: partial success, and this is the one place it is right.**
`/import/clients` stays all-or-nothing because a person previewing their own file
wants to fix it and re-send. A nightly drop has nobody watching at 02:00, holds
four thousand rows, and rejecting all of them because eleven are malformed takes
a firm's whole book stale over one bad date. Whole-file problems stay whole-file:
a missing header is one problem, not four thousand.

The SFTP transport and PGP at rest are deployment configuration described in
`docs/integrations.md` rather than Python. A gateway that shelled out to an SFTP
daemon would be a gateway nobody could test.

**`dollars_to_cents`, and an argument I had wrong.** Firms send dollars;
invariant 3 needs integer cents. The first version of that module claimed
`float("25000.50") * 100` fails. It does not — a half is exactly representable.
The real failures are ordinary amounts: `int(float("19.99") * 100)` is 1998 and
`int(float("0.29") * 100)` is 28. That is the worst pattern a conversion can fail
in, because it is right on the amounts somebody checks by hand and wrong on the
ones a book is full of, and nothing says so until a determination is replayed.
Corrected in the module, in the test, and in the control that proves it.

**The snapshot records where the positions came from.** §S4 asks for it by name.
"10% concentration, from custody" and "10% concentration, because nobody has told
us otherwise" are different findings, and a regime may reasonably refer rather
than allow on the second — so it is inside the frozen snapshot and a replay
reproduces which one it was.

**Two guards were wrong and both are fixed.** `lint_migrations.sh` matched the
word "real" in a docstring — twice, on "a real integration" and "revocation is
real" — and told me to reword prose. A guard that does that is one people route
around, and the next thing they route around is a violation. It now requires DDL
context on the same line; all six kinds of genuine float column are still caught,
verified by probe. `test_rbac.py` was right where I was wrong: I narrowed three
GETs on the reasoning of "who would want this", and the existing test asserts a
better principle — reading is open to the firm, and what separates the roles is
what they can make happen.

**Gate.**

1. **Webhook delivery survives a dead endpoint** — met. Retries, backoff, then
   dead-lettered visibly in the log and readable at `/v1/webhooks/deliveries`.
2. **A malformed batch file produces row-level errors, not a failed run** — met.
3. **Demo tenant still runs on fixtures, still labelled** — met, and tested. This
   is the only gate item about something *not* changing, which is why it needed a
   test: the natural next step after building a working gateway is to point the
   demo at it.
4. **An external integrator onboards a synthetic book via API and via batch,
   following only the OpenAPI docs** — **owed, and it is Vova's to perform.**
   Everything it needs exists: `/v1`, `docs/integrations.md`, a generated
   `docs/api/openapi.json` and a runnable Postman collection whose token request
   stores its own token. `make api-docs-check` is in the ladder so the contract
   cannot drift from the API.

**Custody read adapters are not built, and that is a decision rather than an
omission.** §S4 says to select vendors by the first customers' actual stacks,
with the decision recorded here. There are no first customers, so there are no
stacks to select against — naming two vendors now would be inventing the input
the decision is supposed to be made from. What is built is the half that does not
depend on it: positions supplied by batch or attested manually, with the source
recorded in the snapshot.

Verified: 667 tests pass, `make ladder` green, the suite passes twice without
reseeding, and the API was walked end to end against a live server as an
integrator would — 401 without a token, credentials to token, idempotent client
upsert and idempotent evaluation returning the same decision id twice, cursor
paging across two pages, a bulk call with one bad pair reporting 2 evaluated and
1 failed, a replay reproducing with the chain verified, and 403 on override,
sign and revoke-all.

Deferred, recorded in `docs/post-raise.md`: asynchronous processing for very
large uploads, PGP and SFTP as deployed infrastructure, mapping transforms for
dates and enumerations, and a self-service console for credentials and webhook
endpoints.

---

### 2026-08-24 — Product Stage 3: engine hardening

The stage that turns "we wrote our own rules engine" from a liability in a
diligence conversation into the answer. `docs/dsl-spec.md` is the document that
goes to the four specialists and to technical diligence; everything else here is
what makes it checkable.

**The missing-data rule was specified and not implemented.** §S3 words it
precisely — an absent snapshot field produces REFER with `DATA_MISSING` and the
field named, never a silent pass and never a crash — and none of it was true.
`_walk` raised, the exception escaped `evaluate_snapshot`, and an imported client
with an unrecorded field would have returned a 500 to whoever was looking at the
screen. It now refers, names the field, and ignores the rule's own `on_fail`: a
rule that would block is not entitled to block on a fact nobody has established.

- **The subtler half is `applies_to.when`.** If the applicability condition
  cannot be evaluated, answering "the rule does not apply" is a silent pass —
  which is the exact failure the whole rule exists to prevent. A missing field
  there refers too.
- **Present-and-null is not missing.** `knowledge_assessed_days_ago` is null for
  somebody never assessed, which is a fact the snapshot records rather than a
  hole in it. A system that referred every never-assessed client for missing data
  would be refusing to answer the question it was built to answer.

**`dsl_version` is a live arrangement, not scaffolding.** It records which
version of the *language* a pack's rules are written against, separate from the
pack's content `version`, and the engine dispatches on it. The temptation was to
ship one version and a dispatch mechanism nothing exercises. Instead
`packs/au_v1.json` stays a version-1 pack: it is loaded by every seed, Harold
Bell's 2025 determination replays under version-1 semantics on every test run,
and it keeps the raising behaviour that version 2 replaced. Bumping it in place
would have been a retroactive change to historical content, which is the precise
discipline the field exists to enforce.

A pack that does not declare a version is read as version 1, never as the newest
— every pack authored before the field existed was written against version 1, and
defaulting forward would silently re-interpret them. A pack declaring a version
the engine does not have is refused at load, with a message saying the engine is
behind rather than the pack ahead, so nobody edits the pack downwards to make the
error go away.

**Derived values are a registry, which made everything else possible.** They were
computed inline in the snapshot builder and named by string, so a pack naming one
that did not exist failed at evaluation with a message about a Python dictionary.
Each now carries its unit, the fields it reads, and a sentence a non-programmer
can check against a regulation — which is what `docs/dsl-spec.md` is written from
and what `test_dsl_spec.py` asserts it has not drifted from.

**Validation runs where content enters, not on every read.** The seed and the
publish endpoint; never during a determination, because a pack already in force
that started failing validation would take every determination in that regime
down rather than telling somebody. Not inside `watch.drafts`, either: invariant
6's guard forbids the drafting service from importing the engine at all, and that
guard is right — a narrower rule ("may import the validator but not the
evaluator") is one somebody widens. The handler that already knows about both
halves does the check.

**Five defects found by the machinery this stage added.** Worth listing, because
they are the argument for having built it:

1. **`rule_applies` read the snapshot by subscript.** `snapshot["asset"]["class"]`
   and `["structural_flags"]` were the last two places bypassing the missing-data
   machinery, so a snapshot lacking either raised `KeyError` out of the evaluator
   and into the caller as a crash — past everything that had just been built to
   prevent exactly that. The fuzzer found it on its first run.
2. **A malformed condition raised `KeyError`, not `PackError`.** An exception that
   reads to every caller as a bug in the engine rather than a fault in the pack.
3. **A decimal threshold nobody read was not a fault.** The evaluator refuses a
   float when it reads one, so an unread one sat in the table producing ordinary
   determinations — waiting for the rule that reads it next quarter, written by
   somebody with no reason to look at the number's type. The property suite
   generated exactly that pack.
4. **A rule reading a field that never exists loaded cleanly** and referred every
   determination for missing data. Right for an absent fact, wrong for a typo.
   `SNAPSHOT_FIELDS` now declares what exists, with a test comparing it against
   what `build_snapshot` actually builds so it cannot drift.
5. **One property test was a tautology.** It asserted the outcome against the same
   function the engine had just used, so it could not fail; a deliberate mutation
   of `worst_of` sailed past it and was caught only by the shuffle test. The
   severity order is now spelled out in the test.

Two of the fuzzer's early failures were the *test* being wrong rather than the
engine — an orphaned reason code damages the explanation rather than the outcome,
and removing a field no rule reads correctly changes nothing. Both are recorded
in place, because a test that demands the wrong thing is worse than no test.

**Benchmarks are budgets, not baselines.** p99 measured at 1.18ms against a 50ms
budget, and 100,000 evaluations projecting to five seconds against ten minutes. A
benchmark that compares against a stored baseline fails on a noisy runner and on
the day the fleet changes, and a benchmark that cries wolf is one somebody
deletes — so these fail on an order-of-magnitude regression and nothing smaller.
The batch number is extrapolated from a real sample and says so, with a test
asserting the engine accumulates no state between evaluations, which is what makes
the extrapolation sound rather than convenient.

**Two gate items are owed, both for the same reason as Stage 2's.**

1. **The nightly replay does not run against staging**, because staging does not
   exist. `scripts/nightly_replay.py` works and is scheduled daily against a
   database the job seeds itself; the step to change is marked in
   `.github/workflows/nightly-replay.yml`. The injected-mismatch half of that gate
   item *is* met — `--inject` breaks a decision in memory and the run fails if the
   mismatch is not caught, which is asserted in CI and in the suite.
2. **The DSL spec has not been reviewed by the AU specialist.** That is a W2
   wall-clock touchpoint and the engagement has not started. The document is
   written for the review and names what it wants signed off — that a
   non-programmer can review a pack — but nobody qualified has said so.

Verified: 558 tests pass and 4 benchmarks skip outside CI, `make ladder` green,
`npm run build` clean, `make seed` rebuilds from zero, and `make nightly-replay
ARGS=--inject` reports 129 decisions reproducing with the chain verified and the
injected mismatch caught.

Deferred, recorded in `docs/post-raise.md`: unit checking between a calc and the
threshold it is compared against, a pack-authoring linter a specialist can run
outside CI, and mutation testing of the engine.

---

### 2026-08-24 — Product Stage 2: identity and access

The shared passcode retires. Every action is attributable to a person, every
permission to a role, and the two-person rules a regulator expects are enforced
in code rather than described in a policy document.

**The passcode is deleted, not disabled, and a grep in CI proves it.** §S2 words
the gate that way deliberately and it is the right bar: a passcode that is merely
unset still has a code path, and a code path that exists is one somebody
re-enables for a demo. `scripts/guard_no_shared_passcode.sh` fails the build on
the constant, the helpers, the exception it raised, and the bare word used as a
key or an assignment. `api/app/auth.py` kept only what was already right — the
opaque cookie, the server-side hash, expiry enforced on read — and deciding *who*
somebody is moved to `api/app/identity.py`.

- **A person is not tenant-scoped, and that exception is load-bearing.** §S2 says
  a user may hold different roles in different tenants because consultancy users
  will. A `tenant_id` on `users` would force one row per firm, which means one
  password per firm, which is the shared-credential problem again wearing a
  different hat. Visibility comes from `user_roles` instead: a firm sees a person
  exactly when it has granted them a role, enforced by the `user_reachable`
  policy in migration 0007 rather than by a `WHERE` clause anybody can forget.
- **Row-level security on the identity tables is containment, not the
  authentication boundary.** Sign-in has to read a password hash before it knows
  who is reading it, so `app.login_email` makes exactly one row readable for
  exactly one statement, and `app.user_id` takes over from there. Migration
  0009 adds the federated twin for OIDC. What this buys is that an injection in
  an unrelated handler cannot enumerate a firm's staff. What it does not buy is
  protection from an attacker who could call `set_config` directly — the thing
  that stops them is that both settings are written in exactly two places, from
  values this process resolved itself, never from a request. Said here because a
  diligence pack that claimed otherwise would be overstating it.
- **Separation of duties is about people, not roles, and needed both halves
  tested.** `test_rbac.py` asserts the route table; no route table can say
  whether *this* person signed *this* draft. So each pair in
  `test_separation_of_duties.py` is written twice — once with two people
  asserting the act goes through, once with one person doing both halves
  asserting it does not — and the refusing case grants the operator an approver
  role for the length of the test. Nobody in the seed holds both, and a rule only
  ever exercised against people who cannot reach it is a rule nobody has tested.
- **The placeholder actor is gone, and the audit trail is checked against
  `users`.** `audit_events.actor` said `demo.officer` on every row, which is the
  worst property an audit trail can have: not a gap, a gap wearing a name.
  `service.audit` now reads the actor from the ambient scope and raises
  `Unattributed` rather than inventing one. `test_attribution.py` resolves every
  actor the suite produces against `users`, so an endpoint added next month that
  writes an unattributed row fails without anybody remembering to extend it.
- **The seed writes what the application writes.** Fixing the placeholder
  surfaced three latent breaks in `api/seed/seed.py` — it still passed an
  `actor` to `service.evaluate` and to `service.audit`, and it signed the HK pack
  with an invented name and published it with nobody in scope, which `publish`
  now refuses. The seeded history is recorded as Dana Whitfield, the overrides
  are approved by Marcus Oyelaran, and the HK pack is signed by Aoife Brennan and
  put in force by Ruth Castellanos. The two invented compliance officers who
  existed nowhere but a Python list are gone. The demo's one artefact on the
  shelf has now passed the same gate everything else does.

**SSO is OIDC against a broker, and the SAML claim is worth stating exactly.**
§S2 asks for "OIDC first, SAML capability present". Quolin speaks OIDC to a
WorkOS-class broker; the broker speaks SAML, Okta or ADFS to the customer. A
customer moving from Okta to Entra is a change to their tenant configuration at
the broker, not a release of ours. That is what the capability is, and
`docs/deployment.md` says it in the same words so the sales conversation and the
code agree.

- **It authenticates; it does not provision.** A subject this deployment has
  never seen is refused, and no account is created for them. On a first federated
  sign-in the provider's `sub` links to the account already holding their
  *verified* email, so people keep their roles, their history and their name in
  the audit trail. An unverified `email` claim is never honoured: at a provider
  that lets a user set any address on their own profile it is a text field, and
  honouring one would let anybody with an account there claim any account here.
- **The stub identity provider is a real server, not a mock.**
  `api/tests/stub_idp.py` runs on a loopback port and signs real RS256 tokens
  with a real key pair, so `app/oidc.py` has no branch that exists only for
  tests. That is what makes the negatives worth having: `test_oidc.py` walks a
  token signed by an unpublished key, `alg: none`, a `nonce` from another login,
  an audience belonging to another client, an expired assertion, a missing state
  cookie and a mismatched `state`. Each of those is a published authentication
  bypass in somebody's hand-rolled verifier, which is also why ID-token checking
  is handed to PyJWT with the algorithm list pinned rather than read from the
  token.
- **A federated session is not treated as freshly re-authenticated.** Whether the
  provider demanded a second factor is its policy and is not visible to us, so
  signing rule content still demands a step-up here. The permissive assumption is
  the one that collects a signature from a session nobody re-proved.

**The access review is a report, not a dump.** §S2 is specific that the SOC 2
control is the report being *generated and signed off*, so `make access-review`
is one command whose output is already the document: findings first, the roster
underneath as evidence for them, a sign-off block, and a SHA-256 of everything
above it so that "the report that was signed" is a specific document. It reads as
the application role with a tenant in scope — a report assembled by a connection
that bypassed row-level security would prove nothing about row-level security —
and it changes nothing, because removing somebody's access is a decision that
needs a name against it.

- **It found a cross-tenant leak in itself before anything else did.** The first
  version reused one session across the tenant loop. `app.tenant_id` binds when a
  transaction *begins*, so the second tenant's section was assembled inside the
  first tenant's still-open transaction and printed one firm's employees under
  another firm's heading — in the one document whose purpose is showing that two
  customers cannot see each other. Every single-tenant test passed. The loop
  moved into `app/access_review.py` where a test can reach it, and two tests now
  assert the isolation in both orderings.
- **`MFA_REQUIRED_ROLES` is declared and enforced nowhere.** It names the roles
  that can approve an override, sign rule content or grant a role, and nothing
  reads it. Three seeded people hold those roles with no second factor. The
  review reports it and says plainly that it is the only place the constant is
  checked. Enforcing it at sign-in was not done: it is a scope addition and would
  lock the seeded demo accounts out. Recorded in `docs/post-raise.md`.

**Two gate items are owed rather than met, and neither is met by a green tick.**

1. **The access review has not been generated against staging**, because staging
   does not exist — applying the Stage 0 Terraform needs credentials this
   repository does not hold. CI generates it against the same real Postgres, real
   migrations and real seed the suite uses, and the staging job in
   `.github/workflows/ci.yml` names the access-review run as work to wire when
   `STAGING_DEPLOY_TOKEN` appears. That proves the report generates. It does not
   prove it generates against staging.
2. **The three-tap smoke test still runs locally rather than against a deployed
   staging**, for the same reason and recorded in the same place.

**The unauthenticated-route test walks more than the gate asked for.** §S2 says
the generated test walks the OpenAPI surface. FastAPI does not describe its own
`/docs`, `/redoc`, `/openapi.json` or Swagger OAuth redirect in that document —
so a walk of the documented surface alone would skip exactly the four routes that
publish the shape of every other one. The walk is generated from the live route
table instead and takes path-parameter types from OpenAPI, which covers 46 routes
including all 12 parameterised ones; the previous version hand-listed six.
`test_the_only_routes_openapi_does_not_describe_are_the_documentation_ones` pins
the gap so a *different* route going undocumented fails rather than silently
narrowing what a reader thinks is tested. And because `require_session` is
middleware and refuses before routing, a URL matching no route returns 401 exactly
like a protected one — so every URL the walk builds is first confirmed to reach a
real handler, or the whole assertion would pass against a list of typos.

**Two suite-level defects fixed on the way, both pre-existing.** The suite was not
idempotent: `make test` passed once after a seed and failed on the second run,
because the separation-of-duties tests publish real pack versions that `packs` has
no DELETE grant to remove and `test_api.py` pinned an exact version count. The
assertion now states what it means rather than counting. And `docs/deployment.md`
still told an operator the API refuses to start without `QUOLIN_PASSCODE`, while
both demo scripts told the presenter to disclaim user accounts that now exist —
all three corrected. Earlier entries in this file are dated records of what was
true when written and are left alone.

Verified: 452 tests pass, `make ladder` green (lint, mypy, suite, five guards,
tofu validate, watch tick, tamper demo), `npm run build` clean, `make seed`
rebuilds from zero, the suite passes twice in a row without reseeding, and the
three protected moments re-walked as a named person — Check (Tom Askew / SOL →
BLOCK, three failing rules), Replay (Harold Bell reproduces exactly under pack
v1, chain verified), Generate (TMD downloads as a valid PDF). The operator is now
refused the override on their own determination, which is the stage in one line.

Deferred, recorded in `docs/post-raise.md`: enforcing `MFA_REQUIRED_ROLES` at
sign-in, just-in-time provisioning from an IdP assertion, a tenant switcher for
consultants holding roles at several firms, and shared rate-limit state across
instances.

---

### 2026-08-23 — Product Stage 1: multi-tenancy and encryption at rest

The stage that makes "one customer cannot reach another's data" a property of
the database rather than of the application's good manners. Tenant model,
fail-closed row-level security, per-tenant hash chains, and per-tenant
encryption of snapshots, client PII and artefact PDFs.

**A deviation from the execution document, and the reason for it.** §S1 says
data keys are "wrapped by KMS". They are wrapped by a master key read from the
environment — `fly secrets` in the hosted instance, the Makefile's printable
development key locally. The S0 Terraform that declares AWS KMS has never been
applied, because applying it needs credentials this repository does not hold and
a state bucket nobody has bootstrapped. Writing a KMS client against an account
that does not exist would give us an untested code path and a false line in a
diligence pack. The envelope structure is the part that matters and is built:
each tenant has its own data key, the data key is stored wrapped, and the
wrapping key lives outside the database. Swapping the environment read for a KMS
`Decrypt` call is a change to two functions in `app/crypto.py` and touches no
ciphertext. That swap is gated on the account existing.

- **Rotation rewraps the key-encryption key; it does not rotate data keys.**
  `scripts/rotate_keys.py` unwraps each tenant's data key under the current
  master key and rewraps it under the new one. Every ciphertext in the database
  is untouched. The alternative — new data key, re-encrypt everything — would
  mean rewriting `decisions`, which is append-only by trigger and by revoked
  grant, and re-chaining every hash after it. A rotation procedure that
  invalidates the evidence chain is not a rotation procedure. The script's
  header says this at length so that nobody quietly extends it into the other
  thing.
- **The rotation is proven by running it, not by describing it.** §S1 asks only
  that rotation be "documented and scripted, even if never yet run". Executing
  it by hand against the dev database would have proved it once, for whoever was
  watching. `tests/test_key_rotation.py` runs the real script as a subprocess —
  same entry point, same environment variables, same exit codes — against a
  throwaway tenant, asserts the data key's bytes are unchanged across the
  rotation, and rotates back. It also asserts every refusal: a missing key, a
  short key, the key already in force, and a current key that fits nothing. Each
  refusal is a database that would otherwise have been sealed shut.
- **Encryption is a column type, not a call site.** `crypto._Encrypted` is a
  SQLAlchemy `TypeDecorator`, so a write cannot forget to encrypt — there is no
  write path that does not go through it. Every value is sealed with additional
  authenticated data naming the tenant and the column, so a ciphertext moved
  between tenants or between columns fails authentication rather than decoding
  into the wrong place. Both moves are asserted in `tests/test_encryption.py`.
- **Three artefacts of the append-only rule, in sequence.** Migration 0005 adds
  the ciphertext columns, `make encrypt-existing` fills them, migration 0006
  drops the plaintext and renames. It is three steps rather than one because
  `decisions` refuses UPDATE at two levels and `scripts/lint_migrations.sh`
  forbids a migration that disables the trigger. The same shape as
  `scripts/rechain.py`, deliberately, rather than a second pattern to learn. Dev
  needs none of it: `make seed` starts from empty and writes ciphertext from the
  first row.
- **The dev owner role is a superuser, and that nearly made the gate
  meaningless.** `FORCE ROW LEVEL SECURITY` does not apply to a superuser or to
  a role with `BYPASSRLS`. The owner role docker-compose creates is both, so a
  cross-tenant test reading through `OwnerSessionLocal` would have passed
  whether or not a single policy worked. Every isolation assertion now reads
  through `SessionLocal`, which connects as `quolin_app`, and one test asserts
  directly that the role the API holds is neither a superuser nor
  `BYPASSRLS`-granted. That test is the one everything else rests on.
- **`test_rls.py` no longer keeps its own list of tenant-scoped tables.** It had
  one, and within a single stage it had already gone stale — it had not heard of
  `chain_anchors` or `tenant_keys`. The list is read from
  `models.TENANT_SCOPED_TABLES` now, and a new test fails if any table in the
  metadata is neither tenant-scoped nor explicitly declared global. That guard
  catches the *next* table, which is the one that would actually leak.
- **Artefact PDFs render to bytes and are sealed before they touch the disk.**
  They were the last tenant data living outside Postgres. Files are filed under
  `artefacts_out/{tenant}/` with a `.enc` suffix and served from memory, because
  decrypting to a temporary file to use `FileResponse` would put a readable
  client document on disk to save copying a few hundred kilobytes.

**Operational note for any database that predates this stage.** Artefact files
written before Stage 1 remain plaintext, outside any tenant directory. The
download endpoint looks for `{tenant}/{name}.enc`, does not find them, and
returns 410 "regenerate" — the correct behaviour, and the correct prompt. But
the plaintext files do not delete themselves. They must be removed by hand once
the artefacts that matter have been regenerated. Dev is unaffected: `make clean`
removes the directory.

Verified: 304 tests pass, `make ladder` green (lint, mypy, suite, four guards,
tofu validate, watch tick, tamper demo), `npm run build` clean, and the three
protected moments re-walked against a live API — Check (Tom Askew / SOL → BLOCK
on `AU-CONC-01`, `AU-LOSS-01`, `AU-TMD-01`), Replay (both Harold Bell decisions
reproduce exactly, one under pack v1 and one under v2, chain verified over 79
records), Generate (TMD downloads as a valid PDF while the stored file is
ciphertext under `demo/`).

Deferred, recorded in `docs/post-raise.md`: ciphertext is not bound to its row
identifier, and the KMS swap.

---

### 2026-08-23 — Product Stage 0: foundations

The first stage of `quolin-prototype-to-product.html` (Execution 1.0). It adds
no capability and changes no behaviour: everything here is a gate, a guard, or a
description of infrastructure. The three protected moments were re-walked and
are unchanged.

**A correction to the execution document, before anything was built.** §3.1 and
§14 both asserted that "the loader already refuses ILLUSTRATIVE for production
tenants". It does not, and cannot: `packs_repo.py` raises only `LookupError`,
`engine/pack.py` records `content_status` and its own docstring says the engine
never asks it, and there are no tenants to refuse anything to until Stage 1.
Both passages now read in future tense and name the dependency — the refusal is
built in S1 alongside the tenant model, and the only thing that can clear the
flag is a signature captured in S5. An invariant the document believes is
already enforced is an invariant nobody goes back and enforces.

- **Strict typing is scoped to `app/engine` and `app/watch`, not to the app.**
  Those are the two modules invariant 6 separates, and they are the two whose
  behaviour has to be identical in 2031. The first attempt used `strict = true`
  in a per-module override, which mypy applies globally — it reported 179 errors
  including 47 in `app/main.py`, outside the module list entirely. The override
  now spells out the nine flags, and applies where it says it applies.
- **Ruff selects `E,F,I,B` and ignores `B008`.** `B008` is FastAPI's entire
  dependency-injection idiom — `Depends()` in a default argument is the
  framework, not a bug. `UP` was dropped for a different reason: it wanted 84
  edits across working code, 21 of them purely to spell `timezone.utc`
  differently. A lint gate whose first act is rewriting the evaluator is a gate
  nobody trusts and everyone starts passing with `--no-verify`.
- **The RLS suite and the migration linter exist now and are dormant now, and
  neither can be forgotten.** `test_rls.py` activates the moment a `tenants`
  table appears in the model metadata; `lint_migrations.sh` activates the moment
  `api/migrations` exists. Both are in CI already. A placeholder that needs
  somebody to remember to switch it on is a placeholder that ships asleep, so
  each derives its own trigger from the codebase — and `test_rls.py` carries one
  always-running test asserting exactly that it cannot sleep through Stage 1.
- **The migration linter guards the properties a migration is most likely to
  quietly undo**: re-granting UPDATE or DELETE on an append-only table, dropping
  or disabling its trigger, introducing a float or numeric column where money
  lives, and dropping `prev_hash` or `this_hash`. It was proven against eight
  sacrificial migrations, one per rule and one ordinary migration that must
  pass.
- **ECS Fargate, not Fly, for product compute.** The document asks for this to
  be decided once and written down; the reasons are all downstream rather than
  about today. Stage 1 puts per-tenant KMS keys and encrypted evidence in AWS,
  and compute outside that boundary spreads the SOC 2 scope across two
  providers. Stage 9's restore drill into a clean environment is a Terraform
  apply here and a manual exercise across providers. Stage 11 promises a
  dedicated stack from the same IaC inside a day, which works when compute is a
  variable in this module and does not when it lives in a `fly.toml` that has to
  be forked per customer. Fly stays, and stays only for the seeded sales demo.
- **Region is `var.region`, defaulting to Sydney, and CI greps for the
  alternative.** Sydney because the first buyers are Australian and "hosted in
  Sydney" shortens a vendor-risk conversation. It is a default and not a legal
  requirement, and must never be presented as one — APRA permits offshore
  hosting with safeguards, and saying otherwise in a room containing someone who
  knows that is expensive. `scripts/guard_no_hardcoded_region.sh` fails the
  build if a region literal appears anywhere but that variable's default, so a
  European customer under GDPR is one variable rather than an archaeology
  exercise.
- **Two KMS keys, split by what they protect rather than by what is convenient.**
  The app key covers infrastructure at rest — database volume, log groups, the
  secrets needed to boot. The tenant-data key covers evidence: decision
  snapshots, artefact PDFs, the encrypted PII columns Stage 1 adds. In a shared
  deployment it wraps per-tenant data keys; in a dedicated deployment the
  customer has it to themselves, which is most of what "dedicated" means to the
  person asking for it.
- **Two secrets, split by who owns the value.** One secret holding both the
  Terraform-generated `database_url` and the human-set passcode forces a choice
  between Terraform clobbering the human value on every apply and `ignore_changes`
  freezing `database_url` the first time the RDS endpoint moves. Terraform owns
  the database secret entirely; the app secret is created empty and populated out
  of band by a person. No credential this repository holds is real, and none ever
  should be.
- **Artefacts are never expired.** The bucket is versioned, KMS-encrypted and
  public-access-blocked, with a transition to cheaper storage and no expiration
  rule at all. The task role has `s3:PutObject` and `s3:GetObject` and
  deliberately not `s3:DeleteObject`. Evidence is not tidied up, and the absence
  of the permission is a stronger statement than a policy saying so.
- **`api_desired_count` stays at 1, in every environment including production.**
  Login rate limiting is per-process (`api/app/auth.py`), so a second task
  silently halves the effective lockout. Raising it before that state is shared
  is a security regression wearing a scaling decision's clothes. Phase 5 recorded
  the same constraint about `fly.toml`; it survives the move to ECS unchanged.
- **Deletion protection on the database and the load balancer, and
  `auto_minor_version_upgrade = false`.** A minor version arriving unannounced
  changes server behaviour underneath a system whose central claim is that a 2026
  decision replays identically in 2031.
- **The staging deploy job exists, is gated on the secret that does not exist
  yet, and announces its own skip.** A green tick against a deploy that did not
  happen is worse than a missing job, so it prints a notice naming this file. The
  day `STAGING_DEPLOY_TOKEN` is set, the job fails loudly until a real deploy and
  a real three-tap smoke test are wired in — setting the secret is the signal
  that the infrastructure is real.

**Written and validated, never applied.** No AWS account has been touched.
`tofu fmt`, `tofu init -backend=false` and `tofu validate` pass in CI and
locally (OpenTofu 1.12.6); a plan against a real account will surface things
validation cannot, and the first `apply` is a gate item that has not been met.
`infra/README.md` says so in place rather than leaving a reader to assume the
diagram is a deployment.

Verified: mypy and ruff clean, 255 tests passing and 4 skipped — the four
skipped are the dormant RLS assertions, and `-rs` in CI prints the reason so
"skipped" never reads as "passed". All four guard scripts pass, the API image
builds from a repository-root context, `tofu validate` succeeds, `make ladder`
green.

Owed by others, and blocking the rest of the Stage 0 gate — none of it is work
this repository can do, because all of it needs credentials or a signature:

- The repository move to the company GitHub organisation, branch protection on
  `main`, and removal of personal-account admin. `CODEOWNERS` currently names
  the only git author in the history and carries a note that the move is
  outstanding.
- Bootstrapping the Terraform state bucket by hand, then the first `apply` of
  staging. Recorded here when it happens, per `infra/README.md`.
- `STAGING_DEPLOY_TOKEN`, and the real deploy plus smoke test behind it.
- The four wall-clock engagements the document's W-track starts on day one: SOC
  2 auditor, the Australian regulatory specialist, counsel, and the penetration
  test booking. These have lead times measured in weeks and are the reason the
  document puts them on a parallel track rather than in a stage.

---

### 2026-08-20 — v2 Phase 6: demo hardening and freeze

The last phase adds no capability. It closes the gaps between what the system
does and what someone walking through it would find, and writes down the
walkthrough itself so it does not have to be improvised.

- **A cached "yes" was unlocking the app offline.** `api.session()` bypassed the
  localStorage mirror but not the service worker's `DATA_CACHE`: `isApiRequest()`
  matches any cross-origin GET, `/auth/session` included, and `networkFirst`
  serves the cached `200` when the network throws. So a device that had signed
  in once opened straight into the app with the engine down, while the comment
  above the function asserted that could not happen. The cached answer is now
  *honoured but labelled* — §9 mandates the airplane-mode demo, the gate was
  never the security boundary, and the records are already on the device — but
  `X-Quolin-From-Cache` is read and the result carries `offline`, so nothing
  renders as live that isn't. Online behaviour is unchanged, because
  `networkFirst` only falls back when the network actually fails.
- **Ten dead ends, found by walking every screen rather than by testing.** The
  representative one: `back` was a bare boolean, so it called `router.back()` —
  correct in a browser with history, a no-op on a deep link or a cold PWA
  relaunch, which is exactly how the demo starts. Back controls now name their
  destination. `/packs/[jurisdiction]` did not exist at all, so the last click
  of the currency walkthrough landed on `not-found`. An empty `catch` in the
  currency triage meant a failed action rejected unhandled and the button just
  did nothing.
- **The tamper demo is read-only, which is a deliberate downgrade.** The first
  version disabled the trigger and rewrote a row so the badge on screen would
  actually turn red. That is a script you would run minutes before presenting,
  against the database you are about to present from, and it leaves a poisoned
  record only `make seed` clears. It now demonstrates the two guarantees
  separately — Postgres refusing an ordinary `UPDATE`, then the stored hash
  recomputed with one field changed — and writes nothing. The red badge is
  covered by `test_evidence_chain.py` instead. It runs in CI, so a prop that
  gets shown to buyers fails the build rather than failing in a meeting.
- **Two guarantees, never one claim.** Decisions are hash-chained; packs,
  overrides and audit events are append-only by database trigger. Said together
  as "hash-chained and append-only" it sounds like one strong property instead
  of two ordinary ones. The chain does not prevent tampering — it makes
  tampering detectable afterwards, which is weaker, more defensible, and what an
  auditor actually asked for. `docs/demo-script.md` carries a table of the
  overstatements that are tempting in the room, each paired with the sentence to
  say instead.
- **The demo script is written from the database, not from the spec.** Every
  name, decision id, date and pack version in it was read out of the seeded
  demo state and walked in a browser. The three protected moments — Check,
  Replay, Generate — were confirmed end to end on this build: Tom Askew/SOL
  blocks on three independent rules under `AU v2`; decision 1 replays
  "Reproduced exactly · pack v1 · chain verified" with no differences across the
  45 seeded records; the TMD renders a real 61 kB PDF.
- **Walking the demo dirties the demo.** Both `make test` and a browser
  walkthrough write real determinations — the chain stood at 88 records after
  verification, against 45 from a clean `make seed`. Nothing is wrong with
  that; it is what an append-only store does. But it means `make seed` is the
  first item on the pre-demo checklist and not an optional tidy-up, or the
  dashboard opens on decisions nobody in the room can account for.
- **`scripts/tunnel.sh` is still the one path with no evidence behind it.** It
  has never been run against a real device. It is marked unproven in the README,
  in `docs/deployment.md` and now in the demo script, rather than being quietly
  listed alongside the things that have been walked.

### 2026-08-20 — v2 Phase 5: private hosting with authentication

A lock on the door, and a documented way to put the thing on the internet.
Scope is deliberately narrow, and the narrowness is stated on the screen rather
than left for someone to discover.

- **One shared passcode, not user accounts.** No SSO, no roles, no per-person
  identity anywhere. This is the whole of it, and `docs/deployment.md`, the lock
  screen and `/integrations` all say so in the same words. An override approver
  and a pack signatory remain names typed into a box by whoever holds the
  passcode — Phase 5 does not change that, and describing it as "authenticated
  approval" in a room would be the kind of overstatement that costs more than
  the feature is worth.
- **Default-deny in middleware, not a dependency on each route.** Every path is
  authenticated unless it is in `PUBLIC_PATHS`. A forgotten decorator opens a
  hole silently; a forgotten exemption breaks the endpoint loudly the first time
  anyone calls it. `test_auth.py` asserts the rule against the *live route
  table*, so a new endpoint cannot quietly join the public set.
- **Server-side sessions rather than a signed token.** A self-describing token
  cannot be revoked without building the same server-side list it was supposed
  to avoid, and revocation is the only property that matters when a laptop goes
  missing. `/auth/sessions` lists what is live and `/auth/revoke-all` ends it.
  Only the SHA-256 of the token is stored; the passcode is never stored and
  never logged.
- **`auth_sessions` is the one table that is not append-only.** Everything
  carrying evidence is; a session row must be deletable or logout is theatre.
  The distinction is asserted by a test so it cannot be "tidied up" later.
- **Logout clears two caches, because there are two.** The localStorage mirror
  and the service worker's `DATA_CACHE` both hold real client records — names,
  dates of birth, portfolio values. Page script cannot delete the second one, so
  the worker is asked over `postMessage`. Without this, "log out" would have
  meant "hide the screens and leave the data on the device", which is worse than
  offering no logout at all.
- **CORS middleware is registered outside the auth check, and the order is
  load-bearing.** The auth check short-circuits with its own 401 instead of
  calling the route, so with the layers reversed that 401 reaches the browser
  without `Access-Control-Allow-Origin` and `fetch` rejects it as a network
  error. The web client treats those two cases differently on purpose — a 401
  clears the cached records and shows the lock screen, a network error keeps
  them and says the engine is unreachable — so the wrong order turned every
  expired session into "connection problem" with client data still on screen.
  Found in a browser during the Phase 5 walkthrough, not by the suite; there is
  now a test.
- **The wildcard origin is gone.** `allow_origins=["*"]` was survivable only
  while there was nothing to authorise against. An unset
  `QUOLIN_ALLOWED_ORIGINS` now falls back to the localhost dev ports, never to a
  wildcard: in production it must fail closed and visibly.
- **Rate limiting is per-process, and that constrains the deployment.**
  `min_machines_running = 1` in `fly.toml` is therefore load-bearing — a second
  instance would silently halve the effective lockout. Scaling past one needs
  shared state first, not a higher number in a config file.
- **The scheduled watch sweep is real machinery over a fixture.** `make
  watch-tick` does what `POST /watch/poll` does without HTTP, so a scheduler
  needs no session and no copy of the passcode in its configuration. It prints
  "no regulator was contacted" on every run, because a log line reading "watch
  tick ok" for six months is how a fixture quietly becomes something people
  believe is a feed. CI runs it, so a signature change breaks the build rather
  than a cron job nobody watches.
- **Deployment requires credentials this repository must never hold.** `fly auth
  login`, `fly secrets set` and the Vercel configuration are all done by the
  person who owns the accounts. `make deploy-check` verifies the secrets exist
  before `make deploy` replaces a machine, so "you forgot to set a secret" fails
  before the deploy rather than after it.

Still not run end to end: `scripts/tunnel.sh`. It is the only path in the
repository with no evidence behind it, and `docs/deployment.md` says so in place.

---

### 2026-08-20 — v2 Phase 4: regulatory currency and watch service

Whether the packs are current is now a question the system answers rather than
one the demo asserts.

- **Freshness is derived, never stored.** `/currency` computes each regime's
  state from when its sources were last checked against the cadence its own pack
  declares, so it decays on its own and cannot be left saying CURRENT by a
  forgotten write. The consequence is that an unattended deployment drifts to
  STALE — which is the screen telling the truth about a system nobody is
  operating.
- **No watch path reaches the evaluator.** A regulatory alert must never change
  a decision without a pack version behind it, so `api/app/watch` cannot be
  imported by `api/app/engine` and does not evaluate.
  `scripts/guard_no_watch_in_engine.sh` plus AST-based tests fail the build if
  that changes. This is the second CI-enforced invariant, alongside "no
  jurisdiction logic in the engine".
- **`WATCH_MODE=live` returns 501 throughout.** There is no publisher adapter,
  and the error names every source that would need one rather than degrading
  quietly to the fixture. A system that pretends to poll a regulator is worse
  than one that says it cannot.
- **Events are triaged against the pack's own vocabulary**, and an item is filed
  against the regime it is *about* rather than the regulator that published it —
  regulators write about each other. Where no pack is held, the item lands in a
  coverage-gap tier instead of being quietly attributed to the publisher's
  jurisdiction.

---

### 2026-08-20 — v2 Phase 3: four jurisdictions and the cross-border resolver

Three more regimes on the same engine, and a determination when more than one of
them reaches the same trade. Full detail in `docs/jurisdictions-spec.md`.

- **The engine learned nothing about jurisdictions.** HK, SG and EU packs were
  added with no change to `api/app/engine`, and
  `scripts/guard_no_jurisdiction_logic.sh` fails the build if a regime code
  appears in engine code. This is the commercial claim of the whole system, so
  it is enforced by CI rather than asserted in a deck.
- **Which regimes apply is derived from the frozen snapshot, not the client
  record.** Licensee, residency and domicile are inside the hash, so replay
  selects the same packs from the same facts. That cost a second snapshot build
  — the first establishes the facts, the second adds each applicable pack's own
  asset classification — and the alternative was a cross-border decision that
  could not be reproduced once a client moved house.
- **The resolver refuses to order what the content gives it no basis to
  order.** Three refusal reasons are recorded rather than resolved:
  `no_common_scale` (HK caps a first purchase in cash, SG as a share of
  portfolio — `$2,000` and `2%` are not the same kind of quantity),
  `scale_not_orderable` (the governing pack declares no direction for the
  scale), and `single_constraint`. A fake ordering would be worse than none: a
  compliance officer can defend "both bind and neither is stricter", and nobody
  can defend a number that came from an engine's guess about which regulator is
  tougher. Partial ordering is refused for the same reason.
- **Which direction is stricter is pack content.** `precedence.scales` states it
  per scale — `lower_is_stricter` for cents, `higher_is_stricter` for band — and
  the governing pack's block is the one that applies. `qualitative` is
  deliberately absent from every pack.
- **A regime whose own rule failed binds even when its number was the laxer
  one.** A failure is not made irrelevant by someone else being stricter.
- **Findings are the union across regimes, each stamped with the pack that
  raised it.** Taking them from the governing pack alone produced the worst
  screen this system could show — a red BLOCK banner above a green panel reading
  "every applicable rule passed", true of that one pack and a lie about the
  determination it sat under. Decision 42 is an AU-governed BLOCK that AU alone
  would have allowed.
- **A jurisdiction with no pack is stated, not swallowed.** `marcus-tan` is
  domiciled in a regime Quolin holds no pack for; the client screen, the
  cross-border panel and the PDF all say that no rule from it was evaluated and
  the determination does not speak for it. A gap that is not shown is a gap
  nobody closes.
- **A bloc is one body of content, not twenty-seven.** A pack answers for a code
  that is its own id *or* appears in its `covers_states`. `match_packs` never
  names a bloc; `ingrid-halvorsen` is German and resolves to the EU pack through
  content alone.
- **Unreviewed content is labelled by every regime that contributed, not just
  the governing one.** A determination is as reviewed as its least reviewed
  input. The badge sits above the verdict on screen and above the title in the
  PDF, is non-dismissible, and is read from the pack at the version the decision
  was made under.
- **Magnitudes print in the unit the pack declared, identically on screen and in
  PDFs.** `200000 cents` and `$2,000.00` are the same number, and only one of
  them can be checked against a statement by whoever reads the evidence pack.
- **The three protected moments were re-walked by hand before merge.** Check
  (Tom Askew / SOL → BLOCK, three plain-English reasons, no jurisdiction labels
  anywhere), Replay (Harold Bell, decision 1 → reproduced exactly, chain
  verified across 58 records), Generate (TMD and evidence-pack PDFs for
  single-regime, single-regime-illustrative and cross-border decisions).

Deferred, and why, in `docs/post-raise.md`: no jurisdiction filter on the
reporting screen, and rationale prose carrying raw scale values.

---

### 2026-08-20 — v2 Phase 2b: import, and label the rest

The other half of phase 2. A CSV client importer, and the screen that says which
edges of this system are real. Full detail in `docs/import-spec.md`.

- **Preview and commit are one call.** `POST /import/clients` takes `commit`,
  defaulting to `false`, so the dangerous call is the one you have to type
  deliberately. A separate validate endpoint was considered and rejected: two
  code paths drift, and then what a reader was shown stops being what a reader
  gets. On screen, **Import** only becomes available once a validation has come
  back clean.
- **Validation is all-or-nothing, and reports every problem.** `_validate_row`
  accumulates errors across all columns instead of returning on the first bad
  one, because returning early turns correcting a spreadsheet into an iterative
  game against the validator. If any row is invalid nothing is written — a
  partial import leaves a book half in one state and half in another, and
  afterwards nobody can describe the result.
- **Decimals in a cents column are refused, not rounded** (invariant 3). The
  message names the real mistake: this column is whole cents, and `$1,234.56` is
  `123456`. A CSV is precisely where a float gets in, and rounding silently puts
  a number in the evidence chain that nobody typed. An unrecognised column is
  refused for the same reason — a column the importer drops is a field the
  author believed they had supplied.
- **Re-importing a client cannot reach backwards into a determination.**
  `clients` is deliberately absent from `APPEND_ONLY_TABLES`, because a CRM
  record legitimately changes. That is safe for a structural reason rather than
  a careful one: every decision freezes its inputs, and replay reads the
  snapshot. A test imports a client, evaluates, changes the loss-capacity band,
  re-imports, and asserts the recorded decision still replays byte-identically.
- **`/integrations` is computed, not written.** Counts of clients, custody
  coverage, audit events, artefacts and determinations are read from the running
  system, so a hardcoded "connected" label cannot go stale into a lie. The status
  chips deliberately avoid the verdict palette: ALLOW/REFER/BLOCK green, amber
  and red mean a determination and nothing else, and reusing them would make a
  mocked integration read as a compliance outcome.

Two defects were found while building and fixed rather than shipped:

- **Zero holdings and no custody record produced identical figures.** An
  imported client has no positions, and `FixturePositionsProvider.get` returned
  zero holdings for a client it had never heard of — so an exposure of 0% was
  fabricated rather than true, and the concentration rule passed for reasons with
  nothing to do with the client's portfolio. `has_record()` now answers that
  question directly. It is deliberately *not* folded into `get()`, because
  `get()` feeds the frozen snapshot and changing that shape would change what
  replay reads back for every decision already recorded (invariants 2 and 5). The
  distinction surfaces in three places: `custody_on_file` on `GET /clients/{id}`,
  a note on the client screen, and `custody_warning` on every import response,
  success and failure alike.
- **Imported clients walked onto the home screen.** Cast membership was inferred
  from `note` being non-empty, so any imported row with a note in it joined the
  six clients the walkthrough was written around. Membership is now an explicit
  `clients.is_cast` column, set by the seed and by nothing else and read through
  `DbClientProvider.cast_ids()` — kept off the snapshot dict for the same reason
  `has_record` is kept off `get`. A CSV column should not be able to grant a
  client a place in the demo.

Verified: all three demo moments re-walked by hand after the change, since the
client detail screen is one of the three. Tom Askew/SOL blocks with three
plain-English reasons carrying rule ids and pack versions; Harold Bell's
14 Nov 2025 decision reproduces exactly under pack v1, chain verified, no
differences; a Target Market Determination renders to a real PDF from
`au_tmd_v2.html`. `make test` 132 passed, run twice to prove idempotence.
`make guard` clean. `tsc --noEmit` and `npm run build` clean.

Deferred, recorded in `docs/post-raise.md`: position import, a file-upload
endpoint, column mapping and dialect detection, and client deletion.

---

### 2026-08-20 — v2 Phase 2a: reporting that is real

Phase 2 was split, and this note records the split as well as what landed.
Phase 2 as briefed carried four things: reporting, CSV import, an
`/integrations` screen, and honest labelling of what is still mocked. The
labelling screen has to describe the system as it actually is, so writing it
before the reporting work would have meant describing a boundary that was about
to move. **2a is reporting; 2b is import plus the labelling screen.** No scope
was added or dropped — only ordered.

- **Returns, register extracts and audit export are computed from the records,
  not staged.** `api/app/reports.py` aggregates recorded decisions and
  overrides; nothing in it is on the decision path, and nothing in it decides
  anything. A report can be wrong without a determination being wrong, which is
  the point of keeping them apart.
- **Only named periods.** `YYYY-MM` and `YYYY-Qn`, rejected at the schema edge
  and again in `period_bounds`. A free date range would let a caller cover an
  arbitrary window and label the result a period; a named period is checkable
  by a reader who was not in the room.
- **The two date fields are not interchangeable, and each document says which
  one it used.** Returns scope on `Decision.as_of` — the business date frozen
  into the snapshot. The override register scopes on `Override.created_at`,
  because an override can be recorded in a later period than the determination
  it displaces. Both PDFs print `scoped by …` rather than leaving a reader to
  assume.
- **The figures on screen are the figures in the PDF.** `render_period` takes an
  already-computed aggregation instead of recomputing; recomputing inside the
  renderer would leave a window in which the preview and the document could
  disagree.
- **Period documents get their own base template.** `_base.html` is
  decision-scoped: its footer names a decision id and it renders a determination
  banner. Inheriting it would have meant passing a fake decision in to satisfy
  the layout, so period documents extend `_period.html`.
- **The reporting pack is the one in force at period end**, and every version
  that actually applied is listed in the body — so the choice of reporting pack
  can never hide a version that was in force for part of the period.
- **The audit export does not claim tamper-evidence, in three places.**
  `audit_events` is append-only (the database refuses UPDATE and DELETE) but,
  unlike `decisions`, it is **not** hash-chained: dropping the table and
  starting again would leave no arithmetic trace. That is stated on the response
  header (`X-Quolin-Integrity: append-only-trigger; not-hash-chained`), in words
  on the reporting screen, and in both PDFs. The service worker refuses to cache
  `/audit/export` at all, because a downloaded file loses its headers and a
  stale CSV on disk is indistinguishable from a current one.
- **Titles stayed pack configuration** (invariant 8). `regulatory_return` and
  `override_report` were added to `artefact_templates` and `artefact_titles` in
  both AU pack versions, and a test asserts every version defines both. The
  titles chosen — "Periodic Distribution Return", "Override Register Extract" —
  are descriptive and deliberately not statutory names.

Two credibility defects were found while building and fixed rather than shipped:
the period base template hardcoded "by assessment date" for both documents,
which mislabelled the override register; and the period dropdown counted
determinations across all books while the preview beside it counted one, so the
two contradicted each other on screen. `available_periods` is now scenario-
scoped and a test holds the dropdown count to the scoped report.

Verified: all three demo moments re-walked manually — Tom Askew / SOL BLOCKs on
three rules with plain-English reasons and pack versions; Harold Bell's
14 Nov 2025 decision reproduces exactly under pack v1, chain verified, no
differences, 50 records checked; a TMD renders and downloads (61 KB, PDF 1.7).
Both new documents were generated from the UI and downloaded. `make test` 94
passed, `make guard` clean, `npm run build` clean. `/reports` measured at 390 px
with no overflow and 44 px touch targets.

Deferred, recorded in `docs/post-raise.md`: hash-chaining `audit_events` (a
schema and write-path change, deliberately not folded into a reporting phase);
returns are generated but never lodged anywhere; and period documents are not
themselves entered into the evidence chain.

---

### 2026-08-19 — v2 Phase 1: make the UI credible

No scope change. One genuine design-system defect, plus the screen work the
phase called for.

- **Verdict colours were not actually reserved.** `refer` and `gold` were both
  `#8A6420` — the same hex. A REFER badge and a "All clients" nav link rendered
  identically, so the palette that is supposed to mean *only* ALLOW / REFER /
  BLOCK was also the interactive accent. REFER is now `#9A5400` on `#FBEBDA`;
  deep bronze `#8A6420` is the accent and nothing else.
- **A determination no longer depends on colour alone.** The verdict banner
  carries a glyph (`✓` / `?` / `✕`) so it survives a colour-blind reader and a
  monochrome print-out. Verdict tags already spelled the word out, so they were
  left as they were.
- **The decision screen states its own authority.** The banner and every reason
  card now carry the pack version in mono, so a single finding stays complete
  when it is screenshotted. The provenance block distinguishes *Observed* from
  *Rule threshold* rather than running two unlabelled lists together — the two
  lists are not paired and are not presented as if they were.
- **The hash chain is drawn as a chain.** Two flat hash rows became
  predecessor → `sha256(prev_hash + canonical record)` → this record, with the
  all-zero genesis case called out.
- **Persistent status bar** (`components/StatusBar.tsx`): active scenario,
  active pack version, and whether the figures are live or cached — fixed to the
  bottom on every screen, so "which rules am I looking at?" never requires
  navigation.

Not built, deliberately: the **regulatory-currency badge** the phase brief lists
for the status bar. Freshness (`last_verified_at`) is not a field until phase 4,
so there is nothing truthful to put in that slot. Rendering a currency
indicator backed by no data would be exactly the hidden unlabelled boundary this
build is meant to avoid, so the slot is empty until phase 4 fills it. The
jurisdiction reads a hardcoded `AU` for the same reason — it becomes a list in
phase 3.

Verified: all three demo moments re-walked manually after the redesign — Tom
Askew / SOL still BLOCKs on three rules with plain-English reasons and rule
versions; Harold Bell's 14 Nov 2025 decision still reproduces exactly under pack
v1 with the chain verified and no differences; a TMD still renders (61 KB, PDF
1.7). `make test` 62 passed, `make guard` clean, `tsc --noEmit` and
`npm run build` clean. The app has no responsive breakpoints, so layout is
width-driven only; the status bar was measured at 390 px with no overflow.

---

### 2026-08-19 — v2 Phase 0: close the three known gaps

No scope change. Three gaps left open at the end of v1, plus two bugs found
while closing them.

- **The service worker was masking staleness.** It answers API GETs from its own
  cache when the network fails, and returned them as ordinary `200`s. `getJson`
  therefore reported `stale: false`, so every screen's existing "cached copy"
  handling stayed silent and the dashboard rendered **"Chain verified · 48
  records"** with the engine dead. A cached copy of a past verification is not a
  verification, and asserting one is the worst failure this product can have.
  Cache fallbacks now carry `X-Quolin-From-Cache: hit`, `getJson` honours it,
  and `ChainBadge` degrades to "Not verified — engine unreachable".
- **Offline status now tracks the engine, not the device.** `OfflineBanner` read
  `navigator.onLine`, which is true on a captive portal and true whenever the
  API alone is down — the exact case that matters. It now reflects whether our
  own requests are reaching the engine (`lib/connectivity.ts`).
- **Actions that need a live engine say so.** Check and Replay are POSTs and
  cannot be served from cache; both are disabled with a one-line explanation
  when the engine is unreachable, rather than failing after the tap.
- **`make test` was missing `DYLD_FALLBACK_LIBRARY_PATH`.** `make api` set it,
  `make test` did not, so the artefact test failed on macOS with a WeasyPrint
  library error unrelated to the code under test.
- **`scripts/tunnel.sh` leaked its Next.js server.** Cleanup killed the
  subshell PID, not the server beneath it, which kept the port and made the next
  run fail its own "already in use" pre-flight. Cleanup now kills the listener;
  the wait-for-web loop is bounded and dumps the log instead of hanging.

Verified: all six screens render cached content with honest messaging under API
down, web down, and both down; the Check → Replay → Generate demo moment still
passes end to end; `npm run build`, `tsc --noEmit`, `make guard` and the 62-test
suite are green.

Deferred, recorded in `docs/post-raise.md`: an automated regression test for the
offline path, and first execution of `scripts/tunnel.sh`.

---

### 2026-08-19 — Initial build against Build spec 1.0

Implementation decisions taken where the spec left detail open. None of these
change scope; they are recorded so the spec and the code do not drift.

- **Loss capacity is two rules, not an ordering dependency.** `AU-LOSS-01` blocks
  when the client is two or more bands below requirement; `AU-LOSS-02` refers when
  they are exactly one band below. `AU-LOSS-02`'s predicate explicitly passes in the
  "far below" case, so the two rules never both fire and rule order stays irrelevant
  (spec §6.1, "rule order must not matter").
- **Two threshold tables instead of arithmetic in the DSL.** The condition DSL has
  comparisons, boolean composition and lookups but no arithmetic, so
  `min_loss_band_by_volatility` and `hard_floor_loss_band_by_volatility` are both
  stated explicitly in the pack. Keeps packs reviewable by a non-programmer (spec §5.3).
- **Concentration is basis points, floor-divided.** `post_trade_crypto_bps`, integer
  maths throughout, no floats anywhere (spec §6.1).
- **Snapshot embeds the asset classification** taken from the pack in force at
  `as_of`, so the stored snapshot really is the only input to replay.
- **AU v2 delta:** `max_crypto_concentration_bps` 1500 → 1000, plus new rule
  `AU-KNOW-02` (knowledge assessment must be under 24 months old). Spec §5.3 required
  exactly one changed threshold and one added rule.
- **Positions stay out of the database.** Custody is mocked per spec §2, so
  `PositionsProvider` reads a fixture file rather than a table. `fixtures/positions.json`
  is written by `make seed` from `positions_cast.json` plus the generated book.
- **Append-only is enforced by database triggers**, not only by convention, and the
  trigger is covered by a test. Spec §7 suggested a role; triggers demonstrate the
  same property without requiring role setup in a throwaway demo database.
- **Provenance is a set, not a log.** A predicate that names the same field in
  two branches of an `or` reads it twice; `inputs_read` records it once. The
  reason card is meant to answer "what was compared", not "how many times was it
  fetched" (spec §6.1).
- **Artefact naming stays configuration.** Template titles come from the pack's
  `artefact_titles` block. Renaming after the DDO consultant's ruling on the §3
  artefact question is a pack edit, not a code change.

Open, owed by others (spec §11.1): consultant sign-off on real thresholds, TMD
template review, and the artefact-naming ruling. Until then every number in
`/packs` is illustrative and labelled as such in the pack `notes` field.
