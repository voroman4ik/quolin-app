# Webhooks — integrating with Quolin

When a determination refers a client, or a document is filed, Quolin can post
the event to an endpoint you control. This is what your engineer needs to
implement it.

## What arrives

A `POST` with a JSON body and two headers that matter:

```
Content-Type: application/json
X-Quolin-Signature: t=1756195200,v1=9f86d081884c7d659a2feaa0c55ad015…
```

The body is canonical JSON — keys sorted, no whitespace. **Verify the raw bytes
you received**, not a re-serialisation of the parsed object. A body serialised
one way for signing and another way for checking is the most common reason a
first integration does not work, and it is our fault when it happens.

## Verifying the signature

The signature is `HMAC-SHA256` over `"{timestamp}.{raw body}"`, keyed with the
endpoint's secret, hex-encoded. The timestamp is **inside the signed material**
— a signature over the body alone is replayable forever by anyone who captures
one.

```python
import hashlib
import hmac
import time


def verify(secret: str, raw_body: str, header: str, tolerance_seconds: int = 300) -> bool:
    parts = dict(p.split("=", 1) for p in header.split(",") if "=" in p)
    try:
        stamp, given = int(parts["t"]), parts["v1"]
    except (KeyError, ValueError):
        return False

    # Reject anything outside the tolerance. This is what makes a captured
    # signature stop working, and it is the half people skip.
    if abs(int(time.time()) - stamp) > tolerance_seconds:
        return False

    expected = hmac.new(
        secret.encode(), f"{stamp}.{raw_body}".encode(), hashlib.sha256
    ).hexdigest()

    # Constant-time. A byte-by-byte comparison of a MAC is a forgery oracle for
    # anyone who can measure how long it takes.
    return hmac.compare_digest(given, expected)
```

`scripts/webhook_receiver.py` in this repository is a working receiver using
exactly this check — run `make webhook-receiver ARGS="--secret <yours>"` and
point an endpoint at it.

**If verification fails, check the clock first.** Skew between your server and
ours is the most common cause, and it looks identical to a wrong secret.

## What we expect back

Any `2xx` means delivered. Anything else — or a timeout — is a failure and we
retry.

**Answer quickly and do the work afterwards.** A receiver that processes the
event before responding is a receiver that times out under load and gets the
same event again. Acknowledge, queue, return.

**Expect duplicates.** We retry on failure, and a response that was lost in
transit looks identical to one that never came. Make your handler idempotent —
the body carries enough to recognise an event you have already seen.

## Retries

Six attempts on an exponential backoff spanning roughly half an hour. After
that the delivery is **dead-lettered**: kept, visible, and not silently
discarded.

A dead delivery is not lost. When you have fixed your endpoint, tell us and an
operator replays it — an explicit, audited action, not a database edit.

## Ordering

Not guaranteed. Retries mean a failed earlier event can arrive after a
successful later one. If order matters to your process, order on the fields in
the body rather than on arrival.

## Secrets

One secret per endpoint, per firm. It is stored encrypted under your firm's own
data key, and it is never shown again after it is created — if it is lost, it is
rotated rather than recovered.

Rotate by configuring a second endpoint, moving traffic, and removing the first.
There is no dual-secret window today, which means a rotation is a brief period
of failures-and-retries rather than a seamless cutover. That is a real gap and
it is recorded in `docs/post-raise.md`.

## What is not built

- **No dual-secret rotation window**, as above.
- **No delivery ordering guarantee**, as above.
- **No customer-facing endpoint management.** Endpoints are configured by us
  today; a firm cannot add or rotate one from the console.


## Where a webhook may point

A webhook is a URL a customer chooses and this system fetches on their behalf,
from inside the network the database is in. That is the shape of every
server-side request forgery, and the prize is usually one address —
`169.254.169.254`, which every cloud provider serves instance credentials from.

There is **no registration endpoint** today: endpoints are rows created by the
seed, by tests and by the game-day drill. The check exists anyway, and it is in
`http_sender` rather than on a form, because a registration screen is an obvious
next feature and a validator on a form is one somebody routes around.

    the scheme must be http or https      `file:`, `gopher:` and `ftp:` are a
                                          different protocol reached through the
                                          same string
    the hostname is resolved              a name that answers with a private
                                          address is the same attack as writing
                                          the address down
    every answer must be public           a host with one public answer and one
                                          link-local answer decides which one
                                          you get
    a name that does not resolve is       either a typo or a target waiting to
    refused                               be given an address later
    redirects are not followed            a 302 would walk past a check made on
                                          the URL we were given

A refused target arrives as a **failed delivery**, not as an exception out of
the worker: `scripts/deliver_webhooks.py` works a queue, and one poisoned row
must not stop the rest of it.

### Delivering to localhost, on purpose

`make webhook-receiver` runs a listener on `127.0.0.1` so a customer's engineer
has a working example of the signature check. Posting to it needs the exception
switched on:

```bash
QUOLIN_WEBHOOK_ALLOW_PRIVATE=1 make deliver-webhooks
```

Explicit rather than inferred from `QUOLIN_ENVIRONMENT`, so a deployed instance
cannot acquire it by having its environment name set to something unexpected.
