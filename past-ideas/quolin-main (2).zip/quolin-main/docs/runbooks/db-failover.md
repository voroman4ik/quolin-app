# The database is unreachable, or has failed over

## How you know

- The API returns 500s; `/health` reports the engine unreachable
- CloudWatch alarms on the RDS instance
- A Multi-AZ failover notification

## Stop the bleeding

1. **Confirm which side of the failover you are on.** RDS Multi-AZ promotes the
   standby and keeps the endpoint; a connection error that clears within two
   minutes is a failover doing what it is for, and the right action is to wait.
2. **If it does not clear, check the database first and the application second.**
   An exhausted connection pool looks identical from the outside, and restarting
   the API when the database is healthy turns a small incident into a longer one.
3. **Do not fail over manually to "try it".** A manual failover is a minute of
   guaranteed downtime to test a hypothesis that the console can answer.

## Find out what happened

- RDS events for the instance, and the `postgresql` log export
- Whether storage was near full (the alarm should have fired first — if it did
  not, that is a second finding)
- Whether a migration or a bulk sweep was running: a long transaction holding
  locks looks like unavailability to everything else

## After it is back

**Verify the chains.** A failover promotes a standby, and the standby is only as
current as replication was. `make health-alerts` runs the chain check; do it
before telling anybody the incident is over.

Determinations written in the seconds around a failover are the ones to look at:
if the API reported success and the write did not survive, a client was told an
answer that no longer exists. That is a determination to re-make, not a row to
re-insert.

## What to tell the customer

Downtime, with the window. If any determination is in the ambiguous seconds
above, name it — a firm needs to know that one of their advisers saw an answer
the record does not contain.
