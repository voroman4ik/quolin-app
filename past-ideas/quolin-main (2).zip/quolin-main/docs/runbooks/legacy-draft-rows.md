# A draft predates a constraint it is now being checked against

**Not an incident, and not an attack.** This is a row written under the rules as
they stood, meeting a rule added afterwards. It is here because the person who
hits it is under time pressure of the ordinary kind — a signatory or a publisher
with a draft that will not move and no idea why — and because the wrong answer
to it is quick, tempting and destroys the thing the constraint exists to record.

## How you know

- `POST /watch/drafts/{id}/sign` or `POST /watch/drafts/{id}/publish` answers
  **409** with *"cannot be moved: it violates …, which was added after the row
  was written"*.
- The message names one of two constraints:

| Constraint | What the row says |
|---|---|
| `pack_drafts_signature_is_independent` | The signature is its author's, and no independent second reviewer is recorded. Migration 0049. |
| `pack_drafts_self_signature_reviewed_these_bytes` | The signature is its author's, a reviewer is recorded, and the review does not name the content that was signed. Migration 0050. |

Before those migrations this was a 500 with a traceback, which told an operator
neither which draft nor which rule. H1 in the Gate A close.

## Why the row is checked at all

Both constraints were added `NOT VALID`. That enforces them on every write from
the migration onwards and asserts nothing about rows that already existed —
deliberately, because this repository's own suite signed self-authored drafts
for thirteen stages and every second review recorded between 0049 and 0050 named
a person and no hash. A validating form would have had to be bought by rewriting
the backfill until nothing violated, which is manufacturing a clean history.

`NOT VALID` is not "never checked". Postgres re-checks a CHECK constraint on any
**UPDATE to that row**, and both signing and publishing update `pack_drafts`. So
an old row sitting still is fine and an old row being moved is refused — which is
the correct behaviour and was only ever presented wrongly.

## Find out what you have

Read-only, through the application connection:

```sql
SELECT id, jurisdiction, proposed_version, status,
       created_by_user_id, signed_by_user_id,
       second_reviewer_user_id,
       second_reviewed_content_hash, content_hash
  FROM pack_drafts
 WHERE signed_by_user_id IS NOT NULL
   AND signed_by_user_id = created_by_user_id
   AND (second_reviewer_user_id IS NULL
        OR second_reviewer_user_id IN (created_by_user_id, signed_by_user_id)
        OR second_reviewed_content_hash IS NULL
        OR second_reviewed_content_hash <> content_hash);
```

`created_by_user_id = 'UNKNOWN_PRE_MIGRATION'` never appears here: the sentinel
cannot equal a real signer, which is why that value was chosen.

## What to do

**Raise a fresh draft from the current version and take it through the workflow.**
That is the whole remediation, and it is not a workaround — the row is refused
because its review chain is one person long, which is exactly the state §3.2
forbids. A new draft costs a specialist an hour and produces content that can be
evidenced. Nothing is deleted: the old draft stays in whatever state it is in,
and `pack_draft_transitions` keeps its history.

If the content genuinely was reviewed by somebody independent and the record was
never made, **the reviewer records it now, on the new draft, having read it
again.** A review recorded today about a read that happened last year is a
justification assembled after the act, and `record_second_review` refuses to
attach one to signed content for that reason.

## What not to do

**Do not drop or weaken either constraint.** They are the half of §3.2 that
survives somebody editing `api/app/watch/drafts.py`. If one has to come off for a
migration, it goes back on in the same transaction and the reason is written into
`docs/spec-changes.md` as a dated entry.

**Do not UPDATE the row to satisfy the check.** Writing a second reviewer's
account into a row so that it will publish is the FP3-26 defect with a compliance
consequence: the published pack, `pack_publications` and the artefact's
evidence-integrity table all carry that name to the customer, and it would be
naming somebody as having read content they have never seen.

**Do not publish it through the schema owner.** A CHECK constraint binds the
owner exactly as it binds everybody else, so this would not work — and the
attempt is what `suspected-breach.md` exists to detect.

## Who decides

The specialist for the regime decides whether to raise the replacement draft.
Nobody decides to remove the constraint on their own: that is a change to §3.2's
enforcement and goes through change control in `docs/spec-changes.md`.
