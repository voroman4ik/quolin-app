# Rolling a release back

`bad-deploy.md` is the runbook for *deciding* to roll back — how you know, what
to tell the customer, what to look at afterwards. This one is the mechanism:
what a cutover actually does, how to practise it, and what the numbers it
produces are and are not evidence of.

## What is claimed, and where

This distinction is the point of the section, so it comes first.

| Claim | Proven where | Status |
|---|---|---|
| Blue-green cutover exists, with a health gate that refuses a bad revision | `docker compose`, on a developer machine | **exercised** — see below |
| A rollback restores the previous revision and is timed | same | **exercised** |
| Rollback completes in under two minutes (§16) | production-shaped infrastructure | **not proven** |

The last row is the one that matters to an assessor and it is not answered here.
`scripts/deploy.py` and `scripts/rollback.py` drive two containers and an nginx
process on one machine: no load balancer draining connections, no ECS task set,
no cross-AZ anything, no traffic. A number produced there is a number about that
machine. §S9's real cutover is the task-set swap in `infra/compute.tf`, and the
§16 claim needs the drill run against a deployed environment with the artefact
stamped with that environment's name.

The evidence artefacts carry the environment they ran in for exactly this
reason. An artefact stamped `compose` is not an artefact stamped `staging`, and
`scripts/evidence_index.py` prints the environment beside every control so the
difference is visible without opening anything.

## The mechanism

Two API containers, `api-blue` and `api-green`, both running and both connected
to the database. An nginx container in front holds one line naming which of them
is upstream. A cutover rewrites that line and reloads nginx.

```bash
make bluegreen-up
```

The router answers on `:8080`. Each colour also publishes its own port — blue on
`:8081`, green on `:8082` — so the health gate can ask a container directly
while the router is still sending every real request to the other one.

Each container reports its colour from `/health`. That is what makes a cutover
checkable rather than assumed: a container still running the previous image
answers a health probe exactly like a fresh one.

## Deploying

```bash
make cutover                      # to whichever colour is idle
make cutover ARGS="--to green"
make cutover ARGS=--dry-run       # health-check the idle colour, change nothing
```

Three things happen in order, and the order is the whole design:

1. **Health-gate the new colour, directly**, while the old one still serves.
   A failure here costs the deploy and nothing else.
2. **Rewrite the router's upstream and reload.** A reload, not a restart —
   in-flight requests finish against the old worker.
3. **Confirm through the router**, and only then report success.

Step 3 is not ceremony. See *What running this taught us* below.

Exit codes: `0` cut over, `1` could not run, `2` the gate refused or the router
never came round. `make` surfaces the non-zero, which is intended: a refused
deploy should fail the command that asked for it.

## Rolling back

```bash
make rollback                     # to the other colour
make rollback ARGS=--evidence-out # and file the timing
```

**It does not health-gate the target, deliberately.** The previous colour was
serving traffic a moment ago, and making a rollback wait on a health check adds
the one thing a rollback cannot afford. If the previous colour has *also* died,
waiting is not the answer — that is an outage rather than a bad deploy, and
`bad-deploy.md` is the wrong runbook for it. The script says so when it happens.

The clock runs from the decision to the moment the router answers **only** as
the target colour, not to the moment the reload was signalled.

## Practising it

The gate is worth having only if it has been seen to refuse, so there is a
committed way to produce a revision that does not start:

```bash
docker compose -f docker-compose.yml -f infra/compose/broken-revision.yml \
  --profile bluegreen up -d --force-recreate api-blue
make cutover ARGS="--to blue --timeout 20 --evidence-out"
```

Expected: `refusing to cut over to blue: no answer` / `green is still serving.
Nothing moved.`, exit 2, and the router unchanged.

Then the other half — a revision that passes the gate and turns out to be bad
anyway, which is the case the runbook exists for:

```bash
docker compose --profile bluegreen up -d --force-recreate api-blue   # a working blue
make cutover ARGS="--to blue --evidence-out"
docker stop quolin-api-blue                                          # it goes bad
make rollback ARGS=--evidence-out
```

Run on 2026-08-26 against this stack: the gate refused the broken revision and
left traffic on green; the fixed revision cut over in 1.0s; with blue stopped the
router returned 504; the rollback restored green in 3.4s, after which five
consecutive requests through the router returned 200. The artefacts are in
`evidence/deployments/`, stamped `compose`. Those seconds describe one laptop —
see the table at the top.

Put it back when you are done:

```bash
make bluegreen-down
```

That removes the three drill containers and leaves the database alone. A plain
`docker compose --profile bluegreen down` does not — it stops every service in
the project, database included, which ends whatever else was running against it.

## What running this taught us

Both of these were found by doing the drill, and in both cases the script had
already printed a success line.

**A reload is not a cutover.** `nginx -s reload` signals the master process and
returns. The first version reported a cutover complete in 0.1s while the router
was demonstrably still serving the colour it had been serving before. A green
deploy log over an unchanged system is worse than a failure, because nobody
looks at it twice.

**One good answer is not a cutover either.** A graceful reload starts new
workers before the old ones finish, and for a short window both accept from the
shared socket. The next version confirmed with a single probe, reported a 0.2s
rollback — and the very next request through the router returned 504 from an old
worker still trying the container that had just been stopped. Confirmation is
now a run of consecutive clean answers; anything else resets the count.

The general shape is worth keeping in mind when the drill moves to staging: a
deploy tool that reports what it *asked for* rather than what it *observed* will
be confidently wrong, and the environments where that is expensive are the ones
this has not run in yet.
