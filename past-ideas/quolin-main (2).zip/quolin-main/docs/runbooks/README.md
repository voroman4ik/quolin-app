# Incident runbooks

Five, per §S9, and they are written to be read by somebody who was woken up.

That shapes the format. Every one opens with **how you know**, because the first
thing a person needs at 3am is to confirm they are in the right document. Then
**stop the bleeding**, then **find out what happened**, then **what to tell the
customer** — in that order, because the order people actually want them in is
the order they will read them in regardless of how the page is laid out.

Two rules run through all of them.

**Nothing here destroys evidence to fix an outage.** Re-chaining, deleting
queued work and restoring over a live database are all things that make a symptom
go away and take the record of what happened with it. Where a step is
irreversible it says so, and says what to capture first.

**Every runbook names who decides.** "Escalate" is not an instruction. A person
holding a pager at 3am needs to know whether they may take the system down
themselves, and whose answer to wait for if not.

| Runbook | Fires when |
|---|---|
| [db-failover.md](db-failover.md) | The database is unreachable or has failed over |
| [bad-deploy.md](bad-deploy.md) | A release is serving errors or wrong answers |
| [chain-mismatch.md](chain-mismatch.md) | The evidence chain does not verify, or a replay disagrees |
| [webhook-storm.md](webhook-storm.md) | Deliveries are failing in bulk, or a customer is being flooded |
| [suspected-breach.md](suspected-breach.md) | Auth anomalies, RLS denials, or anything that looks like access nobody granted |

One procedure, which is not an incident and is here because it is the document
somebody reaches for under time pressure of a different kind:

| Procedure | Read it when |
|---|---|
| [dedicated-stack.md](dedicated-stack.md) | A contract requires a single-tenant stack — standing one up, proving it, handing it over, tearing it down |
| [rollback.md](rollback.md) | The mechanism `bad-deploy.md` sends you to — how a cutover works, how to practise it, and what its timings are evidence of |
| [legacy-draft-rows.md](legacy-draft-rows.md) | A draft refuses to sign or publish because it predates one of the separation-of-duties constraints |

Each is reachable from the alert that fires it: `app/alerts.py` puts the path in
the `action` of the finding, so the page a person receives names the document.
