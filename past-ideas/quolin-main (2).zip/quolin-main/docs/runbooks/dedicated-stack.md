# Standing up a dedicated stack

Not an incident runbook. This is the procedure §S11 asks be written down: bring
up a single-tenant stack for one customer, prove it works, hand it over — and
tear it down again when the contract ends.

The target is **a new dedicated stack from IaC in under one day**. Most of that
day is AWS creating an RDS instance. The parts that can go wrong are the parts
that involve a person deciding something, and this document exists to remove as
many of those decisions as possible.

**Read this before you start:** three things must exist and cannot be created by
an apply. If any is missing you are not doing this today.

| Needed | Why it cannot be automated |
|---|---|
| An AWS account with credentials for this stack | Somebody with authority creates it |
| The organisation's Route53 hosted zone id | One zone for everyone; delegating nameservers per customer is a conversation with a registrar |
| A master key, generated and stored where it survives this AWS account | It is the one value that cannot be regenerated: lose it and every encrypted record, backups included, is gone |

---

## 1. Allocate (2 minutes)

```bash
make new-stack ARGS="--slug acme --zone-id Z0123456789ABCDEFGHIJ"
```

This writes `infra/envs/acme.tfvars` and `infra/envs/acme.backend.hcl`, and adds
a row to `infra/envs/allocations.md`.

**Do not skip this and hand-write the tfvars.** The network range is the thing
you would get wrong, and it is the mistake that does not announce itself: two
stacks with overlapping CIDRs both apply cleanly, both run fine, and collide the
day somebody peers or routes between them — by which time both hold a customer's
evidence and neither can be renumbered without downtime. `make new-stack
ARGS=--check` runs in CI and compares the register against `infra/envs/`, so a
range allocated from memory fails the build.

Read the generated tfvars before going on. It is short on purpose.

## 2. Apply (35-50 minutes, mostly waiting)

```bash
cd infra
tofu init -backend-config=envs/acme.backend.hcl -reconfigure
tofu plan  -var-file=envs/acme.tfvars -out=acme.plan
tofu apply acme.plan
```

The long pole is the RDS instance, 10-20 minutes, longer with Multi-AZ. The
certificate is issued and DNS-validated inside the apply, which is usually a
minute or two but is the step that hangs if the zone id is wrong: a validation
record written into a zone that does not serve the domain never validates, and
Terraform waits rather than failing. If `aws_acm_certificate_validation` is still
running after ten minutes, check the zone id before you check anything else.

`tofu output url` is the address this stack answers on. Everything below uses it.

## 3. Give it the one value Terraform must not hold (5 minutes)

```bash
aws secretsmanager put-secret-value \
  --secret-id "$(tofu output -raw app_secret_name)" \
  --secret-string '{"master_key":"...","allowed_origins":"https://acme.quolin.example"}'
```

Terraform owns the container and never the contents — see the note in
`infra/secrets.tf`. An apply that found this empty leaves it empty rather than
filling it with a default, because a default key that works is worse than a
deployment that will not start.

**Record where the master key is kept before you move on.** Not in this stack,
and not only in the head of whoever ran this.

## 4. Migrate and seed the tenant (10 minutes)

Run migrations as the owner, then create the customer's tenant row, its data key
and its chain anchor. There is no single "provision a tenant" call yet — every
path that makes one assembles it from the same three pieces, which is recorded in
`docs/post-raise.md` as a thing to fix before the first customer rather than
after. Until it exists, follow `api/seed/seed.py` and do the three by hand.

A dedicated stack holds **one** tenant. The probe in step 5 checks that, and it
is the check most worth believing: a dedicated stack quietly holding two
customers is a sales claim that has stopped being true.

## 5. Prove it (10 minutes)

Three things, in this order, and none of them is optional.

**The full RLS suite, while the stack is still empty.** It provisions a second
tenant and proves neither can see the other, which is the only way to prove
isolation properly — and the reason it runs now rather than later is that it
writes, and what it writes would otherwise be a fake customer inside a real
customer's database.

```bash
cd api
DATABASE_URL=<owner url> APP_DATABASE_URL=<app url> uv run pytest -q tests/test_rls.py -rs
```

Then reset the database and re-run step 4, so the customer's stack contains the
customer and nothing else.

**The read-only isolation probe, which is what you run from now on.**

```bash
APP_DATABASE_URL=<app url> DATABASE_URL=<owner url> \
  make rls-probe ARGS="--tenancy dedicated"
```

It writes nothing and is safe against a live stack on a Tuesday afternoon. It
checks that the application role cannot bypass row-level security, that every
policed table has it enabled *and* forced with a policy attached, that a
connection with no tenant sees nothing, and that this stack holds exactly one
tenant.

**The smoke test, over HTTP, from outside.**

```bash
QUOLIN_SMOKE_PASSWORD=... make smoke BASE="$(tofu output -raw url)" \
  ARGS="--email <an operator> --write"
```

`--write` walks the three taps — Check, Replay, Generate — and records a
determination, which on a stack that has just come up is exactly what you want
to have proven. Without `--write` it asserts only the read-only half.

## 6. Hand over

- The URL, and who at the customer is the named signatory.
- Where the master key is kept.
- That `make comparison-report` and `make health-alerts` are scheduled on this
  stack too — they are in the same Terraform, so they are, but say it.
- The stack's row in `allocations.md`, moved from `planned` to `live`.

---

## Tearing it down

```bash
cd infra
tofu destroy -var-file=envs/acme.tfvars
```

Then, and this is the part people skip:

1. **Take a final dump first, and put it where the contract says.** `destroy`
   removes the database. The evidence in it is the customer's, and the retention
   term is a contractual question, not an ops one — find the answer before you
   run the command, not after.
2. **Mark the row `retired` in `allocations.md`. Never delete it, and never
   return the range to the pool.** Reusing a range is how a routing table ends up
   pointing at a customer who left.
3. **The KMS keys have a 30-day deletion window.** Until it elapses the data is
   recoverable; after it, it is not, master key or no master key.
4. Delete `infra/envs/acme.tfvars` and its backend file, or the register check
   will fail — a `retired` row with a live tfvars beside it is a stack somebody
   is about to re-apply by accident.

---

## What this document has not been able to prove

Every step above has been written against the Terraform that would execute it,
and the two acceptance checks in step 5 have been run — against the development
database and a locally started API, in CI, on every push. Nothing here has been
run against AWS, because there is no AWS account to run it against.

So the timings are estimates from what the resources are, not measurements: the
RDS creation time is AWS's published behaviour, and the "under one day" claim in
§S11's gate is **unverified**. The first real execution of this document is owed,
and is recorded as owed in `docs/spec-changes.md` and `docs/post-raise.md`
alongside the staging deploy and the point-in-time-recovery drill, which are
blocked on exactly the same thing.
