# Access nobody granted

Covers auth anomalies, row-level-security denials, and anything else that looks
like somebody reaching for data that is not theirs.

## How you know

- `auth.failures_against_account` — repeated failures against one account
- `auth.failures_from_source` — one address working through many accounts
- `rls.denied` — a query the database refused, which in this system means either
  an attack or a code path that lost its tenant. There is no third explanation.

## Stop the bleeding

**Preserve first, then contain.** The `security_events` table is append-only, so
it cannot be tidied — but sessions, tokens and logs can be, and the containment
steps below destroy some of them.

1. **Capture** the `security_events` rows and the request ids they name, and the
   log lines for those requests.
2. **Contain**, in this order:
   - Suspend the account, if one account is the target. This kills new sessions
     and leaves existing ones, which is why the next step matters.
   - Revoke that account's sessions.
   - Block the source address at the load balancer if it is not a customer's
     office. Check before you block: a shared office NAT is one address and
     several dozen people.
3. **Do not rotate the master key.** Losing it destroys every encrypted record,
   backups included. Key rotation is a deliberate, planned act with its own
   procedure, never an incident reflex.

## Find out what happened

- Did anything succeed? A failed attempt is noise until one works. Search
  `auth_sessions` for a session created from the same address in the window.
- For an RLS denial, read the request id in the log line and find the handler.
  A denial from an ordinary endpoint is far more likely to be our bug than an
  attack — and it means that endpoint had no tenant in scope, which is worth
  fixing today regardless.
- Whether any determination or artefact was read. The audit trail names every
  actor; a session that read another firm's client would have been refused by
  the database, which is what the denial is.

## Who decides

Containment is the on-call engineer's to take immediately — suspending an
account and blocking an address are reversible. **Telling a customer, and any
regulatory notification, is not the engineer's call**: it is the CTO's, and in
most jurisdictions there is a clock on it that starts when we become aware.
Wake them; that is what the escalation path is for.

## What to tell the customer

Once it is understood, not before — and quickly, because notification windows
are short. Say what was attempted, what succeeded, whose data was involved, and
what has changed. If nothing succeeded, say that plainly: "somebody tried and
the database refused them" is a good sentence and an honest one.
