# Deliveries are failing in bulk, or a customer is being flooded

## How you know

- `webhook.dead_letters` from `make health-alerts`
- A customer reports thousands of notifications
- Queue depth rising with the worker running

## Stop the bleeding

**Which direction is the storm?** They need opposite responses.

**Their endpoint is down** — deliveries pile up and dead-letter. Nothing is
being lost: dead deliveries are kept, and the customer can be replayed once they
are back. Suspend the endpoint so the worker stops spending attempts on it, and
tell them.

**We are flooding them** — a bulk sweep or a loop is producing notifications a
customer did not ask for. Suspend the endpoint *first*, then find the source.
Stage 8 made a sweep emit one event rather than one per determination for exactly
this reason; a storm from a sweep means that suppression has been undone.

## Find out what happened

- `webhook_deliveries` grouped by event and subject: one subject repeated is a
  loop, many subjects is a legitimate burst
- Whether a bulk run is in progress, and whether its determinations carry a
  `run_id` — a sweep whose determinations have no run id will notify per
  determination

## What to tell the customer

For a dead endpoint: what was missed, over what window, and that it is kept and
can be replayed on their word. Do not replay without asking — a case system that
receives four thousand determinations at once may have the same problem again.

For a flood: apologise for the volume, say what caused it, and confirm whether
they need the duplicates identified. Their reconciliation is now our problem too.
