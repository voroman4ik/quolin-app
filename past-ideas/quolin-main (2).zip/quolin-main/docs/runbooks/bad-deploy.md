# A release is serving errors, or wrong answers

## How you know

- Error rate or latency alarms after a deploy
- The staging smoke test failed and the deploy proceeded anyway
- A customer reports an outcome that changed with no pack change

## Stop the bleeding

**Roll back first, diagnose afterwards.** The deploy is blue-green: the previous
task set is still running and the rollback is a listener shift, not a rebuild.
§S9's target is under two minutes, and the reason it is that fast is so that
nobody is tempted to debug forward on a live system.

1. Shift traffic back to the previous task set. The mechanism, the commands and
   the way to practise it are in [rollback.md](rollback.md); on a deployed
   environment this is a task-set swap, and on a developer machine it is
   `make rollback`.
2. Confirm the error rate drops. If it does not, the deploy was not the cause
   and this is the wrong runbook.
3. Only then look at what shipped.

**Wrong answers are worse than errors and are treated differently.** A release
that returns 500s is loud. A release that returns *plausible but different
determinations* is silent, and every minute it runs produces records a firm will
file. If outcomes are suspect: roll back, then run a bulk re-evaluation over the
affected window and read the delta report. That report is what tells you who was
told what.

## Find out what happened

- The diff between the two image tags
- Whether migrations ran: a rollback of code does not roll back a schema, and a
  migration that removed a column will break the previous version too. This is
  the case where rolling back makes things worse, and it is why migrations in
  this repository are additive.
- The replay suite against determinations made during the window

## What to tell the customer

If only availability was affected, the window. If any determination was affected,
name them and say what the correct outcome was — with the delta report attached,
because "212 clients were assessed under a build that computed concentration
wrongly" is a sentence that needs the list beside it.
