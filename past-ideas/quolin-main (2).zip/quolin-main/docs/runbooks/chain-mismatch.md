# The evidence chain does not verify

**Severity: the highest in this system.** Every other incident is about
availability. This one is about whether the records this firm has been filing
with regulators mean what they say.

## How you know

- `chain.broken` or `chain.no_anchor` from `make health-alerts`
- `chain.unverifiable` — the chain could not be walked at all; see below
- `replay.mismatch` — a stored determination no longer reproduces
- `make restore-drill` exits 2 with "the chain does not verify in the restored copy"
- A customer asks why an artefact's hash does not match one they hold

**`chain.broken` carries a reason, and it decides which branch of *Find out what
happened* you are in.** The alert's `detail.reason` is one of:

| Reason | What it means |
|---|---|
| `HASH_MISMATCH` | A row decrypts and does not hash to what is stored, or does not name the previous row. The ordinary tamper. |
| `UNDECRYPTABLE_SNAPSHOT` | A row's snapshot is not ciphertext this tenant's key can open. **It was not written by this application.** |
| `ROW_UNREADABLE` | The row stopped the walk for some other reason. Rare, and read it as the one above until you know otherwise. |

The distinction is the first question you ask. `HASH_MISMATCH` asks *what
changed*; `UNDECRYPTABLE_SNAPSHOT` asks *who has write access to the database*,
because `decisions` grants the application `INSERT` and `SELECT` and nothing
else — a row it cannot decode is a row something other than the application
appended, which is the shape a raw-SQL forgery takes.

**`chain.unverifiable` is not a broken chain.** It means the verifier could not
run: most often a `QUOLIN_MASTER_KEY` this process cannot read, or a tenant with
no row in `tenant_keys`. It is critical anyway — a chain nobody has checked is
not a chain that verifies — but the first thing to check is the process's
configuration, not the evidence.

## Stop the bleeding

**Do not re-chain anything.** `make rechain` recomputes hashes so the chain
verifies again — which destroys the evidence of what happened, permanently, and
leaves a chain that verifies and proves nothing. It is the right tool once the
cause is known and never before.

1. **Stop artefact generation.** A document produced now carries a hash from a
   chain under suspicion, and it will be filed. Scale the artefact worker to
   zero; the queue holds.
2. **Capture the state before anything else.** `make restore-drill --keep` takes
   a copy and leaves it. That copy is the evidence of the incident.
3. **Leave determinations running or stop them — this is a judgement call, and
   it is the CTO's.** New determinations extend a chain whose earlier links are
   in doubt. Stopping them stops the firm advising clients. Neither is obviously
   right; the person paged does not decide alone.

## Find out what happened

`make rechain` (without `--apply`) reports which link breaks and where. Then:

- **One determination fails, later ones verify.** Its row was altered, or its
  snapshot was. Look at `audit_events` around its `created_at` and at any
  database access outside the application role.

- **The failing row's snapshot will not decrypt** (`UNDECRYPTABLE_SNAPSHOT`).
  Start from the row's `created_at` and the database's own connection log rather
  than from the application's audit trail: the application cannot produce this
  row, so nothing it wrote will explain it. `make rechain` is doubly wrong here
  — it would compute a hash over bytes nobody can read and leave a chain that
  verifies a forgery.
- **Every determination after a point fails.** Something was inserted or deleted
  mid-chain, which the append-only trigger should have refused — so ask *how*
  before asking what. Check whether anything ran as the owner.
- **The chain verifies but a replay disagrees.** The stored snapshot is not the
  only input any more: either a pack was edited in place, or evaluation began
  reading something outside the snapshot. `docs/spec-changes.md` records that
  invariant; the recent commits touching `app/engine` are where to look.

## What to tell the customer

Say it early and say what is and is not affected. A firm that learns from us on
Tuesday that determinations may have been altered can act. One that learns in a
regulator's letter cannot.

The honest statement is narrow: which determinations are in the affected range,
that their *content* is unchanged as far as we can show, and that the chain that
proves they are unchanged is broken. Do not say "your data is safe" — that is a
claim about the thing under investigation.
