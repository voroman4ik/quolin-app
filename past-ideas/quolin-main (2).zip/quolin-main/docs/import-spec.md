# Client import

How a client book gets into Quolin, what the importer refuses, and what it does
not bring with it.

## What a client record is, and is not

A client row is **reference data**. `clients` is deliberately absent from
`APPEND_ONLY_TABLES`: a CRM record legitimately changes, because people are
reassessed and flags are added. What must never change is a determination that
was already made.

That is safe here for a structural reason rather than a careful one. Every
decision freezes its inputs into a snapshot at the moment it is made, and replay
reads the snapshot rather than the client table. **Re-importing a client cannot
reach backwards into a determination**, and a test asserts exactly this: import a
client, evaluate, change the client's loss-capacity band, re-import, and the
recorded decision still replays byte-identically against its stored inputs.

## The file

CSV with a header row. Columns may appear in any order.

| Column | Required | Form |
| --- | --- | --- |
| `id` | yes | lowercase letters, digits, hyphens; 2–64 characters |
| `scenario` | yes | `meridian` or `sterling` |
| `name` | yes | any non-empty text |
| `dob` | yes | `YYYY-MM-DD`, in the past |
| `client_category` | yes | `retail` or `wholesale` |
| `knowledge_assessed` | yes | `true`/`yes`/`y`/`1` or `false`/`no`/`n`/`0` |
| `knowledge_date` | conditional | `YYYY-MM-DD`; required when `knowledge_assessed` is true |
| `loss_capacity_band` | yes | integer 1–5 |
| `vulnerability_flag` | yes | boolean, as above |
| `assessable_portfolio_cents` | yes | whole cents, ≥ 0 |
| `prior_crypto_purchases` | yes | integer ≥ 0 |
| `structural_acks` | yes (may be empty) | `|`-separated list |
| `default_trade_amount_cents` | yes | whole cents, ≥ 1 |
| `jurisdiction` | no | two-letter code; defaults to `AU` |
| `residency` | no | two-letter code; defaults to `jurisdiction` |
| `domicile` | no | two-letter code; defaults to `jurisdiction` |
| `note` | no | free text |

A worked example is at `fixtures/sample_client_book.csv`, and a test asserts that
file survives the validator — an example that does not import is worse than no
example.

### The three jurisdiction columns

`jurisdiction` is the licence the advice is given under. It is a fact about the
firm. `residency` and `domicile` are facts about the client, and they are what
pull a second and third regulator into a determination.

Each defaults to `jurisdiction` when the cell is blank, so a book that names
none of them imports as it always did: a client advised from where they live and
where they are domiciled, which is the ordinary case and was the only case any
row written before this column existed could describe. A blank cell is not an
error; it is what the row means when it says nothing.

A cell with something in it that is not a two-letter code *is* an error, because
a client filed under the wrong regulator is a decision made under the wrong
rules. The check is on the shape of the code and not on a list of the regimes
Quolin currently ships. Rejecting `NZ` because no NZ pack is loaded would make
adding a jurisdiction a change in two places, which is the thing the pack
architecture exists to prevent — and the decision path already states an
applicable regime it has no pack for rather than quietly dropping it.

Naming a jurisdiction Quolin holds no pack for is therefore allowed, and the
consequence is visible rather than silent: the resolver records that code under
`unmatched`, and the decision says so on its face.

## What the importer refuses, and why

**Decimals in a cents column.** `1234.56` is rejected with a message naming the
real mistake: this column is whole cents, and `$1,234.56` is `123456`. Cents are
integers everywhere in this system (invariant 3), and a CSV is precisely where a
float gets in. Silently rounding would put a number in the evidence chain that
nobody typed.

**A column it does not recognise.** Refused rather than ignored. A column the
importer silently drops is a field the author believed they had supplied.

**`knowledge_assessed` true with no `knowledge_date`.** AU v2 refers when an
assessment is more than 24 months old, and it cannot compute an age from
nothing. Importing "assessed, but we won't say when" creates a client the rule
cannot evaluate.

**A loss-capacity band outside 1–5.** No pack threshold table maps a band
outside that range, so such a client would produce a determination nobody could
explain.

**A scenario that is not a known book.** Otherwise the import creates clients
that exist in the database and on no screen.

**A duplicate id inside one file.** The error names the earlier row, so the
author can find both.

## Validation reports every problem, not the first

`_validate_row` accumulates errors across all columns rather than returning on
the first bad one. Returning early would make correcting a spreadsheet an
iterative game against the validator: fix one cell, resubmit, discover the next.

Every error carries `row`, `column` and `message`. Row numbers are the numbers a
spreadsheet shows — the header is row 1, so the first data row is row 2.

## All-or-nothing

If any row is invalid, **nothing is written**. A partial import leaves a book
half in one state and half in another, and afterwards nobody can describe the
result — least of all the person who has to explain it.

## Preview and commit are the same call

`POST /import/clients`

```json
{ "csv_text": "id,scenario,name,…", "commit": false }
```

`commit` defaults to `false`, so the dangerous call is the one you have to type
deliberately, and a caller who forgets the flag gets a preview rather than a
write. A separate validate endpoint was considered and rejected: two code paths
can drift, and then what a reader was shown stops being what a reader gets.

The response reports `total_rows`, `valid_rows`, `rejected_rows`,
`new_clients`, `updated_clients`, the ids in each group, and every row error.

On the screen, **Import** is only enabled once a validation has come back clean.

## Re-importing an existing id updates it

An id already in the database is updated in place, and the preview says how many
rows would be updates rather than inserts, so nobody discovers the overwrite
afterwards. Every commit writes an `import.clients` audit event recording the
counts.

## What import does not bring

**Custody positions.** A client CSV carries no holdings, and custody in this
prototype is `fixtures/positions.json`. An imported client therefore has **no
custody record**, and `FixturePositionsProvider.get` returns zero holdings for a
client it has never heard of.

That matters because zero holdings and no record produce identical figures and
mean entirely different things. The first makes an exposure of 0% true; the
second makes it fabricated — and the concentration rule then passes for a reason
that has nothing to do with the client's real portfolio.

**Since Q-06 it is also a gate, and not only a disclosure.** The three places
below all *say* that custody is absent; none of them stopped a determination
being made on the fabricated zero. One was: a client imported with a $100,000
portfolio and a $5,000 purchase evaluated ALLOW on a post-trade concentration of
500 bps that nobody had supplied a single input for.

Absent custody is the same class of fact as an absent snapshot field, and DSL v2
already knows what to do with one of those. So when `positions.source` is
`none_on_file`, the calcs that read custody — `existing_crypto_cents`,
`post_trade_crypto_cents`, `post_trade_crypto_bps` — are **withheld from the
snapshot** rather than computed from the zero. A rule that reads one refers the
case to a human and names the field. `trade_share_bps` is not withheld: this
trade against this portfolio is arithmetic on facts the firm actually supplied.

The snapshot names what was withheld, under `positions.withheld_calcs`, so a
determination replayed in two years can say what it was decided on and what it
was not. The key is absent when custody *is* on file, so a snapshot for a client
with positions is byte-identical to the ones already recorded.

This is an interim gate, not a custody integration. It stops a wrong answer
being recorded; it does not produce a right one. A firm that needs a
concentration figure needs a custody feed.

The three disclosures remain, because a refusal a person can act on still needs
to say why:

- `FixturePositionsProvider.has_record()` answers it directly. It is deliberately
  *not* folded into `get()`, because `get()` feeds the frozen snapshot and
  changing that shape would change what replay reads back for every decision
  already recorded (invariants 2 and 5). The engine never asks this question;
  only screens and importers do.
- `GET /clients/{id}` returns `custody_on_file`, and the client screen replaces
  "No digital-asset holdings" with "No positions on file" plus a note that the
  exposure shown is not a view of a real portfolio.
- Every import response carries `custody_warning`, displayed on success and
  failure alike.

**A place in the demo.** The home screen shows the six hand-written clients the
walkthrough was built around, and that membership is the `clients.is_cast`
column, set by the seed and by nothing else. It was previously inferred from
`note` being non-empty — which meant an imported row with a note in it promoted
itself onto the home screen. An imported client is a real client and appears
everywhere a client appears; it is only absent from the walkthrough.

`DbClientProvider.cast_ids()` answers this, and like `has_record()` it is
deliberately a separate query rather than a key on the dict `get()` returns.
That dict is the frozen snapshot (invariants 2 and 5), and cast membership has
nothing to do with a determination in any case.

## Endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| `POST` | `/import/clients` | Validate a book; write it when `commit` is true |
| `GET` | `/integrations` | Every external edge, its status, and what it costs |

## What is not built

- No file upload endpoint — the CSV arrives as text in a JSON body. The screen
  reads the chosen file in the browser and posts its contents.
- No position import. Custody stays a fixture until a real provider replaces it.
- No delete. Import creates and updates; removing a client is not an import
  operation.
- No column mapping or dialect detection. The header must use these names.
