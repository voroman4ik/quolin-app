# Quolin — investor walkthrough

**Training document for the presenting team.** Everything in here was observed
on a live local stack on 20 August 2026, not written from the spec. Where a
number appears, it is the number that came out of the running system. Your
numbers will differ after a reseed; the shape will not.

This is a different document from [`demo-script.md`](demo-script.md). That one
is written for a compliance buyer, who wants to know whether the thing would
survive their audit. This one is written for an investor, who wants to know
whether the thing is real. Same six minutes on screen, different emphasis:
every step below tells you not just what to click but **what that step
proves**, and what it does not.

---

## Before you start

Three commands, in three terminals, in this order:

```
make seed
make api
make web
```

Then open `http://localhost:3000`, sign in as one of the seeded staff — `make
seed` prints the five addresses and the password — and **click the Sterling
tenant** before you begin. Dana Whitfield, the operator, is the one to walk in
as: she can run determinations but cannot approve her own overrides, which is
the point if anyone asks.

`make seed` is not optional tidy-up. It is the first item on the checklist.
Both `make test` and any browser walkthrough write real determinations into an
append-only store — during one rehearsal the chain went from 45 records to 88.
Nothing is broken when that happens; it is exactly what an append-only ledger
is supposed to do. But it means that if you skip the reseed, the dashboard
opens on decisions nobody in the room can account for, and the first question
you get will be about a record you cannot explain.

### Four gotchas that will bite you on stage

1. **The app opens on Meridian, not Sterling.** Meridian is the crypto
   platform; Sterling is the private wealth manager. The script below is
   Sterling's. Click the tenant switch before you start talking, not during.
2. **Click through the app. Do not type URLs.** A hard navigation resets the
   tenant to the Meridian default, and the footer brand will change under you
   mid-sentence. Clicking from screen to screen preserves Sterling.
3. **Sessions idle out after two hours.** If you set the laptop up before
   lunch and present after, you will hit the lock screen in front of the room.
   Sign in again right before you walk in.
4. **Every Check writes a real decision.** The record count climbs as you
   demo. This is a feature and you should say so out loud when it happens —
   but know that it happens, so it does not surprise you.

---

## The six minutes

### 1 · Frame (30 seconds)

Stay on the dashboard. Do not click anything yet.

> "This is a compliance decision engine. An adviser is about to recommend a
> product to a client. Before that recommendation goes out, the firm has to
> know whether it is allowed — under which regulator, against which version of
> which rules, and be able to prove that answer years later. Today that is a
> person reading a PDF policy and making a judgement call. Here it is a
> determination with a receipt."

**What this proves:** nothing yet. It buys you the next five minutes. Keep it
short — the screens do the work.

### 2 · Check (2 minutes) — *the product*

Click through to **Tom Askew**. Before you press anything, read the inputs out
loud from the screen:

- portfolio $200,000
- crypto exposure 10.00% against a cap of 10.00%
- loss capacity Band 1

> "He is exactly at the line. Not over it. At it."

Now recommend **SOL** and run the check.

**Expected result:** a **BLOCK**, governed by pack **AU v2**, regulator
**ASIC**, pack effective 01 Jun 2026, with a record hash on screen and a panel
headed **"WHY — 3 RULES DID NOT PASS"**:

| Rule | What failed |
|---|---|
| `AU-CONC-01` | post-trade crypto exposure **14.00%** against max **10.00%** |
| `AU-LOSS-01` | loss capacity band **1**, volatility band **3**, against hard floor **2** |
| `AU-TM-01` | outside the target market — loss capacity band 1, asset class altcoin |

**What this proves:** the answer is not a score, a percentage, or a
traffic light. It is three named rules, each with the input it read and the
threshold it read that input against, each stamped with the pack version that
supplied the threshold. That is the difference between a model that has an
opinion and an engine that has a reason. An investor who has seen compliance
AI pitches before is braced for a confidence score; give them the rule IDs
instead.

**What this does not prove:** that the rules are right. Say so before you are
asked — see the "Do not say" table at the end.

### 3 · Replay (90 seconds) — *the moat*

Navigate to **decision 1** (Harold Bell, SOL, REFER, 14 Nov 2025) and press
**Replay this decision**.

**Expected result:** *"Reproduced exactly · pack v1 · chain verified ✓"*,
differences **none**, and the current record count.

Pause here. This is the single hardest thing on screen to fake, and most of
the room will not immediately see why.

> "That decision was made in November against version 1 of the Australian
> pack. Version 2 came into effect in June. We just re-ran the original
> decision — and the engine went and got version 1 to do it, because that is
> the version that governed it. Nothing reproduced 'approximately'. Zero
> differences."

**What this proves:** three things at once, and it is worth naming them
separately.

- **Determinism.** The same inputs produce the same output, which is only true
  if there is no model in the decision path.
- **Versioned rule content.** The engine did not evaluate today's rules
  against yesterday's facts. Old decisions are judged by old rules, which is
  what a regulator will actually ask for.
- **Integrity.** The hash chain over the decision log verified at the same
  time.

This is the moat. Anyone can build the Check screen in a fortnight. Being able
to press this button on a nine-month-old record, in front of an auditor, is
the part that takes a year.

### 4 · Generate (60 seconds) — *the deliverable*

From the same decision, generate the **TMD**.

**Expected result:** a real PDF — roughly 60KB, template `au_tmd_v1.html`,
stamped with the generation timestamp in UTC.

Show the document, then show its two honesty markers: the prototype banner in
the masthead, and the evidence-integrity table at the foot carrying the
decision reference, the pack version and signatory, and both the previous and
current hash.

**What this proves:** the output is the artefact the firm actually has to
produce and file, not a dashboard export. And the artefact is bound to the
determination that produced it — the hashes on the page are the hashes in the
chain.

### 5 · Close (60 seconds)

Click through to **`/integrations`**.

> "Everything you just saw runs behind an API. The engine does not care
> whether a human pressed the button or an order management system did. This
> is where it plugs into what the firm already runs."

**What this proves:** that this is infrastructure, not an app. Close there.

---

## Handling pushback

Four challenges you should expect, each with something you can actually show.
Do not answer any of these from the slide deck when you can answer it from the
terminal or the screen.

### "How do I know the records haven't been edited?"

Run `make tamper-demo` in a terminal. It is read-only and writes nothing, so
it is safe to run live.

It does three things: verifies the chain end to end; attempts an
`UPDATE decisions SET outcome='ALLOW'` and shows the database refusing with
`table decisions is append-only`; then recomputes a stored hash (it matches)
and recomputes it with the forged outcome (it does not).

**Two guarantees, and you must state them as two.** The append-only triggers
stop an edit through the application. The hash chain means an edit made *below*
the application — straight into the storage layer, by someone with the access
to do that — cannot be hidden. Neither one alone is the claim. Collapsing them
into "it can't be tampered with" is how you lose a technical investor in the
room.

### "What about a client with exposure to more than one regulator?"

Pull up **Marcus Tan**. The determination resolves across regimes and shows,
explicitly, **"US unmatched — no pack"**.

**What this proves:** the system knows the difference between *evaluated and
passed* and *not evaluated at all*, and it says so on the face of the
document. A system that quietly returns ALLOW when a whole regime was never
checked is worse than no system. Point at that line — it is a small piece of
UI and it is one of the most credible things in the product.

### "Different currencies?"

Show **`/currency`**.

### "What happens when the firm disagrees with the engine?"

Show the **Priya Nair** override.

**What this proves:** the engine does not pretend to be the final authority. A
human can override it — and the override is itself a recorded, attributed,
justified event in the same chain. This is the answer to "no compliance
officer will ever let software make this call." They don't have to. They just
have to leave a trace when they don't.

---

## Do not say

These are not style notes. Each one is a claim the product cannot support, and
a technically literate investor will catch it.

| Do not say | Say instead |
|---|---|
| "Tamper-proof" | "Tamper-**evident**" |
| "It monitors regulators for changes" | The regulatory watch path is a **fixture**. It does not reach the evaluator. |
| "It's hash-chained and append-only, so it's secure" | Two separate guarantees. State them separately (see above). |
| "It's secure" | Accounts, roles and two-person rules are real and tested. It has had **no penetration test** and holds no real client data. Say that plainly. |
| "The rules are correct" | The **mechanism** is what is being demonstrated. The rule content is illustrative and reviewed by no qualified adviser. |

The last one matters more than it looks. Every artefact the system generates
from unreviewed rule content prints a red banner saying exactly that, on the
page, above the title. If you claim more from the stage than the PDF claims
about itself, someone will open the PDF.

---

## If something goes wrong

**The engine is down and the screen says "Engine unreachable — showing last
synced records."** This is not a failure, and you should not apologise for it.
The badge reads **"Not verified — engine unreachable"** — not a green tick.
Replay is disabled with an explanation. The footer says **CACHED**.

Use it:

> "The engine is offline and the app is telling you it cannot verify the
> chain, rather than showing you a tick it hasn't earned. That distinction is
> deliberate. Cached data is never dressed up as verified data."

This behaviour proved itself twice by accident during rehearsal, which is the
only kind of proof of a failure path that is worth anything.

**You hit the lock screen.** Sign in again. Mention that sessions expire and
are revocable server-side, and move on.

**A decision count doesn't match what you expected.** Say so out loud and
explain why: every check writes a record, records are never deleted, and the
count only goes up. Then keep going. Explaining an append-only ledger in one
sentence is a better moment than a clean number would have been.
