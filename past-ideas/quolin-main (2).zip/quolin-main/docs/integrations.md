# Connecting to Quolin

**Who this is for.** An engineer at a customer, integrating their systems with
ours. You should be able to get a synthetic book in and decisions back out
without talking to us — that is the bar this document is written to, and S4's
gate is somebody doing exactly that following only these pages.

**Three ways in, and you probably want one of them.**

| | Use it when | Latency |
|---|---|---|
| **REST API** | You have engineers and a system that can make HTTPS calls | Immediate |
| **Batch file drop** | Your book lives in a system that exports files overnight | On demand — see the status note |
| **Webhooks** (outbound) | You want determinations to land in the case system you already watch | Push, usually inside two minutes |

Webhooks are not an alternative to the other two — they are how you find out
about things without polling, and most integrations use them alongside one.

> **Status.** Webhooks are built, tested and delivered on a schedule. The batch
> **gateway** is built and tested — validation, row-level errors, the error file,
> the manifest, duplicate detection — and the **transport** that would put a file
> in front of it is not: there is no SFTP server, no per-tenant chroot and no PGP
> handling anywhere in this system, and nothing sweeps a drop directory in the
> deployed stack. [Batch file drop](#2-batch-file-drop) says so in full rather
> than leaving it to this note. The REST API is being built now; the endpoint
> list below is the shape it is being built to. Custody read adapters are not
> built — see [Positions](#positions) for what to do meanwhile.

---

## 1. Credentials

Every integration acts as an **API client**: a machine credential belonging to
one tenant, with its own id, its own secret, and its own roles.

It is deliberately not a user account. Nobody types its password and nobody can
be asked what it meant, so it is a different kind of thing — it appears in your
quarterly access review in its own table, and the audit trail names it as the
actor for anything it does.

**Roles a credential may hold.** `viewer` and `operator`. A credential *can* be
granted `approver`, `pack_signatory` or `tenant_admin`, and your access review
will flag it as the loudest finding it has: approving an override and signing
rule content are acts a regulator wants a name against, and a machine cannot be
asked why it did one.

**Set an expiry.** The secret is shown once when the credential is created and
there is nothing to recover it from — so the only way to rotate is to issue a
new one deliberately, which nobody does unless something asks. A credential
with no expiry is reported in every access review until it has one.

---

## 2. Batch file drop

For firms whose book lives somewhere that exports files. This is a first-class
path, not a fallback.

### The drop

> **Planned, not delivered.** SFTP, per-tenant chroots and PGP at rest are the
> transport this gateway is designed for, and **none of them is built**. There is
> no Transfer Family resource, no sshd and no PGP handling anywhere in this
> system, and the deployed stack schedules nothing that sweeps a drop directory.
> This section describes the shape it will take; the paragraphs after it describe
> what exists today, which is everything that happens to a file *once it has
> landed*. If you are integrating now, talk to us — the practical answer is
> `POST /import/clients`, which is the same validation over the same CSV.

The intended shape is an SFTP account, chrooted to your own directory:

```
/<your-tenant>/
├── incoming/     you put files here
├── processed/    we move them here once loaded
└── errors/       we write rejects here
```

One directory per tenant, to be enforced by the chroot rather than by our
application — a shared directory would be one customer able to read another's
book, and no application check can undo that once the transport has allowed it.

**PGP at rest is planned and unimplemented.** When it exists you will encrypt to
a key we publish for your tenant and we will decrypt on collection. Do not send
us anything today on the assumption that it is encrypted at rest by this system:
what is in the database is encrypted under your firm's own data key, and a file
sitting in a directory is not.

**What does exist, and is tested**, is everything below this line: the schema
validation, the row-level errors, the error file, the manifest, the duplicate
detection and the size limit. `api/app/batch.py` is the gateway and
`scripts/batch_sweep.py` runs a pass over a directory tree by hand. What is
missing between you and it is the transport.

### The file

UTF-8 CSV. The header row names the columns; every required column must be
present, and a column we do not recognise is refused rather than ignored — a
column we silently dropped is a field you believed you had supplied.

Required: `id`, `scenario`, `name`, `dob`, `client_category`,
`knowledge_assessed`, `knowledge_date`, `loss_capacity_band`,
`vulnerability_flag`, `assessable_portfolio_cents`, `prior_crypto_purchases`,
`structural_acks`, `default_trade_amount_cents`.

Optional: `jurisdiction`, `residency`, `domicile`, `note`.

**Money is whole cents. Never a decimal.** `assessable_portfolio_cents` for a
$25,000 portfolio is `2500000`. This is not a formatting preference: a
determination has to reproduce exactly years later, and a number that went
through floating point does not. A decimal anywhere in a file is a rejected row.

`structural_acks` is a list in one cell, separated by `|` — a comma cannot be
used inside a CSV field without quoting, and quoting is where hand-edited files
go wrong.

### What happens to a bad row

**A malformed row does not fail the run.** Nobody is watching at 02:00, and
rejecting four thousand good rows because eleven are malformed would take your
whole book stale over one bad date. We load what we can and write the rejects
to `errors/<yourfile>.errors.csv`:

```csv
source_file,row,column,problem
nightly-book.csv,3,dob,"'1985-13-45' is not a date (expected YYYY-MM-DD)"
nightly-book.csv,7,loss_capacity_band,"'high' is not a whole number between 1 and 5"
```

Row numbers are the ones you see in a spreadsheet — row 1 is the header, so the
first data row is row 2. Fix those eleven rows and drop *those*; you do not need
to re-cut the file.

**A file nobody could read is different.** A missing header, an unrecognised
column, or a file that is not UTF-8 fails the whole run — every row would fail
for the same reason, and four thousand identical error lines is a worse answer
than one. That file **stays in `incoming/`**, so the one file that needs
attention is not buried in `processed/`.

### Knowing what happened

A `manifest.json` is written back into your directory after each run:

```json
{
  "ran_at": "2026-08-24T02:14:07+00:00",
  "files": [{"filename": "book.csv", "status": "completed_with_errors",
             "rows_written": 3991, "rows_rejected": 9,
             "error_file": "book.errors.csv"}],
  "totals": {"files": 1, "rows_written": 3991, "rows_rejected": 9}
}
```

Your scheduler can read that without calling an API, which is the point — you
are on files rather than HTTP for a reason.

**Sending the same file twice is detected and not refused.** Re-sending after a
failed night is the right thing to do. We record the content hash of every run,
so a duplicate is visible in your import history rather than silently doubled or
silently dropped.

**Size limit: 32 MB per file.** Split a larger book, or talk to us.

---

## 3. Webhooks

So that determinations land in the case system you already watch, rather than
in a console somebody has to remember to open.

### Events

| Event | Fires when |
|---|---|
| `decision.recorded` | A determination is made |
| `decision.overridden` | An approver overrides one |
| `queue.referred` | A determination needs a human |
| `pack.staged` | Rule content is signed and awaiting publication |
| `pack.published` | Rule content is put in force |
| `source.stale` | A regulatory source has not been checked recently enough |

Register an endpoint with no event list and you get all of them — we would
rather tell you too much than have you not hear about something you assumed you
had subscribed to.

### Verifying a delivery

Every request carries three headers:

```
X-Quolin-Event:      decision.recorded
X-Quolin-Delivery:   whd_8fK2mQ...
X-Quolin-Signature:  t=1756032000,v1=5a3f...
```

**Check the signature before you parse the body.** The signed material is
`{timestamp}.{body}`, HMAC-SHA256 under your endpoint's secret:

```python
import hashlib, hmac, time

def verify(secret: str, body: str, header: str, tolerance: int = 300) -> bool:
    parts = dict(p.split("=", 1) for p in header.split(",") if "=" in p)
    stamp, given = int(parts["t"]), parts["v1"]
    if abs(int(time.time()) - stamp) > tolerance:
        return False                       # too old — a captured delivery replayed
    expected = hmac.new(
        secret.encode(), f"{stamp}.{body}".encode(), hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(given, expected)
```

The timestamp is **inside** the signed material, not merely beside it. A
signature over the body alone is replayable forever by anyone who captures one,
which for a decision webhook means replaying last year's ALLOW at your case
system today. Reject anything outside your tolerance.

Compare in constant time. A byte-by-byte comparison of a MAC is a forgery
oracle for anyone who can measure it.

### Retries, and what we expect of you

We attempt a delivery up to **six times** over roughly half an hour:

| Attempt | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|
| Wait before | — | 30s | 2m | 5m | 15m | 30m |

**Read those as floors, not as a timetable.** A scheduled task asks once a
minute whether anything is due, and starting it takes a further several seconds,
so the first attempt on a new event lands within about a minute and a half and
the 30-second step above is in practice about a minute. The later intervals are
long enough that the scheduler adds nothing to them. We would rather tell you the
number you will measure than the one in the backoff table.

Any `2xx` is success. A `3xx` is not — a receiver that answers 302 has not taken
it, whatever it meant by that.

After six failures the delivery is **dead-lettered, visibly**. It stays in your
delivery log marked `dead` with the last error we saw, and you can read it back.
We do not silently drop alerts: a dropped alert is worse than one that never
existed, because you believe you are being told.

**Please make your handling idempotent.** We retry, so you will occasionally see
the same delivery twice — `X-Quolin-Delivery` is a stable id you can deduplicate
on. That is the one thing we ask of you in exchange for retrying.

**Answer quickly.** We time out after 10 seconds and treat it as a failure. Take
the payload, put it on your own queue, and return 204.

---

## 4. REST API

> Being built. The shape below is what it is being built to.

Versioned under `/v1`. OAuth2 client-credentials for authentication, an
idempotency key on every write, cursor pagination on every list.

| Endpoint | Does |
|---|---|
| `POST /v1/clients` | Upsert a client |
| `POST /v1/evaluations` | Request a determination |
| `GET /v1/decisions/{id}` | Read one back, with its evidence |
| `GET /v1/decisions` | List, cursor-paginated |
| `GET /v1/artefacts/{id}` | Retrieve a generated document |
| `GET /v1/queue` | Referrals awaiting a human |
| `POST /v1/bulk` | Trigger a batch evaluation |

### Idempotency

**Send an `Idempotency-Key` header on every write.** You will retry — a dropped
response, a redelivered queue message, a script run twice — and without a key
each retry writes a second determination into an append-only evidence chain that
cannot be tidied up afterwards. Duplicated evidence is not cosmetic: it is two
records of a decision that was made once.

We return the **original response**, verbatim, rather than re-executing.
Re-executing would produce a different decision id and a different position in
the hash chain, which is exactly what you sent the key to avoid.

Re-using a key with a *different* body is refused. You believe you sent two
things; answering with the first one's response would be a strange way to tell
you otherwise.

---

## 5. Positions

Concentration limits are the rule most likely to refuse a trade, and they are
computed from what a client already holds. So where positions come from matters,
and the snapshot records which source was used.

**Custody read adapters are not built.** The execution document says to choose
vendors by the first customers' actual stacks, and there are no first customers
yet — picking two now would be inventing the input that decision is supposed to
be made from. Until then:

- **Supply positions via batch**, alongside the client book; or
- **Attest manually**, which records that a person asserted the figure.

A client with no positions on file is assessed as holding nothing, and any
determination made for them says so. That is stated on every import result and
on the client's own screen — an unstated zero would read as a real portfolio
that happens to be empty.

---

## 6. What is not connected

`/integrations` in the product lists every external edge, its status, and what
it would be in production. It is computed rather than asserted, so it cannot go
stale into a lie. Read it before you assume something is live.

The demo tenant runs entirely on fixtures and says so — its cast is invented and
its positions are a file in our repository. Nothing you see in a demo is a real
portfolio.
