# Deployment

Three ways to run Quolin, in increasing order of how much of it is exposed to
the internet. Pick the least of these that does the job — a demo on a laptop
leaks nothing.

| | Where it runs | Who can reach it | Use when |
|---|---|---|---|
| **Local** | Your machine | Nobody | Development, and any demo given in person on your own screen |
| **Tunnel** | Your machine, published over HTTPS | Anyone with the URL, while it runs | Testing the PWA on a phone; a demo where they hold the device |
| **Hosted** | Fly.io (Sydney) + Vercel | Anyone with the URL and an account | A link someone opens after the meeting |

Everything below assumes the database has been seeded, because sign-in is
per-person and a deployment with no people in it has nobody who can log in.
`make seed` creates the demo firm's five staff and prints their addresses.

---

## What the lock actually is

Say this before anyone asks. The gap is much smaller than it was — Stage 2
replaced the shared passcode with real accounts — but getting caught overstating
what is here still costs more than the feature is worth.

- **Per-person accounts, with roles.** `viewer`, `operator`, `approver`,
  `pack_signatory` (per jurisdiction), `tenant_admin` and `quolin_support`.
  Every route names the roles that may call it and `test_rbac.py` asserts that
  against the live route table.
- **Every action is attributed to a person.** The actor on an audit row comes
  from the session and nowhere else; a write with nobody behind it raises rather
  than inventing a name. An override approver and a pack signatory are the
  account that acted, not a name typed into a box.
- **Two-person rules are enforced in code.** Nobody overrides a determination
  they ran; nobody publishes rule content they signed. Compared by account, not
  by the name printed on the document.
- **Sign-in is a password with optional TOTP, or the firm's own identity
  provider over OIDC.** See *Single sign-on* below for what the SSO path does
  and does not do.
- **What is still honest to say plainly:** the deployment serves one tenant, so
  a consultant who holds roles at three firms signs in to whichever deployment
  they are pointed at rather than switching between them; rate limiting is
  in-process, so it resets on restart and is not shared across instances; and
  `quolin_support` grants are time-boxed but nobody is yet using them.

`api/app/auth.py` holds the session mechanics and `api/app/identity.py` decides
who somebody is. Both are short. Read them before describing them to anyone.

---

## Environment variables

| Variable | Required | Default | What it does |
|---|---|---|---|
| `QUOLIN_MASTER_KEY` | **yes** | none — API will not start | 32 random bytes, base64. Wraps every customer's data key. `make master-key` generates one. |
| `DATABASE_URL` | migrations, seed and workers only | local Postgres on :5433 | The **schema owner**. Owns every table and append-only trigger, exempt from FORCE row-level security. **Never set it on the API** — FP3-04, and `make deploy-check` refuses a deploy while it is. |
| `APP_DATABASE_URL` | **yes** for the API | `quolin_app` on local :5433 | What the API connects as. Not a superuser, does not own the tables, does not hold BYPASSRLS — all three would switch row-level security off. |
| `QUOLIN_COOKIE_SECURE` | yes when hosted | `false` | `true` sets `Secure` + `SameSite=None`. See below. |
| `QUOLIN_ALLOWED_ORIGINS` | yes when hosted | localhost:3000/3100 | Comma-separated CORS allowlist. Never `*`. |
| `QUOLIN_SESSION_HOURS` | no | `12` | Absolute session lifetime. |
| `QUOLIN_IDLE_MINUTES` | no | `120` | Idle timeout. |
| `QUOLIN_MAX_ATTEMPTS` | no | `8` | Failed logins before lockout. |
| `QUOLIN_LOCKOUT_SECONDS` | no | `300` | Lockout window. |
| `QUOLIN_REAUTH_MINUTES` | no | `5` | How recently a credential must have been presented to sign a pack. |
| `QUOLIN_TOTP_WINDOW_STEPS` | **no — local only** | `1` (±30s) | Widens the window a one-time code is accepted in, in thirty-second steps. Exists so a demo can be driven from a terminal and a browser on one laptop. **Never set it on a deployment** — each step is another thirty seconds a code read over a shoulder still works. `make deploy-check` refuses a Fly deploy while it is set, and `guard_task_credentials.py` fails `make guard` if it appears in an ECS task. |
| `QUOLIN_OIDC_ISSUER` | no | unset — SSO off | The identity provider's issuer URL. All four OIDC variables are needed together. |
| `QUOLIN_OIDC_CLIENT_ID` | with issuer | — | This deployment's client id at the provider. |
| `QUOLIN_OIDC_CLIENT_SECRET` | with issuer | — | Its client secret. A secret, so never in `fly.toml`. |
| `QUOLIN_OIDC_REDIRECT_URI` | with issuer | — | `https://<api-host>/auth/oidc/callback`. Must match the provider's registered value exactly. |
| `QUOLIN_OIDC_POST_LOGIN_URL` | no | `http://localhost:3100/` | Where the browser lands after a federated sign-in. Set this to the web app. |
| `QUOLIN_OIDC_SCOPES` | no | `openid email profile` | Scopes requested. `email` is required — an account cannot be matched without it. |
| `WATCH_MODE` | no | `replay` | `live` makes every polling path return 501 — there is no live adapter. |
| `NEXT_PUBLIC_API_BASE` | yes (web) | `http://localhost:8000` | Where the web app sends requests. Baked in at build time. |

### Single sign-on

Off unless the four `QUOLIN_OIDC_*` variables are all set. That is a supported
state, not a misconfiguration: the password fallback with TOTP exists precisely
for tenants with no identity provider, and the demo is one of them.

**Against a broker, not against a customer's IdP directly.** Quolin speaks OIDC
to WorkOS (or Auth0, or Entra); the broker speaks SAML, Okta, ADFS or whatever
the customer's security team actually runs. That is what "we support SAML"
means here and it is worth being exact about it in a diligence conversation: a
customer moving from Okta to Entra is a change to their tenant's configuration
at the broker, not a release of ours.

**It authenticates; it does not provision.** A subject the deployment has never
seen is refused. On a person's first federated sign-in their provider `sub` is
linked to the account that already holds their verified email address, so they
keep their roles, their history and their name in the audit trail — and after
that the link is what identifies them, so the address can change without
anything breaking. Somebody with no account here does not get one by signing in,
because roles are the firm's decision and an IdP that could grant them silently
would make the quarterly access review a description of a directory group.

**An unverified email claim is never honoured.** At a provider that lets a user
set any address on their own profile, `email` is a text field until
`email_verified` says otherwise — so honouring an unverified one would let
anybody with an account there claim any account here.

**Signing still demands a step-up.** Whether the provider asked for a second
factor is its policy and is not visible to us, so a federated session is
recorded as not having presented one. `QUOLIN_REAUTH_MINUTES` still applies
before a pack can be signed.

To turn it on, register `https://<api-host>/auth/oidc/callback` as the redirect
URI at the provider, then:

```
fly secrets set QUOLIN_OIDC_ISSUER='https://your-broker.example'
fly secrets set QUOLIN_OIDC_CLIENT_ID='...'
fly secrets set QUOLIN_OIDC_CLIENT_SECRET='...'
fly secrets set QUOLIN_OIDC_REDIRECT_URI='https://quolin-api.fly.dev/auth/oidc/callback'
fly secrets set QUOLIN_OIDC_POST_LOGIN_URL='https://quolin.vercel.app/'
```

`api/tests/stub_idp.py` is a full identity provider that the suite runs on a
loopback port, so the whole flow — discovery, PKCE, token exchange, signature,
`nonce` — is exercised in CI against something that behaves like a real one.

### The cookie flag is the one people get wrong

`QUOLIN_COOKIE_SECURE` has no safe default, so it is explicit.

- **Local** — web on `:3100`, API on `:8000`. Different origins, but the *same
  site*: SameSite is computed on the registrable domain and both are
  `localhost`. Set `false`, get `SameSite=Lax`, which is stricter and works.
- **Hosted or tunnelled** — `quolin.vercel.app` and `quolin-api.fly.dev` are
  genuinely different sites. The cookie is only sent with `SameSite=None`,
  which browsers only honour alongside `Secure`, which requires HTTPS. Set
  `true`.

Getting this wrong produces one symptom in both directions: login appears to
succeed and every subsequent request is 401, because the cookie was set and
then never sent.

### The master key is not a password

They fail differently and it is worth being clear about which is which.

A password is authentication: somebody who forgets theirs gets a new one, and
nothing is lost. The master key is the top of an envelope: every customer has a random data
key, that key is what actually encrypts their names, dates of birth, snapshots
and documents, and `tenant_keys` holds it wrapped under the master key. **Lose
the master key and the data is gone** — not inaccessible pending a reset,
gone, including in every backup, because a backup contains the wrapped key and
not the thing that opens it.

That is the property being bought. A stolen database dump decrypts nothing,
because the two secrets live in two systems. The price is that the second
system has to be somewhere you will still have it in a year.

Dev and CI use a key committed in the `Makefile`, and its decoded bytes read
`quolin-dev-key-not-a-secret-0001` so that nobody can mistake it for one. A
hosted instance takes its key from `fly secrets`, and `make deploy-check`
refuses to deploy without it.

---

## Local

```
make up && make seed
make api                                        # terminal 1
make web                                        # terminal 2
```

---

## Tunnel — for testing on a phone

Two Cloudflare quick tunnels: one for the API, one for the web app. Both get
random `*.trycloudflare.com` hostnames that disappear when you Ctrl-C.

```
brew install cloudflared
```

Terminal 1 — the API, with the cross-site cookie flag on, because the tunnel
puts the web app on a different hostname:

```
cd ~/Desktop/Quolin && QUOLIN_COOKIE_SECURE=true make api
```

Terminal 2:

```
cd ~/Desktop/Quolin && WEB_PORT=3100 make tunnel
```

The script prints a URL. Open it on the phone, then Safari → Share → Add to
Home Screen.

> **Not yet run end to end.** `scripts/tunnel.sh` has still never been executed
> against a real device. Everything else here has been walked; the phone has
> not. Its pre-flight is no longer unproven — the API check, the port check and
> the single-dev-server check ran on 2026-08-26 — but a pre-flight is not the
> flight.

The CORS gap this section used to leave to the reader is closed, and the reason
it could not simply be fixed is worth keeping. A Cloudflare quick tunnel's
hostname is random and is only known once cloudflared connects, which is after
the API has started, and it differs on every run — so it cannot be put in
`QUOLIN_ALLOWED_ORIGINS` in advance. The script therefore asks the running API
whether it accepts the origin, and if not prints the exact command and waits
while you restart it. Restarting the API does not disturb its tunnel;
cloudflared reconnects to the port.

---

## Hosted

Requires accounts you hold, and credentials this repository must never contain.

### API + Postgres — Fly.io, Sydney

```
brew install flyctl && fly auth login

fly launch --no-deploy --copy-config --name quolin-api --region syd
fly postgres create --name quolin-db --region syd
fly postgres attach quolin-db          # sets DATABASE_URL — see below
```

**Then take `DATABASE_URL` off the API, because it is the schema owner.**
`fly postgres attach` sets it for you and that is the wrong credential for this
process: it owns every table and every append-only trigger, it is exempt from
FORCE row-level security, and it is what `scripts/rechain.py` uses to rewrite
evidence hashes. Nothing in the request path uses it and the container runs no
migration at start, so it would sit in the environment of the first process an
attacker reaches for no purpose at all. FP3-04 removed it from the ECS task
definition and `scripts/guard_task_credentials.py` keeps it out; this line put
it back on the other deployment target, where nothing was checking.

```
fly secrets unset DATABASE_URL --app quolin-api
fly secrets set APP_DATABASE_URL='postgres://quolin_app:...@quolin-db.internal:5432/quolin'
```

The `quolin_app` role is created by the migrations. It is deliberately not a
superuser, does not own the tables and does not hold BYPASSRLS — because each of
those three silently switches row-level security off, and a policy that is
present and inert is worse than no policy.

`make deploy-check` now refuses to deploy while `DATABASE_URL` is set on
`quolin-api`, so this is a step you cannot skip by forgetting it.

Secrets. These are **not** in `fly.toml`, because `fly.toml` is in git:

```
fly secrets set QUOLIN_MASTER_KEY='...'      # make master-key
fly secrets set QUOLIN_ALLOWED_ORIGINS='https://quolin.vercel.app'
```

Then deploy. `make deploy` runs the test suite, checks the preflight, and only
then replaces the machine:

```
make deploy-check     # logged in? both secrets present? — touches nothing
make deploy           # test + deploy-check + fly deploy
```

The split exists so "you forgot to set a secret" fails before a machine is
replaced rather than after. `QUOLIN_MASTER_KEY` missing means the API will not
start at all; `QUOLIN_ALLOWED_ORIGINS` missing means it starts and refuses every
request the Vercel app makes, which is the more confusing of the two.

Then seed the database once — **from your machine, not from the API container.**
The seed runs as the schema owner, and the point of the step above is that the
API machine does not hold that credential. `fly proxy` puts the database on a
local port for as long as the command is running and nothing is stored anywhere:

```
fly proxy 5433:5432 --app quolin-db &      # leave running
DATABASE_URL='postgres://quolin:...@localhost:5433/quolin' \
  make seed
```

Migrations are applied the same way, for the same reason. `fly ssh console -C
"... seed.seed"` is what this said before, and it only worked because
`DATABASE_URL` was on the machine — so following it now fails with the
`app.owner_only` import error, which is the boundary telling the truth rather
than something to work around.

### Web — Vercel

Root directory `web`. One environment variable:

```
NEXT_PUBLIC_API_BASE = https://quolin-api.fly.dev
```

It is `NEXT_PUBLIC_`, so it is compiled into the client bundle and **changing
it requires a rebuild**, not just a redeploy of the same artefact. It is also
public by definition — never put anything secret behind that prefix.

Once Vercel gives you the final hostname, make sure it matches
`QUOLIN_ALLOWED_ORIGINS` above exactly, including scheme and no trailing slash.

### Region

Sydney for the same commercial reason the build spec gives: it shortens vendor
risk review for Australian buyers. Do not claim offshore hosting is prohibited
— APRA permits it with safeguards, and saying otherwise to someone who knows
the rules costs the room.

---

## Migrating a database that has rows in it

Dev never needs this — `make seed` drops the schema and rebuilds it by running
the migrations, so the demo database is always produced by the same statements
as staging. Every other environment does:

```
make migrate-check                     # what would be applied, printed
make migrate                           # apply it
```

**One migration matters more on a hosted database than in dev.**
`0029_maintenance_role` creates the `quolin_maintenance` role and grants it to
the account that applies the migration — which is the account the background
workers connect as. Without it, tenant enumeration is governed by the policy on
`tenants`, and that policy is only walked past by a superuser or a role holding
BYPASSRLS. Development's owner is both. **An RDS master account is neither.** On
a database where this migration has not been applied, every scheduled job
enumerates zero firms, does nothing, and exits 0 — including `health-alerts`,
which would report all-clear for the life of the deployment.

Apply it as the same role the workers will use. If migrations are applied by one
account and workers connect as another, grant it explicitly:

```
psql "$DATABASE_URL" -c "GRANT quolin_maintenance TO <the workers' role>"
```

`tests/test_worker_tenant_enumeration.py` asserts this by connecting as a role
with neither privileged attribute, so the check is real rather than a comment.

**One migration needs a second step.** `0004_chain_anchors` gives each customer
their own evidence chain, starting at their own recorded anchor rather than at
the constant every chain used to share. Decisions written before it was applied
were hashed against the old start, so after upgrading they are intact records
whose arithmetic is out of date, and `/evidence/verify` will say so. The fix is
to recompute:

```
make rechain                           # dry run: what would change
make rechain ARGS=--apply
make rechain ARGS="--apply --force"    # required, because a stale chain does
                                       # not verify and the tool refuses to
                                       # guess whether that is why
```

**A rechain is a recorded event, not a maintenance detail.** `--apply` now
requires `--reason` and `--by`:

```
make rechain ARGS="--apply --reason 'migrated across 0004' --by you@example.com"
```

This is the one tool here that rewrites evidence, and the only thing separating
it from a tamper is that somebody meant it and said so. Both are recorded:

* `chain_rechains` — one append-only, tenant-scoped row per rewrite, carrying
  the table, the operator, the reason, **the tip before**, the tip after and how
  many rows moved. `tip_before` is the field that matters: it is what lets
  somebody holding an export from before the rewrite reconcile it against one
  taken after, rather than merely observe that every hash differs.
* two chained audit events, `evidence.rechain.begin` and
  `evidence.rechain.done`. Two rather than one so an interrupted rewrite still
  says somebody started it — a record written only on success is absent exactly
  when something went wrong.

A run that finds nothing to do still records itself. "Did anyone rechain this
firm" is a question an auditor asks, and a record kept only when the answer was
yes-and-it-changed-something cannot answer it. A dry run records nothing and
needs neither flag, because reading is not rewriting.

Read `scripts/rechain.py`'s header before running it with `--apply`. It is the
only tool in this repository that rewrites stored records, and the reason it
asks twice is that recomputing hashes over a record somebody has *altered*
would make the alteration consistent rather than reveal it.

**And one migration is a pair with a step in the middle.** `0005_tenant_keys`
adds an empty ciphertext column beside each column that is becoming encrypted.
`0006_encrypted_columns` drops the plaintext and renames the ciphertext into
its place — and refuses to run while any row is still unencrypted, so there is
no way to reach it in the wrong order by accident. Filling the gap is a script
rather than the second half of `0005` because encrypting the stored snapshots
means suspending append-only on `decisions`, which is something an operator
does deliberately with the act recorded, not something a migration does quietly
on deploy.

```
make migrate                           # stops at 0006 and says what is missing
make encrypt-existing                  # dry run: how many rows, per column
make encrypt-existing ARGS=--apply
make migrate                           # now completes
```

Between the two, the database is at `0005` and **that is a working state** —
the application reads the plaintext columns until `0006` lands, so an
interrupted upgrade serves traffic rather than errors.

Dev never sees any of this: `make seed` runs every migration against empty
tables and then writes ciphertext from the first row onward.

### The artefact files are a separate job, and a manual one

The migrations move rows. They do not touch the PDFs already on disk, which were
written before any of this and are still readable by anyone who can list the
directory.

After the upgrade, artefacts are written to `artefacts_out/{tenant}/` with a
`.enc` suffix. The old files sit at the top level with neither. Nothing reads
them any more — the download endpoint looks for the sealed path, does not find
it, and returns `410 artefact file missing; regenerate`, which is the right
answer and the right prompt. But nothing deletes them either.

So: regenerate the artefacts anyone still needs, confirm they download, then
remove the loose `.pdf` files from the top of `artefacts_out/` yourself. Leaving
them is the one place where an upgraded deployment is less private than a fresh
one.

---

## Rotating the master key

Rotate when the key has been exposed, when someone who had it leaves, or on
whatever schedule your auditor asks for.

What rotation does here is rewrap: each customer's data key is unwrapped under
the old master key and rewrapped under the new one. **No ciphertext is
rewritten.** Not one row of `decisions`, not one document. The data keys
themselves are unchanged — only the envelope around them moves. That is the
whole answer to an exposed master key, and it avoids rewriting a table of
evidence to change nothing an auditor can observe.

Re-keying a *customer's* data key is a different operation, with a different
justification and a real rewrite of their evidence. It is not this, and
`scripts/rotate_keys.py` deliberately does not offer it.

```
export NEW_MASTER_KEY="$(make master-key)"
make rotate-keys                       # dry run — unwraps and rewraps in memory,
                                       # then checks the result opens again
make rotate-keys ARGS=--apply
fly secrets set QUOLIN_MASTER_KEY="$NEW_MASTER_KEY" --app quolin-api
```

**The order matters and only in one direction.** Rewrap first, set the secret
second. A process already running holds its unwrapped data keys in memory and
is unaffected by either step, so there is no outage — but a process that
*starts* between them reads the old master key and cannot open anything. Since
`fly secrets set` restarts the machine, doing it in this order means the
restart is the thing that picks up the new key.

Running the script twice is safe. It detects a row already wrapped under
`NEW_MASTER_KEY` and skips it rather than failing, so an operator who is unsure
whether the first run committed can simply run it again. It stops outright,
before writing anything, if a row opens under neither key — that means one of
the two keys is wrong, and guessing which would seal the row shut permanently.

Keep the old key until the new one has served traffic through a restart. After
that, destroy it: while both exist, the property that a stolen dump is inert
depends on both being held as carefully.

---

## Keeping the watch service current

Freshness on `/currency` is computed from when each source was last checked, so
without something checking, every regime drifts to STALE and the screen is
telling the truth about a deployment nobody is running.

```
make watch-tick                        # locally, or from cron
```

Hosted, as a Fly scheduled machine:

```
fly machine run . --schedule daily --command "uv run --no-dev python -m scripts.watch_tick"
```

This runs in **replay mode**. It polls the fixture, not any regulator. That is
not a limitation of the scheduler — there is no live adapter at all, and
`WATCH_MODE=live` returns 501 rather than pretending. The scheduled job proves
the cadence machinery works; it does not make the monitoring real.

---

## The quarterly access review

```bash
make access-review ARGS="--out reviews/2026-Q3.md"
```

One command, and the output is the document rather than the raw material for
one: findings first, the roster underneath as evidence for them, and a sign-off
block at the bottom. The SOC 2 control is not "access is correct" — it is that
the report was generated, read, and signed off on a cadence with the decisions
recorded — so the thing worth optimising is that producing one is free.

Against staging or a hosted deployment, run it where the database is:

```bash
fly ssh console -C "uv run --no-dev python -m scripts.access_review"
```

Add `--json` for an evidence archive, `--inactive-days N` to change the window,
and tenant ids as positional arguments to review several in one report. Tenants
are **named, not discovered** — under `FORCE ROW LEVEL SECURITY` a query for
"every tenant" returns the one in scope, so a discovery mode would work in
development and silently review nothing in production.

**What it flags.** Accounts that are suspended but still hold grants; support
access with no expiry; people holding both halves of a two-person rule; grants
nobody has ever used or has not used inside the window; signatories with no
qualification recorded; grants naming a user the tenant cannot resolve; and
anybody holding a role in `MFA_REQUIRED_ROLES` with no second factor enrolled.
That last one is worth knowing about: **nothing currently enforces that constant
at sign-in**, so this report is the only place it is checked.

**What it does not do.** It changes nothing — no grant revoked, no account
suspended. Removing somebody's access is a decision that needs a name against
it. It also does not fail on findings: the exit code is 0 whether it found five
things or none, because a review that could fail a build is a review people
learn to make empty.

The last line of the report is a SHA-256 of everything above it, so that "the
report that was signed" is a specific document rather than a description of one.
Keep the file; that is the evidence.

---

## Provisioning access

Until fix-pack 2 a person and a role grant could only be created from a database
shell, and `identity.grant_role` defaulted its granter to the string
`bootstrap`. The access review then reported, accurately and uselessly, on
permissions whose authorisation was a word.

There are now three routes, and all three are `quolin_operator` only, require a
second factor, require a credential presented in the last few minutes, and write
a chained audit event:

```
POST /admin/users                      {"email": ..., "display_name": ...}
POST /admin/users/{user_id}/roles      {"role": ..., "jurisdiction": ...,
                                        "qualification_ref": ...,
                                        "expires_at": ...}
POST /admin/roles/{grant_id}/revoke
```

No password is set. An account created by an administrator and an account that
has chosen a credential are different states, and collapsing them means an
invited user exists with a password somebody else typed.

**A customer's `tenant_admin` cannot provision, deliberately.** A firm's
administrator who could grant roles could grant themselves `quolin_operator`,
which is the role that publishes rule content to every tenant. Splitting the
vocabulary into "roles a customer may grant" and "roles only we may grant" is a
larger design decision and has not been made. Nobody has lost anything: this
replaces a psql prompt, not a screen.

**`bootstrap` still exists and is now scoped.** The seed has to create a firm's
first administrator and there is genuinely nobody to attribute that to, so
`identity.bootstrapping()` permits it for the length of that block. Nothing that
answers a request enters it, so a grant made through the API always names an
account somebody can be asked about.

`qualification_ref` on a `pack_signatory` grant is load-bearing rather than
decorative: publication reads it to decide whether a signature can carry content
to `REVIEWED`. A placeholder there keeps the pack at `PENDING_REVIEW`. See Q-02.

## Revoking access

Two different questions, and they have different answers.

**One person should no longer have access.** Remove their role grants, or set
their `users.status` to `suspended`. Sign-in checks status, so the next attempt
fails — but a session already issued keeps working until it expires, so revoke
that too. Their row is never deleted: the audit trail names it, and an audit
trail with a dangling actor is worse than one naming somebody who has left.

**Everyone should be signed out now.** This is the credential-in-the-wrong-place
case, and it does not wait for anything to expire:

```
curl -X POST https://quolin-api.fly.dev/auth/revoke-all \
  -H "Cookie: quolin_session=<your session>"
```

`/auth/sessions` lists what is currently live, so revoking is a decision made
against something visible rather than a guess.

---

## What is not here

This list said the opposite of the truth on four counts until 2026-08-26 — it
described per-user accounts, live polling, database-backed rate limiting and
automated backups as absent when all four had shipped. `README.md` records how
that happened. The corrected version, and the reason each one is still worth
naming:

- **Nothing below has run in a deployed environment.** Everything in this
  document describes applying Terraform nobody has applied. Every measurement it
  quotes came from a developer machine or from CI, and `README.md` has a table
  saying which. That is the gap the rest of this list hangs off.
- **Horizontal scale past one task is untested.** Rate limiting reads
  `auth_attempts` from the database, so it is shared — but `api_desired_count`
  is a number that met a budget on one machine, and there is no autoscaling
  rule and no measurement of where the next knee is.
- **A restore from a real automated backup.** `backup_retention_days` is set and
  `make restore-drill` runs weekly against a development database. Restoring
  from an RDS snapshot is a different act, and the one the runbook assumes.
- **A live regulator feed in production.** The polling adapters exist and run;
  what does not exist is a deployment running them on a schedule against real
  publications, with somebody reading what they raise.


## What it will serve, and what happens when it will not

§S12 measured it: twenty concurrent sessions against tables holding twenty firms
— ten thousand clients and forty thousand determinations — with three API tasks.

| | p99 | Budget |
|---|---|---|
| Interactive determination, end to end | 234ms | 500ms |
| Dashboard | 217ms | 1s |
| Document, from Generate to file | 2.9s | 5s |
| Interactive p99 while a bulk sweep runs | 1.25x | 2x |

Measured on a development machine against a generated model, so treat them as
the shape of the system rather than as a deployment's latency — staging does not
exist yet. `make load-model` and `make load-test` reproduce them, and
`.github/workflows/load-test.yml` runs the same thing weekly.

**Two numbers that must move together.** `QUOLIN_MAX_CONCURRENT_REQUESTS`
(default 24) sets both the request thread limiter and the database pool. Raising
one without the other is what produced `QueuePool limit of size 5 overflow 10
reached` under load: threads admitted to work they had no connection to do.

**`api_desired_count` is 3.** One Python process is one core of bytecode, and
rendering a document is several hundred milliseconds of it during which that
process serves nobody. It was 1 until §S12, because login rate limiting lived in
process memory; that counter is in Postgres now.

## A dedicated stack for one customer

§S11: the same Terraform, different variables. `make new-stack ARGS="--slug acme
--zone-id ..."` allocates a network range from `infra/envs/allocations.md`,
writes the tfvars and the backend config, and records the allocation.
[docs/runbooks/dedicated-stack.md](runbooks/dedicated-stack.md) is the procedure
from there: apply, populate the one secret Terraform must not hold, migrate,
prove it with `make rls-probe` and `make smoke`, hand over — and the tear-down,
including the parts people skip.

Nothing about the application differs between a shared and a dedicated stack,
and `scripts/guard_no_tier_divergence.sh` fails the build if that stops being
true.

## Evidence for an audit

`make evidence-pack ARGS='--signed-by <a reviewer>'` collects the six controls
for a window — access review, chain verification, replay, audit extract, restore
drill — hashes every file into a manifest, and refuses to call the pack complete
when one is missing. `--verify` checks the hashes and reports anything present
the manifest does not list.

The sign-off names somebody resolved against the users table who holds a role in
the firm. The SOC 2 control is that the report was read, not that it was
generated, so a pack with no name against it evidences the wrong half.

Packs are not committed — see `.gitignore` and the note beside it. They belong in
the evidence archive an auditor is pointed at.

`docs/threat-model.md` is the review this all sits under, including the parts it
cannot tell you.

## Operating it

### One entrypoint convention, and it is the image's PATH

`api/Dockerfile` installs dependencies into `/app/.venv` and puts
`/app/.venv/bin` at the front of `PATH`. **`python` in this image is the
virtualenv's python**, everywhere: the API's own `CMD`, the healthcheck, every
scheduled task's `command` override, and a shell in a running container. Nothing
wraps itself in `uv run`, and nothing needs to.

That sentence is a fix rather than a description. The API's `CMD` used to wrap
itself and the three scheduled tasks in `infra/compute.tf` overrode it with a
bare `["python", "-m", "scripts.…"]`, which resolved to the base image's
interpreter. Every deployed scheduled task died on its first third-party import,
which silently disabled the entire monitoring tier — the watch sweep, the weekly
comparison, and the health job that would have reported the outage, including
the heartbeat written so a dead monitor can be told from a quiet one.

Two reasons it is PATH and not a wrapper. A wrapper has to be remembered at
every call site, and three task definitions are the proof of what happens when
one is not. And `uv run` was repairing the image on the way past: there was no
`.dockerignore`, so `COPY api/ /app/` copied a developer's macOS virtualenv over
the Linux one, and `uv run` rebuilt it at every container start. The API worked,
the tasks did not, and the reason was invisible in both directions.

`make image-smoke` builds the image and runs every task definition's exact
command inside it — resolving the entrypoint, then importing each `-m` module.
It runs in CI on every push. The suite cannot do this: `pytest` runs under an
interpreter that has every dependency, which is exactly why the test that
existed passed about an environment production does not provide.

### The scheduled jobs

The scheduled jobs, and what each is for. All of them exit non-zero when
something is wrong, so a scheduler that watches exit codes is the minimum
monitoring this system needs.

| Command | Cadence | Exit codes |
|---|---|---|
| `make health-alerts` | every 5 minutes | 2 when anything is wrong; 1 when the checks could not run |
| `make watch-tick` | every 6 hours | 2 while a source is unreachable; 1 when the sweep could not run |
| `make deliver-webhooks` | every minute | 1 when a delivery dead-lettered on this run |
| `make artefact-worker` | every minute | 2 when a document failed to render; 1 when the pass could not run |
| `make bulk-worker` | every 5 minutes | 2 when a chunk failed; 1 when the pass could not run |
| `make settle` | daily | plans re-checks when a pack becomes effective |
| `make comparison-report` | weekly, Monday morning | 2 when a firm in shadow had nothing to compare; 1 when it could not run |
| `make batch-sweep` | DEFERRED — it reads a directory tree per tenant and this deployment has no EFS mount, no drop bucket and no SFTP server, so a nightly task would read an empty directory inside its own container forever and report success every morning. One task definition and one rule once a file has somewhere to land. | 1 when a file could not be read at all |
| `make restore-drill` | DEFERRED — run deliberately, before any release that touches evidence, and against a restored copy rather than the live database. Automating it would mean a scheduled job with credentials to restore a snapshot, which is a larger thing to hold than the drill is worth. | 2 when the restored chain does not verify |

Anything added to that table needs adding to `aws_iam_role_policy.watch_scheduler`
in the same change. The scheduler role names the task definitions it may run one
by one — a wildcard there would be permission to run the API's own task with a
different command — and a task definition missing from the list produces a
schedule that exists and is denied every time it fires.

**That rule is checked now rather than remembered.** `scripts/deployed_workers.py`
— `make deployed-workers`, and a step in CI — reads this table, the Makefile, the
schedules and the policy, and fails when any of the four disagrees. It links a
row to a task through the *module* the target runs rather than by matching names,
so renaming a resource cannot make it vacuous. A row may be marked `DEFERRED`,
and then it must carry a reason: "not deployed" with nothing beside it reads
exactly like an omission, which is what the two rows above used to be.

**Five of these had a `make` target and no scheduler at all.** Enqueued webhooks
were never sent, queued documents never rendered, bulk runs never executed — so
delta reports and the pinned-tenant UAT flow were both dead — future-dated packs
never became effective, and the batch drop was never swept. Four are deployed
now; the fifth says above why it is not.

**Each of them serves every firm, and that is why each holds `DATABASE_URL`.**
Under FORCE row-level security a query for "all tenants" returns the one in
scope, so a worker without the owner connection would have served whichever firm
`QUOLIN_TENANT` happened to name and reported success — Q-01's shape, and worse
than not running at all because it looks like it worked.
`maintenance.active_tenant_ids` is admitted by migration 0029's
`quolin_maintenance` grant, with `assert_can_enumerate` in front of it so a
connection that cannot see `tenants` refuses rather than enumerating nothing.
`scripts/guard_task_credentials.py` is where that trade is reviewed.

### When a scheduled task does not run, or runs and dies

EventBridge reports success when `RunTask` is *accepted*. What the container
then does is not its concern, so a task that starts and stops on an import looks
identical to one that did its job. Three things close that, and they are three
different incidents.

`aws_cloudwatch_metric_alarm.schedule_never_fired` watches `FailedInvocations`
on each rule — the times EventBridge could not start the task at all. The usual
cause is the task definition missing from `aws_iam_role_policy.watch_scheduler`,
which produces a schedule that exists and is denied every time it fires. One
occurrence pages: a schedule refused on every firing is not a transient.

`aws_cloudwatch_event_rule.task_stopped_badly` watches for a container in this
cluster exiting non-zero, and sends the group, the task definition and the
stopped reason to the pager. It deliberately does not filter by exit code: a job
that exits 2 because something is genuinely wrong and a task that dies on an
import both need a person, and the exit codes in the table above are what tells
them apart once somebody is reading.

`aws_cloudwatch_event_rule.task_never_started` is the third, and it exists
because the second could not reach it. An EventBridge field filter requires the
field to be present, so `exitCode = [{"anything-but": 0}]` matches only a
container that ran and exited. A container that never ran has no exit code at
all — an image that will not pull, a task that cannot be placed, a secret ARN
the execution role may not read — and `FailedInvocations` does not see it
either, because EventBridge accepted the `RunTask` and the failure happened
after that, inside ECS. Between them those two alarms left a scheduled job that
executes no line of code paging nobody. This rule matches `exitCode` **absent**
and says so in its own words: there are no application logs to read, because
nothing ran.

Both rules publish to the same topic, and both are named in
`aws_sns_topic_policy.pager_accepts_events`. A rule missing from that policy
matches, fires its target, and is refused by SNS with nothing saying so — the
same shape as a task definition missing from the scheduler policy.

`make game-day` is not scheduled. It is run deliberately — against staging when
one exists, and against a development database until then, which is where every
run of it so far has happened. It is run when
somebody wants to know whether the alerts still work — after changing a
threshold, after adding a check, and on a cadence somebody picks. It refuses to
run against production, because it creates failed sign-ins, a dead delivery and
a deep queue on purpose.

### When something is wrong

The alert names its runbook. `docs/runbooks/` holds five, and the alert's
`action` field carries the path — so the page a person receives names the
document rather than expecting them to guess which one applies.

### What the pager needs

`QUOLIN_PAGER_URL` is a URL that reaches a person. With it unset the checks
still run and still exit non-zero, and `health-alerts` says plainly that nobody
was told. That is deliberate: the failure mode to avoid is an alerting system
that reports success while alerting nobody.

### Every scheduled job leaves a pulse, and finding nothing is a fault

`worker_heartbeats` holds one row per worker: when it last ran, how many firms
it enumerated, and what it concluded. Query it. A monitor that is quiet because
all is well and one that is quiet because it is dead are indistinguishable
without it, and `health-alerts` was in exactly that position until migration
0029.

```
psql "$DATABASE_URL" -c "select * from worker_heartbeats order by ran_at"
```

A run that enumerates **zero active firms now exits non-zero** rather than
printing a summary and returning 0. On a platform with paying customers a sweep
with nothing to do has not had a quiet night — it cannot see the work. If you
see that exit code on a genuinely empty deployment, nothing should be scheduled
against it yet.
