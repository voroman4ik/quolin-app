# The rule language

**Who this is for.** Anyone who has to satisfy themselves that a Quolin rule pack
says what a regulation says — a compliance specialist, a regulatory lawyer, a
technical diligence team — without reading any Python. If you can read the
regulation, you can read the pack, and this document is the bridge.

**What it covers.** Every construct the language has. There is nothing else: no
arithmetic, no loops, no functions a pack can define, no way to call out to
anything. A pack is a list of comparisons. That is a deliberate limit and it is
the reason a non-programmer can review one.

> This document describes DSL **version 2**. Every pack declares which version
> its rules are written against, and the engine keeps every version it has ever
> shipped. [Versions](#versions) explains why, and what changed.

---

## 1. What a pack is

A pack is one regime's rules, at one version, as a JSON file. It holds:

| Part | What it is |
|---|---|
| `pack_id`, `version` | Which regime, and which revision of its content |
| `dsl_version` | Which version of *this language* the rules are written in |
| `effective_from`, `effective_to` | The dates this content governs |
| `content_status` | `REVIEWED`, `PENDING_REVIEW` or `ILLUSTRATIVE` — see §8 |
| `signed_by`, `signed_at` | The named person who accepted it |
| `thresholds` | The numbers, in one place, separate from the logic |
| `asset_classes` | How this regime classifies each instrument |
| `rules` | The comparisons |
| `reason_codes` | The plain-English text a refusal prints |

**Numbers live in `thresholds`, never inside a rule.** A rule says "compare this
to `max_crypto_concentration_bps`"; the pack says what that number is. Changing a
limit is therefore a one-line change to a named value, reviewable on its own,
and the currency screen can show what changed between two versions without
anybody reading the logic.

---

## 2. What a rule is

Every rule has the same shape:

```json
{
  "rule_id": "AU-CONC-01",
  "title": "Post-trade crypto concentration within cap",
  "applies_to": { "asset_class": ["major", "altcoin", "stablecoin", "leveraged"] },
  "predicate": {
    "op": "lte",
    "left":  { "calc": "post_trade_crypto_bps" },
    "right": { "threshold": "max_crypto_concentration_bps" }
  },
  "on_fail": "BLOCK",
  "reason_code": "CONC_EXCEEDED",
  "severity": 2
}
```

Read it as a sentence: *for these asset classes, the post-trade crypto share must
be at most the concentration cap; if it is not, block, and say `CONC_EXCEEDED`.*

| Field | Required | Meaning |
|---|---|---|
| `rule_id` | yes | Unique within the pack. Appears in the evidence, so it must not be reused or renamed casually. |
| `title` | no | What a reader sees. Defaults to the id, which is worse. |
| `applies_to` | no | When this rule has anything to say. Absent means always. §4 |
| `predicate` | yes | The condition that must hold. §5 |
| `on_fail` | yes | `REFER` or `BLOCK`. Never `ALLOW`. |
| `reason_code` | yes | Which entry in `reason_codes` explains a failure. |
| `severity` | yes | Orders findings for display. Does not affect the outcome. |
| `constraint` | no | Declares the dimension and scale this rule constrains, for cross-border resolution. Not used in single-regime evaluation. |

**A predicate states what *should* be true.** It passes when the trade is
acceptable. This is worth saying twice, because writing the failure condition by
mistake inverts every determination the rule makes while looking perfectly
sensible.

**`on_fail` cannot be `ALLOW`.** A rule that allows on failure cannot refuse
anything, so it is a rule somebody wrote by accident. The pack is refused.

### Where a rule came from

A rule may carry its **provenance**: which document says this, which section,
who checked it, and when.

```json
"provenance": {
  "source_document": "ASIC RG 227",
  "section": "s4.2",
  "verified_by": "A Qualified Specialist",
  "verified_on": "2026-03-14",
  "note": "Read together with the 2025 amendment."
}
```

Four structured fields and an optional note. The four are structured because
they are *queried* — "which rules have not been verified since the amendment"
should be a search, not a reading exercise — and `verified_on` is a date for the
same reason. The note is prose because a specialist will always have one more
thing to say.

**Provenance is optional, and complete when present.** A rule with no provenance
is legitimate: illustrative content has no source document, and claiming one
would be exactly the dishonesty `content_status` exists to prevent. What is
refused is a *partial* provenance — a rule carrying a source document and no
verifier reads as checked when nobody has checked it, which is worse than saying
nothing.

---

## 3. Outcomes

Three, in order of severity:

| Outcome | Meaning |
|---|---|
| `ALLOW` | Nothing objected. |
| `REFER` | A person must look at this before it proceeds. |
| `BLOCK` | It must not proceed. |

**The determination is the worst outcome any applicable rule produced.** One
BLOCK blocks. No rule can override another, and there is no scoring, weighting or
netting — a rule cannot "outvote" another rule. This is what makes the result
explainable: every failing rule is listed, and each one on its own is sufficient
to explain the outcome.

**Rule order does not matter.** Rules are evaluated independently and the worst
outcome is taken, so shuffling a pack's rules produces the same determination
with the same evidence. `test_properties.py` asserts this over randomly
generated packs.

---

## 4. When a rule applies

`applies_to` narrows a rule. All three filters must pass for the rule to run.

```json
"applies_to": {
  "asset_class": ["major", "leveraged"],
  "structural_flags_any": ["algorithmic_peg"],
  "when": { "op": "eq", "left": {"field": "client.knowledge_assessed"}, "right": {"const": true} }
}
```

| Filter | Passes when |
|---|---|
| `asset_class` | The asset's class, *as this pack classifies it*, is in the list. |
| `structural_flags_any` | The asset carries at least one of these flags. |
| `when` | The condition holds. Same language as a predicate. §5 |

A rule that does not apply is not evaluated and appears in
`rules_not_applicable`. It is not a pass — the evidence distinguishes "this rule
said yes" from "this rule had nothing to say".

---

## 5. Conditions

A condition is either a **comparison** or a **combination**.

### Comparisons

```json
{ "op": "lte", "left": <term>, "right": <term> }
```

| Operator | True when |
|---|---|
| `eq` / `neq` | left equals / does not equal right |
| `lt` / `lte` | left is less than / at most right |
| `gt` / `gte` | left is greater than / at least right |
| `in` / `not_in` | left is / is not one of right (right is a list) |
| `contains` / `not_contains` | left (a list) does / does not contain right |

### Combinations

```json
{ "op": "and", "of": [ <condition>, <condition>, ... ] }
{ "op": "or",  "of": [ <condition>, <condition>, ... ] }
{ "op": "not", "of": <condition> }
```

**Every branch of an `or` is evaluated**, even after one has passed. This is not
an oversight and it is not a performance mistake: the evidence has to show what
the officer would have to argue with, not only the first branch that happened to
succeed.

**`and` is the same, and that has a consequence worth stating plainly: you
cannot write a null-guard.** Recorded against FP3-20 / audit C-05.

Neither operator short-circuits, so this does **not** do what it looks like:

```json
{ "op": "and", "of": [
    { "op": "neq", "left": { "field": "client.knowledge_assessed_days_ago" },
                   "right": { "const": null } },
    { "op": "lte", "left": { "field": "client.knowledge_assessed_days_ago" },
                   "right": { "threshold": "knowledge_max_age_days" } }
] }
```

The second branch is evaluated whether or not the first one passed, so for a
client who has never been assessed it compares `null` with a number and the rule
raises `PackError` — reaching the officer as a 422 about the client record.
The guard does not guard.

**Write the rule the way DSL v2 already means it instead.** A present-but-null
field is a fact, not a hole (see §9), and a comparison against null fails on its
own terms — so the shape above is unnecessary as well as ineffective. Use the
applicability condition to say when the rule is in scope, which is checked
before the predicate runs and is what `rules_not_applicable` records.

**Why it is documented rather than changed.** Short-circuiting `and` would mean
the branches after a failure are no longer evaluated, so they would no longer
appear in `inputs_read` — and `inputs_read` is stored on every determination
ever made. Every one of them would fail to reproduce, which the chain-mismatch
runbook says to treat as tampering. Making `and` lazy is an additive DSL v3
change, taken deliberately with its own version, not a fix to v2.

---

## 6. Terms — the things being compared

Five kinds, and a term is exactly one of them.

| Term | Reads | Example |
|---|---|---|
| `const` | A literal written in the rule | `{"const": 18}` |
| `field` | A fact from the frozen snapshot | `{"field": "client.age_years"}` |
| `calc` | A registered derived value (§7) | `{"calc": "post_trade_crypto_bps"}` |
| `threshold` | A number from this pack's `thresholds` | `{"threshold": "adult_age_years"}` |
| `lookup` | A row from a table in `thresholds` | below |

```json
{ "lookup": "min_loss_band_by_volatility", "key": { "field": "asset.volatility_band" } }
```

A lookup reads the table named, keyed by whatever the `key` term resolves to.
Table keys are text in JSON, so a numeric key is matched by its text form —
volatility band `4` finds the row `"4"`.

### What a rule may read

Only the frozen snapshot. Not the database, not the clock, not the network. The
snapshot is built once, before evaluation, and is stored with the decision —
which is what makes a 2026 determination reproduce in 2031.

| Section | Holds |
|---|---|
| `as_of` | The date the determination is made for |
| `licensee.jurisdiction` | Which regime is the governing one |
| `client.*` | Age, category, loss-capacity band, portfolio, acknowledgements, residency, domicile |
| `asset.*` | Class, volatility band, leverage, structural flags — **as this pack classifies it** |
| `trade.amount_cents` | The amount being transacted |
| `calc.*` | Derived values (§7) |
| `jurisdictions.*` | How *other* regimes classify the same asset, for cross-border cases |

### No decimals, anywhere

Money is whole **cents**. Proportions are whole **basis points** — one per cent
is 100 bps, so a 10% cap is `1000`. A decimal number anywhere in a pack is
refused when the pack is loaded.

This is not fastidiousness. `0.1 + 0.2` is not `0.3` in binary floating point,
and a determination whose stored number is a rounding of a rounding does not
reproduce byte-for-byte years later. Invariant 3 exists to keep that impossible.

---

## 7. Derived values

A pack cannot do arithmetic, so anything that needs calculating is a **registered
calc**: a named function in the engine, documented here, individually tested. A
pack may only name one that exists; naming anything else means the pack is
refused when it loads.

<!-- CALCS TABLE START -->
| Calc | Unit | Reads | What it is |
|---|---|---|---|
| `existing_crypto_cents` | cents | `positions.crypto_value_cents` | What the client already holds in crypto-assets, before this trade, as reported by custody. |
| `post_trade_crypto_bps` | bps | `positions.crypto_value_cents`, `trade.amount_cents`, `client.assessable_portfolio_cents` | The share of the client's assessable portfolio that would be held in crypto-assets after this trade. This is the number a concentration limit is compared against. |
| `post_trade_crypto_cents` | cents | `positions.crypto_value_cents`, `trade.amount_cents` | What the client would hold in crypto-assets if this trade went ahead: their existing holding plus the amount being bought. |
| `trade_share_bps` | bps | `trade.amount_cents`, `client.assessable_portfolio_cents` | This trade alone, as a share of the client's assessable portfolio. Distinct from the concentration figure because some regimes cap a first purchase as a proportion of the portfolio rather than as a cash sum, and a proportion and a sum have no common ordering. |
<!-- CALCS TABLE END -->

**Operands are checked for kind and for unit, not only for existence.** The
validator caught every error that named something which did not exist, and none
of the errors where everything named exists and the comparison is nonsense
anyway. Three constructions loaded clean and evaluated wrongly, and none of them
is visible to somebody reading the JSON who does not think in Python:

| Written | What it does | Now |
|---|---|---|
| an integer `eq` a boolean threshold | `3 == True` is False, `1 == True` is True | refused |
| `in` against a string | substring, not membership — `'com' in 'complex'` | refused |
| a `bps` calc `gt` a `cents` threshold | 1000 bps is 10%, 1000 cents is $10 | refused |

So: a comparison may not mix a boolean with a non-boolean, and may not put a
boolean in an ordering comparison; `in` and `not_in` need a list on the right and
`contains` and `not_contains` need one on the left; and two operands that both
declare a unit must declare the same one.

**Units come from the names that already carry them** — `_cents`, `_bps`,
`_days`, `_years` — matched as whole words, so `knowledge_assessed_days_ago` is
a number of days. Nothing new is declared in a pack body and no operator or term
kind was added: this is a validator change, not a language change. SG caps a
first purchase in basis points where AU caps it in cents, so the suffix was
already the only thing distinguishing `first_exposure_limit_bps` from
`first_exposure_limit_cents`.

A term the validator cannot identify — a constant, a cross-border read under
`jurisdictions.` — is permitted rather than refused. What is checked is a
*conflict* between two stated things, never the absence of one.

**A calc that reads `positions.` is withheld when custody has told us nothing.**
If `positions.source` is `none_on_file` — which is every client who arrived by
CSV, file drop or API, because none of those carry holdings — the three calcs
above that read custody are left out of the snapshot rather than computed from a
zero that means "nobody has said". A rule reading one then gets the ordinary
missing-field treatment: REFER, with the field named. `trade_share_bps` stays,
because this trade against this portfolio is arithmetic on facts the firm
supplied.

The snapshot records what was withheld under `positions.withheld_calcs`, so the
determination can say what it was decided on. See Q-06 in `docs/spec-changes.md`
and the custody section of `docs/import-spec.md`.

**Division is always rounded down**, and a portfolio of zero does not divide by
zero: somebody with no assessable portfolio who buys anything has put all of it
into that purchase, so the answer is 10,000 bps. Buying nothing with nothing is
zero.

**The unit is part of the meaning.** A rule comparing `post_trade_crypto_bps` to
a threshold written in cents is wrong by a factor of ten thousand while reading
perfectly sensibly. Check the unit column against the threshold's name.

---

## 8. Missing data

**An absent fact is never treated as a pass, and never crashes.**

If a rule reads a snapshot field that is not there, that rule produces `REFER`
with the reason code `DATA_MISSING`, and the evidence names the field. The rule's
own `on_fail` is ignored: a rule that would have blocked is not entitled to block
on a fact nobody has established.

The same applies to `applies_to.when`. If the applicability condition cannot be
evaluated, the honest answer is "we cannot tell whether this rule applies", and
skipping the rule would turn that into a silent pass.

**A field that is present and empty is not missing.**
`client.knowledge_assessed_days_ago` is `null` for somebody who has never been
assessed. That is a fact the snapshot is recording, not a hole in it, and it is
answered by the rule that asks about it rather than by this one.

`DATA_MISSING` is the language's reason code, not a regime's. The engine supplies
its plain-English text so that no pack can leave the reason card blank; a pack
that wants to say it in its own words may define the code itself. **No rule may
use `DATA_MISSING` for anything else** — the pack is refused if one does.

---

## 9. Versions

`dsl_version` records which version of this language a pack's rules are written
against. It is not the pack's `version`, which counts revisions of its *content*.

| Version | Behaviour |
|---|---|
| **1** | The language before Stage 3. A rule reading an absent snapshot field raises, and the determination fails. |
| **2** | A rule reading an absent field produces `REFER` with `DATA_MISSING`, naming the field (§8). Nothing else differs. |

**Every version is kept forever.** Changes are additive; removals are
deprecations that never delete evaluation support. A determination made in 2026
under version 1 is replayed in 2031 under version 1, because "we improved it
later" is not a reproduction.

This is a live arrangement rather than a promise. `packs/au_v1.json` is a
version-1 pack, it is loaded on every seed, and Harold Bell's 2025 determination
replays under version-1 semantics on every test run.

**A pack that does not declare a version is read as version 1**, never as the
newest — every pack authored before the field existed was written against
version 1, and defaulting forward would silently re-interpret them.

**A pack declaring a version the engine does not have is refused when it loads.**
That means the content is newer than the code, which is almost always a
deployment running behind. Upgrade the engine; do not lower the pack.

---

## 10. What the engine will not do

Stated plainly, because a diligence team's next question is usually one of these.

- **It does not weight, score or net.** No rule can offset another. The outcome is
  the worst single result.
- **It does not decide anything a pack did not say.** There is no
  jurisdiction-specific logic in engine code; a guard script fails the build if a
  regime's name appears in it. Which of two limits is stricter is a question the
  *pack* answers, in `precedence`, because that is a fact about a regime rather
  than about arithmetic.
- **It does not consult a model.** No part of a determination involves a language
  model. The watch service uses one to read regulator publications and draft
  proposals for a human to sign, and a guard script forbids that service from
  importing the engine at all.
- **It does not read anything but the snapshot.** No database, no clock, no
  network, no configuration.
- **It does not check whether the rules are right.** Whether an 8% cap is the
  correct cap is not a question any validator can answer. That is what the named
  signatory and `content_status` are for, and content nobody qualified has
  reviewed is labelled `ILLUSTRATIVE` and carries a banner on every document it
  produces.

---

## 11. When a pack is refused

Validation runs when a pack is loaded — by `make seed`, and by the endpoint that
publishes a signed draft. It never runs during a determination, because a pack
already in force that started failing validation would take every determination
in that regime down rather than telling somebody.

Every fault is reported at once, each naming the rule, the problem and where
possible the fix:

```
pack AU v2 cannot be loaded — 2 problem(s):
  - rule 'AU-CONC-01' predicate → right: names the threshold
    'max_crypto_concetration_bps', which this pack does not define.
    Did you mean 'max_crypto_concentration_bps'?
  - rule 'AU-KNOW-01': 'on_fail' is 'ALLOW'; it must be one of REFER, BLOCK.
```

What is checked: unknown operators; thresholds, lookup tables and derived values
that do not exist; reason codes the pack does not define; decimal constants;
duplicate rule ids; `on_fail` values other than `REFER` or `BLOCK`; rules
claiming the reserved `DATA_MISSING`; snapshot sections that do not exist; and
lookup tables that do not cover every asset class the pack classifies.

---

## 12. Where the proof is

| Claim | Asserted by |
|---|---|
| Every construct above behaves as described | `api/tests/test_dsl.py` |
| The same inputs always produce the same output | `api/tests/test_properties.py` |
| Rule order does not change a determination | `api/tests/test_properties.py` |
| No float can enter a determination | `api/tests/test_properties.py` |
| Known cases still produce known results | `api/tests/test_corpus.py` and `corpus/` |
| Malformed packs are refused, never mis-evaluated | `api/tests/test_fuzz.py` |
| This document matches the code | `api/tests/test_dsl_spec.py` |

The last row is the one that keeps the rest true. A specification that drifts
from its implementation is worse than none, because it is believed.
