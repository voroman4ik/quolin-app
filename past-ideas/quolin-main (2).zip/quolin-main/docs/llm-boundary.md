# Is an AI writing your rules?

No. This page is here so that you can check that rather than take our word for
it, and it names the files to read.

The short version: a language model reads publications and can raise a hand. It
cannot write a rule, change a threshold, publish a pack, or influence any
determination made about a client. That is not a policy we follow — it is a
property of how the system is built, and the three mechanisms that make it true
are a code path, a credential, and a database grant.

---

## What the model actually does

The watch service polls the publications each rule pack declares — a regulator's
media releases, its regulatory guides, the official journal. Anything new is
sorted into a queue for a compliance officer to read.

That sorting is done by **string matching against vocabulary the content team
wrote into the pack**, and it always has been. A term the pack maps to a
threshold or a rule id appears in a publication; the item goes to the top of the
queue with the matched terms attached, so an officer can immediately say "that
matched 'leverage' because the release is about a different product". See
`api/app/watch/triage.py`. No model is involved in it.

The model does two things beside that:

1. **Summarises** a publication in two sentences, for an officer deciding what
   to read first.
2. **Says whether it looks relevant**, with a confidence, and a sentence saying
   what led it there.

Its output is stored next to the publication. The one effect it can have is to
set a boolean: *raise this for a person to read*.

## What it cannot do

The function that decides what a suggestion is worth is nine lines long, and it
is short on purpose. It is `apply` in `api/app/watch/assist.py`:

```python
def apply(suggestion, *, deterministic_tier) -> tuple[bool, str]:
```

It returns a boolean and a sentence. There is nowhere in that signature for a
tier, a rule, a threshold or an outcome to go, and no caller that could use one
if there were. The tier stored against a watch event is computed by
`triage.classify` from pack vocabulary, written to the database, and *then* the
model is asked — an ordering `test_the_tier_is_settled_before_the_model_is_asked`
asserts directly.

Three further boundaries hold it there:

- **`api/app/watch` cannot import the evaluator.** `scripts/guard_no_watch_in_engine.sh`
  fails the build if any watch module imports `app/engine` or `app/service`, and
  if any watch module other than `drafts.py` constructs a pack row.
- **The watch service's database role cannot write the `packs` table.** Not
  "does not" — the privilege is not granted, so Postgres refuses before any code
  of ours is consulted. See `api/migrations/versions/0014_watch_role.py` and
  `api/tests/test_watch_role.py`.
- **Rule content still needs a named human signature.** A draft is inert until a
  person with a signatory grant for that regime signs it, having re-authenticated
  minutes earlier, and a *different* person publishes it. That is Stage 2's
  separation of duties and Stage 5's lifecycle, and nothing in this stage touches
  it.

So the path from "a model read a press release" to "a client was blocked" runs
through: a human officer reading the item, a human drafting a change, a human
signatory signing specific bytes, a second human publishing it, and — for a
pinned tenant — that customer taking the version deliberately after their own
review window.

## Uncertainty escalates. It never settles.

A confident suggestion that something matters raises it. An *unconfident*
suggestion also raises it.

There is no confidence score low enough to make an item quieter, and no
threshold below which the model's opinion suppresses anything. This is
deliberate and it is the opposite of how a scoring system usually works. The
reasoning is that the two errors are not the same size: a false positive costs
somebody thirty seconds, and a missed rule change costs a firm a remediation
programme. A threshold that could suppress would be a model deciding something.

If the model cannot be reached at all, the item is escalated and the failure is
recorded. An outage becomes visible in the queue rather than only in a log
nobody reads.

## Everything it was asked, and everything it said

Every call is written to `watch_assist_calls`: the exact prompt, the exact
response, the model id, the confidence, the tier the pack's vocabulary produced,
whether it escalated and why.

That table is append-only — a trigger refuses UPDATE and DELETE, and the grant
is revoked as a second, independent statement of the same rule. A retention
record that could be edited after the fact answers a different question: what do
you *say* it said.

The model id is stored exactly, not as a family name. "We use Claude" does not
survive the question of which one.

## The credential is the boundary

Only the watch task is given a model credential. Core-api is given none.

Both services run from the same image, which is deliberate — one image means one
thing to review — so what confines the model is the credential and the code path
rather than which library is installed. Both are checked in CI:

- No file outside `api/app/watch/assist.py` may import a model client.
- The API task definition may not carry a model credential.

Absent a credential, `assist.available()` is false and the watch service is
exactly what it was before this stage: string matching over a vocabulary the
content team wrote.

## What we have not claimed

- **The model is not accurate.** We make no claim about how often it is right.
  It sorts a queue; being wrong costs a reader thirty seconds either way.
- **The summaries are not a substitute for the publication.** The queue links to
  the source, and the officer drafting a change reads it.
- **This is not a control you should rely on us to police.** Every mechanism
  above is a file you can read and a test you can run, and that is the point of
  the page.

## Where to look

| Claim | File |
|---|---|
| The model's entire authority | `api/app/watch/assist.py` — `apply` |
| Tiering is string matching over pack content | `api/app/watch/triage.py` |
| The boundary, asserted | `api/tests/test_llm_boundary.py` |
| Watch cannot evaluate, or write a pack | `scripts/guard_no_watch_in_engine.sh` |
| Watch cannot write packs at the database | `api/migrations/versions/0014_watch_role.py`, `api/tests/test_watch_role.py` |
| Retention is append-only | `api/migrations/versions/0015_watch_assist_calls.py` |
| Rule content needs a named signature | `api/app/watch/drafts.py`, `api/app/watch/lifecycle.py` |
