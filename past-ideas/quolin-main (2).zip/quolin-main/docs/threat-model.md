# Threat model

Reviewed against the finished system, 2026-08-25 (§S13). Re-read 2026-08-26
after the remaining-work branch, which added an evidence room, an operator path
for webhook deliveries, manual source attestations, a blue-green cutover and an
automated offline regression. Three rows changed; the changes are marked.

This is written to be argued with. Every row names what stops the thing, where
that stopping happens, and what would have to be true for it to fail — because a
threat model whose every line says "mitigated" is a document nobody learns
anything from, and the rows worth reading here are the ones that do not.

Three things shape it.

**The asset is the evidence, not the software.** A determination made in 2026 has
to replay identically in 2031, and the record has to be one an auditor can rely
on. Almost everything below is about that: unauthorised *reads* of client data
matter, and unauthorised *writes* to the record matter more, because a leak is a
bad day and a forged determination is the product not working.

**We are in the threat model.** The people who can reach the owning database
role are us. Several rows below are about limiting what we can do quietly, and
one of them — the audit trail not being chained — is a hole we have not closed.

**Nobody outside has looked.** §S13 asks for pen-test findings remediated. There
has been no pen test, so there are no findings, and the review below is the
people who wrote the code reviewing their own work. That is worth something and
it is not the same thing. See "What this review cannot tell you".

---

## Actors

| | Who | What they can already do |
|---|---|---|
| **A1** | A customer's own staff | Hold a session, act within their firm's data, within their role |
| **A2** | Another customer on the same deployment | Hold a session for a different tenant |
| **A3** | An unauthenticated stranger | Reach the load balancer |
| **A4** | Us — engineers and operators | Reach the owning database role, the master key, and the deploy pipeline |
| **A5** | A dependency author | Ship code we install |
| **A6** | A regulator or auditor | Read what we hand them |

---

## The record

### T1 — A determination is altered after the fact (A1, A2, A4)

Every determination is hash-chained to the one before it within its tenant:
`prev_hash`, `this_hash`, anchored at a per-tenant genesis. Changing any field of
any determination breaks every link after it, and `make tamper-demo` performs
exactly that and shows the break.

**The chain does not prevent the edit. It makes the edit impossible to hide**,
which is the property an auditor wants and the one to be precise about in a
sales conversation.

*Changed by the Gate A audit.* The property was real and the **verifier stopped
answering when it was exercised**, which is worse than either the property or
the verifier being wrong. `decisions` grants the application `INSERT` — the
chain is meant to make an appended forgery visible rather than impossible — so
the reachable attack is a row appended by raw SQL, whose `snapshot` is not
ciphertext any key can open. SQLAlchemy decrypts while materialising a row, so
`verify_chain` raised out of the column type before it had a hash to compare.
`alerts.check`'s blanket handler then reported *"the chain_integrity check could
not run — fix the check before trusting the absence of the alerts it produces"*,
and the nightly replay died outright.

The severity and the exit code were right and the instruction was wrong, which
is worse than either being wrong alone: it is actionable, and the action sends
somebody to look at monitoring code while the evidence is being altered.
`verify_chain` returns a graded verdict now — `HASH_MISMATCH`,
`UNDECRYPTABLE_SNAPSHOT`, `ROW_UNREADABLE` — naming the decision and the tenant,
and `docs/runbooks/chain-mismatch.md` says which question each reason asks. A
key this process cannot read is deliberately **not** one of them: it is
`chain.unverifiable`, because reporting a configuration failure as tampering is
the same misdiagnosis pointing the other way.

*Would fail if:* somebody with the owning role recomputed the chain forward from
the altered row. `scripts/rechain.py` exists and can do this — it is how a
legitimately broken chain gets repaired — and nothing outside our own process
stops it being used the other way. A chain anchored in something we do not
control (a transparency log, a notary, a counterparty's system) is what would
close it, and is not built.

### T2 — Evidence is deleted (A1, A2, A4)

`decisions`, `audit_events`, `artefacts`, `security_events`, `auth_attempts`,
`tenant_stages` and — since 2026-08-26 — `source_verifications` are append-only
two ways, independently: a `BEFORE UPDATE OR DELETE` trigger, and
`UPDATE`/`DELETE` revoked from `quolin_app`. Either alone would be enough; both
means a migration that quietly drops one still leaves the other.
`scripts/lint_migrations.sh` fails any migration that touches a trigger or a
grant, and a test fails the build when a new table is classified neither
tenant-scoped nor global — which is how the new table was caught, rather than by
somebody remembering.

*Would fail if:* the owning role dropped the trigger. See T9.

*The evidence room is not covered by any of this, and says so itself.*
`evidence/` holds dated artefacts with self-digests, and the digest catches a
file altered after it was filed. It cannot show that a run happened: anybody
with write access to the folder could author a convincing artefact, and could
delete one. That is stated in `docs/evidence.md`, in every artefact's own
footer, and in the index's output — deliberately, because an evidence room whose
limits are not written down is read as proof of more than it is. The stronger
form is filing artefacts somewhere the people who produce them cannot rewrite.

### T3 — The audit trail is edited (A4)

**Closed in §S13, with the same mechanism the determinations use.**
`audit_events` carries `prev_hash` and `this_hash`, one chain per tenant, whose
genesis is derived from that tenant's recorded anchor. `GET /evidence/verify`
walks both chains and reports them separately;
`scripts/rechain.py --table audit_events` linked the rows written before it
existed, and the verifier counts anything still unlinked rather than folding it
into the total — "we verified 40 of 1200 rows" and "we verified 1200 rows" are
different sentences.

**Tamper-evident, not tamper-proof, and the distinction still stands.**
Append-only stops the application role editing or removing a row. What was
missing was any proof that history had not been *inserted*: a privileged actor
could write rows describing things that never happened, and the export carried
no arithmetic that would have shown it. Now it does.

The owning role remains a trust boundary — see T1 and T9. It can still rewrite
the chain, because `scripts/rechain.py` has to exist for a legitimately broken
one to be repairable. What it cannot do is alter the record and leave it
looking untouched.

---

## Isolation

### T4 — One customer reads another's data (A2)

Row-level security, `ENABLE` *and* `FORCE`, on every tenant-scoped and platform
table, with the tenant read from `current_setting('app.tenant_id')` and no
default — a connection that has not said who it is sees nothing.
`api/tests/test_rls.py` asserts fail-closed against every policed table, and
`make rls-probe` checks the same properties by inspection against any deployment.

*Would fail if:* the application connected as a role with `BYPASSRLS` or as the
owner. Both are asserted against directly rather than assumed — §S9's restore
drill was verifying as the owner and therefore proving nothing, which is how that
assertion came to exist.

### T5 — A grant in one firm opens another (A1)

**Found and closed in §S12, and it had been open the whole time.**
`identity.roles_for` trusted row-level security alone. `app.tenant_id` binds when
a transaction *begins*, and sign-in asks "does this person hold a grant here"
inside a transaction that is already open — so the policy was evaluated against
whatever the pooled connection last held. A person whose only grant was in one
firm signed in to a deployment serving another and read its entire book.

It now filters by tenant explicitly as well as relying on the policy. The
generalisation is the one worth carrying: **a query whose answer decides who may
act should not rest on ambient state.**

Found by the load model, which was the first thing to create a person belonging
to one firm and point them at a deployment serving another. Six stages of tests
did not, because the demo has only ever had one firm's staff.

---

## Credentials and access

### T6 — Credential stuffing or brute force (A3)

Per-address rate limiting, eight failures in five minutes, counted in Postgres
so it holds across processes. Failures are recorded in `auth_attempts` and
alerted on, by account and by source separately — fifty failures against one
account and fifty across fifty accounts are different incidents.

**This was broken until §S12** and nothing noticed: the record was going to a
tenant-scoped table from the one endpoint that has no tenant, so every row failed
the policy and was discarded. The alerting was reading a table nothing wrote to,
and its game day passed because the game day wrote its own rows.

*Would fail if:* an attacker distributes across addresses. Nothing here counts
failures per *account* across many addresses for lockout purposes — it alerts on
it but does not block, deliberately, because that is a denial-of-service lever
against a named user.

### T7 — Session theft (A3)

Cookies are `HttpOnly`, `Secure` and `SameSite`; the token is never stored, only
its hash; the HTTP listener redirects and never serves. Signing a pack demands
re-authentication within minutes regardless of session age.

### T8 — The login form discloses who has an account (A3)

Every failure returns one message and does the same work either way, including a
deliberate delay on an address that does not exist. `security_events` and
`auth_attempts` record the *account* when an attempt resolves to one and never
the address that was typed — a table of typed addresses is a list of who might
have an account here.

### T9 — An insider acts quietly (A4)

Partially closed, and honestly so. Every action through the application names the
person who took it; `make access-review` produces the quarterly report and
`scripts/evidence_pack.py` files it. But the owning database role bypasses
row-level security by definition, holds the grants the triggers refuse to the
application, and is what migrations run as.

*What actually limits it:* the master key is in Secrets Manager rather than in
the database, so a dump without it is ciphertext; and the chain makes a
determination edit visible even to the role that made it, unless that role also
re-chains (T1).

*What does not limit it:* nothing stops an operator reading a customer's data
through the owning connection, and nothing records that they did. Database-level
audit logging is not configured.

*Improved 2026-08-26, narrowly.* Two operator actions that previously needed a
psql prompt are now product surfaces and are therefore attributed: replaying a
dead webhook delivery writes `webhook.redeliver` naming the person, and the
delivery list omits payloads, so scanning the queue is no longer a way to read a
customer's book. That converts two specific unattributed acts into recorded
ones. It does not touch the general case — an operator with the owning
connection can still read anything and leave no trace.

*Narrowed again by the Gate A audit.* The blast radius above is stated about a
role nothing serving a request holds, and one request handler held it anyway:
`GET /admin/users` imported `OwnerSessionLocal` from `app.db` inside the handler.
FP3-04 removed `DATABASE_URL` from the request-serving task, so in the
deployment this did not escalate — `db.py` falls back to a hardcoded
`localhost:5433` and the screen returned 500. The reachable version of it is a
laptop or the suite, where the owner connection happens to be lying about.

Two things follow, and the second is the one worth keeping. It bought nothing:
migration 0047 re-pointed `user_reachable` at `tenant_members`, which is exactly
the roster that screen lists, so the read is a plain scoped query and always
was. And `app/owner_only.py` — written for this, refusing to import without
`DATABASE_URL` — says in its own docstring that "importing this from anything a
request can reach is a mistake this cannot prevent". It could not, because the
import went around it to `app.db`.
`scripts/guard_no_owner_in_request_path.sh` is what prevents it: no module under
`api/app` may name `OwnerSessionLocal`, `owner_engine` or `OWNER_DATABASE_URL`
except `db.py`, which constructs them, and `owner_only.py`, which is the door.

*And that guard forbade three names rather than the class, until B2.* Two
independent follow-up audits walked past it the same way, and one of them ran
it: a request-path module doing

    from app import owner_only
    owner_only.active_tenant_ids()

names none of the three, reaches the schema owner, and left the guard exiting 0
— on the exact case `owner_only.py`'s own docstring says it cannot prevent. The
deployment was not reachable (the API task holds no `DATABASE_URL`, so this is
an `ImportError` there), which means the reachable version is again a laptop and
the suite — the environment the original defect was reachable in, and where CI
runs.

The guard and its AST twin now forbid **reaching `app.owner_only` at all** from
anything under `api/app`, in every spelling: `from app import owner_only`,
`from . import owner_only`, `from .owner_only import x`, `import app.owner_only`,
an attribute access, and the dotted path as a string for `import_module`.

`source_alerts.py` was allowlisted for this and was deleted rather than
exempted. Its `all_tenant_ids` was a delegation to `owner_only` with no caller
left in the tree — an owner-privileged callable sitting in a request-path
module, which is this finding's own shape ready-made.

*And the guard forbade the door and left the key beside it, until F2.* Three
things were still open, and the third is why the allow-list is now empty.

`auth.py` was exempted so that `_reset_rate_limit_for_tests` could clear
`auth_attempts`, which is append-only to the application role by grant and by
trigger. What that exemption held open was a function that disables the trigger
as the schema owner and deletes every row — **invariant 4, and the login rate
limit with it, reachable from any handler**, because `auth` is imported by
everything that serves a request. Its only caller was the suite. It is
`conftest.reset_rate_limit_for_tests` now, and the allow-list for the door is
empty: nothing under `api/app` opens it.

The guard also forbade the door and three names for what is behind it, and said
nothing about `create_engine(os.environ["DATABASE_URL"])` — the same role,
reached with none of those tokens. `DATABASE_URL`, `create_engine` and
`psycopg.connect` are now forbidden under `api/app` except in `db.py`, which
constructs the engines. `owner_only.py` read the variable itself and now asks
`db.OWNER_URL_WAS_SUPPLIED`, so one file names the key.

And `api/seed` and `scripts` sit beside `api/app` on `sys.path` in the suite and
in the built image, and both re-export the owner at module scope — holding it is
what a worker is for. `import seed.seed; seed.seed.OwnerSessionLocal()` reached
the owner while naming neither the connection nor the door. Importing either
package from `api/app` is now forbidden outright.

Two files remain exempt from anything: `db.py`, which constructs the connections,
and `owner_only.py`, which is the door. Each is mutated in
`test_guard_mutations.py` to prove the entry is not a hole, and re-adding
`auth.py`'s import is a mutation case of its own.

*Still true, and worth being exact about:* **this is a coupling check, not the
boundary.** The boundary is the credential. The request-serving task is not
given `DATABASE_URL` (`scripts/guard_task_credentials.py`,
`test_the_api_is_not_given_the_owner_connection_in_the_first_place`), so in the
deployment the owner is unreachable no matter what the code says. Inside a
single process that *does* hold the credential — a laptop, this suite — no
Python mechanism makes it unreachable, because any construct that hides it can
be undone by the code that would otherwise have bypassed a guard. Four rounds of
this guard have each closed the spelling last used; what they buy is that a
coupling nobody intended fails in CI, and the sequence ends there rather than at
a fifth pattern list. `docs/spec-changes.md` records why.

---

## Content and correctness

### T10 — Rule content is altered (A1, A4)

Packs are signed by a named person with the content hash captured, and the
jurisdiction's `ILLUSTRATIVE` flag can only be cleared by a signature. The watch
service connects as a role that **cannot write the packs table** — a grant, not a
convention — so the path that reads regulator publications cannot change what the
engine evaluates.

*The largest correction to this entry, 2026-08-28, and it is B1.* Migration 0049
made a signature by a draft's own author unrepresentable unless an independent,
qualified second reviewer is recorded — and recorded *who* and *when*, not
*what*. Both follow-up audits found the same hole through it and one of them
executed it against a live database:

    author cuts a draft
      → an independent, qualified signatory records their read
      → the author edits the body
      → the author signs their own draft

`sign` asked only whether the reviewer column was populated, and it still was.
The CHECK constraint asked the same question of the same three columns and was
satisfied for the same reason. So the one act that turns a proposal into rule
content attested to bytes nobody but their author had ever seen, and every
downstream record — the published pack, `pack_publications`, the artefact's
evidence-integrity table — carried the reviewer's name as though they had read
it. The principal it needs holds `operator` and `pack_signatory`, which is the
S5 workbench workflow rather than a corner case.

Closed in three places, because each answers a different question. Migration
0050 adds `second_reviewed_content_hash`, captured at the review over the same
canonical form the signature hashes. `drafts.sign` refuses an author's own
signature when that hash does not match the body in front of it
(`ReviewedBytesChanged`). `main.edit_draft` clears the review outright on any
change to the body, so a stale one never sits on the row looking valid to a
reader. And `pack_drafts_self_signature_reviewed_these_bytes` refuses the row in
Postgres, so a writer that never went through Python is refused too — which is
the half a check in an editable file cannot give.

The window this closes is the one before the signature. Its sibling after the
signature was already closed: `publish` re-checks `content_hash` and refuses
`SignedBytesChanged`. The two are now the same guarantee either side of the
attestation.

*And a third window, 2026-08-28, F1.* B1 bound the review to content — and took
the hash when the approval arrived, which is not when the reviewer read
anything. The gap is the reviewer's reading time, minutes for a rule pack, and
an author holding `operator` can edit inside it: the reviewer approves, the hash
matches itself, `sign` is satisfied, and the reviewer's account stands against
bytes they never saw. The auditor executed it and got a 200 and a signature.
`view` returns `current_content_hash` of the body it rendered; the reviewer
sends it back as a required `reviewed_content_hash`; `record_second_review`
refuses `ReviewedBytesMoved` when it does not match.

*And the same defect on three sibling routes, 2026-08-29.* F1 was scoped to the
route that had been reported. `SignRequest` sat twenty lines above
`SecondReviewRequest` in the same file, carrying only a note, and the auditor ran
F1's own sequence through it: a signatory reads a draft, its author edits a
threshold, the signatory signs, 200 — with `content_hash` on the row taken over
the author's edit, and it publishes, because only the window after the signature
was guarded.

So this round enumerated the class rather than the route. Every state-changing
route in the application is now classified in `docs/spec-changes.md` and in
`test_an_attestation_is_of_the_bytes_the_attester_saw.py`, which holds the census
as data and fails when a route is added without one. It found two more instances
beyond the reported one: `approve-publication` and `publish` took **no request
body at all**, so the two people who put rule content in front of every firm had
no way to say what they had read — and their window is wider, because it spans
the signature. Both were carried through to `packs` on this tree before the fix.

Four routes now bind, with one comparison behind them: reading to second review
(`ReviewedBytesMoved`), reading to signature (`SignedBytesMoved`), reading to
approval and publication (`ApprovedBytesMoved`), review to signature
(`ReviewedBytesChanged`), and signature to publication (`SignedBytesChanged`).
Every window between a person seeing rule content and their name being recorded
against it is guarded, and the test asserts the set rather than the instances.

*A finding on the way past.* `POST …/approve-publication` and `POST …/publish`
are held to `quolin_operator`, and `GET /watch/drafts/{id}` was not — so a
platform publisher holding no firm role got 403 from the route that shows a
draft and 200 from the route that puts it live. The two people who decide what
governs every customer could not read what they were deciding on. The read is
now `STAFF | {quolin_operator}`, the same shape and the same argument as
`GET /admin/users`.

**A named limit: "author" means creator, not writer.**

`created_by_user_id` is written when a draft is cut and never on an edit, and
`sign` compares the signer to that column. So an operator holding
`pack_signatory` may rewrite a colleague's draft — or a watch-service draft —
and sign it, with no second review demanded, because they did not create it. The
auditor executed this twice.

This is a design decision and the repository has made it consistently: §3.2 says
"a draft they authored", 0049's constraint compares the same column, and every
screen and record reads "author" the same way. It is recorded here rather than
closed because changing it is a change to what the rule means, not a defect in
how the rule is enforced — and because a rule the code and the spec disagree
about is worse than either reading.

What it costs is real and should be said plainly: **the two-person control on
rule content protects the *creator's* seat, not the content.** A firm relying on
it should grant `operator` and `pack_signatory` to the same person only where it
would accept that person editing and signing anybody's draft.

Closing it has a known shape: a `last_edited_by_user_id` column, written by
`edit_draft`, checked in `sign` beside `created_by_user_id`, and added to
`pack_drafts_signature_is_independent` so the database refuses the row too. That
is a migration and a change to §3.2, and it belongs to whoever decides what
§3.2 means rather than to a fix pack.

**A named limit: the attestation census covers write methods only.**

`WRITE_METHODS` in `test_an_attestation_is_of_the_bytes_the_attester_saw.py` is
`{POST, PUT, PATCH, DELETE}`, and every assertion in that file — that a new
route is classified, that a bound route carries a required `*_content_hash`,
that an unbound one gives a reason — is over that set. **No GET route is in the
census, and several GET routes write a person's name into `audit_events.actor`.**
Named here rather than left to be discovered, because "we only checked write
methods" is a sentence somebody will ask about, and the answer should be
written down before they do rather than reconstructed afterwards.

The five, as of 2026-08-29, out of 49 GET routes the application serves:

| Route | What it records | Through |
|---|---|---|
| `GET /clients/{id}` | who read a client's file | `service.audit_read` |
| `GET /decisions/{id}` | who read a determination | `service.audit_read` |
| `GET /artefacts/{id}/pdf` | who downloaded a document | `service.audit_read` |
| `GET /audit/certificate` | who asked for a chain verification | `service.audit` |
| `GET /auth/oidc/callback` | who signed in through the firm's provider | `service.audit`, and a session row |

`GET /audit/export` is not among them: it reads `audit_events` and writes
nothing, which is worth stating because it is the route people assume writes
one.

**Provenance and attestation are different properties, and only one of them has
a window to close.** An attestation is a claim about content: *this person read
these bytes and vouches for them*. It has a window because the content can move
between the reading and the claim, and closing that window is what the four
bound routes do. Provenance is a claim about a request: *this account asked for
this thing at this time*. There is no content being vouched for, so there is
nothing to hash — and binding one of these to a content hash would not be a
weaker control, it would be a meaningless one, comparing a value to a body
nobody is asserting anything about. `audit_read` exists because FP3-14 found
that thirty audit calls covered no GET at all and a client's file could be read
with nothing recorded; it answers "who looked", which is the SOC 2 question and
the subject-access question. It does not answer, and does not claim to answer,
"who approved".

`GET /auth/oidc/callback` is the one that looks least like the others and is
still on the right side of the line. It is a genuinely state-changing GET — it
provisions a link, writes an `auth_sessions` row and audits the sign-in — and it
is a GET because the OAuth redirect makes it one, not by choice. What it records
is that a person authenticated. No content is in front of them and none is
attested to.

**The boundary, stated so it catches the next thing rather than only describing
this one.** A GET is outside the census because a GET is not where somebody
approves something — not because a GET cannot write. The moment a GET route
starts recording a decision, an approval, a review, or anything a person is
vouching for about content this system holds, it is an attestation wearing the
wrong verb, and it belongs in the census with a binding whatever its method. If
you are adding one: you are probably adding it in the wrong place, and if it
must be a GET, classify it and bind it anyway.

That catch is a human one. It is a person reading this paragraph, which is
weaker than the mechanical check the census gives write methods, and the
asymmetry is deliberate rather than unnoticed. Widening the census to enumerate
GET routes was considered in this round and not done. It would mean classifying
forty-nine further routes to record that forty-four of them write nothing, and
the check that would make it *mechanical* — asking which endpoints call
`service.audit` — is static analysis of `api/app` source from a test, which
`test_no_test_reads_source.py` forbids without an allow-list entry, on an
allow-list whose own test says it should not grow. The honest trade is a
paragraph a reviewer reads and a boundary stated in terms of what a route
records rather than which verb it uses.

**A named limit: the owner credential's boundary is the deployment, not the
laptop.**

`api/app/db.py` builds `owner_engine` at module scope, and `OWNER_DATABASE_URL`
falls back to `postgresql+psycopg://quolin:quolin@localhost:5433/quolin` when
`DATABASE_URL` is unset. So on a developer's machine the object exists and
points at a real database. Making it lazy — refusing to construct until somebody
asks, and refusing then unless the variable was genuinely supplied — was named
as the next structural step and is recorded here rather than done.

What actually stands between a request-path module and the owner today is
lexical and it is enforced in CI. `guard_no_owner_in_request_path.sh` and its AST
twin forbid any module under `api/app` from naming `OwnerSessionLocal`,
`owner_engine` or `OWNER_DATABASE_URL` outside `db.py`, and from naming
`DATABASE_URL`, `create_engine` or `psycopg.connect` anywhere but `db.py` — a
module that can build its own engine does not need anyone's door. `owner_only.py`
raises `ImportError` at load time when no owner connection was supplied. In
deployment, `DATABASE_URL` is absent and there is no Postgres at
`localhost:5433`, so the fallback is an address rather than an escalation.

So laziness would add a runtime refusal over the same set of names a lexical
guard already refuses, and would buy one thing the guard cannot: it would catch a
module reaching the engine through a name the AST cannot see — `getattr(db,
"Owner" + "SessionLocal")` — on a laptop. That is a deliberate evasion by
somebody who can also edit the guard.

The cost is what makes it a separate change rather than part of this one.
`owner_engine` is used as an object in ten files (`.connect()`, `.begin()`,
`inspect(...)`), `OwnerSessionLocal` is called in 283 places across 77, and the
name `owner_engine` is what `guard_no_owner_in_request_path.sh`, its AST twin and
`test_guard_mutations.py`'s fixtures all key on. Turning it into a function
rewrites the guards that were hardened last round; turning it into a
`__getattr__` proxy makes the file that *is* the credential boundary harder to
read, which is the property the guard exists to protect. Doing that in the same
pass as a four-route security fix is how a good change breaks a better one.

**What a reader should take from this:** the boundary is real where it is
enforced — in deployment, and in CI for every file under `api/app` — and it is a
convention on a developer's laptop, where the guard is a pre-commit-and-CI check
rather than a runtime refusal. Nothing in the request path has ever used the
owner connection; that is asserted, not asserted-by-comment.

*Changed 2026-08-26.* A person may now attest that they checked a source nothing
can poll, which is a new way for a human claim to affect what the currency
screen shows. It is held to the same bar as signing rule content: the actor must
hold `pack_signatory` **for that source's jurisdiction**, must have passed a
second factor, and the row lands in an append-only, tenant-scoped table with the
audit event chained. Three refusals bound it — a polled source cannot be attested
to (which would let a human claim paper over a poller that had silently stopped),
a future date is rejected, and an older attestation cannot move the freshness
clock backwards. What it does *not* do is make a source read `CURRENT`: the badge
stays `MANUAL`, because somebody remembering to look is not the assurance that an
automatic check is.

### T11 — A model influences a determination (A5, and us)

Invariant 6, enforced as a grep in CI: `app/engine` may not import `app/watch`,
and no model client or credential exists outside the watch service. A language
model may summarise a publication for a human to read; it may not decide
anything.

### T12 — A dependency ships something hostile (A5)

`pip-audit` and `npm audit` run on every push and fail the build. §S13 found and
closed two high-severity advisories this way (Next.js and postcss, both fixed by
upgrading Next 14 → 16).

*Would fail if:* the advisory does not exist yet. There is no lockfile-diff
review, no vendoring, and no allowlist of packages — a compromised patch release
of something already trusted lands on the next `npm ci`.

---

## Availability

### T13 — The service is overwhelmed (A3, and any customer)

Weakly addressed. §S12 sized the thread limiter and the connection pool together
so admitted work can proceed, and gave the artefact queue priorities so a batch
cannot bury a person. There is **no rate limiting on anything but sign-in, and no
load shedding**: past the limiter, requests queue rather than being refused, and
a request that arrives in ninety seconds is worse than a 503 with a `Retry-After`.

Recorded in `docs/post-raise.md`. It is an availability problem and not an
integrity one — nothing about it can produce a wrong determination.

---

## Data at rest and in transit

### T14 — A database dump is stolen (A3, A4)

Client names, dates of birth and every decision snapshot are encrypted per tenant
under a key wrapped by a master key that lives outside the database. A dump
without the master key is ciphertext. TLS terminates at the load balancer, and
the HTTP listener only redirects.

*Would fail if:* the master key were stored with the backups, which is the
mistake the runbooks warn about by name. And the ciphertext is bound to its
tenant and its column but **not to its row**, so two clients' names within one
tenant could be swapped and would decrypt cleanly — recorded in
`docs/post-raise.md`, and it needs the owning role to exploit.

---

## Disclosure

### T15 — What an unauthenticated caller can learn (A3)

*Added 2026-08-26.* `/health` is the one always-open endpoint. It answers with a
liveness flag, a count of packs — global content, identical for every caller —
and, since the blue-green work, the revision label the container is running.

The revision is there because a cutover cannot be verified without it: a
container still on the previous image answers a health probe exactly like a
fresh one, which is how a deploy silently does nothing. The cost is that a
stranger learns which of two colours is serving. That is accepted, and bounded
by keeping the value a rotation label rather than a build SHA or a hostname —
`main.py` says so where somebody would otherwise put one, `infra/` sets nothing,
and a test in `test_auth.py` fails if a field appears on that endpoint that
nobody added deliberately.

*Would fail if:* somebody set `QUOLIN_REVISION` to a commit hash, which would
tell an attacker exactly which published advisories apply.

---

## What this review cannot tell you

**There has been no penetration test.** §S13's gate is "zero open pen-test
findings above low", and zero findings from zero tests is not the same sentence.
Everything above was written by the people who wrote the code, which reliably
finds the mistakes we know how to make and reliably misses the ones we do not.

The two things most worth an outsider's time, on the evidence of what internal
work has already found:

- **Anything that depends on transaction state.** T5 was open for six stages and
  was found by accident. `app.tenant_id` binds at transaction begin, and every
  place that reads it inside an already-open transaction is a candidate.
- **The paths that write without a tenant in scope.** Sign-in is one, and it was
  silently failing to record for §S9's entire lifetime. There may be others.
- **Anything that only differs in a production build.** Added 2026-08-26: every
  dynamic route in the web app was requesting the record `undefined`, because
  `params` is a Promise in Next 16 and six components read it synchronously.
  `npm run build` compiled it without complaint and the demo runs `next dev`, so
  nothing had ever opened a production-built detail screen. Nothing here was a
  security defect, but the *class* is worth an outsider's attention: the build
  that ships is not the build anybody looked at.

Booking a test is a commercial decision, and until it happens this file is a
review rather than an assessment.

**And no row here has been tested against a deployed system.** Every mitigation
above was exercised on a developer machine or in CI — including the isolation
rows, which ran against one deployment holding one tenant. `README.md` carries a
table of which claim was produced where. A threat model verified only where the
threat cannot arise is a document with a known blind spot, and this is it.
