# Jurisdictions and cross-border resolution

Four regimes on one engine, and a determination when more than one of them
reaches the same trade.

The claim this phase makes is architectural, not legal. Adding Hong Kong,
Singapore and the European Union to Quolin took no change to
`api/app/engine`, which is enforced rather than asserted:
`scripts/guard_no_jurisdiction_logic.sh` fails the build if the string `AU`,
`HK`, `SG` or `EU` appears in engine code. Every regime name, regulator,
threshold, scale and ordering direction in this document comes from pack JSON.

**None of the HK, SG or EU content has been reviewed by a qualified adviser in
those jurisdictions.** It is labelled `ILLUSTRATIVE` in the pack, on the shelf,
on every client and decision screen it touches, and above the title of every
PDF it contributed to. See *Illustrative content* below.

---

## Which regimes apply

Three facts about a client can pull a regime in. They are frozen into the
snapshot, so replay derives the same set from the same facts:

| Basis | Snapshot field | Phrase used on screen |
|---|---|---|
| `licensee` | `licensee.jurisdiction` | the licence this advice is given under |
| `residency` | `client.residency` | where the client lives |
| `domicile` | `client.domicile` | where the client is domiciled |

Order is licensee, residency, domicile, and duplicates collapse — most clients
are all three at once, and those clients are single-regime. A regime can be
pulled in by more than one basis; all of them are recorded, because "because
your licence is there" and "because the client lives there" are different
arguments to have with a regulator.

The licensee's regime is **governing**. It supplies the artefact templates and
titles, and — see below — the precedence block that orders everything else. It
does not automatically supply the outcome.

### Matching a code to a pack

A pack answers for a code when the code is its own `pack_id` **or** appears in
its `covers_states`. That single rule is the whole of the "one pack, twenty-seven
member states" claim, and it lives in content: `match_packs` never names a bloc.
Where a member state departs from the bloc, that departure is a pack of its own
rather than a fork of the bloc pack.

### Codes with no pack

A code nothing matches is returned as `resolution.unmatched`, never dropped. It
is shown on the client screen, in the cross-border panel, and in the PDF, in
each case saying that no rule from that regime was evaluated and the
determination does not speak for it.

`marcus-tan` exists to exercise this: SG licence, HK residency, US domicile, and
no US pack on the shelf. A gap that is not shown is a gap nobody closes.

---

## Evaluating more than one pack

`service.evaluate` builds the snapshot **twice**, on purpose:

1. A probe build under the governing pack establishes the frozen facts.
2. `select_packs` derives the applicable regimes from that probe.
3. A second build adds each applicable pack's own asset classification at
   `snapshot.jurisdictions[code]`.

Only the asset classification differs between regimes — one regulator's altcoin
is another's complex product — and freezing the alternatives means replay reads
back exactly the classification each pack was evaluated against. `view_for`
hands each pack its own view.

Each pack is then evaluated independently by the same evaluator. Nothing in the
resolver re-runs a rule; it reads results and constraint metadata, so a
resolution can never disagree with the evaluations it was built from.

---

## Resolution

Rules declare a `constraint` block:

```json
"constraint": { "dimension": "first_exposure_limit", "scale": "cents",
                "magnitude": { "threshold": "first_exposure_limit_cents" } }
```

Constraints are grouped by `dimension` across every applicable pack, and each
dimension is resolved on its own.

### Ordering direction is content

The governing pack's `precedence.scales` block states, per scale, which
direction is stricter:

```json
"scales": { "band": "higher_is_stricter", "years": "higher_is_stricter",
            "bps": "lower_is_stricter",   "cents": "lower_is_stricter",
            "days": "lower_is_stricter" }
```

Which of two numbers is the stricter one is a fact about the regime, not about
arithmetic. `500 bps` is stricter than `1000 bps`; `Band 4` is stricter than
`Band 2`. An engine that hardcoded either would be wrong the first time a
regulator inverted a scale.

`qualitative` is deliberately absent from every pack's table.

### The three ways a dimension refuses to order

| `reason` | When | What is recorded |
|---|---|---|
| `no_common_scale` | Two regimes constrain the same dimension in different units | Every failing constraint binds independently |
| `scale_not_orderable` | The governing pack declares no direction for the scale, or some constraint on an orderable scale had no resolvable magnitude | Same |
| `single_constraint` | Only one regime constrains the dimension | It binds; nothing was ordered |

`no_common_scale` is the one worth understanding. HK caps a first purchase as a
cash sum and SG caps it as a share of the portfolio. `$2,000` and `2%` are not
the same kind of quantity, so neither is the stricter, and the engine says so
rather than picking. A fake ordering would be worse than none: a compliance
officer can defend "both bind and neither is stricter"; nobody can defend a
number that came from an engine's guess about which regulator is tougher.

Partial ordering is refused for the same reason — if any constraint on an
orderable scale has no resolvable magnitude, the whole dimension drops to
`scale_not_orderable`. Ordering a subset and presenting it as the answer would
hide the rest.

### When a dimension does order

The strictest magnitude binds. **A regime whose own rule failed also binds**,
even where its number was the laxer one — a failure is not made irrelevant by
someone else being stricter. Everything else is recorded as
`evaluated_not_binding`: evaluated, on the record, not governing.

### The outcome

`worst_of` across every regime's own outcome. The strictest regime wins, and it
is very often not the governing one — decision 42 is an AU-governed BLOCK that
AU alone would have allowed.

### Rationale prose

Every dimension carries a plain-English `rationale` generated inside the
resolver, not in the API or UI layer. It is inside the hash, so replay rebuilds
it byte for byte; that is also why it cannot be reworded after the fact.

---

## What is in the record

`decisions.resolution` is hashed with the rest of the determination and contains
`outcome`, `outcome_by_jurisdiction`, `applicable` (with basis), `unmatched`,
`illustrative`, `dimensions`, and `precedence_source`. Every field is a function
of the frozen snapshot and the per-pack evaluations and of nothing else — a
field that quietly depended on today's pack shelf would break replay the first
time the shelf changed.

`decisions.rule_results.other_jurisdictions` stores each non-governing pack's
version and results, so replay reads every pack back **by version of record**
rather than by what is in force now. The thing being reproduced is the
determination that was made, not the one that would be made today.

Presentation is assembled at read time, never stored: regime names, regulators
and per-regime findings live in `service._per_jurisdiction`. A pack that renamed
its regulator would otherwise change a hash that has to stay fixed for as long
as the decision does.

---

## Findings across regimes

On a cross-border decision the findings are the **union** across every
applicable regime, each stamped with the code and version of the pack that
raised it (`service._resolved_reasons`).

Taking findings from the governing pack alone produced the worst screen this
system could show: a red BLOCK banner above a green panel reading "every
applicable rule passed" — true of that one pack, and a lie about the
determination it sits under.

Worst-first ordering is shared across regimes rather than re-decided per pack.

---

## Illustrative content

`content_status` is pack content, one of `REVIEWED`, `PENDING_REVIEW`,
`ILLUSTRATIVE`. Only `ILLUSTRATIVE` raises the badge.

The badge is driven by **every regime that contributed**, not only the governing
one. A determination is as reviewed as its least reviewed input, and an
AU-governed BLOCK sourced from an illustrative HK pack would otherwise print
with no badge at all. `decision.illustrative_jurisdictions` is read from the
resolution, falling back to the governing pack for single-regime decisions.

| Surface | Treatment |
|---|---|
| Decision screen | Red non-dismissible block **above** the verdict — a reader who has taken the verdict in has stopped reading |
| PDF | Red block above the document title, on the first page, by construction in `_base.html` |
| Pack shelf | `ILLUSTRATIVE` chip per regime; full badge on the opened pack |
| Client screen | Chip per applicable regime in the regimes card |

The badge is never driven by anything a caller can pass in, and it is read from
the pack **at the version the decision was made under**.

---

## The cast

| Client | Licence | Residency | Domicile | Cross-border | What it exercises |
|---|---|---|---|---|---|
| `wei-lin-chow` | AU | HK | SG | yes | Three regimes; AU ALLOW, HK BLOCK, SG REFER; `no_common_scale` on first exposure |
| `ingrid-halvorsen` | AU | DE | DE | yes | Bloc coverage — DE resolves to the EU pack via `covers_states` |
| `marcus-tan` | SG | HK | US | yes | Non-AU governing pack (SG's precedence orders the constraints); US coverage gap |
| `chen-yu-hsuan` | HK | HK | HK | no | Single non-AU regime; illustrative badge without cross-border |
| `tom-askew`, `harold-bell` | AU | AU | AU | no | The protected single-regime path is unchanged |

`marcus-tan` matters most for the architectural claim: the resolver is not
AU-shaped. SG governs, SG's precedence block orders the dimensions, and SG's
templates title the documents.

---

## Screens

- **Client** — a regimes card, gated on `cross_border || jurisdictions_without_packs.length > 0`. Every client has a licence, so a card announcing that a domestic client is domestic would be noise on the overwhelming majority of screens, which is how the few that matter stop being noticed. Single-regime clients get three facts in the profile card instead.
- **Decision** — `JurisdictionPanel`: what each regime said alone (expandable to that regime's own findings), then one card per dimension. Reading order is failed constraints, then unorderable ones, then everything that passed. The stored order is alphabetical and inside the hash, so it is not touched — this is reading order, not record order.
- **Packs** — the shelf, with governed and considered counts per regime, and a `covers_states` card that only renders for a bloc.

Magnitudes render in the unit the pack declared, identically on screen
(`lib/format.ts::formatMagnitude`) and in PDFs (`artefacts/render.py::_magnitude`).
`200000 cents` and `$2,000.00` are the same number, and only one of them can be
checked against a statement by whoever reads the evidence pack. An unrecognised
scale prints the raw value beside the scale's own name rather than being coerced
into a unit no pack declared.

---

## Tests

`api/tests/test_crossborder.py` covers pack selection from the snapshot,
bloc matching via `covers_states`, coverage gaps, each of the three refusal
reasons, the failing-regime-still-binds rule, non-AU governing packs, resolution
determinism, and replay of a cross-border decision against packs read back by
version. `test_cast.py` pins the five cast clients' outcomes.

`make guard` runs the no-jurisdiction-logic check, and CI runs it alongside
`make test`.
