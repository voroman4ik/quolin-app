# Reporting spec

Two period documents and one export. All three read recorded evidence and add
nothing to it.

Reporting is not on the decision path. Nothing in `app/reports.py` can change a
determination, and a report being wrong does not make a determination wrong.
That separation is deliberate: aggregation is allowed to change shape between
versions, determinations are not.

---

## Periods

Only two shapes are accepted, at the API edge and again in `period_bounds`:

| Shape | Example | Bounds (inclusive) |
|---|---|---|
| Month | `2026-01` | 2026-01-01 – 2026-01-31 |
| Quarter | `2026-Q1` | 2026-01-01 – 2026-03-31 |

A free-text date range is deliberately not accepted. It would let a caller
produce a document covering an arbitrary window and label it a period; a named
period is checkable by whoever reads the document.

`GET /reports/periods` returns only months that actually contain
determinations, so the UI cannot offer a period that renders an empty document.
The screen derives quarter options from those months client-side.

### Which date a period filters on

Two date fields exist and they are not interchangeable. Each document states
its own basis in the Scope table, so a reader never has to guess.

| Document | Scoped by | Field |
|---|---|---|
| Periodic Distribution Return | assessment date | `decisions.as_of` |
| Override Register Extract | date the override was recorded | `overrides.created_at` |

`as_of` is the business date frozen into the snapshot — the date a reader would
recognise as "when this client was assessed". `created_at` on a decision is
when the row was written and is used only for the audit trail.

An override can be recorded in a later period than the determination it
displaces. Each register row prints both dates rather than collapsing them.

---

## Documents

Both are pack-configured. Titles and template filenames live in
`artefact_templates` / `artefact_titles` in the pack JSON, never in code —
invariant 8. Neither title claims a statutory document name:

| Kind | Title | Template (v1 / v2) |
|---|---|---|
| `regulatory_return` | Periodic Distribution Return | `period_return_v1.html` / `period_return_v2.html` |
| `override_report` | Override Register Extract | `period_overrides_v1.html` / `period_overrides_v2.html` |

Both extend `_period.html`, a separate base from the decision-scoped
`_base.html` — that one names a decision id in its page footer and renders a
determination banner, neither of which a period document has.

### Which pack renders the document

The pack **in force at the end of the period**. That is the configuration the
document is filed under. Where a period straddles a pack change, every version
applied is listed in the body with its signatory and its share of the
determinations, so the choice of reporting pack never hides one.

Q1 2026 therefore renders under v1 (v1 runs to 2026-05-31) and Q3 2026 under
v2. `test_the_reporting_pack_is_the_one_in_force_at_period_end` holds this.

### Storage

Period documents reuse the `artefacts` table. No migration was needed:

- `kind` — `regulatory_return` or `override_report`
- `ref_id` — `{jurisdiction}:{period}:{scenario or "all"}`, where a decision
  artefact stores the decision id

`GET /artefacts/{id}/pdf` serves both without change.

---

## Endpoints

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/reports/periods` | Periods containing determinations |
| `GET` | `/reports/preview?kind=&period=&jurisdiction=&scenario=` | The figures, as JSON |
| `POST` | `/returns` | Generate the distribution return |
| `POST` | `/reports/overrides` | Generate the override register extract |
| `GET` | `/audit/export?start=&end=` | Audit trail as CSV |

`POST` bodies are `{period, jurisdiction, scenario}`.

### Preview exists so the numbers can be checked first

`render_period` takes an already-computed aggregation rather than recomputing
one. The figures a user saw on screen are the figures that reach the PDF; there
is no window in which the two can disagree. A document whose numbers cannot be
inspected beforehand is a document nobody checks.

---

## Audit export, and what it does not guarantee

`audit_events` is append-only: a `BEFORE UPDATE OR DELETE` trigger raises on
any attempt to modify or remove a row. It is **not** hash-chained the way
`decisions` is. Dropping the table and starting again would leave no arithmetic
trace.

Saying nothing about this would let a reader carry over the decision chain's
guarantee by assumption, so it is stated in three places:

1. `X-Quolin-Integrity: append-only-trigger; not-hash-chained` on the response.
2. In words on the reporting screen, because a downloaded file loses its
   headers.
3. In the Evidence integrity table of both period PDFs.

The export is also excluded from service-worker caching. It is a file download,
so the `X-Quolin-From-Cache` marker never reaches a reader — a stale CSV would
land on disk looking exactly like a current one. Failing loudly offline is
better than handing someone a silently out-of-date audit trail.

Columns: `id,at,actor,action,subject`. Nothing is prepended or appended to the
CSV body; provenance travels in headers and in the UI, not in comment rows that
would break a parser.

---

## What is not built

- **Signed or chained audit export.** Deferred; see `docs/post-raise.md`.
- **Scheduled or lodged returns.** Documents are generated on request. Nothing
  is submitted anywhere, and no lodgement deadline is modelled.
- **Cross-jurisdiction returns.** `jurisdiction` is a parameter and defaults to
  `AU`, which is the only pack that exists until phase 3.
