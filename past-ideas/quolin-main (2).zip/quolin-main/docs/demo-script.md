# Demo script

Two things: the walkthrough to give, and the checklist to run the evening
before. The checklist is the part you cannot improvise on the day.

The walkthrough is six minutes. It is three moments — **Check**, **Replay**,
**Generate** — with a frame at the front and a disclaimer at the back. Everything
else in this system is an answer to a question, not a step in the script. If you
find yourself opening a fourth screen unprompted, you have left the script.

---

## The six minutes

Times are cumulative and generous. Nobody will time you; they exist so you can
tell, mid-demo, whether you are running long.

### 0:00 — Frame it, and say "prototype" out loud

> "This is a working prototype, not a product. The decision logic, the evidence
> store and the documents it generates are real. Everything at the edges — the
> CRM, the custody positions, the compliance queue — is mocked behind interfaces.
> I'll point out which is which as we go."

Say this first. The honesty is the pitch: the audience is compliance people, and
they have all been shown a demo that quietly implied more than it had.

Have the app already open and signed in as Dana Whitfield, the operator. Do not
demonstrate the login screen; it costs thirty seconds and the interesting part
is not that a password works. If somebody asks who is signed in, the answer is
worth giving: named accounts, roles per person, and the two-person rules below.

### 0:30 — Check: the machine refuses, and says why

Dashboard → **Tom Askew** → asset **SOL** → **Check**.

Expect **BLOCK**, with three independent reasons:

| Reason | What it says |
|---|---|
| `CONC_EXCEEDED` | Concentration over the cap, with both numbers shown |
| `LOSS_CAPACITY_INSUFFICIENT` | Loss capacity band below requirement |
| `OUTSIDE_TARGET_MARKET` | Asset outside the determined target market |

What to point at, in this order:

1. **Three reasons, not one.** A system that stops at the first failure tells a
   client to fix one thing, and they come back and fail on the next. This
   evaluates every rule and reports all of them.
2. **The values, not just the verdict.** Each reason shows the client's actual
   figure against the threshold that rejected it. That is the difference between
   a decision a compliance officer can defend and one they have to trust.
3. **The rule ID and pack version.** `AU-CONC-01`, pack `AU v2`. Every
   determination names the rule and the version of the rulebook it was decided
   under.

> "The thresholds are content, not code. Nothing about Australia is compiled
> into this engine — that's what makes the next two minutes possible."

### 2:00 — Replay: a decision from before the rules changed

Back → **Harold Bell** → decision **1** (SOL, 14 November 2025) → **Evidence** →
**Replay**.

Expect **"Reproduced exactly · pack v1 · chain verified ✓"**.

This is the moment the room came for, so slow down:

> "This determination was made in November, under version 1 of the Australian
> pack. Version 2 has been in force since June — one threshold changed, one rule
> added. I'm re-running it now, today, on the current build. It reproduces
> exactly, because it's evaluated against the rulebook that was in force on its
> own date, not the one in force now."

Then the badge:

> "Chain verified. Every decision's hash covers the previous one. If anyone had
> edited this record, this would say so."

**Do not say the record is tamper-proof.** It is tamper-*evident*, which is a
different and more defensible claim. If someone pushes on it, that is a good
sign — run `make tamper-demo` (see below) or promise it as a follow-up.

### 3:15 — Generate: the document at the end of it

Same screen → **Generate TMD**.

Expect the button to work, then a real PDF. Open it. Scroll it on the phone.

> "That's a Target Market Determination, generated from the same evidence the
> decision was made on. Not a template someone fills in afterwards — the
> determination and the document come from one record."

Two honesty notes to volunteer before you are asked:

- The template has not been through a compliance consultant. It is structurally
  right and the wording is illustrative.
- The artefact is generated on request, not stored and served. Regenerating it
  gives the same document because the evidence it is built from cannot change.

### 4:30 — Close: what is real and what is not

Open **`/integrations`**. It lists every mock in the system, by name, with what
it would be in production.

> "This screen exists because I'd rather you heard the list from me. Client
> records, positions, the compliance queue, the regulator feed — all mocked. The
> engine, the evidence store, the hash chain, the documents and the accounts are
> real. Everyone here has their own login and their own roles, every action is
> filed against the person who took it, and the system won't let one person
> approve their own override or publish rule content they signed themselves."

Stop there. Six minutes.

---

## If they ask — the extensions

Each of these is a complete answer to a specific question. Do not volunteer them.

**"Does this work outside Australia?"** → **Marcus Tan**, BTC. Resident in Hong
Kong, trading through a Singapore licensee, with a US nexus. The determination
names **SG** as governing on a licensee basis, lists HK as considered, and
reports **US as unmatched — no pack**. The unmatched line is the point: it
declines to guess rather than silently applying the nearest rulebook.

**"What happens when the rules change?"** → **`/currency`**. Freshness per
regime, computed from when each source was last checked. Then a draft: the watch
service proposes a threshold change, a named human signs it, and publishing it
creates a new pack version. The signature is a typed name — say so.

**"What about the cases that aren't clear-cut?"** → **Priya Nair**, ETH → REFER
→ **`/queue`** → open it → **Request override**. An override needs a
justification and a named approver, and it is appended to the decision rather
than replacing it. The original determination and its evidence stay exactly as
they were.

**"How do I know the audit trail is real?"** → run this in a terminal:

```bash
make tamper-demo
```

It shows Postgres refusing an ordinary edit to a stored decision, then
recomputes that decision's hash with one field changed to show the numbers no
longer agree. It writes nothing, so it is safe to run mid-meeting.

Note what it does *not* do: it does not turn the badge on the evidence screen
red, because that would mean committing a corrupted record to the demo database.
If you want that on screen, do it beforehand against a scratch copy of the
database, not the one you are about to present from.

---

## Pre-demo checklist

Run this the evening before, not in the room.

### 1. Reset the data

```bash
make seed
```

Running the test suite writes real decisions to the demo database — `test_api.py`
evaluates live trades. `make seed` is the reset button. Do it after any test run.

It also resets watch freshness. If `/currency` shows everything STALE, run
`make watch-tick` — freshness is derived from when each source was last checked,
so it decays on its own and a deployment nobody is operating drifts to STALE.

### 2. Confirm the three moments

With `make api` and `make web` running, signed in as any seeded account (`make
seed` prints the addresses and the password), in a browser on
`http://localhost:3000`:

| Step | Do | Expect |
|---|---|---|
| Check | Tom Askew → SOL → **Check** | BLOCK, three failing rules, values compared, `AU-CONC-01` and pack version visible |
| Replay | Decision 1 (Harold Bell, 14 Nov 2025) → Evidence → **Replay** | "Reproduced exactly · pack v1 · chain verified", differences none |
| Generate | Same screen → **Generate TMD** | "Target Market Determination", then a real PDF downloads |

If any of the three fails, stop and fix it. Nothing else in the demo matters.

### 3. Offline — walk all three failure modes

**These are now a test.** `make offline-test` drives a real browser through all
three modes against its own API and web server on :8100 and :3100, and asserts
what the table below asks a person to look for. Run it before a demo instead of
walking the table by hand; walk the table when the test fails, or on the phone,
where no runner can go.

```bash
make offline-test
```

It needs a seeded database and Playwright's browser
(`cd web && npx playwright install chromium`, or `PLAYWRIGHT_CHANNEL=chrome` to
use a Google Chrome you already have).

iOS only registers a service worker in a **secure context**, so offline can only
be verified over HTTPS or on localhost. A plain `http://192.168.x.x` LAN origin
is neither. Use `make tunnel` to test on a real phone — that part is still by
hand, and it is the part worth doing by hand.

First **visit every screen while online** — the cache only holds what has been
fetched at least once. Then:

| Mode | How | Expect |
|---|---|---|
| API down, web up | `kill $(lsof -nP -iTCP:8000 -sTCP:LISTEN -t)` | Every screen renders cached content. Dark banner "Engine unreachable — showing last synced records". Chain badge reads **"Not verified — engine unreachable"**, not a green tick. **Check** and **Replay** are disabled with a one-line explanation. |
| Web down, API up | `kill $(lsof -nP -iTCP:3000 -sTCP:LISTEN -t)` | App shell still loads from the service worker cache. |
| Both down | kill both | Same as above; no screen white-screens. |

The failure mode this is guarding against is subtle and worth stating plainly:
a service worker serving a cached API response returns an ordinary `200`, so
without the `X-Quolin-From-Cache` marker the app cannot tell cached data from
live data — and would render an unverified hash chain as "Chain verified". If
you ever see a green tick while the engine is down, that marker has regressed.

**Sign in before you go offline.** The lock screen needs a live engine, because
logging in is a POST and no cache can answer it. A device that signed in first
opens straight into the app on cached records, with the offline banner up; a
device that never did gets "Cannot reach the decision engine" and cannot get
past it until the API is back. On a plane that is unrecoverable, so do it on the
ground.

### 4. On the phone

```bash
make api        # terminal 1
make tunnel     # terminal 2 — prints one HTTPS URL
```

Open the printed URL in Safari → **Share → Add to Home Screen**. Launch from the
icon (not from Safari) and confirm it opens full-screen with no browser chrome.
Sign in. Then put the phone in **airplane mode** and confirm the screens above
still render. Ctrl-C the tunnel when finished — while it runs, anyone with the
link can reach the demo.

If port 3000 is busy, `WEB_PORT=3100 make tunnel`. Do not run `make web` at the
same time — Next 16 permits one dev server per directory, so a free port is not
enough. The script checks for one and says so in a sentence rather than waiting
sixty seconds and reporting a timeout.

> **`scripts/tunnel.sh` has still not been run end to end against a real
> device.** Its pre-flight has: the API check, the port check and the
> single-dev-server check were exercised on 2026-08-26 and one of them caught a
> running server. What has not happened is the part that matters — two
> Cloudflare tunnels, Safari, *Add to Home Screen*, and the service worker
> registering over HTTPS on an actual iPhone. Nothing in this repository can
> stand in for that. Walk it before you rely on it in front of anyone, and note
> what it prints so the next person does not start from nothing.

### 5. Battery and screen

Turn off auto-lock. A locked phone mid-demo means re-launching the PWA, which
means a cold start and a visible loading state.

Sessions last 12 hours and idle out after 2. A demo that starts more than two
hours after you last touched the app will land on the lock screen — open it once
in the waiting room.

---

## Things not to say

Written down because they are all tempting in the moment, and each one is
recoverable only by admitting it on the spot.

| Do not say | Say instead |
|---|---|
| "Tamper-proof" | "Tamper-evident — an edit can't be hidden" |
| "It monitors the regulators" | "It has a watch service running against a fixture; there's no live regulator feed in this build" |
| "Approved by our compliance consultant" | "Structurally right, wording illustrative, not yet reviewed" |
| "It's secure" | "Per-person accounts, roles and two-person rules are real and tested. It has not had a penetration test and holds no real client data yet" |
| "Hash-chained and append-only" (as one claim) | Two claims: decisions are hash-chained; packs, overrides and audit events are append-only by database trigger |
| "Offshore hosting isn't allowed for Australian firms" | APRA permits it with safeguards. Sydney is commercial positioning, not a legal requirement |
