# The evidence room

What is filed here is the record that a control *operated* — not the code that
would run it, and not a description of what it would do. A generator is not
evidence.

**Contents are deliberately not committed.** An artefact names people, describes
a specific deployment on a specific day, and often carries a firm's staff list.
A git history is the wrong home for all three, and a repository somebody clones
is the wrong place to distribute them. The folders are committed so the shape of
the room survives a fresh checkout; what goes in them does not.

**An empty folder is the honest state.** Nothing writes an artefact for a
control that has not run. `incidents/` and `pack-signatures/` are empty because
there has been no incident and no specialist has signed a pack, and both should
stay empty until those things are true.

| Folder | What belongs in it | Written by |
|---|---|---|
| `access-reviews/` | Who held what, and who had gone quiet | `make access-review ARGS=--evidence-out` |
| `drills/` | Restore, replay, isolation, load, smoke | the drill and probe scripts |
| `game-days/` | Alert paths fired on purpose, and whether each fired | `make game-day ARGS=--evidence-out` |
| `scans/` | Secret and dependency scans | `make scan-secrets`, `make audit-deps` |
| `deployments/` | Cutovers and rollbacks, with elapsed time | `scripts/deploy.py`, `scripts/rollback.py` |
| `incidents/` | What happened, what was done, what changed after | by hand, from the runbook |
| `pack-signatures/` | A named specialist signing rule content | the workbench, once one does |

`scripts/evidence_index.py` walks the room, recomputes every artefact's digest,
and reports what is missing against the cadence each control is expected on.
That index is the thing to hand an auditor first.

Full detail — cadence per control, retention, and how to hand the room over —
is in `docs/evidence.md`.
