# ECR and ECS Fargate.
#
# The deploy target decision the execution document asks to be made once and
# recorded: ECS, not Fly. The prototype deploys to Fly and that was right for a
# prototype, but three things in this plan point at AWS compute. Stage 1 puts
# per-tenant KMS keys and encrypted evidence in AWS, and compute outside that
# boundary means the SOC 2 scope spans two providers. Stage 9 asks for a
# restore drill into a clean environment, which is a Terraform apply here and a
# manual exercise across providers. Stage 11 promises a dedicated stack from
# the same IaC in under a day — achievable when compute is a variable in this
# module, not when it lives in a fly.toml that has to be forked per customer.
#
# fly.toml stays in the repository. It deploys the demo environment, which is a
# sales asset rather than product infrastructure, and there is no reason to pay
# for a Fargate task to keep it alive.

resource "aws_ecr_repository" "api" {
  name                 = "${local.name}-api"
  image_tag_mutability = "IMMUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  encryption_configuration {
    encryption_type = "KMS"
    kms_key         = aws_kms_key.app.arn
  }
}

# Immutable tags mean the image a decision was produced by can still be pulled
# years later, which is what replaying that decision on the original code
# requires. Untagged images are the only ones worth reaping.
resource "aws_ecr_lifecycle_policy" "api" {
  repository = aws_ecr_repository.api.name

  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Expire untagged images after 14 days"
      selection = {
        tagStatus   = "untagged"
        countType   = "sinceImagePushed"
        countUnit   = "days"
        countNumber = 14
      }
      action = { type = "expire" }
    }]
  })
}

resource "aws_cloudwatch_log_group" "api" {
  name              = "/quolin/${var.environment}/api"
  retention_in_days = var.log_retention_days
  kms_key_id        = aws_kms_key.app.arn
}

resource "aws_ecs_cluster" "main" {
  name = local.name

  setting {
    name  = "containerInsights"
    value = "enabled"
  }
}

resource "aws_iam_role" "task_execution" {
  name = "${local.name}-task-execution"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "task_execution" {
  role       = aws_iam_role.task_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

resource "aws_iam_role_policy" "task_execution_secrets" {
  name = "read-startup-secrets"
  role = aws_iam_role.task_execution.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = ["secretsmanager:GetSecretValue"]
        Resource = [
          aws_secretsmanager_secret.app.arn,
          aws_secretsmanager_secret.database.arn,
        ]
      },
      {
        Effect   = "Allow"
        Action   = ["kms:Decrypt"]
        Resource = [aws_kms_key.app.arn]
      }
    ]
  })
}

# The running application's role, distinct from the role that starts it. The
# task can use the tenant-data key and write artefacts; it cannot read the
# startup secrets again, and it has no ECR or log-group permissions of its own.
resource "aws_iam_role" "api_task" {
  name = "${local.name}-api-task"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "api_task" {
  name = "tenant-data-and-artefacts"
  role = aws_iam_role.api_task.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        # GenerateDataKey rather than Encrypt: Stage 1 wraps a per-tenant data
        # key under this one and encrypts evidence with the data key, so the
        # KMS key itself never sees a decision snapshot.
        Effect   = "Allow"
        Action   = ["kms:GenerateDataKey", "kms:Decrypt", "kms:DescribeKey"]
        Resource = [aws_kms_key.tenant_data.arn]
      },
      {
        # No s3:DeleteObject. Artefacts are evidence; the bucket is versioned
        # and the application has no business removing anything from it.
        Effect   = "Allow"
        Action   = ["s3:PutObject", "s3:GetObject", "s3:ListBucket"]
        Resource = [aws_s3_bucket.artefacts.arn, "${aws_s3_bucket.artefacts.arn}/*"]
      }
    ]
  })
}

resource "aws_ecs_task_definition" "api" {
  family                   = "${local.name}-api"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = var.api_cpu
  memory                   = var.api_memory
  execution_role_arn       = aws_iam_role.task_execution.arn
  task_role_arn            = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "api"
    image     = "${aws_ecr_repository.api.repository_url}:${var.image_tag}"
    essential = true

    portMappings = [{ containerPort = 8000, protocol = "tcp" }]

    environment = [
      { name = "ARTEFACT_BUCKET", value = aws_s3_bucket.artefacts.id },
      { name = "AWS_REGION", value = var.region },
      { name = "QUOLIN_COOKIE_SECURE", value = "true" },
      { name = "QUOLIN_ENVIRONMENT", value = var.environment },
      { name = "QUOLIN_TENANT_KEY_ARN", value = aws_kms_key.tenant_data.arn },
      # Who may be believed about the caller's address. FP3-02.
      #
      # The only thing in front of this task is the ALB, which lives in this
      # VPC, so the VPC's own range is the trust boundary and there is nothing
      # to maintain: change the VPC and this follows. uvicorn reads it in the
      # Dockerfile's CMD — one value, decided here, used there.
      #
      # Never `0.0.0.0/0` and never `*`. Trusting every proxy makes uvicorn
      # take the first `X-Forwarded-For` entry, which is the one the caller
      # sent, which is the finding.
      { name = "QUOLIN_TRUSTED_PROXY_CIDRS", value = var.vpc_cidr },
    ]

    secrets = [
      # `DATABASE_URL` — the schema owner — is deliberately absent. FP3-04.
      #
      # It used to be here, above `APP_DATABASE_URL`, under a comment claiming
      # that "without this the API would fall back to the owner connection".
      # That was wrong twice: `DATABASE_URL` *is* the owner connection, and what
      # `db.py` falls back to when it is missing is a hardcoded localhost, not a
      # role escalation.
      #
      # The owner owns every table and every append-only trigger, is exempt from
      # FORCE row-level security, and is the role `scripts/rechain.py` uses to
      # rewrite evidence hashes. Inside `api/app` it had two users: a test
      # helper and one watch-path enumerator that FP3-03 moved out. The
      # container runs no migration at start. So it bought nothing, and it sat
      # in the environment of the first process an attacker reaches.
      #
      # `app/owner_only.py` refuses to import without it, so anything in the
      # request path that reaches for the owner now fails loudly here rather
      # than succeeding quietly somewhere else.
      #
      # The role that actually serves requests, and the only connection this
      # task gets:
      {
        name      = "APP_DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:app_database_url::"
      },
      {
        name      = "QUOLIN_ALLOWED_ORIGINS"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:allowed_origins::"
      },
      # Losing this destroys every encrypted record, backups included. It is in
      # the human-owned secret for that reason: Terraform generating it would
      # put it in state, and a `terraform destroy` would then be able to take
      # the only copy of it with the infrastructure.
      {
        name      = "QUOLIN_MASTER_KEY"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:master_key::"
      },
    ]

    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = aws_cloudwatch_log_group.api.name
        "awslogs-region"        = var.region
        "awslogs-stream-prefix" = "api"
      }
    }

    healthCheck = {
      command     = ["CMD-SHELL", "python -c \"import urllib.request; urllib.request.urlopen('http://localhost:8000/health')\" || exit 1"]
      interval    = 30
      timeout     = 5
      retries     = 3
      startPeriod = 30
    }
  }])
}

resource "aws_lb" "main" {
  name               = local.name
  load_balancer_type = "application"
  subnets            = aws_subnet.public[*].id
  security_groups    = [aws_security_group.alb.id]

  enable_deletion_protection = true
  drop_invalid_header_fields = true
}

resource "aws_lb_target_group" "api" {
  name        = "${local.name}-api"
  port        = 8000
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = aws_vpc.main.id

  health_check {
    path                = "/health"
    matcher             = "200"
    interval            = 30
    timeout             = 5
    healthy_threshold   = 2
    unhealthy_threshold = 3
  }

  # Stage 9 asks for blue-green with instant rollback. Draining fast enough
  # that a rollback is not spent waiting on connections, slow enough that an
  # in-flight PDF render finishes.
  deregistration_delay = 30
}

# Plain HTTP exists only to refuse. Session cookies are marked Secure, so an
# HTTP request that was served rather than redirected would be a request whose
# login silently did not work.
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.main.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type = "redirect"

    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }
}

resource "aws_lb_listener" "https" {
  count = local.serves_https ? 1 : 0

  load_balancer_arn = aws_lb.main.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = local.certificate_arn

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.api.arn
  }
}

resource "aws_ecs_service" "api" {
  name            = "${local.name}-api"
  cluster         = aws_ecs_cluster.main.id
  task_definition = aws_ecs_task_definition.api.arn
  desired_count   = var.api_desired_count
  launch_type     = "FARGATE"

  network_configuration {
    subnets          = aws_subnet.private[*].id
    security_groups  = [aws_security_group.api.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.api.arn
    container_name   = "api"
    container_port   = 8000
  }

  # Roll forward without dropping the old task until the new one is healthy.
  deployment_minimum_healthy_percent = 100
  deployment_maximum_percent         = 200

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  # The deploy pipeline sets the image tag; Terraform owning it too would mean
  # every plan proposed reverting the last deploy.
  lifecycle {
    ignore_changes = [task_definition]
  }

  depends_on = [aws_lb_listener.http]
}

# ---------------------------------------------------------------------------
# The watch service, deployed separately.
#
# §S6: "watch runs as its own service with a DB role that has no write grant on
# `packs` — the only publish path is the signature endpoint in core-api."
#
# Three separations, and each is a different kind of thing going wrong that this
# prevents:
#
#   its own database role     `quolin_watch` cannot INSERT, UPDATE or DELETE a
#                             pack. Not "does not" — the privilege is not
#                             granted, so Postgres refuses before any code of
#                             ours runs. See migration 0014 and
#                             `api/tests/test_watch_role.py`.
#   its own task role         no artefact bucket, no tenant KMS key. The watch
#                             service reads publications and writes drafts; it
#                             has no business decrypting a client record.
#   no master key             the encryption envelope is not in its environment
#                             at all, so a compromised watch task cannot read a
#                             client name, a decision snapshot or a webhook
#                             secret even with a database connection.
#
# A scheduled task rather than a long-running service. A sweep is periodic by
# nature — every source has a declared cadence and polling faster keeps neither
# the promise nor the publisher's goodwill — so the thing that runs is the same
# `scripts/watch_tick.py` a developer runs by hand, on a schedule, exiting when
# it is done. A daemon would have to grow its own timer, and that timer would be
# a second place where cadence lived.

resource "aws_cloudwatch_log_group" "watch" {
  name              = "/quolin/${var.environment}/watch"
  retention_in_days = var.log_retention_days
  kms_key_id        = aws_kms_key.app.arn
}

# Deliberately thinner than `api_task`. No S3, no tenant KMS: what the watch
# service cannot reach, a compromised watch service cannot reach either.
resource "aws_iam_role" "watch_task" {
  name = "${local.name}-watch-task"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_ecs_task_definition" "watch" {
  family                   = "${local.name}-watch"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = var.watch_cpu
  memory                   = var.watch_memory
  execution_role_arn       = aws_iam_role.task_execution.arn
  task_role_arn            = aws_iam_role.watch_task.arn

  container_definitions = jsonencode([{
    name      = "watch"
    image     = "${aws_ecr_repository.api.repository_url}:${var.image_tag}"
    essential = true

    # The same image as the API, and a different entrypoint. One image means the
    # code a sweep runs is the code that was reviewed and tested together with
    # everything else; a separate build would be a second thing to keep in step.
    command = ["python", "-m", "scripts.watch_tick"]

    environment = [
      { name = "AWS_REGION", value = var.region },
      { name = "QUOLIN_ENVIRONMENT", value = var.environment },
      # Live against real publishers, which is what §S6 asks for. Sources whose
      # pack content declares no readable feed are reported as content gaps
      # rather than outages, so turning this on does not manufacture alerts.
      { name = "WATCH_MODE", value = var.watch_mode },
    ]

    secrets = [
      # The watch role's connection string, and nothing else. Not `database_url`
      # (the schema owner) and not `app_database_url`: either would hand this
      # task the ability to write a pack, which is the one thing the whole
      # separation exists to withhold.
      {
        name      = "WATCH_DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:watch_database_url::"
      },
      # The model credential, and this is the only task that gets one. Absent it
      # the watch service is exactly what it was before: string matching over a
      # vocabulary the content team wrote. A determination is never one
      # environment variable away from a model, because core-api has no code
      # path that would use one — see docs/llm-boundary.md and the guard script.
      #
      # In the human-owned secret rather than generated: it is somebody's API
      # key, and Terraform generating it would put it in state.
      {
        name      = "ANTHROPIC_API_KEY"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:model_key::"
      },
    ]

    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = aws_cloudwatch_log_group.watch.name
        "awslogs-region"        = var.region
        "awslogs-stream-prefix" = "watch"
      }
    }
  }])
}

resource "aws_cloudwatch_event_rule" "watch_sweep" {
  name                = "${local.name}-watch-sweep"
  description         = "One regulatory watch sweep. Cadence per source is pack content; this is how often we look at all."
  schedule_expression = var.watch_schedule_expression
}

resource "aws_cloudwatch_event_target" "watch_sweep" {
  rule     = aws_cloudwatch_event_rule.watch_sweep.name
  arn      = aws_ecs_cluster.main.arn
  role_arn = aws_iam_role.watch_scheduler.arn

  ecs_target {
    task_definition_arn = aws_ecs_task_definition.watch.arn
    task_count          = 1
    launch_type         = "FARGATE"

    network_configuration {
      subnets          = aws_subnet.private[*].id
      security_groups  = [aws_security_group.api.id]
      assign_public_ip = false
    }
  }
}

resource "aws_iam_role" "watch_scheduler" {
  name = "${local.name}-watch-scheduler"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "events.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

# Every scheduled task this deployment runs, and nothing else.
#
# Listed one by one rather than granted with a wildcard, because `ecs:RunTask`
# on `*` in this cluster is permission to run the API's own task definition with
# a different command — which is a shell on the evidence database wearing a
# scheduler's hat.
#
# The list is the part that goes wrong: Stage 9 added the health task and left
# this policy naming only the watch sweep, so the schedule existed and every run
# of it would have been denied. Terraform validates a plan like that happily —
# an IAM policy that grants too little is not a syntax error — and the failure
# only shows up as a stopped task nobody is looking at. Anything added to the
# schedule belongs here in the same change.
resource "aws_iam_role_policy" "watch_scheduler" {
  name = "run-the-scheduled-tasks"
  role = aws_iam_role.watch_scheduler.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = "ecs:RunTask"
        Resource = [
          "${aws_ecs_task_definition.watch.arn_without_revision}:*",
          "${aws_ecs_task_definition.health.arn_without_revision}:*",
          "${aws_ecs_task_definition.comparison.arn_without_revision}:*",
          # The asynchronous execution tier, added with the schedules that run
          # it. `scripts/deployed_workers.py` fails the build when a task
          # definition is scheduled and missing from this list — which produces
          # a schedule that exists and is denied every time it fires, and which
          # nothing validated and nobody saw until it was written down.
          "${aws_ecs_task_definition.webhooks.arn_without_revision}:*",
          "${aws_ecs_task_definition.artefacts.arn_without_revision}:*",
          "${aws_ecs_task_definition.bulk.arn_without_revision}:*",
          "${aws_ecs_task_definition.settle.arn_without_revision}:*",
        ]
        Condition = {
          ArnEquals = { "ecs:cluster" = aws_ecs_cluster.main.arn }
        }
      },
      {
        Effect = "Allow"
        Action = "iam:PassRole"
        Resource = [
          aws_iam_role.task_execution.arn,
          aws_iam_role.watch_task.arn,
          # The health and comparison tasks run as the application, because both
          # read what the application wrote and neither should be able to do
          # more than the application can.
          aws_iam_role.api_task.arn,
        ]
      },
    ]
  })
}

# ---------------------------------------------------------------------------
# Blue-green deploys, and the alarms that page a person.
#
# §S9: "blue-green deploys with instant rollback" and "alerts page a person, not
# a channel nobody reads".
#
# The rollback being fast is what makes the bad-deploy runbook's first
# instruction — roll back, then diagnose — a reasonable thing to ask of somebody
# at 3am. A rollback that means a rebuild is one people talk themselves out of,
# and then debug forward on a live system instead.

resource "aws_lb_target_group" "api_green" {
  name        = "${local.name}-api-green"
  port        = 8000
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = aws_vpc.main.id

  health_check {
    path                = "/health"
    matcher             = "200"
    interval            = 15
    healthy_threshold   = 2
    unhealthy_threshold = 2
  }
}

resource "aws_codedeploy_app" "api" {
  name             = "${local.name}-api"
  compute_platform = "ECS"
}

resource "aws_iam_role" "codedeploy" {
  name = "${local.name}-codedeploy"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "codedeploy.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "codedeploy" {
  role       = aws_iam_role.codedeploy.name
  policy_arn = "arn:aws:iam::aws:policy/AWSCodeDeployRoleForECS"
}

resource "aws_codedeploy_deployment_group" "api" {
  app_name               = aws_codedeploy_app.api.name
  deployment_group_name  = "${local.name}-api"
  service_role_arn       = aws_iam_role.codedeploy.arn
  deployment_config_name = "CodeDeployDefault.ECSAllAtOnce"

  ecs_service {
    cluster_name = aws_ecs_cluster.main.name
    service_name = aws_ecs_service.api.name
  }

  # The old task set stays up for an hour after traffic moves. That hour is the
  # whole point: a rollback within it is a listener shift measured in seconds,
  # which is what makes §S9's under-two-minutes target achievable rather than
  # aspirational.
  blue_green_deployment_config {
    deployment_ready_option {
      action_on_timeout = "CONTINUE_DEPLOYMENT"
    }

    terminate_blue_instances_on_deployment_success {
      action                           = "TERMINATE"
      termination_wait_time_in_minutes = 60
    }
  }

  auto_rollback_configuration {
    enabled = true
    # Rolled back by the alarms below without waiting for a person. A deploy
    # that starts erroring at 2am should not need somebody to wake up first.
    events = ["DEPLOYMENT_FAILURE", "DEPLOYMENT_STOP_ON_ALARM"]
  }

  alarm_configuration {
    enabled = true
    alarms  = [aws_cloudwatch_metric_alarm.api_5xx.alarm_name]
  }

  load_balancer_info {
    target_group_pair_info {
      prod_traffic_route {
        # Whichever listener is actually serving. The HTTPS one exists only
        # where a certificate has been provided; staging without one still gets
        # blue-green deploys, because a rollback path that only exists in
        # production is one nobody has rehearsed.
        listener_arns = [
          local.serves_https
          ? aws_lb_listener.https[0].arn
          : aws_lb_listener.http.arn
        ]
      }
      target_group { name = aws_lb_target_group.api.name }
      target_group { name = aws_lb_target_group.api_green.name }
    }
  }

  deployment_style {
    deployment_option = "WITH_TRAFFIC_CONTROL"
    deployment_type   = "BLUE_GREEN"
  }
}

# The pager. A topic rather than a chat webhook, because §S9's sentence is that
# alerts page a *person* — and a topic is what a pager service subscribes to.
# The subscription is a variable with no default: an unconfigured pager is a
# deployment decision somebody has to make, not something to guess at.
resource "aws_sns_topic" "pager" {
  name              = "${local.name}-pager"
  kms_master_key_id = aws_kms_key.app.id
}

resource "aws_sns_topic_subscription" "pager" {
  count     = var.pager_endpoint == "" ? 0 : 1
  topic_arn = aws_sns_topic.pager.arn
  protocol  = var.pager_protocol
  endpoint  = var.pager_endpoint
}

resource "aws_cloudwatch_metric_alarm" "api_5xx" {
  alarm_name          = "${local.name}-api-5xx"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  period              = 60
  threshold           = 5
  namespace           = "AWS/ApplicationELB"
  metric_name         = "HTTPCode_Target_5XX_Count"
  statistic           = "Sum"
  treat_missing_data  = "notBreaching"

  dimensions = {
    LoadBalancer = aws_lb.main.arn_suffix
    TargetGroup  = aws_lb_target_group.api.arn_suffix
  }

  alarm_description = "The API is returning server errors. See docs/runbooks/bad-deploy.md."
  alarm_actions     = [aws_sns_topic.pager.arn]
  ok_actions        = [aws_sns_topic.pager.arn]
}

resource "aws_cloudwatch_metric_alarm" "database_storage" {
  alarm_name          = "${local.name}-db-storage"
  comparison_operator = "LessThanThreshold"
  evaluation_periods  = 1
  period              = 300
  # Ten percent of what was allocated. Early enough to act, because the incident
  # a full evidence database causes is refusing to record determinations.
  threshold   = var.postgres_allocated_storage_gb * 1024 * 1024 * 1024 * 0.1
  namespace   = "AWS/RDS"
  metric_name = "FreeStorageSpace"
  statistic   = "Minimum"

  dimensions = { DBInstanceIdentifier = aws_db_instance.main.identifier }

  alarm_description = "The evidence database is running out of room. See docs/runbooks/db-failover.md."
  alarm_actions     = [aws_sns_topic.pager.arn]
}

# §S10's weekly comparison. A firm in shadow is running us alongside their
# incumbent, and this is the report that period exists to produce. It runs as a
# scheduled task rather than on request because the point is that it arrives
# whether or not anybody remembers to ask for it.
#
# It exits 2 when a tenant in shadow had nothing comparable that week — shadow
# mode nobody is comparing is a switched-off system with extra steps — and the
# non-zero exit shows up as a stopped task with a non-zero code in the same log
# group as everything else.
resource "aws_cloudwatch_event_rule" "comparison" {
  name                = "${local.name}-comparison"
  description         = "Produce the weekly incumbent comparison for every firm in shadow."
  schedule_expression = var.comparison_report_schedule
}

resource "aws_ecs_task_definition" "comparison" {
  family                   = "${local.name}-comparison"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = aws_iam_role.task_execution.arn
  task_role_arn            = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "comparison"
    image     = "${aws_ecr_repository.api.repository_url}:${var.image_tag}"
    essential = true
    command   = ["python", "-m", "scripts.comparison_report", "--json"]

    environment = [
      { name = "AWS_REGION", value = var.region },
      { name = "QUOLIN_ENVIRONMENT", value = var.environment },
    ]

    secrets = [
      {
        name      = "APP_DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:app_database_url::"
      },
      {
        name      = "DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:database_url::"
      },
      {
        name      = "QUOLIN_MASTER_KEY"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:master_key::"
      },
    ]

    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = aws_cloudwatch_log_group.api.name
        "awslogs-region"        = var.region
        "awslogs-stream-prefix" = "comparison"
      }
    }
  }])
}

resource "aws_cloudwatch_event_target" "comparison" {
  rule     = aws_cloudwatch_event_rule.comparison.name
  arn      = aws_ecs_cluster.main.arn
  role_arn = aws_iam_role.watch_scheduler.arn

  ecs_target {
    task_definition_arn = aws_ecs_task_definition.comparison.arn
    task_count          = 1
    launch_type         = "FARGATE"

    network_configuration {
      subnets          = aws_subnet.private[*].id
      security_groups  = [aws_security_group.api.id]
      assign_public_ip = false
    }
  }
}

# The application's own checks — chain integrity, replay mismatches, queue depth,
# dead letters, auth anomalies — run as a scheduled task rather than as
# CloudWatch alarms, because none of them is a metric AWS can see. `alerts.py`
# is where they live and `scripts/health_alerts.py` is what runs them.
resource "aws_cloudwatch_event_rule" "health" {
  name                = "${local.name}-health"
  description         = "Run the application's own §S9 checks and page on anything critical."
  schedule_expression = var.health_check_schedule
}

resource "aws_ecs_task_definition" "health" {
  family                   = "${local.name}-health"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = aws_iam_role.task_execution.arn
  task_role_arn            = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "health"
    image     = "${aws_ecr_repository.api.repository_url}:${var.image_tag}"
    essential = true
    command   = ["python", "-m", "scripts.health_alerts"]

    environment = [
      { name = "AWS_REGION", value = var.region },
      { name = "QUOLIN_ENVIRONMENT", value = var.environment },
    ]

    secrets = [
      {
        name      = "APP_DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:app_database_url::"
      },
      {
        name      = "DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:database_url::"
      },
      {
        name      = "QUOLIN_MASTER_KEY"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:master_key::"
      },
      # Where a page goes. Unset in the secret means the checks still run and
      # still exit non-zero — and nobody is told, which the script says out loud
      # rather than reporting success.
      {
        name      = "QUOLIN_PAGER_URL"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:pager_url::"
      },
    ]

    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = aws_cloudwatch_log_group.api.name
        "awslogs-region"        = var.region
        "awslogs-stream-prefix" = "health"
      }
    }
  }])
}

resource "aws_cloudwatch_event_target" "health" {
  rule     = aws_cloudwatch_event_rule.health.name
  arn      = aws_ecs_cluster.main.arn
  role_arn = aws_iam_role.watch_scheduler.arn

  ecs_target {
    task_definition_arn = aws_ecs_task_definition.health.arn
    task_count          = 1
    launch_type         = "FARGATE"

    network_configuration {
      subnets          = aws_subnet.private[*].id
      security_groups  = [aws_security_group.api.id]
      assign_public_ip = false
    }
  }
}

# ---------------------------------------------------------------------------
# A scheduled task that never started, and one that started and died.
#
# The Gate A audit's fourth finding is that all three scheduled tasks ran an
# entrypoint the image could not resolve, so each one started and stopped on its
# first import. **Nothing anywhere would have said so.** EventBridge reports
# success when `RunTask` is accepted; what the container then does is not its
# concern, and a monitoring tier whose death is invisible is worse than none —
# it produces the feeling of coverage without the coverage, which is the same
# sentence `scripts/health_alerts.py` uses about an unconfigured pager.
#
# Two failures, and they are genuinely different incidents.
#
# **The invocation never landed.** `FailedInvocations` on the rule counts the
# times EventBridge could not start the task at all — a denied `ecs:RunTask`,
# which is the exact shape of the IAM omission `aws_iam_role_policy.watch_scheduler`'s
# own comment warns about, or a throttle. One is enough: a schedule that fires
# hourly and is refused every time is not a transient.
#
# **The task ran and stopped badly.** That is not a CloudWatch metric — ECS
# emits it as an event — so it is a rule rather than an alarm. It fires on a
# non-zero exit from any container in these families, which is how a task that
# dies on an import, and a job that exits 2 because something is genuinely
# wrong, both reach a person. The two are deliberately not separated here: the
# jobs' exit codes already carry that distinction and are documented in
# docs/deployment.md, and a filter that dropped exit 2 would drop every alert
# `health_alerts` exists to raise.

locals {
  # One list, so a schedule added without an alarm is a visible omission rather
  # than a silent one. `aws_iam_role_policy.watch_scheduler` names the same
  # tasks for the same reason.
  scheduled_rules = {
    watch      = aws_cloudwatch_event_rule.watch_sweep.name
    comparison = aws_cloudwatch_event_rule.comparison.name
    health     = aws_cloudwatch_event_rule.health.name
    webhooks   = aws_cloudwatch_event_rule.webhooks.name
    artefacts  = aws_cloudwatch_event_rule.artefacts.name
    bulk       = aws_cloudwatch_event_rule.bulk.name
    settle     = aws_cloudwatch_event_rule.settle.name
  }
}

resource "aws_cloudwatch_metric_alarm" "schedule_never_fired" {
  for_each = local.scheduled_rules

  alarm_name          = "${local.name}-${each.key}-not-started"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 1
  period              = 300
  threshold           = 1
  namespace           = "AWS/Events"
  metric_name         = "FailedInvocations"
  statistic           = "Sum"
  # `notBreaching`, not `breaching`: a rule that fires weekly emits no data
  # points for six days, and an alarm that pages about the silence between
  # invocations is one somebody disables. That a job *did not run at all* is
  # what `worker_heartbeats` answers — see docs/deployment.md.
  treat_missing_data = "notBreaching"

  dimensions = { RuleName = each.value }

  alarm_description = join(" ", [
    "EventBridge could not start the ${each.key} task.",
    "The usual cause is that its task definition is missing from",
    "aws_iam_role_policy.watch_scheduler, which produces a schedule that exists",
    "and is denied every time it fires. See docs/deployment.md.",
  ])
  alarm_actions = [aws_sns_topic.pager.arn]
  ok_actions    = [aws_sns_topic.pager.arn]
}

resource "aws_cloudwatch_event_rule" "task_stopped_badly" {
  name        = "${local.name}-task-stopped-badly"
  description = "A scheduled task exited non-zero, or stopped for a reason nobody asked for."

  event_pattern = jsonencode({
    source      = ["aws.ecs"]
    detail-type = ["ECS Task State Change"]
    detail = {
      clusterArn    = [aws_ecs_cluster.main.arn]
      lastStatus    = ["STOPPED"]
      desiredStatus = ["STOPPED"]
      containers = {
        exitCode = [{ "anything-but" : 0 }]
      }
    }
  })
}

# **And the task that stopped without an exit code at all.** H6.
#
# The rule above matches `containers.exitCode = [{ "anything-but": 0 }]`, and an
# EventBridge field filter requires the field to be *present*. A container that
# never ran has no exit code to be anything-but: an image that will not pull, a
# task that cannot be placed, a secret ARN the execution role may not read, a
# subnet with no route to the registry. Every one of those stops the task with
# `stoppedReason` set and `exitCode` absent.
#
# It matched neither alarm. `schedule_never_fired` reads `FailedInvocations`,
# which counts EventBridge failing to *start* the task — and EventBridge
# succeeded: `RunTask` was accepted and the failure happened afterwards, inside
# ECS. So the gap is narrow and complete: a scheduled job that never executes a
# line of code, with nothing paging anybody.
#
# A second rule rather than a widened first one. The pattern language cannot
# express "exit code absent OR non-zero" in a single field filter, and the two
# incidents want different sentences anyway: the one above says read the task's
# logs, and this one says there are no logs to read.
resource "aws_cloudwatch_event_rule" "task_never_started" {
  name        = "${local.name}-task-never-started"
  description = "A scheduled task stopped without an exit code — it never ran."

  event_pattern = jsonencode({
    source      = ["aws.ecs"]
    detail-type = ["ECS Task State Change"]
    detail = {
      clusterArn    = [aws_ecs_cluster.main.arn]
      lastStatus    = ["STOPPED"]
      desiredStatus = ["STOPPED"]
      containers = {
        exitCode = [{ "exists" : false }]
      }
    }
  })
}

resource "aws_cloudwatch_event_target" "task_never_started" {
  rule      = aws_cloudwatch_event_rule.task_never_started.name
  arn       = aws_sns_topic.pager.arn
  target_id = "pager"

  input_transformer {
    input_paths = {
      group  = "$.detail.group"
      task   = "$.detail.taskDefinitionArn"
      reason = "$.detail.stoppedReason"
    }
    input_template = join(" ", [
      "\"A scheduled task stopped without ever running: <group> (<task>).",
      "Reason: <reason>.",
      "There is no exit code because no code ran — an image that would not",
      "pull, a task that could not be placed, or a credential the execution",
      "role may not read. There are no application logs to read.\"",
    ])
  }
}

resource "aws_cloudwatch_event_target" "task_stopped_badly" {
  rule      = aws_cloudwatch_event_rule.task_stopped_badly.name
  arn       = aws_sns_topic.pager.arn
  target_id = "pager"

  # The exit code and the reason, rather than the whole event. Somebody woken at
  # 3am needs the sentence, and the raw ECS state change is four hundred lines
  # of ARNs around it.
  input_transformer {
    input_paths = {
      group  = "$.detail.group"
      task   = "$.detail.taskDefinitionArn"
      reason = "$.detail.stoppedReason"
    }
    input_template = join(" ", [
      "\"A scheduled task stopped badly: <group> (<task>).",
      "Reason: <reason>.",
      "A task that exits non-zero on its first import looks exactly like this;",
      "so does a health check that found something wrong and exited 2.",
      "Read the task's logs before assuming which.\"",
    ])
  }
}

resource "aws_sns_topic_policy" "pager_accepts_events" {
  arn = aws_sns_topic.pager.arn

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Principal = { Service = "events.amazonaws.com" }
        Action    = "SNS:Publish"
        Resource  = aws_sns_topic.pager.arn
        Condition = {
          # Both rules, and H6 is why there are two. A rule not named here is
          # denied on publish, which is the same silent failure
          # `aws_iam_role_policy.watch_scheduler` had: the rule matches, the
          # target fires, SNS refuses, and nothing anywhere says so.
          ArnEquals = {
            "aws:SourceArn" = [
              aws_cloudwatch_event_rule.task_stopped_badly.arn,
              aws_cloudwatch_event_rule.task_never_started.arn,
            ]
          }
        }
      },
      {
        Effect    = "Allow"
        Principal = { Service = "cloudwatch.amazonaws.com" }
        Action    = "SNS:Publish"
        Resource  = aws_sns_topic.pager.arn
      },
    ]
  })
}

# ===========================================================================
# The asynchronous execution tier.
#
# Five scripts had a `make` target and no scheduler. Four are deployed here and
# the fifth — `batch_sweep` — is deferred with its reason in `infra/variables.tf`
# and in docs/deployment.md's operating table.
#
# Every one of them serves *every* firm, so every one holds the owner connection
# for `maintenance.active_tenant_ids` and nothing else — the same trade `health`
# and `comparison` already make, reviewed in
# `scripts/guard_task_credentials.py`. `scripts/deployed_workers.py` fails the
# build when this file, that allow-list, the scheduler policy and the operating
# table stop agreeing.
# ===========================================================================

# # Enqueued webhooks, sent.
#
# `app/webhooks.py` enqueues and this delivers, and until now nothing
# delivered: every `decision.recorded`, `queue.referred` and
# `pack.published` a customer had subscribed to sat in the table. A
# dropped alert is worse than one that never existed, because the
# customer believes they are being told — which is what
# `docs/integrations.md` promises them in writing.
#
# Exit 1 when something dead-lettered on this run, which is the one
# outcome somebody has to act on; `task_stopped_badly` pages on it.
resource "aws_cloudwatch_event_rule" "webhooks" {
  name                = "${local.name}-webhooks"
  description         = "Attempt every webhook delivery that is due."
  schedule_expression = var.webhook_delivery_schedule
}

resource "aws_ecs_task_definition" "webhooks" {
  family                   = "${local.name}-webhooks"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = aws_iam_role.task_execution.arn
  # The application's role, because each of these does what the application
  # does and none of them should be able to do more.
  task_role_arn = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "webhooks"
    image     = "${aws_ecr_repository.api.repository_url}:${var.image_tag}"
    essential = true
    command   = ["python", "-m", "scripts.deliver_webhooks"]

    environment = [
      { name = "AWS_REGION", value = var.region },
      { name = "QUOLIN_ENVIRONMENT", value = var.environment },
    ]

    secrets = [
      {
        name      = "APP_DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:app_database_url::"
      },
      # The owner connection, for enumeration and nothing else. Every one of
      # these serves every firm, and under FORCE row-level security a query for
      # "all tenants" returns the one in scope — `maintenance.active_tenant_ids`
      # is admitted by the `quolin_maintenance` grant migration 0029 creates,
      # which the owner holds. The same trade `health` and `comparison` already
      # make, and `scripts/guard_task_credentials.py` is where it is reviewed.
      {
        name      = "DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:database_url::"
      },
      {
        name      = "QUOLIN_MASTER_KEY"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:master_key::"
      },
    ]

    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = aws_cloudwatch_log_group.api.name
        "awslogs-region"        = var.region
        "awslogs-stream-prefix" = "webhooks"
      }
    }
  }])
}

resource "aws_cloudwatch_event_target" "webhooks" {
  rule     = aws_cloudwatch_event_rule.webhooks.name
  arn      = aws_ecs_cluster.main.arn
  role_arn = aws_iam_role.watch_scheduler.arn

  ecs_target {
    task_definition_arn = aws_ecs_task_definition.webhooks.arn
    task_count          = 1
    launch_type         = "FARGATE"

    network_configuration {
      subnets          = aws_subnet.private[*].id
      security_groups  = [aws_security_group.api.id]
      assign_public_ip = false
    }
  }
}


# # The document queue, drained.
#
# §S7 moved rendering off the request path and nothing was on the other
# side of it: a document a compliance officer asked for was queued and
# never rendered. `alerts.queue_depth` fires at a thousand, which is a
# threshold that means nothing unless the queue is normally emptied.
#
# More memory than the others: WeasyPrint binds Pango and Cairo and
# renders a real PDF, which is the one job here that is not mostly SQL.
resource "aws_cloudwatch_event_rule" "artefacts" {
  name                = "${local.name}-artefacts"
  description         = "Render every document waiting in the queue."
  schedule_expression = var.artefact_worker_schedule
}

resource "aws_ecs_task_definition" "artefacts" {
  family                   = "${local.name}-artefacts"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 512
  memory                   = 1024
  execution_role_arn       = aws_iam_role.task_execution.arn
  # The application's role, because each of these does what the application
  # does and none of them should be able to do more.
  task_role_arn = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "artefacts"
    image     = "${aws_ecr_repository.api.repository_url}:${var.image_tag}"
    essential = true
    command   = ["python", "-m", "scripts.artefact_worker"]

    environment = [
      { name = "AWS_REGION", value = var.region },
      { name = "QUOLIN_ENVIRONMENT", value = var.environment },
    ]

    secrets = [
      {
        name      = "APP_DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:app_database_url::"
      },
      # The owner connection, for enumeration and nothing else. Every one of
      # these serves every firm, and under FORCE row-level security a query for
      # "all tenants" returns the one in scope — `maintenance.active_tenant_ids`
      # is admitted by the `quolin_maintenance` grant migration 0029 creates,
      # which the owner holds. The same trade `health` and `comparison` already
      # make, and `scripts/guard_task_credentials.py` is where it is reviewed.
      {
        name      = "DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:database_url::"
      },
      {
        name      = "QUOLIN_MASTER_KEY"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:master_key::"
      },
    ]

    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = aws_cloudwatch_log_group.api.name
        "awslogs-region"        = var.region
        "awslogs-stream-prefix" = "artefacts"
      }
    }
  }])
}

resource "aws_cloudwatch_event_target" "artefacts" {
  rule     = aws_cloudwatch_event_rule.artefacts.name
  arn      = aws_ecs_cluster.main.arn
  role_arn = aws_iam_role.watch_scheduler.arn

  ecs_target {
    task_definition_arn = aws_ecs_task_definition.artefacts.arn
    task_count          = 1
    launch_type         = "FARGATE"

    network_configuration {
      subnets          = aws_subnet.private[*].id
      security_groups  = [aws_security_group.api.id]
      assign_public_ip = false
    }
  }
}


# # The bulk-evaluation queue, worked.
#
# §S8 re-checks a whole book in chunks, and nothing worked the chunks —
# so a run planned by a pack becoming effective, or by a client's
# profile changing, stayed `planned` forever. The delta report and the
# pinned-tenant UAT flow both read a completed run, so both were dead:
# a pinned firm could open its review window and never see what the new
# version would have changed, which is the whole of what pinning is for.
resource "aws_cloudwatch_event_rule" "bulk" {
  name                = "${local.name}-bulk"
  description         = "Work every chunk waiting in the bulk-evaluation queue."
  schedule_expression = var.bulk_worker_schedule
}

resource "aws_ecs_task_definition" "bulk" {
  family                   = "${local.name}-bulk"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 1024
  memory                   = 2048
  execution_role_arn       = aws_iam_role.task_execution.arn
  # The application's role, because each of these does what the application
  # does and none of them should be able to do more.
  task_role_arn = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "bulk"
    image     = "${aws_ecr_repository.api.repository_url}:${var.image_tag}"
    essential = true
    command   = ["python", "-m", "scripts.bulk_worker"]

    environment = [
      { name = "AWS_REGION", value = var.region },
      { name = "QUOLIN_ENVIRONMENT", value = var.environment },
    ]

    secrets = [
      {
        name      = "APP_DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:app_database_url::"
      },
      # The owner connection, for enumeration and nothing else. Every one of
      # these serves every firm, and under FORCE row-level security a query for
      # "all tenants" returns the one in scope — `maintenance.active_tenant_ids`
      # is admitted by the `quolin_maintenance` grant migration 0029 creates,
      # which the owner holds. The same trade `health` and `comparison` already
      # make, and `scripts/guard_task_credentials.py` is where it is reviewed.
      {
        name      = "DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:database_url::"
      },
      {
        name      = "QUOLIN_MASTER_KEY"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:master_key::"
      },
    ]

    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = aws_cloudwatch_log_group.api.name
        "awslogs-region"        = var.region
        "awslogs-stream-prefix" = "bulk"
      }
    }
  }])
}

resource "aws_cloudwatch_event_target" "bulk" {
  rule     = aws_cloudwatch_event_rule.bulk.name
  arn      = aws_ecs_cluster.main.arn
  role_arn = aws_iam_role.watch_scheduler.arn

  ecs_target {
    task_definition_arn = aws_ecs_task_definition.bulk.arn
    task_count          = 1
    launch_type         = "FARGATE"

    network_configuration {
      subnets          = aws_subnet.private[*].id
      security_groups  = [aws_security_group.api.id]
      assign_public_ip = false
    }
  }
}


# # Pack lifecycle states, settled.
#
# Two transitions nobody performs: a draft becomes effective because a
# date arrived, and an earlier version is superseded because a later one
# took over. With nothing running this, a future-dated pack never became
# effective — a signed, published rule change simply did not take force
# — and the transition log had a hole where midnight should have been.
#
# Idempotent, and it works out what should have happened by now rather
# than what changed since it last ran, so a missed day catches up.
resource "aws_cloudwatch_event_rule" "settle" {
  name                = "${local.name}-settle"
  description         = "Move packs whose effective date has arrived, and notice each firm."
  schedule_expression = var.settle_schedule
}

resource "aws_ecs_task_definition" "settle" {
  family                   = "${local.name}-settle"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 256
  memory                   = 512
  execution_role_arn       = aws_iam_role.task_execution.arn
  # The application's role, because each of these does what the application
  # does and none of them should be able to do more.
  task_role_arn = aws_iam_role.api_task.arn

  container_definitions = jsonencode([{
    name      = "settle"
    image     = "${aws_ecr_repository.api.repository_url}:${var.image_tag}"
    essential = true
    command   = ["python", "-m", "scripts.settle_packs"]

    environment = [
      { name = "AWS_REGION", value = var.region },
      { name = "QUOLIN_ENVIRONMENT", value = var.environment },
    ]

    secrets = [
      {
        name      = "APP_DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:app_database_url::"
      },
      # The owner connection, for enumeration and nothing else. Every one of
      # these serves every firm, and under FORCE row-level security a query for
      # "all tenants" returns the one in scope — `maintenance.active_tenant_ids`
      # is admitted by the `quolin_maintenance` grant migration 0029 creates,
      # which the owner holds. The same trade `health` and `comparison` already
      # make, and `scripts/guard_task_credentials.py` is where it is reviewed.
      {
        name      = "DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:database_url::"
      },
      {
        name      = "QUOLIN_MASTER_KEY"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:master_key::"
      },
    ]

    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = aws_cloudwatch_log_group.api.name
        "awslogs-region"        = var.region
        "awslogs-stream-prefix" = "settle"
      }
    }
  }])
}

resource "aws_cloudwatch_event_target" "settle" {
  rule     = aws_cloudwatch_event_rule.settle.name
  arn      = aws_ecs_cluster.main.arn
  role_arn = aws_iam_role.watch_scheduler.arn

  ecs_target {
    task_definition_arn = aws_ecs_task_definition.settle.arn
    task_count          = 1
    launch_type         = "FARGATE"

    network_configuration {
      subnets          = aws_subnet.private[*].id
      security_groups  = [aws_security_group.api.id]
      assign_public_ip = false
    }
  }
}
