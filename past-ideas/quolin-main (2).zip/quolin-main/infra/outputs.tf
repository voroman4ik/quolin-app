output "region" {
  description = "Echoed back so a plan makes it obvious which region is about to be touched."
  value       = var.region
}

output "environment" {
  value = var.environment
}

output "url" {
  description = <<-EOT
    Where this stack answers. The name a customer is given and the name the
    smoke test is pointed at, so a deploy that came up on the wrong host is
    visible in the apply output rather than in a support ticket.
  EOT
  value       = local.fqdn != "" ? "https://${local.fqdn}" : "http://${aws_lb.main.dns_name}"
}

output "alb_dns_name" {
  description = "Point the environment's DNS record at this."
  value       = aws_lb.main.dns_name
}

output "ecr_repository_url" {
  description = "Deploy pipeline pushes here."
  value       = aws_ecr_repository.api.repository_url
}

output "database_endpoint" {
  description = "Host only. The credentials are in the database secret, not here."
  value       = aws_db_instance.main.endpoint
}

output "app_secret_name" {
  description = "The human-owned secret. Populate it before the first deploy or the API will not start."
  value       = aws_secretsmanager_secret.app.name
}

output "artefact_bucket" {
  value = aws_s3_bucket.artefacts.id
}

output "tenant_data_key_arn" {
  description = "Stage 1 wraps each tenant's data key under this one."
  value       = aws_kms_key.tenant_data.arn
}
