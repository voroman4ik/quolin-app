terraform {
  required_version = ">= 1.6"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.70"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  # State lives in S3 with DynamoDB locking, configured per environment at init
  # time rather than hardcoded here:
  #
  #   terraform init -backend-config=envs/staging.backend.hcl
  #
  # Partial configuration is deliberate. Stage 11 deploys a dedicated stack per
  # customer from this same root module, and a backend pinned to one bucket and
  # one key would make that a fork rather than a parameterisation.
  backend "s3" {}
}

provider "aws" {
  region = var.region

  default_tags {
    tags = {
      Product     = "quolin"
      Environment = var.environment
      Tenancy     = var.tenancy
      ManagedBy   = "terraform"
    }
  }
}
