# Infrastructure

Everything the product runs on, as code. One root module, parameterised per
environment — there is no separate staging tree, and there will be no separate
tree for a dedicated customer stack either. That is the point.

## State right now

**Written and validated. Never applied.** No AWS account has been touched by
this module. `tofu validate` and `tofu fmt` pass in CI; a plan against a real
account will surface things validation cannot, and the first `apply` is a
Stage 0 gate item that has not been met yet.

The prototype still deploys to Fly (`fly.toml`, `docs/deployment.md`), and that
stays true until staging here is real.

## The environments

| Environment | What it is | State |
|---|---|---|
| `dev` | docker-compose on a laptop | exists, unchanged |
| `demo` | the seeded sales demo on Fly, ILLUSTRATIVE packs and the cast | exists, stays on Fly |
| `staging` | production-shaped, scrubbed seed | described here, not applied |
| `prod` | empty until Stage 9 says otherwise | described here, not applied |
| dedicated | one customer, own database and keys (Stage 11) | `envs/dedicated.tfvars.example` |

## Layout

```
versions.tf     providers, and the partial S3 backend
variables.tf    every value that differs between environments
network.tf      VPC, subnets, security groups
data.tf         KMS keys, Postgres, the artefact bucket
compute.tf      ECR, ECS Fargate, load balancer, IAM
secrets.tf      Secrets Manager, split by who owns each value
outputs.tf      what a deploy pipeline and a human need afterwards
envs/           one tfvars per environment
```

## Running it

State is per environment and configured at init time, so switching
environments means re-initialising:

```sh
cd infra
tofu init -backend-config=envs/staging.backend.hcl
tofu plan  -var-file=envs/staging.tfvars
tofu apply -var-file=envs/staging.tfvars
```

A `*.backend.hcl` holds the state bucket, key and lock table for one
environment. They are gitignored because they name account-specific resources;
the shape is:

```hcl
bucket         = "quolin-tfstate-<account>"
key            = "staging/terraform.tfstate"
region         = "ap-southeast-2"
dynamodb_table = "quolin-tfstate-lock"
encrypt        = true
```

Validation needs no credentials and no backend:

```sh
tofu init -backend=false && tofu validate && tofu fmt -check
```

That is what CI runs.

## Decisions recorded here

**ECS Fargate, not Fly, for product compute.** The execution document asks for
this to be decided once and written down. Three reasons, all downstream: Stage
1 puts per-tenant KMS keys and encrypted evidence in AWS, and compute outside
that boundary spreads the SOC 2 scope across two providers; Stage 9's restore
drill into a clean environment is a Terraform apply here and a manual exercise
across providers; Stage 11 promises a dedicated stack from the same IaC inside
a day, which works when compute is a variable in this module and does not when
it lives in a `fly.toml` that has to be forked per customer.

**Region is `var.region`, defaulting to Sydney.** Sydney because the first
buyers are Australian and "hosted in Sydney" shortens a vendor-risk
conversation. It is not a legal requirement and must never be presented as one
— APRA permits offshore hosting with safeguards, and saying otherwise in a room
containing someone who knows that is expensive.
`scripts/guard_no_hardcoded_region.sh` fails CI if a region literal appears
anywhere but that variable's default.

**Two KMS keys.** The app key covers infrastructure at rest — database volume,
log groups, the secrets needed to start. The tenant-data key covers evidence:
decision snapshots, artefact PDFs, the encrypted PII columns Stage 1 adds. In a
shared deployment it is the wrapping key for per-tenant data keys; in a
dedicated deployment the customer has it to themselves, which is most of what
"dedicated" means to the person asking for it.

**Artefacts are never expired.** The bucket is versioned, KMS-encrypted, has no
public access and no expiration rule — only a transition to cheaper storage.
The task role has `s3:PutObject` and `s3:GetObject` and deliberately not
`s3:DeleteObject`. Evidence is not tidied up.

**`api_desired_count` stays at 1.** Login rate limiting is per-process (see
`api/app/auth.py`), so a second task silently halves the effective lockout.
Raising it before that state is shared is a security regression wearing a
scaling decision's clothes.

**Deletion protection on the database and the load balancer**, and
`auto_minor_version_upgrade = false`. A minor version arriving unannounced
changes server behaviour under a system whose central claim is that a 2026
decision replays identically in 2031.

## Not here yet, on purpose

- **The watch service as its own ECS service with its own database role.**
  Stage 6 requires it — a role with no write grant on `packs`, so the guard
  script becomes a deployment fact. Adding it now would be building Stage 6's
  infrastructure during Stage 0.
- **DNS and certificates.** `acm_certificate_arn` is empty and the HTTPS
  listener is not created without it. An environment with no certificate
  redirects and refuses rather than serving insecurely.
- **The bootstrap of the state bucket itself.** Chicken and egg; it is created
  once, by hand, and recorded in `docs/spec-changes.md` when it happens.
