# Every value that differs between staging, production and a dedicated
# customer stack is a variable here. Nothing environment-specific belongs in a
# resource block: Stage 11 promises "the Terraform that deploys shared deploys
# dedicated, no code fork", and that promise is kept or broken in this file.

variable "region" {
  description = <<-EOT
    AWS region. Sydney by default because the first buyers are Australian and
    "hosted in Sydney" shortens a vendor-risk conversation. It is not a legal
    requirement and must never be presented as one — APRA permits offshore
    hosting with safeguards. A European customer changes this variable; they
    do not get a different codebase.
  EOT
  type        = string
  default     = "ap-southeast-2"
}

variable "environment" {
  description = "staging | prod | demo, or a customer slug for a dedicated stack."
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{1,20}$", var.environment))
    error_message = "environment must be lowercase alphanumeric with hyphens, 2-21 characters."
  }
}

variable "tenancy" {
  description = <<-EOT
    shared: many tenants on one deployment, isolated by row-level security.
    dedicated: one tenant, own database and own keys (Stage 11).
    The application code is identical either way — this changes what gets
    provisioned, never what runs.
  EOT
  type        = string
  default     = "shared"

  validation {
    condition     = contains(["shared", "dedicated"], var.tenancy)
    error_message = "tenancy must be shared or dedicated."
  }
}

variable "vpc_cidr" {
  description = "Staging and production get separate VPCs at minimum; separate accounts are better."
  type        = string
  default     = "10.0.0.0/16"
}

variable "availability_zone_count" {
  description = "Two is the minimum for a Multi-AZ database; there is no reason to go higher yet."
  type        = number
  default     = 2
}

variable "postgres_version" {
  description = <<-EOT
    Pinned to the major version the application is developed and tested
    against. Row-level security, the append-only triggers and the hash-chain
    verification all depend on server behaviour, so a silent major upgrade is
    a correctness risk rather than a maintenance detail.
  EOT
  type        = string
  default     = "16.4"
}

variable "postgres_instance_class" {
  description = "Overridden per environment; staging does not need production's instance."
  type        = string
  default     = "db.t4g.medium"
}

variable "postgres_allocated_storage_gb" {
  type    = number
  default = 50
}

variable "postgres_multi_az" {
  description = "False in staging, true in production. The DR drill in Stage 9 tests the failover."
  type        = bool
  default     = false
}

variable "backup_retention_days" {
  description = <<-EOT
    Stage 9 states 35-day point-in-time recovery as the target and measures it
    with a restore drill. 35 is the RDS maximum for automated backups, so
    anything longer is a snapshot-export problem rather than a knob here.
  EOT
  type        = number
  default     = 35
}

variable "artefact_retention_days" {
  description = <<-EOT
    Artefacts are evidence, and evidence is not tidied up. This governs
    transition to cheaper storage, never expiry — there is deliberately no
    expiration rule in the lifecycle policy.
  EOT
  type        = number
  default     = 90
}

variable "api_desired_count" {
  description = <<-EOT
    How many API tasks run.

    This was 1 until Stage 12, because login rate limiting lived in process
    memory and a second task silently halved the effective lockout — raising it
    then would have been a security regression disguised as a scaling decision.
    The counter now lives in Postgres (migration 0022), so the constraint is
    gone and the reason it existed is worth keeping written down.

    Three, because a load test found the API using between one and two of
    twelve cores: one Python process is one core of bytecode, and rendering a
    PDF is several hundred milliseconds of it during which nothing else in that
    process runs. Three tasks is what met §S12's p99 budgets with room; more is
    a decision to make against a measurement rather than a hope.
  EOT
  type        = number
  default     = 3
}

variable "api_cpu" {
  type    = number
  default = 512
}

variable "api_memory" {
  description = "WeasyPrint holds a whole document in memory while rendering; 512MB is the floor."
  type        = number
  default     = 1024
}

variable "log_retention_days" {
  description = "Stage 9 asks for 12 months of central log retention."
  type        = number
  default     = 365
}

variable "image_tag" {
  description = <<-EOT
    The image the service starts from. Deploys move this forward outside
    Terraform, which is why aws_ecs_service ignores task_definition changes —
    otherwise every plan would propose reverting the last deploy. Never
    "latest": an immutable tag is what lets a 2031 replay pull the 2026 image.
  EOT
  type        = string
  default     = "bootstrap"
}

variable "acm_certificate_arn" {
  description = <<-EOT
    TLS certificate for the load balancer. Empty until DNS and certificate
    issuance are done, and the HTTPS listener is not created without it. The
    HTTP listener still exists and still redirects, so an environment without a
    certificate refuses traffic rather than serving it insecurely.
  EOT
  type        = string
  default     = ""
}

variable "dns_zone_id" {
  description = <<-EOT
    The Route53 hosted zone this stack writes its record into. One zone for the
    whole organisation, not one per customer: a zone per stack means delegating
    nameservers per stack, which is a conversation with a registrar rather than
    an apply.

    Empty means DNS and certificate issuance are somebody else's job — the
    module then uses `acm_certificate_arn` if it has one, and serves no HTTPS at
    all if it does not.
  EOT
  type        = string
  default     = ""
}

variable "dns_hostname" {
  description = <<-EOT
    The label in front of the zone name. Defaults to the environment, so a
    dedicated stack for `acme` answers on `acme.<zone>` — the same slug that
    names its database, its keys and its log group. Set it only when a customer
    wants a name that is not their slug.
  EOT
  type        = string
  default     = ""
}

variable "watch_cpu" {
  description = "CPU units for one watch sweep. It reads a handful of feeds and writes rows; the work is waiting on other people's web servers."
  type        = number
  default     = 256
}

variable "watch_memory" {
  description = "Memory for one watch sweep, in MiB."
  type        = number
  default     = 512
}

variable "watch_mode" {
  description = "`live` reaches the publishers whose pack content declares a readable feed; `replay` reads the committed fixture and contacts nobody. The demo environment stays on replay — a sales asset that quietly starts making requests to four regulators is a different product."
  type        = string
  default     = "live"

  validation {
    condition     = contains(["live", "replay"], var.watch_mode)
    error_message = "watch_mode must be `live` or `replay`."
  }
}

variable "watch_schedule_expression" {
  description = "How often a sweep runs at all. Each source's own cadence decides whether it is actually checked, so this only has to be at least as frequent as the shortest cadence any pack declares."
  type        = string
  default     = "rate(6 hours)"
}

variable "pager_endpoint" {
  description = "Where a page goes — a pager service's endpoint. Empty means nobody is subscribed, which the health task reports rather than hiding."
  type        = string
  default     = ""
}

variable "pager_protocol" {
  description = "How the pager subscribes: `https` for a pager service's inbound webhook, `email` only for environments where nobody is on call."
  type        = string
  default     = "https"
}

variable "comparison_report_schedule" {
  description = "When the weekly shadow comparison runs. Monday morning: a firm in shadow reads last week's divergences at the start of this one, which is the cadence a compliance officer can absorb. Daily would be noise; monthly would be archaeology."
  type        = string
  default     = "cron(0 6 ? * MON *)"
}

variable "health_check_schedule" {
  description = "How often the application's own checks run. Five minutes: often enough that a broken chain is noticed within a working quarter-hour, rare enough that the chain recomputation is not the database's main workload."
  type        = string
  default     = "rate(5 minutes)"
}

# ---------------------------------------------------------------------------
# The asynchronous execution tier.
#
# Five scripts appeared in the Makefile and in zero Terraform files: enqueued
# webhooks were never sent, queued documents never rendered, bulk runs never
# executed — so delta reports and the pinned-tenant UAT flow were dead — future
# dated packs never became effective, and the batch drop was never swept.
#
# **Scheduled tasks rather than an always-on service, and the code decided it.**
# All five are one-shot: they run a pass, report a tally and exit with a code
# their own docstrings document. `deliver_webhooks.py` says "run it on a short
# cycle — a minute is right"; `settle_packs.py` says "run it daily, after
# midnight in the deployment's region". A daemon would have to grow its own
# timer, and that timer would be a second place where cadence lived — which is
# the argument `aws_ecs_task_definition.watch` already makes for the sweep.
#
# The cost is real and is stated rather than hidden: a Fargate task takes tens
# of seconds to start, so a webhook enqueued now is delivered in about a minute
# and a half rather than "within seconds". `docs/integrations.md` says a minute,
# because it now says what this deploys.

variable "webhook_delivery_schedule" {
  description = "How often due webhook deliveries are attempted. A minute is the shortest EventBridge allows and is what scripts/deliver_webhooks.py asks for: the backoff in webhooks.py spaces out retries, and this only asks whether anything is due."
  type        = string
  default     = "rate(1 minute)"
}

variable "artefact_worker_schedule" {
  description = "How often the document queue is drained. A minute: somebody is waiting on a document they asked for, and the queue-depth alert fires at a thousand — which is a number that only means anything if the queue is normally being emptied."
  type        = string
  default     = "rate(1 minute)"
}

variable "bulk_worker_schedule" {
  description = "How often the bulk-evaluation queue is worked. Five minutes rather than one: a run is a sweep of a whole book that takes minutes itself, and a second task starting while the first is working takes nothing (FOR UPDATE SKIP LOCKED) but costs a launch."
  type        = string
  default     = "rate(5 minutes)"
}

variable "settle_schedule" {
  description = "When pack lifecycle states are settled. Daily, after midnight in the deployment's region — the two transitions nobody performs happen because a date arrived. Idempotent, so a missed day catches up rather than skipping the states nobody recorded."
  type        = string
  default     = "cron(30 14 * * ? *)"
}

# `batch_sweep` is deliberately **not** scheduled here, and this is where the
# reason lives rather than in a commit message.
#
# It reads a directory tree — one per tenant, `incoming/`, `processed/`,
# `errors/`. A Fargate task's filesystem is ephemeral and private to that task,
# and this deployment has no EFS mount, no drop bucket and no SFTP server; the
# transport `docs/integrations.md` describes is not built. A nightly task
# pointed at a path inside its own container would read an empty directory
# forever and report success every morning, which is precisely the shape of
# thing the Gate A audit is about: a job represented as operating that has never
# operated on anything.
#
# So it stays a `make` target, and `docs/deployment.md`'s operating table
# records it as deferred with what it needs. Deploying it is one task definition
# and one rule once there is somewhere for a file to land.
