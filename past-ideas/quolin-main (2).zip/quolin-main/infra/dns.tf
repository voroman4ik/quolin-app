# The customer's own subdomain, and the certificate for it.
#
# §S11: "own Postgres, own KMS keys, own subdomain, parameterised per customer".
# The first two are true by construction — every resource in this module is
# keyed on `local.name`, so a second stack shares nothing with the first. The
# subdomain was the piece that was still a manual step, and a manual step is
# what turns "a stack in under a day" into a stack plus an afternoon of waiting
# for somebody to notice a Slack message about DNS.
#
# The hosted zone is **not** created here. One zone per customer stack would
# mean delegating nameservers per customer, which is a conversation with a
# registrar rather than an apply. The zone exists once at the organisation
# level; each stack writes one record into it and owns nothing else about it.
#
# With no zone id, the module behaves exactly as it did before: an externally
# issued certificate, or no HTTPS listener at all and an HTTP listener that
# only redirects. A stack with neither refuses traffic rather than serving it
# insecurely, which is the property worth keeping through a change like this.

data "aws_route53_zone" "main" {
  count   = var.dns_zone_id == "" ? 0 : 1
  zone_id = var.dns_zone_id
}

locals {
  dns_enabled = var.dns_zone_id != ""

  # `acme` → `acme.quolin.example`. The customer slug is already the
  # environment, so a dedicated stack gets its subdomain from the same string
  # that names its database, its keys and its log group. One slug, one stack.
  hostname = var.dns_hostname != "" ? var.dns_hostname : var.environment
  fqdn = (
    local.dns_enabled
    ? "${local.hostname}.${trimsuffix(data.aws_route53_zone.main[0].name, ".")}"
    : ""
  )

  # Whether an HTTPS listener exists at all. Computed from variables rather than
  # from the certificate's ARN, because a `count` cannot depend on a value that
  # is only known after the certificate has been issued.
  serves_https = local.dns_enabled || var.acm_certificate_arn != ""

  certificate_arn = (
    local.dns_enabled
    ? aws_acm_certificate_validation.main[0].certificate_arn
    : var.acm_certificate_arn
  )
}

resource "aws_acm_certificate" "main" {
  count = local.dns_enabled ? 1 : 0

  domain_name       = local.fqdn
  validation_method = "DNS"

  # The listener holds a reference to the certificate, so a replacement has to
  # exist before the old one goes away or the stack loses HTTPS mid-apply.
  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_route53_record" "certificate_validation" {
  for_each = {
    for option in try(aws_acm_certificate.main[0].domain_validation_options, []) :
    option.domain_name => option
  }

  zone_id = var.dns_zone_id
  name    = each.value.resource_record_name
  type    = each.value.resource_record_type
  records = [each.value.resource_record_value]
  ttl     = 60

  # A stack torn down and stood up again under the same name reuses the record.
  allow_overwrite = true
}

# Waits for the certificate to actually be issued. Without this the listener can
# be created against a PENDING_VALIDATION certificate, which applies cleanly and
# then serves nothing.
resource "aws_acm_certificate_validation" "main" {
  count = local.dns_enabled ? 1 : 0

  certificate_arn         = aws_acm_certificate.main[0].arn
  validation_record_fqdns = [for record in aws_route53_record.certificate_validation : record.fqdn]
}

resource "aws_route53_record" "api" {
  count = local.dns_enabled ? 1 : 0

  zone_id = var.dns_zone_id
  name    = local.fqdn
  type    = "A"

  alias {
    name                   = aws_lb.main.dns_name
    zone_id                = aws_lb.main.zone_id
    evaluate_target_health = true
  }
}
