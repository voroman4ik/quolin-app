# Network allocations

Every stack this Terraform has ever been asked to create, and the /16 it owns.

This file is the written record `dedicated.tfvars.example` tells you to allocate
from. It exists because the failure it prevents is quiet: two stacks with
overlapping CIDRs apply cleanly, run fine, and break the day somebody peers them
or routes between them — by which time both hold customer data and neither can
be renumbered without downtime.

`scripts/new_stack.py --check` validates this table against `infra/envs/` on
every CI run: no duplicate slugs, no overlapping ranges, and no stack in one
place that is missing from the other. Add rows with `scripts/new_stack.py`
rather than by hand, so the check and the allocation cannot disagree.

A row is never deleted. A stack that has been torn down keeps its range marked
`retired` — reusing a range is how a routing table ends up pointing at a
customer who left.

| Slug | CIDR | Tenancy | Status | Note |
|---|---|---|---|---|
| staging | 10.10.0.0/16 | shared | planned | Described in `envs/staging.tfvars`; never applied — no AWS account yet. |
| prod | 10.20.0.0/16 | shared | planned | Described in `envs/prod.tfvars`; never applied. |
| acme | 10.30.0.0/16 | dedicated | example | `envs/dedicated.tfvars.example`. Not a real customer; the range is reserved so the first real one does not take it by accident. |
| probe-corp | 10.32.0.0/16 | dedicated | retired | Stage 11's test instance. The files were generated and the allocation checked; it was never applied, because there is no AWS account to apply it into. The range stays retired rather than returning to the pool — see the note above. |
