# Empty until Stage 9 says otherwise. Applying this before operational
# resilience exists would create an environment nobody can restore, which is
# worse than not having one.

environment = "prod"
tenancy     = "shared"
vpc_cidr    = "10.20.0.0/16"

postgres_instance_class       = "db.t4g.medium"
postgres_allocated_storage_gb = 100
postgres_multi_az             = true

backup_retention_days = 35

# Three. The per-process login rate limiter that pinned this at one is gone —
# the counter is in Postgres since migration 0022 — and §S12 measured what one
# process could actually serve, which was between one and two of twelve cores.
api_desired_count = 3
