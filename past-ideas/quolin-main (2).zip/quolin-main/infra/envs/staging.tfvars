# Production-shaped, deliberately not production-sized. Staging exists to make
# a deploy boring and to hold scrubbed seed data; paying for Multi-AZ to
# discover that would be spending money to learn nothing.

environment = "staging"
tenancy     = "shared"
vpc_cidr    = "10.10.0.0/16"

postgres_instance_class = "db.t4g.small"
postgres_multi_az       = false

# Shorter than production on purpose: a staging database is rebuilt from seed,
# so the thing being tested by the Stage 9 restore drill is the procedure, and
# the procedure does not care how far back the window goes.
backup_retention_days = 7
