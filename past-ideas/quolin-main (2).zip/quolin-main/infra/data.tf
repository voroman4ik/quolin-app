# Keys, database, artefact storage.
#
# Two KMS keys, not one, and the reason matters for Stage 1. The application
# key protects infrastructure-level state — the database volume, log groups,
# the secrets that let the app start. The tenant-data key protects evidence:
# decision snapshots, artefact PDFs, and the encrypted PII columns on clients.
#
# In a shared deployment the tenant-data key is the wrapping key: Stage 1
# generates a per-tenant data key, encrypts it under this one, and stores the
# wrapped blob against the tenant row. In a dedicated deployment the customer
# gets this whole key to themselves, which is most of what "dedicated" means to
# the person asking for it.

resource "aws_kms_key" "app" {
  description             = "quolin ${var.environment} — infrastructure at rest"
  enable_key_rotation     = true
  deletion_window_in_days = 30
}

resource "aws_kms_alias" "app" {
  name          = "alias/${local.name}-app"
  target_key_id = aws_kms_key.app.key_id
}

resource "aws_kms_key" "tenant_data" {
  description             = "quolin ${var.environment} — tenant evidence and PII"
  enable_key_rotation     = true
  deletion_window_in_days = 30
}

resource "aws_kms_alias" "tenant_data" {
  name          = "alias/${local.name}-tenant-data"
  target_key_id = aws_kms_key.tenant_data.key_id
}

resource "aws_db_subnet_group" "main" {
  name       = local.name
  subnet_ids = aws_subnet.private[*].id
}

# Parameters, not defaults, because two of these are load-bearing for the
# invariants rather than for performance.
resource "aws_db_parameter_group" "main" {
  name   = local.name
  family = "postgres16"

  # Row-level security is the Stage 1 isolation mechanism. A superuser bypasses
  # RLS unless the table forces it, so the application must never connect as
  # one — this makes an accidental superuser connection visible in the logs
  # rather than silently effective.
  parameter {
    name  = "log_connections"
    value = "1"
  }

  parameter {
    name  = "log_disconnections"
    value = "1"
  }

  # Statements that modify data, so an append-only violation attempt leaves a
  # trace outside the database's own refusal.
  parameter {
    name  = "log_statement"
    value = "mod"
  }

  # Q-03. `timestamptz` is rendered to a client in the session's timezone, and
  # the evidence chain hashes a timestamp. A chain written under UTC and read
  # under this region's local zone verified as broken on every tenant — and the
  # runbook treats a broken chain as a security incident, with nothing in the
  # report to distinguish it from tampering.
  #
  # `app/evidence.py` normalises to UTC before hashing, which is the actual
  # fix and is what makes the evidence independent of this line. This is the
  # third lock, after that and the per-transaction `set_config` in `app/db.py`:
  # anything else reading a timestamp out of this database gets UTC too, rather
  # than whatever a later operator sets while chasing a reporting bug.
  parameter {
    name  = "timezone"
    value = "UTC"
  }
}

resource "random_password" "postgres" {
  length  = 40
  special = false
}

resource "aws_db_instance" "main" {
  identifier     = local.name
  engine         = "postgres"
  engine_version = var.postgres_version
  instance_class = var.postgres_instance_class

  allocated_storage     = var.postgres_allocated_storage_gb
  max_allocated_storage = var.postgres_allocated_storage_gb * 4
  storage_type          = "gp3"
  storage_encrypted     = true
  kms_key_id            = aws_kms_key.app.arn

  db_name  = "quolin"
  username = "quolin_admin"
  password = random_password.postgres.result

  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.postgres.id]
  parameter_group_name   = aws_db_parameter_group.main.name
  publicly_accessible    = false

  multi_az                = var.postgres_multi_az
  backup_retention_period = var.backup_retention_days
  backup_window           = "14:00-15:00"
  maintenance_window      = "sun:15:00-sun:16:00"
  copy_tags_to_snapshot   = true

  # A minor version arriving unannounced would change server behaviour under a
  # system whose central claim is that a 2026 decision replays identically in
  # 2031. Upgrades are deliberate, tested against the replay suite, and applied
  # in the maintenance window.
  auto_minor_version_upgrade = false

  performance_insights_enabled    = true
  enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]

  # Deleting the evidence database must be an explicit, awkward act.
  deletion_protection       = true
  skip_final_snapshot       = false
  final_snapshot_identifier = "${local.name}-final"

  lifecycle {
    ignore_changes = [password]
  }
}

# Artefacts are the documents a compliance officer files and a regulator may
# later ask for. Versioned so an overwrite cannot destroy the earlier document,
# object-locked in production so neither can a delete, and never expired.
resource "aws_s3_bucket" "artefacts" {
  bucket = "${local.name}-artefacts"
}

resource "aws_s3_bucket_versioning" "artefacts" {
  bucket = aws_s3_bucket.artefacts.id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "artefacts" {
  bucket = aws_s3_bucket.artefacts.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.tenant_data.arn
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_public_access_block" "artefacts" {
  bucket = aws_s3_bucket.artefacts.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_lifecycle_configuration" "artefacts" {
  bucket = aws_s3_bucket.artefacts.id

  rule {
    id     = "archive-old-artefacts"
    status = "Enabled"

    filter {}

    # Transition only. There is deliberately no expiration block: an artefact
    # that expires is evidence that has been destroyed, and no storage saving
    # is worth explaining that to an auditor.
    transition {
      days          = var.artefact_retention_days
      storage_class = "STANDARD_IA"
    }

    noncurrent_version_transition {
      noncurrent_days = var.artefact_retention_days
      storage_class   = "STANDARD_IA"
    }
  }
}
