# Two secrets, split by who owns the value rather than by what it configures.
#
# The tempting design is one secret with several keys. It does not work: the
# database URL is Terraform's (Terraform generated the password), the master key
# is a person's, and a single resource forces a choice between Terraform
# overwriting the person's value on every apply or ignore_changes freezing the
# database URL the first time the endpoint moves. Splitting by ownership means
# each value has exactly one writer.
#
# Anything in the Terraform-owned secret is also in the Terraform state file.
# That is acceptable for a generated database password behind a private subnet
# and unacceptable for anything a human chose, which is the other half of why
# the split is here.

resource "aws_secretsmanager_secret" "database" {
  name                    = "${local.name}/database"
  kms_key_id              = aws_kms_key.app.arn
  recovery_window_in_days = 14
}

# Three connection strings, three roles, and the difference between them is the
# whole of what each process is allowed to do.
#
#   database_url        the schema owner. Migrations run as it and nothing that
#                       serves a request does.
#   app_database_url    `quolin_app`: not the owner, no BYPASSRLS, so row-level
#                       security is actually in force for every request.
#   watch_database_url  `quolin_watch`: can read packs and cannot write them.
#                       Stage 6 makes the watch service's separation a privilege
#                       rather than a convention — see migration 0014.
#
# The two role passwords are generated here and applied to the roles by the
# bootstrap that runs migrations, in the same way `make seed` does for dev. The
# migrations create both roles NOLOGIN and without a password on purpose: a
# password in a committed migration is a password in every clone of the
# repository.
locals {
  db_host_and_name = "${aws_db_instance.main.endpoint}/${aws_db_instance.main.db_name}"
}

resource "random_password" "app_role" {
  length  = 32
  special = false
}

resource "random_password" "watch_role" {
  length  = 32
  special = false
}

resource "aws_secretsmanager_secret_version" "database" {
  secret_id = aws_secretsmanager_secret.database.id

  secret_string = jsonencode({
    database_url = join("", [
      "postgresql+psycopg://",
      aws_db_instance.main.username,
      ":",
      random_password.postgres.result,
      "@",
      local.db_host_and_name,
    ])
    app_database_url = join("", [
      "postgresql+psycopg://quolin_app:",
      random_password.app_role.result,
      "@",
      local.db_host_and_name,
    ])
    watch_database_url = join("", [
      "postgresql+psycopg://quolin_watch:",
      random_password.watch_role.result,
      "@",
      local.db_host_and_name,
    ])
  })
}

# Created empty and populated out of band:
#
#   aws secretsmanager put-secret-value \
#     --secret-id quolin-staging/app \
#     --secret-string '{"master_key":"...","allowed_origins":"https://..."}'
#
# `master_key` is the output of `make master-key` and is the one value here that
# cannot be regenerated: lose it and every encrypted record, backups included,
# is gone. Keep a copy somewhere that survives this AWS account.
#
# Terraform owns the container and never the contents. An apply that found this
# empty would leave it empty rather than filling it with a default, because a
# default key that works is worse than a deployment that will not start.
resource "aws_secretsmanager_secret" "app" {
  name                    = "${local.name}/app"
  kms_key_id              = aws_kms_key.app.arn
  recovery_window_in_days = 14
}
