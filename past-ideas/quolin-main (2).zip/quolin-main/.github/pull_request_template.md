## What this changes

<!-- One paragraph. What moved, and why now. -->

## Stage

<!-- e.g. stage-1-multi-tenancy, or "fix" / "content" if outside a stage. -->

## Invariants

The seven invariants are in `docs/spec-changes.md` and in §3.1 of the execution
document. Tick every one this PR touches, and say in one line how it is still
enforced afterwards. A PR that touches none of them ticks none — that is a
normal answer, not a missing one.

- [ ] **1. No jurisdiction logic in engine code** —
- [ ] **2. Deterministic decisions; the frozen snapshot is the only input** —
- [ ] **3. Integer cents and basis points; no floats resolved** —
- [ ] **4. Append-only evidence; decisions hash-chained** —
- [ ] **5. Replay reproduces exactly, forever** —
- [ ] **6. Rules decide, never models; AI reads, drafts and flags only** —
- [ ] **7. Every live pack has a named human signatory; unreviewed content is loudly labelled** —

If this PR appears to require breaking one, do not open it. Say so first.

## Evidence

- [ ] Full test suite green
- [ ] `make guard` green (every guard script, not a chosen subset)
- [ ] `uv run mypy` and `uv run ruff check .` clean
- [ ] The three-tap demo regression still walks: Check (Tom Askew / SOL → BLOCK
      with reasons), Replay (Harold Bell reproduces under pack v1), Generate
      (TMD PDF downloads)

<!-- If a box is unticked, say why here rather than deleting it. -->

## Recorded

- [ ] Dated entry added to `docs/spec-changes.md` for any decision a future
      engineer would otherwise have to reverse-engineer
