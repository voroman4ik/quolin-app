# Quolin

Hybrid prototype of a compliance decision engine for digital-asset distribution.
The decision logic, evidence store and artefact generation are real. The
institution's CRM, custody positions and compliance queue are mocked behind
typed interfaces.

The whole point is one demo moment: pick a client, pick an asset, tap **Check**,
see a BLOCK with three plain-English reasons and the exact rule versions that
fired. Open a decision from eighteen months ago, tap **Replay**, watch it
reproduce under the old rule version. Tap **Generate** and a PDF downloads.

Four jurisdictions run on the same engine — AU, HK, SG and the EU — and when
more than one reaches the same trade, a resolver states which governs, or
records that it cannot order them and why.

---

## Run it

Prerequisites: Docker, Python 3.12 with [uv](https://docs.astral.sh/uv/), Node 20,
and WeasyPrint's native libraries (`brew install pango cairo gdk-pixbuf libffi`
on macOS).

```bash
make up                                          # Postgres 16 on host port 5433
make seed                                        # rebuild schema, load packs, generate the demo book
make api                                         # FastAPI on :8000
make web                                         # Next.js on :3000
```

Then open http://localhost:3000 and sign in as one of the people `make seed`
printed. Anybody holding a privileged role is asked for a six-digit code as
well; the seed prints a working one.

**The API will not start without `QUOLIN_MASTER_KEY`, deliberately.** A prototype
holding client records and an audit trail should fail loudly rather than come up
unlocked. Minimum 12 characters. See [Who can get in](#who-can-get-in).

`make test` runs the engine, replay, evidence, API and auth suites. `make reset`
is `down` + `up` + `seed`. `make watch-tick` runs one sweep of the watch
sources. `make tamper-demo` proves the audit trail in front of an audience —
see [Proving the audit trail](#proving-the-audit-trail).

**Before demoing, read [`docs/demo-script.md`](docs/demo-script.md).** It has the
six-minute walkthrough, the checklist to run the evening before, and a table of
the things that are tempting to say in the room and wrong.

## Proving the audit trail

```bash
make tamper-demo
```

A green "chain verified" tick is worth nothing to a compliance audience if it has
never been seen to fail. This demonstrates the two guarantees separately, because
they are usually conflated:

1. **Append-only.** Postgres refuses an ordinary `UPDATE` on a stored decision,
   by trigger, with no application code involved.
2. **Hash-chained.** The trigger only binds someone with ordinary privileges —
   whoever owns the table can switch it off. What they cannot do is make the
   numbers agree afterwards. The script takes a real stored determination,
   changes one field, recomputes the hash exactly as the engine would, and shows
   it no longer matches the record.

**It writes nothing**, so it is safe to run minutes before presenting, or
mid-meeting. The `UPDATE` is inside a transaction that is always rolled back, and
the recomputation is arithmetic on values read out of the database. It exits
non-zero if either guarantee has regressed, so it doubles as a check and runs in
CI.

The honest framing, worth saying out loud: **the chain does not prevent
tampering — it makes tampering detectable after the fact.** That is tamper-
*evident*, not tamper-*proof*, and it is the property an auditor actually wants.

What it deliberately does *not* do is turn the badge on the evidence screen red,
because that would mean committing a corrupted row to the demo database. That
state is covered by `api/tests/test_evidence_chain.py`; to show it on screen, use
a scratch copy of the database.

## Who can get in

**Per-person identity, and no shared credential anywhere.** The prototype
shipped one passcode and this file described it for far longer than it was
true — the passcode was deleted in Stage 2, and `scripts/guard_no_shared_passcode.sh`
fails the build if a code path for one reappears.

What there is now:

- **People, not a password on a whiteboard.** Each person has an account with
  their own password, and roles granted per firm: `viewer`, `operator`,
  `approver`, `pack_signatory`, `tenant_admin`, `quolin_support`
- **Single sign-on** via OIDC, where a firm has an identity provider. Where they
  do not, password plus an authenticator app
- **A second factor is required for the roles that matter.** `approver`,
  `pack_signatory`, `tenant_admin` and `quolin_support` cannot act without one:
  a session belonging to somebody who holds one of those and has enrolled no
  authenticator can do exactly two things — enrol, and verify. Signing and
  approving assert it again at the action, so the guarantee does not rest on the
  middleware being right
- **Separation of duties.** The person who ran a determination may not override
  it, and the person who signs rule content may not be the one who publishes it.
  Signing additionally demands a credential presented in the last few minutes,
  so an unattended screen cannot sign on its owner's behalf
- **Every action names the account that took it.** The audit trail refuses a row
  it cannot attribute to a provisioned person or machine — there is no
  placeholder actor, because a plausible-looking stand-in reads like a person
  right up until somebody asks who that is

- Every endpoint requires a session except four: `/health`, so a load balancer
  can probe it, and the three `/auth` routes you need in order to log in at all.
  The Swagger docs are **not** in that set — FastAPI serves them publicly by
  default, which hands the whole API surface to anyone with the URL. A test
  asserts the exempt list against the live route table, so a new endpoint cannot
  quietly join it
- Sessions are server-side and revocable — `/auth/sessions` lists what is live,
  `/auth/revoke-all` ends all of them. A signed token would have needed the same
  server-side list to be revocable at all
- The cookie is HttpOnly and carries an opaque id; a password is never stored in
  the clear and never logged, and only a SHA-256 of the session token is kept
- Failed sign-ins are rate limited per address, counted in Postgres so the limit
  holds across processes, and recorded — an attempt names the account when it
  resolves to one and never the address that was typed
- Signing out clears both client-side caches — the localStorage mirror *and* the
  service worker's, which page script cannot reach and so has to be asked. Skip
  the second and "log out" means "hide the screens and leave the client records
  on the device"

`api/app/auth.py` is under 300 lines and is the whole of it. Read it before
describing it to anyone.

## Put it somewhere other than this laptop

[docs/deployment.md](docs/deployment.md) covers three modes — local, a
Cloudflare tunnel for phone testing, and hosted on Fly.io (Sydney) plus Vercel.
Pick the least of them that does the job; a demo on a laptop leaks nothing.

Deployment needs accounts and credentials this repository must never contain.
`fly auth login`, `fly secrets set` and the Vercel configuration are done by
whoever owns the accounts. `make deploy-check` verifies the secrets are present
before `make deploy` replaces a machine.

The one setting people get wrong is `QUOLIN_COOKIE_SECURE`, and it fails the
same way in both directions: login appears to succeed and every request after it
is 401. The reasoning is in the deployment doc.

## Put it on the phone

`make api` binds to localhost only, so a phone cannot reach it. Use the LAN
targets instead, in two terminals:

```bash
make phone        # prints the URL to open
make phone-api    # FastAPI on 0.0.0.0:8000
make phone-web    # Next.js with NEXT_PUBLIC_API_BASE pointed at this Mac
```

Open the printed `http://<mac-ip>:3000` in Safari, then **Share → Add to Home
Screen**. It installs with the Quolin icon and opens full-screen with no browser
chrome.

Both devices must be on the same Wi-Fi, and the Mac's IP changes when you move
networks — re-run `make phone` to get the current one.

**Offline will not work over the LAN.** iOS only registers a service worker in a
secure context, which means HTTPS or localhost; a plain `http://192.168.x.x`
origin is neither. The install and every screen work fine; only the cached
offline mode is unavailable. Offline works as-is in a desktop browser on
localhost.

### Offline on the phone, over HTTPS

```bash
QUOLIN_COOKIE_SECURE=true make api                                      # one terminal
WEB_PORT=3100 make tunnel                                               # another
```

`make tunnel` opens two Cloudflare quick tunnels and prints one URL to open on
the phone. Two, not one: the page is served over HTTPS, so its API calls must be
HTTPS too or the browser blocks them as mixed content — which is why the API
tunnel has to come up before Next.js starts.

`QUOLIN_COOKIE_SECURE=true` is required here and not optional. The tunnel puts
the web app on a different site from the API, so the session cookie is only sent
with `SameSite=None`, which browsers only honour alongside `Secure`.

No Cloudflare account is needed; the hostnames are random and disappear on
Ctrl-C. While it runs the demo is reachable by anyone with the link who also holds an
account, so treat the URL as private and shut it down afterwards.

> **Not yet run end to end.** `scripts/tunnel.sh` has still never been executed
> against a real device — two Cloudflare tunnels, Safari, *Add to Home Screen*,
> and a service worker registering over HTTPS on an actual iPhone. It remains
> the one path here with no evidence behind it.
>
> Its pre-flight has been exercised: the API check, the port check and the
> single-dev-server check all ran on 2026-08-26, and the last of them caught a
> server that was in fact running. The CORS gap this note used to describe is
> closed — a quick tunnel's hostname is random and cannot be registered in
> advance, so the script now detects that the API is refusing the origin, prints
> the exact command, and waits while you restart it.

### Sign in before you go offline

The lock screen needs a live engine. Logging in is a `POST`, and no cache can
answer a `POST` — so a device that has never signed in shows "Cannot reach the
decision engine" and cannot get past it until the API is back. On a plane that is
unrecoverable. Open the app once on the ground.

A device that *has* signed in opens straight into the app on cached records, with
the offline banner up. That is deliberate: the spec requires the airplane-mode
demo, the gate was never the security boundary — the API is — and the client
records are already on the device either way. But the cached session is labelled
rather than trusted: `/auth/session` reads the `X-Quolin-From-Cache` marker and
reports `offline`, so nothing renders as live when it isn't.

That marker is load-bearing and worth knowing about. A service worker serving a
cached API response returns an ordinary `200`; without the marker the app cannot
tell cached data from live data, and would render an unverified hash chain as
"Chain verified". Offline, the badge must read **"Not verified — engine
unreachable"**, and **Check** and **Replay** must be disabled. A green tick while
the engine is down means the marker has regressed.

### Things that will bite you

**Port 5433, not 5432.** Chosen so this never collides with a Postgres you
already have running. `DATABASE_URL` defaults to
`postgresql+psycopg://quolin:quolin@localhost:5433/quolin`.

**macOS needs `DYLD_FALLBACK_LIBRARY_PATH=/opt/homebrew/lib`** for WeasyPrint to
find its native libraries. The `make api` target sets this for you; if you run
uvicorn by hand, set it yourself or PDF generation raises an import error.

**Running the tests writes decisions to the demo database.** `test_api.py`
evaluates real trades. Before a demo, run `make seed` — that is the reset button.

That used to be the whole of the protection, and a warning in a README is not a
control. **The suite now refuses to run against a database that has not been
marked disposable**, and only `make seed` marks one — it drops the schema and
rebuilds it from zero, so a database it has run against is disposable by
definition. The mark is a comment on the database itself rather than a table, so
no migration can put it on a deployment by being applied there. Point
`DATABASE_URL` at anything holding real records and the suite stops before the
first test, naming the database and saying why.

**Running the tests also signs out every open browser.** The auth suite exercises
`/auth/revoke-all`, which is global by design and hits the same database the dev
server uses. Log in again; nothing is lost. Worth knowing before you conclude the
session handling is flaky.

**`make api` refuses to start without `QUOLIN_MASTER_KEY`.** That is the
feature, not a misconfiguration: every client name and every snapshot is
encrypted under a key it wraps, so starting without one would mean either
serving nothing or writing plaintext.

---

## The cast

Ten hand-built clients, each carrying a specific thing worth showing — a few
carry two. The other 200 are generated so the dashboards and queue look like a
real book.

**Single jurisdiction — the engine's basic vocabulary:**

| Client | Asset | Outcome | What it shows |
|---|---|---|---|
| Margaret Wu | BTC | ALLOW | The happy path. Suitable client, suitable asset, inside every threshold |
| Tom Askew | SOL | BLOCK | Three independent reasons at once: concentration, loss capacity, target market |
| Priya Nair | ETH | REFER | One band below requirement — a human judgement call, not a machine refusal |
| Harold Bell | BTC | REFER | Vulnerability flag routes to review regardless of the numbers |
| Dana Cole | BTC | BLOCK | No knowledge assessment on file |
| Tom Askew | BTC3L | BLOCK | Leveraged product, prohibited for retail outright |
| Alex Reyes | ALGO-USD | REFER | A structural flag on the asset, not a fault of the client |

**Cross-border — where the same trade reaches more than one regime:**

| Client | What it shows |
|---|---|
| Chen Yu-Hsuan | One regime, and it is not the reference one. A decision runs end to end under an illustrative pack with no cross-border panel, because nothing was resolved |
| Wei-Lin Chow | Three regimes on one trade. SOL is an altcoin to the AU pack and a complex product to the HK pack, so AU alone would allow and HK blocks. First exposure is capped as a cash sum by AU and HK and as a share of portfolio by SG — two constraints with no common scale, which the system records rather than fakes an ordering for |
| Ingrid Halvorsen | Resident in Germany, advised from Australia. The EU pack is matched by member state, not by code — one pack, twenty-seven states. ALGO-USD is a stablecoin to the AU pack and an asset-referenced token to the EU pack, and the EU target market binds |
| Marcus Tan | Advised through the firm's Singapore licence, so SG governs and SG's precedence orders the constraints — the resolver is not AU-shaped. Domiciled where no pack is held, which the decision states rather than leaving for someone to notice |

Harold also carries the replay story. His SOL purchase on 2025-11-14 landed at
1204 basis points of concentration: inside pack v1's 1500 cap, outside v2's 1000
cap. Replay it and the system reproduces the original REFER under v1 — the
decision stands, the rules moved on.

---

## How it is put together

```
packs/          jurisdiction packs as versioned, effective-dated JSON
api/app/engine/ the evaluator — dsl, snapshot, evaluate, crossborder, pack.
                No jurisdiction-specific rule *content*; CI fails the build if
                a regime name, pack id or rule id appears. Generic jurisdiction
                machinery — residency, domicile, cross-border resolution — is
                engine code by design.
api/app/watch/  regulatory source polling and triage. Cannot reach the engine.
api/app/auth.py sessions, rate limiting, credential freshness
api/app/identity.py people, roles, passwords, TOTP; api/app/mfa.py enforces it
api/app/        evidence chain, artefact rendering, service layer, HTTP surface
fixtures/       mocked CRM and custody data
scripts/        CI guards, the scheduled watch sweep, the tunnel script
web/            Next.js PWA
```

**Packs hold everything jurisdiction-specific**: thresholds, asset
classifications, rules, reason codes, artefact templates. The engine holds none
of it. CI greps for `if jurisdiction ==`, `'AU'` and rule-ID patterns in engine
code and fails the build if it finds any. A fifth jurisdiction is a new JSON
file, not a code change — which is the commercial claim of the whole system, so
it is enforced by CI rather than asserted in a deck.

**Which regimes apply is derived from the frozen snapshot**, not from the client
record as it stands today. Licensee, residency and domicile are inside the hash,
so replay selects the same packs from the same facts even after a client moves
house.

**The resolver refuses to order what it has no basis to order.** Where two
constraints are expressed in different quantities — a cash cap and a share of
portfolio — it records `no_common_scale` rather than inventing a ranking. A
compliance officer can defend "both bind and neither is stricter"; they cannot
defend a fabricated ordering.

**Rules are a condition DSL**, not code: comparisons, boolean composition and
table lookups. No arithmetic, no `eval`, nothing arbitrary. A pack is reviewable
by a compliance specialist who does not program.

**Every decision freezes a snapshot** — client profile, asset classification as
it stood in the pack in force that day, trade amount, derived calculations. The
snapshot is the only input to evaluation, which is what makes replay exact
rather than approximate.

**Money is integer cents, ratios are integer basis points.** A guard in the DSL
raises if a float is ever resolved, because float drift breaks replay equality
and you would only find out years later.

**Packs, decisions, overrides and audit events are append-only for the
application role**, enforced two ways independently: a Postgres trigger and a
revoked grant. Either alone would do; both means a migration that quietly drops
one still leaves the other. Session rows are the one deliberate exception —
they must be deletable, or logout is theatre.

**Decisions and audit events are hash-chained.** Each row commits to the one
before it within its firm, so altering any stored input breaks every hash that
follows, and `GET /evidence/verify` walks both chains and recomputes every link.
Appends are serialised per firm and a unique index refuses two rows claiming the
same parent — Stage 13's restore drill found ten determinations sharing one,
written twenty milliseconds apart, which is what concurrency does to a chain
nothing is guarding.

**Tamper-evident, not tamper-proof, and the difference is the honest part.**
Append-only stops the application role editing or removing a row. It does not
constrain the owning database role, which runs migrations and can drop a trigger
— so privileged database access remains a trust boundary, written down as T1,
T3 and T9 in `docs/threat-model.md`. What the chains add is that an alteration
cannot be made to look like it never happened.

---

## Whether the rules are current

`/currency` answers it rather than the demo asserting it. Each regime's
freshness is **derived** from when its sources were last checked against the
cadence its own pack declares, so it decays on its own and cannot be left
reading CURRENT by a forgotten write.

The consequence is intentional: an unattended deployment drifts to STALE, which
is the screen telling the truth about a system nobody is operating. Something
has to run the sweep.

**A regime watched by hand cannot report CURRENT.** Most sources are polled — a
publisher's own feed where one exists, and otherwise by digesting the page and
comparing with the last check. Some genuinely cannot be: a publication behind a
login, or a search portal whose front page moves without anything being
published. Those are declared `MANUAL` in pack content, carry the date somebody
last looked, and roll up as `MANUAL` — which is a *worse* state than `CURRENT`,
because somebody remembering to check is not the same assurance as a check that
happens on its own. Being manual does not excuse being unverified: past its
cadence a manual source goes `DUE` and then `STALE` like any other.

```bash
make watch-tick     # locally, or from cron, or as a Fly scheduled machine
```

**It defaults to replay mode, over a fixture**, because the failure mode of the
other default is a demo that quietly starts making requests to four regulators.
Under `WATCH_MODE=live` sources are actually read — a feed where the pack
declares one, a page digest otherwise — and `live` refuses only when *nothing*
in the shelf can be read at all, naming the sources. A system that pretends to
poll a regulator is worse than one that says it cannot. `/currency` still answers under `live` — it reports the mode rather
than inventing freshness, since it reads what was already recorded. The
sweep prints "no regulator was contacted" on every run — a log line reading
"watch tick ok" for six months is how a fixture quietly becomes something people
believe is a feed.

**No watch path can reach the evaluator.** A regulatory alert must never change
a decision without a pack version behind it, so `api/app/engine` cannot import
`api/app/watch`, and `api/app/watch` does not evaluate. A shell guard and
AST-based tests fail the build if that changes. It is the second CI-enforced
invariant, alongside "no jurisdiction logic in the engine".

---

## Where the mocks are

Three interfaces, in `api/app/providers/__init__.py`:

- `ClientProvider` — reads the demo `clients` table; would read a CRM
- `PositionsProvider` — reads `fixtures/positions.json`; would read custody
- `QueueSink` — writes an audit event; would push to a real compliance queue

Swap the implementation, not the call sites. `/integrations` lists every one of
them on screen, so the question "what is actually real here?" is answered inside
the demo rather than in a footnote afterwards.

---

## What the console does not reach

Fix-pack 3 gave seven API surfaces a screen — bulk-run delta reports, the
document queue, user administration and invitation, the rule-version policy, the
chain certificate, the adoption rung and source attestations. That leaves a
short list of routes a person still cannot reach from the app, and being
specific about which ones is more useful than a claim that the console is
complete.

Every route below is published in the OpenAPI document at `/docs`.

| Route | Who calls it |
| --- | --- |
| `POST /comparison/ingest` | The customer's own system, or us on their behalf during a shadow-mode bake-off. It takes an extract of what *their* engine decided, which is a file they produce — a screen would be an upload form for a format only they can generate. |
| `POST /artefacts/batch` | Their scheduler at month-end, and this app when it asks for a failed document again. Nobody sits and queues a hundred documents by hand. |
| `POST /currency/sources/{id}/verify` | A specialist attesting that they checked a publication. The *history* is on the currency screen now; recording one belongs in whatever they were already using when they did the checking, not in a form they have to remember to open afterwards. |
| `GET /watch/alerts` | A monitoring system. It is the page-us-when-a-source-stops-answering feed, and its consumer is PagerDuty rather than a person — the same information reaches the screen as the "not answering" line on each source. |
| `POST /v1/oauth/token`, `GET /v1/decisions`, `POST /v1/evaluate` | A customer's own integration, holding a client-credentials token. These are the machine API. A screen for them would be a screen for somebody else's server. |

Two more are **deferred**, and the reason is the same in both cases: the API
exists, works and is tested, and the screen would be the second half of a
feature whose first half nobody has asked for yet.

* **`GET /auth/sessions` and `POST /auth/revoke-all`** — "who else has this
  open", and a way to end all of it. Worth building when there is more than one
  device per person to worry about; today the honest answer is that suspending
  somebody already ends every session they hold (FP3-13), which covers the case
  that matters. Deferred rather than dropped: the day a customer runs this on
  their own staff's laptops, a person needs to see the list.
* **`GET /webhooks/deliveries` and redelivery** — the delivery log and a retry
  button. Deferred because webhook consumers are systems, and the person who
  cares whether a delivery landed is an engineer with database access rather
  than a compliance officer with a phone. It becomes a screen when a customer is
  integrating against it and asks why an event did not arrive.

---

## What this is not yet

This list was four-fifths wrong when it was re-read on 2026-08-26, and every
error ran the same direction — it described a product weaker than the one in the
repository. It claimed a shared passcode with nothing attributed to an
individual (per-user sign-in with MFA has been in since Stage 2, and a guard
fails the build if a passcode code path returns). It claimed `WATCH_MODE=live`
returns 501 (live polling adapters exist). It claimed rate limiting is
per-process (it reads `auth_attempts` from the database, so it is shared across
instances). It claimed there are no automated backups and no restore drill
(`backup_retention_days` on RDS, and `make restore-drill`).

Understating what a system does is not the safe direction. Somebody assessing
this would have drawn conclusions about its security posture from a paragraph
nobody had re-read in eleven stages. What follows is what is actually missing.

**Nothing here has run in a deployed environment.** This is the single largest
gap and most of the others are downstream of it. `infra/` describes staging and
production in OpenTofu; that Terraform has never been applied, because doing so
needs a cloud account this repository does not have. Every number quoted
anywhere in these documents was produced on a developer machine or in CI. The
table below says which is which.

| Claim | Where it was actually produced | What is still owed |
|---|---|---|
| Blue-green cutover, health-gated, with a timed rollback | `docker compose` on a laptop, 2026-08-26 | §16 wants under two minutes on production-shaped infrastructure |
| Load targets — 20 concurrent sessions, 10k clients, 40k determinations | a developer machine against a generated model | §S12's gate asks for staging with production-shaped volumes |
| Restore drill, chains verified in the restored copy | a development database | the drill against a real automated backup |
| Game day — every alert path fired on purpose | a development database | staging, per `docs/deployment.md` |
| Access review generated with a digest | CI, against the seeded database | §S2's gate asks for staging |
| Nightly replay, with an injected mismatch caught | CI | §S3's gate asks for staging on a schedule |
| Tenant isolation — RLS suite and read-only probe | CI, one deployment, one tenant | a real multi-tenant topology |
| The three offline failure modes | a real browser, production build, locally and in CI | a phone |

Fix-pack 2 is what makes the first real run survivable, and it found the cost of
never having done one. Every background worker enumerated tenants through a
policy that only a superuser or a `BYPASSRLS` role walks past; development's
owner is both and an RDS master account — which `infra/` provisions — is
neither, so on the first deployed database every scheduled job would have found
nothing, done nothing and exited 0, including the §S9 paging path. The evidence
chain hashed a timestamp rendered in the connection's timezone, and Sydney is
the primary region in `infra/`, so verification would have failed on every
tenant and read as a tampering incident. Neither was visible from here. See
[docs/spec-changes.md](docs/spec-changes.md), Tier 0.

**"An assurance layer that can still lie" — where that verdict now stands.**

Three merged audits gave that summary of this repository on 2026-08-27. It was
fair, and it is worth being specific about which parts of it fix-pack 3 answered
and which it did not.

*What changed, and each of these was a real way the system could have said
something untrue about itself:*

* **The migration linter guarded nothing.** It was a regex over SQL spellings
  and every migration here is alembic Python — `op.drop_column("decisions",
  "prev_hash")` passed it. It applies migrations to a scratch database and reads
  the catalog back now, and on its first honest run it found two things no audit
  had named: migration 0003's downgrade removed every tenant-isolation policy,
  and the application role could edit `chain_rechains`, the table recording who
  rewrote a firm's evidence hashes.
* **Four more guards were decorative.** Engine purity, jurisdiction leakage,
  tier divergence and the region check each ran, printed OK, and had nothing
  behind them. Every one now has mutation cases that watch it fail.
* **The rate limit was keyed on a header the caller writes.** Thirty failed
  sign-ins behind a spoofed `X-Forwarded-For` reached no limit at all, and
  `auth_attempts` — the record Stage 9 says survives an attacker — recorded the
  attacker's chosen fiction.
* **The owner connection sat in the request-serving task**, for nothing: no
  request path used it.
* **`source.stale` and `pack.staged`/`pack.published` reached nobody.** The
  first could not run in the deployed watch task at all; the second reached only
  the publisher's own tenant, which is not a customer.
* **Reads were not audited.** Forty GET routes, thirty audit calls, none of them
  on a GET — including `/clients/{id}`, which returns a name and a date of birth
  to any `viewer`.
* **The shadow-mode agreement rate was editable in place.** The one number a
  sale closes on was the one number not protected the way every other one is.
* **Publishing rule content was authorised by a tenant-local row.** A capability
  whose target is every customer on the platform was conferred by a role grant
  belonging to one firm, so compromise of a single firm's role set reached every
  firm's regulatory content. It is a platform grant now, held by two named
  people, and publication takes both of them.
* **A pinned firm learned about a new version on the day it already applied.**
  The review window opened after the thing it was a window for had happened. It
  opens on publication now, and a firm left past its window is told every day,
  in a chained record, with every determination it makes in that period saying
  so on its face.
* **A firm could revoke somebody's last role and lose the ability to say who
  they were.** No audit named this one; it was found by revoking a grant through
  a screen this fix-pack had just built, and of everything in this list it is the
  most literal case of the system saying something untrue about itself — the
  audit trail went on naming a person the firm could no longer resolve, and the
  quarterly access review would not have mentioned them at all, because it walks
  live grants and they no longer had one. The suite's own
  `test_the_trail_names_only_actors_that_exist` is what refused it. `users` has
  no `tenant_id` and cannot have one — a consultant compliance officer serves
  three firms and is one human — so migration 0007 answered "which people may
  this firm see?" with "the ones it has granted a role to". `user_roles` was
  therefore carrying two different facts, who belongs here and what they may do,
  and revoking the second removed the first. Accepting an invitation before being granted anything reached the same
  state with no revocation at all. Migration 0047 separates them: membership is
  its own create-only table, the backfill repairs the firms where this had
  already happened rather than only the next case, tenant isolation is asserted
  unchanged, and a revoked role still stops authorising.

*Where the verdict still holds, and these are not small:*

* **Business dates were the container's calendar day**, and the two sites that
  spelled it `datetime.now(timezone.utc).date()` were found by the new
  dual-timezone CI run rather than by anyone reading. There will be others of
  that shape; the guard covers the two spellings we know about.
* **Five determinations on file carry a knowledge assessment dated after the day
  they were made**, evaluating to ALLOW because every currency rule reads a
  negative age as comfortably recent. New writes are refused; those five rows
  stand, and the corpus case exists so nobody re-discovers this by accident.
* **Two findings have no browser test, and it is the same gap in both.** FP3-12
  (authenticator enrolment, in-place re-authentication) and FP3-26 (seven
  console screens) were first recorded here as NOT DONE, because both asked for
  Playwright specs and Playwright's browser does not launch in this environment
  — verified, not assumed. They were then built without those specs, on
  instruction, and the entry above is corrected rather than deleted: the screens
  exist, they typecheck and they compile in a production build, and **no
  automated test has driven one of them in a browser**.

  What *is* proved automatically is the half a browser test would have proved
  second: the session says when it is confined and when a credential has gone
  stale, a confined session can enrol and the confinement lifts, a
  ten-minute-old credential signs and a twenty-minute-old one is refused with
  the header the client reads, re-authenticating in place lets the same act
  through on the same cookie, and the firm's roster lists its members with the
  grants `user_roles` records while refusing a viewer the writes. That is the
  contract the client is written against.

  Whether the client honours it was then checked by a person driving Chrome —
  every screen, as the role that would use it, against a live engine. That found
  four defects a typecheck and a production build had both passed: a screen
  offering four buttons to somebody authorised to press none of them, a raw user
  id where a name belongs, an invitation page that rejected a valid link, and
  the same page leaving a live credential in the address bar after promising not
  to. All four are fixed and written up in
  [docs/spec-changes.md](docs/spec-changes.md).

  It also found the data-model defect listed above — belonging to a firm and
  holding a role in it being the same row — which is not a screen bug at all.
  A test had performed that sequence since Stage 2 and asserted the half of it
  that was working. Clicking the button was the first time anybody looked at
  what the rest of the system said afterwards.

  That walkthrough is better than nothing and it is not a test. It happened
  once, by hand, and nothing repeats it on the next change — which is exactly
  the kind of evidence the rest of this document declines to accept. FP3-17's
  console banner is done on the same terms.
* **The deeper point is unchanged, and this fix-pack sharpened it.** Every one
  of the defects above was found by running something rather than by reading it,
  and several sat underneath green tests that asserted the opposite. Two rules
  now make part of that mechanical — no test may read source text to prove
  behaviour, and every guard has a mutation case.

  Neither rule would have caught the last one on the list, and the reason is
  worth being exact about.
  `test_a_grant_can_be_revoked_and_the_revocation_is_recorded` had performed
  that exact sequence since Stage 2 — provision somebody, grant one role, revoke
  it — and passed throughout. It asserted that the grant was gone and that the
  revocation was chained. Both true. It never asked whether the person was still
  someone the firm could name, and the person it provisions never acts, so no
  audit row named them and nothing downstream noticed either. The test was not
  weak about its own claim; it was complete about one half of what the act does
  and silent about the other.

  It now asserts the other half, and that assertion was checked failing against
  the old policy before being kept. A related claim of mine did not survive
  contact with CI at all: 0047 enforced "a grant implies a membership" by
  putting the write inside `grant_role`, and two test fixtures construct the row
  directly, so on a database built from zero the invariant simply did not hold.
  It is a database trigger now (0048). The local suite had been green because a
  developer machine stops having an empty database after the first run. But the sequencing is the point: the test
  was strengthened *after* somebody pressed the button and read what the rest of
  the system said. Rules make a claim harder to fake; they do not make anybody
  ask whether the claim was the right one. What did that was using the product.
  That is a practice rather than a rule, and practices are only as good as the
  next person's willingness to keep them.

**No penetration test.** [docs/threat-model.md](docs/threat-model.md) is the
people who wrote the code reviewing their own work, and says so at the top and
the bottom. Zero findings from zero tests is not zero findings.

Three external reviews have now been through §16's audit gate, and fix-pack 2
worked their findings — [docs/spec-changes.md](docs/spec-changes.md) records
every one as FIXED, NOT REPRODUCED or NOT PRESENT, including the eight places
the brief was wrong against the code and the three defects no review contained.
That is still not a penetration test. The most useful thing it demonstrated is
that **the suite passing is not the same as the system working**: `POST
/v1/oauth/token` refused every valid credential on any real deployment while
twenty-eight tests exercised it and passed, and `make tamper-demo` told its
audience the evidence chain was already broken. Both were found by running the
thing, not by reading it.

**The evidence room is nearly empty.** `evidence/` and `make evidence-index`
exist and work; what they hold is a handful of artefacts from the day the room
was built. A SOC 2 observation window is wall-clock, and no window has started.

**Custody is a fixture.** `PositionsProvider` reads `fixtures/positions.json`.
The other two interfaces are equally mocked and labelled — see *Where the mocks
are* above, and `/integrations` inside the app.

Since fix-pack 2 that absence is a *gate* rather than a disclosure. A client who
arrived by CSV, by file drop or through the API has no custody record, and the
concentration calcs are withheld from the snapshot rather than computed from a
zero nobody supplied. Rules that read one refer the case to a person and name
the missing field; the document says "Not on file" and explains why. Before
that, an imported client with a $100,000 portfolio and a $5,000 purchase
evaluated ALLOW on a concentration of 500 bps that had no input behind it. What
is still owed is a custody adapter: this stops a wrong answer being recorded, it
does not produce a right one.

**Every threshold in `/packs` is illustrative** and labelled as such in each
pack's notes. Real numbers need consultant sign-off.

The §14 workflow can now actually produce reviewed content — before fix-pack 2
it could not, and the only route to a `REVIEWED` pack was hand-editing a file
and reseeding as the owner. It still will not produce one here, and that is
deliberate: publication stamps `REVIEWED` only when the signature carries a real
qualification reference, and every `pack_signatory` grant in this repository
holds a placeholder. Engaging a specialist is what changes that, which is the
honest position.

**No rate limiting beyond sign-in, and no load shedding.** Past the thread
limiter, requests queue rather than being refused — a request served in ninety
seconds is worse than a 503 with a `Retry-After`. T13 in the threat model.

**The phone is unproven.** `scripts/tunnel.sh` has had its pre-flight exercised
and has never been run end to end against a real device. Nothing in this
repository substitutes for Safari, *Add to Home Screen*, and a service worker
registering over HTTPS on an actual iPhone.

**The Gate A audit found eight more, and three of them were the same shape as
the entries above: a thing this repository believed it operated and did not.**
Two independent external audits assessed the tree against §16.1 on 2026-08-28;
one read code, the other provisioned Postgres, seeded it and attacked the
running system. The fixes are in [docs/spec-changes.md](docs/spec-changes.md)
and the three worth naming here are these.

*Every deployed scheduled task died on its first import.* All three ran
`python -m scripts.…` against an image whose dependencies live in `/app/.venv`,
so `python` was the base image's interpreter. That silently disabled the whole
monitoring tier — the watch sweep, the weekly comparison, and the health job
that would have reported the outage, including the heartbeat written so a dead
monitor can be told from a quiet one. The API worked because its command wrapped
itself in `uv run`, which was also rebuilding a virtualenv the build had
clobbered: there was no `.dockerignore`, so `COPY api/ /app/` copied a
developer's macOS venv over the Linux one. Three defects, and each hid the next.

*Five more workers had a `make` target and no scheduler at all.* Enqueued
webhooks were never sent, queued documents never rendered, bulk runs never
executed — so delta reports and the pinned-tenant UAT flow were both dead —
future-dated packs never became effective. `docs/deployment.md` already stated
the rule that would have caught two of them, in prose, which is a rule enforced
by whoever remembers it.

*And the chain verifier stopped answering under tamper.* A forged row raised out
of the decrypting column type before any hash was compared, so the page said
"the chain_integrity check could not run — fix the check" rather than naming the
determination. The severity and the exit code were right; the instruction sent
somebody to look at monitoring code while the evidence was being altered.

The other five: a signature could be the author's own and nothing recorded who
the author was; a malformed rule id crashed the validator and let two rules
share a number; a required CI guard passed with its scan pointed at nothing; a
request handler held the schema owner's connection; and `docs/integrations.md`
told a customer they get a chrooted SFTP account with PGP at rest, none of which
exists.

The full list, stage by stage, is in [docs/post-raise.md](docs/post-raise.md).

---

## Scope

The spec is closed. Anything not in it is out — good ideas go in
[docs/post-raise.md](docs/post-raise.md), not into code. Implementation decisions
taken where the spec left detail open are recorded in
[docs/spec-changes.md](docs/spec-changes.md).

Every number in `/packs` is illustrative and labelled as such in the pack notes.
Real thresholds need consultant sign-off, and until that lands nothing here
should be described as a compliance determination.
