/**
 * The three failure modes, walked by a browser instead of by a person.
 *
 * `docs/demo-script.md` §3 is the checklist this replaces. Its own words on why
 * it matters are worth repeating, because they are the assertion:
 *
 *   a service worker serving a cached API response returns an ordinary 200, so
 *   without the `X-Quolin-From-Cache` marker the app cannot tell cached data
 *   from live data — and would render an unverified hash chain as "Chain
 *   verified".
 *
 * So the tests below do not check that the app "works offline". They check that
 * it *says* it is offline, in the three places a person would otherwise be
 * misled: the banner, the chain badge, and the two controls that need a live
 * engine and would fail after the tap rather than before it.
 *
 * One browser context for the whole file, created once. A service worker is
 * per-origin state that takes a visit to install and a second visit to serve
 * from; a fresh context per test would test installation three times and the
 * offline path never.
 */

import { expect, test, type BrowserContext, type Page } from '@playwright/test';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import {
  API_ORIGIN,
  OPERATOR,
  PASSWORD,
  WEB_ORIGIN,
  demoTotpSecret,
  startApi,
  startWeb,
  stopAll,
  stopApi,
  stopWeb,
  totpNow,
} from './servers';

const SCREENS = ['/', '/clients', '/queue', '/packs', '/reports', '/integrations'];

let context: BrowserContext;
let page: Page;

/** Filled by the first test; the later ones skip rather than assert on ''. */
let clientUrl = '';
let evidenceUrl = '';

test.describe.configure({ mode: 'serial' });

test.beforeAll(async ({ browser }) => {
  await startApi();
  await startWeb();
  context = await browser.newContext({ baseURL: WEB_ORIGIN });
  page = await context.newPage();
});

test.afterAll(async () => {
  await context?.close();
  await stopAll();
});

/** Choose the first real asset, so `Check` is judged on the engine and not on an empty form. */
async function selectAnAsset(target: Page): Promise<void> {
  const select = target.getByLabel('Asset', { exact: true });
  await expect(select).toBeVisible();
  const value = await select
    .locator('option')
    .nth(1)
    .getAttribute('value');
  expect(value, 'the asset list is empty, so Check can never be enabled').toBeTruthy();
  await select.selectOption(value!);
}

/** Wait until a worker is not merely registered but actually serving this page. */
async function serviceWorkerControls(target: Page): Promise<void> {
  await expect
    .poll(
      () => target.evaluate(() => Boolean(navigator.serviceWorker?.controller)),
      {
        message:
          'no service worker took control of the page. Everything below would ' +
          'pass against an app with no offline support at all, so it fails here.',
        timeout: 60_000,
      },
    )
    .toBe(true);
}

test.describe('offline regression', () => {
  test('sign in and fill the cache from a live engine', async () => {
    await page.goto('/');

    await page.getByLabel(/email/i).fill(OPERATOR);
    await page.getByLabel(/password/i).fill(PASSWORD);
    await page.getByRole('button', { name: /sign in/i }).click();

    // The second factor, if this account owes one.
    //
    // F8 put `operator` into `MFA_REQUIRED_ROLES`, so the seeded operator now
    // has an authenticator and the form asks for a code after the password
    // checks out — the engine cannot say so sooner without becoming an
    // account-enumeration oracle, which is why this is a second step rather
    // than a field filled up front.
    //
    // Conditional rather than unconditional: this spec should keep working
    // against a deployment whose operator holds no factor.
    //
    // The wait is on *either* outcome rather than on the code field alone, and
    // that is not a nicety. `isVisible()` answers immediately, so asking it the
    // instant after the click races the render — it would report false on a
    // slow paint, the code step would be skipped, and the failure would look
    // exactly like the one this is fixing. Waiting for whichever of the two
    // arrives first is the only form of this that is not a race.
    const codeField = page.getByLabel(/six-digit code/i);
    const chainBadge = page.getByText('Chain verified');
    await expect(codeField.or(chainBadge).first()).toBeVisible();

    if (await codeField.isVisible()) {
      await codeField.fill(totpNow(demoTotpSecret(OPERATOR)));
      // The button reads 'Checking…' while the first request is in flight, so
      // this locator also waits for it to settle back.
      await page.getByRole('button', { name: /sign in/i }).click();
    }

    // The dashboard's chain badge is the thing the offline case must change.
    await expect(chainBadge).toBeVisible();

    await serviceWorkerControls(page);

    // The cache only holds what has been fetched at least once — the same
    // sentence the manual checklist opens with, and the same reason.
    for (const screen of SCREENS) {
      await page.goto(screen);
      /*
       * Wait for the requests, not for the markup.
       *
       * A screen paints before its data arrives, and the first version of this
       * loop navigated straight on — cancelling the in-flight fetch, so the
       * cache it was supposed to be filling stayed empty and the offline tests
       * below failed against screens that had never actually loaded.
       *
       * The status bar was the next attempt and is worse than useless here:
       * `connectivity` starts optimistic, so it reads `Live` before anything
       * has been requested. It reports the last answer, not the presence of one.
       */
      await page.waitForLoadState('networkidle');
    }

    /*
     * Two detail screens, because the controls that must be refused offline
     * live on them and not on any list.
     *
     * The ids come from the API rather than from clicking whichever link the
     * DOM offers first. The clicking version navigated to the wordmark and sat
     * there until the test timed out — a fragility in the test that says
     * nothing about the product, which is the worst kind.
     */
    const ids = await page.evaluate(async (apiBase: string) => {
      const get = async (path: string) => {
        const res = await fetch(apiBase + path, { credentials: 'include' });
        return res.ok ? await res.json() : [];
      };
      const clients = await get('/clients?limit=5');
      const decisions = await get('/decisions?limit=5');
      return {
        client: clients[0]?.id ?? '',
        decision: decisions[0]?.id ?? '',
      };
    }, API_ORIGIN);

    expect(ids.client, 'the seeded book has no clients — run `make seed`').toBeTruthy();
    expect(
      ids.decision,
      'no recorded decisions, so the replay control cannot be exercised',
    ).toBeTruthy();

    clientUrl = `/clients/${ids.client}`;
    evidenceUrl = `/decisions/${ids.decision}/evidence`;

    /*
     * The same care on the detail screens, and here it is also the online
     * baseline: both controls are *enabled*, which is what makes "disabled"
     * further down mean something.
     */
    await page.goto(clientUrl);
    /*
     * Pick an asset first. `Check` is disabled with nothing selected, so
     * asserting "disabled" offline without this would pass against a build
     * where `engineUp` had stopped being consulted at all — the control would
     * be refusing for the wrong reason and the test would call it a pass.
     */
    await selectAnAsset(page);
    await expect(page.getByRole('button', { name: /^check$/i })).toBeEnabled();

    await page.goto(evidenceUrl);
    await expect(
      page.getByRole('button', { name: /replay this decision/i }),
    ).toBeEnabled();

    // Nothing is claimed as cached until the worker has actually seen it.
    await page.goto('/');
    await serviceWorkerControls(page);
  });

  test('API down, web up — every screen renders, and says it is cached', async () => {
    await stopApi();
    await page.goto('/');

    await expect(
      page.getByText('Engine unreachable — showing last synced records'),
    ).toBeVisible();

    // The regression this file exists for. A cached 200 without the marker
    // would leave this reading "Chain verified" over unverified evidence.
    await expect(page.getByText('Not verified — engine unreachable')).toBeVisible();
    await expect(page.getByText('Chain verified')).toHaveCount(0);

    // And the records are still there — an app that failed safe by rendering
    // nothing would pass the assertions above and be useless on a plane.
    await expect(page.getByText(/records at last sync/)).toBeVisible();

    for (const screen of SCREENS) {
      await page.goto(screen);
      /*
       * Each screen renders its own heading and its own banner — which is a
       * claim about the app, not about the absence of something.
       *
       * The first version searched for `/application error|500|502|503/` and
       * failed on the packs screen, where a governed-asset count happened to
       * contain one of those digits. Asserting the absence of loose patterns
       * across arbitrary content finds page data, not errors.
       */
      await expect(page.getByRole('heading').first()).toBeVisible();
      await expect(
        page.getByText('Engine unreachable — showing last synced records'),
      ).toBeVisible();
    }
  });

  test('API down — the controls that need an engine refuse before the tap', async () => {
    // Not `test.skip`. These ran green under a sabotage check that removed the
    // engine test from the control entirely — because the skip fired and a
    // skipped test is not a failure. A guard that can quietly stop guarding is
    // worse than no guard, so a missing setup is an error.
    expect(clientUrl, 'the setup did not reach a client screen').toBeTruthy();
    await page.goto(clientUrl);
    await selectAnAsset(page);

    // Enabled a moment ago with the same asset selected. The only thing that
    // changed is that the engine went away.
    const check = page.getByRole('button', { name: /^check$/i });
    await expect(check).toBeVisible();
    await expect(check).toBeDisabled();
    await expect(
      page.getByText(/A new check runs the engine, so it needs a connection/),
    ).toBeVisible();
  });

  test('API down — replay says why it cannot run, and the record stays readable', async () => {
    expect(evidenceUrl, 'the setup did not reach an evidence screen').toBeTruthy();
    await page.goto(evidenceUrl);

    const replay = page.getByRole('button', { name: /replay this decision/i });
    await expect(replay).toBeVisible();
    await expect(replay).toBeDisabled();
    await expect(
      page.getByText(/Replay re-runs the engine, so it needs a connection/),
    ).toBeVisible();
  });

  test('web down, API up — the shell still comes from the service worker', async () => {
    await startApi();
    await stopWeb();

    // Nothing is listening on the port. Anything that renders here came out of
    // the worker's cache, which is the whole claim.
    await page.goto('/');
    await expect(page.getByText('Quolin')).toBeVisible();
    await expect(page.locator('body')).not.toBeEmpty();
  });

  test('both down — no white screen', async () => {
    await stopApi();

    await page.goto('/clients');

    // Not "something rendered" — the book rendered. With neither server up,
    // every one of these came out of the service worker's cache, and the page
    // says so rather than presenting it as a fresh read.
    await expect(
      page.getByText('Engine unreachable — showing last synced records'),
    ).toBeVisible();
    await expect(
      page.getByText('Cached copy — could not reach the engine to refresh.'),
    ).toBeVisible();
    await expect(page.getByRole('link', { name: /portfolio/ }).first()).toBeVisible();

    // Put the servers back for anything that follows, and for a developer who
    // runs this file on its own and wonders where their API went.
    await startWeb();
    await startApi();
  });
});

/**
 * The named regression, checked without a browser.
 *
 * `X-Quolin-From-Cache` is a bare string in two files that never import each
 * other. Everything above depends on them agreeing, and this says so in one
 * line when they stop.
 */
test('the cache marker is spelled the same in the worker and the client', () => {
  const here = path.resolve(__dirname, '..');
  const worker = readFileSync(path.join(here, 'public', 'sw.js'), 'utf8');
  const client = readFileSync(path.join(here, 'lib', 'api.ts'), 'utf8');

  const declared = worker.match(/const CACHE_MARK = '([^']+)'/);
  expect(declared, 'sw.js no longer declares CACHE_MARK').toBeTruthy();

  const marker = declared![1];
  expect(
    client.includes(`'${marker}'`),
    `lib/api.ts does not read '${marker}'. The app would present cached ` +
      'records as live, with a verified chain badge over them.',
  ).toBe(true);
});