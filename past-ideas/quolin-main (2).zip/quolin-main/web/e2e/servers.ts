/**
 * Start and stop the two servers the offline regression needs.
 *
 * The three failure modes are *processes being down*, so this stops processes.
 * The obvious shortcut — intercepting requests with `page.route` — does not
 * reach requests made by a service worker, which is the exact component under
 * test; a test built that way would pass against an app with no worker at all.
 *
 * Dedicated ports, away from 8000 and 3000, so a developer with `make api` and
 * `make web` running can execute this without their afternoon being killed
 * halfway through. 3100 is already in the API's default CORS list.
 */

import { spawn, type ChildProcess } from 'node:child_process';
import { createHash, createHmac } from 'node:crypto';
import { existsSync, mkdtempSync, openSync, readFileSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';

export const API_PORT = 8100;
export const WEB_PORT = 3100;
export const WEB_ORIGIN = `http://localhost:${WEB_PORT}`;
export const API_ORIGIN = `http://localhost:${API_PORT}`;

const ROOT = path.resolve(__dirname, '..', '..');

/**
 * The seeded operator.
 *
 * Signing in as this person used to be one POST. It is two since F8 put
 * `operator` into `MFA_REQUIRED_ROLES` — it is the role that produces evidence,
 * and a phished password was the whole credential — so the seed enrols an
 * authenticator for them and the form asks for a six-digit code. `signIn` below
 * walks both steps, which is what a real operator now does.
 */
export const OPERATOR = 'dana.whitfield@quolin.example';
export const PASSWORD =
  process.env.QUOLIN_SEED_PASSWORD || 'demo password not a real one';

/**
 * The seeded operator's authenticator secret.
 *
 * Derived rather than pasted, using the same function `api/seed/seed.py` uses —
 * `sha256("quolin-demo-totp:" + email)`, first 20 bytes, base32 — so that
 * changing the operator's address here cannot leave a stale literal behind. The
 * seed is the source of truth; this is the same arithmetic on the same input.
 *
 * Not a secret in any meaningful sense: it belongs to a demonstration account
 * in a database `make seed` drops and rebuilds.
 */
export function demoTotpSecret(email: string): string {
  const digest = createHash('sha256').update(`quolin-demo-totp:${email}`).digest();
  return base32(digest.subarray(0, 20));
}

/** RFC 4648 base32, no padding — the shape an authenticator app expects. */
function base32(input: Buffer): string {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = 0;
  let value = 0;
  let out = '';
  for (const byte of input) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += alphabet[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += alphabet[(value << (5 - bits)) & 31];
  return out;
}

/**
 * The six-digit code an authenticator app would be showing right now.
 *
 * RFC 6238 with the defaults every authenticator uses: SHA-1, thirty-second
 * steps, six digits.
 */
export function totpNow(secret: string, atSeconds?: number): string {
  const padded = secret.toUpperCase();
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = 0;
  let value = 0;
  const bytes: number[] = [];
  for (const char of padded.replace(/=+$/, '')) {
    const index = alphabet.indexOf(char);
    if (index < 0) continue;
    value = (value << 5) | index;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  const counter = Math.floor((atSeconds ?? Date.now() / 1000) / 30);
  const message = Buffer.alloc(8);
  message.writeUInt32BE(Math.floor(counter / 2 ** 32), 0);
  message.writeUInt32BE(counter >>> 0, 4);
  const digest = createHmac('sha1', Buffer.from(bytes)).update(message).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const code = digest.readUInt32BE(offset) & 0x7fffffff;
  return String(code % 1_000_000).padStart(6, '0');
}

const MASTER_KEY =
  process.env.QUOLIN_MASTER_KEY || 'cXVvbGluLWRldi1rZXktbm90LWEtc2VjcmV0LTAwMDE=';

let api: ChildProcess | null = null;
let web: ChildProcess | null = null;

/*
 * Both servers write to a log, and a failure to start prints its tail.
 *
 * The first run of this harness died on "the web server did not answer within
 * 120s" with the output sent to /dev/null — which is the same message whether
 * Next crashed on a syntax error, could not bind the port, or was simply still
 * compiling. `scripts/tunnel.sh` learned this already and dumps its log for the
 * same reason.
 */
const LOGS = mkdtempSync(path.join(os.tmpdir(), 'quolin-e2e-'));

function logFile(name: string): string {
  return path.join(LOGS, `${name}.log`);
}

function tail(name: string, lines = 25): string {
  try {
    return readFileSync(logFile(name), 'utf8').split('\n').slice(-lines).join('\n');
  } catch {
    return '(no output was captured)';
  }
}

function sink(name: string): [number, number] {
  const fd = openSync(logFile(name), 'a');
  return [fd, fd];
}

async function reachable(url: string): Promise<boolean> {
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(2000) });
    return res.ok;
  } catch {
    return false;
  }
}

async function waitFor(
  url: string,
  seconds: number,
  what: string,
  log: string,
): Promise<void> {
  for (let i = 0; i < seconds; i++) {
    if (await reachable(url)) return;
    await new Promise((r) => setTimeout(r, 1000));
  }
  throw new Error(
    `${what} did not answer on ${url} within ${seconds}s.\n` +
      `--- last lines of ${logFile(log)} ---\n${tail(log)}`,
  );
}

async function waitGone(url: string, seconds: number, what: string): Promise<void> {
  for (let i = 0; i < seconds * 2; i++) {
    if (!(await reachable(url))) return;
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(
    `${what} was still answering on ${url} after ${seconds}s. The test that ` +
      'follows would have proved nothing, so this fails here instead.',
  );
}

/**
 * Kill a process and everything it spawned.
 *
 * `next dev` runs its compiler in a child, and killing only the parent leaves
 * that child holding the port — which looks exactly like a server that refused
 * to stop. Spawned detached so there is a process group to signal.
 */
function stop(child: ChildProcess | null): void {
  if (!child || child.killed || child.pid === undefined) return;
  try {
    process.kill(-child.pid, 'SIGKILL');
  } catch {
    try {
      child.kill('SIGKILL');
    } catch {
      /* already gone */
    }
  }
}

export async function startApi(): Promise<void> {
  if (api) return;
  const venv = path.join(ROOT, 'api', '.venv', 'bin', 'python');
  if (!existsSync(venv)) {
    throw new Error(
      `No API virtualenv at ${venv}. Run \`make api\` once, or \`uv sync\` in api/.`,
    );
  }
  api = spawn(
    venv,
    ['-m', 'uvicorn', 'app.main:app', '--port', String(API_PORT), '--log-level', 'warning'],
    {
      cwd: path.join(ROOT, 'api'),
      detached: true,
      stdio: ['ignore', ...sink('api')],
      env: {
        ...process.env,
        QUOLIN_MASTER_KEY: MASTER_KEY,
        // WeasyPrint's native libraries, on a Mac with Homebrew. Harmless
        // elsewhere; without it the API will not import on this machine.
        DYLD_FALLBACK_LIBRARY_PATH: '/opt/homebrew/lib',
      },
    },
  );
  await waitFor(`${API_ORIGIN}/health`, 60, 'the API', 'api');
}

export async function stopApi(): Promise<void> {
  stop(api);
  api = null;
  await waitGone(`${API_ORIGIN}/health`, 15, 'the API');
}

/**
 * A production build, in its own output directory.
 *
 * Not `next dev`, for two reasons found by trying it. Next 16 refuses to start
 * a second dev server against one directory, so the harness could not run
 * beside a developer's `make web` — and a build sharing `.next` with a running
 * dev server is the same collision by another route. `NEXT_DIST_DIR` keeps this
 * run's output to itself.
 *
 * It is also the closer test. In development the worker registers as
 * `/sw.js?dev=1` and treats build assets as mutable; the deployed PWA does not,
 * and the deployed PWA is where somebody is standing in a lift with no signal.
 * The data path — network first, cache fallback, `X-Quolin-From-Cache` — is
 * identical either way, which is the part these tests are about.
 */
const DIST = '.next-e2e';

async function buildWeb(): Promise<void> {
  if (process.env.QUOLIN_E2E_SKIP_BUILD) return;
  await new Promise<void>((resolve, reject) => {
    const build = spawn('npm', ['run', 'build'], {
      cwd: path.join(ROOT, 'web'),
      stdio: ['ignore', ...sink('build')],
      env: { ...process.env, NEXT_DIST_DIR: DIST, NEXT_PUBLIC_API_BASE: API_ORIGIN },
    });
    build.on('exit', (code) =>
      code === 0
        ? resolve()
        : reject(
            new Error(
              `next build failed (exit ${code}).\n` +
                `--- last lines of ${logFile('build')} ---\n${tail('build', 40)}`,
            ),
          ),
    );
  });
}

export async function startWeb(): Promise<void> {
  if (web) return;
  await buildWeb();
  web = spawn('npx', ['next', 'start', '-p', String(WEB_PORT)], {
    cwd: path.join(ROOT, 'web'),
    detached: true,
    stdio: ['ignore', ...sink('web')],
    env: { ...process.env, NEXT_DIST_DIR: DIST, NEXT_PUBLIC_API_BASE: API_ORIGIN },
  });
  await waitFor(WEB_ORIGIN, 120, 'the web server', 'web');
}

export async function stopWeb(): Promise<void> {
  stop(web);
  web = null;
  await waitGone(WEB_ORIGIN, 15, 'the web server');
}

export async function stopAll(): Promise<void> {
  stop(api);
  stop(web);
  api = null;
  web = null;
}
