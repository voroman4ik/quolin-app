'use client';

/**
 * Whether this browser is signed in, and what to destroy when it is not.
 *
 * The session itself lives in an HttpOnly cookie, which this file cannot read
 * and deliberately never tries to. Nothing here is a security control — the
 * API decides, every time, and the only honest signal available to the client
 * is what the API last answered. This module exists so the UI can *react* to
 * that answer, not to make its own.
 *
 * The part that matters is `clearCachedData`. Quolin mirrors every successful
 * GET to localStorage so a previously visited screen still renders on dead
 * conference Wi-Fi. That cache is real client records — names, dates of birth,
 * portfolio values. Signing out has to take it with it, or "log out" means
 * "hide the screens and leave the data on the device", which is worse than not
 * offering logout at all.
 */

import { useEffect, useState } from 'react';

type Listener = (authed: boolean) => void;

// Starts null — "not asked yet" — which is a different state from "signed out"
// and must not render the login screen before the first answer arrives.
let authed: boolean | null = null;
const listeners = new Set<Listener>();

export function reportAuthenticated(value: boolean) {
  if (value === authed) return;
  authed = value;
  for (const fn of listeners) fn(value);
}

export function subscribeAuth(fn: Listener): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

export function useAuthState(): boolean | null {
  const [value, setValue] = useState<boolean | null>(authed);
  useEffect(() => {
    setValue(authed);
    return subscribeAuth(setValue);
  }, []);
  return value;
}

/**
 * Remove every cached record this device is holding.
 *
 * Called on logout and on any 401. The 401 case matters as much as the
 * deliberate one: a session that expired overnight leaves a laptop showing
 * cached client data to whoever opens the lid, and the expiry is exactly when
 * nobody is around to press a button.
 *
 * Scoped to the `quolin:` prefix rather than `localStorage.clear()` so it
 * cannot destroy something another app on the same origin put there.
 */
export function clearCachedData() {
  if (typeof window === 'undefined') return;
  try {
    const doomed: string[] = [];
    for (let i = 0; i < window.localStorage.length; i += 1) {
      const key = window.localStorage.key(i);
      if (key && key.startsWith('quolin:cache:')) doomed.push(key);
    }
    for (const key of doomed) window.localStorage.removeItem(key);
  } catch {
    /* private mode, quota, disabled storage — best effort by design */
  }

  /*
   * There are two caches, not one.
   *
   * The loop above clears the localStorage mirror. The service worker keeps a
   * second copy of the same API responses in a Cache Storage bucket that page
   * script cannot touch — only the worker can delete it — so it has to be
   * asked. Missing this would leave every cached client record on the device
   * after a sign-out that told the user they were gone.
   */
  try {
    navigator.serviceWorker?.controller?.postMessage({ type: 'quolin-purge-data' });
  } catch {
    /* no worker registered, or unsupported — the localStorage clear still ran */
  }
}
