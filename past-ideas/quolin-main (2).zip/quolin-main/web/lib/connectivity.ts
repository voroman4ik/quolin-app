/**
 * Whether the decision engine is currently reachable.
 *
 * `navigator.onLine` cannot answer this. It reports whether the device has any
 * network interface at all, so it stays true on a captive portal, on hotel
 * Wi-Fi that has stopped forwarding, and — the case that matters here — when
 * the browser is perfectly online but the API process is down. The only honest
 * signal is whether our own last request actually reached the engine.
 *
 * Every GET reports its outcome here; the banner reflects the most recent one.
 */

import { useEffect, useState } from 'react';

type Listener = (reachable: boolean) => void;

let reachable = true;
const listeners = new Set<Listener>();

export function reportEngineReachable(value: boolean) {
  if (value === reachable) return;
  reachable = value;
  for (const fn of listeners) fn(reachable);
}

export function isEngineReachable(): boolean {
  return reachable;
}

export function subscribeEngineReachable(fn: Listener): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

/**
 * For controls that need a live engine — evaluate, replay, override, artefact
 * generation. These are POSTs and cannot be served from cache, so offering them
 * while the engine is unreachable promises something the app cannot do.
 *
 * Starts optimistic: the first render should not disable a control before any
 * request has had the chance to prove the engine is gone.
 */
export function useEngineReachable(): boolean {
  const [reachable, setReachable] = useState(true);
  useEffect(() => {
    setReachable(isEngineReachable());
    return subscribeEngineReachable(setReachable);
  }, []);
  return reachable;
}
