/**
 * Display formatters.
 *
 * There are no floats anywhere in this system: money is integer cents and
 * concentration is integer basis points. Every helper below does integer
 * arithmetic and formats to a string — never parse these back into numbers
 * for further maths.
 */

/** 857 bps -> "8.57%" */
export function formatBps(bps: number): string {
  const sign = bps < 0 ? '-' : '';
  const abs = Math.abs(Math.trunc(bps));
  const whole = Math.trunc(abs / 100);
  const frac = abs % 100;
  return `${sign}${whole}.${String(frac).padStart(2, '0')}%`;
}

/** 14000000 cents -> "$140,000" */
export function formatCents(cents: number, withCents = false): string {
  const neg = cents < 0;
  const abs = Math.abs(Math.trunc(cents));
  const dollars = Math.trunc(abs / 100);
  const rem = abs % 100;
  const body = dollars.toLocaleString('en-AU');
  const tail = withCents ? `.${String(rem).padStart(2, '0')}` : '';
  return `${neg ? '-' : ''}$${body}${tail}`;
}

/** Compact money for dense rows: "$1.25m", "$140k". */
export function formatCentsCompact(cents: number): string {
  const abs = Math.abs(Math.trunc(cents));
  const dollars = Math.trunc(abs / 100);
  const sign = cents < 0 ? '-' : '';
  if (dollars >= 1_000_000) {
    const hundredths = Math.trunc(dollars / 10_000);
    return `${sign}$${Math.trunc(hundredths / 100)}.${String(hundredths % 100).padStart(2, '0')}m`;
  }
  if (dollars >= 1_000) return `${sign}$${Math.trunc(dollars / 1_000)}k`;
  return `${sign}$${dollars.toLocaleString('en-AU')}`;
}

/** "2025-11-14" -> "14 Nov 2025" */
export function formatDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  const d = new Date(iso.length <= 10 ? `${iso}T00:00:00Z` : iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    timeZone: 'UTC',
  });
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${formatDate(iso)} · ${d.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'UTC',
  })} UTC`;
}

/** Shorten a 64-char hash for display: "fed187a2…9ad9f231" */
export function shortHash(hash: string | null | undefined, head = 8, tail = 8): string {
  if (!hash) return '—';
  if (hash.length <= head + tail + 1) return hash;
  return `${hash.slice(0, head)}…${hash.slice(-tail)}`;
}

/** REASON_CODE / field.ref -> readable label, without inventing rule text. */
export function humanizeRef(ref: string): string {
  return ref
    .replace(/\[(.+)\]$/, ' [$1]')
    .replace(/_/g, ' ')
    .replace(/\./g, ' · ');
}

export function humanizeCode(code: string): string {
  return code
    .toLowerCase()
    .replace(/_/g, ' ')
    .replace(/^\w/, (c) => c.toUpperCase());
}

/**
 * Render a provenance value for display. Values arrive as ints, bools or
 * strings; bps and cents refs get unit-aware formatting.
 */
export function formatProvenanceValue(ref: string, value: unknown): string {
  if (value === null || value === undefined) return '—';
  if (typeof value === 'boolean') return value ? 'Yes' : 'No';
  if (typeof value === 'number') {
    if (/_bps$/.test(ref)) return formatBps(value);
    if (/_cents$/.test(ref)) return formatCents(value);
    return String(value);
  }
  if (Array.isArray(value)) return value.length ? value.join(', ') : 'none';
  if (typeof value === 'object') return JSON.stringify(value);
  return String(value);
}

export function bandLabel(band: number): string {
  return `Band ${band}`;
}

/**
 * A cross-border constraint's magnitude, in the unit its own pack declared.
 *
 * The unit comes from the pack, never from a guess about the number: $2,000 and
 * 2% are both "200" in the wrong hands, and the whole point of the panel below
 * this is that a share of a portfolio and a cash sum are not the same kind of
 * thing. An unrecognised scale prints the raw value beside its name rather than
 * being coerced into a unit nobody declared.
 */
export function formatMagnitude(value: number | string | null, scale: string): string {
  // A qualitative constraint has nothing to put in a column of numbers, and the
  // dash is the table convention for that. The words "no magnitude" sat in the
  // value column reading like a failed render of a value that should be there,
  // and the card's rationale has already said why the quantity does not exist.
  if (value === null || value === undefined) return '—';
  if (typeof value === 'number') {
    if (scale === 'cents') return formatCents(value);
    if (scale === 'bps') return formatBps(value);
    if (scale === 'band') return bandLabel(value);
    if (scale === 'days') return `${value} day${value === 1 ? '' : 's'}`;
    if (scale === 'years') return `${value} year${value === 1 ? '' : 's'}`;
  }
  return `${value} ${scale}`;
}

/** `first_exposure_limit` -> `First exposure limit`. */
export function humanizeDimension(dimension: string): string {
  return dimension.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
}
