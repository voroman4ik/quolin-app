export type Outcome = 'ALLOW' | 'BLOCK' | 'REFER';

export type ScenarioId = 'meridian' | 'sterling';

/**
 * How far a pack's rule content can be trusted.
 *
 * `ILLUSTRATIVE` content exercises the architecture and nobody has reviewed a
 * threshold in it. Anything rendered from such a pack carries a badge that
 * cannot be dismissed — showing unreviewed regulatory content as though it were
 * verified is the fastest way to lose a room. A missing value is treated as the
 * weakest claim, never the strongest.
 */
export type ContentStatus = 'REVIEWED' | 'PENDING_REVIEW' | 'ILLUSTRATIVE';

/** Which of the three frozen facts pulled a regime into a determination. */
export type JurisdictionBasis = 'licensee' | 'residency' | 'domicile';

export interface Scenario {
  id: ScenarioId;
  name: string;
  kind: string;
  blurb: string;
  artefact_kind: ArtefactKind;
}

export type ArtefactKind = 'tmd' | 'evidence_pack';

export interface Health {
  status: string;
  /** Packs loaded, not decisions. /health is public, and a decision count is a
   *  tenant's data — see the endpoint's own note. */
  packs: number;
}

export interface ChainState {
  verified: boolean;
  /** Whose chain this is. There is one per customer, each starting at its own
   *  recorded anchor rather than at a shared constant. */
  tenant_id: string;
  genesis_hash: string;
  checked: number;
  tip_hash: string;
}

export interface PendingItem {
  decision_id: number;
  client_id: string;
  client_name: string;
  asset_id: string;
  as_of: string;
  reason_codes: string[];
}

export interface Dashboard {
  scenario: ScenarioId;
  decisions_today: number;
  decisions_total: number;
  refers_pending: number;
  overrides_this_month: number;
  blocks_total: number;
  allows_total: number;
  chain: ChainState;
  pending: PendingItem[];
}

export interface ClientSummary {
  id: string;
  name: string;
  scenario: ScenarioId;
  loss_capacity_band: number;
  vulnerability_flag: boolean;
  knowledge_assessed: boolean;
  assessable_portfolio_cents: number;
  note: string;
}

/** A regime in play for a client, before any trade is proposed. */
export interface ApplicableJurisdiction {
  jurisdiction: string;
  pack_version: number;
  content_status: ContentStatus;
  covers_states: string[];
  basis: JurisdictionBasis[];
  governing: boolean;
}

export interface Holding {
  asset_id: string;
  value_cents: number;
}

export interface DecisionSummary {
  id: number;
  client_id?: string;
  client_name?: string;
  asset_id: string;
  outcome: Outcome;
  as_of: string;
  pack_version: number;
  created_at: string;
}

export interface ClientDetail extends ClientSummary {
  dob: string;
  client_category: string;
  knowledge_date: string | null;
  prior_crypto_purchases: number;
  structural_acks: string[];
  default_trade_amount_cents: number;
  positions: { crypto_value_cents: number; holdings: Holding[] };
  /**
   * Whether custody holds a record for this client at all. Zero holdings and no
   * record produce identical figures and mean different things: the first makes
   * an exposure of 0% true, the second makes it fabricated. Imported clients are
   * always the second kind.
   */
  custody_on_file: boolean;
  exposure_bps: number;
  concentration_cap_bps: number;
  pack_version: number;
  pack_content_status: ContentStatus;
  /** The licence the advice is given under — a fact about the firm. */
  jurisdiction: string;
  /** Facts about the client, and what pulls a second regulator in. */
  residency: string;
  domicile: string;
  cross_border: boolean;
  applicable_jurisdictions: ApplicableJurisdiction[];
  /** Codes that apply and that Quolin holds no pack for. Shown, never dropped. */
  jurisdictions_without_packs: string[];
  decisions: DecisionSummary[];
}

/* integrations and import */

/** live = the real thing; fixture = a file stands in; local = real but not reaching out. */
export type IntegrationStatus = 'live' | 'fixture' | 'local';

export interface IntegrationEdge {
  id: string;
  name: string;
  stands_for: string;
  implementation: string;
  status: IntegrationStatus;
  detail: string;
  /** What believing this mock would cost a reader. Only where there is a cost. */
  consequence?: string;
  clients_without_records?: number;
  how_data_gets_in: string;
  replaced_by: string | null;
}

export interface IntegrationSummary {
  edges: IntegrationEdge[];
  live: number;
  mocked: number;
  statement: string;
}

export interface ImportRowError {
  row: number;
  column: string;
  message: string;
}

export interface ImportResult {
  ok: boolean;
  committed: boolean;
  total_rows: number;
  valid_rows: number;
  rejected_rows: number;
  new_clients: number;
  updated_clients: number;
  errors: ImportRowError[];
  new_ids: string[];
  updated_ids: string[];
  custody_warning: string;
}

export interface Asset {
  id: string;
  symbol: string;
  name: string;
  class: string;
  volatility_band: number;
  leverage: boolean;
  structural_flags: string[];
}

/** A provenance entry: what the engine read, or the threshold it compared against. */
export interface Provenance {
  kind: string;
  ref: string;
  value: unknown;
}

export interface RuleResult {
  rule_id: string;
  title: string;
  passed: boolean;
  outcome: Outcome;
  reason_code: string | null;
  severity: number;
  inputs_read: Provenance[];
  thresholds_used: Provenance[];
}

export interface Reason extends RuleResult {
  reason_title: string;
  reason_plain_english: string;
  /**
   * Which regime raised this finding. Present only on a cross-border
   * determination, where the findings are the union across every applicable
   * regime and "whose rule is this?" is the first thing a reader needs.
   */
  jurisdiction?: string;
  jurisdiction_name?: string;
  pack_version?: number;
}

export interface Snapshot {
  as_of: string;
  client: Record<string, unknown>;
  asset: Record<string, unknown>;
  trade: { amount_cents: number };
  calc: Record<string, number>;
}

export interface Override {
  justification: string;
  approver: string;
  created_at: string;
}

/* --------------------------- cross-border ----------------------------- */

/** One regime's constraint on one dimension, as the resolver read it. */
export interface ConstraintEntry {
  jurisdiction: string;
  pack_version: number;
  rule_id: string;
  title: string;
  /** The unit the magnitude is in: `cents`, `bps`, `band`, `days`, `years`… */
  scale: string;
  /** Null when the constraint has no magnitude, or none that would resolve. */
  magnitude: number | string | null;
  passed: boolean;
  outcome: Outcome;
  reason_code: string | null;
}

/**
 * Why an ordering was not possible. `no_common_scale` means the constraints are
 * measured in different units — a share of a portfolio against a cash sum — and
 * `scale_not_orderable` means the governing pack's precedence block states no
 * direction for the scale, or a magnitude would not resolve. Both produce the
 * same honest answer: every failing constraint binds, and nothing was ranked.
 */
export type UnorderableReason =
  | 'no_common_scale'
  | 'scale_not_orderable'
  | 'single_constraint';

export interface ResolvedDimension {
  dimension: string;
  orderable: boolean;
  ordering: 'lower_is_stricter' | 'higher_is_stricter' | 'none';
  reason: UnorderableReason | null;
  scales: string[];
  direction: 'lower_is_stricter' | 'higher_is_stricter' | null;
  binding: ConstraintEntry[];
  evaluated_not_binding: ConstraintEntry[];
  rationale: string;
}

export interface Resolution {
  outcome: Outcome;
  /** What each regime would have determined on its own. */
  outcome_by_jurisdiction: Record<string, Outcome>;
  governing: { jurisdiction: string; pack_version: number };
  /** Whose precedence block did the ordering, and the note saying so. */
  precedence_source: { jurisdiction: string; pack_version: number; note: string };
  dimensions: ResolvedDimension[];
  rules_not_applicable: {
    jurisdiction: string;
    rule_id: string;
    dimension: string | null;
    title: string;
    note?: string;
  }[];
  unordered_dimensions: string[];
  illustrative: string[];
  requested: string[];
  applicable: ApplicableJurisdiction[];
  unmatched: string[];
}

/**
 * A regime that touched a decision, and what it said on its own.
 *
 * Assembled for display and deliberately outside the hash: names are pack
 * content, and a regulator renaming itself must not disturb a record that has
 * to stay fixed for as long as the decision does.
 */
export interface DecisionJurisdiction {
  jurisdiction: string;
  name: string;
  regulator: string;
  pack_version: number;
  content_status: ContentStatus;
  signed_by: string;
  covers_states: string[];
  governing: boolean;
  basis: JurisdictionBasis[];
  outcome: Outcome;
  reasons: Reason[];
}

export interface Decision {
  id: number;
  client_id: string;
  client_name: string;
  asset_id: string;
  asset_symbol: string;
  as_of: string;
  outcome: Outcome;
  pack_id: string;
  pack_version: number;
  pack_effective_from: string;
  pack_signed_by: string;
  pack_content_status: ContentStatus;
  pack_covers_states: string[];
  pack_jurisdiction_name: string;
  pack_regulator: string;
  /** Whether the governing pack's content is unreviewed. Drives the badge. */
  illustrative: boolean;
  /** Every regime on this decision whose content is unreviewed, not just the
   *  governing one: a determination is only as reviewed as its weakest input. */
  illustrative_jurisdictions: string[];
  cross_border: boolean;
  resolution: Resolution | null;
  jurisdictions: DecisionJurisdiction[];
  snapshot: Snapshot;
  reasons: Reason[];
  rule_results: RuleResult[];
  rules_not_applicable: string[];
  prev_hash: string | null;
  /** First decision in this customer's chain — its predecessor is the anchor.
   *  Comes from the API because a chain now starts at a recorded per-tenant
   *  hash, which is indistinguishable from any other hash from out here. */
  is_genesis: boolean;
  this_hash: string;
  created_at: string;
  override: Override | null;
}

export interface ReplayResult {
  match: boolean;
  pack_version: number;
  stored_outcome: Outcome;
  replayed_outcome: Outcome;
  differences: unknown[];
  chain: ChainState;
}

export interface Artefact {
  id: number;
  kind: ArtefactKind;
  title: string;
  template_version: string;
  download_url: string;
  created_at: string;
}

export interface QueueItem extends PendingItem {
  pack_version: number;
  resolved: boolean;
  approver: string | null;
}

/* ------------------------------ reporting ----------------------------- */

/** Period documents are aggregates, not determinations. Kept separate from
 *  ArtefactKind so a period kind can never be posted to /artefacts/{kind}. */
export type ReportKind = 'regulatory_return' | 'override_report';

export interface ReportPeriod {
  period: string;
  label: string;
  decisions: number;
}

export interface PackInForce {
  pack_id: string;
  version: number;
  effective_from: string;
  effective_to: string | null;
  signed_by: string;
  decisions: number;
}

interface ReportBase {
  jurisdiction: string;
  period: string;
  period_label: string;
  period_start: string;
  period_end: string;
  /** What the period filters on — differs between the two documents. */
  scope_basis: string;
  scenario: string | null;
  packs_in_force: PackInForce[];
  chain: ChainState;
}

export interface ReturnPreview extends ReportBase {
  kind: 'regulatory_return';
  decisions_total: number;
  clients_assessed: number;
  outcomes: { outcome: Outcome; count: number }[];
  by_asset: { symbol: string; count: number }[];
  findings: { rule_id: string; reason_code: string; title: string; count: number }[];
  overrides_total: number;
}

export interface OverrideEntry {
  override_id: number;
  decision_id: number;
  client_id: string;
  client_name: string;
  asset_symbol: string;
  as_of: string;
  outcome: Outcome;
  pack_version: number;
  approver: string;
  justification: string;
  recorded_at: string;
  findings: { rule_id: string; reason_code: string; title: string }[];
}

export interface OverridePreview extends ReportBase {
  kind: 'override_report';
  overrides_total: number;
  by_outcome: { outcome: Outcome; count: number }[];
  by_approver: { approver: string; count: number }[];
  entries: OverrideEntry[];
}

export type ReportPreview = ReturnPreview | OverridePreview;

export interface ReportArtefact extends Omit<Artefact, 'kind'> {
  kind: ReportKind;
  period: string;
}

export interface PackRuleRef {
  rule_id: string;
  title: string;
  on_fail: Outcome;
  reason_code: string;
  severity?: number;
}

export interface PackVersion {
  version: number;
  effective_from: string;
  effective_to: string | null;
  signed_by: string;
  signed_at: string;
  /** Per version: content is reviewed one version at a time. */
  content_status: ContentStatus;
  notes: string;
  rule_count: number;
  thresholds: Record<string, unknown>;
  rules: PackRuleRef[];
}

/** One regime on the shelf. The list is the architectural claim, made countable. */
export interface PackShelfEntry {
  jurisdiction: string;
  /** Named from pack content — the UI holds no map of codes to regulators. */
  name: string;
  regulator: string;
  current_version: number | null;
  versions: number;
  content_status: ContentStatus;
  covers_states: string[];
  signed_by: string;
  /** Decisions this regime's pack governed. */
  decisions_governed: number;
  /** Decisions it was evaluated on, governing or not. Never smaller. */
  decisions_considered: number;
}

export interface PackDiff {
  from_version: number;
  to_version: number;
  thresholds_changed: { name: string; from: unknown; to: unknown }[];
  thresholds_added: { name: string; to: unknown }[];
  rules_added: PackRuleRef[];
  rules_removed: PackRuleRef[];
  rules_modified: PackRuleRef[];
}

export interface PackView {
  jurisdiction: string;
  name: string;
  regulator: string;
  current_version: number;
  content_status: ContentStatus;
  covers_states: string[];
  versions: PackVersion[];
  diffs: PackDiff[];
}

/* ------------------------------------------------------------------ *
 * Regulatory currency.
 *
 * The types below describe monitoring, not determination. Nothing here is
 * ever an input to a decision — a watch item becomes rule content only by
 * being written into a draft and signed, and the draft types say so.
 * ------------------------------------------------------------------ */

/** Derived from `last_checked_at` and the pack's declared cadence, never stored. */
export type Freshness = 'CURRENT' | 'MANUAL' | 'DUE' | 'STALE';

/** Whether a machine can read this source at all. */
export type PollingStatus = 'AUTOMATIC' | 'MANUAL';

/** How a poll was performed. `live` is not implemented and does not fall back. */
export type WatchMode = 'replay' | 'live';

export type TriageTier = 'TOUCHES_RULE_CONTENT' | 'IN_SCOPE' | 'UNMATCHED';

export type WatchStatus = 'new' | 'reviewing' | 'dismissed' | 'actioned';

/**
 * The states a piece of rule content moves through.
 *
 * Six rather than the five the execution document lists, and the extra one is
 * the separation of duties: `signed` is attested and `published` is scheduled,
 * because a signatory putting their own signature into force is one person
 * agreeing with themselves. `effective` is in force; `superseded` is what
 * decisions were made under before the change; `rejected` is the record that
 * somebody looked and said no.
 *
 * Kept in step with `app/watch/lifecycle.py`, which owns the transition table.
 */
export type DraftStatus =
  | 'draft'
  | 'in_review'
  | 'signed'
  | 'published'
  | 'effective'
  | 'superseded'
  | 'rejected';

export interface WatchSource {
  id: string;
  jurisdiction: string;
  name: string;
  url: string;
  cadence_days: number;
  last_checked_at: string | null;
  last_mode: string;
  enabled: boolean;
  freshness: Freshness;
  polling_status?: PollingStatus;
  fetcher?: string;
  days_overdue: number | null;
  /** The specialist paged when this source stops answering. Pack content. */
  owner: string;
  consecutive_failures: number;
  alert_after_failures: number;
  last_error: string;
  last_failed_at: string | null;
  /**
   * At or past its own threshold: the publisher is not answering, which is a
   * different fact from nobody having got to it. Late is us; unreachable is
   * them, and a customer asking why their regime is stale deserves the right
   * answer.
   */
  breaching: boolean;
}

/** One vocabulary hit, and the pack content the pack itself says it touches. */
export interface WatchMatch {
  term: string;
  touches: string[];
}

export interface WatchEvent {
  id: number;
  source_id: string;
  jurisdiction: string;
  title: string;
  summary: string;
  url: string;
  published_at: string;
  observed_at: string | null;
  tier: TriageTier;
  tier_label: string;
  /** Why this is where it is. Never a score — see api/app/watch/triage.py. */
  matched: WatchMatch[];
  touches: string[];
  status: WatchStatus;
  note: string;
}

export interface WatchQueue {
  mode: WatchMode;
  tiers: { id: TriageTier; label: string; explanation: string }[];
  events: WatchEvent[];
}

export interface PackDraft {
  id: number;
  jurisdiction: string;
  base_version: number;
  proposed_version: number;
  effective_from: string;
  days_until_effective: number;
  title: string;
  rationale: string;
  event_ids: number[];
  status: DraftStatus;
  created_at: string | null;
  signed_by: string;
  signed_at: string | null;
  signature_note: string;
  published_pack_id: number | null;
  /** True only once published. The screen never infers this from a signature. */
  is_live: boolean;
  /**
   * F1. The hash of the body **this response carried**, for a client that is
   * about to act on what it displayed.
   *
   * Every attestation route sends it back, under the name that route uses:
   * `reviewed_content_hash` on a second review, `signed_content_hash` on a
   * signature, `approved_content_hash` on a publication approval and
   * `published_content_hash` on a publication. In each case the server refuses
   * if the draft has moved since — which closes the window between reading a
   * draft and acting on it, where its author, who holds `operator`, can edit it.
   *
   * Not `content_hash`: that name is taken, and it means the bytes that were
   * *signed* (see `DraftHistory`). Two hashes of two different bodies under one
   * name on one screen is how a client sends the wrong one.
   *
   * The signing screen sends it (`api.signDraft`). There is still no
   * second-review or publication screen in this client; the routes exist and
   * `api.publishDraft` takes the value, so a screen that gets built binds to
   * this field rather than discovering it.
   */
  current_content_hash: string;
}

export interface PackDraftDetail extends PackDraft {
  delta: PackDiff | { unavailable: string };
  body?: Record<string, unknown>;
  events?: {
    id: number;
    title: string;
    url: string;
    published_at: string;
    tier: TriageTier;
    jurisdiction: string;
  }[];
}

export interface PendingPack {
  jurisdiction: string;
  jurisdiction_name: string;
  version: number;
  effective_from: string;
  days_until_effective: number;
  content_status: ContentStatus;
  signed_by: string;
  notes: string;
}

export interface CurrencyJurisdiction {
  jurisdiction: string;
  jurisdiction_name: string;
  regulator: string;
  version: number;
  effective_from: string;
  content_status: ContentStatus;
  signed_by: string;
  /** False when the pack declares no sources. Unmonitored, not up to date. */
  watched: boolean;
  vocabulary_terms: number;
  sources: WatchSource[];
  /** Sources that have stopped answering, as distinct from ones nobody has
   *  got to yet. */
  unreachable: { id: string; name: string; consecutive_failures: number; reason: string }[];
  freshness: Freshness;
  open_items: number;
  open_by_tier: Partial<Record<TriageTier, number>>;
  last_checked_at: string | null;
}

export interface CurrencyOverview {
  as_of: string;
  checked_at: string;
  mode: WatchMode;
  mode_note: string;
  freshness: Freshness;
  jurisdictions: CurrencyJurisdiction[];
  /**
   * The regimes this answer covers, or null when it covers every regime we hold
   * a pack for. Null is not the same as an empty list: a customer who has not
   * told us where they are licensed sees everything, because a screen reporting
   * perfect currency while watching nothing is the worst answer available.
   */
  regimes: string[] | null;
  /** How many sources across those regimes have stopped answering. */
  unreachable: number;
  open_items: number;
  open_by_tier: Partial<Record<TriageTier, number>>;
  pending_packs: PendingPack[];
  drafts_awaiting_signature: PackDraft[];
  drafts_signed_not_published: PackDraft[];
  uncovered: { jurisdiction: string; events: number }[];
  statement: string;
}

export interface PollResult {
  mode: WatchMode;
  sources_checked: number;
  new_events: number;
  already_seen: number;
  by_tier: Partial<Record<TriageTier, number>>;
}


/**
 * One edit from the workbench: whole sections, never a patch.
 *
 * A specialist editing thresholds is replacing a table rather than applying a
 * diff to one, and a patch format would put a second representation of the
 * content between what they see and what gets signed.
 *
 * Every field optional so a save can carry only the section somebody touched.
 * Omitted means "leave it alone" — clearing a pack's thresholds is a thing to
 * do deliberately, not by leaving out a key.
 */
export interface DraftEdit {
  thresholds?: Record<string, unknown>;
  rules?: unknown[];
  reason_codes?: Record<string, unknown>;
  notes?: string;
}

/** One move of a draft from one state to another, and who made it. */
export interface DraftTransition {
  from: string | null;
  to: string;
  at: string;
  by: string | null;
  note: string;
}

export interface DraftHistory {
  draft_id: number;
  status: string;
  content_hash: string | null;
  transitions: DraftTransition[];
}

/**
 * What a rule says about where its content came from.
 *
 * Four structured fields because they are queried — "which rules have not been
 * verified since the amendment" should be a search — plus a note, because a
 * specialist will always have one more thing to say.
 */
export interface RuleProvenance {
  source_document: string;
  section: string;
  verified_by: string;
  verified_on: string;
  note?: string;
}


/** A pack version staged for this tenant, and how long they have to look. */
export interface StagedAdvance {
  id: string;
  jurisdiction: string;
  pack_version: number;
  policy: string;
  noticed_at: string;
  window_closes_at: string | null;
  days_left: number | null;
  /**
   * Past the deadline and still not taken.
   *
   * Deliberately not "applied automatically". The deadline is a prompt — a
   * version that applied itself because nobody clicked would be pinning in name
   * only, and pinning is the whole answer to "how do you control vendor
   * changes?".
   */
  overdue: boolean;
  note: string;
}

export interface AdvanceState {
  policy: 'auto' | 'pinned' | string;
  uat_window_days: number;
  pending: StagedAdvance[];
}
