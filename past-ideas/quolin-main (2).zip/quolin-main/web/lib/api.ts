import type {
  Artefact,
  ArtefactKind,
  Asset,
  ClientDetail,
  ClientSummary,
  CurrencyOverview,
  Dashboard,
  Decision,
  DecisionSummary,
  Health,
  ImportResult,
  IntegrationSummary,
  PackDraft,
  AdvanceState,
  DraftEdit,
  DraftHistory,
  PackDraftDetail,
  PackShelfEntry,
  PackView,
  PollResult,
  QueueItem,
  ReplayResult,
  ReportArtefact,
  ReportKind,
  ReportPeriod,
  ReportPreview,
  Scenario,
  ScenarioId,
  WatchQueue,
  WatchStatus,
} from './types';
import { reportEngineReachable } from './connectivity';
import { clearCachedData, reportAuthenticated } from './auth';

export const API_BASE =
  process.env.NEXT_PUBLIC_API_BASE?.replace(/\/$/, '') || 'http://localhost:8000';

/** Absolute URL for an API path (also used for artefact download_url values). */
export function apiUrl(path: string): string {
  return path.startsWith('http') ? path : `${API_BASE}${path}`;
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

/**
 * What `/auth/session` answers.
 *
 * Everything past `authenticated` is absent when the answer is no, which is why
 * it is optional rather than nullable: a signed-out response carries one field,
 * not a shape full of nulls describing a person who is not there.
 */
export interface SessionState {
  authenticated: boolean;
  since?: string;
  expires?: string;
  user?: { email: string; display_name: string };
  roles?: string[];
  /** Whether an action demanding a freshly presented credential would go through now. */
  credential_fresh?: boolean;
  /**
   * How long a presented credential is accepted for. FP3-12(c).
   *
   * Read from the session rather than written here, because it is an
   * environment variable on the engine and a number duplicated in the client
   * is a number that stops being true without anybody noticing.
   */
  credential_fresh_minutes?: number;
  mfa_satisfied?: boolean;
  /**
   * This session may enrol a second factor and do nothing else. FP3-12(a).
   *
   * Answered by the engine from the same check its middleware enforces with.
   * The client deliberately holds no copy of `MFA_REQUIRED_ROLES`: a duplicated
   * policy list drifts, and it drifts towards a privileged account seeing 403s
   * on every screen with nothing offering a way out.
   */
  mfa_required?: boolean;
}

/**
 * The password was right and a second factor is still owed.
 *
 * A distinct type rather than a status code the caller has to interpret,
 * because the sign-in form has to do something quite different with it: keep
 * what was typed, show the code field, and not present it as a failure. It is
 * still a 401 on the wire — nothing has been granted yet.
 */
export class MfaRequired extends ApiError {
  constructor(message: string) {
    super(message, 401);
    this.name = 'MfaRequired';
  }
}

/**
 * The session is live and the credential behind it has gone stale.
 *
 * FP3-12. This is a 401 on the wire and it is **not** a sign-out. Signing rule
 * content, publishing it, overriding a determination and provisioning access
 * all demand a credential presented in the last few minutes — and the previous
 * client treated every 401 identically: destroy the cache, show the lock
 * screen. So a signatory who read a draft for six minutes and pressed Sign lost
 * the draft, the cache and the session, and the two-person controls became a
 * race against a timer.
 *
 * A distinct type, for the same reason `MfaRequired` is one: the caller has to
 * do something completely different with it. `X-Quolin-Reauth: required` is how
 * the engine says which kind of 401 this is, and it is in `expose_headers` —
 * without that a cross-origin client reads `null` and cannot tell them apart,
 * which is exactly the defect the 27 August entry records for `X-Quolin-MFA`.
 */
export class ReauthRequired extends ApiError {
  constructor(message: string) {
    super(message, 401);
    this.name = 'ReauthRequired';
  }
}

/**
 * FastAPI returns validation failures as {detail: [{msg, loc}]} and other
 * failures as {detail: "..."}. Never let either shape reach the screen raw.
 */
async function toApiError(res: Response): Promise<ApiError> {
  let message = `Request failed (${res.status})`;
  try {
    const body = await res.json();
    const detail = body?.detail;
    if (typeof detail === 'string') {
      message = detail;
    } else if (Array.isArray(detail) && detail.length) {
      message = detail
        .map((d: { msg?: string; loc?: (string | number)[] }) => {
          const field = Array.isArray(d.loc) ? d.loc[d.loc.length - 1] : undefined;
          const msg = (d.msg || 'Invalid value').replace(/^Value error, /, '');
          return field && field !== 'body' ? `${field}: ${msg}` : msg;
        })
        .join('. ');
    }
  } catch {
    /* non-JSON body — keep the generic message */
  }
  return new ApiError(message, res.status);
}

/* ------------------------------------------------------------------ *
 * Offline cache.
 * Every successful GET is mirrored to localStorage. When the network is
 * unavailable the cached copy is served instead, so a previously visited
 * screen still renders on a dead conference Wi-Fi.
 * ------------------------------------------------------------------ */

const CACHE_PREFIX = 'quolin:cache:';

export function readCache<T>(key: string): T | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(CACHE_PREFIX + key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

function writeCache(key: string, value: unknown) {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(CACHE_PREFIX + key, JSON.stringify(value));
  } catch {
    /* quota exceeded — cache is best-effort */
  }
}

export interface Fetched<T> {
  data: T;
  /** True when the network failed and this came from the offline cache. */
  stale: boolean;
}

/**
 * A 401 means the session is gone — expired, revoked, or never established.
 *
 * Two things have to happen, in this order. The cached records are destroyed
 * first, because the alternative is a device still holding client data after
 * the server stopped recognising it. Only then is the UI told to show the
 * login screen.
 *
 * Called from both fetch paths. A 401 on a POST is the more likely one in
 * practice — a demo sits idle on a read-only screen and then someone taps
 * Check — so handling it only on GET would put the login screen up at the
 * least helpful possible moment.
 */
function handleUnauthorized() {
  clearCachedData();
  reportAuthenticated(false);
}

/**
 * Which kind of 401 this is, and what to do about it.
 *
 * FP3-12. Returns an error to throw when the session is genuinely gone, and
 * `null` when the credential is merely stale — in which case nothing is
 * cleared, nobody is signed out, and the caller is expected to raise a
 * `ReauthRequired` instead.
 *
 * The header is the mechanism, not a hint about it. A stale credential and a
 * dead session are indistinguishable from the status code alone, and treating
 * them the same is what made every signature a race.
 */
function isStaleCredential(res: Response): boolean {
  return res.headers.get('X-Quolin-Reauth') === 'required';
}

export async function getJson<T>(path: string): Promise<Fetched<T>> {
  try {
    const res = await fetch(apiUrl(path), {
      headers: { Accept: 'application/json' },
      cache: 'no-store',
      // The session cookie is on the API's origin, not this page's. Without
      // this the browser sends nothing and every request is anonymous.
      credentials: 'include',
    });
    if (res.status === 401) {
      if (isStaleCredential(res)) {
        throw new ReauthRequired((await toApiError(res)).message);
      }
      handleUnauthorized();
    }
    if (!res.ok) throw await toApiError(res);
    const data = (await res.json()) as T;

    /*
     * A 200 does not mean we reached the engine: the service worker answers
     * from its own cache when the network fails, and stamps the response when
     * it does. Treating that as live is how a screen ends up asserting "chain
     * verified" against figures nobody verified.
     */
    const fromCache = res.headers.get('X-Quolin-From-Cache') === 'hit';
    reportEngineReachable(!fromCache);
    if (!fromCache) writeCache(path, data);
    return { data, stale: fromCache };
  } catch (err) {
    if (err instanceof ApiError) {
      // The engine answered, it just refused this request.
      reportEngineReachable(true);
      throw err;
    }
    reportEngineReachable(false);
    const cached = readCache<T>(path);
    if (cached !== null) return { data: cached, stale: true };
    throw new ApiError(
      'Cannot reach the decision engine. Check that the API is running.',
      0,
    );
  }
}

export async function postJson<T>(path: string, body: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(apiUrl(path), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body ?? {}),
      credentials: 'include',
    });
  } catch {
    reportEngineReachable(false);
    throw new ApiError(
      'Cannot reach the decision engine. This action needs a connection.',
      0,
    );
  }
  reportEngineReachable(true);
  if (res.status === 401) {
    if (isStaleCredential(res)) {
      throw new ReauthRequired((await toApiError(res)).message);
    }
    handleUnauthorized();
  }
  if (!res.ok) throw await toApiError(res);
  return (await res.json()) as T;
}

/**
 * Run an action; if the credential has gone stale, confirm and run it again.
 *
 * FP3-12, and the shape matters. The *original* call is retried — not a
 * re-render, not a navigation — so whatever the person was doing survives the
 * interruption. `confirm` is supplied by the UI and resolves with a password,
 * or resolves null if they cancel, in which case the original error is thrown
 * and the screen reports it normally.
 *
 * Retried exactly once. A second `ReauthRequired` immediately after a
 * successful `/auth/reauth` is not a stale credential, it is something wrong,
 * and looping on it would be a password prompt that will not go away.
 */
export async function withReauth<T>(
  action: () => Promise<T>,
  confirm: (message: string) => Promise<{ password: string; code?: string } | null>,
): Promise<T> {
  try {
    return await action();
  } catch (err) {
    if (!(err instanceof ReauthRequired)) throw err;
    const answer = await confirm(err.message);
    if (answer === null) throw err;
    await api.reauth(answer);
    return await action();
  }
}

export async function patchJson<T>(path: string, body: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(apiUrl(path), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(body ?? {}),
      credentials: 'include',
    });
  } catch {
    reportEngineReachable(false);
    throw new ApiError(
      'Cannot reach the decision engine. This action needs a connection.',
      0,
    );
  }
  reportEngineReachable(true);
  if (res.status === 401) {
    if (isStaleCredential(res)) {
      throw new ReauthRequired((await toApiError(res)).message);
    }
    handleUnauthorized();
  }
  if (!res.ok) throw await toApiError(res);
  return (await res.json()) as T;
}

/* ----------------------------- endpoints ----------------------------- */

export const api = {
  health: () => getJson<Health>('/health'),
  scenarios: () => getJson<Scenario[]>('/scenarios'),
  dashboard: (scenario: ScenarioId) =>
    getJson<Dashboard>(`/dashboard?scenario=${scenario}`),
  castClients: (scenario?: ScenarioId) =>
    getJson<ClientSummary[]>(
      `/clients?cast_only=true${scenario ? `&scenario=${scenario}` : ''}`,
    ),
  clients: (scenario: ScenarioId, limit = 200) =>
    getJson<ClientSummary[]>(`/clients?scenario=${scenario}&limit=${limit}`),
  client: (id: string) => getJson<ClientDetail>(`/clients/${id}`),
  assets: () => getJson<Asset[]>('/assets'),
  decision: (id: number | string) => getJson<Decision>(`/decisions/${id}`),
  decisions: (params: { client_id?: string; outcome?: string; limit?: number }) => {
    const q = new URLSearchParams();
    if (params.client_id) q.set('client_id', params.client_id);
    if (params.outcome) q.set('outcome', params.outcome);
    if (params.limit) q.set('limit', String(params.limit));
    return getJson<DecisionSummary[]>(`/decisions?${q.toString()}`);
  },
  queue: (scenario?: string) =>
    getJson<QueueItem[]>(scenario ? `/queue?scenario=${scenario}` : '/queue'),
  /** Every regime on the shelf. The screen picks from this; it hardcodes none. */
  packShelf: () => getJson<PackShelfEntry[]>('/packs'),
  pack: (jurisdiction: string) => getJson<PackView>(`/packs/${jurisdiction}`),

  evaluate: (body: {
    client_id: string;
    asset_id: string;
    as_of?: string;
    amount_cents?: number;
  }) => postJson<Decision>('/evaluate', body),
  replay: (id: number | string) => postJson<ReplayResult>(`/decisions/${id}/replay`, {}),
  /**
   * The approver is not sent. It is whoever holds this session, resolved on the
   * server — a name typed into a form is an approval by nobody in particular,
   * and the server refuses one from the person who ran the check.
   */
  override: (id: number | string, body: { justification: string }) =>
    postJson<Decision>(`/decisions/${id}/override`, body),
  artefact: (kind: ArtefactKind, decision_id: number) =>
    postJson<Artefact>(`/artefacts/${kind}`, { decision_id }),

  /* --------------------------- reporting --------------------------- */

  reportPeriods: (scenario?: ScenarioId) =>
    getJson<ReportPeriod[]>(
      `/reports/periods${scenario ? `?scenario=${scenario}` : ''}`,
    ),

  /** The figures the document will contain, fetched before anyone generates it. */
  reportPreview: <T extends ReportPreview>(
    kind: ReportKind,
    period: string,
    scenario?: ScenarioId,
  ) =>
    getJson<T>(
      `/reports/preview?kind=${kind}&period=${period}${
        scenario ? `&scenario=${scenario}` : ''
      }`,
    ),

  generateReport: (kind: ReportKind, period: string, scenario?: ScenarioId) =>
    postJson<ReportArtefact>(
      kind === 'regulatory_return' ? '/returns' : '/reports/overrides',
      { period, scenario: scenario ?? null },
    ),

  /**
   * A plain link, not a fetch: the CSV is a file download, and routing it
   * through fetch would mean buffering it just to hand it back to the browser.
   */
  auditExportUrl: () => apiUrl('/audit/export'),

  /* ------------------------- integrations ------------------------- */

  integrations: () => getJson<IntegrationSummary>('/integrations'),

  /**
   * Preview and commit are the same call with one flag, so what a reader was
   * shown is what a reader gets — a separate validate endpoint could drift from
   * the one that writes. `commit` is explicit at every call site rather than
   * defaulted here, because the default that matters lives on the server.
   */
  importClients: (csvText: string, commit: boolean) =>
    postJson<ImportResult>('/import/clients', { csv_text: csvText, commit }),

  /* -------------------- regulatory currency -------------------- */

  currency: () => getJson<CurrencyOverview>('/currency'),

  watchEvents: (params: { jurisdiction?: string; tier?: string; status?: string } = {}) => {
    const q = new URLSearchParams();
    if (params.jurisdiction) q.set('jurisdiction', params.jurisdiction);
    if (params.tier) q.set('tier', params.tier);
    if (params.status) q.set('status', params.status);
    const qs = q.toString();
    return getJson<WatchQueue>(`/watch/events${qs ? `?${qs}` : ''}`);
  },

  /**
   * Returns 501 in live mode rather than falling back to the fixture. The
   * error surfaces to the screen with the adapter it would need named in it,
   * which is the only honest thing a button can do when the mode it was asked
   * for does not exist.
   */
  pollWatch: () => postJson<PollResult>('/watch/poll', {}),

  triageEvent: (id: number, status: WatchStatus, note = '') =>
    postJson<{ id: number; status: WatchStatus; note: string; was: string }>(
      `/watch/events/${id}/triage`,
      { status, note },
    ),

  drafts: () => getJson<{ statuses: string[]; drafts: PackDraft[] }>('/watch/drafts'),
  draft: (id: number) => getJson<PackDraftDetail>(`/watch/drafts/${id}`),

  /**
   * Records a signature, and nothing else. It used to be able to publish in the
   * same call, which let one person sign rule content and put it into force —
   * the separation the signatory role exists to create, undone by a flag.
   * Publishing is `publishDraft` and belongs to somebody else.
   *
   * No signatory name is sent. It is whoever holds this session, which the
   * server checks holds a `pack_signatory` grant for *this draft's*
   * jurisdiction and has confirmed a password in the last few minutes.
   */
  /**
   * Check an edit without saving it. What the workbench calls as you type.
   *
   * Deliberately does not write: a specialist trying a threshold to see what it
   * would break must not be leaving half-edited content behind them. The faults
   * come back as the pack validator produces them — each one names the rule,
   * the problem and where possible the fix, because they were written for this
   * reader.
   */
  /**
   * What is staged for this firm, and how long is left on each.
   *
   * An auto tenant sees an empty list *and* the policy that explains why, which
   * is a different answer from "nothing has changed" and worth being able to
   * tell apart.
   */
  advances: () => getJson<AdvanceState>('/advances'),

  takeAdvance: (id: string, note: string) =>
    postJson<{ id: string; status: string }>(`/advances/${id}/take`, { note }),

  /** The note is required — it is the thing that gets escalated. */
  declineAdvance: (id: string, note: string) =>
    postJson<{ id: string; status: string }>(`/advances/${id}/decline`, { note }),

  validateDraft: (id: number, edit: DraftEdit) =>
    postJson<{ ok: boolean; faults: string[]; rules?: number }>(
      `/watch/drafts/${id}/validate`,
      edit,
    ),

  /** Save an edit. Refused with a fault list if it would not evaluate. */
  editDraft: async (id: number, edit: DraftEdit): Promise<PackDraftDetail> => {
    const res = await fetch(apiUrl(`/watch/drafts/${id}`), {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      credentials: 'include',
      body: JSON.stringify(edit),
    });
    if (res.status === 401) handleUnauthorized();
    if (!res.ok) throw await toApiError(res);
    return (await res.json()) as PackDraftDetail;
  },

  /** Put a draft up for a signatory. The clock they are waiting on starts here. */
  submitDraft: (id: number) => postJson<PackDraft>(`/watch/drafts/${id}/submit`, {}),

  /**
   * The document this draft's templates would produce, as HTML.
   *
   * Returns markup rather than JSON, so it is fetched here rather than through
   * `getJson`. Nothing is stored — see the endpoint.
   */
  previewArtefact: async (id: number, kind: string): Promise<string> => {
    const res = await fetch(apiUrl(`/watch/drafts/${id}/preview/${kind}`), {
      headers: { Accept: 'text/html' },
      cache: 'no-store',
      credentials: 'include',
    });
    if (res.status === 401) handleUnauthorized();
    if (!res.ok) throw await toApiError(res);
    return res.text();
  },

  /** How this draft came to be where it is. Read when a question is asked. */
  draftHistory: (id: number) =>
    getJson<DraftHistory>(`/watch/drafts/${id}/history`),

  /**
   * `signedContentHash` is the `current_content_hash` of the draft this screen
   * rendered, and it is a required argument rather than an optional one.
   *
   * The server refuses if the draft has moved since — which closes the window
   * between reading a draft and signing it, where its author, who holds
   * `operator`, can edit it. An auditor walked exactly that: read 1000, PATCH to
   * 9999, sign, 200, with the signatory's name and qualification reference
   * against bytes they had never seen.
   *
   * Required so that a caller which forgets does not compile. An optional
   * parameter here would be one somebody omits in a hurry, and the omission
   * would be a signature over whatever is on the row.
   */
  signDraft: (id: number, note: string, signedContentHash: string) =>
    postJson<PackDraft>(`/watch/drafts/${id}/sign`, {
      note,
      signed_content_hash: signedContentHash,
    }),

  /**
   * `publishedContentHash` is the same value, for the same reason.
   *
   * Pressing publish counts as one of the two approvals a publication needs, so
   * a publisher is an attester too — and this route took no body at all until
   * the attestation census, which left them in a reading window that spans the
   * signature: read while the draft is in review, its author edits, a signatory
   * signs the edit, and the publisher puts bytes they never saw in front of
   * every firm under the regime.
   */
  publishDraft: (id: number, publishedContentHash: string) =>
    postJson<{ pack_id: number; jurisdiction: string; version: number }>(
      `/watch/drafts/${id}/publish`,
      { published_content_hash: publishedContentHash },
    ),

  /* ------------------------------- auth ------------------------------- */

  /**
   * Ask the engine whether this browser is signed in.
   *
   * Deliberately not routed through `getJson`, whose localStorage fallback
   * would hand back a "yes" written weeks ago. But bypassing that helper is
   * only half the job, and the half that was missing until Phase 6: the
   * service worker caches this response too, in a bucket page script cannot
   * reach, and answers from it whenever the network fails. So a cached "yes"
   * *was* reaching this function, arriving as an ordinary 200, and unlocking
   * the app — which is precisely what the old comment here claimed could not
   * happen. Two caches, one of them defended against.
   *
   * The resolution is not to refuse the cached answer, because the demo has to
   * survive airplane mode (§9 of the spec) and a device with no network cannot
   * be asked to prove anything. It is to stop pretending the answer was live.
   * `offline: true` means: this browser signed in successfully at some point,
   * the engine could not be reached to confirm it still is, and every record
   * on screen is a local copy. The caller decides what to do with that; what
   * it must not do is show it as a verified session.
   *
   * Note what is *not* weakened. The service worker only falls back when the
   * network throws, so an engine that answers "no" still answers "no" — a
   * revoked session online is signed out immediately, cache or not.
   */
  session: async (): Promise<SessionState & { offline: boolean }> => {
    const res = await fetch(apiUrl('/auth/session'), {
      headers: { Accept: 'application/json' },
      cache: 'no-store',
      credentials: 'include',
    });
    if (!res.ok) throw new ApiError('Cannot reach the decision engine.', res.status);
    const offline = res.headers.get('X-Quolin-From-Cache') === 'hit';
    const body = (await res.json()) as SessionState;
    // Tell the rest of the app before it renders anything, so the offline
    // banner is up on first paint rather than after the first screen's fetch
    // fails a moment later.
    reportEngineReachable(!offline);
    return { ...body, offline };
  },

  /**
   * Sign in as a person.
   *
   * `code` is the one-time code from an authenticator app, and is left empty on
   * the first attempt. The client cannot know whether an account has a second
   * factor without asking about that account, and an endpoint that answered
   * would be an account-enumeration oracle — so the engine says so only once the
   * password has checked out, by way of `MfaRequired`.
   */
  login: async (credentials: {
    email: string;
    password: string;
    code?: string;
  }): Promise<void> => {
    let res: Response;
    try {
      res = await fetch(apiUrl('/auth/login'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ ...credentials, code: credentials.code ?? '' }),
        credentials: 'include',
      });
    } catch {
      throw new ApiError(
        'Cannot reach the decision engine. Check that the API is running.',
        0,
      );
    }
    if (!res.ok) {
      const err = await toApiError(res);
      if (res.headers.get('X-Quolin-MFA') === 'required') {
        throw new MfaRequired(err.message);
      }
      throw err;
    }
    reportAuthenticated(true);
  },

  /* ------------------------------- FP3-12 ------------------------------- */

  /**
   * Confirm the password on a session that is already live.
   *
   * The whole point of it existing: signing a pack demands a credential
   * presented in the last few minutes, so there has to be a way to present one
   * *without signing out first* — otherwise the answer to "confirm your
   * password" is "log out and back in", and the draft on screen is lost.
   *
   * The route has existed since Stage 2 and the web client never called it.
   */
  reauth: async (credentials: { password: string; code?: string }): Promise<void> => {
    await postJson<{ status: string }>('/auth/reauth', {
      password: credentials.password,
      code: credentials.code ?? '',
    });
  },

  /**
   * Begin enrolling an authenticator. The secret comes back once and only once.
   *
   * FP3-12: `/auth/mfa/enrol` and `/auth/mfa/verify` had no screen at all, so
   * the only accounts with a second factor were the ones the seed enrolled —
   * and every role in `MFA_REQUIRED_ROLES` was, in a real deployment, an
   * account that could sign in and do nothing.
   */
  mfaEnrol: () =>
    postJson<{ secret: string; otpauth_url: string; status: string; statement: string }>(
      '/auth/mfa/enrol',
      {},
    ),

  /**
   * Spend an invitation and choose a password. FP3-11, reached from FP3-26.
   *
   * Public, and the only route in this client that a browser with no session
   * calls on purpose — which is the point: the person calling it cannot get a
   * session until it succeeds.
   */
  setPassword: (token: string, password: string) =>
    postJson<{ status: string; email: string }>('/auth/set-password', {
      token,
      password,
    }),

  /** Confirm the authenticator by proving it produces the right code. */
  mfaVerify: (code: string) =>
    postJson<{ status: string; mfa_satisfied: boolean }>('/auth/mfa/verify', { code }),

  /**
   * Ends the session server-side, then destroys the local cache.
   *
   * The cache is cleared even when the request fails. A logout that leaves
   * client records on the device because the network was down has not done the
   * thing the person pressing it asked for.
   */
  logout: async (): Promise<void> => {
    try {
      await fetch(apiUrl('/auth/logout'), {
        method: 'POST',
        credentials: 'include',
      });
    } finally {
      clearCachedData();
      reportAuthenticated(false);
    }
  },
};
