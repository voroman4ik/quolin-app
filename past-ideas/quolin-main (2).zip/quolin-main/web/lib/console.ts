/**
 * The seven administrative screens' half of the client. FP3-26.
 *
 * Separate from `api.ts` for the reason the routes are separate from the rest:
 * these are the screens a firm's administrator and Quolin's own operator use,
 * and they are read by seven pages that the six-hundred-line client for the
 * compliance workflow never touches. Keeping them apart also keeps the offline
 * story honest — none of this is cached for a plane, because none of it is
 * something to do without a connection.
 *
 * Every route here already existed and was already published in the OpenAPI
 * document, with one exception that is called out on `users` below. The finding
 * was never that the API was missing; it was that a customer could only reach
 * any of it with curl.
 */

import { getJson, patchJson, postJson } from './api';

export const admin = {
  runs: () => getJson<{ runs: RunSummary[] }>('/runs'),
  run: (id: number | string) => getJson<RunSummary>(`/runs/${id}`),
  runDeltas: (id: number | string) =>
    getJson<{ run: RunSummary; deltas: RunDelta[]; note: string }>(
      `/runs/${id}/deltas`,
    ),

  artefactJobs: (status?: string) =>
    getJson<{ jobs: ArtefactJob[]; depth: Record<string, number> }>(
      `/artefacts/jobs${status ? `?status=${status}` : ''}`,
    ),
  artefactJob: (id: number) => getJson<ArtefactJob>(`/artefacts/jobs/${id}`),
  queueArtefacts: (jobs: BatchJobRequest[]) =>
    postJson<{ accepted: (ArtefactJob & { created: boolean })[] }>(
      '/artefacts/batch',
      { jobs },
    ),

  adoption: () => getJson<AdoptionState>('/adoption'),
  auditCertificate: () => getJson<AuditCertificate>('/audit/certificate'),

  advancePolicy: () => getJson<AdvancePolicyState>('/tenant/advance-policy'),
  /**
   * PATCH answers a different shape from GET — it carries `was` and drops the
   * catalogue — so the screen reloads rather than pretending one is the other.
   */
  setAdvancePolicy: (policy: string, window_days?: number) =>
    patchJson<AdvancePolicyChange>('/tenant/advance-policy', {
      policy,
      window_days,
    }),

  sourceVerifications: (sourceId: string) =>
    getJson<SourceVerifications>(`/currency/sources/${sourceId}/verifications`),

  /**
   * This firm's people and what they hold.
   *
   * The one new route FP3-26 needed: everything else on the seven screens was
   * already published API surface, but provisioning, granting, revoking and
   * suspending were all writes with nothing to read them back from, and a
   * screen that administers users has to be able to list them.
   */
  users: () => getJson<FirmUsers>('/admin/users'),

  provisionUser: (body: { email: string; display_name: string }) =>
    postJson<ProvisionedUser>('/admin/users', body),
  grantRole: (userId: string, body: { role: string; jurisdiction?: string }) =>
    postJson<GrantedRole>(`/admin/users/${userId}/roles`, body),
  revokeRole: (grantId: string) =>
    postJson<{ status: string; revoked: string }>(`/admin/roles/${grantId}/revoke`, {}),
  suspendUser: (userId: string, reason: string) =>
    postJson<{ status: string; account_status: string; sessions_ended: number }>(
      `/admin/users/${userId}/suspend`,
      { reason },
    ),
  reinstateUser: (userId: string, reason: string) =>
    postJson<{ status: string; account_status: string }>(
      `/admin/users/${userId}/reinstate`,
      { reason },
    ),
};

/* ------------------------------------------------------------------ *
 * FP3-26. The shapes the seven console screens read.
 *
 * Written against the routes as they answer today rather than against what a
 * screen would find convenient — every one of these already existed as API
 * surface with published OpenAPI, which is why the finding is about screens
 * and not about endpoints.
 * ------------------------------------------------------------------ */

/** One move, and how many clients made it. */
export interface RunMove {
  from: string;
  to: string;
  count: number;
}

/** A sweep of the book. */
export interface RunSummary {
  id: number;
  trigger: string;
  jurisdiction: string;
  as_of: string;
  status: string;
  requested_by: string;
  requested_at: string;
  started_at: string | null;
  finished_at: string | null;
  dry_run: boolean;
  against_version: number | null;
  pairs_total: number;
  pairs_done: number;
  changed: number;
  failures: number;
  chunks: Record<string, number>;
  moves: RunMove[];
  note: string | null;
}

/**
 * One client whose outcome moved, with the rule that moved it.
 *
 * `rule_id` and `reason_code` are the half of this that matters: "212 clients
 * moved to REFER" is the headline, and "under AU-KNOW-02" is what a regulator
 * asks next.
 */
export interface RunDelta {
  client_id: string;
  asset_id: string;
  from: string;
  to: string;
  from_pack_version: number | null;
  to_pack_version: number | null;
  rule_id: string;
  reason_code: string;
  decision_id: number | null;
}

export interface ArtefactJob {
  id: string;
  kind: string;
  subject: string;
  status: string;
  priority: number;
  attempts: number;
  /**
   * What the job was asked for, in the keys `/artefacts/batch` takes.
   *
   * `subject` is a sentence for a person — "determination #4021" — so a retry
   * built from it would be parsing English to decide what to re-enqueue.
   */
  params: Record<string, string | null>;
  requested_at: string;
  started_at: string | null;
  finished_at: string | null;
  artefact_id: number | null;
  error: string | null;
  download_url: string | null;
}

export interface AdoptionOnboarding {
  measured: boolean;
  reached_shadow?: boolean;
  contracted_at?: string;
  days?: number;
  days_so_far?: number;
  target_days: number;
  within_target?: boolean;
  why_not?: string;
  reached_shadow_at?: string | null;
}

export interface AdoptionState {
  stage: string;
  means: string;
  ladder: string[];
  /**
   * The slice of the book that is live in `limited`.
   *
   * `adoption.scope_of` always answers both keys, empty when nothing is named,
   * so this is not nullable — a firm on another rung has an empty scope rather
   * than no scope.
   */
  limited_scope: { scenarios: string[]; asset_ids: string[] };
  onboarding: AdoptionOnboarding;
  history: {
    from: string | null;
    to: string;
    at: string;
    signed_by: string;
    signed_by_user_id: string | null;
    note: string;
  }[];
}

export interface AuditCertificate {
  verified: boolean;
  tenant_id: string;
  tenant_name: string;
  genesis_hash: string;
  checked: number;
  checked_at: string;
  covers: string;
  statement: string;
  tip_hash?: string;
  broken_at_decision_id?: number;
  expected_hash?: string;
  stored_hash?: string;
}

export interface AdvancePolicyState {
  policy: string;
  window_days: number;
  means: string;
  policies: Record<string, string>;
  default: string;
}

export interface SourceVerification {
  id: string;
  verified_on: string;
  verified_by: string;
  note: string;
  attachment_ref: string;
}

export interface SourceVerifications {
  source_id: string;
  name: string;
  jurisdiction: string;
  polling_status: string;
  verifications: SourceVerification[];
}

export interface HeldRole {
  id: string;
  role: string;
  jurisdiction: string;
  granted_by: string;
  granted_at: string;
  expires_at: string | null;
}

export interface FirmUser {
  id: string;
  email: string;
  display_name: string;
  status: string;
  roles: HeldRole[];
}

export interface FirmUsers {
  tenant_id: string;
  users: FirmUser[];
}

/**
 * What `POST /admin/users` answers.
 *
 * `invitation` is the FP3-11 half and is present only when the person was
 * created by this call: the token is returned once, to the administrator who
 * created the account, and is never stored in a readable form. There is no
 * route that can show it again, which is what makes hashing it worth anything —
 * so a screen that loses it has to issue another rather than look it up.
 */
export interface ProvisionedUser {
  id: string;
  email: string;
  created: boolean;
  invitation?: { token: string; expires_at: string };
}

export interface GrantedRole {
  id: string;
  user_id: string;
  role: string;
  jurisdiction: string;
  granted_by: string;
  granted_at: string;
  expires_at: string | null;
}

/**
 * What PATCH answers, which is not what GET answers.
 *
 * It carries `was` — the policy that has just been replaced — and drops the
 * catalogue of what each policy means. Typed separately rather than made
 * optional on `AdvancePolicyState`, because a screen that treated the two as
 * one would render an empty catalogue after a successful change.
 */
export interface AdvancePolicyChange {
  policy: string;
  window_days: number;
  means: string;
  was: { policy: string; window_days: number };
}

/** One entry in a `/artefacts/batch` request. */
export interface BatchJobRequest {
  kind: string;
  jurisdiction?: string | null;
  decision_id?: number | null;
  run_id?: number | null;
  period?: string | null;
  scenario?: string | null;
}

/**
 * Ask for a failed document again.
 *
 * Rebuilt from the job's own `params` rather than from its subject line, and
 * sent to the endpoint that queued it the first time. `enqueue` treats a
 * *finished* job as no reason to suppress a new one and rendering is
 * deterministic, so repeating the request is what a retry is — there is no
 * separate retry route and adding one would be a second way to say the same
 * thing.
 *
 * The failed row is left alone. It is the answer to "why did this not arrive on
 * the day it was due", and a retry that tidied it away would erase that too.
 */
export function retryArtefactJob(job: ArtefactJob) {
  const p = job.params ?? {};
  const numeric = (v: string | null | undefined) =>
    v === null || v === undefined || v === '' ? null : Number(v);
  return admin.queueArtefacts([
    {
      kind: job.kind,
      jurisdiction: p.jurisdiction ?? null,
      decision_id: numeric(p.decision_id),
      run_id: numeric(p.run_id),
      period: p.period ?? null,
      scenario: p.scenario ?? null,
    },
  ]);
}
