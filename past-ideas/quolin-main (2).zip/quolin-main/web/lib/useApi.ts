'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { ApiError, type Fetched, type SessionState, api } from './api';

export interface ApiState<T> {
  data: T | null;
  error: string | null;
  loading: boolean;
  /** Served from the offline cache because the network was unreachable. */
  stale: boolean;
  reload: () => void;
}

/**
 * Runs a getJson-style loader. `deps` controls re-fetching; the loader itself
 * is intentionally not a dependency so callers can pass inline arrow functions.
 */
export function useApi<T>(
  loader: () => Promise<Fetched<T>>,
  deps: unknown[] = [],
  options: { skip?: boolean } = {},
): ApiState<T> {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(!options.skip);
  const [stale, setStale] = useState(false);
  const [nonce, setNonce] = useState(0);

  const loaderRef = useRef(loader);
  loaderRef.current = loader;

  const skip = options.skip ?? false;

  useEffect(() => {
    if (skip) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setError(null);

    loaderRef
      .current()
      .then((res) => {
        if (cancelled) return;
        setData(res.data);
        setStale(res.stale);
        setError(null);
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setError(
          err instanceof ApiError ? err.message : 'Something went wrong loading this view.',
        );
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, nonce, skip]);

  const reload = useCallback(() => setNonce((n) => n + 1), []);

  return { data, error, loading, stale, reload };
}

/**
 * Who is signed in, for screens that print the acting person's name.
 *
 * `api.session` predates `Fetched` and carries its own `offline` flag, so it
 * cannot be handed to `useApi` directly. Mapped here once rather than at each
 * call site, because the two screens that show a name — the override and the
 * signature — are the two where a name from the wrong session would be a
 * misattribution rather than a cosmetic bug.
 */
export function useSession(): ApiState<SessionState> {
  return useApi<SessionState>(async () => {
    const { offline, ...state } = await api.session();
    return { data: state, stale: offline };
  }, []);
}
