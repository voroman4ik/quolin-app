'use client';

import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { ArtefactKind, ScenarioId } from './types';

const STORAGE_KEY = 'quolin:scenario';

/** Static mirror of GET /scenarios so the shell renders instantly and offline. */
export const SCENARIOS: {
  id: ScenarioId;
  name: string;
  kind: string;
  artefact_kind: ArtefactKind;
  artefact_label: string;
}[] = [
  {
    id: 'sterling',
    name: 'Sterling Private Wealth',
    kind: 'Private wealth manager',
    artefact_kind: 'tmd',
    artefact_label: 'TMD',
  },
  {
    id: 'meridian',
    name: 'Meridian Digital',
    kind: 'Crypto platform',
    artefact_kind: 'evidence_pack',
    artefact_label: 'Evidence Pack',
  },
];

export function scenarioMeta(id: ScenarioId) {
  return SCENARIOS.find((s) => s.id === id) ?? SCENARIOS[0];
}

interface ScenarioCtx {
  scenario: ScenarioId;
  setScenario: (s: ScenarioId) => void;
  ready: boolean;
}

const Ctx = createContext<ScenarioCtx>({
  scenario: 'sterling',
  setScenario: () => {},
  ready: false,
});

export function ScenarioProvider({ children }: { children: React.ReactNode }) {
  const [scenario, setScenarioState] = useState<ScenarioId>('sterling');
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved === 'sterling' || saved === 'meridian') setScenarioState(saved);
    setReady(true);
  }, []);

  const setScenario = useCallback((s: ScenarioId) => {
    setScenarioState(s);
    try {
      window.localStorage.setItem(STORAGE_KEY, s);
    } catch {
      /* private mode — in-memory only */
    }
  }, []);

  return <Ctx.Provider value={{ scenario, setScenario, ready }}>{children}</Ctx.Provider>;
}

export function useScenario() {
  return useContext(Ctx);
}
