/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  /*
   * Normally `.next`. The offline regression in e2e/ overrides it so its own
   * production build does not land on top of a `make web` dev server's working
   * directory — Next 16 refuses to run two dev servers against one directory,
   * and a build sharing the folder with a running one is the same collision by
   * another route. See web/e2e/servers.ts.
   */
  distDir: process.env.NEXT_DIST_DIR || '.next',
  headers: async () => [
    {
      source: '/sw.js',
      headers: [
        { key: 'Cache-Control', value: 'no-cache, no-store, must-revalidate' },
        { key: 'Service-Worker-Allowed', value: '/' },
      ],
    },
  ],
};

export default nextConfig;
