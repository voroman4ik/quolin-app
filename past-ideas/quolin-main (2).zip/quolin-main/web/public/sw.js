/*
 * Quolin service worker.
 *
 * Purpose: the demo runs from a home-screen icon on conference Wi-Fi that may
 * not work. The app shell and every page visited during prep are cached, and
 * API GETs are mirrored so the six screens still render with no network.
 *
 * Strategies:
 *   build assets (/_next/static) -> cache first, immutable
 *   navigations + RSC payloads   -> network first, cache fallback
 *   API GETs (any origin)        -> network first, cache fallback
 *   POSTs                        -> never cached; they need a live engine
 */

/*
 * Dev builds re-use chunk URLs while changing their contents, so immutable
 * caching is disabled when registered as /sw.js?dev=1.
 */
const DEV = new URL(self.location.href).searchParams.has('dev');

// Bumped for the purge handler below: an old worker without it would keep
// serving cached client records after a sign-out that claimed to delete them.
//
// v7 adds the chain certificate to the never-cache list. FP3-26.
const VERSION = DEV ? 'quolin-dev' : 'quolin-v7';
const SHELL_CACHE = `${VERSION}-shell`;
const ASSET_CACHE = `${VERSION}-assets`;
const DATA_CACHE = `${VERSION}-data`;

const SHELL_ROUTES = ['/', '/clients', '/queue', '/packs', '/reports', '/integrations'];

const SHELL_ASSETS = [
  '/manifest.json',
  '/icons/icon-180.png',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/icon-maskable-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(SHELL_CACHE);
      // Individually, so one failure cannot abort the whole install.
      await Promise.all(
        [...SHELL_ROUTES, ...SHELL_ASSETS].map(async (url) => {
          try {
            const res = await fetch(url, { cache: 'reload' });
            if (res.ok) await cache.put(url, res);
          } catch (_) {
            /* offline at install time — it will be filled on first visit */
          }
        }),
      );
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k)),
      );
      await self.clients.claim();
    })(),
  );
});

function isBuildAsset(url) {
  return url.pathname.startsWith('/_next/static') || url.pathname.startsWith('/icons/');
}

function isApiRequest(url) {
  // Anything not served by this origin is the decision engine.
  return url.origin !== self.location.origin;
}

async function cacheFirst(request, cacheName) {
  const cache = await caches.open(cacheName);
  const hit = await cache.match(request);
  if (hit) return hit;
  const res = await fetch(request);
  if (res && res.ok) cache.put(request, res.clone());
  return res;
}

/*
 * Serving a cached response as a plain 200 makes the page believe it reached
 * the engine, so it renders months-old figures as though they were live. Stamp
 * every cache fallback so the app can tell the difference and say so.
 *
 * A worker-synthesised Response is handed to the page as-is, so this header
 * survives without needing Access-Control-Expose-Headers on the API.
 */
const CACHE_MARK = 'X-Quolin-From-Cache';

async function markAsCached(response) {
  const headers = new Headers(response.headers);
  headers.set(CACHE_MARK, 'hit');
  return new Response(await response.blob(), {
    status: response.status,
    statusText: response.statusText,
    headers,
  });
}

async function networkFirst(request, cacheName, fallbackUrl) {
  const cache = await caches.open(cacheName);
  try {
    const res = await fetch(request);
    // Opaque responses are useless to us but harmless to skip.
    if (res && res.ok && res.type !== 'opaque') cache.put(request, res.clone());
    return res;
  } catch (err) {
    const hit = await cache.match(request);
    if (hit) return markAsCached(hit);
    if (fallbackUrl) {
      const shell = await caches.open(SHELL_CACHE);
      const fallback = await shell.match(fallbackUrl);
      if (fallback) return markAsCached(fallback);
    }
    throw err;
  }
}

/*
 * Signing out has to reach in here too.
 *
 * DATA_CACHE is a second copy of the client records — separate from the
 * localStorage mirror the page keeps, and not reachable from page script,
 * because a service worker cache is only writable by the worker. Clearing
 * localStorage alone would leave every cached API response sitting on the
 * device, and the Sign out button says it deletes them. This is how that
 * sentence stays true.
 *
 * Also cleared on any 401, which is the case that matters more: a session
 * expiring overnight is exactly when nobody is present to press a button.
 */
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'quolin-purge-data') {
    event.waitUntil(
      (async () => {
        await caches.delete(DATA_CACHE);
        // Acknowledge, so the page can report a real outcome rather than
        // assuming one. An unanswered postMessage is indistinguishable from a
        // worker that was never listening.
        if (event.ports && event.ports[0]) event.ports[0].postMessage({ purged: true });
      })(),
    );
  }
});

self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Never interfere with evaluate / override / artefact generation.
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // PDFs must always come from the network: they are generated per request.
  if (url.pathname.includes('/artefacts/') && url.pathname.endsWith('/pdf')) return;

  /*
   * The audit export is a file download, so the X-Quolin-From-Cache marker
   * never reaches a reader — a stale CSV would land on disk looking exactly
   * like a current one. Better to fail loudly offline than to hand someone a
   * silently out-of-date audit trail.
   */
  if (url.pathname === '/audit/export') return;

  /*
   * The chain certificate is a claim about *now*, and the endpoint refuses to
   * cache it server-side for exactly that reason: "a stored 'verified' is a
   * claim about a moment that has passed, and the moment it goes stale is
   * precisely the moment it matters."
   *
   * A worker that served yesterday's certificate would reintroduce the thing
   * the endpoint went out of its way to avoid — and worse than the audit export
   * above, because this one is downloaded as a signed-looking statement. Better
   * to fail offline than to hand somebody a certificate saying the chain
   * verified before the record that broke it was written.
   */
  if (url.pathname === '/audit/certificate') return;

  if (isBuildAsset(url)) {
    // Production chunks are content-hashed, so they can be served cache-first.
    event.respondWith(
      DEV ? networkFirst(request, ASSET_CACHE) : cacheFirst(request, ASSET_CACHE),
    );
    return;
  }

  if (isApiRequest(url)) {
    event.respondWith(networkFirst(request, DATA_CACHE));
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith(networkFirst(request, SHELL_CACHE, '/'));
    return;
  }

  // React Server Component payloads for client-side navigation.
  if (url.searchParams.has('_rsc')) {
    event.respondWith(networkFirst(request, SHELL_CACHE));
    return;
  }

  event.respondWith(networkFirst(request, ASSET_CACHE));
});
