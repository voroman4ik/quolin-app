import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#0F1C2E',
          800: '#1B2C42',
          600: '#33465F',
          400: '#5A6B80',
        },
        parchment: {
          DEFAULT: '#FAF8F4',
          dark: '#F1EDE6',
        },
        gold: {
          DEFAULT: '#8A6420',
          soft: '#F5EDDF',
        },
        rule: {
          DEFAULT: '#DCD7CE',
          strong: '#C4BDB1',
        },
        /*
         * Verdict colours are reserved: nothing that is not an ALLOW / REFER /
         * BLOCK determination may use them. `refer` was previously the same hex
         * as `gold`, which made a nav link indistinguishable from a referral.
         */
        allow: { DEFAULT: '#14654A', bg: '#E4EFEA' },
        block: { DEFAULT: '#8A2E2E', bg: '#F4E8E8' },
        refer: { DEFAULT: '#9A5400', bg: '#FBEBDA' },
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'ui-monospace', 'SFMono-Regular', 'monospace'],
      },
      letterSpacing: {
        wider2: '0.08em',
      },
      maxWidth: {
        column: '46rem',
      },
    },
  },
  plugins: [],
};

export default config;
