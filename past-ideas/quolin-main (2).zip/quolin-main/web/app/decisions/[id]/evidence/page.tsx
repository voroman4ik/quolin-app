'use client';

import Link from 'next/link';
import { use, useState } from 'react';
import { ApiError, api } from '@/lib/api';
import {
  formatDate,
  formatDateTime,
  formatProvenanceValue,
  humanizeRef,
} from '@/lib/format';
import { useApi } from '@/lib/useApi';
import { useEngineReachable } from '@/lib/connectivity';
import { AppBar } from '@/components/AppBar';
import ArtefactButton from '@/components/ArtefactButton';
import ChainCertificate from '@/components/ChainCertificate';
import { ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import { VerdictTag } from '@/components/Verdict';
import type { ArtefactKind, ReplayResult } from '@/lib/types';

/*
 * `params` is a Promise in Next 16 and has to be unwrapped.
 *
 * It was read synchronously here, which a production build resolves to
 * `undefined` — so this screen requested the record `undefined` and rendered
 * "Unavailable" over an engine that was answering perfectly well. Every
 * dynamic route in the app had the same line. It survived because nothing
 * exercised a production build at runtime: `npm run build` compiles it without
 * complaint, and the demo and `make tunnel` both run `next dev`.
 *
 * Found by the offline regression in e2e/, which serves a production build.
 */
export default function EvidencePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const decision = useApi(() => api.decision(id), [id]);
  const d = decision.data;

  // Null until the client is known — see the note in the decision screen. This
  // is the screen with the gold Generate button the demo ends on, so an
  // authoritative-looking wrong label here is the most expensive version of
  // this bug.
  const client = useApi(() => api.client(d!.client_id), [d?.client_id], { skip: !d });
  const artefactKind: ArtefactKind | null = client.data
    ? client.data.scenario === 'meridian'
      ? 'evidence_pack'
      : 'tmd'
    : null;

  const engineUp = useEngineReachable();

  const [replay, setReplay] = useState<ReplayResult | null>(null);
  const [replaying, setReplaying] = useState(false);
  const [replayError, setReplayError] = useState<string | null>(null);

  async function runReplay() {
    setReplaying(true);
    setReplayError(null);
    setReplay(null);
    try {
      const result = await api.replay(id);
      setReplay(result);
    } catch (err) {
      setReplayError(
        err instanceof ApiError ? err.message : 'The replay could not be completed.',
      );
    } finally {
      setReplaying(false);
    }
  }

  return (
    <main className="min-h-dvh pb-20">
      <AppBar
        title="Evidence record"
        subtitle={d ? `Decision ${d.id} · ${formatDate(d.as_of)}` : undefined}
        back={`/decisions/${id}`}
      />

      <div className="col space-y-6 pt-5">
        {decision.stale && <StaleNotice />}
        {decision.loading && !d && <LoadingBlock rows={4} />}
        {decision.error && !d && (
          <ErrorState message={decision.error} onRetry={decision.reload} />
        )}

        {d && (
          <>
            {/* Provenance header — everything below is reconstructed from stored state. */}
            <section className="rounded-md border border-navy-800 bg-navy px-5 py-5 text-parchment">
              <p className="label text-parchment/45">Determination as recorded</p>
              <div className="mt-2 flex items-baseline justify-between gap-3">
                <p className="text-[26px] font-semibold leading-none tracking-tight">
                  {d.outcome}
                </p>
                <span className="mono text-parchment/60">#{d.id}</span>
              </div>
              <p className="mt-3 text-[14px] leading-snug text-parchment/80">
                {d.client_name} · {d.asset_symbol}
              </p>
              <dl className="mono mt-4 space-y-1.5 border-t border-parchment/15 pt-3 text-parchment/70">
                <Line k="as_of" v={d.as_of} />
                <Line k="pack" v={`${d.pack_id} v${d.pack_version}`} />
                <Line k="effective_from" v={d.pack_effective_from} />
                <Line k="recorded" v={formatDateTime(d.created_at)} />
              </dl>
              <p className="mt-3 border-t border-parchment/15 pt-3 text-[12px] leading-snug text-parchment/50">
                Signed by {d.pack_signed_by}
              </p>
            </section>

            {/* Replay — the proof that history survives rule changes. */}
            <section aria-labelledby="replay-h">
              <h2 id="replay-h" className="label mb-2">
                Reproduction
              </h2>

              {!replay && (
                <div className="card p-4">
                  <p className="text-[14px] leading-relaxed text-navy-600">
                    Re-run this decision against the rule pack that was in force on{' '}
                    {formatDate(d.as_of)} — pack v{d.pack_version} — using only the inputs
                    stored with the record.
                  </p>
                  <button
                    type="button"
                    onClick={runReplay}
                    disabled={replaying || !engineUp}
                    className="btn-primary mt-3 w-full"
                  >
                    {replaying ? 'Replaying…' : 'Replay this decision'}
                  </button>
                  {!engineUp && (
                    <p className="mt-2 text-[12px] leading-snug text-navy-400">
                      Replay re-runs the engine, so it needs a connection. The record
                      above is complete and readable offline.
                    </p>
                  )}
                </div>
              )}

              {replayError && (
                <div className="mt-3">
                  <ErrorState message={replayError} onRetry={runReplay} />
                </div>
              )}

              {replay && (
                <div
                  className={`card overflow-hidden ${
                    replay.match ? 'border-allow/30' : 'border-block/30'
                  }`}
                >
                  <div className={replay.match ? 'bg-allow-bg px-5 py-5' : 'bg-block-bg px-5 py-5'}>
                    <div className="flex items-start gap-3">
                      <span
                        aria-hidden="true"
                        className={`mt-0.5 inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[15px] font-bold text-white ${
                          replay.match ? 'bg-allow' : 'bg-block'
                        }`}
                      >
                        {replay.match ? '✓' : '!'}
                      </span>
                      <div>
                        <p
                          className={`text-[22px] font-semibold leading-tight tracking-tight ${
                            replay.match ? 'text-allow' : 'text-block'
                          }`}
                        >
                          {replay.match ? 'Reproduced exactly' : 'Reproduction mismatch'}
                        </p>
                        <p
                          className={`mono mt-1 ${
                            replay.match ? 'text-allow/80' : 'text-block/80'
                          }`}
                        >
                          pack v{replay.pack_version} · chain{' '}
                          {replay.chain.verified ? 'verified ✓' : 'FAILED'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <dl className="divide-y divide-rule">
                    <Compare label="Stored outcome" value={replay.stored_outcome} />
                    <Compare label="Replayed outcome" value={replay.replayed_outcome} />
                    <div className="flex items-baseline justify-between gap-4 px-4 py-3">
                      <dt className="text-[13px] text-navy-400">Differences</dt>
                      <dd className="mono text-navy">
                        {replay.differences.length === 0
                          ? 'none'
                          : `${replay.differences.length} found`}
                      </dd>
                    </div>
                    <div className="flex items-baseline justify-between gap-4 px-4 py-3">
                      <dt className="text-[13px] text-navy-400">Records checked</dt>
                      <dd className="mono text-navy">{replay.chain.checked}</dd>
                    </div>
                  </dl>

                  {replay.differences.length > 0 && (
                    <div className="border-t border-rule bg-block-bg px-4 py-3">
                      <p className="label text-block">Differences</p>
                      <pre className="mono mt-1.5 whitespace-pre-wrap break-words text-navy">
                        {JSON.stringify(replay.differences, null, 2)}
                      </pre>
                    </div>
                  )}

                  <div className="border-t border-rule px-4 py-3">
                    <button type="button" onClick={runReplay} className="btn-secondary w-full">
                      Replay again
                    </button>
                  </div>
                </div>
              )}
            </section>

            {/* Hash chain */}
            <section aria-labelledby="chain-h">
              <h2 id="chain-h" className="label mb-2">
                Hash chain
              </h2>
              <div className="card overflow-hidden">
                <ChainNode label="Preceding record" hash={d.prev_hash} genesis={d.is_genesis} />
                <ChainJoin />
                <ChainNode label={`This record · decision ${d.id}`} hash={d.this_hash} current />
              </div>
              <p className="mt-2 text-[12px] leading-snug text-navy-400">
                Each decision commits to the one before it. Altering any stored input would
                break every hash that follows.
              </p>

              {/* FP3-26. The sentence above is a claim about every record, made
                  on a screen that had checked one. This is the check. */}
              <div className="mt-3">
                <ChainCertificate />
              </div>
            </section>

            {/* Stored inputs */}
            <section aria-labelledby="snap-h">
              <h2 id="snap-h" className="label mb-2">
                Stored inputs
              </h2>
              <div className="space-y-3">
                <SnapshotBlock title="Client" data={d.snapshot.client} />
                <SnapshotBlock title="Asset" data={d.snapshot.asset} />
                <SnapshotBlock
                  title="Trade"
                  data={d.snapshot.trade as unknown as Record<string, unknown>}
                />
                <SnapshotBlock
                  title="Derived"
                  data={d.snapshot.calc as unknown as Record<string, unknown>}
                />
              </div>
            </section>

            {/* Findings as recorded */}
            <section aria-labelledby="find-h">
              <h2 id="find-h" className="label mb-2">
                Findings as recorded
              </h2>
              {d.reasons.length === 0 ? (
                <div className="card p-4">
                  <p className="text-[14px] text-navy-600">
                    No rule failed. All applicable rules passed under pack v{d.pack_version}.
                  </p>
                </div>
              ) : (
                <div className="card divide-y divide-rule">
                  {d.reasons.map((r) => (
                    <div key={r.rule_id} className="px-4 py-3">
                      <div className="flex items-start justify-between gap-3">
                        <p className="text-[14px] font-medium leading-snug text-navy">
                          {r.reason_title}
                        </p>
                        <VerdictTag outcome={r.outcome} />
                      </div>
                      <p className="mt-1 text-[13px] leading-snug text-navy-600">
                        {r.reason_plain_english}
                      </p>
                      <p className="mono mt-1.5 text-navy-400">
                        {r.rule_id} · {r.reason_code}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {d.override && (
              <section className="card border-gold/35 bg-gold-soft p-4">
                <p className="label text-gold">Override on record</p>
                <p className="mt-2 text-[14px] leading-relaxed text-navy">
                  {d.override.justification}
                </p>
                <p className="mt-2 text-[12px] text-navy-600">
                  {d.override.approver} · {formatDateTime(d.override.created_at)}
                </p>
              </section>
            )}

            <section className="space-y-3">
              <ArtefactButton decisionId={d.id} kind={artefactKind} variant="gold" />
              <Link href={`/packs?highlight=${d.pack_version}`} className="btn-secondary w-full">
                Compare rule pack versions
              </Link>
            </section>
          </>
        )}
      </div>
    </main>
  );
}

function Line({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-4">
      <dt className="text-parchment/45">{k}</dt>
      <dd className="text-right text-parchment/90">{v}</dd>
    </div>
  );
}

function Compare({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4 px-4 py-3">
      <dt className="text-[13px] text-navy-400">{label}</dt>
      <dd className="mono font-semibold text-navy">{value}</dd>
    </div>
  );
}

function ChainNode({
  label,
  hash,
  genesis,
  current,
}: {
  label: string;
  hash: string | null;
  genesis?: boolean;
  current?: boolean;
}) {
  return (
    <div className={`px-4 py-3 ${current ? 'bg-parchment' : ''}`}>
      <div className="flex items-center gap-2">
        <span
          aria-hidden="true"
          className={`h-2 w-2 shrink-0 rounded-full ${current ? 'bg-navy' : 'bg-rule-strong'}`}
        />
        <p className="label">{label}</p>
      </div>
      <p className="mono mt-1.5 break-all leading-relaxed text-navy">{hash ?? '—'}</p>
      {genesis && (
        <p className="mt-1 text-[12px] leading-snug text-navy-400">
          Chain anchor — this account&rsquo;s chain starts here, so there is no preceding
          decision.
        </p>
      )}
    </div>
  );
}

/** The link itself, stated as the construction the engine actually performs. */
function ChainJoin() {
  return (
    <div className="flex items-center gap-2 border-y border-rule px-4 py-2">
      <span aria-hidden="true" className="ml-[3px] h-6 w-px shrink-0 bg-rule-strong" />
      <p className="mono text-navy-400">sha256(prev_hash + canonical record)</p>
    </div>
  );
}

function SnapshotBlock({ title, data }: { title: string; data: Record<string, unknown> }) {
  const entries = Object.entries(data ?? {});
  if (entries.length === 0) return null;
  return (
    <div className="card overflow-hidden">
      <p className="label border-b border-rule bg-parchment px-4 py-2">{title}</p>
      <dl className="divide-y divide-rule/60">
        {entries.map(([k, v]) => (
          <div key={k} className="flex items-baseline justify-between gap-4 px-4 py-2">
            <dt className="mono min-w-0 flex-1 break-words text-navy-400">{humanizeRef(k)}</dt>
            <dd className="mono shrink-0 text-right font-medium text-navy">
              {formatProvenanceValue(k, v)}
            </dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
