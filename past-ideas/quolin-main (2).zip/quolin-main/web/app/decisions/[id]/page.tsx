'use client';

import Link from 'next/link';
import { use, useState } from 'react';
import { api } from '@/lib/api';
import { formatDate, formatDateTime, shortHash } from '@/lib/format';
import { useApi } from '@/lib/useApi';
import { AppBar } from '@/components/AppBar';
import ArtefactButton from '@/components/ArtefactButton';
import IllustrativeBadge from '@/components/IllustrativeBadge';
import JurisdictionPanel from '@/components/JurisdictionPanel';
import ReasonCard from '@/components/ReasonCard';
import RuleLedger from '@/components/RuleLedger';
import { ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import { VerdictBanner } from '@/components/Verdict';
import type { ArtefactKind } from '@/lib/types';

/*
 * `params` is a Promise in Next 16 and has to be unwrapped.
 *
 * It was read synchronously here, which a production build resolves to
 * `undefined` — so this screen requested the record `undefined` and rendered
 * "Unavailable" over an engine that was answering perfectly well. Every
 * dynamic route in the app had the same line. It survived because nothing
 * exercised a production build at runtime: `npm run build` compiles it without
 * complaint, and the demo and `make tunnel` both run `next dev`.
 *
 * Found by the offline regression in e2e/, which serves a production build.
 */
export default function DecisionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const decision = useApi(() => api.decision(id), [id]);
  const d = decision.data;

  // Artefact kind follows the client's own scenario, not the current switcher.
  // Null until that is actually known: the old `?? 'tmd'` turned a failed or
  // in-flight client fetch into a confident offer of the wrong document.
  const client = useApi(() => api.client(d!.client_id), [d?.client_id], { skip: !d });
  const artefactKind: ArtefactKind | null = client.data
    ? client.data.scenario === 'meridian'
      ? 'evidence_pack'
      : 'tmd'
    : null;

  const [showLedger, setShowLedger] = useState(false);

  return (
    <main className="min-h-dvh pb-20">
      <AppBar
        title={d ? `Decision ${d.id}` : 'Decision'}
        subtitle={d ? `${d.client_name} · ${d.asset_symbol}` : undefined}
        // A destination, not `router.back()`. This screen is reachable by deep
        // link — the PWA relaunches onto it after the phone locks mid-demo, and
        // a pasted decision URL is how the evidence gets shared — and in both
        // cases there is no history entry, so a history-back arrow is a button
        // that visibly does nothing. Going to the client the decision is about
        // is also the more useful answer even when history does exist.
        back={d ? `/clients/${d.client_id}` : '/queue'}
      />

      <div className="col space-y-6 pt-5">
        {decision.stale && <StaleNotice />}
        {decision.loading && !d && <LoadingBlock rows={3} />}
        {decision.error && !d && (
          <ErrorState message={decision.error} onRetry={decision.reload} />
        )}

        {d && (
          <>
            {/* Above the determination, not below it. A reader who has already
                taken the verdict in has stopped reading. */}
            <IllustrativeBadge
              jurisdictions={d.illustrative_jurisdictions}
              governing={d.pack_id}
            />

            <VerdictBanner
              outcome={d.outcome}
              asset={`${d.asset_symbol} · ${formatDate(d.as_of)}`}
              client={d.client_name}
              overridden={!!d.override}
              pack={`${d.pack_id} v${d.pack_version}`}
            />

            <section className="card divide-y divide-rule text-[13px]">
              {/* "Rule pack" is the truth on a single-regime decision and a
                  half-truth on a cross-border one, where three packs were read
                  and one of them decided the order. Say which. */}
              <Meta
                label={d.cross_border ? 'Governing pack' : 'Rule pack'}
                value={`${d.pack_id} v${d.pack_version}`}
                mono
              />
              {d.pack_regulator && (
                <Meta label="Regulator" value={d.pack_regulator} />
              )}
              <Meta label="Effective from" value={formatDate(d.pack_effective_from)} />
              <Meta label="Evaluated" value={formatDateTime(d.created_at)} />
              <Meta label="Record hash" value={shortHash(d.this_hash)} mono />
            </section>

            <section aria-labelledby="reasons-h">
              <h2 id="reasons-h" className="label mb-2">
                {d.reasons.length === 0
                  ? 'Findings'
                  : `Why — ${d.reasons.length} rule${d.reasons.length === 1 ? '' : 's'} did not pass` +
                    (d.cross_border
                      ? ` across ${new Set(d.reasons.map((r) => r.jurisdiction)).size} regimes`
                      : '')}
              </h2>

              {d.reasons.length === 0 ? (
                <div className="card border-allow/25 bg-allow-bg p-5">
                  <p className="text-[15px] leading-snug text-allow">
                    Every applicable rule{' '}
                    {d.cross_border
                      ? `in all ${d.jurisdictions.length} applicable packs`
                      : `in pack ${d.pack_id} v${d.pack_version}`}{' '}
                    passed. No findings were recorded against this client and asset.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {d.reasons.map((r, i) => (
                    <ReasonCard
                      key={`${r.jurisdiction ?? d.pack_id}-${r.rule_id}`}
                      reason={r}
                      index={i + 1}
                      /* The regime that raised it, not the one that governs.
                         On a cross-border BLOCK most findings come from a pack
                         that is not the licensee's, and a card stamped with the
                         governing pack would misattribute every one of them. */
                      pack={
                        r.jurisdiction
                          ? `${r.jurisdiction} v${r.pack_version}`
                          : `${d.pack_id} v${d.pack_version}`
                      }
                    />
                  ))}
                </div>
              )}
            </section>

            {d.cross_border && d.resolution && (
              <JurisdictionPanel resolution={d.resolution} jurisdictions={d.jurisdictions} />
            )}

            {d.override && (
              <section className="card border-gold/35 bg-gold-soft p-4">
                <p className="label text-gold">Override recorded</p>
                <p className="mt-2 text-[15px] leading-relaxed text-navy">
                  {d.override.justification}
                </p>
                <p className="mt-2 text-[12px] text-navy-600">
                  Approved by {d.override.approver} · {formatDateTime(d.override.created_at)}
                </p>
              </section>
            )}

            <section className="space-y-3" aria-label="Actions">
              <ArtefactButton decisionId={d.id} kind={artefactKind} />

              <Link href={`/decisions/${d.id}/evidence`} className="btn-secondary w-full">
                Evidence &amp; replay
              </Link>

              {d.outcome === 'BLOCK' && !d.override && (
                <Link href={`/decisions/${d.id}/override`} className="btn-secondary w-full">
                  Request override
                </Link>
              )}

              {d.outcome === 'REFER' && (
                <>
                  <Link href="/queue" className="btn-secondary w-full">
                    View in review queue
                  </Link>
                  {!d.override && (
                    <Link href={`/decisions/${d.id}/override`} className="btn-secondary w-full">
                      Resolve with override
                    </Link>
                  )}
                </>
              )}
            </section>

            <section>
              <button
                type="button"
                onClick={() => setShowLedger((v) => !v)}
                className="btn-secondary w-full"
                aria-expanded={showLedger}
              >
                {showLedger ? 'Hide' : 'Show'} all {d.rule_results.length} rules evaluated
              </button>
              {showLedger && (
                <div className="mt-3">
                  <RuleLedger
                    results={d.rule_results}
                    notApplicable={d.rules_not_applicable}
                  />
                </div>
              )}
            </section>
          </>
        )}
      </div>
    </main>
  );
}

function Meta({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4 px-4 py-2.5">
      <span className="text-navy-400">{label}</span>
      <span className={mono ? 'mono text-navy' : 'text-navy'}>{value}</span>
    </div>
  );
}
