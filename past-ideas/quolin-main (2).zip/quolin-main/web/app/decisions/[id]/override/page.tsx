'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { use, useState } from 'react';
import { ApiError, api } from '@/lib/api';
import { formatDate } from '@/lib/format';
import { useApi, useSession } from '@/lib/useApi';
import { AppBar } from '@/components/AppBar';
import { useReauth } from '@/components/Reauth';
import { ErrorState, LoadingBlock } from '@/components/States';
import { VerdictTag } from '@/components/Verdict';

const MIN_JUSTIFICATION = 20;

/*
 * `params` is a Promise in Next 16 and has to be unwrapped.
 *
 * It was read synchronously here, which a production build resolves to
 * `undefined` — so this screen requested the record `undefined` and rendered
 * "Unavailable" over an engine that was answering perfectly well. Every
 * dynamic route in the app had the same line. It survived because nothing
 * exercised a production build at runtime: `npm run build` compiles it without
 * complaint, and the demo and `make tunnel` both run `next dev`.
 *
 * Found by the offline regression in e2e/, which serves a production build.
 */
export default function OverridePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const router = useRouter();
  const decision = useApi(() => api.decision(id), [id]);
  const me = useSession();
  const d = decision.data;

  const [justification, setJustification] = useState('');
  const [touched, setTouched] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const reauth = useReauth();
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const trimmed = justification.trim();
  const shortBy = MIN_JUSTIFICATION - trimmed.length;
  const justificationValid = trimmed.length >= MIN_JUSTIFICATION;
  const canSubmit = justificationValid && !submitting;

  async function submit() {
    if (!canSubmit) {
      setTouched(true);
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await reauth(() => api.override(id, { justification: trimmed }));
      setDone(true);
      // Let the confirmation register before returning to the decision.
      setTimeout(() => {
        router.push(`/decisions/${id}`);
        router.refresh();
      }, 900);
    } catch (err) {
      setError(
        err instanceof ApiError ? err.message : 'The override could not be recorded.',
      );
      setSubmitting(false);
    }
  }

  return (
    <main className="min-h-dvh pb-20">
      {/* A destination rather than `router.back()`, for the same reason as the
          decision screen: reached by deep link there is no history to go back
          to, and the arrow becomes decoration. */}
      <AppBar
        title="Request override"
        subtitle={d ? `Decision ${d.id}` : undefined}
        back={`/decisions/${id}`}
      />

      <div className="col space-y-6 pt-5">
        {decision.loading && !d && <LoadingBlock rows={2} />}
        {decision.error && !d && (
          <ErrorState message={decision.error} onRetry={decision.reload} />
        )}

        {done && (
          <div className="card border-gold/35 bg-gold-soft p-5">
            <p className="label text-gold">Recorded</p>
            <p className="mt-2 text-[15px] leading-snug text-navy">
              The override has been stamped on decision {id} and added to the client&apos;s
              history.
            </p>
          </div>
        )}

        {d && !done && (
          <>
            <section className="card p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-[15px] font-medium leading-tight text-navy">
                    {d.client_name} · {d.asset_symbol}
                  </p>
                  <p className="mono mt-0.5 text-navy-400">
                    {formatDate(d.as_of)} · pack v{d.pack_version}
                  </p>
                </div>
                <VerdictTag outcome={d.outcome} />
              </div>
              {d.reasons.length > 0 && (
                <ul className="mt-3 space-y-1 border-t border-rule pt-3">
                  {d.reasons.map((r) => (
                    <li key={r.rule_id} className="text-[13px] leading-snug text-navy-600">
                      <span className="mono text-navy-400">{r.rule_id}</span>{' '}
                      {r.reason_title}
                    </li>
                  ))}
                </ul>
              )}
            </section>

            {d.override && (
              <p className="rounded-md border border-gold/35 bg-gold-soft px-4 py-3 text-[13px] leading-snug text-navy">
                An override is already recorded on this decision. Submitting again will
                replace it.
              </p>
            )}

            <section>
              <label htmlFor="justification" className="label mb-2 block">
                Justification (required)
              </label>
              <textarea
                id="justification"
                value={justification}
                onChange={(e) => setJustification(e.target.value)}
                onBlur={() => setTouched(true)}
                rows={5}
                placeholder="Set out the basis on which this determination is being overridden."
                aria-describedby="justification-help"
                className="field resize-y"
              />
              <p
                id="justification-help"
                className={`mt-1.5 text-[12px] ${
                  touched && !justificationValid ? 'text-block' : 'text-navy-400'
                }`}
              >
                {justificationValid
                  ? `${trimmed.length} characters — meets the minimum.`
                  : `Minimum ${MIN_JUSTIFICATION} characters. ${shortBy} more needed.`}
              </p>
            </section>

            {/* Shown, not chosen. This used to be a dropdown of standing
                delegates, which meant the approval carried whichever name was
                selected rather than the name of the person selecting it. */}
            <section>
              <p className="label mb-2 block">Approving as</p>
              <div className="field flex items-center justify-between gap-3">
                <span className="text-navy">
                  {me.data?.user?.display_name ?? 'Loading…'}
                </span>
                <span className="mono text-[12px] text-navy-400">
                  {me.data?.roles?.includes('approver') ? 'approver' : 'not an approver'}
                </span>
              </div>
              <p className="mt-1.5 text-[12px] leading-snug text-navy-400">
                Recorded against your account. A determination cannot be overridden by
                the person who ran it.
              </p>
            </section>

            {/* Retries the submission rather than reloading the decision: what
                failed was recording the override, and the typed justification
                is still in state, so the useful offer is "send that again". */}
            {error && <ErrorState message={error} onRetry={submit} />}

            <div className="space-y-3">
              <button
                type="button"
                onClick={submit}
                disabled={!canSubmit}
                className="btn-primary w-full"
              >
                {submitting ? 'Recording…' : 'Confirm override'}
              </button>
              <Link href={`/decisions/${id}`} className="btn-secondary block w-full text-center">
                Cancel
              </Link>
            </div>

            <p className="text-[12px] leading-snug text-navy-400">
              The override is appended to the decision record. The original determination and
              its evidence are retained unchanged.
            </p>
          </>
        )}
      </div>
    </main>
  );
}
