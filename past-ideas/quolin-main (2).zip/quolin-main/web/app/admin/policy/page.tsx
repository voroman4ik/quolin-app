'use client';

/**
 * How a new version of a rule pack reaches this firm. FP3-26.
 *
 * Q-15 recorded that nothing could set this and the endpoint answered it: a
 * firm wanting to pin their rules had to ask somebody here to run an UPDATE.
 * `PATCH /tenant/advance-policy` fixed the API half and left the screen half,
 * which is the half a customer meets — and this is the customer's headline
 * lever, the answer to "how do you control vendor changes?".
 *
 * The explanation travels with the value, because the endpoint deliberately
 * sends it. A screen that said "pinned" and nothing else would leave the fact
 * that matters — that rule content will not change under this firm without
 * somebody looking — as tribal knowledge held by whoever set it.
 *
 * Held to the same bar as moving along the adoption ladder: it is a decision
 * about whether this firm's determinations can change without anybody being
 * asked again, so the engine demands a freshly presented credential and the
 * change goes through `useReauth`.
 */

import Link from 'next/link';
import { useState } from 'react';
import { ApiError } from '@/lib/api';
import { useApi } from '@/lib/useApi';
import { admin } from '@/lib/console';
import { AppBar } from '@/components/AppBar';
import { useReauth } from '@/components/Reauth';
import { ErrorState, LoadingBlock, StaleNotice } from '@/components/States';

export default function AdvancePolicyPage() {
  const reauth = useReauth();
  const state = useApi(() => admin.advancePolicy(), []);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [changed, setChanged] = useState<string | null>(null);

  const s = state.data;

  async function choose(policy: string) {
    if (busy || policy === s?.policy) return;
    setBusy(true);
    setError(null);
    setChanged(null);
    try {
      const result = await reauth(() => admin.setAdvancePolicy(policy, s?.window_days));
      setChanged(
        `Changed from ${result.was.policy} to ${result.policy}. ` +
          `Review window ${result.window_days} days.`,
      );
      // Reloaded rather than patched from the response: PATCH answers a
      // different shape — it carries `was` and drops the catalogue — and a
      // screen that treated one as the other would render an empty list of
      // policies immediately after a successful change.
      state.reload();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'The policy was not changed.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-dvh pb-16">
      <AppBar title="Rule-version policy" subtitle="How updates reach this firm" back="/" />

      <div className="col space-y-6 pt-5">
        {state.stale && <StaleNotice />}
        {state.loading && !s && <LoadingBlock rows={2} label="Loading policy" />}
        {state.error && !s && <ErrorState message={state.error} onRetry={state.reload} />}

        {s && (
          <>
            <section className="card p-5">
              <p className="label">In force</p>
              <p className="mt-1 text-[20px] font-semibold capitalize leading-tight text-navy">
                {s.policy}
              </p>
              <p className="mt-2 text-[13px] leading-relaxed text-navy-600">{s.means}</p>
              {s.policy === 'pinned' && (
                <p className="mt-2 text-[13px] leading-relaxed text-navy-600">
                  A new version is staged for {s.window_days} days before its
                  review window closes. Nothing advances on its own when it does —
                  see{' '}
                  <Link href="/currency" className="font-medium text-gold underline">
                    regulatory currency
                  </Link>{' '}
                  for what is waiting.
                </p>
              )}
            </section>

            <section>
              <h2 className="label mb-2">Change it</h2>
              <div className="space-y-3">
                {Object.entries(s.policies).map(([name, means]) => (
                  <button
                    key={name}
                    type="button"
                    disabled={busy || name === s.policy}
                    onClick={() => choose(name)}
                    className={`card w-full p-4 text-left disabled:opacity-60 ${
                      name === s.policy ? 'border-gold/50 bg-parchment-dark' : ''
                    }`}
                  >
                    <p className="text-[15px] font-medium capitalize leading-tight text-navy">
                      {name}
                      {name === s.policy && (
                        <span className="ml-2 text-[11px] font-semibold uppercase tracking-wider2 text-gold">
                          current
                        </span>
                      )}
                      {name === s.default && name !== s.policy && (
                        <span className="ml-2 text-[11px] font-semibold uppercase tracking-wider2 text-navy-400">
                          default
                        </span>
                      )}
                    </p>
                    <p className="mt-1 text-[13px] leading-snug text-navy-600">{means}</p>
                  </button>
                ))}
              </div>
            </section>

            {changed && (
              <p className="card border-gold/40 bg-parchment-dark p-4 text-[13px] leading-snug text-navy">
                {changed}
              </p>
            )}
            {error && (
              <p className="text-[13px] leading-snug text-block" role="alert">
                {error}
              </p>
            )}

            <p className="text-[12px] leading-relaxed text-navy-400">
              Whichever is set, the change is recorded against your name in the
              audit trail with the value it replaced. Pinning does not stop a
              version arriving — it stops one applying without somebody deciding
              that it should.
            </p>
          </>
        )}
      </div>
    </main>
  );
}
