'use client';

/**
 * The firm's people, and every act that changes what they can do. FP3-26.
 *
 * Five write routes have existed since Stage 2 — provision, grant, revoke,
 * suspend, reinstate — and FP3-11 added the invitation that makes provisioning
 * mean anything. None had a screen, so the answer to "add my new compliance
 * officer" was somebody here running curl against a customer's tenant, which is
 * both an access-control problem and the reason the quarterly access review had
 * findings nobody could act on.
 *
 * **Two audiences, and the screen is not the same for both.** Reading the
 * roster is open to every role inside the firm — a firm should be able to see
 * who holds access to its own data. Every *write* belongs to `quolin_operator`,
 * which is Quolin's own operator and not the firm's, because provisioning
 * access is our act on their behalf. That is `rbac.ROUTE_ROLES`'s existing
 * decision, not a new one.
 *
 * So a firm's own staff see the roster and none of the buttons. Found by
 * walking the screen as a seeded `operator`: it offered Add someone, Grant,
 * Revoke and Suspend, and every one of them answered "Your roles do not allow
 * this". A control that exists to produce a 403 is worse than no control — it
 * tells somebody they can do a thing, lets them compose the act, and refuses at
 * the end. The same reasoning `useEngineReachable` already applies to POSTs
 * while the engine is unreachable.
 *
 * Every write here also demands a credential presented in the last few minutes,
 * so every one goes through `useReauth` — see FP3-12(b). The read does not,
 * which is what lets the screen open at all.
 */

import { useState } from 'react';
import { ApiError } from '@/lib/api';
import { formatDate, formatDateTime } from '@/lib/format';
import { useApi, useSession } from '@/lib/useApi';
import { admin } from '@/lib/console';
import { AppBar } from '@/components/AppBar';
import { useReauth } from '@/components/Reauth';
import { EmptyState, ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import type { FirmUser, ProvisionedUser } from '@/lib/console';

/**
 * The roles a person can be granted here.
 *
 * Not fetched: there is no route that lists them, and inventing one to populate
 * a dropdown would be new API surface for a cosmetic reason. The engine
 * validates the value — `POST /roles` refuses an unknown role — so a list that
 * drifts produces a clear refusal rather than a silent wrong grant.
 */
const ROLES = [
  { name: 'viewer', means: 'Reads the firm’s work. No operational permission.' },
  { name: 'operator', means: 'Runs checks, generates documents, files returns.' },
  { name: 'approver', means: 'Approves an override. Needs a second factor.' },
  {
    name: 'pack_signatory',
    means: 'Signs rule content. Needs a second factor.',
  },
  {
    name: 'tenant_admin',
    means: 'Administers the firm. Holds no operational permission, deliberately.',
  },
];

export default function UsersPage() {
  const people = useApi(() => admin.users(), []);
  const session = useSession();
  const users = people.data?.users ?? [];

  // Undefined until the session answers, and the controls stay hidden until
  // then. Flashing a button that disappears is worse than one arriving a beat
  // late, and this one would flash for every member of the firm's staff.
  const mayAdminister = session.data?.roles?.includes('quolin_operator') ?? false;

  /*
   * `granted_by` is a user id, and a raw `usr_3FT6FW8AcS5hIT-m` on the line
   * that says who handed somebody a role is the least useful place to print
   * one — that line exists to answer "who did this", and an opaque id answers
   * it only for whoever can query the database.
   *
   * Resolved from the roster this screen already holds rather than by asking
   * the engine to resolve it: the granter is almost always somebody who holds
   * a role here too. When they are not — Quolin's own operator, or the seed —
   * the id stands, which is honest: we do not know that name and should not
   * invent one.
   */
  const nameOf = (id: string) =>
    users.find((person) => person.id === id)?.display_name ?? id;

  return (
    <main className="min-h-dvh pb-16">
      <AppBar title="People" subtitle="Access and roles" back="/" />

      <div className="col space-y-6 pt-5">
        {people.stale && <StaleNotice />}

        {mayAdminister ? (
          <Invite onDone={people.reload} />
        ) : (
          <p className="text-[13px] leading-relaxed text-navy-600">
            Who holds what, and who granted it. Adding people, granting and
            revoking roles and suspending accounts are Quolin&rsquo;s to
            perform on this firm&rsquo;s behalf — ask us, and it will appear
            here with your request recorded against it.
          </p>
        )}

        {people.loading && users.length === 0 && (
          <LoadingBlock rows={3} label="Loading people" />
        )}
        {people.error && users.length === 0 && (
          <ErrorState message={people.error} onRetry={people.reload} />
        )}
        {!people.loading && !people.error && users.length === 0 && (
          <EmptyState
            title="Nobody holds a role in this firm"
            detail="Somebody with no grant here is not listed, even if they hold one elsewhere."
          />
        )}

        <div className="space-y-3">
          {users.map((person) => (
            <PersonCard
              key={person.id}
              person={person}
              onChanged={people.reload}
              mayAdminister={mayAdminister}
              nameOf={nameOf}
            />
          ))}
        </div>
      </div>
    </main>
  );
}

/**
 * Create a person and hand over the one-time link.
 *
 * The token is shown exactly once, in this component's own state, and is never
 * re-fetched. There is no route that could return it — only its digest is
 * stored — which is the whole reason hashing it is worth anything. So the copy
 * says so, and losing it means issuing another rather than asking somebody to
 * look it up.
 */
function Invite({ onDone }: { onDone: () => void }) {
  const reauth = useReauth();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ProvisionedUser | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy || email.trim() === '' || name.trim() === '') return;
    setBusy(true);
    setError(null);
    try {
      const created = await reauth(() =>
        admin.provisionUser({ email: email.trim(), display_name: name.trim() }),
      );
      setResult(created);
      setEmail('');
      setName('');
      onDone();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not create that account.');
    } finally {
      setBusy(false);
    }
  }

  if (result) {
    return (
      <section className="card border-gold/40 p-5">
        <p className="label text-gold">Account ready</p>
        <p className="mt-1 text-[15px] font-medium leading-snug text-navy">
          {result.email}
        </p>

        {result.invitation ? (
          <>
            <p className="mt-3 text-[13px] leading-relaxed text-navy-600">
              Send them this link. It lets them choose their own password — you
              never see it, and neither do we.
            </p>
            <p className="mono mt-2 select-all break-all rounded-md border border-rule bg-parchment-dark px-3 py-2 text-[12px] leading-snug text-navy">
              {inviteLink(result.invitation.token)}
            </p>
            <p className="mt-2 text-[12px] leading-snug text-block">
              Shown once. It is stored as a digest, so there is no way to read it
              back — if it is lost, create the invitation again. Expires{' '}
              {formatDateTime(result.invitation.expires_at)}.
            </p>
          </>
        ) : (
          <p className="mt-3 text-[13px] leading-relaxed text-navy-600">
            This person already had an account — a consultant compliance officer
            serves several firms and exists once. No invitation was issued
            because they already have a password. Grant them a role below.
          </p>
        )}

        <button
          type="button"
          onClick={() => {
            setResult(null);
            setOpen(false);
          }}
          className="btn-secondary mt-4 w-full"
        >
          Done
        </button>
      </section>
    );
  }

  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)} className="btn-primary w-full">
        Add someone
      </button>
    );
  }

  return (
    <section className="card p-5">
      <h2 className="text-[16px] font-semibold leading-tight text-navy">Add someone</h2>
      <form onSubmit={submit}>
        <label className="label mt-4 block" htmlFor="new-name">
          Full name
        </label>
        <input
          id="new-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="field mt-1"
          autoComplete="off"
          disabled={busy}
        />

        <label className="label mt-4 block" htmlFor="new-email">
          Work email
        </label>
        <input
          id="new-email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="field mt-1"
          autoComplete="off"
          disabled={busy}
        />

        {error && (
          <p className="mt-3 text-[13px] leading-snug text-block" role="alert">
            {error}
          </p>
        )}

        <div className="mt-4 grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="btn-secondary"
            disabled={busy}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="btn-primary disabled:opacity-40"
            disabled={busy || email.trim() === '' || name.trim() === ''}
          >
            {busy ? 'Creating…' : 'Create'}
          </button>
        </div>
      </form>
    </section>
  );
}

function inviteLink(token: string): string {
  const origin = typeof window === 'undefined' ? '' : window.location.origin;
  // The token is in the fragment, not the query string. A query string is
  // written into access logs, browser history and referrer headers, and this
  // one grants a credential — the same reasoning `SetPasswordRequest` gives for
  // keeping it out of the URL on the wire.
  return `${origin}/invite#${token}`;
}

function PersonCard({
  person,
  onChanged,
  mayAdminister,
  nameOf,
}: {
  person: FirmUser;
  onChanged: () => void;
  mayAdminister: boolean;
  nameOf: (id: string) => string;
}) {
  const reauth = useReauth();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [granting, setGranting] = useState(false);
  const [role, setRole] = useState(ROLES[0].name);

  async function act<T>(action: () => Promise<T>) {
    setBusy(true);
    setError(null);
    try {
      await reauth(action);
      onChanged();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'That did not go through.');
    } finally {
      setBusy(false);
    }
  }

  const suspended = person.status !== 'active';

  return (
    <article className="card p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-[15px] font-medium leading-tight text-navy">
            {person.display_name}
          </p>
          <p className="truncate text-[12px] leading-tight text-navy-400">{person.email}</p>
        </div>
        {suspended && (
          <span className="shrink-0 rounded-sm bg-block-bg px-2 py-1 text-[11px] font-semibold uppercase tracking-wider2 text-block">
            {person.status}
          </span>
        )}
      </div>

      <ul className="mt-3 divide-y divide-rule border-t border-rule">
        {person.roles.map((grant) => (
          <li key={grant.id} className="flex items-center gap-3 py-2">
            <div className="min-w-0 flex-1">
              <p className="text-[14px] leading-tight text-navy">
                {grant.role}
                {grant.jurisdiction && (
                  <span className="ml-1.5 text-navy-400">{grant.jurisdiction}</span>
                )}
              </p>
              {/*
                Who handed it over, and when. This is the column the quarterly
                access review is about: a grant nobody is named for is the thing
                `identity.grant_role` refuses to write.
              */}
              <p className="mt-0.5 text-[12px] leading-tight text-navy-400">
                granted by {nameOf(grant.granted_by)} · {formatDate(grant.granted_at)}
                {grant.expires_at && ` · expires ${formatDate(grant.expires_at)}`}
              </p>
            </div>
            {mayAdminister && (
              <button
                type="button"
                disabled={busy}
                onClick={() => act(() => admin.revokeRole(grant.id))}
                className="shrink-0 text-[13px] font-medium text-block underline disabled:opacity-40"
              >
                Revoke
              </button>
            )}
          </li>
        ))}
      </ul>

      {mayAdminister && person.roles.length > 0 && (
        /*
          Said here because the obvious worry about this button used to be
          correct. Revoking somebody's last grant once removed them from the
          firm's view entirely — every audit event naming them stopped
          resolving, which is the state FP3-13 built suspension to avoid.
          Migration 0047 separated belonging from holding a role, so revoking is
          now only what it says. The sentence stays because an administrator
          about to remove somebody's only role deserves to know which of the two
          things they are doing.
        */
        <p className="mt-2 text-[12px] leading-snug text-navy-400">
          Revoking removes what someone can do. It does not remove them: their
          name goes on resolving on every decision, override and audit event
          they made. Suspending is how somebody leaves.
        </p>
      )}

      {!mayAdminister ? null : granting ? (
        <div className="mt-3 border-t border-rule pt-3">
          <label className="label block" htmlFor={`role-${person.id}`}>
            Role
          </label>
          <select
            id={`role-${person.id}`}
            className="field mt-1"
            value={role}
            onChange={(e) => setRole(e.target.value)}
            disabled={busy}
          >
            {ROLES.map((r) => (
              <option key={r.name} value={r.name}>
                {r.name}
              </option>
            ))}
          </select>
          <p className="mt-1.5 text-[12px] leading-snug text-navy-400">
            {ROLES.find((r) => r.name === role)?.means}
          </p>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setGranting(false)}
              className="btn-secondary"
              disabled={busy}
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() =>
                act(() => admin.grantRole(person.id, { role })).then(() =>
                  setGranting(false),
                )
              }
              className="btn-primary disabled:opacity-40"
            >
              Grant
            </button>
          </div>
        </div>
      ) : (
        <div className="mt-3 grid grid-cols-2 gap-3 border-t border-rule pt-3">
          <button
            type="button"
            onClick={() => setGranting(true)}
            className="btn-secondary"
            disabled={busy}
          >
            Grant a role
          </button>
          <SuspendButton person={person} busy={busy} act={act} />
        </div>
      )}

      {error && (
        <p className="mt-3 text-[13px] leading-snug text-block" role="alert">
          {error}
        </p>
      )}
    </article>
  );
}

/**
 * Off-boarding, which FP3-13 made one act rather than five.
 *
 * A reason is required by the route and asked for here rather than defaulted:
 * "why is this person suspended" is the question a leaver's record has to
 * answer, and a screen that filled it in with "suspended via console" would
 * make the field worthless while looking like it was carrying its weight.
 */
function SuspendButton({
  person,
  busy,
  act,
}: {
  person: FirmUser;
  busy: boolean;
  act: <T>(action: () => Promise<T>) => Promise<void>;
}) {
  const [reason, setReason] = useState('');
  const [asking, setAsking] = useState(false);
  const suspended = person.status !== 'active';

  if (!asking) {
    return (
      <button
        type="button"
        onClick={() => setAsking(true)}
        disabled={busy}
        className={`${suspended ? 'btn-secondary' : 'btn-secondary text-block'} disabled:opacity-40`}
      >
        {suspended ? 'Reinstate' : 'Suspend'}
      </button>
    );
  }

  return (
    <div className="col-span-2">
      <label className="label block" htmlFor={`reason-${person.id}`}>
        Reason
      </label>
      <input
        id={`reason-${person.id}`}
        value={reason}
        onChange={(e) => setReason(e.target.value)}
        className="field mt-1"
        placeholder={suspended ? 'Returned from leave' : 'Left the firm on 4 March'}
        disabled={busy}
      />
      <div className="mt-3 grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() => setAsking(false)}
          className="btn-secondary"
          disabled={busy}
        >
          Cancel
        </button>
        <button
          type="button"
          disabled={busy || reason.trim() === ''}
          onClick={() =>
            act(() =>
              suspended
                ? admin.reinstateUser(person.id, reason.trim())
                : admin.suspendUser(person.id, reason.trim()),
            ).then(() => setAsking(false))
          }
          className="btn-primary disabled:opacity-40"
        >
          {suspended ? 'Reinstate' : 'Suspend'}
        </button>
      </div>
      {!suspended && (
        <p className="mt-2 text-[12px] leading-snug text-navy-400">
          Suspending ends every session this person is holding and stops them
          signing in. Their name stays on every decision, override and audit
          event they made — nothing here deletes a person, because those records
          point at them.
        </p>
      )}
    </div>
  );
}
