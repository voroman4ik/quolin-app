'use client';

import Link from 'next/link';
import { useEffect } from 'react';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Keep the detail in the console; never put a raw error object on screen.
    console.error(error);
  }, [error]);

  return (
    <main className="flex min-h-dvh items-center justify-center">
      <div className="col max-w-sm text-center">
        <p className="label text-block">Interrupted</p>
        <h1 className="mt-2 text-[22px] font-semibold tracking-tight text-navy">
          This view could not be displayed
        </h1>
        <p className="mt-2 text-[14px] leading-snug text-navy-400">
          The record was not rendered. No decision was created or altered.
        </p>
        <div className="mt-6 space-y-3">
          <button type="button" onClick={reset} className="btn-primary w-full">
            Try again
          </button>
          {/* Says dashboard because it goes to the dashboard. The label read
              "Return to queue" while pointing at `/`, which is a small lie on
              the one screen whose entire job is to be trustworthy when
              something has already gone wrong. */}
          <Link href="/" className="btn-secondary w-full">
            Return to dashboard
          </Link>
        </div>
      </div>
    </main>
  );
}
