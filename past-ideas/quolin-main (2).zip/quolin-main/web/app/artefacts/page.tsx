'use client';

/**
 * What has been asked for, what arrived, and what did not. FP3-26.
 *
 * `/artefacts/jobs` has answered since the queue landed and no screen asked it.
 * The queue exists because a hundred documents is not a request — a month-end
 * batch renders in the background while somebody waits — and until now the only
 * way to learn whether your batch had finished was to ask an engineer.
 *
 * The failures are the point. `queue.failed` keeps them rather than deleting
 * them, in its own words because "a document somebody asked for and never
 * received has to be findable, by them and by whoever is asked why it never
 * arrived". That promise was only half kept: the row survived and nothing could
 * show it to the person who asked.
 */

import { useState } from 'react';
import { ApiError, apiUrl } from '@/lib/api';
import { formatDateTime } from '@/lib/format';
import { useApi } from '@/lib/useApi';
import { admin, retryArtefactJob } from '@/lib/console';
import { AppBar } from '@/components/AppBar';
import { EmptyState, ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import type { ArtefactJob } from '@/lib/console';

const FILTERS = ['all', 'queued', 'running', 'done', 'failed'] as const;

export default function ArtefactQueuePage() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>('all');
  const queue = useApi(
    () => admin.artefactJobs(filter === 'all' ? undefined : filter),
    [filter],
  );

  const jobs = queue.data?.jobs ?? [];
  const depth = queue.data?.depth ?? {};

  return (
    <main className="min-h-dvh pb-16">
      <AppBar title="Document queue" subtitle="Batch artefact rendering" back="/" />

      <div className="col space-y-5 pt-5">
        {queue.stale && <StaleNotice />}

        <div className="grid grid-cols-4 gap-2">
          {FILTERS.filter((f) => f !== 'all').map((status) => (
            <div key={status} className="card px-3 py-3">
              <p className="text-[24px] font-semibold leading-none tracking-tight text-navy">
                {depth[status] ?? 0}
              </p>
              <p className="mt-1.5 text-[11px] capitalize leading-tight text-navy-400">
                {status}
              </p>
            </div>
          ))}
        </div>

        <div>
          <label className="label block" htmlFor="job-filter">
            Show
          </label>
          <select
            id="job-filter"
            className="field mt-1"
            value={filter}
            onChange={(e) => setFilter(e.target.value as (typeof FILTERS)[number])}
          >
            {FILTERS.map((f) => (
              <option key={f} value={f} className="capitalize">
                {f === 'all' ? 'Everything' : f}
              </option>
            ))}
          </select>
        </div>

        {queue.loading && jobs.length === 0 && <LoadingBlock rows={3} label="Loading queue" />}
        {queue.error && jobs.length === 0 && (
          <ErrorState message={queue.error} onRetry={queue.reload} />
        )}
        {!queue.loading && !queue.error && jobs.length === 0 && (
          <EmptyState
            title={filter === 'all' ? 'Nothing has been queued' : `Nothing is ${filter}`}
            detail="One document at a time still renders on the spot — this queue is for batches."
          />
        )}

        <div className="space-y-3">
          {jobs.map((job) => (
            <JobCard key={job.id} job={job} onChanged={queue.reload} />
          ))}
        </div>
      </div>
    </main>
  );
}

function JobCard({ job, onChanged }: { job: ArtefactJob; onChanged: () => void }) {
  return (
    <article className="card p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="truncate text-[15px] font-medium leading-tight text-navy">
            {job.subject || job.kind}
          </p>
          <p className="mono mt-0.5 text-navy-400">
            {job.kind} · job {job.id}
          </p>
        </div>
        <StatusChip status={job.status} />
      </div>

      <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 border-t border-rule pt-3">
        <Field label="Requested" value={formatDateTime(job.requested_at)} />
        <Field
          label="Finished"
          value={job.finished_at ? formatDateTime(job.finished_at) : '—'}
        />
        <Field label="Attempts" value={String(job.attempts)} />
        {/*
          Shown because "why is my document still pending" has a real answer.
          A period return outranks a single determination, so a batch filed at
          month-end is not stuck behind whatever somebody clicked at the same
          moment — and a person watching a queue deserves to know that rather
          than concluding it is broken.
        */}
        <Field label="Priority" value={String(job.priority)} />
      </dl>

      {job.error && (
        <p className="mono mt-3 break-words rounded-md border border-block/30 bg-block-bg px-3 py-2 text-block">
          {job.error}
        </p>
      )}

      <div className="mt-3 flex gap-3">
        {job.download_url && (
          <a
            href={apiUrl(job.download_url)}
            target="_blank"
            rel="noopener"
            className="btn-primary flex-1"
          >
            Download
          </a>
        )}
        {job.status === 'failed' && <RetryButton job={job} onChanged={onChanged} />}
      </div>
    </article>
  );
}

/**
 * Ask for it again.
 *
 * Not a "retry" route: `enqueue` already treats a *finished* job as no reason
 * to suppress a new one, and rendering is deterministic, so asking again is
 * exactly what a retry is. What this sends is the original request rebuilt from
 * `params` — the same keys `/artefacts/batch` takes — rather than a sentence
 * parsed out of `subject`.
 *
 * A new job row, not a resurrected one. The failure stays on file with its
 * error, because it is the answer to "why did this not arrive on the day it was
 * due", and a retry that erased it would erase that too.
 */
function RetryButton({ job, onChanged }: { job: ArtefactJob; onChanged: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function retry() {
    setBusy(true);
    setError(null);
    try {
      await retryArtefactJob(job);
      onChanged();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not queue it again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex-1">
      <button
        type="button"
        onClick={retry}
        disabled={busy}
        className="btn-secondary w-full disabled:opacity-40"
      >
        {busy ? 'Queueing…' : 'Ask again'}
      </button>
      {error && (
        <p className="mt-2 text-[12px] leading-snug text-block" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="label">{label}</dt>
      <dd className="mt-0.5 text-[13px] leading-tight text-navy">{value}</dd>
    </div>
  );
}

function StatusChip({ status }: { status: string }) {
  const tone =
    status === 'failed'
      ? 'bg-block-bg text-block'
      : status === 'done'
        ? 'bg-allow-bg text-allow'
        : 'bg-parchment-dark text-navy-600';
  return (
    <span
      className={`shrink-0 rounded-sm px-2 py-1 text-[11px] font-semibold uppercase tracking-wider2 ${tone}`}
    >
      {status}
    </span>
  );
}
