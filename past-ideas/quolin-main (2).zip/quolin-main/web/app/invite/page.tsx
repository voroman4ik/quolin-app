'use client';

/**
 * The other end of an invitation. FP3-11, reached from FP3-26.
 *
 * FP3-11 gave `POST /admin/users` an invitation token and `POST
 * /auth/set-password` a way to spend it, which fixed "the first customer's
 * first user could be created and could never sign in" at the API. It did not
 * fix it for a person: the token came back as JSON to an administrator running
 * curl, and there was nowhere to send it.
 *
 * So this exists alongside the administration screen rather than after it. An
 * invitation somebody has to paste into a terminal is the same defect wearing a
 * different hat.
 *
 * **Outside `AuthGate`, necessarily.** The person arriving here has no session
 * and cannot get one — that is what they are here to fix. The gate renders the
 * lock screen for exactly this case, so the page reads its token from the URL
 * fragment and talks to a public route.
 *
 * **The token is in the fragment, not the query string.** A fragment is not sent
 * to the server, not written into access logs, and not put in a `Referer`
 * header. `SetPasswordRequest` gives the same reasoning for keeping it out of
 * the URL on the wire, and a link that leaked its own credential into three log
 * files would undo that.
 */

import { useEffect, useState } from 'react';
import { ApiError, api } from '@/lib/api';
import { Wordmark } from '@/components/AppBar';

/** Long enough to be rejected by the schema's `min_length` before a round trip. */
const MIN_PASSWORD = 12;

export default function InvitePage() {
  /*
   * Three states, and both of the wrong ways to do this were tried in a browser.
   *
   *   undefined — not looked yet. The server pass, and the first client paint.
   *   null      — looked, and there is no token.
   *   string    — the token.
   *
   * The distinction is not pedantry. A page that starts at `null` renders
   * "Nothing to accept" for a moment to somebody holding a perfectly good link,
   * which is the worst possible first impression on a screen whose entire job
   * is to be trusted with a password.
   *
   * **Why not a lazy `useState` initialiser.** Because this page is
   * prerendered: on the server `window` does not exist, so the initialiser
   * returns null, and hydration keeps the server's state rather than re-running
   * it. Tried, and it rendered "Nothing to accept" against a live link.
   *
   * **Why the functional update.** The effect clears the hash once it has read
   * it, and React invokes effects twice in development — so a plain
   * `setToken(raw || null)` had the second pass read the now-empty hash and
   * overwrite a good token with null. `prev ?? …` makes the first read win.
   */
  const [token, setToken] = useState<string | null | undefined>(undefined);
  const [password, setPassword] = useState('');
  const [again, setAgain] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const raw = window.location.hash.replace(/^#/, '').trim();
    setToken((prev) => prev ?? (raw || null));
    if (!raw) return;

    /*
     * Get it out of the address bar, and keep checking that it stayed out.
     *
     * The token is in the fragment so it never reaches a server log, a
     * `Referer` header or a proxy. That argument covers the wire and says
     * nothing about the screen: a live credential sitting in the address bar is
     * in the browser's history, in every screenshot, and visible to whoever
     * walks past.
     *
     * Clearing it is not one call, and this was established by watching it fail
     * in a browser rather than by reasoning. A bare `history.replaceState` in
     * this effect is undone — the App Router syncs its own history entry during
     * hydration, which happens after effects run, and puts the fragment back.
     * `router.replace(pathname)` does not remove it either: a hash-only
     * difference is not a navigation as far as the router is concerned. Both
     * were tried; the fragment was still there two seconds later, polled.
     *
     * So: clear it, then verify, for a second. Bounded and self-cancelling — it
     * stops the moment the fragment is gone, and on unmount. A fixed
     * `setTimeout` would be the same race with the failure mode hidden.
     */
    const clear = () => window.history.replaceState(null, '', window.location.pathname);
    clear();
    let attempts = 0;
    const timer = window.setInterval(() => {
      attempts += 1;
      if (window.location.hash === '') {
        window.clearInterval(timer);
        return;
      }
      clear();
      if (attempts >= 20) window.clearInterval(timer);
    }, 50);
    return () => window.clearInterval(timer);
  }, []);

  const ready =
    !!token && password.length >= MIN_PASSWORD && password === again && !busy;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!ready || !token) return;
    setBusy(true);
    setError(null);
    try {
      await api.setPassword(token, password);
      setDone(true);
    } catch (err) {
      setError(
        err instanceof ApiError
          ? err.message
          : 'That did not work. The link may have been used already.',
      );
    } finally {
      setBusy(false);
      setPassword('');
      setAgain('');
    }
  }

  return (
    <main className="flex min-h-dvh flex-col justify-center bg-navy px-6 py-10">
      <div className="mx-auto w-full max-w-sm">
        <div className="mb-6 text-parchment">
          <Wordmark />
        </div>

        <div className="card p-6">
          {done ? (
            <>
              <h1 className="text-[18px] font-semibold leading-tight text-navy">
                You&rsquo;re set
              </h1>
              <p className="mt-2 text-[13px] leading-relaxed text-navy-600">
                Your password is saved. Sign in with your work email — and if
                your role needs a second factor, you will be asked to set up an
                authenticator before anything else.
              </p>
              <a href="/" className="btn-primary mt-5 w-full">
                Sign in
              </a>
            </>
          ) : token === undefined ? (
            // Looked-at-nothing yet. Deliberately blank rather than either
            // message: this lasts one paint, and both alternatives would be a
            // claim we cannot support for it.
            <p className="text-[13px] leading-relaxed text-navy-400">Opening your invitation…</p>
          ) : token === null ? (
            <>
              <h1 className="text-[18px] font-semibold leading-tight text-navy">
                Nothing to accept
              </h1>
              <p className="mt-2 text-[13px] leading-relaxed text-navy-600">
                This page needs the whole invitation link, including the part
                after the <span className="mono">#</span>. Open the link you were
                sent rather than typing this address, and if it has already been
                used ask for another — an invitation can be spent once.
              </p>
            </>
          ) : (
            <>
              <h1 className="text-[18px] font-semibold leading-tight text-navy">
                Choose a password
              </h1>
              <p className="mt-2 text-[13px] leading-relaxed text-navy-600">
                Nobody else sees this, including whoever invited you. Quolin
                stores what it needs to check the password and not the password.
              </p>

              <form onSubmit={submit}>
                <label className="label mt-5 block" htmlFor="invite-password">
                  New password
                </label>
                <input
                  id="invite-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="field mt-1"
                  autoComplete="new-password"
                  autoFocus
                  disabled={busy}
                />
                <p className="mt-1.5 text-[12px] leading-snug text-navy-400">
                  At least {MIN_PASSWORD} characters. Length is what matters —
                  there is no rule here about symbols, because a rule about
                  symbols is how people end up with one password and a keyboard
                  pattern.
                </p>

                <label className="label mt-4 block" htmlFor="invite-again">
                  Again
                </label>
                <input
                  id="invite-again"
                  type="password"
                  value={again}
                  onChange={(e) => setAgain(e.target.value)}
                  className="field mt-1"
                  autoComplete="new-password"
                  disabled={busy}
                />
                {again !== '' && again !== password && (
                  <p className="mt-1.5 text-[12px] leading-snug text-block">
                    These do not match.
                  </p>
                )}

                {error && (
                  <p className="mt-3 text-[13px] leading-snug text-block" role="alert">
                    {error}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={!ready}
                  className="btn-primary mt-4 w-full disabled:opacity-40"
                >
                  {busy ? 'Saving…' : 'Save and continue'}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </main>
  );
}
