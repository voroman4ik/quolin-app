'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import { formatDate, humanizeCode } from '@/lib/format';
import { scenarioMeta, useScenario } from '@/lib/scenario';
import { useApi } from '@/lib/useApi';
import { Wordmark } from '@/components/AppBar';
import AdoptionBadge from '@/components/AdoptionBadge';
import ChainBadge from '@/components/ChainBadge';
import { Chevron } from '@/components/DecisionRow';
import ScenarioSwitcher from '@/components/ScenarioSwitcher';
import { EmptyState, ErrorState, Skeleton } from '@/components/States';

export default function HomePage() {
  const { scenario, ready } = useScenario();
  const meta = scenarioMeta(scenario);

  const dash = useApi(() => api.dashboard(scenario), [scenario], { skip: !ready });
  const cast = useApi(() => api.castClients(scenario), [scenario], { skip: !ready });

  /*
   * Warm the offline cache for the screens the demo will reach for next.
   * The shelf is walked rather than a code being named here: a regime added to
   * the shelf should reach the offline cache without a line changing in the UI.
   */
  useEffect(() => {
    if (!ready) return;
    void api.assets().catch(() => {});
    void api.queue().catch(() => {});
    void api
      .packShelf()
      .then(({ data }) =>
        Promise.all(data.map((e) => api.pack(e.jurisdiction).catch(() => {}))),
      )
      .catch(() => {});
  }, [ready]);

  const d = dash.data;

  return (
    <main className="min-h-dvh pb-16">
      <header className="bg-navy pb-5 pt-4 text-parchment">
        <div className="col space-y-4">
          <div className="flex items-start justify-between gap-3">
            <Wordmark />
            <span className="mt-1 text-[11px] uppercase tracking-wider2 text-parchment/45">
              Decision engine
            </span>
          </div>

          <ScenarioSwitcher />

          <div>
            <p className="text-[13px] leading-snug text-parchment/70">{meta.name}</p>
            <p className="text-[12px] leading-snug text-parchment/45">
              Artefact type: {meta.artefact_label}
            </p>
          </div>

          {dash.loading && !d ? (
            <Skeleton className="h-[52px] w-full" />
          ) : (
            <ChainBadge chain={d?.chain} tone="dark" stale={dash.stale} />
          )}

          {/* FP3-26. Above the numbers, not below them: on a firm in `shadow`
              every figure on this screen describes work nobody is acting on,
              and that has to be read before the figures rather than after. */}
          <AdoptionBadge tone="dark" />
        </div>
      </header>

      <div className="col space-y-7 pt-6">
        {dash.error && !d ? (
          <ErrorState message={dash.error} onRetry={dash.reload} />
        ) : (
          <section aria-label="Today">
            <div className="grid grid-cols-3 gap-3">
              <Stat label="Decisions today" value={d?.decisions_today} loading={dash.loading && !d} />
              <Stat label="REFERs pending" value={d?.refers_pending} loading={dash.loading && !d} accent={!!d?.refers_pending} />
              <Stat label="Overrides (mo.)" value={d?.overrides_this_month} loading={dash.loading && !d} />
            </div>
            {d && (
              <p className="mt-3 text-[12px] text-navy-400">
                {d.decisions_total} decisions on file · {d.allows_total} allowed ·{' '}
                {d.blocks_total} blocked
              </p>
            )}
          </section>
        )}

        {/* The six hand-crafted clients drive the demo — one tap from home. */}
        <section aria-labelledby="clients-h">
          <SectionHead id="clients-h" title="Clients" href="/clients" hrefLabel="All clients" />
          <div className="card divide-y divide-rule">
            {cast.loading && !cast.data && (
              <div className="space-y-2 p-4">
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            )}
            {cast.error && !cast.data && (
              <div className="p-4">
                <ErrorState message={cast.error} onRetry={cast.reload} />
              </div>
            )}
            {cast.data?.length === 0 && (
              <div className="p-4">
                <EmptyState title="No clients for this scenario" />
              </div>
            )}
            {cast.data?.map((c) => (
              <Link key={c.id} href={`/clients/${c.id}`} className="row-link">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[15px] font-medium leading-tight text-navy">
                    {c.name}
                  </p>
                  {c.note && (
                    <p className="mt-0.5 line-clamp-2 text-[12px] leading-snug text-navy-400">
                      {c.note}
                    </p>
                  )}
                </div>
                {c.vulnerability_flag && (
                  <span className="shrink-0 rounded-sm bg-refer-bg px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider2 text-refer">
                    Vuln
                  </span>
                )}
                <Chevron />
              </Link>
            ))}
          </div>
        </section>

        <section aria-labelledby="pending-h">
          <SectionHead id="pending-h" title="Pending review" href="/queue" hrefLabel="Full queue" />
          <div className="card divide-y divide-rule">
            {dash.loading && !d && (
              <div className="space-y-2 p-4">
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            )}
            {d && d.pending.length === 0 && (
              <div className="p-4">
                <EmptyState
                  title="Nothing awaiting review"
                  detail="Every referral for this scenario has been resolved."
                />
              </div>
            )}
            {/* When the dashboard fetch fails there is no `d`, so neither the
                skeleton nor the empty state nor the rows render, and this card
                collapses to an empty bordered box under a live-looking heading.
                An empty queue and an unreadable one must not look the same. */}
            {dash.error && !d && (
              <div className="p-4">
                <ErrorState message={dash.error} onRetry={dash.reload} />
              </div>
            )}
            {d?.pending.map((p) => (
              <Link key={p.decision_id} href={`/decisions/${p.decision_id}`} className="row-link">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[15px] font-medium leading-tight text-navy">
                    {p.client_name}
                    <span className="mono ml-2 text-navy-400">{p.asset_id}</span>
                  </p>
                  <p className="mt-0.5 truncate text-[12px] leading-tight text-navy-400">
                    {formatDate(p.as_of)} ·{' '}
                    {p.reason_codes.map(humanizeCode).join(', ') || 'Referred'}
                  </p>
                </div>
                <span className="shrink-0 rounded-sm bg-refer-bg px-2 py-1 text-[11px] font-semibold uppercase tracking-wider2 text-refer">
                  Refer
                </span>
                <Chevron />
              </Link>
            ))}
          </div>
        </section>

        <nav className="grid grid-cols-2 gap-3 pt-1">
          <Link href="/packs" className="btn-secondary">
            Rule packs
          </Link>
          <Link href="/reports" className="btn-secondary">
            Reporting
          </Link>
          {/* Next to the pack shelf, not buried under it. "Which rules do we
              enforce" and "are those rules still current" are the same question
              asked twice, and a viewer who finds only the first has been told
              half of it. */}
          <Link href="/currency" className="btn-secondary col-span-2">
            Regulatory currency
          </Link>
          {/* In the main navigation on purpose: a boundary a viewer has to go
              looking for is one they find after they have already believed a
              number that depended on it. */}
          <Link href="/runs" className="btn-secondary">
            Delta reports
          </Link>
          <Link href="/artefacts" className="btn-secondary">
            Document queue
          </Link>
          <Link href="/admin/users" className="btn-secondary">
            People
          </Link>
          <Link href="/admin/policy" className="btn-secondary">
            Rule-version policy
          </Link>
          <Link href="/integrations" className="btn-secondary col-span-2">
            What&rsquo;s real, what&rsquo;s mocked
          </Link>
          <Link href="/clients" className="btn-primary col-span-2">
            Check an asset
          </Link>
        </nav>

        <SignOut />

        {dash.stale && (
          <p className="text-center text-[12px] text-navy-400">
            Showing cached figures — engine unreachable.
          </p>
        )}
      </div>
    </main>
  );
}

/**
 * Signing out, and saying what it actually does.
 *
 * The sentence under the button is there because "sign out" on most web apps
 * means "forget my cookie". Here it also destroys the offline cache, which is
 * the copy of the client records this device has been keeping so the demo
 * survives bad Wi-Fi. That is the part worth stating: it is the difference
 * between logging out and leaving the data on a phone in a taxi.
 */
function SignOut() {
  const [busy, setBusy] = useState(false);
  return (
    <div className="border-t border-rule pt-5">
      <button
        type="button"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          await api.logout();
          setBusy(false);
        }}
        className="btn-secondary w-full disabled:opacity-40"
      >
        {busy ? 'Signing out…' : 'Sign out'}
      </button>
      <p className="mt-2 text-center text-[12px] leading-snug text-navy-400">
        Ends the session on the engine and deletes every record cached on this
        device for offline use.
      </p>
    </div>
  );
}

function SectionHead({
  id,
  title,
  href,
  hrefLabel,
}: {
  id: string;
  title: string;
  href: string;
  hrefLabel: string;
}) {
  return (
    <div className="mb-2 flex items-baseline justify-between">
      <h2 id={id} className="label">
        {title}
      </h2>
      <Link href={href} className="text-[12px] font-medium text-gold">
        {hrefLabel}
      </Link>
    </div>
  );
}

function Stat({
  label,
  value,
  loading,
  accent,
}: {
  label: string;
  value?: number;
  loading?: boolean;
  accent?: boolean;
}) {
  return (
    <div className="card px-3 py-3">
      {loading ? (
        <Skeleton className="h-8 w-10" />
      ) : (
        <p
          className={`text-[30px] font-semibold leading-none tracking-tight ${
            accent ? 'text-refer' : 'text-navy'
          }`}
        >
          {value ?? '—'}
        </p>
      )}
      <p className="mt-1.5 text-[11px] leading-tight text-navy-400">{label}</p>
    </div>
  );
}
