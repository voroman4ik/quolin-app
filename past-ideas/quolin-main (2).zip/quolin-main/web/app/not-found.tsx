import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="flex min-h-dvh items-center justify-center">
      <div className="col max-w-sm text-center">
        <p className="label">Not found</p>
        <h1 className="mt-2 text-[22px] font-semibold tracking-tight text-navy">
          That record does not exist
        </h1>
        <p className="mt-2 text-[14px] leading-snug text-navy-400">
          The decision, client or page you followed is not on file.
        </p>
        <Link href="/" className="btn-primary mt-6 w-full">
          Return to dashboard
        </Link>
      </div>
    </main>
  );
}
