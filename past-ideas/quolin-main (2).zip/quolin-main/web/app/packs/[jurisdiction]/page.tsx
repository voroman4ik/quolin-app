'use client';

import { use } from 'react';

/**
 * The same shelf, opened on a named regime.
 *
 * This route exists because the draft screen links to it: sign a pack, publish
 * it, and the confirmation offers to show you the pack you just put in force.
 * Before Phase 6 that link pointed at a route nobody had written, so the one
 * tap at the end of the regulatory-currency walkthrough landed on "not found".
 *
 * The code is not validated here. An unknown jurisdiction falls through to the
 * pack fetch, which 404s, and the screen renders its own error with a retry —
 * a better answer than this file guessing at the list of valid regimes, which
 * is content and lives in the packs, not in the web app.
 */

import PacksScreen from '@/components/PacksScreen';

/*
 * `params` is a Promise in Next 16 and has to be unwrapped.
 *
 * It was read synchronously here, which a production build resolves to
 * `undefined` — so this screen requested the record `undefined` and rendered
 * "Unavailable" over an engine that was answering perfectly well. Every
 * dynamic route in the app had the same line. It survived because nothing
 * exercised a production build at runtime: `npm run build` compiles it without
 * complaint, and the demo and `make tunnel` both run `next dev`.
 *
 * Found by the offline regression in e2e/, which serves a production build.
 */
export default function PacksForJurisdictionPage({
  params,
}: {
  params: Promise<{ jurisdiction: string }>;
}) {
  const { jurisdiction } = use(params);
  return <PacksScreen initial={decodeURIComponent(jurisdiction).toUpperCase()} />;
}
