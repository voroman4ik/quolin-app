'use client';

/**
 * S6 — the pack shelf, opened on whichever regime has governed the most
 * decisions. The screen itself is `components/PacksScreen`, shared with
 * `/packs/[jurisdiction]`.
 */

import PacksScreen from '@/components/PacksScreen';

export default function PacksPage() {
  return <PacksScreen />;
}
