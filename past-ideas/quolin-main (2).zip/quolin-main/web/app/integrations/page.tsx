'use client';

/*
 * The screen that says what is not real.
 *
 * It sits deliberately in the main navigation rather than behind an "about"
 * link. A boundary a viewer has to go looking for is a boundary they will find
 * at the wrong moment — usually after they have already believed a number that
 * depended on it. Everything here is fetched from the engine rather than
 * written into this file, so a label cannot quietly stop being true.
 */

import { useRef, useState } from 'react';
import { ApiError, api } from '@/lib/api';
import { useApi } from '@/lib/useApi';
import { AppBar } from '@/components/AppBar';
import { ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import type { ImportResult, IntegrationEdge, IntegrationStatus } from '@/lib/types';

const STATUS_LABEL: Record<IntegrationStatus, string> = {
  live: 'Real',
  fixture: 'Fixture',
  local: 'Local only',
};

/*
 * Deliberately not the verdict palette. ALLOW/REFER/BLOCK green, amber and red
 * mean a determination and nothing else; reusing them here would make a mocked
 * integration read as a compliance outcome.
 */
const STATUS_STYLE: Record<IntegrationStatus, string> = {
  live: 'bg-parchment-dark text-navy-600 border-rule-strong',
  fixture: 'bg-gold-soft text-gold border-gold/40',
  local: 'bg-parchment text-navy-400 border-rule',
};

export default function IntegrationsPage() {
  const state = useApi(() => api.integrations(), []);

  return (
    <>
      <AppBar title="Integrations" back="/" />
      <main className="mx-auto w-full max-w-3xl px-4 pb-28 pt-4">
        <p className="text-sm leading-relaxed text-navy-600">
          Every external edge this system has, and what stands in for it. This page is
          generated from the running engine, not written by hand.
        </p>

        {state.stale && <StaleNotice />}
        {state.loading && <LoadingBlock />}
        {state.error && <ErrorState message={state.error} onRetry={state.reload} />}

        {state.data && (
          <>
            <div className="mt-4 rounded-lg border border-rule bg-white p-4">
              <div className="flex gap-6">
                <Count value={state.data.live} label="Real" />
                <Count value={state.data.mocked} label="Standing in" />
              </div>
              <p className="mt-3 text-xs leading-relaxed text-navy-600">
                {state.data.statement}
              </p>
            </div>

            <ul className="mt-4 space-y-3">
              {state.data.edges.map((edge) => (
                <EdgeCard key={edge.id} edge={edge} />
              ))}
            </ul>

            <ImportPanel onImported={state.reload} />
          </>
        )}
      </main>
    </>
  );
}

function Count({ value, label }: { value: number; label: string }) {
  return (
    <div>
      <div className="font-mono text-2xl text-navy">{value}</div>
      <div className="text-xs uppercase tracking-wide text-navy-400">{label}</div>
    </div>
  );
}

function EdgeCard({ edge }: { edge: IntegrationEdge }) {
  return (
    <li className="rounded-lg border border-rule bg-white p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="font-medium text-navy">{edge.name}</h2>
          <p className="text-xs text-navy-400">{edge.stands_for}</p>
        </div>
        <span
          className={`shrink-0 rounded border px-2 py-0.5 text-xs font-medium ${
            STATUS_STYLE[edge.status]
          }`}
        >
          {STATUS_LABEL[edge.status]}
        </span>
      </div>

      <p className="mt-3 text-sm leading-relaxed text-navy-600">{edge.detail}</p>

      {/* The cost of believing the mock. Given its own block so it cannot be
          skimmed past as part of the description. */}
      {edge.consequence && (
        <p className="mt-2 border-l-2 border-gold bg-gold-soft px-3 py-2 text-sm leading-relaxed text-navy-800">
          {edge.consequence}
        </p>
      )}

      <dl className="mt-3 space-y-1 text-xs text-navy-600">
        <Row term="Implementation" value={<code className="font-mono">{edge.implementation}</code>} />
        <Row term="Data arrives by" value={edge.how_data_gets_in} />
        {edge.replaced_by && <Row term="Replaced by" value={edge.replaced_by} />}
        {typeof edge.clients_without_records === 'number' &&
          edge.clients_without_records > 0 && (
            <Row
              term="Clients with no record"
              value={`${edge.clients_without_records} — assessed as holding nothing`}
            />
          )}
      </dl>
    </li>
  );
}

function Row({ term, value }: { term: string; value: React.ReactNode }) {
  return (
    <div className="flex gap-2">
      <dt className="w-40 shrink-0 text-navy-400">{term}</dt>
      <dd className="text-navy-600">{value}</dd>
    </div>
  );
}

/* ----------------------------- CSV import ----------------------------- */

/*
 * Import lives on this screen rather than its own, because it is the answer to
 * the question this screen raises. A viewer reads "client records are seeded
 * here, not synchronised with a CRM" and immediately asks how their own book
 * would get in. The answer should be in the same place as the caveat.
 */
function ImportPanel({ onImported }: { onImported: () => void }) {
  const [text, setText] = useState('');
  const [result, setResult] = useState<ImportResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  async function run(commit: boolean) {
    setBusy(true);
    setError(null);
    try {
      const body = await api.importClients(text, commit);
      setResult(body);
      if (body.committed) onImported();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Import failed.');
      setResult(null);
    } finally {
      setBusy(false);
    }
  }

  async function onFile(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    setText(await file.text());
    setResult(null);
    setError(null);
  }

  const canPreview = text.trim().length > 0 && !busy;
  /* Commit is offered only once a preview has come back clean. Importing a file
     nobody has looked at is how a book arrives in a state nobody chose. */
  const canCommit = Boolean(result && result.ok && !result.committed) && !busy;

  return (
    <section className="mt-6 rounded-lg border border-rule bg-white p-4">
      <h2 className="text-xs font-medium uppercase tracking-wide text-navy-400">
        Import a client book
      </h2>
      <p className="mt-2 text-sm leading-relaxed text-navy-600">
        CSV, one client per row. Every row is validated before anything is written, and
        a file with any bad row writes nothing — a half-imported book leaves a state
        nobody chose.
      </p>

      <div className="mt-3 flex flex-wrap gap-2">
        <input
          ref={fileRef}
          type="file"
          accept=".csv,text/csv"
          onChange={onFile}
          className="hidden"
        />
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="btn-secondary min-h-[44px]"
        >
          Choose CSV file
        </button>
        <button
          type="button"
          onClick={() => run(false)}
          disabled={!canPreview}
          className="btn-secondary min-h-[44px] disabled:opacity-40"
        >
          {busy ? 'Checking…' : 'Validate'}
        </button>
        <button
          type="button"
          onClick={() => run(true)}
          disabled={!canCommit}
          className="btn-primary min-h-[44px] disabled:opacity-40"
        >
          Import
        </button>
      </div>

      <textarea
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          setResult(null);
        }}
        rows={5}
        spellCheck={false}
        placeholder="id,scenario,name,dob,client_category,…"
        className="mt-3 w-full rounded border border-rule-strong p-2 font-mono text-xs"
      />

      {error && (
        <p className="mt-3 rounded border border-block/30 bg-block-bg px-3 py-2 text-sm text-block">
          {error}
        </p>
      )}

      {result && <ImportOutcome result={result} />}
    </section>
  );
}

function ImportOutcome({ result }: { result: ImportResult }) {
  return (
    <div className="mt-3 rounded border border-rule bg-parchment p-3">
      <p className="text-sm font-medium text-navy">
        {result.committed
          ? `Imported ${result.valid_rows} of ${result.total_rows} rows.`
          : result.ok
            ? `${result.total_rows} rows checked, all valid. Nothing written yet.`
            : `${result.rejected_rows} of ${result.total_rows} rows rejected. Nothing written.`}
      </p>

      {result.ok && (
        <p className="mt-1 text-xs text-navy-600">
          {result.new_clients} new, {result.updated_clients} updated.
          {result.updated_clients > 0 &&
            ' Updating a client does not change any determination already recorded — each decision was frozen with the inputs it was made from.'}
        </p>
      )}

      {result.errors.length > 0 && (
        <table className="mt-3 w-full text-left text-xs">
          <thead className="text-navy-400">
            <tr>
              <th className="w-12 pb-1 font-medium">Row</th>
              <th className="w-40 pb-1 font-medium">Column</th>
              <th className="pb-1 font-medium">Problem</th>
            </tr>
          </thead>
          <tbody className="align-top font-mono text-navy-600">
            {result.errors.map((e, i) => (
              <tr key={i} className="border-t border-rule">
                <td className="py-1">{e.row}</td>
                <td className="py-1">{e.column}</td>
                <td className="py-1 font-sans">{e.message}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* Shown on every outcome, not only the successful one. */}
      <p className="mt-3 border-l-2 border-gold bg-gold-soft px-3 py-2 text-xs leading-relaxed text-navy-800">
        {result.custody_warning}
      </p>
    </div>
  );
}
