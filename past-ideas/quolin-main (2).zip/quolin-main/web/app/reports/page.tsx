'use client';

import { useMemo, useState } from 'react';
import { ApiError, api, apiUrl } from '@/lib/api';
import { formatDate, formatDateTime } from '@/lib/format';
import { scenarioMeta, useScenario } from '@/lib/scenario';
import { useApi } from '@/lib/useApi';
import { AppBar } from '@/components/AppBar';
import { EmptyState, ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import type {
  OverridePreview,
  ReportArtefact,
  ReportKind,
  ReportPeriod,
  ReturnPreview,
} from '@/lib/types';

const KINDS: { id: ReportKind; tab: string; blurb: string }[] = [
  {
    id: 'regulatory_return',
    tab: 'Distribution',
    blurb:
      'Determinations made in the period, the findings behind them, and the rule pack versions applied.',
  },
  {
    id: 'override_report',
    tab: 'Overrides',
    blurb:
      'Every determination a named approver overrode in the period, with the justification and the findings it displaced.',
  },
];

export default function ReportsPage() {
  const { scenario, ready } = useScenario();
  const meta = scenarioMeta(scenario);

  const [kind, setKind] = useState<ReportKind>('regulatory_return');
  const [period, setPeriod] = useState<string | null>(null);

  const periods = useApi(() => api.reportPeriods(scenario), [scenario], {
    skip: !ready,
  });

  /*
   * Quarters are offered alongside months because a quarter is the period a
   * compliance calendar actually runs on. They are derived from the months the
   * engine reported rather than from the calendar, so a quarter is only ever
   * offered when at least one of its months holds determinations.
   */
  const options = useMemo(() => buildOptions(periods.data ?? []), [periods.data]);

  /* Switching book can strand a period that only the other book had data in. */
  const stillOffered = period && options.some((o) => o.period === period);
  const selected = (stillOffered ? period : options[0]?.period) ?? null;

  const preview = useApi(
    () => api.reportPreview(kind, selected!, scenario),
    [kind, selected, scenario],
    { skip: !ready || !selected },
  );

  const active = KINDS.find((k) => k.id === kind)!;

  return (
    <main className="min-h-dvh pb-20">
      <AppBar title="Reporting" subtitle={meta.name} back="/" />

      <div className="col space-y-6 pt-5">
        {(periods.stale || preview.stale) && <StaleNotice />}

        <section aria-label="Document type">
          <div className="flex rounded-md border border-rule-strong bg-white p-1">
            {KINDS.map((k) => (
              <button
                key={k.id}
                type="button"
                onClick={() => setKind(k.id)}
                aria-pressed={kind === k.id}
                className={`tap flex-1 rounded-[3px] px-3 text-[14px] font-medium transition-colors ${
                  kind === k.id
                    ? 'bg-navy text-parchment'
                    : 'text-navy-600 hover:bg-parchment-dark'
                }`}
              >
                {k.tab}
              </button>
            ))}
          </div>
          <p className="mt-2 text-[13px] leading-snug text-navy-400">{active.blurb}</p>
        </section>

        <section aria-labelledby="period-h">
          <h2 id="period-h" className="label mb-2">
            Period
          </h2>
          {periods.loading && !periods.data && <LoadingBlock rows={1} />}
          {periods.error && !periods.data && (
            <ErrorState message={periods.error} onRetry={periods.reload} />
          )}
          {/* `!periods.error` matters: without it a failed fetch renders the
              error and then "No determinations have been recorded yet"
              underneath it, the second confidently contradicting the first.
              We do not know there are none — we know we could not ask. */}
          {options.length === 0 && !periods.loading && !periods.error && (
            <EmptyState
              title="No periods to report on"
              detail="No determinations have been recorded yet."
            />
          )}
          {options.length > 0 && (
            <select
              value={selected ?? ''}
              onChange={(e) => setPeriod(e.target.value)}
              className="field"
              aria-label="Reporting period"
            >
              {options.map((o) => (
                <option key={o.period} value={o.period}>
                  {o.label} — {o.decisions} determination{o.decisions === 1 ? '' : 's'}
                </option>
              ))}
            </select>
          )}
        </section>

        {preview.loading && !preview.data && <LoadingBlock rows={2} />}
        {preview.error && !preview.data && (
          <ErrorState message={preview.error} onRetry={preview.reload} />
        )}

        {preview.data && (
          <>
            <section aria-labelledby="figures-h">
              <h2 id="figures-h" className="label mb-2">
                What the document will contain
              </h2>
              {preview.data.kind === 'regulatory_return' ? (
                <ReturnFigures report={preview.data as ReturnPreview} />
              ) : (
                <OverrideFigures report={preview.data as OverridePreview} />
              )}
            </section>

            <PackProvenance report={preview.data} />

            <GenerateButton
              kind={kind}
              period={selected!}
              scenarioId={scenario}
              label={active.tab}
            />
          </>
        )}

        <AuditExport />
      </div>
    </main>
  );
}

/* ------------------------------ figures ------------------------------ */

function ReturnFigures({ report }: { report: ReturnPreview }) {
  if (report.decisions_total === 0) {
    return (
      <EmptyState
        title="No determinations in this period"
        detail={`Nothing was assessed between ${formatDate(report.period_start)} and ${formatDate(report.period_end)}.`}
      />
    );
  }

  const tone: Record<string, string> = {
    ALLOW: 'text-allow',
    REFER: 'text-refer',
    BLOCK: 'text-block',
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-3 gap-3">
        {report.outcomes.map((o) => (
          <div key={o.outcome} className="card px-3 py-3">
            <p
              className={`text-[30px] font-semibold leading-none tracking-tight ${tone[o.outcome]}`}
            >
              {o.count}
            </p>
            <p className="mt-1.5 text-[11px] leading-tight text-navy-400">{o.outcome}</p>
          </div>
        ))}
      </div>

      <p className="text-[12px] text-navy-400">
        {report.decisions_total} determination{report.decisions_total === 1 ? '' : 's'} across{' '}
        {report.clients_assessed} client{report.clients_assessed === 1 ? '' : 's'} ·{' '}
        {report.overrides_total} overridden · scoped by {report.scope_basis}
      </p>

      {report.findings.length > 0 && (
        <div className="card divide-y divide-rule">
          <p className="label px-4 pb-1 pt-3">Findings recorded</p>
          {report.findings.map((f) => (
            <div
              key={`${f.rule_id}:${f.reason_code}`}
              className="flex items-baseline justify-between gap-4 px-4 py-2.5"
            >
              <div className="min-w-0">
                <p className="text-[14px] leading-tight text-navy">{f.title}</p>
                <p className="mono mt-0.5 text-navy-400">{f.rule_id}</p>
              </div>
              <span className="mono shrink-0 text-navy">{f.count}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function OverrideFigures({ report }: { report: OverridePreview }) {
  if (report.overrides_total === 0) {
    return (
      <EmptyState
        title="No overrides in this period"
        detail="The extract would be generated, and it would be empty. That is a reportable fact, not an error."
      />
    );
  }

  return (
    <div className="space-y-3">
      <p className="text-[12px] text-navy-400">
        {report.overrides_total} override{report.overrides_total === 1 ? '' : 's'} ·{' '}
        {report.by_approver.map((a) => `${a.approver} (${a.count})`).join(' · ')} · scoped by{' '}
        {report.scope_basis}
      </p>

      <div className="space-y-3">
        {report.entries.map((e) => (
          <div key={e.override_id} className="card p-4">
            <div className="flex items-baseline justify-between gap-3">
              <p className="text-[15px] font-medium leading-tight text-navy">
                {e.client_name} <span className="mono text-navy-400">{e.asset_symbol}</span>
              </p>
              <span
                className={`shrink-0 rounded-sm px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider2 ${
                  e.outcome === 'BLOCK'
                    ? 'bg-block-bg text-block'
                    : 'bg-refer-bg text-refer'
                }`}
              >
                {e.outcome}
              </span>
            </div>
            <p className="mt-2 text-[14px] leading-relaxed text-navy">{e.justification}</p>
            <p className="mt-2 text-[12px] text-navy-600">
              {e.approver} · {formatDateTime(e.recorded_at)}
            </p>
            <p className="mono mt-1 text-navy-400">
              decision {e.decision_id} · pack v{e.pack_version} ·{' '}
              {e.findings.map((f) => f.rule_id).join(' · ') || 'no findings'}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

/**
 * Which pack produced these figures, and who signed it. A period that straddles
 * a pack change lists both, so the reporting pack never hides one.
 */
function PackProvenance({
  report,
}: {
  report: ReturnPreview | OverridePreview;
}) {
  if (report.packs_in_force.length === 0) return null;
  return (
    <section aria-labelledby="packs-h">
      <h2 id="packs-h" className="label mb-2">
        Rule packs applied
      </h2>
      <div className="card divide-y divide-rule text-[13px]">
        {report.packs_in_force.map((p) => (
          <div key={p.version} className="px-4 py-2.5">
            <div className="flex items-baseline justify-between gap-4">
              <span className="mono text-navy">
                {p.pack_id} v{p.version}
              </span>
              <span className="mono text-navy-400">
                {p.decisions} determination{p.decisions === 1 ? '' : 's'}
              </span>
            </div>
            <p className="mt-1 text-[12px] leading-snug text-navy-400">
              Effective {formatDate(p.effective_from)} —{' '}
              {p.effective_to ? formatDate(p.effective_to) : 'current'} · signed{' '}
              {p.signed_by}
            </p>
          </div>
        ))}
      </div>
      <p className="mt-2 text-[12px] leading-snug text-navy-400">
        Chain{' '}
        {report.chain.verified
          ? `verified — ${report.chain.checked} records recomputed`
          : 'NOT VERIFIED'}
        . The document restates this at the moment it is generated.
      </p>
    </section>
  );
}

/* ----------------------------- generation ---------------------------- */

/**
 * Same pattern as ArtefactButton: render server-side, then leave a persistent
 * link. A programmatic open can be swallowed in a standalone PWA on iOS, and a
 * dead end here would kill the demo.
 */
function GenerateButton({
  kind,
  period,
  scenarioId,
  label,
}: {
  kind: ReportKind;
  period: string;
  scenarioId: 'sterling' | 'meridian';
  label: string;
}) {
  const [busy, setBusy] = useState(false);
  const [artefact, setArtefact] = useState<ReportArtefact | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function generate() {
    setBusy(true);
    setError(null);
    try {
      const result = await api.generateReport(kind, period, scenarioId);
      setArtefact(result);
      const a = document.createElement('a');
      a.href = apiUrl(result.download_url);
      a.target = '_blank';
      a.rel = 'noopener';
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (err) {
      setError(
        err instanceof ApiError ? err.message : `Could not generate the ${label} document.`,
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <section aria-label="Generate">
      <button
        type="button"
        onClick={generate}
        disabled={busy}
        className="btn-primary w-full"
      >
        {busy ? 'Generating…' : 'Generate PDF'}
      </button>

      {error && (
        <p className="mt-2 rounded-md border border-block/30 bg-block-bg px-3 py-2 text-[13px] text-block">
          {error}
        </p>
      )}

      {artefact && (
        <div className="card mt-3 border-gold/35 bg-gold-soft p-4">
          <p className="label text-gold">Document ready</p>
          <p className="mt-1 text-[15px] font-medium leading-snug text-navy">
            {artefact.title}
          </p>
          <p className="mono mt-1 text-navy-600">
            {artefact.period} · {artefact.template_version} ·{' '}
            {formatDateTime(artefact.created_at)}
          </p>
          <a
            href={apiUrl(artefact.download_url)}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary mt-3 w-full"
          >
            Download PDF
          </a>
        </div>
      )}
    </section>
  );
}

/**
 * The audit trail, and an honest statement of what it does and does not
 * guarantee. `audit_events` is append-only at the database level but is not
 * hash-chained the way `decisions` is — saying nothing here would let a reader
 * carry over the chain's guarantee by assumption.
 */
function AuditExport() {
  return (
    <section aria-labelledby="audit-h" className="border-t border-rule pt-6">
      <h2 id="audit-h" className="label mb-2">
        Audit trail
      </h2>
      <p className="text-[13px] leading-snug text-navy-600">
        Every evaluation, replay, override and document generation, as CSV.
      </p>
      <p className="mt-2 text-[12px] leading-snug text-navy-400">
        Append-only: the database refuses updates and deletes on this table. It is
        not hash-chained — unlike the decision record, this export does not carry
        arithmetic proof that nothing was removed.
      </p>
      <a
        href={api.auditExportUrl()}
        target="_blank"
        rel="noopener noreferrer"
        className="btn-secondary mt-3 w-full"
      >
        Export audit trail (CSV)
      </a>
    </section>
  );
}

/* ------------------------------- periods ----------------------------- */

function buildOptions(months: ReportPeriod[]): ReportPeriod[] {
  const quarters = new Map<string, number>();
  for (const m of months) {
    const [year, mon] = m.period.split('-');
    const key = `${year}-Q${Math.floor((Number(mon) - 1) / 3) + 1}`;
    quarters.set(key, (quarters.get(key) ?? 0) + m.decisions);
  }

  const quarterOptions: ReportPeriod[] = [...quarters.entries()]
    .sort((a, b) => (a[0] < b[0] ? 1 : -1))
    .map(([period, decisions]) => ({
      period,
      label: `${period.slice(5)} ${period.slice(0, 4)}`,
      decisions,
    }));

  return [...quarterOptions, ...months];
}
