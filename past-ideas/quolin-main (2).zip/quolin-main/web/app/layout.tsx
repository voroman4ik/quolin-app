import type { Metadata, Viewport } from 'next';
import { Inter, IBM_Plex_Mono } from 'next/font/google';
import './globals.css';
import { ScenarioProvider } from '@/lib/scenario';
import AuthGate from '@/components/AuthGate';
import ServiceWorker from '@/components/ServiceWorker';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

const mono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Quolin',
  description: 'Compliance decision engine for Australian digital-asset distribution.',
  manifest: '/manifest.json',
  applicationName: 'Quolin',
  appleWebApp: {
    capable: true,
    title: 'Quolin',
    statusBarStyle: 'black-translucent',
  },
  icons: {
    icon: [{ url: '/icons/icon-512.png', sizes: '512x512', type: 'image/png' }],
    apple: [{ url: '/icons/icon-180.png', sizes: '180x180', type: 'image/png' }],
  },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: '#0F1C2E',
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  // Locked: pinch-zoom on a verdict screen looks like a broken web page.
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-AU" className={`${inter.variable} ${mono.variable}`}>
      <body>
        <ScenarioProvider>
          {/*
            Wraps everything, so a new screen is behind the lock by default.
            The API enforces this independently — see components/AuthGate.tsx —
            but a route that renders its shell before being refused still shows
            the shape of the data to someone who should not have it.
          */}
          {/*
            The chrome is inside the gate and *not* passed through it.
            `AuthGate` renders these around the app only once there is an app to
            show: the lock screen, the enrolment interstitial and the invitation
            page all belong to somebody who has no session, and a footer telling
            them how many rule packs are loaded is both meaningless to them and
            a request that answers 401.
          */}
          <AuthGate>{children}</AuthGate>
        </ScenarioProvider>
        <ServiceWorker />
      </body>
    </html>
  );
}
