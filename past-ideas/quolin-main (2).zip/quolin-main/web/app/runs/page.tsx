'use client';

/**
 * Every sweep of the book, newest first. FP3-26.
 *
 * `/runs` has answered since §S8 and nothing in this app asked it. That is the
 * shape of the whole finding: a bulk re-evaluation writes an `eval_runs` row,
 * per-chunk progress and one `eval_deltas` row for every client whose outcome
 * moved — and a compliance officer could reach none of it without curl.
 *
 * It matters most for the reason the run exists. A pack version becomes
 * effective, the book is re-checked, and two hundred clients move to REFER. The
 * firm has to evidence that to a regulator, and the run is the evidence.
 */

import Link from 'next/link';
import { formatDateTime } from '@/lib/format';
import { useApi } from '@/lib/useApi';
import { admin } from '@/lib/console';
import { AppBar } from '@/components/AppBar';
import { Chevron } from '@/components/DecisionRow';
import { EmptyState, ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import type { RunSummary } from '@/lib/console';

export default function RunsPage() {
  const runs = useApi(() => admin.runs(), []);
  const rows = runs.data?.runs ?? [];

  return (
    <main className="min-h-dvh pb-16">
      <AppBar title="Delta reports" subtitle="Bulk re-evaluations" back="/" />

      <div className="col space-y-5 pt-5">
        {runs.stale && <StaleNotice />}

        <p className="text-[13px] leading-relaxed text-navy-600">
          A sweep re-checks every client against a pack version and records the
          ones whose outcome moved. The report is what a firm shows a regulator
          when rule content changes underneath a book that had already been
          decided.
        </p>

        {runs.loading && rows.length === 0 && <LoadingBlock rows={3} label="Loading runs" />}
        {runs.error && rows.length === 0 && (
          <ErrorState message={runs.error} onRetry={runs.reload} />
        )}
        {!runs.loading && !runs.error && rows.length === 0 && (
          <EmptyState
            title="No sweeps have been run"
            detail="A run is started when a pack version becomes effective, or on demand."
          />
        )}

        {rows.length > 0 && (
          <div className="card divide-y divide-rule">
            {rows.map((run) => (
              <Link key={run.id} href={`/runs/${run.id}`} className="row-link">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[15px] font-medium leading-tight text-navy">
                    {run.jurisdiction}
                    {run.against_version !== null && (
                      <span className="ml-1.5 font-normal text-navy-400">
                        v{run.against_version}
                      </span>
                    )}
                    <DryRunChip run={run} />
                  </p>
                  <p className="mt-0.5 truncate text-[12px] leading-tight text-navy-400">
                    {formatDateTime(run.requested_at)} · {run.trigger}
                  </p>
                  <Headline run={run} />
                </div>
                <StatusChip status={run.status} failures={run.failures} />
                <Chevron />
              </Link>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}

/**
 * The one sentence a person repeats out loud.
 *
 * Grouped by the move rather than by the destination, because `bulk.stats`
 * groups it that way and it is right to: ALLOW→REFER and BLOCK→REFER are not
 * the same news.
 */
function Headline({ run }: { run: RunSummary }) {
  if (run.changed === 0) {
    return (
      <p className="mt-0.5 text-[12px] leading-tight text-navy-400">
        {run.pairs_done} checked, nothing moved
      </p>
    );
  }
  const top = run.moves.slice(0, 2);
  return (
    <p className="mt-0.5 truncate text-[12px] leading-tight text-navy">
      {run.changed} moved ·{' '}
      {top.map((m, i) => (
        <span key={`${m.from}-${m.to}`}>
          {i > 0 && ', '}
          {m.count} {m.from}&rarr;{m.to}
        </span>
      ))}
      {run.moves.length > top.length && ' …'}
    </p>
  );
}

/**
 * A dry run reports what a version *would* do. It recorded nothing.
 *
 * Said on the row rather than only on the detail screen, because the whole
 * point of the distinction is that somebody must not read a preview as a thing
 * that happened to their book.
 */
function DryRunChip({ run }: { run: RunSummary }) {
  if (!run.dry_run) return null;
  return (
    <span className="ml-2 rounded-sm bg-parchment-dark px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider2 text-navy-600">
      Preview
    </span>
  );
}

function StatusChip({ status, failures }: { status: string; failures: number }) {
  const bad = failures > 0 || status === 'failed';
  return (
    <span
      className={`shrink-0 rounded-sm px-2 py-1 text-[11px] font-semibold uppercase tracking-wider2 ${
        bad ? 'bg-block-bg text-block' : 'bg-parchment-dark text-navy-600'
      }`}
    >
      {failures > 0 ? `${failures} failed` : status}
    </span>
  );
}
