'use client';

/**
 * One sweep: what moved, under which rule, and a file to hand over. FP3-26.
 *
 * The list a compliance officer evidences to a regulator, and the one a pinned
 * firm reads during its review window before deciding whether to take a
 * version. Both of those are "read it, then send it somewhere", which is why
 * the export is on this screen and not a follow-up request to us.
 *
 * `rule_id` and `reason_code` are the columns that make it evidence rather than
 * a count. "212 clients moved to REFER" is the headline; "under AU-KNOW-02" is
 * the next question, and a report that cannot answer it sends somebody back to
 * the engine one client at a time.
 */

import Link from 'next/link';
import { use, useMemo, useState } from 'react';
import { formatDateTime } from '@/lib/format';
import { useApi } from '@/lib/useApi';
import { admin } from '@/lib/console';
import { AppBar } from '@/components/AppBar';
import { EmptyState, ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import type { RunDelta, RunSummary } from '@/lib/console';

/** `params` is a Promise in Next 16 — see the note in app/clients/[id]/page.tsx. */
export default function RunPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const report = useApi(() => admin.runDeltas(id), [id]);
  const [move, setMove] = useState<string>('all');

  const run = report.data?.run;
  const deltas = report.data?.deltas ?? [];

  const moves = useMemo(() => {
    const seen = new Map<string, number>();
    for (const d of deltas) {
      const key = `${d.from}→${d.to}`;
      seen.set(key, (seen.get(key) ?? 0) + 1);
    }
    return [...seen.entries()].sort((a, b) => b[1] - a[1]);
  }, [deltas]);

  const shown = move === 'all' ? deltas : deltas.filter((d) => `${d.from}→${d.to}` === move);

  return (
    <main className="min-h-dvh pb-16">
      <AppBar
        title={run ? `${run.jurisdiction} sweep` : 'Delta report'}
        subtitle={run ? `Run ${run.id}` : undefined}
        back="/runs"
      />

      <div className="col space-y-6 pt-5">
        {report.stale && <StaleNotice />}

        {report.loading && !run && <LoadingBlock rows={3} label="Loading report" />}
        {report.error && !run && <ErrorState message={report.error} onRetry={report.reload} />}

        {run && (
          <>
            {run.dry_run && (
              <div className="card border-gold/40 bg-parchment-dark p-4">
                <p className="label text-gold">Preview</p>
                <p className="mt-1 text-[13px] leading-snug text-navy">
                  This run reports what the version would do. Nothing was
                  recorded against any client, and no determination on file
                  changed.
                </p>
              </div>
            )}

            <Summary run={run} />

            {report.data?.note && (
              <p className="text-[12px] leading-relaxed text-navy-400">
                {report.data.note}
              </p>
            )}

            {deltas.length === 0 ? (
              /*
                `changed` and the delta rows are written in one flush, so a real
                run cannot disagree with itself. A run that does is not telling
                the truth about something, and saying "nothing moved" under a
                summary card reading "4 moved" would leave a reader to notice
                the contradiction and guess which half to believe.
              */
              run.changed > 0 ? (
                <ErrorState
                  message={`This run says ${run.changed} outcomes moved and has no record of any of them. The two are written together, so one of them is wrong and neither should be relied on. Report the run id (${run.id}).`}
                />
              ) : (
                <EmptyState
                  title="Nothing moved"
                  detail="Every client landed on the outcome they already had. A rewording or a renumbered rule is not a change here — what counts is an outcome."
                />
              )
            ) : (
              <>
                <div className="flex items-center justify-between gap-3">
                  <MoveFilter moves={moves} value={move} onChange={setMove} total={deltas.length} />
                  <ExportButton run={run} deltas={deltas} />
                </div>
                <DeltaTable deltas={shown} />
                {deltas.length >= 2000 && (
                  <p className="text-[12px] leading-snug text-block">
                    Showing the first 2,000 rows, which is the API&rsquo;s limit
                    for this report. The export carries the same 2,000 — a
                    larger sweep needs the audit export rather than this screen.
                  </p>
                )}
              </>
            )}
          </>
        )}
      </div>
    </main>
  );
}

function Summary({ run }: { run: RunSummary }) {
  return (
    <section className="card p-4">
      <dl className="grid grid-cols-2 gap-x-4 gap-y-3">
        <Field label="Trigger" value={run.trigger} />
        <Field label="Status" value={run.status} />
        <Field label="As of" value={run.as_of} />
        <Field
          label="Against version"
          value={run.against_version === null ? 'current' : `v${run.against_version}`}
        />
        <Field label="Requested" value={formatDateTime(run.requested_at)} />
        <Field label="Finished" value={run.finished_at ? formatDateTime(run.finished_at) : '—'} />
        <Field label="Pairs checked" value={`${run.pairs_done} of ${run.pairs_total}`} />
        <Field label="Outcomes moved" value={String(run.changed)} />
      </dl>

      {run.failures > 0 && (
        <p className="mt-3 border-t border-rule pt-3 text-[13px] leading-snug text-block">
          {run.failures} pair{run.failures === 1 ? '' : 's'} could not be
          evaluated. The report below is therefore incomplete, and the
          difference is not "nothing changed for them" — it is "we do not know".
        </p>
      )}

      {run.note && (
        <div className="mt-3 border-t border-rule pt-3">
          {/*
            Labelled, because `note` is two different things. A caller can set
            it when asking for a run, and `run_chunk` overwrites it with the
            last pair that failed — so on a run with failures this is an error
            message, and printing it as unlabelled prose under a summary card
            reads like a remark somebody made about the sweep.
          */}
          <p className="label">{run.failures > 0 ? 'Last failure' : 'Note'}</p>
          <p className="mono mt-1 break-words text-[12px] leading-snug text-navy-600">
            {run.note}
          </p>
        </div>
      )}
    </section>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="label">{label}</dt>
      <dd className="mt-0.5 text-[14px] leading-tight text-navy">{value}</dd>
    </div>
  );
}

function MoveFilter({
  moves,
  value,
  onChange,
  total,
}: {
  moves: [string, number][];
  value: string;
  onChange: (v: string) => void;
  total: number;
}) {
  return (
    <div className="min-w-0 flex-1">
      <label className="label block" htmlFor="move-filter">
        Move
      </label>
      <select
        id="move-filter"
        className="field mt-1"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        <option value="all">All ({total})</option>
        {moves.map(([key, count]) => (
          <option key={key} value={key}>
            {key} ({count})
          </option>
        ))}
      </select>
    </div>
  );
}

/**
 * The file that leaves the building.
 *
 * Built in the browser from what is already on screen rather than added as an
 * endpoint. Two reasons, and the second is the one that decided it: the rows
 * are already here, so a second route would be a second implementation of the
 * same report that could disagree with this one — and the audit export at
 * `/audit/export` is the route for "give me a file the engine attests to". This
 * is a convenience over a view, and it says so.
 *
 * The filter is deliberately *not* applied. A CSV that quietly held a subset
 * because of a dropdown somebody had forgotten they touched is the kind of
 * evidence that gets a firm into trouble; the file is the report.
 */
function ExportButton({ run, deltas }: { run: RunSummary; deltas: RunDelta[] }) {
  const [href, setHref] = useState<string | null>(null);

  function build() {
    const header = [
      'client_id',
      'asset_id',
      'from',
      'to',
      'from_pack_version',
      'to_pack_version',
      'rule_id',
      'reason_code',
      'decision_id',
    ];
    const rows = deltas.map((d) => [
      d.client_id,
      d.asset_id,
      d.from,
      d.to,
      d.from_pack_version ?? '',
      d.to_pack_version ?? '',
      d.rule_id,
      d.reason_code,
      d.decision_id ?? '',
    ]);
    const csv = [header, ...rows]
      .map((row) => row.map(csvCell).join(','))
      .join('\r\n');
    // A BOM, because the overwhelmingly likely destination is Excel and without
    // one it renders a client's name in mojibake.
    const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
    setHref(URL.createObjectURL(blob));
  }

  if (!href) {
    return (
      <button type="button" onClick={build} className="btn-secondary shrink-0 self-end">
        Export CSV
      </button>
    );
  }

  return (
    <a
      href={href}
      download={`quolin-run-${run.id}-deltas.csv`}
      className="btn-primary shrink-0 self-end"
    >
      Download
    </a>
  );
}

/**
 * RFC 4180 quoting, and it is not decorative.
 *
 * `reason_code` and `rule_id` are engine-controlled and tame, but `client_id`
 * comes from a customer's own import and a comma in one would silently shift
 * every column after it — which turns a report about who may no longer trade
 * into a report about somebody else.
 */
function csvCell(value: string | number): string {
  const s = String(value);
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function DeltaTable({ deltas }: { deltas: RunDelta[] }) {
  return (
    <div className="card overflow-x-auto">
      <table className="w-full text-left text-[13px]">
        <thead>
          <tr className="border-b border-rule">
            <Th>Client</Th>
            <Th>Asset</Th>
            <Th>Move</Th>
            <Th>Rule</Th>
            <Th>Reason</Th>
          </tr>
        </thead>
        <tbody className="divide-y divide-rule">
          {deltas.map((d, i) => (
            <tr key={`${d.client_id}-${d.asset_id}-${i}`}>
              <td className="px-3 py-2">
                <Link href={`/clients/${d.client_id}`} className="mono text-navy underline">
                  {d.client_id}
                </Link>
              </td>
              <td className="mono px-3 py-2 text-navy-600">{d.asset_id}</td>
              <td className="whitespace-nowrap px-3 py-2">
                <span className="text-navy-400">{d.from}</span>
                <span className="mx-1 text-navy-400">&rarr;</span>
                <span className="font-semibold text-navy">{d.to}</span>
              </td>
              <td className="mono px-3 py-2 text-navy-600">{d.rule_id}</td>
              <td className="px-3 py-2 text-navy-600">
                {d.decision_id ? (
                  <Link href={`/decisions/${d.decision_id}`} className="underline">
                    {d.reason_code}
                  </Link>
                ) : (
                  d.reason_code
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="label px-3 py-2 font-medium">{children}</th>;
}
