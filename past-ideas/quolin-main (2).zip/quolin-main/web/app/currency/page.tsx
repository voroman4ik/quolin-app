'use client';

import Link from 'next/link';
import { useState } from 'react';
import { ApiError, api } from '@/lib/api';
import { formatDate, formatDateTime, humanizeRef } from '@/lib/format';
import type { PackDraft, TriageTier, WatchEvent } from '@/lib/types';
import { useApi } from '@/lib/useApi';
import { AppBar } from '@/components/AppBar';
import SourceAttestations from '@/components/SourceAttestations';
import { StagedVersions } from '@/components/StagedVersions';
import { Chevron } from '@/components/DecisionRow';
import FreshnessBadge, {
  FRESHNESS_HEADLINE,
  freshnessSentence,
} from '@/components/FreshnessBadge';
import { EmptyState, ErrorState, LoadingBlock, Skeleton } from '@/components/States';

/**
 * S7 — Regulatory currency.
 *
 * The screen answers "is what this system enforces still current?" and it is
 * arranged so that the honest answer arrives before the reassuring one. The
 * freshness rollup and the unsigned-draft count are above the fold; the tidy
 * per-regime list is below it. A currency screen that opened on four green
 * badges would be doing the opposite of its job.
 *
 * Nothing here changes a rule. The only control that can is the signature
 * action on a draft, and it is a separate screen reached by a deliberate tap.
 */

const TIER_TONE: Record<TriageTier, string> = {
  // Not the verdict palette — see FreshnessBadge. A queue tier is a reading
  // order, and dressing one as a BLOCK would be claiming a finding.
  TOUCHES_RULE_CONTENT: 'bg-navy text-parchment',
  IN_SCOPE: 'bg-parchment-dark text-navy-600',
  UNMATCHED: 'bg-gold-soft text-gold',
};

export default function CurrencyPage() {
  const view = useApi(() => api.currency(), []);
  const queue = useApi(() => api.watchEvents(), []);
  const [polling, setPolling] = useState(false);
  const [pollNote, setPollNote] = useState<string | null>(null);
  const [pollFailed, setPollFailed] = useState(false);

  const c = view.data;

  async function poll() {
    setPolling(true);
    setPollNote(null);
    setPollFailed(false);
    try {
      const r = await api.pollWatch();
      setPollNote(
        r.new_events === 0
          ? `Checked ${r.sources_checked} sources in ${r.mode} mode. Nothing new — ${r.already_seen} items had already been seen.`
          : `Checked ${r.sources_checked} sources in ${r.mode} mode. ${r.new_events} new item${
              r.new_events === 1 ? '' : 's'
            }.`,
      );
      view.reload();
      queue.reload();
    } catch (err) {
      // A 501 in live mode is the honest answer, not a crash. It names the
      // adapter that does not exist, and that message is shown verbatim rather
      // than replaced with "polling failed".
      setPollFailed(true);
      setPollNote(
        err instanceof ApiError ? err.message : 'Could not reach the engine to poll.',
      );
    } finally {
      setPolling(false);
    }
  }

  return (
    <main className="min-h-dvh pb-16">
      <AppBar title="Regulatory currency" back="/" />

      <div className="col space-y-7 pt-5">
        {/* First on the page, above the regulator feed. What is about to change
            for *this firm* outranks what a regulator published, because one of
            them has a deadline on it and the other is reading. */}
        <StagedVersions />
        {view.error && !c ? (
          <ErrorState message={view.error} onRetry={view.reload} />
        ) : (
          <>
            {/* The headline is the worst thing true of this deployment. */}
            <section aria-labelledby="state-h" className="card p-5">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h2 id="state-h" className="label">
                    Monitoring state
                  </h2>
                  {view.loading && !c ? (
                    <Skeleton className="mt-2 h-7 w-40" />
                  ) : (
                    <p className="mt-1 text-[22px] font-semibold leading-tight text-navy">
                      {c && FRESHNESS_HEADLINE[c.freshness]}
                    </p>
                  )}
                </div>
                {c && <FreshnessBadge freshness={c.freshness} />}
              </div>

              {c && (
                <>
                  <dl className="mt-4 grid grid-cols-3 gap-3 border-t border-rule pt-4">
                    <Metric label="Open items" value={c.open_items} />
                    <Metric
                      label="Awaiting signature"
                      value={c.drafts_awaiting_signature.length}
                      accent={c.drafts_awaiting_signature.length > 0}
                    />
                    <Metric label="Pending packs" value={c.pending_packs.length} />
                  </dl>
                  <p className="mt-4 text-[13px] leading-relaxed text-navy-600">
                    {c.statement}
                  </p>
                </>
              )}
            </section>

            {/* The mode boundary, stated where the button that uses it lives. */}
            <section aria-labelledby="mode-h" className="card p-5">
              <div className="flex items-baseline justify-between gap-3">
                <h2 id="mode-h" className="label">
                  Source of these items
                </h2>
                {c && (
                  <span className="mono rounded-sm bg-parchment-dark px-2 py-1 uppercase text-navy-600">
                    {c.mode}
                  </span>
                )}
              </div>
              <p className="mt-2 text-[13px] leading-relaxed text-navy-600">
                {c?.mode_note ?? <Skeleton className="h-4 w-full" />}
              </p>
              <button
                type="button"
                onClick={poll}
                disabled={polling || !c}
                className="btn-secondary mt-4 w-full disabled:opacity-50"
              >
                {polling ? 'Checking sources…' : 'Check sources now'}
              </button>
              {pollNote && (
                <p
                  className={`mt-3 text-[13px] leading-relaxed ${
                    pollFailed ? 'text-block' : 'text-navy-600'
                  }`}
                >
                  {pollNote}
                </p>
              )}
            </section>

            {/* The demo moment. Above the queue, because a draft that nobody has
                signed is more urgent than an item nobody has read. */}
            {c && c.drafts_awaiting_signature.length > 0 && (
              <section aria-labelledby="sign-h">
                <h2 id="sign-h" className="label mb-2">
                  Waiting for a signature
                </h2>
                <div className="card divide-y divide-rule border-gold/40">
                  {c.drafts_awaiting_signature.map((d) => (
                    <DraftRow key={d.id} draft={d} />
                  ))}
                </div>
                <p className="mt-2 text-[12px] leading-snug text-navy-400">
                  A draft changes nothing. It is not visible to the evaluator, and it
                  cannot become rule content until a named person signs it.
                </p>
              </section>
            )}

            {c && c.pending_packs.length > 0 && (
              <section aria-labelledby="pending-h">
                <h2 id="pending-h" className="label mb-2">
                  Signed, not yet in force
                </h2>
                <div className="card divide-y divide-rule">
                  {c.pending_packs.map((p) => (
                    <div key={`${p.jurisdiction}-${p.version}`} className="px-5 py-4">
                      <div className="flex items-baseline justify-between gap-3">
                        <p className="text-[15px] font-medium leading-tight text-navy">
                          {p.jurisdiction_name}{' '}
                          <span className="mono text-navy-400">v{p.version}</span>
                        </p>
                        <span className="shrink-0 rounded-sm bg-gold-soft px-2 py-1 text-[11px] font-semibold uppercase tracking-wider2 text-gold">
                          {p.days_until_effective}d
                        </span>
                      </div>
                      <p className="mt-1 text-[13px] leading-snug text-navy-600">
                        Takes effect {formatDate(p.effective_from)}. Signed by{' '}
                        {p.signed_by || '—'}.
                      </p>
                      {/* The countdown is only meaningful next to this sentence.
                          Without it a viewer reasonably assumes the new pack is
                          already deciding things. */}
                      <p className="mt-1 text-[12px] leading-snug text-navy-400">
                        No determination made today uses it. Decisions are evaluated
                        against the version in force on their own date.
                      </p>
                    </div>
                  ))}
                </div>
              </section>
            )}

            <section aria-labelledby="regimes-h">
              <h2 id="regimes-h" className="label mb-2">
                By regime
              </h2>
              {view.loading && !c ? (
                <LoadingBlock rows={4} label="Loading regimes" />
              ) : c && c.jurisdictions.length === 0 ? (
                /* A heading with nothing under it reads as a rendering bug.
                   This is the same "engine up, no content" case the packs
                   shelf guards against, seen from the currency screen. */
                <EmptyState
                  title="No regimes are being watched"
                  detail="Freshness is computed per pack, and there are no packs loaded to compute it for."
                />
              ) : (
                <div className="space-y-3">
                  {c?.jurisdictions.map((j) => (
                    <div key={j.jurisdiction} className="card p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-[15px] font-medium leading-tight text-navy">
                            {j.jurisdiction_name}{' '}
                            <span className="mono text-navy-400">
                              {j.jurisdiction} v{j.version}
                            </span>
                          </p>
                          <p className="mt-0.5 text-[12px] leading-snug text-navy-400">
                            {j.regulator || 'Regulator not stated in pack'}
                          </p>
                        </div>
                        <FreshnessBadge freshness={j.freshness} size="sm" />
                      </div>

                      <p className="mt-2 text-[13px] leading-snug text-navy-600">
                        {freshnessSentence(
                          j.freshness,
                          j.last_checked_at,
                          j.sources.length,
                          j.unreachable.length,
                        )}
                      </p>

                      <ul className="mt-3 space-y-2 border-t border-rule pt-3">
                        {j.sources.map((s) => (
                          <li key={s.id} className="flex items-baseline gap-2">
                            <FreshnessBadge freshness={s.freshness} size="sm" />
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-[13px] leading-snug text-navy">
                                {s.name}
                              </p>
                              <p className="text-[11px] leading-snug text-navy-400">
                                Every {s.cadence_days}d · last checked{' '}
                                {s.last_checked_at ? formatDate(s.last_checked_at) : 'never'}
                                {/* Per-source, not from the environment: a screen
                                    must not be able to relabel history by having
                                    WATCH_MODE flipped after the fact. */}
                                {s.last_mode ? ` (${s.last_mode})` : ''}
                              </p>
                              {/* Said in the source's own row rather than only in
                                  a rollup. "Late" and "not answering" look
                                  identical on a freshness badge, and only one of
                                  them is somebody working on it. */}
                              {s.breaching && (
                                <p className="mt-0.5 text-[11px] leading-snug text-block">
                                  Not answering — {s.consecutive_failures} failed checks in a
                                  row{s.last_error ? `: ${s.last_error}` : ''}. Reported to{' '}
                                  {s.owner || 'us'}.
                                </p>
                              )}
                              {/* FP3-26. The freshness badge above is derived
                                  state; this is the evidence for it, and for a
                                  MANUAL source it is the only evidence there is. */}
                              <SourceAttestations
                                sourceId={s.id}
                                manual={s.polling_status === 'MANUAL'}
                              />
                            </div>
                          </li>
                        ))}
                        {j.sources.length === 0 && (
                          <li className="text-[13px] text-navy-400">
                            This pack declares no sources.
                          </li>
                        )}
                      </ul>

                      {j.open_items > 0 && (
                        <p className="mt-3 text-[12px] text-navy-400">
                          {j.open_items} open item{j.open_items === 1 ? '' : 's'} in the queue.
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* Phase 3 stated coverage gaps on a determination. This is the
                same admission on the monitoring side. */}
            {c && c.uncovered.length > 0 && (
              <section aria-labelledby="gap-h" className="card border-gold/40 p-5">
                <h2 id="gap-h" className="label text-gold">
                  Regimes with no pack
                </h2>
                <p className="mt-2 text-[13px] leading-relaxed text-navy-600">
                  {c.uncovered
                    .map((u) => `${u.jurisdiction} (${u.events})`)
                    .join(', ')}{' '}
                  — items have been observed about {c.uncovered.length === 1 ? 'this' : 'these'}{' '}
                  regime{c.uncovered.length === 1 ? '' : 's'} and Quolin holds no rule content
                  for {c.uncovered.length === 1 ? 'it' : 'them'}. Nothing can be said about
                  whether they matter.
                </p>
              </section>
            )}

            <section aria-labelledby="queue-h">
              <div className="mb-2 flex items-baseline justify-between">
                <h2 id="queue-h" className="label">
                  Watch queue
                </h2>
                <span className="text-[12px] text-navy-400">
                  {queue.data?.events.length ?? 0} items
                </span>
              </div>

              {queue.error && !queue.data ? (
                <ErrorState message={queue.error} onRetry={queue.reload} />
              ) : queue.loading && !queue.data ? (
                <LoadingBlock rows={3} label="Loading queue" />
              ) : queue.data?.events.length === 0 ? (
                <EmptyState
                  title="Nothing observed yet"
                  detail="Check the sources to populate the queue."
                />
              ) : (
                <div className="space-y-3">
                  {queue.data?.events.map((e) => (
                    <EventCard key={e.id} event={e} onChanged={() => queue.reload()} />
                  ))}
                </div>
              )}

              {queue.data && (
                <div className="mt-4 space-y-2">
                  {queue.data.tiers.map((t) => (
                    <p key={t.id} className="text-[12px] leading-snug text-navy-400">
                      <span
                        className={`mr-2 inline-block rounded-sm px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider2 ${
                          TIER_TONE[t.id]
                        }`}
                      >
                        {t.label}
                      </span>
                      {t.explanation}
                    </p>
                  ))}
                </div>
              )}
            </section>

            {c && (
              <p className="text-center text-[12px] text-navy-400">
                As at {formatDate(c.as_of)} · rendered {formatDateTime(c.checked_at)}
              </p>
            )}
          </>
        )}
      </div>
    </main>
  );
}

function Metric({
  label,
  value,
  accent,
}: {
  label: string;
  value: number;
  accent?: boolean;
}) {
  return (
    <div>
      <dd
        className={`text-[26px] font-semibold leading-none tracking-tight ${
          accent ? 'text-gold' : 'text-navy'
        }`}
      >
        {value}
      </dd>
      <dt className="mt-1.5 text-[11px] leading-tight text-navy-400">{label}</dt>
    </div>
  );
}

function DraftRow({ draft }: { draft: PackDraft }) {
  return (
    <Link href={`/currency/drafts/${draft.id}`} className="row-link">
      <div className="min-w-0 flex-1">
        <p className="text-[15px] font-medium leading-tight text-navy">{draft.title}</p>
        <p className="mono mt-0.5 text-navy-400">
          {draft.jurisdiction} v{draft.base_version} → v{draft.proposed_version} · effective{' '}
          {formatDate(draft.effective_from)}
        </p>
      </div>
      <span className="shrink-0 rounded-sm bg-gold-soft px-2 py-1 text-[11px] font-semibold uppercase tracking-wider2 text-gold">
        Unsigned
      </span>
      <Chevron />
    </Link>
  );
}

function EventCard({ event, onChanged }: { event: WatchEvent; onChanged: () => void }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const closed = event.status === 'dismissed' || event.status === 'actioned';

  async function move(status: 'reviewing' | 'dismissed') {
    setBusy(true);
    setError(null);
    try {
      await api.triageEvent(event.id, status);
      onChanged();
    } catch (err) {
      // Without this the rejection was unhandled: the button re-enabled, the
      // card did not move, and nothing said why. Triage is a POST, so the
      // ordinary cause is an engine that is not there — the same reason the
      // buttons below are disabled when it is known to be gone.
      setError(
        err instanceof ApiError
          ? err.message
          : 'Could not record that. The event is unchanged.',
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <article className={`card p-4 ${closed ? 'opacity-60' : ''}`}>
      <div className="flex items-start justify-between gap-3">
        <span
          className={`shrink-0 rounded-sm px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider2 ${
            TIER_TONE[event.tier]
          }`}
        >
          {event.tier_label}
        </span>
        <span className="mono shrink-0 text-navy-400">
          {event.jurisdiction} · {formatDate(event.published_at)}
        </span>
      </div>

      <h3 className="mt-2 text-[15px] font-medium leading-snug text-navy">{event.title}</h3>
      {event.summary && (
        <p className="mt-1 text-[13px] leading-relaxed text-navy-600">{event.summary}</p>
      )}

      {/* Why this item is where it is. The list is the whole reason the tier is
          defensible: an officer can disagree with a match, and cannot disagree
          with a score. */}
      {event.matched.length > 0 && (
        <div className="mt-3 border-t border-rule pt-3">
          <p className="label">Matched</p>
          <ul className="mt-1.5 space-y-1">
            {event.matched.map((m) => (
              <li key={m.term} className="text-[12px] leading-snug text-navy-600">
                <span className="font-medium">“{m.term}”</span>
                {m.touches.length > 0 && (
                  <span className="text-navy-400">
                    {' '}
                    → {m.touches.map(humanizeRef).join(', ')}
                  </span>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-3 flex items-center gap-2 border-t border-rule pt-3">
        <span className="mono flex-1 text-navy-400">{event.status}</span>
        {!closed && (
          <>
            <button
              type="button"
              disabled={busy}
              onClick={() => move('dismissed')}
              className="btn-secondary px-3 py-1.5 text-[13px] disabled:opacity-50"
            >
              Dismiss
            </button>
            {event.status === 'new' && (
              <button
                type="button"
                disabled={busy}
                onClick={() => move('reviewing')}
                className="btn-secondary px-3 py-1.5 text-[13px] disabled:opacity-50"
              >
                Reviewing
              </button>
            )}
          </>
        )}
        {event.url && (
          <a
            href={event.url}
            target="_blank"
            rel="noreferrer noopener"
            className="text-[13px] font-medium text-gold"
          >
            Source
          </a>
        )}
      </div>

      {error && (
        <p
          role="alert"
          className="mt-2 rounded-md border border-block/30 bg-block-bg px-3 py-2 text-[13px] leading-snug text-block"
        >
          {error}
        </p>
      )}

      {event.note && (
        <p className="mt-2 text-[12px] leading-snug text-navy-400">{event.note}</p>
      )}
    </article>
  );
}
