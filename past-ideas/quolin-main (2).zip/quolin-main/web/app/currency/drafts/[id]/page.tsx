'use client';

import Link from 'next/link';
import { use, useState } from 'react';
import { ApiError, api } from '@/lib/api';
import { formatDate, formatDateTime, formatProvenanceValue, humanizeRef } from '@/lib/format';
import type { PackDiff } from '@/lib/types';
import { useApi, useSession } from '@/lib/useApi';
import { AppBar } from '@/components/AppBar';
import { useReauth } from '@/components/Reauth';
import { Workbench } from '@/components/Workbench';
import { ErrorState, LoadingBlock } from '@/components/States';

/**
 * S8 — a proposed rule change, and the gate it has to get through.
 *
 * This is the only screen in Quolin from which live rule content can be
 * created, and it is written to make that feel like what it is. The proposed
 * numbers are shown before the signature box. The signature box asks for a
 * name, not a click. And the sentence above the button says, in the present
 * tense, what signing does — because "Approve" on its own is a word people
 * press without reading, and this is not a button anybody should press without
 * reading.
 *
 * Until it is signed, everything on this page is inert. `/packs` does not show
 * it, the evaluator cannot see it, and a determination made while this screen
 * is open is unaffected by every number on it.
 */

/*
 * `params` is a Promise in Next 16 and has to be unwrapped.
 *
 * It was read synchronously here, which a production build resolves to
 * `undefined` — so this screen requested the record `undefined` and rendered
 * "Unavailable" over an engine that was answering perfectly well. Every
 * dynamic route in the app had the same line. It survived because nothing
 * exercised a production build at runtime: `npm run build` compiles it without
 * complaint, and the demo and `make tunnel` both run `next dev`.
 *
 * Found by the offline regression in e2e/, which serves a production build.
 */
export default function DraftPage({ params }: { params: Promise<{ id: string }> }) {
  const id = Number(use(params).id);
  const draft = useApi(() => api.draft(id), [id]);
  const me = useSession();
  const [note, setNote] = useState('');
  const reauth = useReauth();
  const [busy, setBusy] = useState(false);
  const [outcome, setOutcome] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  const d = draft.data;
  const delta = d && 'thresholds_changed' in d.delta ? (d.delta as PackDiff) : null;
  const unavailable = d && 'unavailable' in d.delta ? d.delta.unavailable : null;

  async function sign() {
    // The hash of the body *this screen rendered*, captured before anything
    // else happens. The server refuses the signature if the draft has moved
    // since, which is what stops one landing on an edit made while the page was
    // open — an auditor read 1000, its author PATCHed it to 9999, and the
    // signature was recorded against 9999 under the reader's name.
    //
    // Read from `d` rather than re-fetched here, and that is the whole point:
    // re-fetching would bind the signature to a body nobody looked at, which is
    // the defect with a network call in front of it.
    //
    // The button only renders inside `d ? …`, so this is unreachable; it is
    // written as a refusal rather than a `!` because the one thing this
    // function must never do is sign with a hash it made up.
    const whatThisScreenShowed = d?.current_content_hash;
    if (!whatThisScreenShowed) {
      setFailed(true);
      setOutcome('This draft is still loading, so there is nothing to sign yet.');
      return;
    }

    setBusy(true);
    setFailed(false);
    setOutcome(null);
    try {
      const r = await reauth(() => api.signDraft(id, note, whatThisScreenShowed));
      setOutcome(
        `Signed by ${r.signed_by}. Not published — it will not become rule content ` +
          'until a second person puts it into force.',
      );
      draft.reload();
    } catch (err) {
      setFailed(true);
      setOutcome(err instanceof ApiError ? err.message : 'Could not record the signature.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="min-h-dvh pb-16">
      <AppBar title="Proposed change" back="/currency" />

      <div className="col space-y-6 pt-5">
        {draft.error && !d ? (
          <ErrorState message={draft.error} onRetry={draft.reload} />
        ) : draft.loading && !d ? (
          <LoadingBlock rows={4} label="Loading draft" />
        ) : d ? (
          <>
            {/* Status first and unmissable. A reader arriving mid-demo needs to
                know whether they are looking at a proposal or at content. */}
            <StatusBanner
              status={d.status}
              isLive={d.is_live}
              days={d.days_until_effective}
              effectiveFrom={d.effective_from}
            />

            <section className="card p-5">
              <p className="label">
                {d.jurisdiction} v{d.base_version} → v{d.proposed_version}
              </p>
              <h2 className="mt-1 text-[20px] font-semibold leading-tight text-navy">
                {d.title}
              </h2>
              <p className="mt-3 text-[14px] leading-relaxed text-navy-600">{d.rationale}</p>
              <p className="mt-3 border-t border-rule pt-3 text-[12px] leading-snug text-navy-400">
                Cut from {d.jurisdiction} v{d.base_version}
                {d.created_at ? ` on ${formatDate(d.created_at)}` : ''}. Would take effect{' '}
                {formatDate(d.effective_from)}.
              </p>
            </section>

            <section aria-labelledby="delta-h">
              <h2 id="delta-h" className="label mb-2">
                What would change
              </h2>
              <div className="card p-5">
                {unavailable && (
                  <p className="text-[13px] leading-relaxed text-navy-600">{unavailable}</p>
                )}
                {delta && delta.thresholds_changed.length === 0 &&
                  delta.thresholds_added.length === 0 &&
                  delta.rules_added.length === 0 &&
                  delta.rules_removed.length === 0 &&
                  delta.rules_modified.length === 0 && (
                    <p className="text-[13px] leading-relaxed text-navy-600">
                      Nothing. This draft is identical to the version it was cut from.
                    </p>
                  )}
                {delta?.thresholds_changed.map((t) => (
                  <div key={t.name} className="flex items-baseline justify-between gap-3 py-1.5">
                    <span className="min-w-0 flex-1 text-[13px] leading-snug text-navy">
                      {humanizeRef(t.name)}
                    </span>
                    <span className="mono shrink-0 text-navy-400 line-through">
                      {formatProvenanceValue(t.name, t.from)}
                    </span>
                    <span className="mono shrink-0 font-semibold text-navy">
                      {formatProvenanceValue(t.name, t.to)}
                    </span>
                  </div>
                ))}
                {delta && delta.rules_added.length > 0 && (
                  <p className="mt-3 border-t border-rule pt-3 text-[13px] text-navy-600">
                    Rules added: {delta.rules_added.map((r) => r.rule_id).join(', ')}
                  </p>
                )}
                {delta && delta.rules_removed.length > 0 && (
                  <p className="mt-1 text-[13px] text-navy-600">
                    Rules removed: {delta.rules_removed.join(', ')}
                  </p>
                )}
                {delta && delta.rules_modified.length > 0 && (
                  <p className="mt-1 text-[13px] text-navy-600">
                    Rules modified: {delta.rules_modified.join(', ')}
                  </p>
                )}
              </div>
            </section>

            {/* A draft with no events behind it is legitimate — a consultant may
                simply author one — and prints as such rather than implying a
                source that does not exist. */}
            <section aria-labelledby="why-h">
              <h2 id="why-h" className="label mb-2">
                What argued for this
              </h2>
              {d.events && d.events.length > 0 ? (
                <div className="card divide-y divide-rule">
                  {d.events.map((e) => (
                    <div key={e.id} className="px-5 py-3">
                      <p className="text-[14px] leading-snug text-navy">{e.title}</p>
                      <p className="mono mt-0.5 text-navy-400">
                        {e.jurisdiction} · {formatDate(e.published_at)}
                      </p>
                      {e.url && (
                        <a
                          href={e.url}
                          target="_blank"
                          rel="noreferrer noopener"
                          className="mt-1 inline-block text-[13px] font-medium text-gold"
                        >
                          Source
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="card p-5">
                  <p className="text-[13px] leading-relaxed text-navy-600">
                    No watch item is recorded against this draft. It was authored
                    directly, which is legitimate — but nothing here traces it to a
                    published source.
                  </p>
                </div>
              )}
            </section>

            {/* The workbench. Above the signature box on purpose: a specialist
                reads what changed, checks it against the regulation, fixes what
                is wrong, and only then signs. Putting the signature first would
                put the irreversible act at the top of the page. */}
            <Workbench draft={d} onSaved={draft.reload} />

            {d.status === 'draft' || d.status === 'in_review' ? (
              <section aria-labelledby="sign-h" className="card border-gold/40 p-5">
                <h2 id="sign-h" className="label text-gold">
                  Signature
                </h2>
                <p className="mt-2 text-[14px] leading-relaxed text-navy">
                  Signing records your name against this content and makes it eligible
                  to become the rule pack {d.jurisdiction} v{d.proposed_version}, in force
                  from {formatDate(d.effective_from)}. Determinations made on and after
                  that date will be evaluated against it. Nothing already decided
                  changes — every recorded decision keeps the version it was made under.
                </p>

                {/* Shown, not typed. A name entered into a box is whatever the
                    person at the keyboard felt like writing; the signature is
                    the account they signed in with, and the engine checks that
                    account holds a signatory grant for {d.jurisdiction}. */}
                <p className="label mt-4 block">Signed by</p>
                <p className="field mt-1 text-navy">
                  {me.data?.user?.display_name ?? 'Loading…'}
                </p>

                <label className="label mt-3 block" htmlFor="signote">
                  Note (optional)
                </label>
                <textarea
                  id="signote"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  rows={3}
                  className="field mt-1"
                  placeholder="What was reviewed, and against what."
                />

                <button
                  type="button"
                  onClick={sign}
                  disabled={busy}
                  className="btn-primary mt-4 w-full disabled:opacity-40"
                >
                  {busy ? 'Recording…' : 'Sign'}
                </button>
                {/* There used to be a "publish immediately" tick here. It let
                    one person sign rule content and put it into force in the
                    same act, which is the separation this screen exists to
                    create. Publication is now somebody else's button. */}
                <p className="mt-2 text-[12px] leading-snug text-navy-400">
                  Signing does not publish. A second person puts signed content into
                  force, and the engine refuses to let that be you.
                </p>
              </section>
            ) : (
              <section aria-labelledby="signed-h" className="card p-5">
                <h2 id="signed-h" className="label">
                  Signature
                </h2>
                <p className="mt-2 text-[15px] font-medium leading-snug text-navy">
                  {d.signed_by || '—'}
                </p>
                <p className="mono mt-0.5 text-navy-400">
                  {d.signed_at ? formatDateTime(d.signed_at) : '—'}
                </p>
                {d.signature_note && (
                  <p className="mt-2 text-[13px] leading-relaxed text-navy-600">
                    {d.signature_note}
                  </p>
                )}
                {d.published_pack_id && (
                  <Link
                    href={`/packs/${d.jurisdiction}`}
                    className="btn-secondary mt-4 w-full"
                  >
                    View {d.jurisdiction} on the shelf
                  </Link>
                )}
              </section>
            )}

            {outcome && (
              <p
                className={`text-[13px] leading-relaxed ${
                  failed ? 'text-block' : 'text-navy-600'
                }`}
              >
                {outcome}
              </p>
            )}
          </>
        ) : null}
      </div>
    </main>
  );
}

function StatusBanner({
  status,
  isLive,
  days,
  effectiveFrom,
}: {
  status: string;
  isLive: boolean;
  days: number;
  effectiveFrom: string;
}) {
  if (status === 'draft') {
    return (
      <div className="card border-gold/40 bg-gold-soft p-4">
        <p className="label text-gold">Unsigned draft</p>
        <p className="mt-1.5 text-[14px] leading-relaxed text-navy">
          Nothing on this page affects any determination. The evaluator cannot see
          this draft, and it will not become rule content until a named person signs
          it.
        </p>
      </div>
    );
  }
  if (status === 'rejected') {
    return (
      <div className="card p-4">
        <p className="label">Rejected</p>
        <p className="mt-1.5 text-[14px] leading-relaxed text-navy-600">
          Considered and declined. Kept, because the record that somebody looked is
          the thing an auditor asks for.
        </p>
      </div>
    );
  }
  if (isLive) {
    return (
      <div className="card border-navy/30 bg-navy p-4 text-parchment">
        <p className="label text-parchment/60">Published</p>
        <p className="mt-1.5 text-[14px] leading-relaxed">
          {days > 0
            ? `This is rule content. It takes effect ${formatDate(effectiveFrom)} — in ${days} day${
                days === 1 ? '' : 's'
              } — and changes no determination before then.`
            : `In force since ${formatDate(effectiveFrom)}.`}
        </p>
      </div>
    );
  }
  return (
    <div className="card border-gold/40 p-4">
      <p className="label text-gold">Signed, not published</p>
      <p className="mt-1.5 text-[14px] leading-relaxed text-navy">
        A signature has been recorded. This still is not rule content — publishing is
        a separate act, and until it happens the evaluator cannot see this.
      </p>
    </div>
  );
}
