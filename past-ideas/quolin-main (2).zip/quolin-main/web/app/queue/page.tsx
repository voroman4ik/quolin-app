'use client';

import Link from 'next/link';
import { useState } from 'react';
import { api } from '@/lib/api';
import { formatDate, humanizeCode } from '@/lib/format';
import { scenarioMeta, useScenario } from '@/lib/scenario';
import { useApi } from '@/lib/useApi';
import { AppBar } from '@/components/AppBar';
import { Chevron } from '@/components/DecisionRow';
import { EmptyState, ErrorState, LoadingBlock, StaleNotice } from '@/components/States';

export default function QueuePage() {
  const { scenario, ready } = useScenario();
  const meta = scenarioMeta(scenario);
  const [scope, setScope] = useState<'scenario' | 'all'>('scenario');

  const queue = useApi(
    () => api.queue(scope === 'all' ? undefined : scenario),
    [scenario, scope],
    { skip: !ready }
  );

  const items = queue.data ?? [];
  const open = items.filter((i) => !i.resolved);
  const resolved = items.filter((i) => i.resolved);

  return (
    <main className="min-h-dvh pb-16">
      <AppBar title="Review queue" subtitle="Referred determinations" back="/" />

      <div className="col space-y-6 pt-5">
        {queue.stale && <StaleNotice />}

        <div className="grid grid-cols-2 gap-1 rounded-md border border-rule bg-white p-1">
          {(['scenario', 'all'] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setScope(s)}
              aria-pressed={scope === s}
              className={`tap rounded-[4px] px-3 text-[13px] font-medium transition-colors ${
                scope === s ? 'bg-navy text-parchment' : 'text-navy-600'
              }`}
            >
              {s === 'scenario' ? meta.name.split(' ')[0] : 'All firms'}
            </button>
          ))}
        </div>

        {queue.loading && !queue.data && <LoadingBlock rows={3} />}
        {queue.error && !queue.data && <ErrorState message={queue.error} onRetry={queue.reload} />}

        {queue.data && (
          <>
            <section aria-labelledby="open-h">
              <h2 id="open-h" className="label mb-2">
                Awaiting review ({open.length})
              </h2>
              {open.length === 0 ? (
                <EmptyState
                  title="Queue is clear"
                  detail="No referrals are awaiting review in this view."
                  action={
                    <Link href="/clients" className="btn-secondary">
                      Run a check
                    </Link>
                  }
                />
              ) : (
                <div className="card divide-y divide-rule">
                  {open.map((q) => (
                    <QueueRow key={q.decision_id} item={q} />
                  ))}
                </div>
              )}
            </section>

            {resolved.length > 0 && (
              <section aria-labelledby="res-h">
                <h2 id="res-h" className="label mb-2">
                  Resolved by override ({resolved.length})
                </h2>
                <div className="card divide-y divide-rule">
                  {resolved.map((q) => (
                    <QueueRow key={q.decision_id} item={q} />
                  ))}
                </div>
              </section>
            )}
          </>
        )}
      </div>
    </main>
  );
}

function QueueRow({
  item,
}: {
  item: {
    decision_id: number;
    client_name: string;
    client_id: string;
    asset_id: string;
    as_of: string;
    pack_version: number;
    reason_codes: string[];
    resolved: boolean;
    approver: string | null;
  };
}) {
  return (
    <Link href={`/decisions/${item.decision_id}`} className="row-link">
      <div className="min-w-0 flex-1">
        <p className="truncate text-[15px] font-medium leading-tight text-navy">
          {item.client_name}
          <span className="mono ml-2 text-navy-400">{item.asset_id}</span>
        </p>
        <p className="mt-0.5 truncate text-[12px] leading-tight text-navy-400">
          {formatDate(item.as_of)} · pack v{item.pack_version} ·{' '}
          {item.reason_codes.map(humanizeCode).join(', ') || 'Referred'}
        </p>
        {item.resolved && (
          <span className="mt-1.5 inline-flex items-center rounded-sm border border-gold/40 bg-gold-soft px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider2 text-gold">
            Overridden{item.approver ? ` · ${item.approver.split('—')[0].trim()}` : ''}
          </span>
        )}
      </div>
      {!item.resolved && (
        <span className="shrink-0 rounded-sm bg-refer-bg px-2 py-1 text-[11px] font-semibold uppercase tracking-wider2 text-refer">
          Refer
        </span>
      )}
      <Chevron />
    </Link>
  );
}
