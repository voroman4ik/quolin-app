'use client';

import { useRouter } from 'next/navigation';
import { use, useState } from 'react';
import { ApiError, api } from '@/lib/api';
import { formatCents, formatDate } from '@/lib/format';
import { useApi } from '@/lib/useApi';
import { useEngineReachable } from '@/lib/connectivity';
import { AppBar } from '@/components/AppBar';
import DecisionRow from '@/components/DecisionRow';
import ExposureBar from '@/components/ExposureBar';
import { ContentStatusChip } from '@/components/IllustrativeBadge';
import { EmptyState, ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import type { ClientDetail, JurisdictionBasis } from '@/lib/types';

/*
 * `params` is a Promise in Next 16 and has to be unwrapped.
 *
 * It was read synchronously here, which a production build resolves to
 * `undefined` — so this screen requested the record `undefined` and rendered
 * "Unavailable" over an engine that was answering perfectly well. Every
 * dynamic route in the app had the same line. It survived because nothing
 * exercised a production build at runtime: `npm run build` compiles it without
 * complaint, and the demo and `make tunnel` both run `next dev`.
 *
 * Found by the offline regression in e2e/, which serves a production build.
 */
export default function ClientDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const client = useApi(() => api.client(id), [id]);
  const assets = useApi(() => api.assets(), []);
  const engineUp = useEngineReachable();

  const router = useRouter();
  const [assetId, setAssetId] = useState('');
  const [checking, setChecking] = useState(false);
  const [checkError, setCheckError] = useState<string | null>(null);

  const c = client.data;

  async function runCheck() {
    if (!assetId) return;
    setChecking(true);
    setCheckError(null);
    try {
      const decision = await api.evaluate({ client_id: id, asset_id: assetId });
      router.push(`/decisions/${decision.id}`);
    } catch (err) {
      setCheckError(
        err instanceof ApiError ? err.message : 'The check could not be completed.',
      );
      setChecking(false);
    }
  }

  return (
    <main className="min-h-dvh pb-20">
      <AppBar
        title={c?.name ?? 'Client'}
        subtitle={c ? `${c.client_category} · ${c.id}` : undefined}
        back="/clients"
      />

      <div className="col space-y-6 pt-5">
        {client.stale && <StaleNotice />}

        {client.loading && !c && <LoadingBlock rows={3} />}
        {client.error && !c && <ErrorState message={client.error} onRetry={client.reload} />}

        {c && (
          <>
            {c.note && (
              <p className="rounded-md border-l-2 border-gold bg-gold-soft px-4 py-3 text-[13px] leading-snug text-navy">
                {c.note}
              </p>
            )}

            {/* Check asset — the primary action, kept above the fold. */}
            <section className="card p-4" aria-labelledby="check-h">
              <h2 id="check-h" className="label mb-2">
                Check asset
              </h2>
              <div className="flex gap-2">
                <select
                  value={assetId}
                  onChange={(e) => setAssetId(e.target.value)}
                  aria-label="Asset"
                  className="field flex-1"
                >
                  <option value="">Select asset…</option>
                  {(assets.data ?? []).map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.symbol} — {a.name}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={runCheck}
                  disabled={!assetId || checking || !engineUp}
                  className="btn-primary px-6"
                >
                  {checking ? 'Checking…' : 'Check'}
                </button>
              </div>
              <p className="mt-2 text-[12px] text-navy-400">
                {engineUp ? (
                  <>
                    Evaluated at {formatCents(c.default_trade_amount_cents)} against{' '}
                    {c.cross_border ? (
                      <>
                        {c.applicable_jurisdictions.length} rule packs —{' '}
                        {c.applicable_jurisdictions
                          .map((j) => `${j.jurisdiction} v${j.pack_version}`)
                          .join(', ')}
                        .
                      </>
                    ) : (
                      <>
                        rule pack {c.jurisdiction} v{c.pack_version}.
                      </>
                    )}
                  </>
                ) : (
                  <>
                    A new check runs the engine, so it needs a connection. Past decisions
                    below remain readable offline.
                  </>
                )}
              </p>
              {assets.error && !assets.data && (
                <p className="mt-2 text-[12px] text-block">
                  Asset list unavailable — {assets.error}
                </p>
              )}
              {checkError && (
                <p className="mt-2 rounded-md border border-block/30 bg-block-bg px-3 py-2 text-[13px] text-block">
                  {checkError}
                </p>
              )}
            </section>

            {/*
             * Only when there is something to say. Every client has a licence,
             * and a card announcing that a domestic client is domestic would be
             * noise on 206 of 210 screens — which is how the four that matter
             * stop being noticed.
             */}
            {(c.cross_border || c.jurisdictions_without_packs.length > 0) && (
              <RegimeCard client={c} />
            )}

            <section className="card p-4" aria-label="Exposure">
              <ExposureBar exposureBps={c.exposure_bps} capBps={c.concentration_cap_bps} />

              {/*
               * Without this, an imported client renders identically to a client
               * who genuinely holds nothing: 0% exposure, "within cap", empty
               * holdings list. The figures are the same and the meaning is not.
               * Custody is a fixture, so a client it has never heard of is
               * assessed as holding nothing — and the concentration rule then
               * passes for a reason that has nothing to do with their portfolio.
               */}
              {!c.custody_on_file && (
                <p className="mt-3 border-l-2 border-gold bg-gold-soft px-3 py-2 text-[13px] leading-relaxed text-navy-800">
                  No custody record for this client. Custody is a fixture in this
                  prototype, so the exposure above is not a view of a real portfolio —
                  it is what the engine assesses when it holds no positions data.
                </p>
              )}

              <div className="mt-4 border-t border-rule pt-3">
                <p className="label mb-2">Holdings</p>
                {c.positions.holdings.length === 0 ? (
                  <p className="text-[13px] text-navy-400">
                    {c.custody_on_file
                      ? 'No digital-asset holdings.'
                      : 'No positions on file.'}
                  </p>
                ) : (
                  <ul className="divide-y divide-rule/60">
                    {c.positions.holdings.map((h) => (
                      <li key={h.asset_id} className="flex justify-between py-1.5">
                        <span className="mono text-navy-600">{h.asset_id}</span>
                        <span className="mono text-navy">{formatCents(h.value_cents)}</span>
                      </li>
                    ))}
                    <li className="flex justify-between py-1.5">
                      <span className="text-[13px] font-medium text-navy">Total</span>
                      <span className="mono font-semibold text-navy">
                        {formatCents(c.positions.crypto_value_cents)}
                      </span>
                    </li>
                  </ul>
                )}
              </div>
            </section>

            <section className="card divide-y divide-rule" aria-label="Profile">
              <Fact label="Assessable portfolio" value={formatCents(c.assessable_portfolio_cents)} mono />
              <Fact label="Loss capacity band" value={`Band ${c.loss_capacity_band}`} />
              <Fact
                label="Knowledge assessed"
                value={
                  c.knowledge_assessed
                    ? `Yes · ${formatDate(c.knowledge_date)}`
                    : 'Not on file'
                }
                tone={c.knowledge_assessed ? undefined : 'block'}
              />
              <Fact
                label="Vulnerability flag"
                value={c.vulnerability_flag ? 'Raised' : 'None'}
                tone={c.vulnerability_flag ? 'refer' : undefined}
              />
              <Fact label="Prior crypto purchases" value={String(c.prior_crypto_purchases)} />
              <Fact
                label="Structural acknowledgements"
                value={c.structural_acks.length ? c.structural_acks.join(', ') : 'None'}
              />
              <Fact label="Date of birth" value={formatDate(c.dob)} />
              {/* Three separate facts, kept apart even when they agree. Which
                  regimes reach a client is derived from these and nothing else. */}
              <Fact label="Advised under licence" value={c.jurisdiction} mono />
              <Fact label="Resident in" value={c.residency} mono />
              <Fact label="Domiciled in" value={c.domicile} mono />
            </section>

            <section aria-labelledby="hist-h">
              <h2 id="hist-h" className="label mb-2">
                Decision history
              </h2>
              {c.decisions.length === 0 ? (
                <EmptyState
                  title="No decisions yet"
                  detail="Run a check above to create the first record for this client."
                />
              ) : (
                <div className="card divide-y divide-rule">
                  {c.decisions.map((d) => (
                    <DecisionRow
                      key={d.id}
                      id={d.id}
                      title={d.asset_id}
                      outcome={d.outcome}
                      asOf={d.as_of}
                      packVersion={d.pack_version}
                    />
                  ))}
                </div>
              )}
            </section>
          </>
        )}
      </div>
    </main>
  );
}

/* ------------------- the regimes that reach this client ------------------ */

/*
 * Before a trade is proposed, and independent of any decision.
 *
 * The three facts on the client — licence, residency, domicile — are what pull
 * a regulator in, so each regime is shown beside the fact that pulled it. No
 * code is named here and no regulator is described here: both arrive from the
 * pack, which is what keeps a jurisdiction a content change rather than a
 * software change.
 */

const BASIS_WORDS: Record<JurisdictionBasis, string> = {
  licensee: 'the licence',
  residency: 'residency',
  domicile: 'domicile',
};

function RegimeCard({ client: c }: { client: ClientDetail }) {
  const gaps = c.jurisdictions_without_packs;

  return (
    <section className="card overflow-hidden" aria-labelledby="regimes-h">
      <div className="flex items-baseline justify-between gap-3 border-b border-rule bg-parchment px-4 py-2">
        <p id="regimes-h" className="label">
          Regimes that apply
        </p>
        <span className="mono text-navy-400">
          {c.applicable_jurisdictions.length + gaps.length} in play
        </span>
      </div>

      <ul className="divide-y divide-rule">
        {c.applicable_jurisdictions.map((j) => (
          <li key={j.jurisdiction} className="flex items-start gap-3 px-4 py-2.5">
            <span className="mono mt-0.5 w-7 shrink-0 font-semibold text-navy">
              {j.jurisdiction}
            </span>
            <span className="min-w-0 flex-1">
              <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
                <span className="text-[13px] leading-snug text-navy">
                  Applies through {j.basis.map((b) => BASIS_WORDS[b] ?? b).join(' and ')}
                </span>
                {j.governing && (
                  <span className="rounded-sm border border-navy-400/40 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider2 text-navy-600">
                    Governing
                  </span>
                )}
                <ContentStatusChip status={j.content_status} />
              </span>
              {j.covers_states.length > 1 && (
                <span className="mono mt-0.5 block text-navy-400">
                  one pack covering {j.covers_states.length} member states
                </span>
              )}
            </span>
            <span className="mono shrink-0 text-navy-400">v{j.pack_version}</span>
          </li>
        ))}

        {/* An applicable regime with no pack is a hole in the answer, and a
            hole stated is worth more than a hole discovered. */}
        {gaps.map((code) => (
          <li key={code} className="flex items-start gap-3 bg-gold-soft px-4 py-2.5">
            <span className="mono mt-0.5 w-7 shrink-0 font-semibold text-gold">{code}</span>
            <span className="text-[13px] leading-snug text-navy-600">
              Applies, and Quolin holds no rule pack for it. No rule from this regime is
              evaluated, so a determination for this client does not speak for it.
            </span>
          </li>
        ))}
      </ul>

      {c.cross_border && (
        <p className="border-t border-rule px-4 py-2.5 text-[12px] leading-snug text-navy-400">
          A check on this client is evaluated under every pack above, then resolved to one
          determination. Which regime bound each constraint is recorded on the decision.
        </p>
      )}
    </section>
  );
}

function Fact({
  label,
  value,
  mono,
  tone,
}: {
  label: string;
  value: string;
  mono?: boolean;
  tone?: 'block' | 'refer';
}) {
  const toneClass =
    tone === 'block' ? 'text-block' : tone === 'refer' ? 'text-refer' : 'text-navy';
  return (
    <div className="flex items-baseline justify-between gap-4 px-4 py-3">
      <span className="text-[13px] text-navy-400">{label}</span>
      <span
        className={`text-right text-[14px] font-medium ${toneClass} ${mono ? 'font-mono text-[13px]' : ''}`}
      >
        {value}
      </span>
    </div>
  );
}
