'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { formatCentsCompact } from '@/lib/format';
import { useScenario } from '@/lib/scenario';
import { useApi } from '@/lib/useApi';
import { AppBar } from '@/components/AppBar';
import { Chevron } from '@/components/DecisionRow';
import { EmptyState, ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import type { ClientSummary } from '@/lib/types';

export default function ClientsPage() {
  const { scenario, ready } = useScenario();
  const [query, setQuery] = useState('');

  const cast = useApi(() => api.castClients(scenario), [scenario], { skip: !ready });
  const all = useApi(() => api.clients(scenario, 200), [scenario], { skip: !ready });

  const castIds = useMemo(
    () => new Set((cast.data ?? []).map((c) => c.id)),
    [cast.data],
  );

  const others = useMemo(() => {
    const list = (all.data ?? []).filter((c) => !castIds.has(c.id));
    const q = query.trim().toLowerCase();
    return q ? list.filter((c) => c.name.toLowerCase().includes(q) || c.id.includes(q)) : list;
  }, [all.data, castIds, query]);

  const castFiltered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = cast.data ?? [];
    return q ? list.filter((c) => c.name.toLowerCase().includes(q) || c.id.includes(q)) : list;
  }, [cast.data, query]);

  return (
    <main className="min-h-dvh pb-16">
      <AppBar title="Clients" subtitle="Select a client to check an asset" back="/" />

      <div className="col space-y-6 pt-5">
        {(cast.stale || all.stale) && <StaleNotice />}

        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by name"
          aria-label="Search clients"
          className="field"
        />

        <section aria-labelledby="cast-h">
          <h2 id="cast-h" className="label mb-2">
            Demonstration clients
          </h2>
          {cast.loading && !cast.data && <LoadingBlock rows={2} />}
          {cast.error && !cast.data && (
            <ErrorState message={cast.error} onRetry={cast.reload} />
          )}
          {cast.data && castFiltered.length === 0 && (
            <EmptyState title="No matches" detail="No demonstration client matches that search." />
          )}
          {castFiltered.length > 0 && (
            <div className="card divide-y divide-rule">
              {castFiltered.map((c) => (
                <ClientLink key={c.id} client={c} showNote />
              ))}
            </div>
          )}
        </section>

        <section aria-labelledby="all-h">
          <h2 id="all-h" className="label mb-2">
            All clients {all.data && <span className="normal-case">({others.length})</span>}
          </h2>
          {all.loading && !all.data && <LoadingBlock rows={2} />}
          {all.error && !all.data && <ErrorState message={all.error} onRetry={all.reload} />}
          {all.data && others.length === 0 && (
            <EmptyState
              title={query ? 'No matches' : 'No other clients'}
              detail={
                query
                  ? 'Try a different name.'
                  : 'This scenario has no additional client records.'
              }
            />
          )}
          {others.length > 0 && (
            <div className="card divide-y divide-rule">
              {others.slice(0, 60).map((c) => (
                <ClientLink key={c.id} client={c} />
              ))}
              {others.length > 60 && (
                <p className="px-5 py-3 text-[12px] text-navy-400">
                  Showing 60 of {others.length}. Refine the search to narrow.
                </p>
              )}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

function ClientLink({ client, showNote }: { client: ClientSummary; showNote?: boolean }) {
  return (
    <Link href={`/clients/${client.id}`} className="row-link">
      <div className="min-w-0 flex-1">
        <p className="truncate text-[15px] font-medium leading-tight text-navy">
          {client.name}
        </p>
        <p className="mt-0.5 truncate text-[12px] leading-tight text-navy-400">
          {formatCentsCompact(client.assessable_portfolio_cents)} portfolio · loss band{' '}
          {client.loss_capacity_band}
          {!client.knowledge_assessed && ' · no knowledge assessment'}
        </p>
        {showNote && client.note && (
          <p className="mt-1 line-clamp-2 text-[12px] leading-snug text-navy-600">
            {client.note}
          </p>
        )}
      </div>
      {client.vulnerability_flag && (
        <span className="shrink-0 rounded-sm bg-refer-bg px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider2 text-refer">
          Vuln
        </span>
      )}
      <Chevron />
    </Link>
  );
}
