/**
 * Generates the PWA icons: a navy square with a gold "Q".
 *
 * Written by hand rather than pulled from a design tool so the build has no
 * binary assets and no image dependencies. Raw RGBA is encoded straight to PNG
 * using zlib, which ships with Node.
 */
import { deflateSync } from 'node:zlib';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const OUT_DIR = resolve(dirname(fileURLToPath(import.meta.url)), '../public/icons');

const NAVY = [0x0f, 0x1c, 0x2e];
const GOLD = [0x8a, 0x64, 0x20];
const PARCHMENT = [0xfa, 0xf8, 0xf4];

/* ----------------------------- PNG encoding ----------------------------- */

const CRC_TABLE = (() => {
  const table = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c;
  }
  return table;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body));
  return Buffer.concat([len, body, crc]);
}

function encodePng(width, height, rgba) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // colour type: RGBA
  // 10-12: compression, filter, interlace — all zero

  // Each scanline is prefixed with filter type 0 (none).
  const stride = width * 4;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0;
    rgba.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/* ------------------------------- drawing -------------------------------- */

/** Linear blend of two colours. */
function mix(a, b, t) {
  return [
    Math.round(a[0] + (b[0] - a[0]) * t),
    Math.round(a[1] + (b[1] - a[1]) * t),
    Math.round(a[2] + (b[2] - a[2]) * t),
  ];
}

/** Coverage of a stroke of half-width `hw` at signed distance `d`, antialiased. */
function coverage(d, hw, aa) {
  const x = (hw - Math.abs(d)) / aa;
  return Math.max(0, Math.min(1, x + 0.5));
}

/** Shortest distance from p to the segment ab. */
function distToSegment(px, py, ax, ay, bx, by) {
  const vx = bx - ax;
  const vy = by - ay;
  const wx = px - ax;
  const wy = py - ay;
  const len2 = vx * vx + vy * vy;
  const t = len2 === 0 ? 0 : Math.max(0, Math.min(1, (wx * vx + wy * vy) / len2));
  const dx = px - (ax + t * vx);
  const dy = py - (ay + t * vy);
  return Math.sqrt(dx * dx + dy * dy);
}

function drawIcon(size, { maskable = false } = {}) {
  const rgba = Buffer.alloc(size * size * 4);
  const cx = (size - 1) / 2;
  const cy = (size - 1) / 2;

  // A maskable icon must keep its mark inside the safe zone (80% circle).
  const scale = maskable ? 0.68 : 0.84;
  const ringR = (size * scale) / 2 - size * 0.06;
  const strokeHW = size * (maskable ? 0.052 : 0.062);
  const aa = size * 0.006;

  // Tail of the Q: a short stroke crossing the lower-right of the ring.
  const diag = Math.SQRT1_2;
  const tailInner = ringR * 0.34;
  const tailOuter = ringR + strokeHW * 0.92;
  const ax = cx + diag * tailInner;
  const ay = cy + diag * tailInner;
  const bx = cx + diag * tailOuter;
  const by = cy + diag * tailOuter;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;

      const dRing = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2) - ringR;
      const ring = coverage(dRing, strokeHW, aa);
      const tail = coverage(
        distToSegment(x, y, ax, ay, bx, by),
        strokeHW * 0.92,
        aa,
      );
      const mark = Math.max(ring, tail);

      const colour = mix(NAVY, GOLD, mark);
      rgba[i] = colour[0];
      rgba[i + 1] = colour[1];
      rgba[i + 2] = colour[2];
      rgba[i + 3] = 255;
    }
  }

  return encodePng(size, size, rgba);
}

/** Apple touch icons render on the home screen with no rounding of their own. */
function write(name, buf) {
  writeFileSync(resolve(OUT_DIR, name), buf);
  console.log(`  ${name}  ${(buf.length / 1024).toFixed(1)} kB`);
}

mkdirSync(OUT_DIR, { recursive: true });
console.log('Generating Quolin icons:');
write('icon-180.png', drawIcon(180));
write('icon-512.png', drawIcon(512));
write('icon-192.png', drawIcon(192));
write('icon-maskable-512.png', drawIcon(512, { maskable: true }));

// Favicon-sized mark for desktop browser tabs.
write('icon-32.png', drawIcon(32));

void PARCHMENT;
