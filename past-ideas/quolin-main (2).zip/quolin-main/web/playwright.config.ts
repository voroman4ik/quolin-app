/**
 * The offline regression, and nothing else.
 *
 * `docs/demo-script.md` walks three failure modes by hand — API down, web down,
 * both down — and the thing at risk of silent regression is small and specific:
 * `X-Quolin-From-Cache` is a bare string in `public/sw.js` and `lib/api.ts`,
 * and if the two drift apart the app renders cached figures as live, with a
 * green "Chain verified" tick over evidence nobody verified.
 *
 * One worker, no retries, and every spec serial. These tests stop and start
 * real servers, so two of them running at once would be two tests fighting over
 * the same ports — and a retry would replay a scenario against a browser
 * profile whose service worker is already in the wrong state.
 */

import { defineConfig, devices } from '@playwright/test';
import { WEB_ORIGIN } from './e2e/servers';

export default defineConfig({
  testDir: './e2e',
  fullyParallel: false,
  workers: 1,
  retries: 0,
  forbidOnly: !!process.env.CI,
  reporter: process.env.CI ? [['list'], ['github']] : [['list']],
  // Generous: several of these wait on a Next dev compile or on a server
  // being confirmed dead, and a timeout here reads as a product failure.
  timeout: 180_000,
  expect: { timeout: 20_000 },
  use: {
    baseURL: WEB_ORIGIN,
    // The point of the exercise. Blocking workers here would leave the suite
    // passing against an app with no offline support whatsoever.
    serviceWorkers: 'allow',
    trace: process.env.CI ? 'retain-on-failure' : 'off',
  },
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        /*
         * Playwright's own Chromium by default, which is what CI installs and
         * what makes a run reproducible.
         *
         * `PLAYWRIGHT_CHANNEL=chrome` drives an already-installed Google Chrome
         * instead. That exists because the bundled download does not extract on
         * every machine — it wedged on the Mac this was written on — and a test
         * nobody can run locally is a test that gets its first real exercise in
         * CI, which is late. Both are the same engine and the same service
         * worker implementation; they are not the same build, so a result from
         * one is not a claim about the other.
         */
        channel: process.env.PLAYWRIGHT_CHANNEL || undefined,
      },
    },
  ],
});
