'use client';

import { formatBps } from '@/lib/format';

/**
 * Current crypto exposure against the concentration cap.
 * Both values are integer basis points; the bar geometry is the only place
 * a ratio is taken, and it never feeds back into a displayed number.
 */
export default function ExposureBar({
  exposureBps,
  capBps,
}: {
  exposureBps: number;
  capBps: number;
}) {
  const over = exposureBps > capBps;
  // Scale so the cap sits at 75% of the track, leaving headroom for breaches.
  const scaleMax = Math.max(capBps, exposureBps, 1) * (over ? 1.05 : 1.34);
  const pct = (v: number) => `${Math.min(100, (v / scaleMax) * 100)}%`;

  return (
    <div>
      <div className="flex items-baseline justify-between">
        <span className="label">Crypto exposure</span>
        <span
          className={`mono font-semibold ${over ? 'text-block' : 'text-navy'}`}
        >
          {formatBps(exposureBps)}
        </span>
      </div>

      <div className="relative mt-2 h-3 w-full overflow-hidden rounded-sm bg-parchment-dark">
        <div
          className={`h-full ${over ? 'bg-block' : 'bg-allow'}`}
          style={{ width: pct(exposureBps) }}
        />
        {/* Cap marker */}
        <div
          className="absolute top-0 h-full w-[2px] bg-navy"
          style={{ left: pct(capBps) }}
          aria-hidden="true"
        />
      </div>

      <div className="mt-1.5 flex items-baseline justify-between">
        <span
          className={`text-[12px] ${over ? 'font-medium text-block' : 'text-navy-400'}`}
        >
          {over ? 'Above cap' : 'Within cap'}
        </span>
        <span className="mono text-navy-400">cap {formatBps(capBps)}</span>
      </div>
    </div>
  );
}
