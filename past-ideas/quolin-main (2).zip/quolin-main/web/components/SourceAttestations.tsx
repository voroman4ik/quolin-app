'use client';

/**
 * Who checked this publication, on what day, and what they said. FP3-26.
 *
 * FP3-16 built `/currency/sources/{id}/verifications` because
 * `watch.sources.verifications` had been written, tested and reached by
 * nothing: an attestation was stored and there was no way to read it back. That
 * fixed the API. This is the screen, and without it the finding was half done —
 * a specialist put their name to "I checked this publication on the 14th" and
 * the only thing anybody could see was that the source was green.
 *
 * It matters most for exactly the sources it exists for. §S13 declared some
 * publications `MANUAL` — behind a login, or a search form nothing can poll —
 * and for those the attestation *is* the monitoring. A currency screen showing
 * green for a manual source with no way to ask who said so is showing an
 * opinion and presenting it as a measurement.
 *
 * Loaded on expand rather than with the page. A regime has several sources and
 * a firm has several regimes; fetching every history to render a row nobody
 * opened would be a dozen requests for a line of text.
 */

import { useState } from 'react';
import { formatDate } from '@/lib/format';
import { useApi } from '@/lib/useApi';
import { admin } from '@/lib/console';

export default function SourceAttestations({
  sourceId,
  manual,
}: {
  sourceId: string;
  /** Whether polling is `MANUAL`, which changes what the absence of records means. */
  manual: boolean;
}) {
  const [open, setOpen] = useState(false);
  const history = useApi(() => admin.sourceVerifications(sourceId), [sourceId], {
    skip: !open,
  });

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="mt-0.5 text-[11px] font-medium text-gold underline"
      >
        Who checked this?
      </button>
    );
  }

  const rows = history.data?.verifications ?? [];

  return (
    <div className="mt-1.5 rounded-md border border-rule bg-parchment-dark px-2.5 py-2">
      {history.loading && !history.data && (
        <p className="text-[11px] leading-snug text-navy-400">Loading attestations…</p>
      )}
      {history.error && (
        <p className="text-[11px] leading-snug text-block">{history.error}</p>
      )}

      {history.data && rows.length === 0 && (
        <p className="text-[11px] leading-snug text-navy-600">
          {manual
            ? // The important case. Nobody can poll this publication, so an
              // automatic check never happened either — "no attestations" means
              // nobody has looked, not "nothing to report".
              'Nobody has recorded a check. This source cannot be polled, so its freshness rests on somebody looking — and nobody has said that they did.'
            : 'No attestations recorded. This source is polled automatically, so its freshness comes from the poll rather than from somebody signing for it.'}
        </p>
      )}

      {rows.length > 0 && (
        <ul className="space-y-1.5">
          {rows.map((v) => (
            <li key={v.id}>
              <p className="text-[11px] leading-snug text-navy">
                <span className="font-medium">{formatDate(v.verified_on)}</span> ·{' '}
                {v.verified_by}
              </p>
              {v.note && (
                <p className="text-[11px] leading-snug text-navy-600">{v.note}</p>
              )}
              {v.attachment_ref && (
                <p className="mono text-navy-400">{v.attachment_ref}</p>
              )}
            </li>
          ))}
        </ul>
      )}

      <button
        type="button"
        onClick={() => setOpen(false)}
        className="mt-2 text-[11px] font-medium text-navy-400 underline"
      >
        Hide
      </button>
    </div>
  );
}
