'use client';

import Link from 'next/link';
import { api } from '@/lib/api';
import { useEngineReachable } from '@/lib/connectivity';
import { scenarioMeta, useScenario } from '@/lib/scenario';
import { useApi } from '@/lib/useApi';

/*
 * Always-visible answer to "which rules am I looking at?". A compliance officer
 * should never have to navigate away from a determination to find out which
 * pack version produced it, or whether the figures are live.
 *
 * The slot named one pack when there was one pack. With a shelf it names the
 * shelf and links to it: four codes and their versions will not fit a phone
 * footer, and a footer that named only the first of them would be quietly
 * wrong on every cross-border screen. The regulatory-currency badge lands in
 * phase 4 once `last_verified_at` is a real field — until then there is nothing
 * truthful to render in that slot, so it stays empty rather than reassuring.
 */
export default function StatusBar() {
  const { scenario, ready } = useScenario();
  const shelf = useApi(() => api.packShelf(), [], { skip: !ready });
  const engineUp = useEngineReachable();

  const meta = scenarioMeta(scenario);
  const entries = shelf.data ?? [];
  const packLabel =
    entries.length === 0
      ? '—'
      : entries.length === 1
        ? `${entries[0].jurisdiction} v${entries[0].current_version ?? '—'}`
        : `${entries.length} packs`;

  return (
    <footer
      aria-label="Session status"
      className="fixed inset-x-0 bottom-0 z-30 border-t border-navy-800 bg-navy text-parchment"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="col flex items-center gap-3 py-1.5">
        <span className="min-w-0 flex-1 truncate text-[11px] leading-tight text-parchment/70">
          {meta.name}
        </span>

        <Link
          href="/packs"
          className="mono shrink-0 text-parchment/70 underline-offset-2 hover:text-parchment hover:underline"
        >
          {packLabel}
        </Link>

        <span
          className={`shrink-0 rounded-sm px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider2 ${
            engineUp ? 'bg-white/10 text-parchment/70' : 'bg-white/10 text-parchment'
          }`}
        >
          {engineUp ? 'Live' : 'Cached'}
        </span>
      </div>
    </footer>
  );
}
