'use client';

/**
 * Verify the whole chain now, and take the result away in a file. FP3-26.
 *
 * `/audit/certificate` has answered since §S7 and nothing asked it. The
 * evidence room already showed one decision's two hashes and the sentence
 * "altering any stored input would break every hash that follows" — which is a
 * claim about every record, made on a screen that had checked one.
 *
 * This is the check. Every link recomputed from the tenant's own anchor, at the
 * moment the button is pressed, because a stored "verified" is a claim about a
 * moment that has passed and the moment it goes stale is exactly the moment it
 * matters.
 *
 * **A broken chain is a result, not an error.** The endpoint answers 200 with
 * `verified: false` and names the decision it broke at, and this renders that
 * as the most important thing on the screen rather than as a failed request. A
 * client that put the strongest finding this system can produce into its retry
 * logic would hide it.
 *
 * **The certificate says what it does not cover.** The audit export is
 * `audit_events` — append-only at the database level and *not* hash-chained.
 * This is `decisions`. The two files make different claims and neither implies
 * the other, and a reader holding both has to be able to tell which is which.
 */

import { useState } from 'react';
import { ApiError } from '@/lib/api';
import { formatDateTime } from '@/lib/format';
import { admin } from '@/lib/console';
import type { AuditCertificate } from '@/lib/console';

export default function ChainCertificate() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AuditCertificate | null>(null);
  const [href, setHref] = useState<string | null>(null);

  async function verify() {
    setBusy(true);
    setError(null);
    setHref(null);
    try {
      const { data } = await admin.auditCertificate();
      setResult(data);
      setHref(
        URL.createObjectURL(
          new Blob([certificateText(data)], { type: 'text/plain;charset=utf-8' }),
        ),
      );
    } catch (err) {
      setError(
        err instanceof ApiError
          ? err.message
          : 'Could not verify the chain. This is a connection failure, not a finding.',
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <section aria-labelledby="cert-h" className="card p-4">
      <h2 id="cert-h" className="label">
        Chain certificate
      </h2>
      <p className="mt-1.5 text-[13px] leading-snug text-navy-600">
        Recompute every link in this firm&rsquo;s decision chain from its anchor,
        now, and produce a certificate stating the result.
      </p>

      {result && (
        <div
          className={`mt-3 rounded-md border p-3 ${
            result.verified
              ? 'border-allow/30 bg-allow-bg'
              : 'border-block/40 bg-block-bg'
          }`}
        >
          <p
            className={`text-[12px] font-semibold uppercase tracking-wider2 ${
              result.verified ? 'text-allow' : 'text-block'
            }`}
          >
            {result.verified ? 'Verified' : 'Chain broken'}
          </p>
          {result.verified ? (
            <p className="mt-1 text-[13px] leading-snug text-navy">
              {result.checked} determination{result.checked === 1 ? '' : 's'}{' '}
              rehashed and matched, checked {formatDateTime(result.checked_at)}.
            </p>
          ) : (
            <p className="mt-1 text-[13px] leading-snug text-navy">
              The chain does not verify. It first disagrees at decision{' '}
              <span className="mono">{result.broken_at_decision_id}</span> — the
              stored hash is not the hash of what is stored beside it. Do not
              treat determinations after that point as evidenced.
            </p>
          )}
          <p className="mono mt-2 break-all text-navy-600">
            anchor {result.genesis_hash}
          </p>
          {result.tip_hash && (
            <p className="mono mt-1 break-all text-navy-600">tip {result.tip_hash}</p>
          )}
        </div>
      )}

      {error && (
        <p className="mt-3 text-[13px] leading-snug text-block" role="alert">
          {error}
        </p>
      )}

      <div className="mt-3 grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={verify}
          disabled={busy}
          className="btn-secondary disabled:opacity-40"
        >
          {busy ? 'Verifying…' : result ? 'Verify again' : 'Verify chain'}
        </button>
        {href && result && (
          <a
            href={href}
            download={`quolin-chain-certificate-${result.tenant_id}.txt`}
            className="btn-primary"
          >
            Download
          </a>
        )}
      </div>

      <p className="mt-3 text-[12px] leading-snug text-navy-400">
        This covers <span className="font-medium">decisions</span>. The audit
        export covers <span className="font-medium">audit_events</span>, which is
        append-only at the database level and is not hash-chained — the two make
        different claims and neither implies the other.
      </p>
    </section>
  );
}

/**
 * The file, as plain text.
 *
 * Not a PDF. A PDF would look more like a certificate and be harder for the
 * person receiving it to check, and every value in here is one they can
 * recompute — which is the property that makes it worth anything. The statement
 * is the engine's own words rather than this component's, so the file cannot
 * claim more than the endpoint did.
 */
function certificateText(c: AuditCertificate): string {
  const lines = [
    'QUOLIN — DECISION CHAIN VERIFICATION CERTIFICATE',
    '',
    `Firm:            ${c.tenant_name} (${c.tenant_id})`,
    `Checked at:      ${c.checked_at}`,
    `Covers:          ${c.covers}`,
    `Result:          ${c.verified ? 'VERIFIED' : 'BROKEN'}`,
    `Records checked: ${c.checked}`,
    `Anchor hash:     ${c.genesis_hash}`,
  ];
  if (c.verified) {
    lines.push(`Tip hash:        ${c.tip_hash ?? ''}`);
  } else {
    lines.push(
      `Breaks at:       decision ${c.broken_at_decision_id}`,
      `Expected hash:   ${c.expected_hash ?? ''}`,
      `Stored hash:     ${c.stored_hash ?? ''}`,
    );
  }
  lines.push('', c.statement, '');
  return lines.join('\n');
}
