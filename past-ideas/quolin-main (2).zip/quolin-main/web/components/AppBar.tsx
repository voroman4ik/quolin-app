'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';

export function AppBar({
  title,
  subtitle,
  back,
  right,
}: {
  title: string;
  subtitle?: string;
  /** Explicit href, or omit for history-back. */
  back?: string | true;
  right?: React.ReactNode;
}) {
  const router = useRouter();

  return (
    <header className="sticky top-0 z-20 border-b border-navy-800 bg-navy text-parchment">
      <div className="col flex items-center gap-3 py-3">
        {back &&
          (typeof back === 'string' ? (
            <Link href={back} aria-label="Back" className="-ml-2 flex h-11 w-9 items-center">
              <BackArrow />
            </Link>
          ) : (
            <button
              type="button"
              aria-label="Back"
              onClick={() => router.back()}
              className="-ml-2 flex h-11 w-9 items-center"
            >
              <BackArrow />
            </button>
          ))}
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-[17px] font-semibold leading-tight">{title}</h1>
          {subtitle && (
            <p className="truncate text-[12px] leading-tight text-parchment/60">{subtitle}</p>
          )}
        </div>
        {right}
      </div>
    </header>
  );
}

function BackArrow() {
  return (
    <svg width="11" height="18" viewBox="0 0 11 18" fill="none" aria-hidden="true">
      <path
        d="M9.5 1.5 2 9l7.5 7.5"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/*
 * The wordmark used on the home screen only.
 *
 * The accent said AU while AU was the only pack. A wordmark is the last place
 * a jurisdiction belongs: the product is the engine, and which regimes are
 * loaded is content that changes without a deploy. "Prototype" is the standing
 * claim instead, matching the masthead every generated document carries.
 */
export function Wordmark() {
  return (
    <div className="flex items-baseline gap-2">
      <span className="text-[22px] font-semibold tracking-tight text-parchment">Quolin</span>
      <span className="text-[11px] uppercase tracking-wider2 text-gold">Prototype</span>
    </div>
  );
}
