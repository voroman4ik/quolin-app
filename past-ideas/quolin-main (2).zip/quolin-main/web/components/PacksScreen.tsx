'use client';

import { useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { formatDate, formatProvenanceValue, humanizeRef } from '@/lib/format';
import { useApi } from '@/lib/useApi';
import { AppBar } from '@/components/AppBar';
import IllustrativeBadge, { ContentStatusChip } from '@/components/IllustrativeBadge';
import { EmptyState, ErrorState, LoadingBlock, StaleNotice } from '@/components/States';
import type { PackShelfEntry, PackVersion } from '@/lib/types';

/*
 * The shelf, and one pack off it.
 *
 * This screen is the architectural claim made visible: the same engine, four
 * bodies of content, and a version history under each. Nothing here names a
 * regime — the shelf arrives from the API, the regulator's name and the states
 * a pack covers arrive from pack content, and which pack opens first is
 * derived from the data rather than chosen in this file.
 *
 * A regime with one version on the shelf is the ordinary case for a new
 * jurisdiction, and it is not a degenerate two-version comparison. Comparing v1
 * against itself would print a table of unchanged values under a heading
 * promising change, which is worse than saying there is nothing to compare yet.
 *
 * This lives in `components/` rather than being a route itself because two URLs
 * render it: `/packs`, which opens on whichever regime has governed the most
 * decisions, and `/packs/AU`, which opens on the one named. The second exists
 * so publishing a draft can link straight to the pack it just created — the
 * step where "the rules changed" becomes "and here is the changed rule".
 */

export default function PacksScreen({ initial }: { initial?: string }) {
  const shelf = useApi(() => api.packShelf(), []);
  const entries = shelf.data ?? [];

  // Seeded from the URL when there is one, but still ordinary state: once the
  // screen is open the shelf buttons move between regimes, and pushing a route
  // per tap would bury the back button in history entries.
  const [picked, setPicked] = useState<string | null>(initial ?? null);

  /*
   * The default is the regime that has governed the most determinations —
   * the firm's own licence, without this file having to know which that is.
   */
  const fallback = useMemo(() => {
    if (entries.length === 0) return null;
    return [...entries].sort(
      (a, b) => b.decisions_governed - a.decisions_governed,
    )[0].jurisdiction;
  }, [entries]);

  const code = picked ?? fallback;

  const pack = useApi(() => api.pack(code!), [code], { skip: !code });
  const p = pack.data;

  const versions = useMemo(
    () => [...(p?.versions ?? [])].sort((a, b) => a.version - b.version),
    [p],
  );

  // Undefined when the regime has only ever had one pack. Every comparison
  // below is written to fall back to a single column when it is.
  const older: PackVersion | undefined = versions.length > 1 ? versions[0] : undefined;
  const newer: PackVersion | undefined = versions[versions.length - 1];

  const diff = p?.diffs?.find(
    (d) => d.from_version === older?.version && d.to_version === newer?.version,
  );

  const changedNames = new Set(diff?.thresholds_changed.map((t) => t.name) ?? []);
  const addedNames = new Set(diff?.thresholds_added.map((t) => t.name) ?? []);

  /**
   * Union of threshold keys across both versions, changed ones first.
   * Scalars go in the comparison; lookup tables get their own full-width
   * blocks, since squeezing a band map into a narrow column on a phone makes
   * both values unreadable.
   */
  const { scalarKeys, tableKeys } = useMemo(() => {
    const keys = new Set<string>([
      ...Object.keys(older?.thresholds ?? {}),
      ...Object.keys(newer?.thresholds ?? {}),
    ]);
    const sorted = [...keys].sort((a, b) => {
      const rank = (k: string) => (changedNames.has(k) ? 0 : addedNames.has(k) ? 1 : 2);
      return rank(a) - rank(b) || a.localeCompare(b);
    });
    const isTable = (k: string) => {
      const v =
        (newer?.thresholds as Record<string, unknown>)?.[k] ??
        (older?.thresholds as Record<string, unknown>)?.[k];
      return typeof v === 'object' && v !== null;
    };
    return {
      scalarKeys: sorted.filter((k) => !isTable(k)),
      tableKeys: sorted.filter(isTable),
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [older, newer, diff]);

  const grid = older ? 'grid-cols-[1fr_auto_auto]' : 'grid-cols-[1fr_auto]';

  return (
    <main className="min-h-dvh pb-16">
      <AppBar
        title="Rule packs"
        subtitle={
          p ? `${p.name} · ${p.regulator || 'regulator not stated'}` : `${entries.length} regimes`
        }
        back="/"
      />

      <div className="col space-y-6 pt-5">
        {(shelf.stale || pack.stale) && <StaleNotice />}
        {shelf.error && entries.length === 0 && (
          <ErrorState message={shelf.error} onRetry={shelf.reload} />
        )}

        {entries.length > 0 && (
          <Shelf entries={entries} selected={code} onSelect={setPicked} />
        )}

        {(shelf.loading || pack.loading) && !p && <LoadingBlock rows={3} />}
        {pack.error && !p && <ErrorState message={pack.error} onRetry={pack.reload} />}

        {/*
          A shelf that loads successfully with nothing on it renders no error,
          no loader and no pack — every branch below is false and the screen is
          the app bar over blank parchment. It should not happen against a
          seeded database, which is exactly why it would happen in a room: an
          unseeded deployment looks like a broken build rather than an empty one.
        */}
        {!shelf.loading && !shelf.error && entries.length === 0 && (
          <EmptyState
            title="No rule packs are loaded"
            detail="The engine started but has no content to evaluate against. Run make seed against this database."
            action={
              <button type="button" onClick={shelf.reload} className="btn-secondary">
                Check again
              </button>
            }
          />
        )}

        {/* A pack on the shelf with no versions under it — same blank screen,
            different cause, and worth distinguishing from the one above. */}
        {p && !newer && (
          <EmptyState
            title={`${p.name} has no versions`}
            detail="The regime is on the shelf but nothing has been signed into force for it yet, so there is nothing to compare or show."
          />
        )}

        {p && newer && (
          <>
            {/* The whole screen is rule content. If this regime's content is
                unreviewed, that is the first thing to say about it. */}
            <IllustrativeBadge
              jurisdictions={p.content_status === 'ILLUSTRATIVE' ? [p.jurisdiction] : []}
            />

            <p className="text-[14px] leading-relaxed text-navy-600">
              Thresholds are content, not code. A decision is always evaluated against the
              pack in force on its date, which is why historic determinations remain
              reproducible after the rules change. Adding the regime below took no change
              to the engine.
            </p>

            {p.covers_states.length > 1 && (
              <div className="card border-navy/20 bg-parchment px-4 py-3">
                <p className="label">
                  One pack · {p.covers_states.length} member states
                </p>
                <p className="mono mt-1.5 leading-relaxed text-navy-600">
                  {p.covers_states.join(' · ')}
                </p>
                <p className="mt-2 text-[13px] leading-snug text-navy-600">
                  A regime that legislates as a bloc is one body of content, not{' '}
                  {p.covers_states.length}. Where a member state departs from it, that
                  departure is a pack of its own — not a fork of this one.
                </p>
              </div>
            )}

            {/* Version headers */}
            <div className={`grid gap-3 ${older ? 'grid-cols-2' : 'grid-cols-1'}`}>
              {older && <VersionCard v={older} tone="past" />}
              <VersionCard v={newer} tone="current" />
            </div>

            {!older && (
              <p className="rounded-md border-l-2 border-navy-400/40 bg-parchment px-4 py-3 text-[13px] leading-snug text-navy-600">
                This regime is on its first pack, so there is no version comparison to
                draw. The thresholds below are the whole of its content to date.
              </p>
            )}

            {/* Threshold comparison */}
            <section aria-labelledby="th-h">
              <h2 id="th-h" className="label mb-2">
                Thresholds
              </h2>
              <div className="card overflow-hidden">
                <div className={`grid ${grid} gap-x-3 border-b border-rule bg-parchment px-3 py-2`}>
                  <span className="label">Name</span>
                  {older && <span className="label text-right">v{older.version}</span>}
                  <span className="label text-right">v{newer.version}</span>
                </div>
                <div className="divide-y divide-rule/60">
                  {scalarKeys.map((k) => {
                    const changed = changedNames.has(k);
                    const added = addedNames.has(k);
                    const a = (older?.thresholds as Record<string, unknown>)?.[k];
                    const b = (newer.thresholds as Record<string, unknown>)[k];
                    return (
                      <div
                        key={k}
                        className={`grid ${grid} items-baseline gap-x-3 px-3 py-2 ${
                          changed ? 'bg-gold-soft' : ''
                        }`}
                      >
                        <span className="mono min-w-0 break-words text-navy-600">
                          {k}
                          {changed && (
                            <span className="ml-1.5 rounded-sm bg-gold px-1 py-0.5 text-[9px] font-bold uppercase tracking-wider2 text-white">
                              changed
                            </span>
                          )}
                          {added && (
                            <span className="ml-1.5 rounded-sm border border-gold/50 px-1 py-0.5 text-[9px] font-bold uppercase tracking-wider2 text-gold">
                              new
                            </span>
                          )}
                        </span>
                        {older && (
                          <span
                            className={`mono text-right ${
                              changed ? 'text-navy-400 line-through' : 'text-navy'
                            }`}
                          >
                            {renderThreshold(k, a)}
                          </span>
                        )}
                        <span
                          className={`mono text-right ${
                            changed || added ? 'font-semibold text-gold' : 'text-navy'
                          }`}
                        >
                          {renderThreshold(k, b)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
              {diff && diff.thresholds_changed.length > 0 && (
                <p className="mt-2 text-[13px] leading-snug text-navy-600">
                  {diff.thresholds_changed
                    .map(
                      (t) =>
                        `${humanizeRef(t.name)} tightened from ${formatProvenanceValue(
                          t.name,
                          t.from,
                        )} to ${formatProvenanceValue(t.name, t.to)}`,
                    )
                    .join('; ')}
                  .
                </p>
              )}

              {tableKeys.length > 0 && (
                <div className="mt-3 space-y-3">
                  {tableKeys.map((k) => (
                    <LookupTable
                      key={k}
                      name={k}
                      a={(older?.thresholds as Record<string, unknown>)?.[k]}
                      b={(newer.thresholds as Record<string, unknown>)[k]}
                      va={older?.version}
                      vb={newer.version}
                    />
                  ))}
                </div>
              )}
            </section>

            {/* Rules added */}
            {diff && (
              <section aria-labelledby="rules-h">
                <h2 id="rules-h" className="label mb-2">
                  Rule changes · v{diff.from_version} → v{diff.to_version}
                </h2>
                <div className="space-y-3">
                  <RuleDelta title="Added" rules={diff.rules_added} tone="add" />
                  <RuleDelta title="Removed" rules={diff.rules_removed} tone="remove" />
                  <RuleDelta title="Modified" rules={diff.rules_modified} tone="mod" />
                  {diff.rules_added.length === 0 &&
                    diff.rules_removed.length === 0 &&
                    diff.rules_modified.length === 0 && (
                      <div className="card p-4">
                        <p className="text-[13px] text-navy-400">
                          No rules were added, removed or modified between these versions.
                        </p>
                      </div>
                    )}
                </div>
              </section>
            )}

            {/* Full rule list of current pack */}
            <section aria-labelledby="cur-h">
              <h2 id="cur-h" className="label mb-2">
                Rules in force · v{newer.version} ({newer.rule_count})
              </h2>
              <div className="card divide-y divide-rule">
                {newer.rules.map((r) => {
                  const isNew = diff?.rules_added.some((x) => x.rule_id === r.rule_id);
                  return (
                    <div key={r.rule_id} className={`px-4 py-3 ${isNew ? 'bg-gold-soft' : ''}`}>
                      <div className="flex items-start justify-between gap-3">
                        <p className="text-[14px] font-medium leading-snug text-navy">
                          {r.title}
                        </p>
                        <span className="mono shrink-0 text-navy-400">{r.on_fail}</span>
                      </div>
                      <p className="mono mt-0.5 text-navy-400">
                        {r.rule_id} · {r.reason_code}
                        {isNew && (
                          <span className="ml-1.5 text-gold">· new in v{newer.version}</span>
                        )}
                      </p>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Signatory */}
            <section className="card p-4">
              <p className="label mb-2">Signatory</p>
              <div className="space-y-3">
                {versions.map((v) => (
                  <div
                    key={v.version}
                    className="border-t border-rule pt-3 first:border-0 first:pt-0"
                  >
                    <p className="mono text-navy-400">
                      v{v.version} · {formatDate(v.effective_from)} —{' '}
                      {v.effective_to ? formatDate(v.effective_to) : 'current'}
                    </p>
                    <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[14px] text-navy">
                      {v.signed_by}
                      <ContentStatusChip status={v.content_status} />
                    </p>
                    <p className="mt-1 text-[12px] leading-snug text-navy-400">{v.notes}</p>
                  </div>
                ))}
              </div>
              <p className="mt-3 border-t border-rule pt-3 text-[12px] leading-snug text-navy-400">
                Every version carries a named human who signed it off. A version with no
                signatory is a version nobody stands behind, and the loader refuses one.
              </p>
            </section>
          </>
        )}
      </div>
    </main>
  );
}

/* ------------------------------ the shelf ------------------------------- */

function Shelf({
  entries,
  selected,
  onSelect,
}: {
  entries: PackShelfEntry[];
  selected: string | null;
  onSelect: (code: string) => void;
}) {
  return (
    <section aria-labelledby="shelf-h">
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <h2 id="shelf-h" className="label">
          Regimes on the shelf
        </h2>
        <span className="mono text-navy-400">one engine</span>
      </div>

      <div className="card divide-y divide-rule overflow-hidden">
        {entries.map((e) => {
          const on = e.jurisdiction === selected;
          return (
            <button
              key={e.jurisdiction}
              type="button"
              onClick={() => onSelect(e.jurisdiction)}
              aria-pressed={on}
              className={`tap flex w-full items-start gap-3 px-4 py-3 text-left transition-colors ${
                on ? 'bg-navy text-parchment' : 'hover:bg-parchment-dark'
              }`}
            >
              <span
                className={`mono mt-0.5 w-7 shrink-0 font-semibold ${
                  on ? 'text-gold' : 'text-navy'
                }`}
              >
                {e.jurisdiction}
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
                  <span
                    className={`text-[15px] font-medium leading-snug ${
                      on ? '' : 'text-navy'
                    }`}
                  >
                    {e.name}
                  </span>
                  {!on && <ContentStatusChip status={e.content_status} />}
                </span>
                <span
                  className={`mt-0.5 block text-[12px] leading-snug ${
                    on ? 'text-parchment/70' : 'text-navy-400'
                  }`}
                >
                  {e.regulator}
                </span>
                <span
                  className={`mono mt-1 block ${on ? 'text-parchment/60' : 'text-navy-400'}`}
                >
                  {e.versions} version{e.versions === 1 ? '' : 's'}
                  {e.covers_states.length > 1 && <> · {e.covers_states.length} states</>}
                  {/* Governed and considered are different claims. A regime
                      reached by residency never governs, and reporting only the
                      first would say a pack that blocked a trade did nothing. */}
                  {' · '}
                  {e.decisions_governed} governed
                  {e.decisions_considered > e.decisions_governed && (
                    <> · {e.decisions_considered} considered</>
                  )}
                </span>
              </span>
              <span
                className={`mono shrink-0 ${on ? 'font-semibold text-gold' : 'text-navy-400'}`}
              >
                {e.current_version === null ? 'none in force' : `v${e.current_version}`}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}

function renderThreshold(name: string, value: unknown): string {
  if (value === undefined) return '—';
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return Object.entries(value as Record<string, unknown>)
      .map(([k, v]) => `${k}:${v}`)
      .join(' ');
  }
  return formatProvenanceValue(name, value);
}

/** A band-map threshold, shown key by key so both versions stay legible. */
function LookupTable({
  name,
  a,
  b,
  va,
  vb,
}: {
  name: string;
  a: unknown;
  b: unknown;
  va?: number;
  vb: number;
}) {
  const toMap = (v: unknown): Record<string, string> => {
    if (Array.isArray(v)) return { '': v.join(', ') };
    if (v && typeof v === 'object') {
      return Object.fromEntries(
        Object.entries(v as Record<string, unknown>).map(([k, x]) => [k, String(x)]),
      );
    }
    return {};
  };
  const ma = toMap(a);
  const mb = toMap(b);
  const keys = [...new Set([...Object.keys(ma), ...Object.keys(mb)])];
  const grid = va === undefined ? 'grid-cols-[1fr_auto]' : 'grid-cols-[1fr_auto_auto]';

  return (
    <div className="card overflow-hidden">
      <p className="mono border-b border-rule bg-parchment px-3 py-2 text-navy-600">{name}</p>
      <div className={`grid ${grid} gap-x-4 px-3 py-1.5`}>
        <span className="label">Key</span>
        {va !== undefined && <span className="label text-right">v{va}</span>}
        <span className="label text-right">v{vb}</span>
      </div>
      <div className="divide-y divide-rule/60 border-t border-rule">
        {keys.map((k) => {
          const changed = va !== undefined && ma[k] !== mb[k];
          return (
            <div
              key={k}
              className={`grid ${grid} gap-x-4 px-3 py-1.5 ${changed ? 'bg-gold-soft' : ''}`}
            >
              <span className="mono text-navy-600">{k || 'values'}</span>
              {va !== undefined && (
                <span className="mono text-right text-navy-400">{ma[k] ?? '—'}</span>
              )}
              <span
                className={`mono text-right ${changed ? 'font-semibold text-gold' : 'text-navy'}`}
              >
                {mb[k] ?? '—'}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function VersionCard({ v, tone }: { v: PackVersion; tone: 'past' | 'current' }) {
  const current = tone === 'current';
  return (
    <div
      className={`card p-3 ${current ? 'border-navy bg-navy text-parchment' : 'bg-white'}`}
    >
      <div className="flex items-baseline justify-between">
        <p className={`text-[18px] font-semibold ${current ? '' : 'text-navy'}`}>
          v{v.version}
        </p>
        <span
          className={`text-[10px] uppercase tracking-wider2 ${
            current ? 'text-gold' : 'text-navy-400'
          }`}
        >
          {current ? 'In force' : 'Superseded'}
        </span>
      </div>
      <p className={`mono mt-1.5 ${current ? 'text-parchment/60' : 'text-navy-400'}`}>
        from {v.effective_from}
      </p>
      <p className={`mono ${current ? 'text-parchment/60' : 'text-navy-400'}`}>
        to {v.effective_to ?? '—'}
      </p>
      <p className={`mono mt-1.5 ${current ? 'text-parchment/60' : 'text-navy-400'}`}>
        {v.rule_count} rules
      </p>
    </div>
  );
}

function RuleDelta({
  title,
  rules,
  tone,
}: {
  title: string;
  rules: { rule_id: string; title: string; on_fail: string; reason_code: string }[];
  tone: 'add' | 'remove' | 'mod';
}) {
  if (rules.length === 0) return null;
  const color =
    tone === 'add' ? 'text-allow' : tone === 'remove' ? 'text-block' : 'text-gold';
  return (
    <div className="card overflow-hidden">
      <p className={`label border-b border-rule bg-parchment px-4 py-2 ${color}`}>
        {title} ({rules.length})
      </p>
      <div className="divide-y divide-rule/60">
        {rules.map((r) => (
          <div key={r.rule_id} className="px-4 py-3">
            <p className="text-[14px] font-medium leading-snug text-navy">{r.title}</p>
            <p className="mono mt-0.5 text-navy-400">
              {r.rule_id} · on fail {r.on_fail} · {r.reason_code}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
