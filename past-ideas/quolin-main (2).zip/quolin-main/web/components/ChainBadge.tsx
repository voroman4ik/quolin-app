'use client';

import { shortHash } from '@/lib/format';
import type { ChainState } from '@/lib/types';

/**
 * Tamper-evidence indicator. Ticks only when the API says the chain verified
 * *on this request*.
 *
 * `stale` matters more than it looks: a cached copy of a past verification is
 * not a verification. Showing a green tick sourced from cache would assert
 * integrity nobody just checked, which is precisely the claim this product
 * exists to make trustworthy.
 */
export default function ChainBadge({
  chain,
  tone = 'light',
  stale = false,
}: {
  chain: ChainState | null | undefined;
  tone?: 'light' | 'dark';
  stale?: boolean;
}) {
  if (!chain) return null;
  const ok = chain.verified && !stale;
  const dark = tone === 'dark';

  return (
    <div
      className={`flex items-center gap-2 rounded-md border px-3 py-2 ${
        dark ? 'border-parchment/15 bg-white/5' : 'border-rule bg-white'
      }`}
    >
      <span
        aria-hidden="true"
        className={`inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-[10px] font-bold ${
          stale
            ? 'bg-navy-400 text-white'
            : ok
              ? 'bg-allow text-white'
              : 'bg-block text-white'
        }`}
      >
        {stale ? '·' : ok ? '✓' : '!'}
      </span>
      <div className="min-w-0 flex-1">
        <p
          className={`text-[12px] font-medium leading-tight ${
            dark ? 'text-parchment' : 'text-navy'
          }`}
        >
          {stale
            ? 'Not verified — engine unreachable'
            : ok
              ? 'Chain verified'
              : 'Chain integrity failure'}
          <span className={dark ? 'text-parchment/50' : 'text-navy-400'}>
            {' '}
            · {chain.checked} records{stale ? ' at last sync' : ''}
          </span>
        </p>
        <p
          className={`mono truncate leading-tight ${
            dark ? 'text-parchment/45' : 'text-navy-400'
          }`}
        >
          tip {shortHash(chain.tip_hash)}
        </p>
      </div>
    </div>
  );
}
