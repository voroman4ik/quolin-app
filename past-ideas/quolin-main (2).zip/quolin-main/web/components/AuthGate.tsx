'use client';

/**
 * The lock screen, and the thing that decides whether to show it.
 *
 * This is not the security boundary — the API is, on every request, and it
 * would refuse an unauthenticated call even if this component were deleted.
 * What this does is stop the app rendering shells and error states to someone
 * who simply has not signed in yet, which is a different job and a purely
 * cosmetic one. Saying so in the file matters: a reviewer who mistakes a
 * client-side gate for access control will draw the wrong conclusion about the
 * whole system.
 *
 * Three states, and the distinction between the first two is the one that
 * usually gets missed:
 *
 *   null  — not asked yet. Renders nothing. Rendering the login form here
 *           would flash it at every already-signed-in user on every reload.
 *   false — asked, and the answer was no. Renders the lock screen.
 *   true  — renders the app.
 *
 * There is a fourth case that only exists on a plane, and it is the one worth
 * reading carefully. Offline, the engine cannot be asked, but the service
 * worker still holds the last answer it gave — so a device that signed in
 * before takeoff gets a cached "yes". We honour it, because the spec requires
 * the walkthrough to survive dead conference Wi-Fi and because refusing would
 * protect nothing: the records the gate would be hiding are already in this
 * same browser's storage, and the gate was never the security boundary. What
 * we do not do is let it look live — `offline` puts the banner up before the
 * first screen paints, so nobody reads a cached figure as a confirmed one.
 *
 * FP3-12 adds a fifth case, between signed-out and signed-in: **confined**. A
 * session holding a role that demands a second factor, with none enrolled, may
 * reach four paths and nothing else. It is authenticated — throwing it back to
 * the lock screen would be a lie and would also be a loop, since signing in
 * again produces the same session — so it gets the one screen it can act on.
 * The engine answers `mfa_required` itself; this file deliberately holds no
 * copy of which roles those are.
 */

import { usePathname } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { ApiError, MfaRequired, api, type SessionState } from '@/lib/api';
import { reportAuthenticated, useAuthState } from '@/lib/auth';
import { Wordmark } from '@/components/AppBar';
import OfflineBanner from '@/components/OfflineBanner';
import OverdueBanner from '@/components/OverdueBanner';
import StatusBar from '@/components/StatusBar';
import MfaEnrolment from '@/components/MfaEnrolment';
import { ReauthProvider } from '@/components/Reauth';

/**
 * Screens that must render to somebody with no session, and cannot get one.
 *
 * `/invite` is where a person spends the token that gives them their first
 * password. Gating it would show them a sign-in form for an account they cannot
 * yet sign in to, which is FP3-11's original defect wearing the gate's clothes.
 *
 * An explicit list rather than a prefix match: "every path starting with /auth"
 * is the shape of rule that quietly exempts the next screen somebody adds under
 * it, and the API's own `mfa.UNLOCKED_PATHS` makes the same argument for the
 * same reason.
 */
const UNGATED = new Set(['/invite']);

export default function AuthGate({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const authed = useAuthState();
  const [asked, setAsked] = useState(false);
  const [unreachable, setUnreachable] = useState(false);
  const [state, setState] = useState<SessionState | null>(null);

  // Re-asked rather than assumed after enrolment. `mfa_required` is the
  // engine's answer and the client's job is to relay it, so the way out of the
  // enrolment screen is the engine saying the session is no longer confined —
  // not this component deciding it must be.
  const [nonce, setNonce] = useState(0);
  const recheck = useCallback(() => setNonce((n) => n + 1), []);

  useEffect(() => {
    let alive = true;
    api
      .session()
      .then((s) => {
        if (!alive) return;
        reportAuthenticated(s.authenticated);
        setState(s);
        setAsked(true);
      })
      .catch(() => {
        // No network *and* no cached answer — so this browser has never
        // completed a sign-in here, or signed out and cleared the cache. That
        // is not the same as being signed out, and asking someone whose API is
        // not running to sign in sends them looking for the wrong problem. It
        // is also unrecoverable until the engine is back: signing in is a POST,
        // which no cache can serve.
        if (!alive) return;
        setUnreachable(true);
        setAsked(true);
      });
    return () => {
      alive = false;
    };
  }, [nonce]);

  // Checked before `asked`, so the invitation screen paints immediately rather
  // than waiting on a session question whose answer is known to be "no".
  if (UNGATED.has(pathname)) return <>{children}</>;

  if (!asked) return null;

  if (unreachable) {
    return (
      <Shell>
        <p className="text-[14px] leading-relaxed text-navy-600">
          Cannot reach the decision engine, so there is no way to tell whether
          this browser is signed in. This is a connection problem, not a
          sign-in problem — the API is probably not running.
        </p>
        <p className="mt-3 text-[13px] leading-relaxed text-navy-400">
          Signing in needs a live engine, so there is nothing to type here until
          it is back. If you are offline on purpose, note that the cached demo
          only opens on a device that signed in before losing connection.
        </p>
        <button
          type="button"
          onClick={() => window.location.reload()}
          className="btn-secondary mt-4 w-full"
        >
          Try again
        </button>
      </Shell>
    );
  }

  if (authed !== true) return <LockScreen onSignedIn={recheck} />;

  // Authenticated, and able to do exactly one thing. Rendering the app here
  // would render four screens' worth of 403s and no way to act on any of them.
  if (state?.mfa_required) {
    return <MfaEnrolment roles={state.roles ?? []} onEnrolled={recheck} />;
  }

  return (
    <ReauthProvider>
      <OfflineBanner />
      {/* FP3-17. On every screen of the app and not dismissible: the state it
          reports is that determinations being made right now carry a stamp
          saying they were made on superseded rules. */}
      <OverdueBanner />
      {children}
      <StatusBar />
    </ReauthProvider>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <main className="flex min-h-dvh flex-col justify-center bg-navy px-6 py-10">
      <div className="mx-auto w-full max-w-sm">
        <div className="mb-6 text-parchment">
          <Wordmark />
        </div>
        <div className="card p-6">{children}</div>
      </div>
    </main>
  );
}

function LockScreen({ onSignedIn }: { onSignedIn: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  // Set once the engine has said this account owes a second factor. The code
  // field is not shown before then: the engine will not say whether an account
  // has one until the password checks out, and a field that appeared for every
  // address would answer that question for free.
  const [needsCode, setNeedsCode] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const ready = email.trim() !== '' && password !== '' && (!needsCode || code !== '');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!ready || busy) return;
    setBusy(true);
    setError(null);
    try {
      await api.login({ email: email.trim(), password, code });
      // Not a redirect: the gate re-renders into the app on the state change,
      // so whatever URL was being visited is the one that loads. A phone that
      // opened a deep link to a decision lands on that decision.
      setPassword('');
      setCode('');
      // Ask the engine again rather than assuming a sign-in means the app. A
      // privileged account with no authenticator has just obtained a session
      // that can do nothing but enrol, and only `/auth/session` says so.
      onSignedIn();
    } catch (err) {
      if (err instanceof MfaRequired) {
        // Not a failure, so it is not shown as one. The password stays put:
        // making someone retype it to add six digits is how they end up
        // keeping it somewhere convenient.
        setNeedsCode(true);
        setError(null);
      } else {
        setError(
          err instanceof ApiError ? err.message : 'Could not check those details.',
        );
        setPassword('');
      }
      setCode('');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Shell>
      <h1 className="text-[18px] font-semibold leading-tight text-navy">
        Sign in
      </h1>
      <p className="mt-2 text-[13px] leading-relaxed text-navy-600">
        Quolin holds client records, decisions and evidence. Every action you
        take here is recorded against your name.
      </p>

      <form onSubmit={submit}>
        <label className="label mt-5 block" htmlFor="email">
          Work email
        </label>
        <input
          id="email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="field mt-1"
          autoComplete="username"
          autoFocus
          disabled={busy || needsCode}
        />

        <label className="label mt-4 block" htmlFor="password">
          Password
        </label>
        <input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="field mt-1"
          autoComplete="current-password"
          // No maxLength and no pattern: client-side rules on a secret field
          // only ever tell an attacker the shape of what they are guessing.
          disabled={busy || needsCode}
        />

        {needsCode && (
          <>
            <label className="label mt-4 block" htmlFor="code">
              Six-digit code
            </label>
            <input
              id="code"
              type="text"
              inputMode="numeric"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="field mt-1"
              autoComplete="one-time-code"
              autoFocus
              disabled={busy}
            />
            <p className="mt-2 text-[12px] leading-snug text-navy-400">
              From your authenticator app. Each code works once.
            </p>
          </>
        )}

        {error && (
          <p className="mt-2 text-[13px] leading-snug text-block" role="alert">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={busy || !ready}
          className="btn-primary mt-4 w-full disabled:opacity-40"
        >
          {busy ? 'Checking…' : 'Sign in'}
        </button>
      </form>

      {/*
        Said on the lock screen rather than only in the docs. This is the first
        thing a technical reviewer sees, and it is the right moment to be
        straight about where identity comes from: these are real accounts held
        here, not accounts federated from the customer's own directory.
      */}
      <p className="mt-5 border-t border-rule pt-4 text-[12px] leading-snug text-navy-400">
        Accounts are held in this deployment rather than in your organisation's
        identity provider. Single sign-on is the next step; until it lands,
        joiners and leavers are managed here.
      </p>
    </Shell>
  );
}
