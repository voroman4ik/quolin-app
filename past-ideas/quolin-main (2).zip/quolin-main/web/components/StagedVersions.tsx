'use client';

import Link from 'next/link';
import { useState } from 'react';
import { ApiError, api } from '@/lib/api';
import { useApi } from '@/lib/useApi';
import type { StagedAdvance } from '@/lib/types';

/**
 * S5 — what is about to change for this firm, and how long they have.
 *
 * The customer-facing half of "how do you control vendor changes?", which is the
 * first question a bank's diligence team asks a rules vendor. A pinned firm sees
 * what is staged with a countdown and takes it deliberately; an auto firm sees
 * an empty list *and* the policy that explains why — a different answer from
 * "nothing has changed", and worth being able to tell apart.
 *
 * **An overdue window does not apply itself.** The countdown going red is a
 * prompt, not a timer on somebody else's decision. A version that applied itself
 * because nobody clicked would be pinning in name only.
 *
 * **Declining asks for a reason and will not proceed without one.** The reason is
 * the whole value: it is what gets escalated, and a refusal with no explanation
 * is a dead end for whoever picks it up.
 */
export function StagedVersions() {
  const state = useApi(() => api.advances(), []);
  const data = state.data;

  if (state.loading && !data) return null;
  if (!data) return null;

  return (
    <section aria-labelledby="staged-h" className="space-y-3">
      <div className="flex items-baseline justify-between gap-3">
        <h2 id="staged-h" className="label">
          About to change
        </h2>
        <PolicyBadge policy={data.policy} windowDays={data.uat_window_days} />
      </div>

      {data.pending.length === 0 ? (
        <div className="card p-5">
          <p className="text-[13px] leading-relaxed text-navy-600">
            {data.policy === 'auto'
              ? 'Nothing waiting. This firm takes new rule versions automatically on their effective date, so there is never a window to act in — every advance is recorded on the version itself.'
              : 'Nothing waiting. When a new rule version becomes effective you will see it here, with a window to check it against your own book before it applies.'}
          </p>
        </div>
      ) : (
        data.pending.map((item) => (
          <StagedRow key={item.id} item={item} onDone={state.reload} />
        ))
      )}
    </section>
  );
}

function PolicyBadge({ policy, windowDays }: { policy: string; windowDays: number }) {
  const pinned = policy === 'pinned';
  return (
    <span
      className={`rounded px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide ${
        pinned ? 'bg-gold/15 text-gold' : 'bg-navy/10 text-navy-600'
      }`}
      title={
        pinned
          ? `New versions are staged for ${windowDays} days before they apply.`
          : 'New versions apply on their effective date.'
      }
    >
      {pinned ? `pinned · ${windowDays}d` : 'auto-advance'}
    </span>
  );
}

function StagedRow({ item, onDone }: { item: StagedAdvance; onDone: () => void }) {
  const [note, setNote] = useState('');
  const [declining, setDeclining] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function act(kind: 'take' | 'decline') {
    setBusy(true);
    setError(null);
    try {
      if (kind === 'take') await api.takeAdvance(item.id, note);
      else await api.declineAdvance(item.id, note);
      onDone();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not record that.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className={`card p-5 ${item.overdue ? 'border-block/40' : 'border-gold/40'}`}>
      <div className="flex items-baseline justify-between gap-3">
        <p className="label">
          {item.jurisdiction} v{item.pack_version}
        </p>
        <Countdown daysLeft={item.days_left} overdue={item.overdue} />
      </div>

      <p className="mt-2 text-[14px] leading-relaxed text-navy">
        This version is in force on the shelf and is <span className="font-medium">not</span>{' '}
        yet applied to your determinations. Check it against your own book, then take
        it — or decline and tell us why.
      </p>

      <Link
        href={`/packs/${item.jurisdiction}`}
        className="btn-secondary mt-3 w-full text-center"
      >
        See what changed in {item.jurisdiction} v{item.pack_version}
      </Link>

      <label className="label mt-4 block" htmlFor={`note-${item.id}`}>
        {declining ? 'Why are you declining?' : 'Note (optional)'}
      </label>
      <textarea
        id={`note-${item.id}`}
        rows={declining ? 3 : 2}
        className="field mt-1"
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder={
          declining
            ? 'What is wrong with this version, in enough detail to escalate.'
            : 'What you checked, and against what.'
        }
      />

      {declining ? (
        <div className="mt-3 flex gap-2">
          <button
            type="button"
            onClick={() => act('decline')}
            disabled={busy || !note.trim()}
            className="btn-primary flex-1 disabled:opacity-40"
          >
            {busy ? 'Recording…' : 'Decline this version'}
          </button>
          <button
            type="button"
            onClick={() => {
              setDeclining(false);
              setError(null);
            }}
            className="btn-secondary flex-1"
          >
            Cancel
          </button>
        </div>
      ) : (
        <div className="mt-3 flex gap-2">
          <button
            type="button"
            onClick={() => act('take')}
            disabled={busy}
            className="btn-primary flex-1 disabled:opacity-40"
          >
            {busy ? 'Recording…' : 'Take this version'}
          </button>
          <button
            type="button"
            onClick={() => setDeclining(true)}
            className="btn-secondary flex-1"
          >
            Decline
          </button>
        </div>
      )}

      {declining && !note.trim() && (
        <p className="mt-2 text-[12px] leading-snug text-navy-400">
          A reason is required. It is what gets escalated, and a refusal with no
          explanation is a dead end for whoever picks it up.
        </p>
      )}

      {error && <p className="mt-2 text-[13px] leading-relaxed text-block">{error}</p>}
    </div>
  );
}

/**
 * How long is left, and what the deadline actually means.
 *
 * The title says it in words because a red badge on its own reads as "this is
 * about to happen to you", and the opposite is true: nothing applies until
 * somebody takes it.
 */
function Countdown({ daysLeft, overdue }: { daysLeft: number | null; overdue: boolean }) {
  if (daysLeft === null) return null;
  if (overdue) {
    return (
      <span
        className="rounded bg-block/10 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-block"
        title="Past the window. Nothing has applied — this is still waiting for you."
      >
        overdue
      </span>
    );
  }
  return (
    <span className="mono text-[12px] text-navy-400">
      {daysLeft} day{daysLeft === 1 ? '' : 's'} left
    </span>
  );
}
