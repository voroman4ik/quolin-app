'use client';

/**
 * Which rung of the adoption ladder this firm is on. FP3-26.
 *
 * `/adoption` has answered since §S10 and no screen asked it, which made the
 * ladder a thing described in documents and invisible in the product. That is
 * the wrong way round for the one rung that changes what the app *means*:
 * in `shadow`, nothing Quolin decides reaches anybody. A screen showing two
 * hundred determinations and a REFER queue, on a firm in shadow, is showing
 * work that is not being acted on — and the endpoint's own docstring says the
 * explanation travels with the stage precisely so that fact is not tribal
 * knowledge.
 *
 * On the dashboard rather than in a settings page, for the same reason the
 * "what's real, what's mocked" link is in the main navigation: a boundary a
 * viewer has to go looking for is one they find after they have already
 * believed a number that depended on it.
 */

import { useApi } from '@/lib/useApi';
import { admin } from '@/lib/console';
import type { AdoptionState } from '@/lib/console';

export default function AdoptionBadge({ tone = 'light' }: { tone?: 'light' | 'dark' }) {
  const { data } = useApi(() => admin.adoption(), []);
  if (!data) return null;

  const dark = tone === 'dark';
  const rung = data.ladder.indexOf(data.stage);
  const live = data.stage !== 'pilot' && data.stage !== 'shadow';

  return (
    <div
      className={`rounded-md border px-3 py-2.5 ${
        dark ? 'border-parchment/15 bg-navy-800' : 'border-rule bg-white'
      }`}
    >
      <div className="flex items-center justify-between gap-3">
        <p
          className={`text-[11px] font-medium uppercase tracking-wider2 ${
            dark ? 'text-parchment/45' : 'text-navy-400'
          }`}
        >
          Adoption
        </p>
        <Ladder ladder={data.ladder} at={rung} dark={dark} />
      </div>

      <p
        className={`mt-1 text-[15px] font-semibold capitalize leading-tight ${
          dark ? 'text-parchment' : 'text-navy'
        }`}
      >
        {data.stage}
        {!live && (
          <span
            className={`ml-2 rounded-sm px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider2 ${
              dark ? 'bg-gold/20 text-gold' : 'bg-gold-soft text-gold'
            }`}
          >
            Not acted on
          </span>
        )}
      </p>

      {/* The engine's own sentence, not a paraphrase. It is written to be shown
          to customers and it says the thing that matters about each rung. */}
      <p
        className={`mt-1 text-[12px] leading-snug ${
          dark ? 'text-parchment/60' : 'text-navy-600'
        }`}
      >
        {data.means}
      </p>

      <LimitedScope data={data} dark={dark} />
    </div>
  );
}

/**
 * The slice of the book that is live, when the rung is `limited`.
 *
 * Shown only on that rung, because on the others it is either everything or
 * nothing and an empty "scope: —" line would suggest a limit that is not there.
 */
function LimitedScope({ data, dark }: { data: AdoptionState; dark: boolean }) {
  if (data.stage !== 'limited') return null;
  const scope = data.limited_scope;
  const parts = [
    ...(scope?.scenarios ?? []),
    ...(scope?.asset_ids ?? []),
  ];
  return (
    <p
      className={`mt-1 text-[12px] leading-snug ${
        dark ? 'text-parchment/60' : 'text-navy-600'
      }`}
    >
      {parts.length > 0
        ? `Live for: ${parts.join(', ')}. Everything else is shadow.`
        : 'No slice has been named, so nothing is live yet.'}
    </p>
  );
}

function Ladder({ ladder, at, dark }: { ladder: string[]; at: number; dark: boolean }) {
  return (
    <div className="flex items-center gap-1" aria-hidden="true">
      {ladder.map((_, i) => (
        <span
          key={i}
          className={`h-1.5 w-4 rounded-full ${
            i <= at
              ? dark
                ? 'bg-gold'
                : 'bg-navy'
              : dark
                ? 'bg-parchment/15'
                : 'bg-rule-strong'
          }`}
        />
      ))}
    </div>
  );
}
