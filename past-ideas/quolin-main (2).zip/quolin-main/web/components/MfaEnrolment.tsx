'use client';

/**
 * The screen a privileged account meets on its first morning. FP3-12(a).
 *
 * `MFA_REQUIRED_ROLES` names four roles. A session holding one of them with no
 * verified second factor may reach exactly four paths — session, logout, enrol,
 * verify — and nothing else. `POST /auth/mfa/enrol` was one of those four and
 * had no screen anywhere in this app, so what a firm's first approver actually
 * experienced was a sign-in that appeared to work followed by a 403 on every
 * page, with a sentence about second factors buried in a JSON body they would
 * never see.
 *
 * That is not a missing feature, it is a locked door with the key on the other
 * side. The engine deliberately keeps the door openable — `mfa.py` explains
 * why refusing the sign-in outright would be worse — and this is the thing that
 * was supposed to be on the other side of it.
 *
 * **Shown instead of the app, not alongside it.** A banner would be dismissible
 * and the app behind it does not work; every screen would render its own error
 * state and the person would be reading four of them at once. There is exactly
 * one thing this session can do, so it is the only thing on screen.
 *
 * **The secret is shown once.** The engine has no route that will read it back,
 * which is what makes storing it encrypted worth anything — a server that
 * re-displays a shared secret on request hands it to anybody holding a stolen
 * session. So the copy says so, and losing it means enrolling again rather than
 * asking somebody to look it up.
 */

import { useState } from 'react';
import { ApiError, api } from '@/lib/api';
import { Wordmark } from '@/components/AppBar';

export default function MfaEnrolment({
  roles,
  onEnrolled,
}: {
  roles: string[];
  /** Called once the code has been confirmed and the session is no longer confined. */
  onEnrolled: () => void;
}) {
  const [started, setStarted] = useState<{ secret: string; otpauth_url: string } | null>(
    null,
  );
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function start() {
    setBusy(true);
    setError(null);
    try {
      const body = await api.mfaEnrol();
      setStarted({ secret: body.secret, otpauth_url: body.otpauth_url });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not start enrolment.');
    } finally {
      setBusy(false);
    }
  }

  async function confirm(e: React.FormEvent) {
    e.preventDefault();
    if (busy || code.trim() === '') return;
    setBusy(true);
    setError(null);
    try {
      await api.mfaVerify(code.trim());
      onEnrolled();
    } catch (err) {
      // The secret stays on screen. Making somebody re-enrol because they
      // mistyped six digits would leave an abandoned unconfirmed credential
      // behind on every fumble, and hand them a second secret to add to an app
      // that already has the first.
      setError(err instanceof ApiError ? err.message : 'Could not check that code.');
      setCode('');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="flex min-h-dvh flex-col justify-center bg-navy px-6 py-10">
      <div className="mx-auto w-full max-w-sm">
        <div className="mb-6 text-parchment">
          <Wordmark />
        </div>

        <div className="card p-6">
          <h1 className="text-[18px] font-semibold leading-tight text-navy">
            Set up your authenticator
          </h1>
          <p className="mt-2 text-[13px] leading-relaxed text-navy-600">
            {/*
              Names the role rather than saying "your account requires MFA".
              The person is owed the reason: it is the role somebody granted
              them that carries this, and if they did not expect to hold it,
              that is worth their finding out here.
            */}
            You hold {roles.length === 1 ? 'the role' : 'the roles'}{' '}
            <span className="font-medium text-navy">{roles.join(', ')}</span>, which{' '}
            {roles.length === 1 ? 'puts' : 'put'} your name to rule content and to
            decisions about other people&rsquo;s clients. A password on its own is
            something you can be talked out of over the phone, so this account needs a
            second factor before it can do anything else.
          </p>

          {!started && (
            <>
              <button
                type="button"
                onClick={start}
                disabled={busy}
                className="btn-primary mt-5 w-full disabled:opacity-40"
              >
                {busy ? 'Preparing…' : 'Begin'}
              </button>
              <p className="mt-3 text-[12px] leading-snug text-navy-400">
                You will need an authenticator app on your phone — the one your firm
                already uses is fine. Nothing is sent by SMS.
              </p>
            </>
          )}

          {started && (
            <>
              <div className="mt-5 rounded-md border border-rule bg-parchment-dark p-4">
                <p className="label">Your secret</p>
                <p className="mono mt-1 select-all break-all text-[15px] leading-snug text-navy">
                  {started.secret}
                </p>
                <p className="mt-3 text-[12px] leading-snug text-navy-600">
                  Add this to your authenticator app, either by typing it or by
                  pasting the link below.
                </p>
                <p className="mono mt-2 select-all break-all text-[11px] leading-snug text-navy-400">
                  {started.otpauth_url}
                </p>
              </div>

              {/*
                Stated plainly and next to the secret, not in a help page. This
                is the one moment it exists in a form a person can read, and
                somebody who closes the tab expecting to come back for it has
                lost it.
              */}
              <p className="mt-3 text-[12px] leading-snug text-block">
                Shown once. There is no way to read it back — if you lose it before
                confirming, start again and you will be given a new one.
              </p>

              <form onSubmit={confirm}>
                <label className="label mt-5 block" htmlFor="enrol-code">
                  Six-digit code from the app
                </label>
                <input
                  id="enrol-code"
                  type="text"
                  inputMode="numeric"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="field mt-1"
                  autoComplete="one-time-code"
                  autoFocus
                  disabled={busy}
                />
                <p className="mt-2 text-[12px] leading-snug text-navy-400">
                  Typing a working code is what confirms the enrolment. Until then
                  the credential does not count, and this session stays where it is.
                </p>

                {error && (
                  <p className="mt-3 text-[13px] leading-snug text-block" role="alert">
                    {error}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={busy || code.trim() === ''}
                  className="btn-primary mt-4 w-full disabled:opacity-40"
                >
                  {busy ? 'Checking…' : 'Confirm and continue'}
                </button>
              </form>
            </>
          )}

          {error && !started && (
            <p className="mt-3 text-[13px] leading-snug text-block" role="alert">
              {error}
            </p>
          )}

          <button
            type="button"
            onClick={() => void api.logout()}
            className="btn-secondary mt-5 w-full"
          >
            Sign out
          </button>
        </div>
      </div>
    </main>
  );
}
