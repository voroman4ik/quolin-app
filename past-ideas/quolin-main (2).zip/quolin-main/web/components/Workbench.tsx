'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ApiError, api } from '@/lib/api';
import { formatProvenanceValue, humanizeRef } from '@/lib/format';
import type { DraftEdit, PackDiff, PackDraftDetail, RuleProvenance } from '@/lib/types';

/**
 * S5 — where a compliance specialist writes rule content.
 *
 * This is the screen four specialists will live in, and it is built around one
 * belief: the person using it can read a regulation and cannot read Python. So
 * nothing here shows them JSON they have to edit as text, every error is a
 * sentence about a rule rather than about a parser, and the thing they are
 * changing is always shown next to the thing it would replace.
 *
 * **Validation runs as they type, and never saves.** A specialist trying a
 * threshold to see what it would break must not be leaving half-edited content
 * behind them — so the check is a separate call that writes nothing, and saving
 * is a deliberate act with its own button.
 *
 * **Faults come from the pack validator unchanged.** They were written for this
 * reader: each one names the rule, the problem, and where possible the fix. A
 * layer here that reworded them would be a second copy of the same advice,
 * drifting.
 *
 * **Editing stops at the signature.** Once somebody has signed, the fields go
 * read-only and the screen says why. A signature attests to specific bytes, and
 * an edit afterwards would leave a named person's name on content they never
 * saw — which is worse than unsigned content, because it reads as reviewed.
 */

type Tab = 'changes' | 'rules' | 'thresholds' | 'documents' | 'history';

export function Workbench({
  draft,
  onSaved,
}: {
  draft: PackDraftDetail;
  onSaved: () => void;
}) {
  const editable = draft.status === 'draft' || draft.status === 'in_review';

  const body = (draft.body ?? {}) as {
    rules?: RuleShape[];
    thresholds?: Record<string, unknown>;
  };

  const [tab, setTab] = useState<Tab>('changes');
  const [rules, setRules] = useState<RuleShape[]>(() => body.rules ?? []);
  const [thresholds, setThresholds] = useState<Record<string, unknown>>(
    () => body.thresholds ?? {},
  );
  const [faults, setFaults] = useState<string[]>([]);
  const [checking, setChecking] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState<string | null>(null);

  // What is on screen differs from what is stored. Tracked rather than inferred
  // from a deep comparison, because the useful question is "have I typed
  // something" and a specialist who reverts a digit by hand should still see the
  // save button they are reaching for.
  const [dirty, setDirty] = useState(false);

  const edit: DraftEdit = useMemo(
    () => ({ rules, thresholds }),
    [rules, thresholds],
  );

  // Debounced, because this runs on every keystroke and the validator is a round
  // trip. Half a second is long enough that a number being typed is not checked
  // four times, and short enough that the answer feels immediate.
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!dirty) return;
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(async () => {
      setChecking(true);
      try {
        const result = await api.validateDraft(draft.id, edit);
        setFaults(result.faults);
      } catch (err) {
        setFaults([
          err instanceof ApiError ? err.message : 'Could not check this draft.',
        ]);
      } finally {
        setChecking(false);
      }
    }, 500);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [draft.id, edit, dirty]);

  const save = useCallback(async () => {
    setSaving(true);
    setSaved(null);
    try {
      await api.editDraft(draft.id, edit);
      setDirty(false);
      setSaved('Saved.');
      onSaved();
    } catch (err) {
      setSaved(err instanceof ApiError ? err.message : 'Could not save this draft.');
    } finally {
      setSaving(false);
    }
  }, [draft.id, edit, onSaved]);

  return (
    <section aria-labelledby="workbench-h" className="space-y-4">
      <div className="flex items-baseline justify-between gap-3">
        <h2 id="workbench-h" className="label">
          Workbench
        </h2>
        {!editable && (
          <p className="text-[12px] leading-snug text-navy-400">
            Read-only — this draft has been signed.
          </p>
        )}
      </div>

      {!editable && (
        <div className="card border-navy/20 bg-navy/[0.03] p-4">
          <p className="text-[13px] leading-relaxed text-navy-600">
            A signature attests to specific content. Editing this now would leave{' '}
            <span className="font-medium text-navy">{draft.signed_by || 'a signatory'}</span>
            &rsquo;s name on rules they never saw, which reads as reviewed and is not.
            To change it, raise a new draft from the version in force.
          </p>
        </div>
      )}

      <nav className="flex gap-1 border-b border-rule" aria-label="Workbench sections">
        {(
          [
            ['changes', 'What changes'],
            ['rules', `Rules (${rules.length})`],
            ['thresholds', `Numbers (${Object.keys(thresholds).length})`],
            ['documents', 'Documents'],
            ['history', 'History'],
          ] as [Tab, string][]
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            aria-current={tab === key ? 'page' : undefined}
            className={`px-3 py-2 text-[13px] font-medium ${
              tab === key
                ? 'border-b-2 border-gold text-navy'
                : 'text-navy-400 hover:text-navy-600'
            }`}
          >
            {label}
          </button>
        ))}
      </nav>

      {tab === 'changes' && <Changes draft={draft} />}
      {tab === 'rules' && (
        <Rules
          rules={rules}
          editable={editable}
          onChange={(next) => {
            setRules(next);
            setDirty(true);
          }}
        />
      )}
      {tab === 'thresholds' && (
        <Thresholds
          thresholds={thresholds}
          editable={editable}
          onChange={(next) => {
            setThresholds(next);
            setDirty(true);
          }}
        />
      )}
      {tab === 'documents' && <Documents draft={draft} />}
      {tab === 'history' && <History draftId={draft.id} />}

      {editable && tab !== 'history' && tab !== 'documents' && (
        <FaultPanel
          faults={faults}
          checking={checking}
          dirty={dirty}
          saving={saving}
          saved={saved}
          onSave={save}
        />
      )}
    </section>
  );
}

/* --------------------------------------------------------------- documents -- */

/**
 * What a regulator would receive, rendered from this draft's own templates.
 *
 * Invariant 8 is the reason this tab exists: artefact titles and templates are
 * pack content, so a specialist editing this draft can change what goes out the
 * door without touching a rule. Seeing it before signing is the difference
 * between catching a renamed statutory heading and publishing it.
 *
 * **A real determination is the sample.** Placeholder text would show the
 * template's shape and hide every question worth asking — whether the figures
 * land in the right columns, whether a long product name wraps, whether a
 * threshold reads as a percentage or a fraction.
 *
 * **HTML in a sandboxed frame rather than the PDF.** Nobody is filing this one,
 * and paying WeasyPrint several seconds per click would buy nothing the eye can
 * see. The sandbox is because the frame renders a template — scripts and
 * navigation are off, so a preview cannot act.
 */
function Documents({ draft }: { draft: PackDraftDetail }) {
  const templates = ((draft.body?.artefact_templates as Record<string, string>) ??
    {}) as Record<string, string>;
  const kinds = Object.keys(templates).sort();
  const [kind, setKind] = useState(kinds[0] ?? '');
  const [html, setHtml] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!kind) return;
    let live = true;
    setLoading(true);
    setError(null);
    api
      .previewArtefact(draft.id, kind)
      .then((text) => {
        if (live) setHtml(text);
      })
      .catch((err) => {
        if (live) {
          setHtml(null);
          setError(
            err instanceof ApiError ? err.message : 'Could not render this document.',
          );
        }
      })
      .finally(() => {
        if (live) setLoading(false);
      });
    return () => {
      live = false;
    };
  }, [draft.id, kind]);

  if (kinds.length === 0) {
    return (
      <div className="card p-5">
        <p className="text-[13px] leading-relaxed text-navy-600">
          This draft defines no artefact templates, so there is nothing a regulator
          would receive from it.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        {kinds.map((k) => (
          <button
            key={k}
            type="button"
            onClick={() => setKind(k)}
            className={`rounded px-2.5 py-1 text-[12px] font-medium ${
              k === kind
                ? 'bg-navy text-white'
                : 'bg-navy/5 text-navy-600 hover:bg-navy/10'
            }`}
          >
            {(draft.body?.artefact_titles as Record<string, string>)?.[k] ??
              k.replace(/_/g, ' ')}
          </button>
        ))}
      </div>

      <p className="text-[12px] leading-relaxed text-navy-400">
        Rendered from this draft against a real determination, so the figures are
        ones you can check. Nothing is filed and nothing is stored — this document
        exists only on this screen.
      </p>

      {loading && !html && (
        <div className="card p-5">
          <p className="text-[13px] text-navy-400">Rendering…</p>
        </div>
      )}
      {error && (
        <div className="card p-5">
          <p className="text-[13px] leading-relaxed text-block">{error}</p>
        </div>
      )}
      {html && (
        <iframe
          title={`Preview of ${kind}`}
          srcDoc={html}
          sandbox=""
          className="h-[640px] w-full rounded border border-rule bg-white"
        />
      )}
    </div>
  );
}

/* ------------------------------------------------------------ what changes -- */

/**
 * The proposed content beside the version it would replace.
 *
 * Side by side rather than as a list of new values, because "8%" means nothing
 * on its own and "10% → 8%" is the whole review. A specialist checking a pack
 * against a regulation is checking a movement.
 */
function Changes({ draft }: { draft: PackDraftDetail }) {
  const delta = draft.delta && 'thresholds_changed' in draft.delta ? (draft.delta as PackDiff) : null;
  const unavailable = draft.delta && 'unavailable' in draft.delta ? draft.delta.unavailable : null;

  if (unavailable) {
    return (
      <div className="card p-5">
        <p className="text-[13px] leading-relaxed text-navy-600">{unavailable}</p>
      </div>
    );
  }
  if (!delta) return null;

  const nothing =
    delta.thresholds_changed.length === 0 &&
    delta.thresholds_added.length === 0 &&
    delta.rules_added.length === 0 &&
    delta.rules_removed.length === 0 &&
    delta.rules_modified.length === 0;

  return (
    <div className="card p-5">
      <p className="label">
        {draft.jurisdiction} v{draft.base_version} → v{draft.proposed_version}
      </p>

      {nothing && (
        <p className="mt-3 text-[13px] leading-relaxed text-navy-600">
          Nothing. This draft is identical to the version it was cut from — worth
          knowing before anybody signs it.
        </p>
      )}

      {delta.thresholds_changed.map((t) => (
        <div key={t.name} className="flex items-baseline justify-between gap-3 border-t border-rule py-2 first:border-0">
          <span className="min-w-0 flex-1 text-[13px] leading-snug text-navy">
            {humanizeRef(t.name)}
          </span>
          <span className="mono shrink-0 text-navy-400 line-through">
            {formatProvenanceValue(t.name, t.from)}
          </span>
          <span aria-hidden className="text-navy-300">→</span>
          <span className="mono shrink-0 font-semibold text-navy">
            {formatProvenanceValue(t.name, t.to)}
          </span>
        </div>
      ))}

      {delta.rules_added.length > 0 && (
        <p className="mt-3 border-t border-rule pt-3 text-[13px] text-navy-600">
          Rules added: {delta.rules_added.map((r) => r.rule_id).join(', ')}
        </p>
      )}
      {delta.rules_removed.length > 0 && (
        <p className="mt-1 text-[13px] text-navy-600">
          Rules removed: {delta.rules_removed.join(', ')}
        </p>
      )}
      {delta.rules_modified.length > 0 && (
        <p className="mt-1 text-[13px] text-navy-600">
          Rules modified: {delta.rules_modified.join(', ')}
        </p>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------- rules -- */

interface RuleShape {
  rule_id: string;
  title?: string;
  on_fail: string;
  reason_code: string;
  severity?: number | string;
  provenance?: RuleProvenance;
  [key: string]: unknown;
}

/**
 * Each rule as a card, with the part a specialist owns editable and the
 * predicate shown rather than typed.
 *
 * The predicate is deliberately read-only here. A structured editor for nested
 * boolean conditions is a real piece of work and a text box holding JSON is not
 * an editor — it is a way to produce invalid packs confidently. Until the
 * structured one exists, the honest arrangement is that a specialist reviews the
 * logic, edits the numbers and the provenance, and asks for a logic change
 * rather than making one by hand. `docs/post-raise.md` says so.
 */
function Rules({
  rules,
  editable,
  onChange,
}: {
  rules: RuleShape[];
  editable: boolean;
  onChange: (next: RuleShape[]) => void;
}) {
  const update = (index: number, patch: Partial<RuleShape>) => {
    const next = rules.map((r, i) => (i === index ? { ...r, ...patch } : r));
    onChange(next);
  };

  return (
    <div className="space-y-3">
      {rules.map((rule, index) => (
        <div key={rule.rule_id ?? index} className="card p-5">
          <div className="flex items-baseline justify-between gap-3">
            <p className="mono text-navy-400">{rule.rule_id}</p>
            <span
              className={`rounded px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide ${
                rule.on_fail === 'BLOCK'
                  ? 'bg-block/10 text-block'
                  : 'bg-gold/15 text-gold'
              }`}
            >
              {rule.on_fail}
            </span>
          </div>

          <label className="label mt-3 block" htmlFor={`title-${index}`}>
            What this rule is
          </label>
          <input
            id={`title-${index}`}
            className="field mt-1"
            value={rule.title ?? ''}
            disabled={!editable}
            onChange={(e) => update(index, { title: e.target.value })}
          />

          <p className="label mt-3">The check</p>
          <pre className="mono mt-1 overflow-x-auto rounded bg-navy/[0.04] p-3 text-[12px] leading-relaxed text-navy-600">
            {describePredicate(rule.predicate)}
          </pre>

          <Provenance
            value={rule.provenance}
            editable={editable}
            onChange={(provenance) => update(index, { provenance })}
          />
        </div>
      ))}
    </div>
  );
}

/**
 * A rule's condition in words rather than as JSON.
 *
 * Not a full renderer — nested boolean trees get their own screen when the
 * structured editor lands. What this does is turn the common shape, a single
 * comparison, into a sentence a non-programmer can check against a regulation,
 * and say plainly when a condition is more complicated than that rather than
 * dumping braces at somebody.
 */
function describePredicate(predicate: unknown): string {
  const OPS: Record<string, string> = {
    eq: 'is', neq: 'is not', lt: 'is less than', lte: 'is at most',
    gt: 'is more than', gte: 'is at least', in: 'is one of',
    not_in: 'is not one of', contains: 'includes', not_contains: 'does not include',
  };
  const term = (t: unknown): string => {
    if (t === null || typeof t !== 'object') return String(t);
    const o = t as Record<string, unknown>;
    if ('const' in o) return JSON.stringify(o.const);
    if ('field' in o) return humanizeRef(String(o.field));
    if ('calc' in o) return humanizeRef(String(o.calc));
    if ('threshold' in o) return `the ${humanizeRef(String(o.threshold))}`;
    if ('lookup' in o) return `the ${humanizeRef(String(o.lookup))} for ${term(o.key)}`;
    return JSON.stringify(o);
  };

  if (!predicate || typeof predicate !== 'object') return String(predicate);
  const p = predicate as Record<string, unknown>;
  const op = String(p.op ?? '');

  if (op === 'and' || op === 'or') {
    const parts = (p.of as unknown[]) ?? [];
    return parts.map((c) => `• ${describePredicate(c)}`).join(`\n${op}\n`);
  }
  if (op === 'not') return `not (${describePredicate(p.of)})`;
  if (OPS[op]) return `${term(p.left)} ${OPS[op]} ${term(p.right)}`;
  return JSON.stringify(predicate, null, 2);
}

/* -------------------------------------------------------------- provenance -- */

const EMPTY: RuleProvenance = {
  source_document: '',
  section: '',
  verified_by: '',
  verified_on: '',
};

/**
 * Where this rule came from — four fields, and all four or none.
 *
 * The engine refuses a partial provenance, so the form says so before somebody
 * fills in two boxes and finds out on save. A rule carrying a source document
 * and no verifier reads as checked when nobody has checked it.
 */
function Provenance({
  value,
  editable,
  onChange,
}: {
  value?: RuleProvenance;
  editable: boolean;
  onChange: (next: RuleProvenance | undefined) => void;
}) {
  const current = value ?? EMPTY;
  const filled = (Object.keys(EMPTY) as (keyof RuleProvenance)[]).filter((k) =>
    String(current[k] ?? '').trim(),
  );
  const partial = filled.length > 0 && filled.length < 4;

  const set = (key: keyof RuleProvenance, next: string) => {
    const merged = { ...current, [key]: next };
    const anything = (Object.keys(EMPTY) as (keyof RuleProvenance)[]).some((k) =>
      String(merged[k] ?? '').trim(),
    );
    onChange(anything ? merged : undefined);
  };

  return (
    <details className="mt-4 border-t border-rule pt-3" open={filled.length > 0}>
      <summary className="label cursor-pointer select-none">
        Where this came from{' '}
        {filled.length === 4 && <span className="text-navy-400">· recorded</span>}
        {partial && <span className="text-block">· incomplete</span>}
        {filled.length === 0 && <span className="text-navy-400">· not recorded</span>}
      </summary>

      {partial && (
        <p className="mt-2 text-[12px] leading-snug text-block">
          All four, or none. A rule with a source document and no verifier reads as
          checked when nobody has checked it.
        </p>
      )}

      <div className="mt-2 grid gap-2 sm:grid-cols-2">
        {(
          [
            ['source_document', 'Document', 'ASIC RG 227'],
            ['section', 'Section', 's4.2'],
            ['verified_by', 'Verified by', 'Name of the person who checked it'],
            ['verified_on', 'Verified on', 'YYYY-MM-DD'],
          ] as [keyof RuleProvenance, string, string][]
        ).map(([key, label, placeholder]) => (
          <div key={key}>
            <label className="label block" htmlFor={`prov-${key}`}>
              {label}
            </label>
            <input
              id={`prov-${key}`}
              className="field mt-1"
              type={key === 'verified_on' ? 'date' : 'text'}
              placeholder={placeholder}
              value={String(current[key] ?? '')}
              disabled={!editable}
              onChange={(e) => set(key, e.target.value)}
            />
          </div>
        ))}
      </div>
    </details>
  );
}

/* --------------------------------------------------------------- thresholds -- */

/**
 * The numbers, as a table, with the unit stated.
 *
 * The unit is the whole reason this is a table rather than a JSON box. A rule
 * comparing a basis-points figure to a cents threshold is wrong by a factor of
 * ten thousand while reading perfectly sensibly, and the name is the only thing
 * that says which is which — so the name is shown expanded, and the raw value
 * beside it.
 *
 * Lookup tables are shown and not edited here for the same reason nested
 * predicates are not: a table keyed by asset class needs a keyed editor, and a
 * text box is not one.
 */
function Thresholds({
  thresholds,
  editable,
  onChange,
}: {
  thresholds: Record<string, unknown>;
  editable: boolean;
  onChange: (next: Record<string, unknown>) => void;
}) {
  const scalars = Object.entries(thresholds).filter(
    ([, v]) => typeof v !== 'object' || v === null,
  );
  const tables = Object.entries(thresholds).filter(
    ([, v]) => typeof v === 'object' && v !== null,
  );

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <p className="label">Numbers</p>
        <div className="mt-2 divide-y divide-rule">
          {scalars.map(([name, value]) => (
            <div key={name} className="flex items-baseline gap-3 py-2">
              <div className="min-w-0 flex-1">
                <p className="text-[13px] leading-snug text-navy">{humanizeRef(name)}</p>
                <p className="mono text-[11px] text-navy-400">{name}</p>
              </div>
              <input
                className="field mono w-40 shrink-0 text-right"
                value={String(value)}
                disabled={!editable}
                inputMode="numeric"
                onChange={(e) => {
                  const raw = e.target.value.trim();
                  // Kept as text until it is a whole number. Parsing eagerly
                  // would turn "10" mid-typing into 1 and then 10, and a
                  // specialist would watch the field fight them.
                  const parsed = /^-?\d+$/.test(raw) ? Number(raw) : raw;
                  onChange({ ...thresholds, [name]: parsed });
                }}
              />
              <span className="w-16 shrink-0 text-[12px] text-navy-400">
                {unitOf(name)}
              </span>
            </div>
          ))}
        </div>
        <p className="mt-3 border-t border-rule pt-3 text-[12px] leading-snug text-navy-400">
          Money is whole cents and proportions are whole basis points — one per cent
          is 100. A decimal here is refused, because a determination has to reproduce
          exactly years later.
        </p>
      </div>

      {tables.length > 0 && (
        <div className="card p-5">
          <p className="label">Tables</p>
          <p className="mt-1 text-[12px] leading-snug text-navy-400">
            Shown, not edited here. A table keyed by asset class needs a keyed
            editor, and a text box is not one.
          </p>
          {tables.map(([name, value]) => (
            <div key={name} className="mt-3 border-t border-rule pt-3">
              <p className="text-[13px] text-navy">{humanizeRef(name)}</p>
              <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1">
                {Object.entries(value as Record<string, unknown>).map(([k, v]) => (
                  <span key={k} className="mono text-[12px] text-navy-600">
                    {k} → {String(v)}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/** The unit a threshold's name declares, for the column beside it. */
function unitOf(name: string): string {
  if (name.endsWith('_bps')) return 'bps';
  if (name.endsWith('_cents')) return 'cents';
  if (name.endsWith('_days')) return 'days';
  if (name.endsWith('_years')) return 'years';
  if (name.includes('band')) return 'band';
  return '';
}

/* ----------------------------------------------------------------- history -- */

/**
 * How this draft got here.
 *
 * "This pack became effective on the fourteenth" is a fact; this is the answer
 * to the question behind it. Oldest first, because it reads as a narrative.
 */
function History({ draftId }: { draftId: number }) {
  const [rows, setRows] = useState<
    { from: string | null; to: string; at: string; by: string | null; note: string }[]
  >([]);
  const [hash, setHash] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    api
      .draftHistory(draftId)
      .then((res) => {
        if (cancelled) return;
        setRows(res.data.transitions);
        setHash(res.data.content_hash);
      })
      .catch((err: unknown) =>
        setError(err instanceof ApiError ? err.message : 'Could not load the history.'),
      );
    return () => {
      cancelled = true;
    };
  }, [draftId]);

  if (error) return <p className="text-[13px] text-block">{error}</p>;

  return (
    <div className="card p-5">
      <ol className="space-y-3">
        {rows.map((row, i) => (
          <li key={i} className="border-l-2 border-rule pl-3">
            <p className="text-[13px] leading-snug text-navy">
              {row.from ? (
                <>
                  <span className="text-navy-400">{row.from}</span> →{' '}
                  <span className="font-medium">{row.to}</span>
                </>
              ) : (
                <span className="font-medium">created</span>
              )}
            </p>
            <p className="mono mt-0.5 text-[11px] text-navy-400">
              {new Date(row.at).toLocaleString()} · {row.by ?? 'unrecorded'}
            </p>
            {row.note && (
              <p className="mt-1 text-[12px] leading-snug text-navy-600">{row.note}</p>
            )}
          </li>
        ))}
      </ol>

      {hash && (
        <div className="mt-4 border-t border-rule pt-3">
          <p className="label">What was signed</p>
          <p className="mono mt-1 break-all text-[11px] text-navy-600">{hash}</p>
          <p className="mt-1 text-[12px] leading-snug text-navy-400">
            The content as it stood at the signature. &ldquo;They signed v
            {''}
            {''}4&rdquo; is a weaker claim than &ldquo;they signed these exact
            bytes&rdquo; when somebody asks what changed afterwards.
          </p>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ faults -- */

/**
 * What is wrong, and the save button.
 *
 * Together on purpose: the answer to "why can I not save" should be in the same
 * place as the button that will not work. Saving is refused while anything is
 * wrong rather than warned about — a draft that cannot evaluate must not be one
 * keystroke from being signed.
 */
function FaultPanel({
  faults,
  checking,
  dirty,
  saving,
  saved,
  onSave,
}: {
  faults: string[];
  checking: boolean;
  dirty: boolean;
  saving: boolean;
  saved: string | null;
  onSave: () => void;
}) {
  return (
    <div
      className={`card p-5 ${faults.length ? 'border-block/40' : ''}`}
      aria-live="polite"
    >
      {faults.length > 0 ? (
        <>
          <p className="label text-block">
            {faults.length} problem{faults.length === 1 ? '' : 's'}
          </p>
          <ul className="mt-2 space-y-2">
            {faults.map((fault, i) => (
              <li key={i} className="text-[13px] leading-relaxed text-navy">
                {fault}
              </li>
            ))}
          </ul>
        </>
      ) : (
        <p className="text-[13px] leading-relaxed text-navy-600">
          {checking
            ? 'Checking…'
            : dirty
              ? 'No problems. This draft would evaluate.'
              : 'No unsaved changes.'}
        </p>
      )}

      <button
        type="button"
        onClick={onSave}
        disabled={!dirty || saving || faults.length > 0 || checking}
        className="btn-primary mt-4 w-full disabled:opacity-40"
      >
        {saving ? 'Saving…' : 'Save changes'}
      </button>

      {saved && (
        <p className="mt-2 text-[13px] leading-relaxed text-navy-600">{saved}</p>
      )}
    </div>
  );
}
