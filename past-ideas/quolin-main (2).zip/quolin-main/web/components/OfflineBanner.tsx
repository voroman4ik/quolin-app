'use client';

import { useEffect, useState } from 'react';
import { isEngineReachable, subscribeEngineReachable } from '@/lib/connectivity';

/**
 * Persistent, quiet notice that the app is running on cached evidence.
 *
 * Driven by whether our own requests are reaching the engine, not by
 * `navigator.onLine`: the demo's worst case is a device that is nominally
 * online — conference Wi-Fi, a captive portal, or simply the API being down —
 * while every figure on screen is hours old.
 */
export default function OfflineBanner() {
  const [reachable, setReachable] = useState(true);

  useEffect(() => {
    setReachable(isEngineReachable());
    return subscribeEngineReachable(setReachable);
  }, []);

  if (reachable) return null;

  return (
    <div className="bg-navy px-5 py-2 text-center text-[12px] font-medium text-parchment">
      Engine unreachable — showing last synced records
    </div>
  );
}
