'use client';

/**
 * Confirming your password without losing what you were doing. FP3-12(b).
 *
 * Signing rule content, publishing it, overriding a determination, provisioning
 * access and changing the advance policy all demand a credential presented in
 * the last few minutes. Until this existed, the client answered that refusal
 * the same way it answered every other 401 — destroy the offline cache, show
 * the lock screen — so a signatory who actually read the draft before signing
 * it lost the draft. The observable effect was that the careful reviewer was
 * punished and the person who signed without reading was not, which is the
 * exact inversion of what a step-up check is for.
 *
 * The shape that fixes it is a retry of the *original* request, not a
 * navigation and not a re-render. `withReauth` in `lib/api.ts` owns that; this
 * file owns the half that needs a person — putting a dialog on the screen and
 * resolving a promise with what they typed.
 *
 * **It is a promise, not a callback tree, on purpose.** A screen writes
 *
 *     await reauth(() => api.signDraft(id, note, hash))
 *
 * and everything about the interruption — the dialog, the cancel, the retry —
 * happens inside that one line. A screen that had to hold "am I mid-reauth"
 * state would eventually forget to, somewhere, and the failure mode of
 * forgetting is a silent no-op on a button that signs rule content.
 *
 * **Cancelling rethrows the original error.** It does not resolve, and it does
 * not swallow. The caller's catch runs exactly as it would have, so the screen
 * says why the action did not happen rather than appearing to succeed.
 */

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api, withReauth } from '@/lib/api';

type Answer = { password: string; code?: string };

interface Ask {
  message: string;
  resolve: (answer: Answer | null) => void;
}

/** Runs an action, standing in for the person if the credential has gone stale. */
type Run = <T>(action: () => Promise<T>) => Promise<T>;

const ReauthContext = createContext<Run | null>(null);

export function ReauthProvider({ children }: { children: React.ReactNode }) {
  const [ask, setAsk] = useState<Ask | null>(null);

  const confirm = useCallback(
    (message: string) =>
      new Promise<Answer | null>((resolve) => {
        setAsk({
          message,
          resolve: (answer) => {
            setAsk(null);
            resolve(answer);
          },
        });
      }),
    [],
  );

  const run = useCallback<Run>(
    (action) => withReauth(action, confirm),
    [confirm],
  );

  const value = useMemo(() => run, [run]);

  return (
    <ReauthContext.Provider value={value}>
      {children}
      {ask && <ReauthDialog message={ask.message} onAnswer={ask.resolve} />}
    </ReauthContext.Provider>
  );
}

/**
 * The wrapper every step-up action goes through.
 *
 * Falls back to running the action bare when no provider is mounted. That is
 * not defensive padding — server-rendered and test contexts exist — and the
 * fallback fails the same way the old client did rather than throwing something
 * new, so a missing provider is a regression to the previous behaviour and not
 * a crash on a signature button.
 */
export function useReauth(): Run {
  const run = useContext(ReauthContext);
  return run ?? ((action) => action());
}

function ReauthDialog({
  message,
  onAnswer,
}: {
  message: string;
  onAnswer: (answer: Answer | null) => void;
}) {
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [minutes, setMinutes] = useState<number | null>(null);

  // Asked once, when the dialog opens, so the sentence below can state the real
  // window instead of a number written into the copy. `QUOLIN_REAUTH_MINUTES`
  // is deployment configuration; a hardcoded "5 minutes" here was true when it
  // was written and is not now.
  useEffect(() => {
    let alive = true;
    void api
      .session()
      .then((s) => {
        if (alive) setMinutes(s.credential_fresh_minutes ?? null);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (busy || password === '') return;
    setBusy(true);
    // Handed back to `withReauth`, which posts it and retries. Deliberately not
    // posted here: the credential and the retry are one operation, and
    // splitting them is how you get a re-authenticated session with the
    // original action quietly dropped.
    //
    // A wrong password therefore surfaces on the screen that started the
    // action, through its own error path, rather than in this dialog — which is
    // the right place for it: the message a person needs is "the pack was not
    // signed", not "the dialog did not close".
    onAnswer({ password, code: code || undefined });
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-navy/60 p-0 sm:items-center sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="reauth-h"
    >
      <div className="card w-full max-w-sm rounded-b-none p-6 sm:rounded-b-md">
        <h2 id="reauth-h" className="text-[17px] font-semibold leading-tight text-navy">
          Confirm it&rsquo;s you
        </h2>
        <p className="mt-2 text-[13px] leading-relaxed text-navy-600">{message}</p>

        <form onSubmit={submit}>
          <label className="label mt-5 block" htmlFor="reauth-password">
            Password
          </label>
          <input
            id="reauth-password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="field mt-1"
            autoComplete="current-password"
            autoFocus
            disabled={busy}
          />

          <label className="label mt-4 block" htmlFor="reauth-code">
            Six-digit code
            <span className="ml-1 font-normal normal-case tracking-normal text-navy-400">
              if you use an authenticator
            </span>
          </label>
          <input
            id="reauth-code"
            type="text"
            inputMode="numeric"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="field mt-1"
            autoComplete="one-time-code"
            disabled={busy}
          />

          <div className="mt-5 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => onAnswer(null)}
              disabled={busy}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={busy || password === ''}
              className="btn-primary disabled:opacity-40"
            >
              {busy ? 'Confirming…' : 'Confirm'}
            </button>
          </div>
        </form>

        {/*
          Said here rather than only in the docs, because this dialog is where
          somebody first meets the rule and the obvious reading of it — "the app
          logged me out" — is wrong and would send them looking for the wrong
          problem.
        */}
        <p className="mt-4 border-t border-rule pt-4 text-[12px] leading-snug text-navy-400">
          You are still signed in. Actions that put your name to something ask
          for a password again if one has not been typed in the last{' '}
          {minutes ?? '15'} minutes, so a signature cannot be collected from a
          screen its owner walked away from. Nothing you have entered is lost —
          this will finish what you were doing.
        </p>
      </div>
    </div>
  );
}
