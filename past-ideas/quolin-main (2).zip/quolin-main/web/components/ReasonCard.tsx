'use client';

import { formatProvenanceValue, humanizeRef } from '@/lib/format';
import type { Provenance, Reason } from '@/lib/types';
import { verdictStyle } from './Verdict';

function ProvenanceRow({ entry }: { entry: Provenance }) {
  return (
    <div className="flex items-baseline justify-between gap-3 py-1.5">
      <span className="mono min-w-0 flex-1 break-words text-navy-600">{entry.ref}</span>
      <span className="mono shrink-0 font-semibold text-navy">
        {formatProvenanceValue(entry.ref, entry.value)}
      </span>
    </div>
  );
}

/**
 * A single failing rule. Every word of the reason and every number in the
 * comparison comes from the decision's stored provenance — nothing here is
 * recomputed or hardcoded in the frontend.
 */
export default function ReasonCard({
  reason,
  index,
  pack,
}: {
  reason: Reason;
  index: number;
  /** Authority for this finding, e.g. "AU v2". Kept per-card so a single
   *  finding stays self-contained when it is screenshotted or printed. */
  pack?: string;
}) {
  const s = verdictStyle(reason.outcome);
  const hasThresholds = reason.thresholds_used.length > 0;

  return (
    <article className="card overflow-hidden">
      <div className="flex items-start gap-3 border-b border-rule px-4 py-3">
        <span className="mono mt-0.5 shrink-0 text-navy-400">{index}</span>
        <div className="min-w-0 flex-1">
          <h3 className="text-[16px] font-semibold leading-snug text-navy">
            {reason.reason_title}
          </h3>
          <p className="mt-1 text-[13px] leading-tight text-navy-400">{reason.title}</p>
        </div>
        <span
          className={`shrink-0 rounded-sm px-2 py-1 text-[10px] font-semibold uppercase tracking-wider2 ${s.bg} ${s.text}`}
        >
          {reason.outcome}
        </span>
      </div>

      <p className="px-4 py-3 text-[15px] leading-relaxed text-navy">
        {reason.reason_plain_english}
      </p>

      {(reason.inputs_read.length > 0 || hasThresholds) && (
        <div className="border-t border-rule bg-parchment px-4 py-3">
          <p className="label mb-1">Values compared</p>
          {reason.inputs_read.length > 0 && (
            <>
              <p className="label mb-1 text-navy-600">Observed</p>
              <div className="divide-y divide-rule/60">
                {reason.inputs_read.map((e, i) => (
                  <ProvenanceRow key={`in-${i}`} entry={e} />
                ))}
              </div>
            </>
          )}
          {hasThresholds && (
            <div className="mt-2 border-t border-rule pt-2">
              <p className="label mb-1 text-gold">Rule threshold</p>
              <div className="divide-y divide-rule/60">
                {reason.thresholds_used.map((e, i) => (
                  <ProvenanceRow key={`th-${i}`} entry={e} />
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1 border-t border-rule px-4 py-2">
        <span className="mono text-navy-600">{reason.rule_id}</span>
        <span className="mono text-navy-400">
          {reason.reason_code}
          {pack && ` · ${pack}`}
        </span>
      </div>
    </article>
  );
}


export { humanizeRef };
