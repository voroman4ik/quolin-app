'use client';

import type { ContentStatus } from '@/lib/types';

/*
 * Unreviewed rule content is never allowed to look like reviewed rule content.
 *
 * There is no dismiss control here, and there deliberately never will be. A
 * badge a viewer can close is a badge that is closed in every screenshot that
 * matters. The architecture is what this prototype demonstrates; letting a
 * reader take illustrative thresholds for verified regulatory content would
 * trade the credibility of the whole thing for a tidier screen.
 *
 * The full-width warning fires for ILLUSTRATIVE alone. PENDING_REVIEW is a
 * weaker claim and gets the chip, not the alarm — a warning that appears on
 * every screen is a warning nobody reads by the third one, and the distinction
 * between "nobody has reviewed this" and "the reviewer is not yet engaged" is
 * exactly what would be lost.
 */

export default function IllustrativeBadge({
  jurisdictions,
  governing,
  className = '',
}: {
  /** Every regime on this record whose content is unreviewed. Empty renders
   *  nothing: a determination with no illustrative input needs no warning. */
  jurisdictions: string[];
  /** The governing regime, when it differs from the unreviewed ones. */
  governing?: string;
  className?: string;
}) {
  if (jurisdictions.length === 0) return null;

  const many = jurisdictions.length > 1;
  const sourcedElsewhere = governing !== undefined && !jurisdictions.includes(governing);

  return (
    <section
      role="note"
      aria-label="Illustrative rule content, not professionally reviewed"
      className={`rounded-md border-2 border-block bg-block-bg px-4 py-3 ${className}`}
    >
      <div className="flex items-start gap-2.5">
        <span
          aria-hidden="true"
          className="mt-px inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-block text-[12px] font-bold leading-none text-white"
        >
          !
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-wider2 text-block">
            Illustrative rule content — not professionally reviewed
          </p>
          <p className="mono mt-1 text-block/80">{jurisdictions.join(' · ')}</p>
          <p className="mt-1.5 text-[13px] leading-snug text-block/90">
            {many ? 'These packs were' : 'This pack was'} written to exercise the engine
            across regimes, not to state the law. No qualified adviser has reviewed a
            threshold in {many ? 'them' : 'it'}.
            {sourcedElsewhere && (
              <>
                {' '}
                The governing pack is {governing}, but the outcome was resolved across
                regimes and {many ? 'these packs' : 'this pack'} took part in it.
              </>
            )}{' '}
            The mechanism is what is being shown here, not the rules.
          </p>
        </div>
      </div>
    </section>
  );
}

const CHIP: Record<ContentStatus, { label: string; title: string; tone: string } | null> = {
  REVIEWED: null,
  PENDING_REVIEW: {
    label: 'Pending review',
    title: 'Reference content authored in-house; named signatory not yet engaged.',
    tone: 'border-gold/50 bg-gold-soft text-gold',
  },
  ILLUSTRATIVE: {
    label: 'Illustrative',
    title: 'Illustrative rule content — not professionally reviewed.',
    tone: 'border-block/50 bg-block-bg text-block',
  },
};

/** The inline form, for a row in a list where the full block would not fit. */
export function ContentStatusChip({
  status,
  className = '',
}: {
  status: ContentStatus;
  className?: string;
}) {
  const chip = CHIP[status];
  if (!chip) return null;
  return (
    <span
      title={chip.title}
      className={`inline-flex shrink-0 items-center rounded-sm border px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider2 ${chip.tone} ${className}`}
    >
      {chip.label}
    </span>
  );
}
