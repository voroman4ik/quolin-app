'use client';

import { useState } from 'react';
import { ApiError, api, apiUrl } from '@/lib/api';
import { formatDateTime } from '@/lib/format';
import type { Artefact, ArtefactKind } from '@/lib/types';

const LABEL: Record<ArtefactKind, string> = {
  tmd: 'TMD',
  evidence_pack: 'Evidence Pack',
};

/**
 * Generates the artefact then hands the user a real anchor to tap.
 *
 * The PDF takes a second or two to render server-side, so the download cannot
 * happen inside the original gesture. We attempt to open it automatically, but
 * always leave a persistent link on screen: in a standalone PWA on iOS a
 * programmatic open can be swallowed, and a dead-end here would kill the demo.
 */
export default function ArtefactButton({
  decisionId,
  kind,
  variant = 'primary',
}: {
  decisionId: number;
  /**
   * `null` means the caller could not work out which document belongs to this
   * decision — the artefact follows the client's scenario, and that lookup is
   * a second request that can fail on its own. Guessing would be worse than
   * waiting: the two kinds are a Target Market Determination and an Evidence
   * Pack, and handing a wealth-management audience the wrong one is the sort
   * of mistake that ends the conversation about whether any of this is real.
   */
  kind: ArtefactKind | null;
  variant?: 'primary' | 'gold';
}) {
  const [busy, setBusy] = useState(false);
  const [artefact, setArtefact] = useState<Artefact | null>(null);
  const [error, setError] = useState<string | null>(null);

  const label = kind ? LABEL[kind] ?? 'Artefact' : 'Artefact';

  async function generate() {
    if (!kind) return;
    setBusy(true);
    setError(null);
    try {
      const result = await api.artefact(kind!, decisionId);
      setArtefact(result);
      const href = apiUrl(result.download_url);
      const a = document.createElement('a');
      a.href = href;
      a.target = '_blank';
      a.rel = 'noopener';
      document.body.appendChild(a);
      a.click();
      a.remove();
    } catch (err) {
      setError(
        err instanceof ApiError ? err.message : `Could not generate the ${label}.`,
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <button
        type="button"
        onClick={generate}
        disabled={busy || !kind}
        className={`${variant === 'gold' ? 'btn-gold' : 'btn-primary'} w-full disabled:opacity-40`}
      >
        {!kind
          ? 'Checking which document applies…'
          : busy
            ? `Generating ${label}…`
            : `Generate ${label}`}
      </button>

      {error && (
        <p className="mt-2 rounded-md border border-block/30 bg-block-bg px-3 py-2 text-[13px] text-block">
          {error}
        </p>
      )}

      {artefact && (
        <div className="card mt-3 border-gold/35 bg-gold-soft p-4">
          <p className="label text-gold">Artefact ready</p>
          <p className="mt-1 text-[15px] font-medium leading-snug text-navy">
            {artefact.title}
          </p>
          <p className="mono mt-1 text-navy-600">
            {artefact.template_version} · {formatDateTime(artefact.created_at)}
          </p>
          <a
            href={apiUrl(artefact.download_url)}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary mt-3 w-full"
          >
            Download PDF
          </a>
        </div>
      )}
    </div>
  );
}
