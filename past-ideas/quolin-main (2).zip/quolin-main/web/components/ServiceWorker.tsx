'use client';

import { useEffect } from 'react';

/** Registers the app-shell service worker so the demo survives dead Wi-Fi. */
export default function ServiceWorker() {
  useEffect(() => {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return;
    /*
     * In development, Next serves chunk URLs that are stable but whose content
     * changes on every edit, so the worker must not treat them as immutable.
     * The flag is read back from the worker's own script URL.
     */
    const url =
      process.env.NODE_ENV === 'production' ? '/sw.js' : '/sw.js?dev=1';
    const register = () => {
      navigator.serviceWorker.register(url, { scope: '/' }).catch(() => {
        /* SW is an enhancement — never block the app on it */
      });
    };
    if (document.readyState === 'complete') register();
    else window.addEventListener('load', register);
    return () => window.removeEventListener('load', register);
  }, []);

  return null;
}
