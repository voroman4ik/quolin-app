'use client';

import { formatProvenanceValue } from '@/lib/format';
import type { RuleResult } from '@/lib/types';

/** Every rule the engine ran, passed or not — the auditor's view. */
export default function RuleLedger({
  results,
  notApplicable,
}: {
  results: RuleResult[];
  notApplicable: string[];
}) {
  return (
    <div className="space-y-3">
      <div className="card divide-y divide-rule">
        {results.map((r) => (
          <div key={r.rule_id} className="px-4 py-3">
            <div className="flex items-start gap-3">
              <span
                aria-hidden="true"
                className={`mt-1 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full text-[10px] font-bold text-white ${
                  r.passed ? 'bg-allow' : r.outcome === 'BLOCK' ? 'bg-block' : 'bg-refer'
                }`}
              >
                {r.passed ? '✓' : '!'}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium leading-snug text-navy">{r.title}</p>
                <p className="mono mt-0.5 text-navy-400">
                  {r.rule_id} · severity {r.severity}
                  {r.reason_code ? ` · ${r.reason_code}` : ''}
                </p>
                {(r.inputs_read.length > 0 || r.thresholds_used.length > 0) && (
                  <p className="mono mt-1.5 leading-relaxed text-navy-600">
                    {[...r.inputs_read, ...r.thresholds_used]
                      .map((e) => `${e.ref} = ${formatProvenanceValue(e.ref, e.value)}`)
                      .filter((v, i, arr) => arr.indexOf(v) === i)
                      .join('  ·  ')}
                  </p>
                )}
              </div>
              <span className="sr-only">{r.passed ? 'Passed' : 'Did not pass'}</span>
            </div>
          </div>
        ))}
      </div>

      {notApplicable.length > 0 && (
        <div className="card p-4">
          <p className="label mb-1.5">Not applicable</p>
          <p className="mono leading-relaxed text-navy-600">{notApplicable.join('  ·  ')}</p>
          <p className="mt-1.5 text-[12px] leading-snug text-navy-400">
            These rules were skipped because their preconditions did not match this client
            and asset.
          </p>
        </div>
      )}
    </div>
  );
}
