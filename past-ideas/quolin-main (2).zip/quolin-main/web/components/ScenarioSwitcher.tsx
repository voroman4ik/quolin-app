'use client';

import { SCENARIOS, useScenario } from '@/lib/scenario';

/** Two-up segmented control. The only "auth" in the prototype. */
export default function ScenarioSwitcher() {
  const { scenario, setScenario } = useScenario();

  return (
    <div>
      <div
        role="tablist"
        aria-label="Scenario"
        className="grid grid-cols-2 gap-1 rounded-md border border-parchment/15 bg-white/5 p-1"
      >
        {SCENARIOS.map((s) => {
          const active = s.id === scenario;
          return (
            <button
              key={s.id}
              role="tab"
              aria-selected={active}
              type="button"
              onClick={() => setScenario(s.id)}
              className={`tap rounded-[4px] px-2 py-2 text-center transition-colors ${
                active ? 'bg-parchment text-navy' : 'text-parchment/70 hover:text-parchment'
              }`}
            >
              <span className="block text-[13px] font-semibold leading-tight">
                {s.name.split(' ')[0]}
              </span>
              <span
                className={`block text-[10px] leading-tight ${
                  active ? 'text-navy-400' : 'text-parchment/45'
                }`}
              >
                {s.kind}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
