'use client';

import type { Freshness } from '@/lib/types';

/**
 * How current a source or a regime is.
 *
 * Deliberately not in the verdict palette. `allow`, `block` and `refer` are
 * reserved for determinations, and a STALE badge in block red would put a
 * compliance verdict's colour on an operational fact — a viewer scanning the
 * screen would read "something was blocked" from across the room. So freshness
 * gets its own language: quiet for CURRENT, gold for DUE, and inverted navy for
 * STALE, which is unmistakable without borrowing meaning it does not have.
 *
 * The words are chosen the same way. STALE says the checking has lapsed. It
 * does not say the rules are wrong, and no badge in this system is entitled to.
 */

const STYLES: Record<Freshness, string> = {
  CURRENT: 'bg-parchment-dark text-navy-600',
  // Distinct from CURRENT and quieter than DUE. A manually verified source is
  // not late; it is checked by somebody remembering to look, which is a
  // different kind of assurance and has to look like one.
  MANUAL: 'bg-white text-navy-600 ring-1 ring-inset ring-rule-strong',
  DUE: 'bg-gold-soft text-gold',
  STALE: 'bg-navy text-parchment',
};

const WORDS: Record<Freshness, string> = {
  CURRENT: 'Current',
  MANUAL: 'Manual',
  DUE: 'Due',
  STALE: 'Stale',
};

export const FRESHNESS_MEANING: Record<Freshness, string> = {
  CURRENT: 'Checked within the cadence the rule pack asks for.',
  MANUAL:
    'Verified by a person within cadence. This source cannot be polled — it needs a login, or has no stable URL — so it is only as current as the last time somebody looked.',
  DUE: 'Past its cadence but within twice it.',
  STALE: 'Past twice its cadence, or never checked.',
};

/**
 * The same three words said about the whole deployment rather than one source.
 *
 * FRESHNESS_MEANING defines the term — "past its cadence" — and reads correctly
 * next to the source it describes. As a headline over the rollup it has no
 * referent: there is no single "it" whose cadence has lapsed. Worst-wins means
 * the rollup is a claim about the laggard, so these say so.
 */
export const FRESHNESS_HEADLINE: Record<Freshness, string> = {
  CURRENT: 'Every source is being checked as often as its pack asks.',
  MANUAL:
    'Every source is within cadence, but at least one is verified by hand rather than polled.',
  DUE: 'At least one source is past the cadence its pack asks for.',
  STALE: 'At least one source has not been checked in twice its cadence.',
};

export default function FreshnessBadge({
  freshness,
  size = 'md',
}: {
  freshness: Freshness;
  size?: 'sm' | 'md';
}) {
  return (
    <span
      className={`inline-flex shrink-0 items-center rounded-sm font-semibold uppercase tracking-wider2 ${
        STYLES[freshness]
      } ${size === 'sm' ? 'px-1.5 py-0.5 text-[10px]' : 'px-2 py-1 text-[11px]'}`}
      title={FRESHNESS_MEANING[freshness]}
    >
      {WORDS[freshness]}
    </span>
  );
}

/** Plain-English line for a jurisdiction's rollup, naming the worst source. */
export function freshnessSentence(
  freshness: Freshness,
  lastChecked: string | null,
  sourceCount: number,
  unreachableCount = 0,
): string {
  // Said first, because it is a different problem with a different owner.
  // "Overdue" is us not having got to something; "not answering" is a publisher
  // being down, and a reader who is told the first when the second is true goes
  // looking in the wrong place.
  if (unreachableCount > 0) {
    return unreachableCount === 1
      ? `One source is not answering. Its owner has been told.`
      : `${unreachableCount} sources are not answering. Their owners have been told.`;
  }
  if (sourceCount === 0) {
    return 'This pack declares no sources to watch, so nothing is being checked for it.';
  }
  if (lastChecked === null) {
    return `${sourceCount} source${sourceCount === 1 ? '' : 's'} declared, none checked yet.`;
  }
  if (freshness === 'CURRENT') {
    return `All ${sourceCount} source${sourceCount === 1 ? '' : 's'} checked within cadence.`;
  }
  // Never the sentence above. A rollup holding a manual source has not earned
  // "all checked" — somebody looked, which is not the same as something
  // checking, and the difference is the whole reason this state exists.
  if (freshness === 'MANUAL') {
    return `All ${sourceCount} source${
      sourceCount === 1 ? '' : 's'
    } within cadence, but at least one is verified by hand rather than polled.`;
  }
  // Worst-wins on the rollup, so the badge is about the laggard rather than the
  // average — an average would let three fresh sources hide one nobody has read
  // since April, which is the exact thing this screen exists to surface.
  return `At least one of ${sourceCount} sources is overdue.`;
}
