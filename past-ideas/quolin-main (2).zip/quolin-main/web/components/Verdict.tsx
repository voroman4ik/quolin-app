'use client';

import type { Outcome } from '@/lib/types';

/*
 * `glyph` exists so a determination is never carried by colour alone — the
 * banner has to survive a colour-blind reader and a monochrome print-out.
 */
const STYLES: Record<
  Outcome,
  { text: string; bg: string; border: string; fill: string; word: string; glyph: string }
> = {
  ALLOW: {
    text: 'text-allow',
    bg: 'bg-allow-bg',
    border: 'border-allow/25',
    fill: 'bg-allow',
    word: 'Permitted under the current rule pack',
    glyph: '✓',
  },
  BLOCK: {
    text: 'text-block',
    bg: 'bg-block-bg',
    border: 'border-block/25',
    fill: 'bg-block',
    word: 'Distribution not permitted',
    glyph: '✕',
  },
  REFER: {
    text: 'text-refer',
    bg: 'bg-refer-bg',
    border: 'border-refer/25',
    fill: 'bg-refer',
    word: 'Requires human review',
    glyph: '?',
  },
};

export function verdictStyle(outcome: Outcome) {
  return STYLES[outcome] ?? STYLES.REFER;
}

/** Small inline verdict tag for list rows. */
export function VerdictTag({ outcome }: { outcome: Outcome }) {
  const s = verdictStyle(outcome);
  return (
    <span
      className={`inline-flex shrink-0 items-center rounded-sm px-2 py-1 text-[11px] font-semibold uppercase tracking-wider2 ${s.bg} ${s.text}`}
    >
      {outcome}
    </span>
  );
}

/** The full-width verdict statement at the top of a decision. */
export function VerdictBanner({
  outcome,
  asset,
  client,
  overridden,
  pack,
}: {
  outcome: Outcome;
  asset: string;
  client: string;
  overridden?: boolean;
  /** Authority for the determination, e.g. "AU v2" — rendered in mono. */
  pack?: string;
}) {
  const s = verdictStyle(outcome);
  return (
    <section className={`rounded-md border ${s.border} ${s.bg} px-5 py-6`}>
      <p className="label opacity-70">Determination</p>
      <div className="mt-1.5 flex items-center gap-3">
        <span
          aria-hidden="true"
          className={`inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-[20px] font-bold leading-none text-white ${s.fill}`}
        >
          {s.glyph}
        </span>
        <p className={`text-[44px] font-semibold leading-none tracking-tight ${s.text}`}>
          {outcome}
        </p>
      </div>
      <p className={`mt-3 text-[14px] leading-snug ${s.text} opacity-90`}>{s.word}</p>
      <div className="mt-3 border-t border-current/10 pt-3">
        <p className="text-[13px] leading-snug text-navy-600">
          {client} · {asset}
        </p>
        {pack && (
          <p className="mono mt-1 text-navy-400">under rule pack {pack}</p>
        )}
      </div>
      {overridden && (
        <p className="mt-3 inline-flex items-center rounded-sm border border-gold/40 bg-white/70 px-2 py-1 text-[11px] font-semibold uppercase tracking-wider2 text-gold">
          Override recorded
        </p>
      )}
    </section>
  );
}
