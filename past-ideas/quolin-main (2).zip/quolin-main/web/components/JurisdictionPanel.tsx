'use client';

import { useState } from 'react';
import { formatMagnitude, humanizeDimension } from '@/lib/format';
import type {
  ConstraintEntry,
  DecisionJurisdiction,
  JurisdictionBasis,
  Resolution,
  ResolvedDimension,
} from '@/lib/types';
import { ContentStatusChip } from './IllustrativeBadge';
import { VerdictTag, verdictStyle } from './Verdict';

/*
 * What happens when more than one regulator reaches the same trade.
 *
 * Three questions, in the order a compliance officer asks them: which regimes
 * apply and why, what each one would have said on its own, and which of them
 * actually bound each constraint. The third is the one nobody else answers.
 *
 * The panel names no jurisdiction. Every label, including the regulator's name,
 * arrives from pack content — a lookup table of codes to regulators living in
 * this file would be invariant 1 broken in TypeScript instead of Python.
 */

const BASIS_WORDS: Record<JurisdictionBasis, string> = {
  licensee: 'the licence this advice is given under',
  residency: 'where the client lives',
  domicile: 'where the client is domiciled',
};

function basisPhrase(basis: JurisdictionBasis[]): string {
  const words = basis.map((b) => BASIS_WORDS[b] ?? b);
  if (words.length === 0) return 'applicable';
  if (words.length === 1) return words[0];
  return `${words.slice(0, -1).join(', ')} and ${words[words.length - 1]}`;
}

/*
 * Reading order, not record order.
 *
 * The stored order is alphabetical and inside the hash, so it is not touched.
 * But ten dimensions with the two that produced the BLOCK sitting seventh and
 * ninth is a panel that answers the question after the reader has stopped
 * asking it. Constraints that failed come first because they are the reasons;
 * then the ones nothing could order, because that is the claim being made;
 * then everything that passed, which is context.
 */
function orderForReading(dimensions: ResolvedDimension[]): ResolvedDimension[] {
  const rank = (d: ResolvedDimension) => {
    if (d.binding.some((b) => !b.passed)) return 0;
    if (!d.orderable) return 1;
    return 2;
  };
  return [...dimensions].sort((a, b) => rank(a) - rank(b));
}

export default function JurisdictionPanel({
  resolution,
  jurisdictions,
}: {
  resolution: Resolution;
  jurisdictions: DecisionJurisdiction[];
}) {
  return (
    <section className="space-y-3" aria-labelledby="xb-h">
      <div className="flex items-baseline justify-between gap-3">
        <h2 id="xb-h" className="label">
          Cross-border resolution
        </h2>
        <span className="mono text-navy-400">
          {jurisdictions.length} regimes · {resolution.dimensions.length} constraints
        </span>
      </div>

      <p className="text-[14px] leading-relaxed text-navy-600">
        More than one regulator reaches this client, so more than one pack was evaluated.
        Each regime&rsquo;s own determination is shown first, then which of them bound each
        constraint and why.
      </p>

      <AloneGrid jurisdictions={jurisdictions} resolved={resolution.outcome} />

      {resolution.unmatched.length > 0 && <CoverageGap codes={resolution.unmatched} />}

      <div className="space-y-3">
        {orderForReading(resolution.dimensions).map((d) => (
          <DimensionCard key={d.dimension} dimension={d} />
        ))}
      </div>

      <p className="text-[12px] leading-snug text-navy-400">
        Ordering follows the precedence block of{' '}
        <span className="mono">
          {resolution.precedence_source.jurisdiction} v
          {resolution.precedence_source.pack_version}
        </span>
        , the pack that governs this relationship. Which pack supplied it is itself part of
        the record.
      </p>
    </section>
  );
}

/* --------------- what each regime would have said alone ---------------- */

function AloneGrid({
  jurisdictions,
  resolved,
}: {
  jurisdictions: DecisionJurisdiction[];
  resolved: string;
}) {
  const [open, setOpen] = useState<string | null>(null);
  const disagree = new Set(jurisdictions.map((j) => j.outcome)).size > 1;

  return (
    <div className="card overflow-hidden">
      <p className="label border-b border-rule bg-parchment px-4 py-2">
        Under each regime alone
      </p>

      <div className="divide-y divide-rule">
        {jurisdictions.map((j) => {
          const expanded = open === j.jurisdiction;
          const s = verdictStyle(j.outcome);
          return (
            <div key={j.jurisdiction} className={expanded ? 'bg-parchment' : ''}>
              <button
                type="button"
                onClick={() => setOpen(expanded ? null : j.jurisdiction)}
                aria-expanded={expanded}
                className="tap flex w-full items-start gap-3 px-4 py-3 text-left transition-colors hover:bg-parchment-dark"
              >
                <span className="mono mt-1 w-7 shrink-0 font-semibold text-navy">
                  {j.jurisdiction}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span className="text-[15px] font-medium leading-snug text-navy">
                      {j.name}
                    </span>
                    {j.governing && (
                      <span className="rounded-sm border border-navy-400/40 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider2 text-navy-600">
                        Governing
                      </span>
                    )}
                    <ContentStatusChip status={j.content_status} />
                  </span>
                  {j.regulator && (
                    <span className="mt-0.5 block text-[12px] leading-snug text-navy-400">
                      {j.regulator}
                    </span>
                  )}
                  <span className="mt-1 block text-[12px] leading-snug text-navy-600">
                    Applies because of {basisPhrase(j.basis)}
                    {j.covers_states.length > 1 && (
                      <> · one pack covering {j.covers_states.length} member states</>
                    )}
                  </span>
                </span>
                <span className="flex shrink-0 flex-col items-end gap-1">
                  <VerdictTag outcome={j.outcome} />
                  <span className="mono text-navy-400">
                    {j.reasons.length === 0
                      ? 'no findings'
                      : `${j.reasons.length} finding${j.reasons.length === 1 ? '' : 's'}`}
                  </span>
                </span>
              </button>

              {expanded && (
                <div className="border-t border-rule px-4 py-3">
                  {j.reasons.length === 0 ? (
                    <p className={`text-[13px] leading-snug ${s.text}`}>
                      Every rule in {j.jurisdiction} v{j.pack_version} that applied to this
                      asset passed. On its own this regime would have permitted the trade.
                    </p>
                  ) : (
                    <ul className="space-y-2.5">
                      {j.reasons.map((r) => (
                        <li key={r.rule_id}>
                          <p className="text-[14px] font-medium leading-snug text-navy">
                            {r.reason_title}
                          </p>
                          <p className="mt-0.5 text-[13px] leading-snug text-navy-600">
                            {r.reason_plain_english}
                          </p>
                          <p className="mono mt-0.5 text-navy-400">
                            {r.rule_id} · {r.outcome}
                          </p>
                        </li>
                      ))}
                    </ul>
                  )}
                  <p className="mono mt-3 border-t border-rule pt-2 text-navy-400">
                    signatory: {j.signed_by}
                  </p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="flex items-center justify-between gap-3 border-t-2 border-navy bg-parchment px-4 py-3">
        <p className="text-[13px] leading-snug text-navy-600">
          {disagree
            ? 'The regimes do not agree. The determination on record is the strictest of them.'
            : 'Every regime reached the same determination.'}
        </p>
        <VerdictTag outcome={resolved as never} />
      </div>
    </div>
  );
}

/* --------------------------- coverage gap ------------------------------ */

function CoverageGap({ codes }: { codes: string[] }) {
  const many = codes.length > 1;
  return (
    <div className="card border-gold/40 bg-gold-soft px-4 py-3">
      <p className="label text-gold">
        Applicable with no pack on file · {codes.join(', ')}
      </p>
      <p className="mt-1.5 text-[13px] leading-snug text-navy-600">
        {many ? 'These regimes reach' : 'This regime reaches'} the client, and Quolin holds
        no rule pack for {many ? 'them' : 'it'}. No rule from{' '}
        {many ? 'those regimes' : 'that regime'} was evaluated, so this determination does
        not speak for {many ? 'them' : 'it'}. Stated here rather than left for someone to
        notice.
      </p>
    </div>
  );
}

/* --------------------- one constraint dimension ------------------------ */

const UNORDERABLE_WORDS: Record<string, string> = {
  no_common_scale: 'No common scale',
  scale_not_orderable: 'No ordering declared',
};

function DimensionCard({ dimension: d }: { dimension: ResolvedDimension }) {
  const unorderable = !d.orderable;
  const single = d.reason === 'single_constraint';
  const count = d.binding.length + d.evaluated_not_binding.length;

  return (
    <article
      className={`card overflow-hidden ${unorderable ? 'border-gold/50' : ''}`}
    >
      <div
        className={`flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1 border-b px-4 py-2.5 ${
          unorderable ? 'border-gold/40 bg-gold-soft' : 'border-rule bg-parchment'
        }`}
      >
        <h3 className="text-[15px] font-semibold leading-snug text-navy">
          {humanizeDimension(d.dimension)}
        </h3>
        <span
          className={`text-[10px] font-bold uppercase tracking-wider2 ${
            unorderable ? 'text-gold' : 'text-navy-400'
          }`}
        >
          {unorderable
            ? UNORDERABLE_WORDS[d.reason ?? ''] ?? 'Not orderable'
            : single
              ? 'One regime only'
              : `${d.binding.map((b) => b.jurisdiction).join(', ')} ${
                  d.binding.length === 1 ? 'binds' : 'bind'
                }`}
        </span>
      </div>

      <p className="px-4 py-3 text-[14px] leading-relaxed text-navy">{d.rationale}</p>

      {/* The rationale above already says what happened. This says why that is
          the right answer rather than a gap in the engine — and it is only
          worth saying where there was genuinely a choice to refuse. */}
      {unorderable && count > 1 && (
        <p className="border-t border-rule bg-parchment px-4 py-2 text-[13px] leading-snug text-navy-600">
          Nothing in the packs ranks these against each other, so the engine did not rank
          them. Each binds on its own terms. An engine that picked one would be inventing
          an answer nobody could defend six months later, and the invented answer would
          look exactly like a real one.
        </p>
      )}

      <div className="border-t border-rule">
        <ConstraintList
          label={unorderable ? 'Independently binding' : 'Binding'}
          entries={d.binding}
          binding
        />
        {d.evaluated_not_binding.length > 0 && (
          <ConstraintList
            label="Evaluated, not binding"
            entries={d.evaluated_not_binding}
            binding={false}
          />
        )}
      </div>
    </article>
  );
}

function ConstraintList({
  label,
  entries,
  binding,
}: {
  label: string;
  entries: ConstraintEntry[];
  binding: boolean;
}) {
  return (
    <div className="border-b border-rule/60 px-4 py-2.5 last:border-b-0">
      <p className="label mb-1.5">{label}</p>
      <ul className="space-y-1.5">
        {entries.map((e) => (
          <li key={`${e.jurisdiction}-${e.rule_id}`} className="flex items-baseline gap-2.5">
            <span className="mono w-7 shrink-0 font-semibold text-navy">
              {e.jurisdiction}
            </span>
            <span className="min-w-0 flex-1">
              <span
                className={`block text-[13px] leading-snug ${
                  binding ? 'text-navy' : 'text-navy-400'
                }`}
              >
                {e.title}
              </span>
              <span className="mono block text-navy-400">{e.rule_id}</span>
            </span>
            <span className="shrink-0 text-right">
              <span
                className={`mono block ${binding ? 'font-semibold text-navy' : 'text-navy-400'}`}
              >
                {formatMagnitude(e.magnitude, e.scale)}
              </span>
              {/* Binding and failed is not binding and passed. On a dimension
                  nothing could order, a rule that passed is still recorded as
                  binding — nothing was set aside — and saying so plainly stops
                  the panel reading as three failures where there is one. */}
              <span
                className={`text-[10px] font-bold uppercase tracking-wider2 ${
                  e.passed ? 'text-navy-400' : 'text-block'
                }`}
              >
                {e.passed ? 'passed' : 'failed'}
              </span>
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
