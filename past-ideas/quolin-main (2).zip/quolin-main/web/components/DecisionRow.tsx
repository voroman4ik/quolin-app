'use client';

import Link from 'next/link';
import { formatDate } from '@/lib/format';
import type { Outcome } from '@/lib/types';
import { VerdictTag } from './Verdict';

export default function DecisionRow({
  id,
  title,
  outcome,
  asOf,
  packVersion,
  overridden,
  note,
}: {
  id: number;
  title: string;
  outcome: Outcome;
  asOf: string;
  packVersion?: number;
  overridden?: boolean;
  note?: string;
}) {
  return (
    <Link href={`/decisions/${id}`} className="row-link">
      <div className="min-w-0 flex-1">
        <p className="truncate text-[15px] font-medium leading-tight text-navy">{title}</p>
        <p className="mt-0.5 text-[12px] leading-tight text-navy-400">
          {formatDate(asOf)}
          {packVersion !== undefined && (
            <span className="mono"> · pack v{packVersion}</span>
          )}
          {note && ` · ${note}`}
        </p>
        {overridden && (
          <span className="mt-1.5 inline-flex items-center rounded-sm border border-gold/40 bg-gold-soft px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider2 text-gold">
            Overridden
          </span>
        )}
      </div>
      <VerdictTag outcome={outcome} />
      <Chevron />
    </Link>
  );
}

export function Chevron() {
  return (
    <svg
      width="7"
      height="12"
      viewBox="0 0 7 12"
      fill="none"
      aria-hidden="true"
      className="shrink-0 text-navy-400"
    >
      <path
        d="M1 1l5 5-5 5"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
