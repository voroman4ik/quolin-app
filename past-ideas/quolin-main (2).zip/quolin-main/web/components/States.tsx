'use client';

export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`skeleton ${className}`} />;
}

export function LoadingBlock({ rows = 3, label }: { rows?: number; label?: string }) {
  return (
    <div className="space-y-3 py-2" role="status" aria-busy="true">
      <span className="sr-only">{label ?? 'Loading'}</span>
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="card p-4">
          <Skeleton className="h-3 w-24" />
          <Skeleton className="mt-3 h-4 w-3/4" />
          <Skeleton className="mt-2 h-3 w-1/2" />
        </div>
      ))}
    </div>
  );
}

export function ErrorState({
  message,
  onRetry,
}: {
  message: string;
  onRetry?: () => void;
}) {
  return (
    <div className="card border-block/30 bg-block-bg p-5">
      <p className="label text-block">Unavailable</p>
      <p className="mt-2 text-[15px] leading-snug text-navy">{message}</p>
      {onRetry && (
        <button type="button" onClick={onRetry} className="btn-secondary mt-4">
          Try again
        </button>
      )}
    </div>
  );
}

export function EmptyState({
  title,
  detail,
  action,
}: {
  title: string;
  detail?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="card border-dashed p-6 text-center">
      <p className="text-[15px] font-medium text-navy">{title}</p>
      {detail && <p className="mt-1 text-[13px] leading-snug text-navy-400">{detail}</p>}
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  );
}

/** Shown when a screen renders from the offline cache. */
export function StaleNotice() {
  return (
    <p className="mb-3 rounded-md border border-rule bg-parchment-dark px-3 py-2 text-[12px] text-navy-600">
      Cached copy — could not reach the engine to refresh.
    </p>
  );
}
