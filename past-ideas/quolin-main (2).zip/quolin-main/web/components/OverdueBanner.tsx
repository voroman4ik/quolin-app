'use client';

/**
 * This firm is operating on rules a newer version has superseded. FP3-17.
 *
 * The engine half of this finding sends a webhook a day, writes one chained
 * audit event a day, and stamps `pack_review_overdue` onto every determination
 * made while a review window is open past its close. All three answer "did they
 * know" *afterwards*, to somebody reading the evidence. None of them answers it
 * to the person deciding today, at the moment they are deciding.
 *
 * So it is on every screen, and it does not close.
 *
 * **Not dismissible, deliberately.** The state it reports lasts until somebody
 * takes or declines the version, which is an act with a screen of its own. A
 * dismiss button would let the firm turn off the notice without changing the
 * fact, and the fact is that determinations being made right now carry a stamp
 * saying they were made on superseded rules. If that is acceptable to them,
 * declining the version says so on the record; hiding the banner says it
 * nowhere.
 *
 * **It names the pack, the version in force and the days overdue**, because
 * "review overdue" on its own is a notification, and what somebody needs in
 * order to act is which regime, what is waiting, and how far past it is.
 *
 * Read from `GET /advances`, which already carried every field. Nothing new.
 */

import Link from 'next/link';
import { api } from '@/lib/api';
import { useApi } from '@/lib/useApi';
import type { StagedAdvance } from '@/lib/types';

/**
 * Whole days past the close of the window.
 *
 * `days_left` is computed by the engine against the firm's own business date
 * (FP3-05) and goes negative once the window closes; Python's integer division
 * on a negative `timedelta` floors, so a window twelve hours past close reports
 * -1 rather than 0 — which is what we want, and why this negates rather than
 * recomputing from the timestamp in the browser's timezone.
 */
function daysOverdue(row: StagedAdvance): number | null {
  return row.days_left === null ? null : Math.max(0, -row.days_left);
}

export default function OverdueBanner() {
  // No polling. The state changes when somebody takes or declines a version,
  // and that happens on a screen this app navigates to — a timer here would
  // spend a request a minute to learn nothing on all but one of them.
  const { data } = useApi(() => api.advances(), []);

  const overdue = (data?.pending ?? []).filter((row) => row.overdue);
  if (overdue.length === 0) return null;

  return (
    <div
      role="status"
      className="border-b border-refer/30 bg-refer-bg px-5 py-2.5 text-center"
    >
      <p className="text-[12px] font-semibold uppercase tracking-wider2 text-refer">
        Review overdue
      </p>
      <p className="mt-0.5 text-[13px] leading-snug text-navy">
        {overdue.map((row, i) => (
          <span key={row.id}>
            {i > 0 && ' · '}
            <span className="font-medium">{row.jurisdiction}</span> version{' '}
            {row.pack_version} has been waiting{' '}
            {(() => {
              const late = daysOverdue(row);
              if (late === null) return 'past its review window';
              return late === 1 ? '1 day past its review window' : `${late} days past its review window`;
            })()}
          </span>
        ))}
      </p>
      <p className="mt-1 text-[12px] leading-snug text-navy-600">
        Determinations made now are recorded as having been made on superseded
        rules.{' '}
        <Link href="/currency" className="font-medium text-refer underline">
          Take or decline it
        </Link>
        .
      </p>
    </div>
  );
}
