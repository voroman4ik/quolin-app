"""The file drop, and the gate item about a malformed file.

S4's gate names this one directly: *a malformed batch file produces row-level
errors, not a failed run.* That sentence is the whole design of this module and
the reason it behaves differently from `/import/clients`, which is all-or-nothing
on purpose.

The difference is who is watching. A person previewing their own upload wants to
fix it and re-send, so rejecting the file is helpful. A nightly drop at 02:00 has
nobody watching, holds four thousand rows, and rejecting all of them because
eleven are malformed takes a firm's entire book stale over one bad date. So a
batch run writes what it can and returns the rejects as a file beside the input.

What is *not* tested here is SFTP. The transport is server configuration
described in `docs/integrations.md`; everything that happens to a file once it
has landed is in this module, and that is what a test can hold.
"""

from __future__ import annotations

import csv
import io

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import select

from app import batch, importer, tenancy
from app.models import ApiClient, Client, ImportRun

#: Every column the importer requires, in its order. Taken from the importer
#: rather than restated, so a new required column breaks these tests loudly
#: rather than making every row silently invalid for a reason unrelated to what
#: is being tested.
HEADER = ",".join(importer.REQUIRED_COLUMNS)

#: The credential a batch run acts as. A nightly drop has no person behind it,
#: so under Stage 2's attribution rule it needs a machine actor or the audit
#: write is refused — which is the rule working rather than an obstacle.
#:
#: A real `api_clients` row rather than a made-up string, because
#: `test_attribution.py` resolves every audit actor against the users and
#: credentials that exist. A batch run attributed to something nobody
#: provisioned would fail there, and should.
ACTOR = "apc_batch_test"


def _csv(*rows: str) -> bytes:
    return ("\n".join([HEADER, *rows]) + "\n").encode()


def _row(client_id: str, *, dob: str = "1985-04-02", band: str = "3") -> str:
    """One valid row, with the two fields the tests damage exposed as arguments."""
    values = {
        "id": client_id,
        "scenario": "meridian",
        "name": "Test Person",
        "dob": dob,
        "client_category": "retail",
        "knowledge_assessed": "true",
        "knowledge_date": "2026-01-15",
        "loss_capacity_band": band,
        "vulnerability_flag": "false",
        "assessable_portfolio_cents": "2500000",
        "prior_crypto_purchases": "2",
        "structural_acks": "",
        "default_trade_amount_cents": "500000",
    }
    return ",".join(values[c] for c in importer.REQUIRED_COLUMNS)


@pytest.fixture(autouse=True)
def machine(session):
    """The credential the drop belongs to, provisioned once per test.

    Created directly rather than through the API for the same reason the webhook
    tests create an endpoint directly: these tests are about what happens to a
    file, not about the route that issues a credential.
    """
    with tenancy.acting_as(DEMO_TENANT):
        existing = session.get(ApiClient, ACTOR)
        if existing is None:
            session.add(
                ApiClient(
                    id=ACTOR,
                    label="Nightly client-book drop",
                    secret_hash="not-a-real-hash",
                    roles=["operator"],
                    status="active",
                )
            )
            session.commit()
    yield ACTOR


@pytest.fixture
def drop(tmp_path):
    return tmp_path / "drop"


@pytest.fixture(autouse=True)
def clean_up(session):
    """Remove the clients and runs a test created.

    The suite runs against the shared demo database and these tests write real
    client rows. A book left behind changes the counts every other file asserts.
    """
    yield
    with tenancy.acting_as(DEMO_TENANT):
        session.rollback()
        session.query(Client).filter(Client.id.like("batch-%")).delete(
            synchronize_session=False
        )
        session.query(ImportRun).delete(synchronize_session=False)
        session.commit()


# --------------------------------------------------- the gate: a malformed file --


def test_a_malformed_file_writes_the_good_rows_and_reports_the_bad(session, drop):
    """S4's gate for this module.

    Eleven bad rows must not take four thousand good ones down with them. The
    run *completes* — it did what a batch run is for — and says precisely what it
    could not load.
    """
    content = _csv(
        _row("batch-1"),
        _row("batch-2", dob="not-a-date"),
        _row("batch-3"),
        _row("batch-4", band="eleven"),
        _row("batch-5"),
    )
    with tenancy.acting_as(DEMO_TENANT):
        result = batch.process(
            session, started_by=ACTOR, tenant_id=DEMO_TENANT, filename="book.csv", raw=content
        )
        session.commit()

    assert result.status == "completed_with_errors"
    assert result.rows_total == 5
    assert result.rows_written == 3, "good rows were not written"
    assert {e["row"] for e in result.errors} == {3, 5}, result.errors

    # And the good rows really are in the book.
    with tenancy.acting_as(DEMO_TENANT):
        session.expire_all()
        stored = {
            c.id
            for c in session.scalars(select(Client).where(Client.id.like("batch-%")))
        }
    assert stored == {"batch-1", "batch-3", "batch-5"}


def test_every_rejected_row_names_its_row_number_and_column(session, drop):
    """"Row 14 is invalid" sends somebody hunting through thirteen fields."""
    with tenancy.acting_as(DEMO_TENANT):
        result = batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="book.csv",
            raw=_csv(_row("batch-1", dob="1985-13-45")),
        )
        session.commit()

    assert result.errors
    error = result.errors[0]
    assert error["row"] == 2, "row 1 is the header, so the first data row is row 2"
    assert error["column"] == "dob"
    assert error["message"]


def test_the_error_file_is_a_csv_their_operations_team_can_open(session, drop):
    """Deliberately not JSON. The person who fixes this opens it in a spreadsheet
    beside the file they sent, and a nested structure would be a worse answer
    delivered more precisely."""
    with tenancy.acting_as(DEMO_TENANT):
        result = batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="nightly-book.csv",
            raw=_csv(_row("batch-1"), _row("batch-2", band="high")),
        )
        session.commit()

    assert result.error_file == "nightly-book.errors.csv"
    written = batch.error_file_for(result.errors, "nightly-book.csv")
    rows = list(csv.DictReader(io.StringIO(written)))
    assert rows[0]["source_file"] == "nightly-book.csv"
    assert rows[0]["row"] == "3"
    assert rows[0]["column"] == "loss_capacity_band"
    assert rows[0]["problem"]


def test_a_file_with_no_bad_rows_completes_without_an_error_file(session, drop):
    with tenancy.acting_as(DEMO_TENANT):
        result = batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="clean.csv",
            raw=_csv(_row("batch-9")),
        )
        session.commit()
    assert result.status == "completed"
    assert result.errors == []
    assert result.error_file is None


def test_the_same_file_dropped_twice_is_recorded_as_a_duplicate(session, drop):
    """FP3-15. `already_seen` was written for this and had no callers.

    The same file dropped twice is the most common batch accident there is, and
    it is usually a firm doing the right thing — re-sending after a failed
    night. It was silently re-imported as though it were new work, so a run
    summary saying "400 rows written" was indistinguishable from four hundred
    rows that had actually moved.

    Reported rather than refused, which is `already_seen`'s own design: the
    second load is an upsert of identical rows and blocking a firm that meant it
    would be worse. What was missing is that it was invisible.
    """
    payload = _csv(_row("batch-dupe-1"))

    with tenancy.acting_as(DEMO_TENANT):
        first = batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="nightly.csv",
            raw=payload,
        )
        session.commit()

        second = batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="nightly.csv",
            raw=payload,
        )
        session.commit()

    assert first.duplicate_of is None, "the first drop of a file is not a duplicate"
    assert second.duplicate_of == first.run_id, (
        "the second drop of identical bytes did not name the run that already "
        "loaded them"
    )
    # Still processed, not refused — the rows are upserted again and the run
    # completes, which is what a firm re-sending after a failure needs.
    assert second.status == "completed"


def test_a_different_file_is_not_a_duplicate(session, drop):
    """The other half, so this is a check on the bytes rather than the name."""
    with tenancy.acting_as(DEMO_TENANT):
        first = batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="monday.csv",
            raw=_csv(_row("batch-dupe-2")),
        )
        session.commit()
        second = batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="monday.csv",
            raw=_csv(_row("batch-dupe-3")),
        )
        session.commit()

    assert first.duplicate_of is None
    assert second.duplicate_of is None


def test_the_duplicate_reaches_the_manifest_the_scheduler_reads(session, drop):
    """The whole point: a firm's own job has to be able to see it.

    They are on files rather than HTTP precisely so their scheduler can read the
    outcome without calling an API, so a duplicate that is only visible in our
    audit trail is not visible to them.
    """
    import json

    payload = _csv(_row("batch-dupe-4"))
    with tenancy.acting_as(DEMO_TENANT):
        batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="again.csv",
            raw=payload,
        )
        session.commit()
        second = batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="again.csv",
            raw=payload,
        )
        session.commit()

    written = json.loads(batch.manifest([second]))
    entry = written["files"][0] if "files" in written else written["results"][0]
    assert entry["duplicate_of"], (
        "the manifest a firm's scheduler reads does not say the file was a "
        f"re-drop: {entry}"
    )


# ----------------------------------------------- whole-file problems are different --


@pytest.mark.parametrize(
    ("name", "content"),
    [
        ("no header", b"batch-1,Test,AU\n"),
        ("empty", b"\n"),
        ("unknown column", (HEADER + ",wingspan\n" + _row("batch-1") + ",7\n").encode()),
    ],
)
def test_a_file_nobody_could_read_fails_the_run_rather_than_every_row(
    session, drop, name, content
):
    """The distinction that keeps the gate honest.

    A missing header is not four thousand row errors that happen to share a
    cause — it is one problem with the file, and reporting it four thousand times
    would be a worse answer. Row-level errors are for rows.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with pytest.raises(batch.BatchError):
            batch.process(
                session,
                started_by=ACTOR,
                tenant_id=DEMO_TENANT,
                filename="broken.csv",
                raw=content,
            )
        session.commit()

        run = session.scalars(select(ImportRun)).one()
        assert run.status == "failed", name
        assert run.errors[0]["row"] == 0, "a whole-file problem is not row 1's fault"


def test_a_file_that_is_not_utf8_fails_before_any_row_is_read(session, drop):
    with tenancy.acting_as(DEMO_TENANT):
        with pytest.raises(batch.BatchError) as raised:
            batch.process(
                session,
                started_by=ACTOR,
                tenant_id=DEMO_TENANT,
                filename="latin1.csv",
                raw=_csv(_row("batch-1")).replace(b"Test Person", b"Se\xf1or"),
            )
        session.commit()
    assert "UTF-8" in str(raised.value)


def test_a_file_over_the_size_limit_is_refused_with_a_number(session, drop):
    """A mis-cut file must not exhaust a worker's memory, and the refusal has to
    say what the limit is — "too large" leaves somebody guessing."""
    with tenancy.acting_as(DEMO_TENANT):
        with pytest.raises(batch.BatchError) as raised:
            batch.process(
                session,
                started_by=ACTOR,
                tenant_id=DEMO_TENANT,
                filename="huge.csv",
                raw=b"x" * (batch.MAX_BYTES + 1),
            )
        session.rollback()
    assert str(batch.MAX_BYTES) in str(raised.value).replace(",", "")


# ------------------------------------------------------------------ the drop --


def test_a_sweep_moves_what_it_processed_and_leaves_the_rejects_beside_it(session, drop):
    """A drop directory that empties itself is one where "what did you send us on
    the 14th" has no answer."""
    root = batch.ensure_drop(drop, DEMO_TENANT)
    (root / batch.INCOMING / "book.csv").write_bytes(
        _csv(_row("batch-1"), _row("batch-2", dob="nope"))
    )

    with tenancy.acting_as(DEMO_TENANT):
        results = batch.sweep(session, tenant_id=DEMO_TENANT, base=drop, started_by=ACTOR)

    assert len(results) == 1
    assert not (root / batch.INCOMING / "book.csv").exists(), "the file was not moved"
    assert (root / batch.PROCESSED / "book.csv").exists()
    assert (root / batch.ERRORS / "book.errors.csv").exists()


def test_a_file_nobody_could_read_stays_in_incoming_for_somebody_to_look_at(
    session, drop
):
    """Moving it out would hide the one file that needs attention."""
    root = batch.ensure_drop(drop, DEMO_TENANT)
    (root / batch.INCOMING / "broken.csv").write_bytes(b"nonsense\n")

    with tenancy.acting_as(DEMO_TENANT):
        results = batch.sweep(session, tenant_id=DEMO_TENANT, base=drop, started_by=ACTOR)

    assert results[0].status == "failed"
    assert (root / batch.INCOMING / "broken.csv").exists()
    assert (root / batch.ERRORS / "broken.errors.csv").exists()


def test_files_are_applied_in_the_order_the_firm_numbered_them(session, drop):
    """`book-001.csv` through `book-012.csv` in that order, rather than in
    whatever order the filesystem returns them."""
    root = batch.ensure_drop(drop, DEMO_TENANT)
    for i in (3, 1, 2):
        (root / batch.INCOMING / f"book-{i:03d}.csv").write_bytes(_csv(_row(f"batch-{i}")))

    with tenancy.acting_as(DEMO_TENANT):
        results = batch.sweep(session, tenant_id=DEMO_TENANT, base=drop, started_by=ACTOR)

    assert [r.filename for r in results] == ["book-001.csv", "book-002.csv", "book-003.csv"]


def test_each_tenant_gets_its_own_directory(drop):
    """Which is what an SFTP chroot maps onto. A shared directory would be one
    customer able to read another's book, and no application check can undo that
    once the transport has allowed it."""
    a = batch.ensure_drop(drop, "acme")
    b = batch.ensure_drop(drop, "beta")
    assert a != b
    assert (a / batch.INCOMING).is_dir() and (b / batch.INCOMING).is_dir()


# ------------------------------------------------------------------ history --


def test_every_run_is_recorded_with_what_it_did(session, drop):
    """"What did you load on the 14th" is a question a firm will ask a year
    later, and a report that only existed in an HTTP response cannot answer it."""
    with tenancy.acting_as(DEMO_TENANT):
        batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="book.csv",
            raw=_csv(_row("batch-1"), _row("batch-2", band="x")),
        )
        session.commit()
        rows = batch.history(session)

    assert len(rows) == 1
    assert rows[0]["filename"] == "book.csv"
    assert rows[0]["rows_written"] == 1
    assert rows[0]["rows_rejected"] == 1
    assert rows[0]["status"] == "completed_with_errors"
    assert rows[0]["content_hash"]


def test_the_same_file_dropped_twice_is_detectable(session, drop):
    """The most common batch accident there is. Reported rather than refused —
    a firm re-sending after a failed night is doing the right thing — but it has
    to be visible."""
    content = _csv(_row("batch-1"))
    with tenancy.acting_as(DEMO_TENANT):
        first = batch.process(
            session, started_by=ACTOR, tenant_id=DEMO_TENANT, filename="book.csv", raw=content
        )
        session.commit()

        seen = batch.already_seen(session, batch.content_hash(content))
        assert seen is not None
        assert seen.id == first.run_id

        assert batch.already_seen(session, batch.content_hash(_csv(_row("batch-2")))) is None


def test_the_manifest_tells_the_firms_own_job_what_happened(session, drop):
    """They are on files rather than HTTP, so a run summary they can read
    without calling an API is the whole point."""
    import json

    root = batch.ensure_drop(drop, DEMO_TENANT)
    (root / batch.INCOMING / "book.csv").write_bytes(
        _csv(_row("batch-1"), _row("batch-2", dob="bad"))
    )
    with tenancy.acting_as(DEMO_TENANT):
        results = batch.sweep(session, tenant_id=DEMO_TENANT, base=drop, started_by=ACTOR)

    written = json.loads(batch.manifest(results))
    assert written["totals"] == {"files": 1, "rows_written": 1, "rows_rejected": 1}
    assert written["files"][0]["error_file"] == "book.errors.csv"
    assert written["ran_at"]


# ------------------------------------------------- where the positions came from --


def test_the_snapshot_records_where_the_positions_came_from(session):
    """S4 asks for this by name, and it is a fact the determination rested on.

    "10% concentration, from custody" and "10% concentration, because nobody has
    told us otherwise" are different findings. A regime may reasonably refer
    rather than allow on the second — and a replay years later has to reproduce
    which one it was, which is why it is inside the frozen snapshot rather than
    beside it.
    """
    from datetime import date

    from app import service
    from app.models import Decision
    from app.providers import FixturePositionsProvider

    provider = FixturePositionsProvider()
    covered = sorted(provider.covered_ids())[0]

    with tenancy.acting_as(DEMO_TENANT):
        known = provider.get(covered, date.today())
        assert known["source"] == "fixture"

        # A client custody has never heard of — an imported one, which is the
        # common case for a firm with no custody integration.
        unknown = provider.get("a-client-custody-never-saw", date.today())
        assert unknown["source"] == "none_on_file"
        assert unknown["crypto_value_cents"] == 0

    # And it reaches the snapshot, which is the part that matters.
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        decision = service.evaluate(
            session, client_id=covered, asset_id="BTC", as_of=date.today()
        )
        session.commit()
        stored = session.get(Decision, decision.id).snapshot

    assert stored["positions"]["source"] == "fixture"
    assert stored["positions"]["as_at"]
