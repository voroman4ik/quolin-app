"""FP3-06: `Pack.is_production_grade` had no caller.

The 27 August entry said it "answers the loader's question". It answered nothing
— `packs_repo._usable` compared `content_status == REVIEWED` and stopped there,
and the property had zero references outside its own tests.

So the "three layers" that entry claimed were two: the status check in the
loader, and the CHECK constraint in migration 0025. The half that was missing is
the one a status column cannot express — a pack can be `REVIEWED` and signed by
`[unsigned]`, or by an `ILLUSTRATIVE ...` placeholder, which is content that has
moved through the lifecycle without a real person's name on it.

**This test lifts the database constraint deliberately**, and that is the whole
point of it: with the CHECK in place the row cannot exist, so any test would be
proving migration 0025 rather than the application.

**And it does the whole thing in one transaction it rolls back**, which took two
attempts to get right. The first version dropped the constraint, committed the
sacrificial row, and tried to re-add the constraint afterwards — which Postgres
refuses, because the row it just committed violates it. `packs` is append-only,
so the row could not simply be deleted either, and the failure left the
constraint off the table for every test that ran after it. DDL is transactional
in Postgres: dropping the constraint, writing the row, asking the loader and
rolling back leaves nothing behind, and cannot leave anything behind even if the
assertion fails.

The gap was never exploitable through a normal write path — the constraint
refused the pairing. What it meant is that the application held no opinion, so
one `ALTER TABLE ... DROP CONSTRAINT` stood between a firm and unsigned content.
"""

from __future__ import annotations

import json
from datetime import date, timedelta

import pytest
from sqlalchemy import select, text

from app import packs_repo, tenancy
from app.db import OwnerSessionLocal
from app.engine.pack import REVIEWED
from app.models import Pack as PackRow

CONSTRAINT = "packs_reviewed_needs_a_signatory"

#: Its own regime, dated far in the past. It never reaches any other test, both
#: because the transaction is rolled back and because `test_crossborder.py`
#: asserts today's shelf is exactly {AU, HK, SG, EU} and is right to.
REGIME = "TP"

PLACEHOLDER = "[unsigned — pending engagement]"

#: A firm that is *acting* on its determinations and holds no permit for
#: unreviewed content.
#:
#: Not the demo firm, and that is the point of the fixture rather than an
#: incidental choice: `demo` has `illustrative_content_permitted = true`, so
#: `_may_use_unreviewed` returns before any filtering happens and the loader is
#: never asked the question. The first version of this test used it and the
#: refusal never fired — a test that would have passed against the unfixed code
#: for a reason that has nothing to do with the finding.
ACTING_FIRM = "reviewed-probe"


@pytest.fixture
def unsigned_content_the_database_would_refuse(pack_bodies):
    """A `REVIEWED` pack signed by a placeholder, live only inside a transaction.

    Yields `(session, effective_on)`. The session is the owner's, because
    dropping a constraint needs it; `packs` carries no row-level security, and
    `_may_use_unreviewed` reads the tenant row, so the tenancy context is
    entered by the tests themselves.
    """
    body = dict(next(iter(pack_bodies.values())))
    body["content_status"] = REVIEWED
    body["jurisdiction"] = REGIME
    body["signed_by"] = PLACEHOLDER

    effective = date(2019, 1, 1)

    owner = OwnerSessionLocal()
    try:
        owner.execute(text(f"ALTER TABLE packs DROP CONSTRAINT {CONSTRAINT}"))
        owner.execute(
            text(
                "INSERT INTO packs (jurisdiction, version, effective_from, "
                "effective_to, body, signed_by, signed_at) VALUES "
                "(:j, 1, :from, NULL, CAST(:body AS jsonb), :by, :at)"
            ),
            {
                "j": REGIME,
                "from": effective,
                "body": json.dumps(body),
                "by": PLACEHOLDER,
                "at": effective.isoformat(),
            },
        )
        owner.flush()
        yield owner, effective
    finally:
        # Undoes the insert *and* the DDL. Nothing to clean up by hand, and
        # nothing left behind if an assertion above raised.
        owner.rollback()
        owner.close()


def test_the_row_really_is_reviewed(unsigned_content_the_database_would_refuse):
    """Without this, the refusal below would prove nothing.

    A test that asserts "the loader refused it" passes just as well when the row
    was never written, or was written with a status the loader was always going
    to reject.
    """
    session, effective = unsigned_content_the_database_would_refuse

    row = session.scalars(
        select(PackRow).where(PackRow.jurisdiction == REGIME)
    ).one()

    assert row.content_status == REVIEWED
    assert row.signed_by == PLACEHOLDER


def test_a_reviewed_pack_signed_by_a_placeholder_is_refused_at_load(
    unsigned_content_the_database_would_refuse,
):
    """The application's own answer, with the database unable to give one.

    Before FP3-06 this row loaded. `content_status` is `REVIEWED`, which was all
    `_usable` looked at, and `is_production_grade` — the property written to
    answer exactly this — had no caller.
    """
    session, effective = unsigned_content_the_database_would_refuse

    with tenancy.acting_as(ACTING_FIRM):
        with pytest.raises(packs_repo.NoReviewedPackAvailable):
            packs_repo.active(session, REGIME, effective + timedelta(days=1))


def test_the_same_pack_with_a_real_signatory_loads(
    unsigned_content_the_database_would_refuse,
):
    """The other half, so this is a check on the signatory and not on the regime.

    Same row, same status, same date — only the name changes.
    """
    session, effective = unsigned_content_the_database_would_refuse

    row = session.scalars(select(PackRow).where(PackRow.jurisdiction == REGIME)).one()
    body = dict(row.body)
    body["signed_by"] = "Su-Lee Oei"
    body["version"] = 2

    # A second row, not an UPDATE. `packs` is append-only and the trigger
    # refuses one — which is the invariant working, and worth meeting here
    # rather than reading about.
    session.execute(
        text(
            "INSERT INTO packs (jurisdiction, version, effective_from, "
            "effective_to, body, signed_by, signed_at) VALUES "
            "(:j, 2, :from, NULL, CAST(:body AS jsonb), :by, :at)"
        ),
        {
            "j": REGIME,
            "from": effective + timedelta(days=1),
            "body": json.dumps(body),
            "by": "Su-Lee Oei",
            "at": effective.isoformat(),
        },
    )
    session.flush()

    with tenancy.acting_as(ACTING_FIRM):
        loaded = packs_repo.active(session, REGIME, effective + timedelta(days=2))

    assert loaded.signed_by == "Su-Lee Oei"


def test_the_constraint_survives_this_file():
    """The teardown, asserted rather than assumed.

    `packs` is global. A constraint left off by the fixture would be left off for
    every test after it, in the table that governs what every firm may decide on
    — which is what happened on the first attempt at this file.
    """
    owner = OwnerSessionLocal()
    try:
        present = owner.execute(
            text(
                "SELECT 1 FROM pg_constraint WHERE conname = :name "
                "AND conrelid = 'packs'::regclass"
            ),
            {"name": CONSTRAINT},
        ).scalar()
        leaked = owner.scalars(
            select(PackRow).where(PackRow.jurisdiction == REGIME)
        ).all()
    finally:
        owner.close()

    assert present, f"{CONSTRAINT} is not on the table"
    assert not leaked, "a sacrificial pack was committed and cannot be removed"
