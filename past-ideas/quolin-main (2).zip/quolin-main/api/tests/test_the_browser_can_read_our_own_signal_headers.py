"""A header the web client is written to read has to reach it.

Found by CI, after F8 — and it is a defect in the product rather than in the
test that surfaced it.

`POST /auth/login` answers `401` with `X-Quolin-MFA: required` when an account
owes a second factor, and `web/lib/api.ts` branches on exactly that header to
throw `MfaRequired`, which is what makes `AuthGate` reveal the six-digit field
rather than showing a failure. The engine cannot say sooner that an account has
a factor without becoming an account-enumeration oracle, so this header *is* the
mechanism.

**The browser could not read it.** `CORSMiddleware` was configured with
`allow_origins`, `allow_credentials`, `allow_methods` and `allow_headers`, and
no `expose_headers`. Only the CORS-safelisted response headers are visible to
cross-origin JavaScript; everything else reads back as `null`. The web client
and the API are different sites — that is the whole reason the session cookie is
`SameSite=None`, and it is true in development too, where the web client is on
:3000 and the engine on :8000.

So `res.headers.get('X-Quolin-MFA')` was always `null` in a browser,
`MfaRequired` never threw, and the message fell into the generic error branch:
the person saw "Enter the six-digit code from your authenticator app." rendered
as an error, with their password cleared and no field to type a code into.
**No privileged account could complete a sign-in through the web client, on any
deployment.**

It was invisible because nothing exercised it. Every role that required a factor
— `approver`, `pack_signatory`, `tenant_admin`, `quolin_support` — is one the
browser suite never signs in as; the offline regression signs in as the
operator, and the operator had no factor until F8 gave them one. The moment that
changed, the only browser test in the repository walked into it.

These assertions are about the *response a browser receives*, not about the
middleware's arguments, because a list that is configured and a header that
arrives are different claims and only the second one matters.
"""

from __future__ import annotations

import pytest
from conftest import reset_rate_limit_for_tests
from fastapi.testclient import TestClient

from app.main import app
from tests.conftest import ADMIN_EMAIL, BROWSER_ORIGIN, TEST_PASSWORD, second_factor_code

#: The headers this API sends as signals *to the client*, rather than as part of
#: a payload. Every one of them is useless if the browser cannot read it.
SIGNAL_HEADERS = (
    "X-Quolin-MFA",
    "X-Quolin-Reauth",
    "X-Quolin-Request-Id",
)


def _exposed(response) -> set[str]:
    raw = response.headers.get("access-control-expose-headers", "")
    return {part.strip().lower() for part in raw.split(",") if part.strip()}


def test_the_mfa_signal_is_readable_by_a_browser() -> None:
    """The finding, at the response a browser actually gets.

    A privileged account signing in with no code must come back both *carrying*
    the header and *permitting* the page to read it. Either half missing and the
    code field never appears.
    """
    reset_rate_limit_for_tests()

    with TestClient(app) as client:
        res = client.post(
            "/auth/login",
            json={"email": ADMIN_EMAIL, "password": TEST_PASSWORD, "code": ""},
            headers={"origin": BROWSER_ORIGIN},
        )

    assert res.status_code == 401, (
        f"the seeded admin signed in with no code: {res.status_code}. This test "
        "needs an account that owes a second factor."
    )
    assert res.headers.get("x-quolin-mfa") == "required", res.headers

    assert "x-quolin-mfa" in _exposed(res), (
        "the response carries X-Quolin-MFA but does not expose it, so "
        "`res.headers.get('X-Quolin-MFA')` is null in a browser. `AuthGate` "
        "never reveals the six-digit field, and no privileged account can "
        "complete a sign-in through the web client."
    )


@pytest.mark.parametrize("header", SIGNAL_HEADERS)
def test_every_signal_header_is_exposed(header: str) -> None:
    """The whole set, so the next one added does not repeat this.

    `X-Quolin-Reauth` is the same mechanism for credential freshness: the
    client's move on that 401 is to ask for the password again rather than to
    give up, and it cannot tell the two apart without reading the header.
    `X-Quolin-Request-Id` is on every response and is what the error messages
    tell people to quote to support — which they cannot do if the page cannot
    see it.
    """
    reset_rate_limit_for_tests()

    with TestClient(app) as client:
        res = client.get("/health", headers={"origin": BROWSER_ORIGIN})

    assert header.lower() in _exposed(res), (
        f"{header} is sent by this API and not exposed to the browser"
    )


def test_the_preflight_agrees() -> None:
    """The browser asks before it sends; the answer has to match."""
    with TestClient(app) as client:
        res = client.options(
            "/auth/login",
            headers={
                "origin": BROWSER_ORIGIN,
                "access-control-request-method": "POST",
                "access-control-request-headers": "content-type",
            },
        )

    assert res.status_code in (200, 204), res.text
    assert res.headers.get("access-control-allow-origin") == BROWSER_ORIGIN


def test_a_foreign_origin_is_still_not_allowed() -> None:
    """Exposing headers must not have widened who may read them.

    `expose_headers` says *which* headers a permitted origin may read. It says
    nothing about which origins are permitted, and this asserts the second thing
    did not move while the first was being fixed.
    """
    with TestClient(app) as client:
        res = client.get("/health", headers={"origin": "https://not-ours.example"})

    assert res.headers.get("access-control-allow-origin") != "https://not-ours.example"


def test_the_second_factor_flow_completes_the_way_the_browser_walks_it() -> None:
    """Both steps, in order, as `AuthGate` performs them.

    Asserted end to end rather than only at the header, because the header being
    readable is worth nothing if the code that follows it is refused.
    """
    reset_rate_limit_for_tests()

    with TestClient(app) as client:
        first = client.post(
            "/auth/login",
            json={"email": ADMIN_EMAIL, "password": TEST_PASSWORD, "code": ""},
            headers={"origin": BROWSER_ORIGIN},
        )
        assert first.status_code == 401
        assert "x-quolin-mfa" in _exposed(first)

        code = second_factor_code(ADMIN_EMAIL)
        assert code, "the seeded admin has no authenticator — run `make seed`"

        second = client.post(
            "/auth/login",
            json={"email": ADMIN_EMAIL, "password": TEST_PASSWORD, "code": code},
            headers={"origin": BROWSER_ORIGIN},
        )

    assert second.status_code == 200, second.text
