"""§S6's second gate item, walked end to end.

    "A real source change (or staged fixture in live-shaped form) flows:
     detect → triage → draft → specialist signs → tenants notified →
     pinned tenants UAT."

Seven steps, six of which were built in earlier stages and none of which had ever
been asserted *as one sequence*. That distinction matters more here than usual:
every step has its own tests, and a chain of individually-tested links is exactly
the shape of a system that does not work end to end. The seam that broke while
this file was being written was between two of them.

The publication is a fixture in live shape — the same dict a real Atom feed
parses into — so the flow being tested is the live one, with no network.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from conftest import publish_with_dual_control, the_bytes_on_the_row
from sqlalchemy import select

from app import advance, tenancy
from app.models import Pack as PackRow
from app.models import PackDraft, Tenant, WatchEvent
from app.watch import drafts, lifecycle, poll, triage

DEMO_TENANT = "demo"
SIGNATORY = "usr_test_gate_signatory"
OFFICER = "usr_test_gate_officer"

#: A publication in the shape a live Atom fetch produces. The words are chosen to
#: match AU vocabulary the pack itself declares, because triage matching invented
#: terms would test the test rather than the pack.
PUBLICATION = {
    "source_id": "au-asic-media",
    "title": "ASIC consults on design and distribution obligations for crypto-assets",
    "summary": (
        "The consultation proposes changes to the concentration limit applied to "
        "digital asset exposure in target market determinations."
    ),
    "url": "https://example.invalid/asic/cp-999-a-fixture",
    "published_at": date.today().isoformat(),
}


@pytest.fixture
def undo(session):
    """Roll the whole walk back, whatever happens.

    Nothing here is committed. That is the only clean-up available: this test
    publishes a pack version, and `packs` is append-only — the trigger refuses
    DELETE for the owner as much as for anybody else, which is the guarantee
    working rather than an obstacle. A published version left behind would sit
    in front of every later test as the version in force for AU.

    The rollback has to be explicit rather than implied by not committing,
    because the session is shared with the rest of the suite: rows flushed and
    left pending are committed by whichever test commits next. That is how this
    leaked the first time — the walk passed, and six tests in three other files
    failed on the second run against the same database.
    """
    try:
        yield
    finally:
        session.rollback()


def test_a_publication_becomes_a_version_a_pinned_tenant_takes(
    session, undo, monkeypatch
):
    """The whole of §S6's flow, in one sequence, with the gate's own wording as
    the section headings."""

    # --- detect --------------------------------------------------------------
    #
    # Through `poll`, not by inserting a row: the digest and the idempotency that
    # depends on it are part of what is being tested. Re-running a sweep must not
    # raise the same publication twice, and an officer who has dismissed an item
    # must not have it handed back to them.
    # The publication is injected at the fixture loader rather than through a
    # stub HTTP transport, so that `sources.sync` still sees the real declared
    # source list — patching that would disable every other source for the rest
    # of the suite. Everything downstream of the loader is the real path:
    # digest, idempotency, triage, and the row that gets written.
    monkeypatch.setattr(poll, "_load_fixture", lambda: [PUBLICATION])

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(OFFICER):
        before = set(session.scalars(select(WatchEvent.digest)))
        poll.poll(session, date.today())
        session.flush()
        after = set(session.scalars(select(WatchEvent.digest)))

    fresh = after - before
    assert len(fresh) == 1, "the publication was not detected exactly once"
    digest = fresh.pop()

    with tenancy.acting_as(DEMO_TENANT):
        event = session.scalars(
            select(WatchEvent).where(WatchEvent.digest == digest)
        ).one()

    # --- triage --------------------------------------------------------------
    #
    # The tier is a statement about a string overlap with pack content, not about
    # whether the rules are now wrong. What makes it defensible is that the terms
    # that produced it are attached to the row.
    assert event.tier == triage.TOUCHES_RULE_CONTENT, (
        "a publication naming this pack's own vocabulary did not reach the top of "
        f"the queue: tier={event.tier}, matched={event.matched}"
    )
    assert event.matched, "a tier with no matched terms is a score wearing a name"
    touched = triage.touched_refs(event.matched)
    assert touched, "nothing in the pack was named"

    # Idempotent: the same sweep again raises nothing new.
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(OFFICER):
        again = poll.poll(session, date.today())
        session.flush()
    assert again["new_events"] == 0, "a second sweep raised the same publication again"
    assert again["already_seen"] >= 1

    # --- draft ---------------------------------------------------------------
    #
    # Cut from the version in force, with the watch item recorded against it, so
    # that "why is this being proposed" has an answer that is not a memory.
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(OFFICER):
        draft = drafts.create(
            session,
            jurisdiction="AU",
            on=date.today(),
            effective_from=date.today() - timedelta(days=1),
            title="Concentration limit, per the ASIC consultation",
            rationale="Raised by the watch queue; see the linked publication.",
            author="The Watch-To-UAT Suite",
            threshold_changes={"max_crypto_concentration_bps": 900},
            event_ids=[event.id],
        )
        session.flush()
        draft_id = draft.id
        proposed_version = draft.proposed_version

    assert draft.status == lifecycle.DRAFT
    assert draft.event_ids == [event.id], "the draft does not name what prompted it"
    assert draft.body["thresholds"]["max_crypto_concentration_bps"] == 900

    # A draft is inert. This is the property the whole watch service rests on.
    with tenancy.acting_as(DEMO_TENANT):
        in_force = session.scalars(
            select(PackRow).where(PackRow.jurisdiction == "AU").order_by(PackRow.version)
        ).all()
    assert all(p.version != proposed_version for p in in_force), (
        "a draft became rule content without a signature"
    )

    # --- a specialist signs --------------------------------------------------
    #
    # And the signature captures the hash of the exact bytes, so that "they signed
    # v4" cannot quietly become a weaker claim than "they signed these bytes".
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(SIGNATORY):
        # Put up for review first, the way the workbench does it. This is the
        # step that found the bug: `drafts.sign` refused anything but DRAFT, so
        # a draft submitted through the screen could not then be signed. Both
        # halves had tests; nothing walked the pair.
        lifecycle.move(
            session,
            session.get(PackDraft, draft_id),
            lifecycle.IN_REVIEW,
            note="submitted for review",
            actor=OFFICER,
        )
        signed = drafts.sign(
            session,
            draft_id,
            signatory="Aoife Brennan",
            signed_content_hash=the_bytes_on_the_row(session, draft_id),
            note="Checked against CP 999.",
        )
        session.flush()

    assert signed.status == lifecycle.SIGNED
    assert signed.content_hash == lifecycle.content_hash(signed.body)

    # Published by somebody else — Stage 2's two-person rule, still standing.
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(OFFICER):
        pack = publish_with_dual_control(session, draft_id)
        session.flush()

    assert pack.version == proposed_version
    assert pack.signed_by == "Aoife Brennan"

    # --- it becomes effective ------------------------------------------------
    #
    # By a date arriving, recorded by the sweep rather than happening silently.
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(OFFICER):
        lifecycle.settle(session, today=date.today())
        session.flush()
        moved = session.get(PackDraft, draft_id)
    assert moved.status in (lifecycle.EFFECTIVE, lifecycle.SUPERSEDED)

    # --- tenants notified ----------------------------------------------------
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(OFFICER):
        noticed = advance.sweep(session, tenant_id=DEMO_TENANT)
        session.flush()
        mine = [r for r in noticed if r.pack_version == proposed_version]

    assert mine, "the tenant was never told a new version exists"
    row = mine[0]

    # --- a pinned tenant gets a window ---------------------------------------
    with tenancy.acting_as(DEMO_TENANT):
        tenant = session.get(Tenant, DEMO_TENANT)
        policy, window = advance.policy_for(tenant)
    assert policy == advance.PINNED, "this test needs a pinned tenant to mean anything"
    assert row.status == advance.PENDING
    assert row.window_closes_at is not None

    with tenancy.acting_as(DEMO_TENANT):
        pending = [p for p in advance.pending(session) if p["id"] == row.id]
    assert pending, "the staged version is not on the customer's list"
    assert pending[0]["days_left"] is not None

    # The version is in force on the shelf and *not* applied to this tenant.
    # This is the property the whole advance policy exists for: a pinned firm's
    # determinations do not move until they say so.
    with tenancy.acting_as(DEMO_TENANT):
        applied = advance.effective_version_for(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", on=date.today()
        )
    assert applied != proposed_version, (
        "a pinned tenant was silently moved onto a version they have not taken"
    )

    # --- and they take it ----------------------------------------------------
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(OFFICER):
        taken = advance.advance(session, row.id, actor=OFFICER, note="UAT complete.")
        session.flush()
        now_on = advance.effective_version_for(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", on=date.today()
        )

    assert taken.status == advance.ADVANCED
    assert taken.advanced_by == OFFICER
    assert now_on == proposed_version, "taking a version did not move the tenant onto it"
