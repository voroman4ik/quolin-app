"""A capability this system does not have is not described in the present tense.

The Gate A audit's eighth finding. `docs/integrations.md` told an engineer at a
customer, in the present tense, that *"you get an SFTP account, chrooted to your
own directory"* and *"at rest, files are PGP-encrypted"*. There is no Transfer
Family resource, no sshd and no PGP handling anywhere in this repository, and
`api/app/batch.py`'s own comment defers to *"server configuration described in
`docs/integrations.md`"* — to the document that claims it exists.

The internal record was right about it the whole time: SFTP and PGP are
post-raise. The customer-facing page was never corrected, which is the pattern
the first external review named — a claim outrunning code, resurfacing in the
document a diligence engineer reads first.

**This is the mechanical form, and it runs in both directions.**

*Forwards:* a customer-facing document may mention a capability on the
`NOT_BUILT` list only inside a section that says it is not built. Not a ban on
the word — describing a shape you intend to build is legitimate and useful, and
a check that forbade it would push the description into a sales conversation
where nobody can read it afterwards. What is forbidden is describing it beside
the things that *are* built, in the same voice.

*Backwards, and this is the half that keeps the list honest:* each entry carries
the evidence that it is not built — a pattern that must match nothing in `infra/`
and `api/`. The day somebody deploys Transfer Family, this file fails and asks
for the documents to be updated the other way. A list of "things we have not
built", hand-maintained, becomes a list of things we used not to have built.

**The circularity worth naming, and why there is no test for it.**
`api/app/batch.py` deferred the transport claim to `docs/integrations.md` — to
the document that made it in the present tense. Neither file was lying on its
own. A test asserting that comment exists would be a grep for a string in
application source, which is precisely what Rule A
(`test_no_test_reads_source.py`) forbids and for precisely the reason it gives:
"a grep for a name in a file is satisfied by the comment explaining the call".
The first version of this file did it and Rule A caught it. What is enforceable
is the half below — the section `batch.py` points at says the transport is not
delivered — and that is asserted.

**H5 — the sweep discovers its own subjects now.** `CUSTOMER_FACING` was a
hand-kept list of eleven filenames, so a document added to `docs/` was outside
this check until somebody remembered to add it there too — and "until somebody
remembers" is the enforcement `docs/deployment.md`'s prose rule had before
`scripts/deployed_workers.py` replaced it. The list is inverted: every top-level
`docs/*.md` is swept unless `INTERNAL` exempts it with a reason, so a new
customer-facing document is checked the moment it exists and an exemption is a
decision somebody wrote down.

**A word on what this cannot check.** It cannot read a sentence and decide
whether it is true. What it can do is refuse the specific, enumerable case where
a document and the repository disagree about whether something exists — which is
this finding, and was also FP3-02's and G-07's. The general problem stays a
reading exercise, and `docs/spec-changes.md` is where the reading is recorded.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
DOCS = REPO / "docs"

#: The documents that are *not* customer-facing, and why each one is not.
#:
#: H5, and this list is the inversion of the one it replaces. `CUSTOMER_FACING`
#: used to be a hand-kept list of eleven filenames, which meant a new
#: customer-facing document escaped this sweep entirely until somebody
#: remembered to add it — and the day nobody remembers is the day a claim
#: outruns the code in a file nothing is reading. A list of what is checked goes
#: stale silently; a list of what is *exempt* cannot, because everything else is
#: swept by default and a new document is checked the moment it exists.
#:
#: Every entry carries the reason it is exempt. An exemption without one is
#: indistinguishable from an omission, which is `scripts/deployed_workers.py`'s
#: rule about the operating table and is the same rule.
INTERNAL: dict[str, str] = {
    "post-raise.md": (
        "the list of things deliberately not built — the one document where "
        "the present tense would be wrong the other way round"
    ),
    "spec-changes.md": (
        "the change log, which has to be able to describe what was removed and "
        "what a document used to claim"
    ),
    "deployment.md": (
        "the operating manual for whoever runs this. It names SFTP and EFS in "
        "the operating table's deferral reason for `make batch-sweep`, which is "
        "a statement that the transport does not exist, written for an operator "
        "rather than for a customer"
    ),
}

#: Where the documents live, and what counts as one.
#:
#: Top-level `docs/*.md`. `docs/runbooks/` is written for whoever holds the
#: pager and `docs/api/` is generated from the code by `make api-docs`, so
#: neither is a place a claim can be written into by hand — and the generated
#: contract has its own staleness check in `make api-docs-check`.
DOC_GLOB = "*.md"

#: The documents a customer, an auditor or a diligence engineer reads.
#:
#: Discovered rather than enumerated. `test_the_internal_list_accounts_for_every
#: _document` is what keeps the exemptions honest in the other direction.
CUSTOMER_FACING = tuple(
    sorted(p.name for p in DOCS.glob(DOC_GLOB) if p.name not in INTERNAL)
)

#: Phrases that mark a section as describing something not delivered. A section
#: mentioning a capability below must contain one of these.
MARKERS = (
    "not built",
    "not delivered",
    "not implemented",
    "planned",
    "unimplemented",
    "deferred",
    "post-raise",
    "does not exist",
    # The plainest way to say it, and the one this document's own status note
    # uses: "there is no SFTP server, no per-tenant chroot and no PGP handling".
    "there is no",
)

#: `"would be"` was on that list and is not, because it let the finding through.
#:
#: The section describing SFTP as delivered also contained "a shared directory
#: **would be** one customer able to read another's book" — a sentence about a
#: risk, not about a deferral — and that was enough to satisfy the check on the
#: original document. A marker has to be a phrase that can only mean "this does
#: not exist yet"; anything looser is a check that agrees with whatever it is
#: shown. Found by running this file against the pre-fix `integrations.md`,
#: where it passed.
_REJECTED_MARKERS = ("would be", "will be", "eventually")

#: Capabilities this system does not have, and how to tell.
#:
#: Each entry carries the evidence that it is not built, and the evidence is
#: chosen so that **none of it is a grep over application source**. Rule A —
#: `test_no_test_reads_source.py` — forbids proving a claim about `api/app` by
#: reading it, because "a grep for a name in a file is satisfied by the comment
#: explaining the call". That rule caught the first version of this file and was
#: right to: it read `api/app/batch.py` to assert a comment was there.
#:
#: So a Python capability is absent when the package that would provide it is
#: not a **dependency** — which is a stronger claim than no import, since a
#: package that is not installed cannot be imported — and a Terraform one is
#: absent when no resource declares it, read from `infra/`, which is a
#: deployment fact and not application source.
NOT_BUILT: dict[str, dict] = {
    "SFTP": {
        "mentions": r"\bSFTP\b|\bsftp\b|\bchroot",
        "packages": ("paramiko", "pysftp", "asyncssh"),
        "terraform": r'resource\s+"aws_transfer_',
        "why": (
            "no Transfer Family resource, and no package that speaks the "
            "protocol is a dependency. `app/batch.py` processes a directory "
            "tree that something else would have to fill."
        ),
    },
    "PGP": {
        "mentions": r"\bPGP\b|\bGPG\b|\bgnupg\b",
        "packages": ("gnupg", "python-gnupg", "pgpy", "pretty-bad-protocol"),
        "terraform": None,
        "why": (
            "nothing in this system encrypts or decrypts a file at rest under "
            "an external key. `app/crypto.py` seals database columns under a "
            "tenant's data key, which is a different claim about different "
            "bytes."
        ),
    },
    "custody adapters": {
        "mentions": r"custody (read )?adapter",
        "packages": (),
        "terraform": None,
        # Asked of the module rather than of its text: the interface is what
        # `PositionsProvider` implementations there are, and there is one.
        "providers_are_fixtures_only": True,
        "why": (
            "`FixturePositionsProvider` reads a file in this repository, and it "
            "is the only implementation. The execution document says to choose "
            "vendors by the first customers' stacks, and there are no first "
            "customers."
        ),
    },
}



def _sections(text: str) -> list[tuple[str, str]]:
    """A document split at its markdown headings, as `(heading, body)`.

    Sections rather than the whole file, because a document with a "What is not
    built" section at the bottom would otherwise excuse a present-tense claim
    three hundred lines above it — which is exactly the shape of what was wrong
    with `integrations.md`, whose status note said the REST API was being built
    while the drop section described SFTP as delivered.
    """
    parts = re.split(r"^(#{1,4} .*)$", text, flags=re.M)
    out: list[tuple[str, str]] = []
    # `parts[0]` is whatever precedes the first heading.
    if parts[0].strip():
        out.append(("(preamble)", parts[0]))
    for heading, body in zip(parts[1::2], parts[2::2], strict=False):
        out.append((heading.strip(), body))
    return out


CASES = [
    pytest.param(name, doc, id=f"{name}:{doc}")
    for name in NOT_BUILT
    for doc in CUSTOMER_FACING
]


@pytest.mark.parametrize("capability,document", CASES)
def test_an_unbuilt_capability_is_never_described_as_delivered(capability, document):
    """Every section mentioning it says, in that section, that it is not built."""
    path = DOCS / document
    if not path.exists():
        pytest.fail(f"{document} is named as customer-facing and does not exist")

    pattern = re.compile(NOT_BUILT[capability]["mentions"])
    offenders = []
    for heading, body in _sections(path.read_text()):
        if not pattern.search(heading + body):
            continue
        haystack = (heading + body).lower()
        if not any(marker in haystack for marker in MARKERS):
            offenders.append(heading)

    assert not offenders, (
        f"{document} describes {capability} in sections that do not say it is "
        f"unbuilt: {offenders}. {NOT_BUILT[capability]['why']}\n\n"
        "This is not a ban on the word — describing a shape you intend to build "
        "is legitimate. What is refused is describing it beside the things that "
        "are built, in the same voice, to somebody who cannot tell them apart."
    )


@pytest.mark.parametrize("capability", sorted(NOT_BUILT))
def test_the_unbuilt_list_is_still_true(capability):
    """The other direction, and the half that keeps this file from going stale.

    A hand-maintained list of "things we have not built" becomes, over time, a
    list of things we *used* not to have built — and then this file is enforcing
    a caveat on a capability that ships. So each entry names the evidence, and
    the day the evidence stops holding this fails and asks for the documents to
    be corrected the other way.

    None of the evidence is a read of `api/app`. See `NOT_BUILT`.
    """
    entry = NOT_BUILT[capability]
    hits: list[str] = []

    # A package that is not a dependency cannot be imported, which is a stronger
    # statement than "no file imports it" and does not involve reading any.
    declared = (REPO / "api" / "pyproject.toml").read_text().lower()
    locked = (REPO / "api" / "uv.lock").read_text().lower()
    for package in entry["packages"]:
        needle = f'"{package}'
        if needle in declared or f'name = "{package}"' in locked:
            hits.append(f"{package} is a dependency of api/pyproject.toml")

    if entry["terraform"]:
        pattern = re.compile(entry["terraform"], re.I | re.M)
        for path in sorted((REPO / "infra").rglob("*.tf")):
            if ".terraform" in path.parts:
                continue
            if pattern.search(path.read_text()):
                hits.append(f"{path.relative_to(REPO)} declares it")

    if entry.get("providers_are_fixtures_only"):
        from app import providers

        implementations = [
            name
            for name in dir(providers)
            if name.endswith("PositionsProvider") and name != "PositionsProvider"
        ]
        if implementations != ["FixturePositionsProvider"]:
            hits.append(
                f"app.providers offers {implementations}, which is more than the "
                "fixture"
            )

    assert not hits, (
        f"{capability} appears to be built now:\n  " + "\n  ".join(hits) + "\n\n"
        "This file has been telling every customer-facing document to caveat it. "
        "Remove it from NOT_BUILT and correct those documents the other way — a "
        "caveat on a capability that ships is the same defect pointing in the "
        "opposite direction."
    )


def test_the_document_that_sends_a_customer_to_check_is_not_missing_an_edge():
    """`/integrations` is offered as the authority, so it has to be complete.

    `docs/integrations.md` §6 says: *"`/integrations` in the product lists every
    external edge, its status, and what it would be in production. It is
    computed rather than asserted, so it cannot go stale into a lie. Read it
    before you assume something is live."*

    The batch file drop — the largest edge in that document, and the one whose
    transport does not exist — had no entry on that endpoint at all. A customer
    following the instruction found nothing about it and could have concluded
    either way, which is the failure `app/integrations.py`'s own docstring says
    it exists to prevent: an unlabelled boundary reads exactly like an
    integrated one.
    """
    from conftest import DEMO_TENANT

    from app import integrations, tenancy
    from app.db import SessionLocal

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            edges = integrations.describe(session)
        finally:
            session.close()

    ids = {edge["id"] for edge in edges}
    assert "batch_file_drop" in ids, (
        "the batch file drop is not an edge on /integrations, and "
        "docs/integrations.md tells a customer that endpoint lists every one."
    )

    drop = next(edge for edge in edges if edge["id"] == "batch_file_drop")
    assert drop["status"] != "live", (
        "the file drop reports `live`, which promises the transport reaches a "
        "counterparty outside this deployment. It does not exist."
    )
    assert "not built" in drop["detail"].lower(), (
        "the edge does not say the transport is unbuilt, so a reader sees a "
        "boundary with a status and no statement about what is missing."
    )


# ------------------------------------------------ and the list stays honest --


def test_the_sweep_found_documents_to_sweep():
    """A scan of nothing is not a clean scan — `scripts/guard_lib.sh`'s rule.

    `CUSTOMER_FACING` is computed now, so it can become empty by a typo in a
    glob rather than by anybody deciding anything. An empty one would make every
    parametrised case above vanish and the file report a pass having read no
    document at all, which is the precise failure §S13 named.
    """
    assert len(CUSTOMER_FACING) >= 8, (
        f"this sweep found {CUSTOMER_FACING}, which is not the set of documents "
        f"in {DOCS}. It is pointed at the wrong place, or INTERNAL has grown "
        "until nothing is being checked."
    )


def test_the_internal_list_accounts_for_every_document():
    """H5. Every top-level document is swept or exempt, and nothing is neither.

    The list this replaces was a hand-kept set of eleven filenames, so a new
    customer-facing document was outside the sweep until somebody remembered to
    add it — and "until somebody remembers" is the same enforcement mechanism
    `docs/deployment.md`'s prose rule had before `scripts/deployed_workers.py`.

    Inverted, the staleness cannot hide: a document that is neither swept nor
    exempt does not exist, because everything not exempt is swept. What this
    asserts is the other half — that `INTERNAL` names files that are really
    there, so an entry outliving its document does not sit in the list quietly
    exempting a name nobody has.
    """
    present = {p.name for p in DOCS.glob(DOC_GLOB)}
    missing = sorted(set(INTERNAL) - present)
    assert not missing, (
        f"INTERNAL exempts documents that do not exist: {missing}. An exemption "
        "nobody prunes is the next thing somebody adds theirs beside."
    )

    assert present == set(CUSTOMER_FACING) | set(INTERNAL), (
        "a document under docs/ is neither swept nor exempt, which this "
        "arrangement is supposed to make impossible"
    )


@pytest.mark.parametrize("document", sorted(INTERNAL))
def test_every_exemption_says_why(document: str):
    """A deferral with no reason reads exactly like an omission.

    The rule `scripts/deployed_workers.py` applies to a DEFERRED row in the
    operating table, applied to the same shape here: a filename in an exemption
    list with nothing beside it is a decision nobody can review, and the review
    is the only thing that keeps the list from growing.
    """
    reason = INTERNAL[document].strip()
    assert len(reason) > 40, (
        f"{document} is exempt from this sweep with no real reason: {reason!r}"
    )
