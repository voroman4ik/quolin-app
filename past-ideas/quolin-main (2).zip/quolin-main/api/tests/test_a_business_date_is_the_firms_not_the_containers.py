"""FP3-05: whose calendar day a determination is dated on.

Q-03 fixed the timestamp timezone and every `datetime` in this codebase is
`datetime.now(timezone.utc)`, which is right. The **business date** is a
different question and was never asked: it was `date.today()`, the process's
local calendar date, which on ECS is UTC.

Reproduced before the fix, at 2026-08-27T23:30:00Z — 09:30 on the 28th in
Sydney:

  * `check_as_of(date(2026, 8, 28))` was refused `as_of_in_the_future`. A Sydney
    operator asking for a determination dated today was told today had not
    happened, for the first ten hours of every working day.
  * The console's default `as_of` recorded the 27th on work done on the 28th.
  * `packs_repo.active_rows(session, date.today())` meant a pack effective on
    the 28th began governing that firm at 10:00 local rather than at midnight.

Replay is untouched — `evidence.replay` reads no clock — so nothing already on
file moves. What moves is every determination made from now on, and the
direction of the old error is that a firm's morning was recorded as yesterday.
"""

from __future__ import annotations

from datetime import date, datetime, timezone

import pytest
from fastapi import HTTPException
from sqlalchemy import select

from app import business_time, tenancy, v1
from app.db import OwnerSessionLocal, SessionLocal
from app.models import Decision, Tenant
from tests.conftest import DEMO_TENANT

#: The instant the whole finding lives in: 2026-08-27T23:30Z.
#:
#: 09:30 on the **28th** in Sydney, and still the **27th** in New York (19:30,
#: UTC-4 in August). The first draft of this used London for the contrast and
#: the test refused it — London is UTC+1 in August, so it is already the 28th
#: there too, and the assertion was wrong rather than the code. Worth leaving
#: written down: "UTC and London are the same date" is exactly the assumption a
#: guard against timezone errors should not be built on.
SYDNEY_MORNING = datetime(2026, 8, 27, 23, 30, tzinfo=timezone.utc)

WESTWARD_PROBE = "business-date-probe-new-york"


@pytest.fixture(scope="module")
def a_new_york_firm():
    """A firm whose business day is not the primary region's.

    The point of the column: a Sydney default is right for every tenant that
    exists today, and would be wrong the day a customer on another continent
    signs.
    """
    owner = OwnerSessionLocal()
    try:
        from sqlalchemy import text

        owner.execute(
            text(
                "INSERT INTO tenants (id, name, region, tier, status, stage, config, "
                "business_timezone, created_at) VALUES (:id, 'Business date probe', "
                "'us-east-1', 'shared', 'active', 'pilot', '{}'::jsonb, "
                "'America/New_York', now()) ON CONFLICT (id) DO UPDATE SET "
                "business_timezone = 'America/New_York', region = 'us-east-1'"
            ),
            {"id": WESTWARD_PROBE},
        )
        owner.commit()
    finally:
        owner.close()
    return WESTWARD_PROBE


def _freeze(monkeypatch) -> None:
    """Pin `business_today` to one instant, without pinning the process clock.

    The original is captured *before* the patch. The first version of this
    referred to `business_time.business_today` inside the replacement, which by
    then was the replacement — a lambda calling itself, and a `RecursionError`
    rather than a wrong date, which is at least the loud kind of mistake.
    """
    original = business_time.business_today
    monkeypatch.setattr(
        business_time,
        "business_today",
        lambda *a, **k: original(*a, **{**k, "now": SYDNEY_MORNING}),
    )


def _tenant(tenant_id: str) -> Tenant:
    """Read a tenant row through a session of its own.

    Not the suite's shared `session` fixture: that one is session-scoped and
    holds a transaction open for the whole run, so a tenant inserted by the
    fixture below is outside its snapshot and comes back as None — which reads
    as "the row was never written" and is not.
    """
    with tenancy.acting_as(tenant_id):
        with SessionLocal() as fresh:
            row = fresh.get(Tenant, tenant_id)
            assert row is not None, f"{tenant_id} is missing — run `make seed`"
            fresh.expunge(row)
            return row


def test_the_seeded_firms_business_day_is_sydney():
    """Backfilled from the region, and asserted rather than assumed.

    Every tenant in the seeded database is `ap-southeast-2`, which is what made
    `Australia/Sydney` the right backfill — checked against the data rather than
    taken from the brief.
    """
    assert _tenant(DEMO_TENANT).business_timezone == "Australia/Sydney"


def test_at_half_past_nine_in_sydney_today_is_already_tomorrow_in_utc():
    """The instant the finding lives in, stated as arithmetic."""
    demo = _tenant(DEMO_TENANT)

    assert business_time.business_today(tenant=demo, now=SYDNEY_MORNING) == date(2026, 8, 28)
    assert business_time.platform_today(SYDNEY_MORNING) == date(2026, 8, 27)


def test_a_new_york_firms_day_is_not_a_sydney_firms_day(a_new_york_firm):
    westward = _tenant(a_new_york_firm)
    assert business_time.business_today(
        tenant=westward, now=SYDNEY_MORNING
    ) == date(2026, 8, 27)


def test_a_sydney_operator_may_date_a_determination_today(session, monkeypatch):
    """The reproduction, inverted.

    Before this, a Sydney operator at 09:30 asking for `as_of` = their today was
    refused as forward-dating.
    """
    _freeze(monkeypatch)
    with tenancy.acting_as(DEMO_TENANT):
        # Accepted: it is the 28th where this firm is.
        v1.check_as_of(session, date(2026, 8, 28), None)

        # And the day after is still refused, so the bound did not simply move.
        with pytest.raises(HTTPException) as refused:
            v1.check_as_of(session, date(2026, 8, 29), None)
    assert refused.value.detail["code"] == "as_of_in_the_future"


def test_a_new_york_firm_is_still_refused_the_date_a_sydney_firm_may_use(
    session, monkeypatch, a_new_york_firm
):
    """Same instant, different firm, different answer. That is the whole change."""
    _freeze(monkeypatch)
    with tenancy.acting_as(a_new_york_firm):
        v1.check_as_of(session, date(2026, 8, 27), None)
        with pytest.raises(HTTPException) as refused:
            v1.check_as_of(session, date(2026, 8, 28), None)
    assert refused.value.detail["code"] == "as_of_in_the_future"


def test_an_unreadable_timezone_falls_back_rather_than_taking_the_console_down():
    """A typo in a provisioning field must not be an outage.

    Wrong by at most a day and visible, against a firm's whole console failing
    on every determination.
    """
    broken = Tenant(id="x", name="x", region="ap-southeast-2")
    broken.business_timezone = "Mars/Olympus_Mons"
    assert business_time.zone_for(broken).key == "UTC"


def test_no_seeded_decision_changed_its_stored_as_of(session):
    """This only affects determinations made from now on.

    Asserted because the standing rule is that a remediation must not alter
    stored evidence: `as_of` is written once, `evidence.replay` reads no clock,
    and nothing in this change rewrites a row. The check is cheap and the claim
    is the kind that should not rest on reasoning alone.
    """
    with tenancy.acting_as(DEMO_TENANT):
        rows = session.scalars(select(Decision).order_by(Decision.id).limit(50)).all()
    assert rows, "no seeded decisions — run `make seed` first"
    for row in rows:
        assert isinstance(row.as_of, date)
        # Every seeded determination is dated on or before the day it was
        # recorded, in either calendar. A row dated ahead of its own creation
        # would mean this change had moved one.
        assert row.as_of <= row.created_at.astimezone(timezone.utc).date() + _ONE_DAY


_ONE_DAY = __import__("datetime").timedelta(days=1)


def test_the_business_date_survives_the_suite_running_under_either_clock():
    """CI runs the whole suite twice, `TZ=UTC` and `TZ=Australia/Sydney`.

    The answer must come from the tenant's timezone and the instant, never from
    the process's. Asserted directly: the same instant and the same tenant give
    the same date whatever `TZ` says, which is what makes the two CI runs a real
    check rather than the same run twice.
    """
    import os
    import time

    demo = Tenant(id="d", name="d", region="ap-southeast-2")
    demo.business_timezone = "Australia/Sydney"

    before = os.environ.get("TZ")
    try:
        for zone in ("UTC", "Australia/Sydney", "America/New_York"):
            os.environ["TZ"] = zone
            time.tzset()
            assert business_time.business_today(
                tenant=demo, now=SYDNEY_MORNING
            ) == date(2026, 8, 28), f"the answer moved with TZ={zone}"
    finally:
        if before is None:
            os.environ.pop("TZ", None)
        else:
            os.environ["TZ"] = before
        time.tzset()
