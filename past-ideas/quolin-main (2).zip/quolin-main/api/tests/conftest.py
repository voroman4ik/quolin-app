from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest
from sqlalchemy import select

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# And the repository root, so `scripts` is importable.
#
# Several guards moved into Python during fix-pack 3 — the migration linter, the
# engine purity and jurisdiction checks, the ECS credential allow-list — and the
# tests that exercise them import the module rather than shelling out and
# parsing stdout. Done once here rather than with a `sys.path.insert` at the top
# of each of them.
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

# The master key is not defaulted, and deliberately. A default here would have
# to equal the one `make seed` used or every seeded row would be unreadable,
# which means the same key written down in two places — and the day they drift,
# the failure is a wall of authentication errors that say nothing about the
# cause. The Makefile owns the value; this only insists it arrived.
if not os.getenv("QUOLIN_MASTER_KEY"):
    raise RuntimeError(
        "QUOLIN_MASTER_KEY is not set. Run the suite with `make test`, which "
        "passes the development key the seed also uses. See the note above "
        "DEV_MASTER_KEY in the Makefile for why that key is not a secret."
    )

from app import tenancy  # noqa: E402
from app.db import SessionLocal  # noqa: E402
from app.models import Decision  # noqa: E402
from seed.seed import DISPOSABLE_MARK, SEED_PASSWORD  # noqa: E402


def _refuse_a_database_that_is_not_ours() -> None:
    """Stop before the first test if this database is not the suite's to destroy.

    Q-16 reported every client record in the demo tenant becoming undecryptable
    after a full suite run. It could not be reproduced — eight full runs, plus
    the key-rotation and encryption suites on their own, and all 217 demo
    clients decrypted through the application's own path every time. What the
    attempt made obvious is a different problem, and a worse one.

    The README has always warned that the suite writes to the demo database. A
    warning in a README is not a control. Nothing stopped `make test` being
    pointed at a database holding a customer's records — and this suite creates
    tenants, mints determinations, publishes rule content, disables append-only
    triggers and deletes every row of `auth_attempts`. If Q-16 was real, that is
    the blast radius it had.

    So the suite refuses to run against a database that has not been marked
    disposable, and only `make seed` marks one — and `make seed` drops the
    schema and rebuilds it from zero, so a database it has run against is
    disposable by definition. The mark is a comment on the database rather than
    a table, so no migration can put it on a deployment by being applied there.
    """
    from sqlalchemy import text

    from app.db import OWNER_DATABASE_URL, owner_engine

    with owner_engine.connect() as conn:
        name = conn.execute(text("SELECT current_database()")).scalar()
        mark = conn.execute(
            text(
                "SELECT shobj_description(oid, 'pg_database') FROM pg_database "
                "WHERE datname = current_database()"
            )
        ).scalar()

    if not (mark or "").startswith(DISPOSABLE_MARK):
        raise RuntimeError(
            f"refusing to run: the database {name!r} is not marked disposable.\n"
            f"\n"
            f"  DATABASE_URL is {OWNER_DATABASE_URL.split('@')[-1]}\n"
            f"  its comment is {mark!r}\n"
            f"\n"
            f"This suite creates tenants, mints determinations, publishes rule\n"
            f"content, suspends append-only triggers and empties `auth_attempts`.\n"
            f"It may only do that to a database whose entire contents are\n"
            f"disposable, and the only thing that says so is `make seed`, which\n"
            f"drops the schema and rebuilds it from zero.\n"
            f"\n"
            f"If this is a development database:   make seed\n"
            f"If this is anybody's real data:      point DATABASE_URL somewhere else."
        )


_refuse_a_database_that_is_not_ours()

PACKS_DIR = Path(__file__).resolve().parents[2] / "packs"

#: The seeded people the suite signs in as, by the role that makes them useful.
#: Imported from the seed rather than restated, for the reason the master key
#: note above gives: two copies of a credential drift, and the drift shows up as
#: an authentication failure that says nothing about its cause.
TEST_PASSWORD = SEED_PASSWORD
OPERATOR_EMAIL = "dana.whitfield@quolin.example"
APPROVER_EMAIL = "marcus.oyelaran@quolin.example"
SIGNATORY_EMAIL = "aoife.brennan@quolin.example"
ADMIN_EMAIL = "ruth.castellanos@quolin.example"
VIEWER_EMAIL = "peter.lindqvist@quolin.example"
#: Quolin's own operator, not the firm's. The only account that may publish rule
#: content into the global `packs` table — see Q-12 and `app/rbac.py`.
PUBLISHER_EMAIL = "sofia.marchetti@quolin.example"
#: The two named humans who hold platform publication. FP3-27.
#:
#: `PUBLISHER_EMAIL` above holds `quolin_operator`, which is what lets somebody
#: *reach* the publish endpoint. Performing the act needs a row in
#: `platform_publishers`, a table with no `tenant_id` that no tenant role can
#: produce — and Sofia deliberately does not have one, which makes her the
#: account the FP3-27 refusal test uses.
PLATFORM_PUBLISHER_EMAIL = "volodymyr.romanenko@quolin.example"
SECOND_PUBLISHER_EMAIL = "su-lee.oei@quolin.example"


def reset_rate_limit_for_tests(session=None) -> None:
    """Forget every sign-in attempt. Owner-only, and only the suite calls it.

    **F2, and this used to be `auth._reset_rate_limit_for_tests`.** It sat in
    the one module everything that serves a request imports, and what it does is
    disable `auth_attempts_append_only` as the schema owner and delete every
    row: invariant 4 breached from request code, and the login rate limit with
    it. It was also the last reason `auth.py` appeared in the guard's list of
    files allowed to open `app.owner_only` — an allow-list entry keeping a door
    open for a caller that is not in the request path at all.

    The argument for leaving it there was that forty test call sites named it.
    That is a fact about diffs, not about what is enforced, and the call sites
    moved mechanically in one commit.

    Here rather than in `app`, because the suite is where the caller is. The
    owner-privileged SQL itself stays in `app/owner_only.py` — the module that
    refuses to import without `DATABASE_URL` — rather than being copied into a
    test helper that would build its own owner session, which is the shape the
    guard's third rule now forbids everywhere else.

    Imported inside the function, so that collecting this file does not need the
    owner credential.
    """
    from app.owner_only import reset_rate_limit

    reset_rate_limit(session)


def sign_in(c, email: str = ADMIN_EMAIL, password: str = TEST_PASSWORD):
    """Log a test client in, and fail loudly rather than 401 later if it cannot.

    A fixture that silently yielded an unauthenticated client would turn one
    broken seed into a hundred confusing 401s in tests about something else.
    """
    body = {"email": email, "password": password}
    code = second_factor_code(email)
    if code:
        # §S13 enforces `MFA_REQUIRED_ROLES`, and the seed enrols an
        # authenticator for anybody it names. A privileged account signing in
        # types a six-digit code, so the helper that stands in for a person
        # types one too — rather than the suite quietly testing a firm whose
        # approvers have no second factor, which is the state the enforcement
        # exists to end.
        body["code"] = code
    res = c.post("/auth/login", json=body)
    assert res.status_code == 200, f"test login as {email} failed: {res.text}"
    return c


def second_factor_code(email: str) -> str:
    """The current code for a seeded account that has an authenticator, if any."""
    from app import totp
    from app.db import OwnerSessionLocal
    from app.models import MfaCredential, User

    owner = OwnerSessionLocal()
    try:
        user = owner.scalars(select(User)).all()
        match = next((u for u in user if u.email == email), None)
        if match is None:
            return ""
        credential = owner.scalars(
            select(MfaCredential).where(MfaCredential.user_id == match.id)
        ).first()
        if credential is None or credential.confirmed_at is None:
            return ""

        # Rewind the replay counter before reading a code.
        #
        # A TOTP code is one-time *per time step*: `check_second_factor` records
        # the step it accepted and refuses that step again, which is the whole
        # point — a code read over somebody's shoulder is spent. The suite signs
        # in dozens of times inside one thirty-second step, so without this the
        # second sign-in of every run is refused as a replay of the first.
        #
        # Resetting here rather than widening the window in the application: the
        # helper is standing in for a person who waited, and the property being
        # faked is time, not the check.
        credential.last_used_counter = 0
        owner.commit()
        return totp.code_at(str(credential.secret))
    finally:
        owner.close()


#: The tenant the seeded demo data belongs to. Migration 0002 creates the row.
DEMO_TENANT = "demo"

#: What a browser would say. Q-05 added a cross-site refusal to the middleware:
#: an unsafe method that does not say where it came from is refused before
#: anything happens, because every current browser sends `Origin` on one and a
#: cookie-carrying POST without it is not a browser doing something ordinary.
#:
#: A `TestClient` stands in for a browser and sent nothing, so the fixture below
#: makes every client in this suite send what the thing it is standing in for
#: would send. Not a way around the check — a test that wants to *be* a foreign
#: page passes its own `Origin` on the request, and
#: `test_cross_site_requests_are_refused.py` does exactly that.
#:
#: `localhost:3000` rather than `testserver`: on a hosted deployment the web
#: client is a different site from the API, which is the whole reason the cookie
#: is `SameSite=None`, and testing the same-site case would test the easy one.
BROWSER_ORIGIN = "http://localhost:3000"


@pytest.fixture(scope="session", autouse=True)
def _test_clients_send_an_origin():
    """Give every `TestClient` in the suite the header a browser would send.

    Patched at the constructor rather than passed at each of the thirty-odd call
    sites, because the interesting property is that *all* of them behave like
    browsers. A call site that forgot would fail with a 403 that says nothing
    about the reason, which is a bad way to learn about a middleware.
    """
    from fastapi.testclient import TestClient

    original = TestClient.__init__

    def with_origin(self, *args, **kwargs):
        headers = dict(kwargs.pop("headers", None) or {})
        headers.setdefault("origin", BROWSER_ORIGIN)
        original(self, *args, headers=headers, **kwargs)

    TestClient.__init__ = with_origin
    try:
        yield
    finally:
        TestClient.__init__ = original


@pytest.fixture(scope="session")
def session():
    """A database session acting for the demo firm.

    The tenant is entered here rather than in each test because a Session in
    this suite stands in for a request, and a request always arrives with a
    tenant — the middleware sets it from the session row before any handler
    runs. A test holding a session with no tenant would be testing a state the
    application cannot be in.

    Deliberately not autouse. Tests that need to observe the *absence* of a
    tenant — the fail-closed assertions in test_rls.py — take raw connections
    instead, and an autouse fixture would quietly set the thing they exist to
    prove is unset.
    """
    with tenancy.acting_as(DEMO_TENANT):
        s = SessionLocal()
        yield s
        s.rollback()
        s.close()


@pytest.fixture(scope="module")
def client():
    """A signed-in API client.

    Every test written before authentication existed still receives an
    authenticated client, so those tests keep testing what they were written to
    test rather than all collapsing into assertions about 401. The
    unauthenticated case gets its own explicit fixture in test_auth.py: it is a
    behaviour to be proven, not a default to fall into.

    Signed in as the seeded operator, because running checks, generating
    artefacts and filing returns is what most of these tests do and `operator` is
    the role that does it. Not as the tenant admin, which would have been the
    tempting choice: admin holds no operational permission at all, deliberately,
    so that nobody both administers the firm and does its compliance work.

    A fixture cannot stand in for everyone. Overriding a decision, signing rule
    content and publishing it belong to three other roles by design, and the
    tests for those sign in for themselves with `sign_in`.
    """
    from fastapi.testclient import TestClient

    from app.main import app

    with TestClient(app) as c:
        yield sign_in(c, OPERATOR_EMAIL)


@pytest.fixture(scope="module")
def approver():
    """A second client, held by the person who may approve an override.

    Separate from `client` rather than a role added to it, because approving is
    not only a different permission but must be a different *person*. A test
    that ran the check and approved the override through one client would pass
    today and break the day the two-person rule lands — which is the wrong
    order in which to find out that the test was describing a violation.
    """
    from fastapi.testclient import TestClient

    from app.main import app

    with TestClient(app) as c:
        yield sign_in(c, APPROVER_EMAIL)


@pytest.fixture
def decisions(session) -> list[Decision]:
    """Every recorded decision, as the database holds it *at this moment*.

    Deliberately not session-scoped. `decisions` is append-only and tests append
    to it — any test that evaluates adds a row. A cached snapshot taken by the
    first test to ask would then disagree with a live aggregate computed by a
    later one, and the reporting tests compare exactly those two things. The
    failure looks like a reporting bug and is not one.

    `expire_all` for the same reason: writes arrive through the API's own
    session, so this one has to be told its identity map is out of date.
    """
    session.expire_all()
    rows = list(session.scalars(select(Decision).order_by(Decision.id)))
    if not rows:
        pytest.fail("no seeded decisions — run `make seed` first")
    return rows


@pytest.fixture(scope="session")
def pack_bodies() -> dict[tuple[str, int], dict]:
    """Every committed pack, keyed by the pair that actually identifies one.

    Keyed by version alone while only one jurisdiction existed. The moment a
    second regime shipped a v1, four of five packs collapsed onto the same key
    and vanished from every validation test that reads this fixture — quietly,
    with everything still green. A pack is a regime and a version, never a
    version on its own.
    """
    return {
        (body["pack_id"], body["version"]): body
        for body in (json.loads(p.read_text()) for p in PACKS_DIR.glob("*.json"))
    }


def a_platform_publisher(user_id: str, *, note: str = "test") -> str:
    """Make sure this account exists and may publish global rule content.

    FP3-27. Publication is no longer conferred by any tenant role: it is a row
    in `platform_publishers`, a table with no `tenant_id`, writable only by the
    owner. Tests that publish need one, and several of them use synthetic ids
    like `user-publisher` that have no `users` row at all — so this creates the
    person as well as the grant.

    Owner connection, because that is the only thing that may write the table,
    which is the control rather than an inconvenience.
    """
    from app.db import OwnerSessionLocal
    from app.models import PlatformPublisher, User

    owner = OwnerSessionLocal()
    try:
        if owner.get(User, user_id) is None:
            owner.add(
                User(
                    id=user_id,
                    email=f"{user_id}@quolin.test",
                    display_name=user_id,
                    status="active",
                )
            )
            owner.flush()
        if owner.get(PlatformPublisher, user_id) is None:
            owner.add(
                PlatformPublisher(user_id=user_id, note=note, granted_by="tests")
            )
        owner.commit()
    finally:
        owner.close()
    return user_id


def the_bytes_on_the_row(session, draft_or_id) -> str:
    """The hash of a draft's body as it stands, for a test not about the binding.

    Every attestation recorder in `watch.drafts` now takes a required
    `*_content_hash` — what the attester says they read — and refuses when it is
    not what is on the row. At an HTTP route that value comes from a `view()` a
    person actually looked at, which is the whole control. A test driving the
    recorder directly has no screen, so it passes the row's own hash and thereby
    says nothing it did not already know.

    That is not a way around the check and it should not be read as one. The
    requirement exists so the *route* cannot skip it, and the route can only be
    held to it if the function it calls insists. A test that is about the binding
    passes a value that is deliberately wrong — see
    `test_an_attestation_is_of_the_bytes_the_attester_saw.py` — and every test
    that is about something else uses this, so that "which tests care about the
    hash" is answerable by grepping for the ones that do not call it.
    """
    from app.db import OwnerSessionLocal
    from app.models import PackDraft as _PackDraft
    from app.watch import drafts as _drafts

    if isinstance(draft_or_id, _PackDraft):
        return _drafts.content_hash(draft_or_id.body)

    # `session=None` for the callers that have a draft id and no session in
    # scope — a test driving HTTP, which needs a truthful hash so that the
    # refusal it is about is the one that answers. Its own session rather than a
    # borrowed one, and closed here, so it cannot leave a transaction open
    # across the request the test is really making.
    owner = session or OwnerSessionLocal()
    try:
        draft = owner.get(_PackDraft, draft_or_id)
        assert draft is not None, f"no draft {draft_or_id!r} to hash"
        return _drafts.content_hash(draft.body)
    finally:
        if session is None:
            owner.close()


def publish_with_dual_control(
    session,
    draft_id: int,
    *,
    publisher: str = "user-publisher",
    second: str = "user-second-publisher",
):
    """Publish a signed draft the way FP3-27 requires: two publishers, one signer.

    Three distinct humans. The signer attested to the content; these two each
    decide it should govern every customer. Pressing publish counts as one
    approval, so the second is recorded first.

    One helper rather than the same six lines in six tests — and one place to
    change if the count ever moves, which it is not going to.

    Both attesters pass the hash of the body they are acting on, which the
    census made required. Read once, before either acts, and reused: this helper
    is publishing a draft nothing is editing, so the honest thing for it to say
    is "we both looked at this body" — and a test that wants the *unhappy* case
    passes its own value or drives the routes directly.
    """
    from app import tenancy as _t
    from app.models import PackDraft as _PackDraft
    from app.watch import drafts as _drafts

    a_platform_publisher(publisher)
    a_platform_publisher(second)

    draft = session.get(_PackDraft, draft_id)
    assert draft is not None, f"no draft {draft_id} to publish"
    what_they_read = _drafts.content_hash(draft.body)

    with _t.acting_as_user(second):
        _drafts.approve_publication(
            session,
            draft_id,
            approved_content_hash=what_they_read,
            note="second pair of eyes",
        )
    with _t.acting_as_user(publisher):
        return _drafts.publish(
            session, draft_id, published_content_hash=what_they_read
        )


def publish_through_the_api(client_factory, draft_id: int) -> dict:
    """Publish a signed draft over HTTP, with the second approval FP3-27 needs.

    `client_factory(email)` is whatever the calling file uses to get a signed-in
    client — `as_person` in the separation-of-duties tests, a local helper
    elsewhere. Two different platform publishers, neither of whom signed.

    Each of them reads the draft and sends back the hash of what they were shown,
    which is what a workbench does and what the census made required. Read
    per-client rather than once: that is the sequence the routes are written for,
    and a helper that shared one hash between two people would be exercising a
    path no client takes.
    """
    second = client_factory(SECOND_PUBLISHER_EMAIL)
    approved = second.post(
        f"/watch/drafts/{draft_id}/approve-publication",
        json={"approved_content_hash": what_this_client_reads(second, draft_id)},
    )
    assert approved.status_code in (200, 409), approved.text

    publisher = client_factory(PLATFORM_PUBLISHER_EMAIL)
    return publisher.post(
        f"/watch/drafts/{draft_id}/publish",
        json={"published_content_hash": what_this_client_reads(publisher, draft_id)},
    )


def what_this_client_reads(client, draft_id: int) -> str:
    """The `current_content_hash` of the draft as this client is shown it.

    What a workbench does before it signs, approves or publishes: read the draft,
    then send back the hash of the body it was given. Every test driving those
    routes over HTTP for some *other* reason — RBAC, CSRF, dual control, a
    malformed pack — uses this, so that the thing being tested is what fails
    rather than a missing field.

    Through `GET` rather than the database on purpose: the value a route must be
    given is the one a person's screen was rendered from, and a test that reached
    past the read would be asserting against a body no client saw. A test that is
    *about* the binding passes a deliberately wrong value instead — see
    `test_an_attestation_is_of_the_bytes_the_attester_saw.py`.
    """
    read = client.get(f"/watch/drafts/{draft_id}")
    assert read.status_code == 200, read.text
    return str(read.json()["current_content_hash"])
