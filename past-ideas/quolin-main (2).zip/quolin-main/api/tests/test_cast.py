"""Table-driven: every hand-crafted client must hit its intended demo moment."""

from __future__ import annotations

from datetime import date

import pytest

from app import packs_repo
from app.engine import build_snapshot, evaluate_snapshot, failing_reasons
from app.models import Asset
from app.providers import DbClientProvider, FixturePositionsProvider

TODAY = date.today()

CAST = [
    ("margaret-wu", "BTC", TODAY, "ALLOW", set()),
    (
        "tom-askew",
        "SOL",
        TODAY,
        "BLOCK",
        {"CONC_EXCEEDED", "LOSS_CAPACITY_INSUFFICIENT", "OUTSIDE_TARGET_MARKET"},
    ),
    ("tom-askew", "BTC3L", TODAY, "BLOCK", {"LEVERAGED_RETAIL"}),
    ("priya-nair", "ETH", TODAY, "REFER", {"LOSS_CAPACITY_BORDERLINE"}),
    ("harold-bell", "BTC", TODAY, "REFER", {"VULNERABILITY_REVIEW"}),
    ("dana-cole", "BTC", TODAY, "BLOCK", {"KNOWLEDGE_NOT_ASSESSED"}),
    ("alex-reyes", "BTC", TODAY, "ALLOW", set()),
    ("alex-reyes", "ALGO-USD", TODAY, "REFER", {"STRUCTURAL_RISK_ACK"}),
    # The replay moment: under the pack in force in November 2025, Harold's
    # 12% concentration was inside the 15% cap. Only the vulnerability flag fired.
    ("harold-bell", "SOL", date(2025, 11, 14), "REFER", {"VULNERABILITY_REVIEW"}),
]


def _assess(session, client_id: str, asset_id: str, as_of: date):
    client = DbClientProvider(session).get(client_id)
    asset = session.get(Asset, asset_id)
    pack = packs_repo.active(session, "AU", as_of)
    snapshot = build_snapshot(
        pack=pack,
        client=client,
        positions=FixturePositionsProvider().get(client_id, as_of),
        asset={"id": asset.id, "symbol": asset.symbol, "name": asset.name},
        amount_cents=client["default_trade_amount_cents"],
        as_of=as_of,
    )
    evaluation = evaluate_snapshot(pack, snapshot)
    codes = {r["reason_code"] for r in failing_reasons(evaluation, pack)}
    return evaluation, codes, pack


@pytest.mark.parametrize(
    "client_id,asset_id,as_of,expected_outcome,expected_codes",
    CAST,
    ids=[f"{c}-{a}-{d}" for c, a, d, _, _ in CAST],
)
def test_cast_client_outcomes(
    session, client_id, asset_id, as_of, expected_outcome, expected_codes
):
    evaluation, codes, _ = _assess(session, client_id, asset_id, as_of)
    assert evaluation["outcome"] == expected_outcome
    assert expected_codes <= codes, f"missing {expected_codes - codes}, got {codes}"


def test_tom_askew_sol_shows_exactly_three_reasons(session):
    """The §1 demo moment: BLOCK with three plain-English reasons."""
    evaluation, codes, pack = _assess(session, "tom-askew", "SOL", TODAY)
    reasons = failing_reasons(evaluation, pack)

    assert evaluation["outcome"] == "BLOCK"
    assert len(reasons) == 3, [r["reason_code"] for r in reasons]
    for reason in reasons:
        assert reason["reason_plain_english"], (
            f"{reason['reason_code']} has no officer-readable text"
        )
        assert reason["inputs_read"] or reason["thresholds_used"]


def test_margaret_wu_allows_with_no_reasons(session):
    evaluation, codes, _ = _assess(session, "margaret-wu", "BTC", TODAY)
    assert evaluation["outcome"] == "ALLOW"
    assert codes == set()


def test_the_replay_decision_would_be_judged_differently_today(session, decisions):
    """Rules changed; the historical decision must not be retrospectively rewritten.

    Harold's November 2025 assessment is the one the demo replays. Under the pack
    of record it was a REFER. Run the identical stored inputs through today's pack
    and it becomes a BLOCK, because the concentration cap tightened.
    """
    stored = next(
        d
        for d in decisions
        if d.client_id == "harold-bell" and d.as_of == date(2025, 11, 14)
    )
    assert stored.pack_version == 1
    assert stored.outcome == "REFER"

    pack_of_record = packs_repo.by_version(session, "AU", 1)
    current_pack = packs_repo.active(session, "AU", TODAY)
    assert current_pack.version == 2

    as_recorded = evaluate_snapshot(pack_of_record, stored.snapshot)
    under_todays_rules = evaluate_snapshot(current_pack, stored.snapshot)

    assert as_recorded["outcome"] == "REFER"
    assert under_todays_rules["outcome"] == "BLOCK"

    recorded_codes = {r["reason_code"] for r in failing_reasons(as_recorded, pack_of_record)}
    today_codes = {r["reason_code"] for r in failing_reasons(under_todays_rules, current_pack)}
    assert recorded_codes == {"VULNERABILITY_REVIEW"}
    assert "CONC_EXCEEDED" in today_codes


def test_every_reason_code_used_by_a_rule_has_officer_readable_text(pack_bodies):
    for (pack_id, version), body in pack_bodies.items():
        for rule in body["rules"]:
            code = rule["reason_code"]
            assert code in body["reason_codes"], f"{pack_id} v{version}: {code} has no text"
            assert body["reason_codes"][code]["plain_english"].strip()
