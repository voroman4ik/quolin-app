"""Key rotation, run rather than described.

A rotation procedure nobody has executed is a paragraph, not a procedure. This
runs `scripts/rotate_keys.py` as an operator would — same entry point, same
environment variables, same exit codes — against a tenant that exists only to
be rotated, and then rotates it back.

The claim being checked is narrow and is the one the script's own header makes:
the data key is *unchanged* and only its wrapping moves. If rotation ever
started replacing data keys, every test here would still pass on the surface
and every existing ciphertext would have become unreadable. So the assertion is
on the data key's bytes, before and after.
"""

from __future__ import annotations

import base64
import os
import subprocess
import sys
from pathlib import Path

import pytest
from sqlalchemy import select

from app import crypto, tenancy
from app.db import OwnerSessionLocal
from app.models import AuditEvent, Tenant, TenantKey

REPO = Path(__file__).resolve().parents[2]

#: A tenant with a data key and no data. Rotating the demo firm's key would
#: work, but it would also mean the suite rewriting the row every other test in
#: the run reads its clients through.
SPARE = "spare"

CURRENT_KEY = os.environ["QUOLIN_MASTER_KEY"]


def _run(*args: str, master: str, new: str | None = None) -> subprocess.CompletedProcess[str]:
    env = os.environ | {"QUOLIN_MASTER_KEY": master}
    if new is not None:
        env["NEW_MASTER_KEY"] = new
    else:
        env.pop("NEW_MASTER_KEY", None)
    return subprocess.run(
        [sys.executable, "-m", "scripts.rotate_keys", *args],
        cwd=REPO,
        env=env,
        capture_output=True,
        text=True,
    )


def _wrapped(tenant_id: str) -> bytes:
    with tenancy.acting_as(tenant_id):
        session = OwnerSessionLocal()
        try:
            return bytes(session.get(TenantKey, tenant_id).wrapped_key)
        finally:
            session.close()


def _rewraps(tenant_id: str) -> int:
    """The rotation counter. Read as a delta, never as an absolute — it is a
    running total over the life of the row, and this suite rotates twice a run.
    """
    with tenancy.acting_as(tenant_id):
        session = OwnerSessionLocal()
        try:
            return session.get(TenantKey, tenant_id).rewraps
        finally:
            session.close()


@pytest.fixture
def spare():
    """A throwaway tenant, provisioned and left provisioned.

    Committed rather than rolled back: the script runs in its own process and
    would not see an uncommitted row.

    The repair below exists because this is the one tenant whose key this suite
    deliberately rewrites. A run interrupted between the rotation and the
    rotation back would leave the row wrapped under a key that no longer exists
    anywhere, and every later run would then fail on the fixture rather than on
    anything real. Deleting and reissuing is safe here and nowhere else: this
    tenant has no rows to be sealed under the key being discarded.
    """
    with tenancy.acting_as(SPARE):
        session = OwnerSessionLocal()
        try:
            if session.get(Tenant, SPARE) is None:
                session.add(Tenant(id=SPARE, name="Spare Holdings", region="ap-southeast-2"))
                session.flush()
            existing = session.get(TenantKey, SPARE)
            if existing is not None:
                try:
                    crypto.unwrap(existing.wrapped_key, SPARE)
                except crypto.KeysNotConfigured:
                    session.delete(existing)
                    session.flush()
                    crypto.forget_keys()
            crypto.ensure_key(session, SPARE)
            session.commit()
        finally:
            session.close()
    return SPARE


def test_rotation_moves_the_wrapping_and_leaves_the_data_key_alone(spare) -> None:
    successor = base64.b64encode(os.urandom(crypto.KEY_BYTES)).decode()

    with tenancy.acting_as(spare):
        before = crypto.unwrap(_wrapped(spare), spare)

    dry = _run(spare, master=CURRENT_KEY, new=successor)
    assert dry.returncode == 0, dry.stderr
    assert "Dry run" in dry.stdout
    assert crypto.unwrap(_wrapped(spare), spare) == before, "a dry run wrote something"

    started_at = _rewraps(spare)

    try:
        applied = _run(spare, "--apply", master=CURRENT_KEY, new=successor)
        assert applied.returncode == 0, applied.stderr

        # The old master key no longer opens it — the point of the exercise.
        with pytest.raises(crypto.KeysNotConfigured):
            crypto.unwrap(_wrapped(spare), spare)

        os.environ["QUOLIN_MASTER_KEY"] = successor
        assert crypto.unwrap(_wrapped(spare), spare) == before

        # Running the same rotation again is a no-op rather than an error, so an
        # operator who is unsure whether the first run committed can just run it
        # again instead of reading the table to find out.
        again = _run(spare, "--apply", master=CURRENT_KEY, new=successor)
        assert again.returncode == 0, again.stderr
        assert "already wrapped" in again.stdout

        assert _rewraps(spare) == started_at + 1, (
            "the second run counted a rotation that did not happen"
        )

        with tenancy.acting_as(spare):
            session = OwnerSessionLocal()
            try:
                row = session.get(TenantKey, spare)
                assert row.rewrapped_at is not None
                recorded = set(
                    session.scalars(
                        select(AuditEvent.action).where(AuditEvent.tenant_id == spare)
                    )
                )
                assert "keys.rewrap" in recorded
            finally:
                session.close()
    finally:
        back = _run(spare, "--apply", master=successor, new=CURRENT_KEY)
        os.environ["QUOLIN_MASTER_KEY"] = CURRENT_KEY
        assert back.returncode == 0, back.stderr
        assert crypto.unwrap(_wrapped(spare), spare) == before


def test_rotation_carries_the_platform_key_without_being_asked(spare) -> None:
    """The row nobody would think to name, and what happens when it is missed.

    `_platform` is not a customer. It holds the key every enrolled second factor
    is sealed under, wrapped by the same master key as every other row in
    `tenant_keys` — so an operator who rotates their tenants and retires the old
    master key has, without being told, made every second factor unreadable. The
    failure arrives hours later as users unable to sign in, with nothing in the
    rotation output pointing at the cause.

    So the script appends it whether or not it appears on the command line, and
    this asserts that by naming only the spare tenant and checking that the
    platform row moved too.
    """
    successor = base64.b64encode(os.urandom(crypto.KEY_BYTES)).decode()
    platform = crypto.PLATFORM_TENANT

    with tenancy.acting_as(platform):
        before = crypto.unwrap(_wrapped(platform), platform)

    applied = _run(spare, "--apply", master=CURRENT_KEY, new=successor)
    try:
        assert applied.returncode == 0, applied.stderr
        assert platform in applied.stdout, "the platform key was not named in the output"

        with pytest.raises(crypto.KeysNotConfigured):
            crypto.unwrap(_wrapped(platform), platform)

        os.environ["QUOLIN_MASTER_KEY"] = successor
        assert crypto.unwrap(_wrapped(platform), platform) == before, (
            "rotation replaced the platform data key instead of rewrapping it"
        )
    finally:
        back = _run(spare, "--apply", master=successor, new=CURRENT_KEY)
        os.environ["QUOLIN_MASTER_KEY"] = CURRENT_KEY
        crypto.forget_keys()
        assert back.returncode == 0, back.stderr
        assert crypto.unwrap(_wrapped(platform), platform) == before


def test_rotation_refuses_a_key_it_cannot_check(spare) -> None:
    """Every rejection here is a database that would have been sealed shut."""
    missing = _run(spare, master=CURRENT_KEY)
    assert missing.returncode != 0
    assert "NEW_MASTER_KEY is not set" in missing.stderr + missing.stdout

    short = _run(spare, master=CURRENT_KEY, new=base64.b64encode(os.urandom(16)).decode())
    assert short.returncode != 0

    same = _run(spare, master=CURRENT_KEY, new=CURRENT_KEY)
    assert same.returncode != 0
    assert "already in force" in same.stderr + same.stdout


def test_rotation_stops_rather_than_guessing_when_neither_key_fits(spare) -> None:
    """A wrong current key must not be treated as "already rotated" and skipped."""
    stranger = base64.b64encode(os.urandom(crypto.KEY_BYTES)).decode()
    successor = base64.b64encode(os.urandom(crypto.KEY_BYTES)).decode()

    result = _run(spare, "--apply", master=stranger, new=successor)
    assert result.returncode != 0
    assert "opens under neither" in result.stderr + result.stdout
    assert crypto.unwrap(_wrapped(spare), spare), "the row was written despite the refusal"
