"""FP3-14: no read was audited.

`main.py` has forty GET routes and thirty `service.audit` calls, and none of the
thirty was on a GET. `/clients/{id}` returns a name, a date of birth and contact
details to anybody holding `viewer`, and nothing anywhere recorded that it had
been read.

That is the SOC 2 question and the privacy question in one sentence: **who
looked at this record**. A firm answering a subject-access request, or an
auditor asking who saw a client's file the week before a complaint, had nothing
to read. And `docs/` describes `quolin_support` access as "every access logged",
logged nowhere.

**Three resources, not forty routes.** Auditing "somebody opened the dashboard"
produces a trail nobody reads, and a trail nobody reads is where a real access
hides. The three are the ones where the question has an answer somebody is
entitled to: a client's detail, a determination's snapshot (which carries the
client's frozen facts), and an artefact download (which is the document).
"""

from __future__ import annotations

import pytest
from conftest import DEMO_TENANT, VIEWER_EMAIL, sign_in
from fastapi.testclient import TestClient
from sqlalchemy import func, select

from app import tenancy
from app.db import SessionLocal
from app.main import app
from app.models import AuditEvent, Decision


@pytest.fixture
def viewer():
    """The least-privileged role that can still read a client's file."""
    with TestClient(app) as c:
        yield sign_in(c, VIEWER_EMAIL)


def _reads(action: str) -> list[AuditEvent]:
    with tenancy.acting_as(DEMO_TENANT):
        with SessionLocal() as s:
            return list(
                s.scalars(
                    select(AuditEvent)
                    .where(AuditEvent.action == action)
                    .order_by(AuditEvent.id.desc())
                )
            )


def _a_seeded_decision() -> Decision:
    with tenancy.acting_as(DEMO_TENANT):
        with SessionLocal() as s:
            row = s.scalars(select(Decision).order_by(Decision.id)).first()
            assert row is not None, "no seeded decisions — run `make seed`"
            s.expunge(row)
            return row


def test_a_viewer_reading_a_client_leaves_a_record(viewer):
    """The finding, as the finding states it."""
    before = len(_reads("read.client"))

    got = viewer.get("/clients/margaret-wu")
    assert got.status_code == 200, got.text

    after = _reads("read.client")
    assert len(after) > before, (
        "a viewer read a client's name, date of birth and contact details and "
        "nothing recorded it"
    )
    assert "margaret-wu" in after[0].subject


def test_the_record_names_the_person_who_looked(viewer):
    """"Who" is the whole question. An unattributed row answers none of it."""
    viewer.get("/clients/margaret-wu")
    latest = _reads("read.client")[0]

    assert latest.actor, "the read is recorded against nobody"
    assert latest.tenant_id == DEMO_TENANT


def test_the_record_is_inside_the_chain(viewer):
    """A record of access that could be edited is the shape of the finding.

    `audit_read` goes through `service.audit`, so it is linked by the same
    mechanism migration 0026 gave every other audit row.
    """
    viewer.get("/clients/margaret-wu")
    latest = _reads("read.client")[0]
    assert latest.this_hash, "the read is outside the audit hash chain"


def test_reading_a_determination_is_reading_the_client(viewer):
    """The snapshot carries the client's frozen facts.

    A trail that recorded the client screen and not the decision screen would be
    answerable by opening the second one.
    """
    decision = _a_seeded_decision()
    before = len(_reads("read.decision"))

    got = viewer.get(f"/decisions/{decision.id}")
    assert got.status_code == 200, got.text

    after = _reads("read.decision")
    assert len(after) > before
    assert f"decision:{decision.id}" in after[0].subject
    assert decision.client_id in after[0].subject, (
        "the record does not say whose determination was read"
    )


def test_the_dashboard_is_not_audited(viewer):
    """The other half, and it is a decision rather than an omission.

    Auditing every GET produces a trail nobody reads, and a trail nobody reads is
    where a real access hides. Three resources are recorded; the rest are not,
    and this is what stops that quietly becoming forty.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with SessionLocal() as s:
            before = s.scalar(select(func.count()).select_from(AuditEvent))

    viewer.get("/dashboard")
    viewer.get("/currency")

    with tenancy.acting_as(DEMO_TENANT):
        with SessionLocal() as s:
            after = s.scalar(select(func.count()).select_from(AuditEvent))

    assert after == before, (
        "opening a screen that carries no client record wrote an audit row; the "
        "trail is meant to be readable"
    )
