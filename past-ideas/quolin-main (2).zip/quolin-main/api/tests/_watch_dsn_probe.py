"""Run the watch sweep and print which of `app.db`'s engines it actually opened.

Not a test. It is the subprocess
`test_the_watch_sweep_runs_in_its_deployed_environment.py` drives, and it lives
in its own file because the claim only means anything in a *fresh interpreter*
with the deployed environment and nothing else: `app.db` builds its engines at
import time from whatever variables are present, so importing it inside the
suite would already have read the developer's own.

Prints one JSON line — the sorted names of the engines that saw a `connect`
event — as the last line of stdout.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "api"))

from sqlalchemy import event  # noqa: E402

from app import db  # noqa: E402

opened: set[str] = set()

for _name in ("engine", "owner_engine", "watch_engine"):
    _engine = getattr(db, _name, None)
    if _engine is None:  # pragma: no cover - a renamed engine
        continue

    def _listen(name: str, engine: object) -> None:
        @event.listens_for(engine, "connect")
        def _record(dbapi_connection: object, record: object) -> None:
            opened.add(name)

    _listen(_name, _engine)

from scripts import watch_tick  # noqa: E402

try:
    watch_tick.main()
except SystemExit:
    # The sweep exits non-zero while a source is in breach, by design. What is
    # under test is which engines it touched, not its verdict.
    pass

print(json.dumps(sorted(opened)))
