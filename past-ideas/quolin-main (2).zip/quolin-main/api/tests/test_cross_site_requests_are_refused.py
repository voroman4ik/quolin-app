"""A cookie the browser attaches cross-site must not carry an action with it.

The hosted deployment puts the web client and the API on different sites, so the
session cookie is issued `SameSite=None` — see `auth.cookie_kwargs`. That is the
one configuration in which a browser attaches credentials to a request some
other page caused, and there was no second check of any kind: no CSRF token, no
`Origin` check, no `Referer` check.

Reproduced by execution before this file was written. A cross-site POST to
`/auth/revoke-all` terminated 24 sessions.

Body-less endpoints are the directly exploitable ones, because a cross-site form
post can reach them without needing to send JSON. The worst is
`POST /watch/drafts/{id}/publish`, which took no body, asserted neither MFA nor
credential freshness, and put staged rule content in front of every tenant on
the platform — from one induced page load in a `tenant_admin`'s browser.

**The check belongs in the middleware, not on the routes.** A per-route
decorator is a thing somebody forgets to add, and the failure mode of forgetting
is silence. The middleware already computes the allowed-origin list for CORS,
and CORS is not this: `Access-Control-Allow-Origin` governs whether a *response*
may be read, and a state-changing POST has already changed the state by the time
the browser refuses to show it the answer.

**Bearer-authenticated requests are exempt, deliberately.** Cross-site request
forgery works because a browser attaches a cookie by itself. It never attaches
an `Authorization` header by itself, so a server-to-server integration posting
with a bearer token has no cross-site exposure and no `Origin` header to offer.
Refusing it would break every integration to fix a risk it does not have.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from conftest import (
    reset_rate_limit_for_tests,
    the_bytes_on_the_row,
    what_this_client_reads,
)
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import identity, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import ApiClient, AuthSession, PackDraft
from tests.conftest import (
    ADMIN_EMAIL,
    APPROVER_EMAIL,
    DEMO_TENANT,
    OPERATOR_EMAIL,
    PLATFORM_PUBLISHER_EMAIL,
    PUBLISHER_EMAIL,
    SECOND_PUBLISHER_EMAIL,
    SIGNATORY_EMAIL,
    sign_in,
)

#: A site that is not ours. Shaped like a real one because the check must be on
#: the value and not on the value looking suspicious.
FOREIGN = "https://totally-legitimate-invoices.example"

#: What the web client sends. On a hosted deployment it is a different site from
#: the API, which is the whole reason the cookie is `SameSite=None`.
OURS = "http://localhost:3000"

ACTOR = "apc_bulk_sweep"


@pytest.fixture
def signed_in():
    with TestClient(app) as c:
        yield sign_in(c, ADMIN_EMAIL)


def _sessions_for(user_email: str) -> int:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            user = identity.find_by_email(owner, user_email)
            assert user is not None
            # Counted rather than filtered on a flag: revocation deletes the
            # row, which is why `revoke-all` is worth attacking — there is
            # nothing to undo afterwards.
            return len(
                list(
                    owner.scalars(
                        select(AuthSession).where(AuthSession.user_id == user.id)
                    )
                )
            )
    finally:
        owner.close()


# ------------------------------------------------------------------ the gate --


@pytest.mark.parametrize(
    "path",
    ("/auth/revoke-all", "/auth/logout"),
)
def test_a_cross_site_post_is_refused_and_has_no_effect(path, signed_in) -> None:
    """The finding, directly: a foreign page cannot spend this cookie."""
    before = _sessions_for(ADMIN_EMAIL)
    assert before > 0, "the fixture is not signed in; this test would prove nothing"

    res = signed_in.post(path, headers={"origin": FOREIGN})

    assert res.status_code == 403, (
        f"a cross-site POST to {path} was accepted with {res.status_code}. The "
        "cookie is SameSite=None on a hosted deployment, so a browser attaches "
        "it to a request any page on the internet can cause."
    )
    assert _sessions_for(ADMIN_EMAIL) == before, (
        f"{path} was refused and still had an effect"
    )


def test_the_same_request_from_our_own_client_succeeds(signed_in) -> None:
    """The check must refuse the attack and not the product."""
    res = signed_in.post("/auth/logout", headers={"origin": OURS})
    assert res.status_code == 200, res.text


def test_a_referer_is_used_only_when_there_is_no_origin(signed_in) -> None:
    """`Origin` first, `Referer` as the fallback, and never the other way round.

    A `Referer` is trimmed or stripped by proxies and privacy settings, so it
    cannot be the primary check; but a request that carries one and no `Origin`
    has still said where it came from, and refusing it outright would break
    clients that are not doing anything wrong.
    """
    # The conftest fixture gives every client the `Origin` a browser would
    # send. Dropped here, because what is under test is the fallback and a
    # request carrying both would never reach it.
    signed_in.headers.pop("origin", None)

    refused = signed_in.post(
        "/auth/logout", headers={"referer": f"{FOREIGN}/pay-now.html"}
    )
    assert refused.status_code == 403, refused.text

    allowed = signed_in.post("/auth/logout", headers={"referer": f"{OURS}/clients"})
    assert allowed.status_code == 200, allowed.text


def test_a_request_that_says_nothing_about_where_it_came_from_is_refused(
    signed_in,
) -> None:
    """Silence is not a same-origin claim.

    Every current browser sends `Origin` on an unsafe method. A cookie-carrying
    POST with neither header is therefore not a browser doing something
    ordinary, and admitting it would leave the check one omitted header from
    being optional.
    """
    signed_in.headers.pop("origin", None)
    res = signed_in.post("/auth/logout")
    assert res.status_code == 403, res.text


def test_a_safe_method_is_not_refused(signed_in) -> None:
    """GET changes nothing, and a cross-site GET is what CORS is for.

    Refusing these would break the read paths without protecting anything: the
    response is what a foreign page wants and CORS is what withholds it.
    """
    res = signed_in.get("/clients", headers={"origin": FOREIGN})
    assert res.status_code == 200, res.text


def test_an_integration_posting_with_a_bearer_token_is_not_refused() -> None:
    """A browser never attaches an `Authorization` header by itself.

    So a server-to-server integration has no cross-site exposure, and no
    `Origin` to send. Refusing it would break every integration to fix a risk it
    does not have — and the risk is genuinely absent: an attacker who has the
    bearer token does not need a victim's browser to use it.

    The request below carries a foreign `Origin` *and* a bearer token, which is
    the shape that separates the two rules cleanly: the same header that refuses
    a cookie-authenticated request must not refuse this one.
    """
    from app import passwords
    from app.models import ApiClient as ApiClientRow

    credential = "apc_csrf_probe"
    secret = "an integration secret, not a real one"

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            row = owner.get(ApiClientRow, credential)
            if row is None:
                owner.add(
                    ApiClientRow(
                        id=credential,
                        label="Cross-site probe",
                        secret_hash=passwords.hash_password(secret, email=credential),
                        roles=["operator", "viewer"],
                        status="active",
                        created_by="test",
                    )
                )
            else:
                # The secret is reset too, not only the roles. A row left by an
                # earlier run of this file under a different secret would
                # otherwise refuse every token request with a message about
                # credentials, which is a confusing way to learn about fixtures.
                row.secret_hash = passwords.hash_password(secret, email=credential)
                row.roles = ["operator", "viewer"]
                row.status = "active"
            owner.commit()
    finally:
        owner.close()


    reset_rate_limit_for_tests()
    with TestClient(app) as machine:
        token = machine.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": secret,
            },
        )
        assert token.status_code == 200, token.text

        machine.headers.pop("origin", None)
        machine.headers["Authorization"] = f"Bearer {token.json()['access_token']}"
        res = machine.post(
            "/v1/clients",
            json={
                "id": "csrf-probe-client",
                "name": "Bearer Probe",
                "jurisdiction": "AU",
                "dob": "1980-01-01",
                "loss_capacity_band": 3,
                "assessable_portfolio_cents": 1000_00,
            },
            headers={"origin": FOREIGN},
        )

    assert res.status_code == 200, (
        f"a bearer-authenticated POST was refused for its Origin: "
        f"{res.status_code} {res.text}. Cross-site request forgery is about a "
        "cookie the browser attaches by itself; it never attaches this header."
    )
    assert ApiClient is not None


# ------------------------------------------------- publication is privileged --


def _draft_ready_to_publish() -> int:
    """A signed draft, cut and signed the way the workflow does it."""
    from app.watch import drafts

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            draft = drafts.create(
                session,
                jurisdiction="AU",
                on=date.today(),
                effective_from=date.today() + timedelta(days=3650),
                title="For the publication gate tests",
                rationale="Written by a test.",
                author="The Cross-Site Suite",
            )
            with tenancy.acting_as_user("user-some-signatory"):
                drafts.sign(
                    session,
                    draft.id,
                    signatory="A. Signatory",
                    signed_content_hash=the_bytes_on_the_row(session, draft),
                )
            session.commit()
            return int(draft.id)
        finally:
            session.close()


def test_a_cross_site_publish_is_refused_and_publishes_nothing() -> None:
    """The worst of the body-less endpoints, and the reason this is CRITICAL.

    `packs` is global. One induced page load in a customer admin's browser put
    staged rule content in front of every tenant on the platform.
    """
    draft_id = _draft_ready_to_publish()
    with TestClient(app) as admin:
        sign_in(admin, PUBLISHER_EMAIL)
        res = admin.post(f"/watch/drafts/{draft_id}/publish", headers={"origin": FOREIGN})

    assert res.status_code == 403, res.text
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            draft = session.get(PackDraft, draft_id)
            assert draft.published_pack_id is None, "a refused publish created a pack"
            assert draft.status == "signed"
        finally:
            session.close()


def test_publication_refuses_a_session_that_has_not_shown_a_second_factor() -> None:
    """Signing asserts MFA and credential freshness; publishing did not.

    Publication is the other half of the two-person rule and the moment content
    becomes live for every tenant. It asserted neither, so the second pair of
    eyes was the one control on the path and an unattended screen was enough.
    """
    from app import auth

    draft_id = _draft_ready_to_publish()
    with TestClient(app) as admin:
        sign_in(admin, PUBLISHER_EMAIL)

        # The same session, with its second factor no longer satisfied — which
        # is the state a session is in when it was created before enrolment.
        owner = OwnerSessionLocal()
        try:
            with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
                token = admin.cookies.get(auth.COOKIE_NAME)
                row = auth.resolve(owner, token)
                assert row is not None
                row.mfa_satisfied = False
                owner.commit()
        finally:
            owner.close()

        res = admin.post(
            f"/watch/drafts/{draft_id}/publish",
            headers={"origin": OURS},
            json={"published_content_hash": the_bytes_on_the_row(None, draft_id)},
        )

    assert res.status_code in (401, 403), (
        f"publication accepted a session with no second factor: {res.status_code} "
        f"{res.text}"
    )
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            assert session.get(PackDraft, draft_id).published_pack_id is None
        finally:
            session.close()


def test_publication_refuses_a_stale_credential() -> None:
    """The same freshness window signing and overriding already require.

    An unattended screen is the threat both of those were given this check for,
    and publication is a larger action than either.
    """
    from app import auth

    draft_id = _draft_ready_to_publish()
    with TestClient(app) as admin:
        sign_in(admin, PUBLISHER_EMAIL)

        owner = OwnerSessionLocal()
        try:
            with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
                token = admin.cookies.get(auth.COOKIE_NAME)
                row = auth.resolve(owner, token)
                assert row is not None
                row.authenticated_at = row.authenticated_at - timedelta(days=1)
                owner.commit()
        finally:
            owner.close()

        res = admin.post(
            f"/watch/drafts/{draft_id}/publish",
            headers={"origin": OURS},
            json={"published_content_hash": the_bytes_on_the_row(None, draft_id)},
        )

    assert res.status_code == 401, (
        f"publication accepted a credential a day old: {res.status_code} {res.text}"
    )
    assert res.headers.get("X-Quolin-Reauth") == "required"


def test_the_ordinary_publication_path_still_works() -> None:
    """The gate must refuse the attack and not the workflow.

    Signed by one person and published by another, from our own client, with a
    fresh credential and a second factor. This is the case §14 describes and it
    has to keep working.
    """
    draft_id = _draft_ready_to_publish()

    # FP3-27. Publication takes two platform publishers now. The origin header
    # is what this test is about and it travels on both requests, so the
    # workflow being exercised is still the one §14 describes — from our own
    # client, with a fresh credential and a second factor.
    def _as(email: str):
        client = TestClient(app)
        client.__enter__()
        sign_in(client, email)
        client.headers["origin"] = OURS
        return client

    second = _as(SECOND_PUBLISHER_EMAIL)
    second.post(
        f"/watch/drafts/{draft_id}/approve-publication",
        json={"approved_content_hash": what_this_client_reads(second, draft_id)},
    )

    publisher = _as(PLATFORM_PUBLISHER_EMAIL)
    res = publisher.post(
        f"/watch/drafts/{draft_id}/publish",
        headers={"origin": OURS},
        json={"published_content_hash": what_this_client_reads(publisher, draft_id)},
    )
    assert res.status_code == 200, res.text
    assert res.json()["pack_id"]
    assert APPROVER_EMAIL and OPERATOR_EMAIL and SIGNATORY_EMAIL
