"""Roles, and what each one may cause to happen.

The load-bearing test is `test_every_route_names_the_roles_that_may_call_it`.
It reads the live route table, so an endpoint added next month is covered by a
test written today — the same property `test_auth.py` gets for authentication,
applied to authorisation.

Everything else here is a specific claim about a specific role, written as a
pair wherever a pair is what matters: the person who may is checked next to the
person who may not, because a permission test that only ever asserts success
passes just as well against a system that permits everything.
"""

from __future__ import annotations

import pytest
from conftest import (
    ADMIN_EMAIL,
    APPROVER_EMAIL,
    OPERATOR_EMAIL,
    SIGNATORY_EMAIL,
    VIEWER_EMAIL,
    reset_rate_limit_for_tests,
    sign_in,
)
from fastapi.testclient import TestClient

from app import rbac
from app.main import PUBLIC_PATHS, _declared_routes, app
from app.models import ROLES


@pytest.fixture
def as_person():
    """Sign in as whoever a test needs, one client per person."""
    clients = []

    def _make(email: str) -> TestClient:
        reset_rate_limit_for_tests()
        c = TestClient(app)
        c.__enter__()
        clients.append(c)
        return sign_in(c, email)

    yield _make
    for c in clients:
        c.__exit__(None, None, None)


# --- the property, against the live route table ---------------------------


def test_every_route_names_the_roles_that_may_call_it():
    """No endpoint is servable without a policy, and no policy outlives its route.

    This runs at boot too — `lifespan` calls the same function, so the API
    refuses to start with a gap. It is repeated here because a boot failure is
    a thing somebody notices while deploying, and a test failure is a thing
    somebody notices while writing the route.
    """
    rbac.check_every_route_is_classified(_declared_routes(), PUBLIC_PATHS)


def test_no_policy_names_a_role_that_does_not_exist():
    """A typo in the table would silently lock an endpoint against everybody.

    `frozenset({"operater"})` is a legal frozenset and an impossible permission.
    Nothing about the request would say so: the caller sees a 403 naming a role
    they cannot be granted, because `grant_role` would refuse to write it.
    """
    named = {role for allowed in rbac.ROUTE_ROLES.values() for role in allowed}
    assert named <= set(ROLES), f"not real roles: {sorted(named - set(ROLES))}"


def test_reading_is_open_to_the_firm_and_writing_is_not():
    """The shape of the table, asserted rather than described.

    Stated independently of the table so that widening a GET to `quolin_support`
    or narrowing one to a single role is a deliberate two-place edit. The claim
    is that every role inside the firm can *see* the firm's work, and that what
    separates the roles is what they can make happen.
    """
    for (method, path), allowed in rbac.ROUTE_ROLES.items():
        if method == "GET" and path not in ("/integrations", "/evidence/verify"):
            assert rbac.STAFF <= allowed, f"GET {path} is not readable by all staff"


# --- a viewer sees everything and changes nothing -------------------------


def test_a_viewer_reads_the_firms_work(as_person):
    viewer = as_person(VIEWER_EMAIL)
    for path in ("/clients", "/decisions", "/dashboard", "/queue", "/packs"):
        assert viewer.get(path).status_code == 200, path


def test_a_viewer_cannot_run_a_check(as_person):
    """403 and not 401, and the difference is the whole point.

    401 tells the client to offer a login, which for this person would be a
    login they already have and a screen that would refuse them again. 403 says
    the account is fine and the roles are not these, which is a thing an
    administrator can act on.
    """
    res = as_person(VIEWER_EMAIL).post(
        "/evaluate", json={"client_id": "tom-askew", "asset_id": "SOL"}
    )
    assert res.status_code == 403


def test_the_refusal_says_what_is_missing(as_person):
    """A permissions error nobody can act on becomes a support ticket."""
    res = as_person(VIEWER_EMAIL).post(
        "/evaluate", json={"client_id": "tom-askew", "asset_id": "SOL"}
    )
    detail = res.json()["detail"]
    assert "operator" in detail and "viewer" in detail


# --- no ladder ------------------------------------------------------------


def test_the_tenant_admin_cannot_do_the_compliance_work(as_person):
    """The absence of inheritance, tested where it costs something.

    A ladder would be the obvious design and this is the case it gets wrong:
    the person who grants roles would acquire, for free, the ability to run a
    check and then approve the override on it. An administrator who needs to do
    the work grants themselves `operator`, and the access review shows it.
    """
    admin = as_person(ADMIN_EMAIL)
    assert admin.get("/clients").status_code == 200
    assert (
        admin.post("/evaluate", json={"client_id": "tom-askew", "asset_id": "SOL"}).status_code
        == 403
    )


def test_an_operator_cannot_approve_an_override(as_person):
    """Requesting and approving are different roles. Whether they are different
    *people* is the next rule, enforced in the handler — this is only the claim
    that no operator reaches the endpoint at all.
    """
    res = as_person(OPERATOR_EMAIL).post(
        "/decisions/1/override", json={"justification": "x" * 25}
    )
    assert res.status_code == 403


def test_an_approver_cannot_sign_rule_content(as_person):
    """Invariant 7 names a signatory, and it is not whoever approves overrides.

    Approving an override is a judgement about one client. Signing a pack is an
    attestation that rule content is a correct reading of a regime, which is a
    different competence and carries a jurisdiction with it.
    """
    res = as_person(APPROVER_EMAIL).post("/watch/drafts/1/sign", json={"note": "x"})
    assert res.status_code == 403


def test_a_signatory_cannot_publish_what_they_signed(as_person):
    """The second of the two pairs the stage gate names.

    Signing says the content is right. Publishing puts it in front of clients.
    One person doing both is one person deciding, unreviewed, what the rules
    are — so the roles are split and the split is asserted here.
    """
    res = as_person(SIGNATORY_EMAIL).post("/watch/drafts/1/publish")
    assert res.status_code == 403


# --- your own session belongs to you --------------------------------------


def test_anyone_signed_in_can_see_and_close_their_own_sessions(as_person):
    """Not a permission a role should gate.

    Somebody who suspects their account is compromised needs to be able to close
    every session immediately, and a viewer who had to ask an administrator
    first would be a viewer whose stolen cookie stays live all afternoon.
    """
    viewer = as_person(VIEWER_EMAIL)
    assert viewer.get("/auth/sessions").status_code == 200
    assert viewer.post("/auth/revoke-all").status_code == 200
