"""An identity provider small enough to reason about, real enough to prove things.

Federated sign-in is the one authentication path that cannot be tested against
the thing it talks to: there is no WorkOS in CI, and a test that mocked
`oidc.complete` would assert that the mock returns what the mock was told to
return. So the provider is written here instead — discovery, JWKS, an
authorization endpoint and a token endpoint, signing real RS256 tokens with a
real key pair, over a real socket on a loopback port.

A real server rather than a patched transport, and that is the point: it means
`app/oidc.py` has no branch that exists only for tests. What runs here is the
same code making the same ordinary HTTP requests it makes against WorkOS.

That makes the interesting negatives constructible, which is the whole point.
A token signed by the wrong key, a `nonce` from another login, an audience
belonging to a different client, an expired assertion — each is a two-line
override here, and each is a published authentication bypass in somebody's
verifier. `test_oidc.py` walks them.

The key pair is generated at import and lives only in this process. It signs
nothing but test tokens and is small on purpose: 2048 bits is what a real
provider uses, and generating it once per test session costs less than the
first Postgres round trip.
"""

from __future__ import annotations

import base64
import json
import socket
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import parse_qsl, urlencode

import jwt
import uvicorn
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

#: Set by `serving()` once the port is known. The discovery document has to
#: name the address it is actually served from — a client that accepted a
#: document whose `issuer` disagreed with where it found it would accept a
#: document served from anywhere.
ISSUER = ""

CLIENT_ID = "quolin-test-client"
CLIENT_SECRET = "test client secret, not a real one"
KEY_ID = "stub-key-1"

_PRIVATE_KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)


def _b64u(value: int) -> str:
    raw = value.to_bytes((value.bit_length() + 7) // 8, "big")
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def jwks() -> dict[str, Any]:
    numbers = _PRIVATE_KEY.public_key().public_numbers()
    return {
        "keys": [
            {
                "kty": "RSA",
                "use": "sig",
                "alg": "RS256",
                "kid": KEY_ID,
                "n": _b64u(numbers.n),
                "e": _b64u(numbers.e),
            }
        ]
    }


@dataclass
class Person:
    """Who the provider will say came back."""

    sub: str
    email: str
    email_verified: bool = True
    name: str = ""


@dataclass
class Stub:
    """The provider's dials, all of which default to behaving correctly.

    Held on one mutable object rather than passed through the endpoints, because
    a test reads better as "this provider now signs with the wrong key" than as
    a chain of query parameters threaded through a redirect it does not control.
    """

    person: Person = field(
        default_factory=lambda: Person(
            sub="idp|dana",
            email="dana.whitfield@quolin.example",
            # The name the seed already holds. A provider that asserted a
            # different one would be exercising the rename path on every test
            # rather than the one test that is about it, and would leave the
            # shared demo database renamed afterwards.
            name="Dana Whitfield",
        )
    )
    #: Set to break the signature: tokens are signed by a second key the
    #: published JWKS knows nothing about.
    sign_with_wrong_key: bool = False
    #: Set to issue a token whose `nonce` is not the one the login asked for.
    override_nonce: str | None = None
    #: Set to issue a token for somebody else's client.
    override_audience: str | None = None
    #: Seconds from now that the token expires. Negative issues a stale one.
    lifetime_seconds: int = 300
    #: Set to refuse the code exchange, as a provider does when PKCE fails.
    refuse_token: bool = False
    #: Every authorization request this provider has seen, newest last. The
    #: test that proves PKCE is sent reads the challenge out of here.
    seen: list[dict[str, str]] = field(default_factory=list)

    def reset(self) -> None:
        self.person = Person(
            sub="idp|dana", email="dana.whitfield@quolin.example", name="Dana Whitfield"
        )
        self.sign_with_wrong_key = False
        self.override_nonce = None
        self.override_audience = None
        self.lifetime_seconds = 300
        self.refuse_token = False
        self.seen.clear()


STUB = Stub()

#: A key the published JWKS does not contain, for the wrong-signature case.
_IMPOSTOR_KEY = rsa.generate_private_key(public_exponent=65537, key_size=2048)

#: Authorization codes this provider has issued, and the login each belongs to.
_CODES: dict[str, dict[str, str]] = {}

app = FastAPI()


@app.get("/.well-known/openid-configuration")
def discovery():
    return {
        "issuer": ISSUER,
        "authorization_endpoint": f"{ISSUER}/authorize",
        "token_endpoint": f"{ISSUER}/token",
        "jwks_uri": f"{ISSUER}/jwks.json",
        "response_types_supported": ["code"],
        "id_token_signing_alg_values_supported": ["RS256"],
        "code_challenge_methods_supported": ["S256"],
    }


@app.get("/jwks.json")
def keys():
    return jwks()


@app.get("/authorize")
def authorize(request: Request):
    """Consent, instantly granted. Returns the redirect the browser would follow.

    A JSON body rather than a 302, because nothing in the test is a browser —
    the test *is* the user agent, and having it read a location out of a body it
    was handed is more honest than pretending a redirect was followed.
    """
    params = dict(request.query_params)
    STUB.seen.append(params)
    code = f"code_{len(_CODES) + 1}"
    _CODES[code] = {
        "nonce": params.get("nonce", ""),
        "challenge": params.get("code_challenge", ""),
    }
    return {"redirect_to": f"{params.get('redirect_uri', '')}?" + urlencode(
        {"code": code, "state": params.get("state", "")}
    )}


@app.post("/token")
async def token(request: Request):
    # The body is parsed by hand rather than through FastAPI's `Form`, which
    # would pull `python-multipart` into the project for the sake of a test
    # fixture. A token request is `application/x-www-form-urlencoded` and this
    # is what reading one amounts to.
    posted = dict(parse_qsl((await request.body()).decode()))
    code = posted.get("code", "")
    client_id = posted.get("client_id", "")
    client_secret = posted.get("client_secret", "")
    code_verifier = posted.get("code_verifier", "")

    if STUB.refuse_token:
        return JSONResponse({"error": "invalid_grant"}, status_code=400)
    if client_id != CLIENT_ID or client_secret != CLIENT_SECRET:
        return JSONResponse({"error": "invalid_client"}, status_code=401)
    issued = _CODES.pop(code, None)  # single use, like a real one
    if issued is None:
        return JSONResponse({"error": "invalid_grant"}, status_code=400)
    if not code_verifier:
        return JSONResponse({"error": "invalid_request"}, status_code=400)

    now = int(time.time())
    claims = {
        "iss": ISSUER,
        "aud": STUB.override_audience or CLIENT_ID,
        "sub": STUB.person.sub,
        "iat": now,
        "exp": now + STUB.lifetime_seconds,
        "nonce": STUB.override_nonce if STUB.override_nonce is not None else issued["nonce"],
        "email": STUB.person.email,
        "email_verified": STUB.person.email_verified,
        "name": STUB.person.name or STUB.person.email,
    }
    signing_key = _IMPOSTOR_KEY if STUB.sign_with_wrong_key else _PRIVATE_KEY
    id_token = jwt.encode(claims, signing_key, algorithm="RS256", headers={"kid": KEY_ID})
    return {"access_token": "stub-access-token", "token_type": "Bearer", "id_token": id_token}


@contextmanager
def serving():
    """Run the provider on a loopback port for the duration of a test session.

    The port is chosen by the operating system rather than hardcoded, so a
    developer who happens to be running something on 8080 does not get a
    mystifying failure in an unrelated suite. `ISSUER` is set before the server
    starts because the discovery document has to name the address it is served
    from, and torn down afterwards so a test that forgets this fixture fails
    loudly rather than pointing at a dead port.
    """
    global ISSUER

    with socket.socket() as probe:
        probe.bind(("127.0.0.1", 0))
        port = probe.getsockname()[1]

    ISSUER = f"http://127.0.0.1:{port}"
    server = uvicorn.Server(
        uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    )
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    deadline = time.monotonic() + 15
    while not server.started:
        if time.monotonic() > deadline:  # pragma: no cover - a hung stub is a bug
            raise RuntimeError("the stub identity provider did not start")
        time.sleep(0.02)
    try:
        yield ISSUER
    finally:
        server.should_exit = True
        thread.join(timeout=10)
        ISSUER = ""


def unsigned_token(claims: dict[str, Any]) -> str:
    """A token with `alg: none`, which no verifier may accept.

    Built by hand because every library worth using refuses to produce one —
    which is the point: the attack is that a *verifier* accepts it, and the only
    way to test that is to forge one here.
    """

    def part(obj: dict[str, Any]) -> str:
        return base64.urlsafe_b64encode(
            json.dumps(obj, separators=(",", ":")).encode()
        ).decode().rstrip("=")

    return f"{part({'alg': 'none', 'typ': 'JWT'})}.{part(claims)}."
