"""The nightly replay job, run as the job rather than as a function.

The suite already replays the seeded decisions, so this file is not about
whether replay works. It is about whether the *job* works: the exit code a
monitor watches, the mismatch it is supposed to catch, and the promise that a
sweep over a customer's whole decision history changes none of it.

Run as a subprocess, the same way `test_key_rotation.py` runs the rotation
script — same entry point, same environment, same exit codes. Importing `main`
and calling it would test a function that resembles the job; what gets deployed
is the command line.

The load-bearing test is `test_an_injected_mismatch_is_caught`. A nightly job
that has never failed is indistinguishable from one that cannot fail, and the
execution document asks for the alert to be demonstrated rather than assumed.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import select

from app import tenancy
from app.models import Decision

ROOT = Path(__file__).resolve().parents[2]


def _run(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "scripts.nightly_replay", *args],
        cwd=ROOT,
        capture_output=True,
        text=True,
        env={**os.environ, "PYTHONPATH": str(ROOT / "api")},
    )


def test_a_clean_history_reports_no_mismatches_and_exits_zero():
    """The state a monitor should see every night.

    The exit code is the alert, so it is asserted rather than the output: a
    monitor that had to parse prose would be a monitor that breaks when somebody
    improves a sentence.
    """
    done = _run(DEMO_TENANT)
    assert done.returncode == 0, done.stdout + done.stderr
    assert "mismatches none" in done.stdout
    assert "chain      verified" in done.stdout


def test_an_injected_mismatch_is_caught():
    """The test this file exists for.

    Without it, a green nightly run means either "every decision reproduces" or
    "this job stopped being able to tell", and those are opposite facts wearing
    the same colour.
    """
    done = _run(DEMO_TENANT, "--inject")
    assert done.returncode == 0, done.stdout + done.stderr
    assert "— caught" in done.stdout, done.stdout
    assert "NOT CAUGHT" not in done.stdout


def test_the_job_alters_nothing_it_replays(session):
    """It reads. Including when it is deliberately breaking a decision to prove
    the alarm works — that alteration happens on a detached object and is never
    flushed.

    A nightly job that rewrote a determination it found wrong would be destroying
    the evidence it exists to check, so this asserts the whole history is
    byte-identical afterwards rather than merely that the count is unchanged.
    """
    def fingerprint() -> list[tuple]:
        session.expire_all()
        with tenancy.acting_as(DEMO_TENANT):
            return [
                (d.id, d.outcome, d.pack_version, d.this_hash, d.prev_hash)
                for d in session.scalars(select(Decision).order_by(Decision.id))
            ]

    before = fingerprint()
    assert before, "no decisions to replay — run `make seed`"

    assert _run(DEMO_TENANT, "--inject").returncode == 0
    assert fingerprint() == before, "the nightly replay changed a decision on file"


def test_the_machine_readable_form_carries_what_an_alerting_pipeline_needs():
    done = _run(DEMO_TENANT, "--json")
    assert done.returncode == 0, done.stderr

    reports = json.loads(done.stdout)
    assert len(reports) == 1
    report = reports[0]
    assert report["tenant_id"] == DEMO_TENANT
    assert report["decisions"] > 0
    assert report["mismatches"] == []
    assert report["chain"]["verified"] is True


def test_an_unknown_tenant_fails_loudly_rather_than_reporting_success():
    """The quiet failure a nightly job is most likely to have.

    A misspelled tenant name in a cron entry would otherwise see zero decisions
    under row-level security, find zero mismatches, and exit 0 — reporting for
    months that a history nobody is checking is fine.

    It does not, and the reason is worth knowing: every tenant has a row in
    `chain_anchors` written when it is provisioned, so a name that matches none
    of them fails at the chain check rather than sweeping an empty set. A real
    tenant with no decisions yet is a different case and correctly passes.
    """
    done = _run("no-such-tenant")
    assert done.returncode == 2, done.stdout
    output = done.stdout + done.stderr
    assert "no-such-tenant" in output
    assert "could not run" in output


@pytest.mark.parametrize("flag", ["--json", ""])
def test_the_exit_code_is_the_alert_in_every_output_mode(flag):
    """Because the pipeline that reads JSON and the human who reads prose are
    watching the same thing, and it must not depend on which one is looking."""
    args = [DEMO_TENANT] + ([flag] if flag else [])
    assert _run(*args).returncode == 0
