"""The language a pack is written in: its semantics, its versions, its refusals.

Three claims are under test here, and they are the three a diligence team asks
about when they hear "we wrote our own rules engine".

**Missing data refers; it does not pass and it does not crash.** The execution
document words this one precisely — an absent snapshot field produces REFER with
`DATA_MISSING` and the field named — and every part of that sentence is load
bearing. Passing would let a determination be made on a fact nobody has.
Blocking would treat an absent fact as evidence against the client. Crashing
would take the endpoint down in front of whoever was using it. Naming the field
is what makes the refusal something an officer can act on rather than escalate.

**A pack keeps the semantics it was written against, forever.** `dsl_version` is
not the pack's content version; it is which language the rules are in. AU v1 is
still a version-1 pack and still gets version-1 behaviour, which is the whole of
invariant 5 applied to the engine rather than to the data.

**A pack that would not evaluate is refused when it is loaded**, in sentences
naming the rule, the fault and the fix — because the person who wrote it is a
compliance specialist and the alternative is a stack trace during a
determination.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

from app.engine import (
    DATA_MISSING,
    DSL_VERSIONS,
    REFER,
    Pack,
    PackError,
    PackInvalid,
    calcs,
    check,
    evaluate_snapshot,
    failing_reasons,
    validate,
)
from app.engine.dsl import MissingField

PACKS = Path(__file__).resolve().parents[2] / "packs"


def _body(name: str) -> dict:
    return json.loads((PACKS / f"{name}.json").read_text())


def _pack(name: str) -> Pack:
    return Pack.from_body(_body(name))


#: A complete snapshot, from which tests remove one field at a time. Written out
#: rather than built through `build_snapshot`, because the point is to control
#: exactly which fields are absent — and a builder that always produces every
#: field cannot express the thing under test.
COMPLETE = {
    "as_of": "2026-01-01",
    "licensee": {"jurisdiction": "AU"},
    "client": {
        "id": "test-client",
        "name": "Test Client",
        "scenario": "meridian",
        "residency": "AU",
        "domicile": "AU",
        "age_years": 41,
        "client_category": "retail",
        "knowledge_assessed": True,
        "knowledge_assessed_days_ago": 30,
        "loss_capacity_band": 4,
        "vulnerability_flag": False,
        "assessable_portfolio_cents": 20_000_000,
        "prior_crypto_purchases": 3,
        "structural_acks": [],
    },
    "asset": {
        "id": "BTC",
        "symbol": "BTC",
        "name": "Bitcoin",
        "class": "major",
        "volatility_band": 2,
        "leverage": False,
        "structural_flags": [],
    },
    "jurisdictions": {},
    "trade": {"amount_cents": 500_000},
    "calc": {
        "existing_crypto_cents": 0,
        "post_trade_crypto_cents": 500_000,
        "post_trade_crypto_bps": 250,
        "trade_share_bps": 250,
    },
}


def _without(path: str) -> dict:
    snapshot = copy.deepcopy(COMPLETE)
    section, _, field = path.partition(".")
    del snapshot[section][field]
    return snapshot


# ------------------------------------------------------------- missing data --


def test_a_complete_snapshot_is_the_control():
    """Everything below removes a field from this. If it did not pass cleanly,
    the tests that follow would be measuring the wrong thing."""
    result = evaluate_snapshot(_pack("au_v2"), COMPLETE)
    assert result["outcome"] == "ALLOW"
    assert not [r for r in result["rule_results"] if r["reason_code"] == DATA_MISSING]


@pytest.mark.parametrize(
    "path",
    ["client.loss_capacity_band", "client.age_years", "client.prior_crypto_purchases"],
)
def test_a_missing_field_refers_and_names_itself(path):
    """The rule the execution document states, on every field a rule reads."""
    result = evaluate_snapshot(_pack("au_v2"), _without(path))

    referred = [r for r in result["rule_results"] if r["reason_code"] == DATA_MISSING]
    assert referred, f"removing {path} produced no DATA_MISSING result"
    assert result["outcome"] == REFER

    named = {read["ref"] for r in referred for read in r["inputs_read"]}
    assert path in named, f"the refusal does not name {path}: {named}"


def test_a_missing_field_never_passes_and_never_blocks():
    """The two wrong answers, ruled out explicitly.

    ALLOW would mean deciding on a fact nobody holds. BLOCK would mean treating
    an absent fact as evidence against the client — and the rule that would have
    blocked does not get to, which is why `on_fail` is ignored on this path.
    """
    blocking = [r for r in _pack("au_v2").rules if r["on_fail"] == "BLOCK"]
    assert blocking, "au_v2 has no blocking rule, so this proves nothing"

    result = evaluate_snapshot(_pack("au_v2"), _without("client.loss_capacity_band"))
    for row in result["rule_results"]:
        if row["reason_code"] == DATA_MISSING:
            assert row["outcome"] == REFER
            assert row["passed"] is False


def test_a_field_that_is_present_and_null_is_not_missing():
    """The distinction the whole rule turns on.

    `knowledge_assessed_days_ago` is null for somebody never assessed. That is a
    fact the snapshot is recording, not a hole in it — and a system that referred
    every never-assessed client for "missing data" would be refusing to answer
    the question it was built to answer.
    """
    snapshot = copy.deepcopy(COMPLETE)
    snapshot["client"]["knowledge_assessed"] = False
    snapshot["client"]["knowledge_assessed_days_ago"] = None

    result = evaluate_snapshot(_pack("au_v2"), snapshot)
    assert not [r for r in result["rule_results"] if r["reason_code"] == DATA_MISSING]
    # It still refuses — for the real reason, named as such.
    assert result["outcome"] in ("REFER", "BLOCK")
    codes = {r["reason_code"] for r in result["rule_results"] if not r["passed"]}
    assert "KNOWLEDGE_NOT_ASSESSED" in codes


def test_a_missing_field_in_an_applicability_condition_also_refers():
    """The subtler half, and the one a naive implementation gets wrong.

    If `applies_to.when` cannot be evaluated, the honest answer is "we cannot
    tell whether this rule applies" — and skipping the rule would turn that into
    a silent pass, which is exactly the failure the whole rule exists to stop.
    """
    body = _body("au_v2")
    body["rules"] = [
        {
            "rule_id": "TEST-SCOPED",
            "title": "Only for people we know the band of",
            "applies_to": {
                "when": {
                    "op": "gte",
                    "left": {"field": "client.loss_capacity_band"},
                    "right": {"const": 1},
                }
            },
            "predicate": {"op": "eq", "left": {"const": 1}, "right": {"const": 1}},
            "on_fail": "BLOCK",
            "severity": "high",
            "reason_code": "CONC_EXCEEDED",
        }
    ]
    result = evaluate_snapshot(Pack.from_body(body), _without("client.loss_capacity_band"))

    assert result["outcome"] == REFER
    assert result["rules_not_applicable"] == [], "the rule was silently skipped"
    assert result["rule_results"][0]["reason_code"] == DATA_MISSING


def test_the_refusal_carries_plain_english_the_pack_did_not_have_to_write():
    """`DATA_MISSING` is the language's code, not a regime's, so the engine
    supplies its wording. A blank reason card is a refusal nobody can act on."""
    result = evaluate_snapshot(_pack("au_v2"), _without("client.loss_capacity_band"))
    reasons = failing_reasons(result, _pack("au_v2"))

    missing = [r for r in reasons if r["reason_code"] == DATA_MISSING]
    assert missing
    assert missing[0]["reason_title"]
    assert len(missing[0]["reason_plain_english"]) > 60


def test_a_pack_may_word_the_missing_data_reason_itself():
    """It is the engine's code but the regime's voice, if the regime wants one."""
    body = _body("au_v2")
    body["reason_codes"][DATA_MISSING] = {
        "title": "Renseignements manquants",
        "plain_english": "Le dossier du client ne contient pas cette information.",
    }
    pack = Pack.from_body(body)
    reasons = failing_reasons(
        evaluate_snapshot(pack, _without("client.loss_capacity_band")), pack
    )
    assert [r for r in reasons if r["reason_title"] == "Renseignements manquants"]


# ----------------------------------------------------------- the DSL version --


def test_the_shipped_packs_declare_versions_this_engine_implements():
    for path in sorted(PACKS.glob("*.json")):
        body = json.loads(path.read_text())
        assert body["dsl_version"] in DSL_VERSIONS, path.name


def test_a_version_one_pack_still_gets_version_one_behaviour():
    """The claim invariant 5 makes about the engine rather than about the data.

    AU v1 is historical content, written before the missing-data rule existed.
    It keeps the semantics it was authored against — including the behaviour
    Stage 3 considered a defect — because a determination recorded under those
    semantics has to reproduce under them, and "we fixed it later" is not a
    reproduction. This is not a hypothetical: `packs/au_v1.json` really is a
    version-1 pack and the seed really loads it.
    """
    v1 = _pack("au_v1")
    assert v1.dsl_version == 1

    with pytest.raises(MissingField) as raised:
        evaluate_snapshot(v1, _without("client.loss_capacity_band"))
    assert raised.value.path == "client.loss_capacity_band"


def test_the_two_versions_agree_on_every_snapshot_that_is_complete():
    """Versioning must not fork the answers, only the edge case it was added for.

    If v1 and v2 disagreed on complete data, every replay of a v1 decision under
    a v2 engine would be suspect. They differ on absent fields and nowhere else.
    """
    body = _body("au_v2")
    as_v1 = Pack.from_body({**body, "dsl_version": 1})
    as_v2 = Pack.from_body({**body, "dsl_version": 2})
    assert evaluate_snapshot(as_v1, COMPLETE) == evaluate_snapshot(as_v2, COMPLETE)


def test_a_pack_that_does_not_say_is_read_as_version_one():
    """Never as the newest. Every pack authored before the field existed was
    written against v1, and defaulting forward would silently re-interpret
    them."""
    body = _body("au_v2")
    del body["dsl_version"]
    assert Pack.from_body(body).dsl_version == 1


def test_an_unknown_dsl_version_is_refused_when_the_pack_is_loaded():
    """And the message says which way round the mismatch is.

    A pack declaring a version this engine has never heard of means the content
    is newer than the code — almost always a deployment running behind. Saying
    so stops somebody editing the pack downwards to make the error go away.
    """
    with pytest.raises(PackError) as raised:
        Pack.from_body({**_body("au_v2"), "dsl_version": 99})
    message = str(raised.value)
    assert "99" in message
    assert "upgrade the engine" in message


# -------------------------------------------------------------- the registry --


def test_every_calc_a_shipped_pack_names_is_registered():
    for path in sorted(PACKS.glob("*.json")):
        pack = Pack.from_body(json.loads(path.read_text()))
        assert validate(pack) == [], f"{path.name} does not validate"


def test_a_snapshot_carries_every_registered_calc_not_only_the_ones_in_use():
    """Because a snapshot is re-evaluated against other regimes' packs.

    Cross-border resolution runs one frozen snapshot through several packs, and a
    snapshot holding only the calcs the governing pack happened to name would
    fail the moment another regime asked for a different one.
    """
    assert set(COMPLETE["calc"]) == set(calcs.names())


def test_each_calc_documents_what_it_reads_and_what_unit_it_is_in():
    """The fields `docs/dsl-spec.md` is written from. A calc with no description
    is a number a specialist cannot check against a regulation."""
    for name, calc in calcs.registered().items():
        assert calc.unit, name
        assert calc.reads, name
        assert len(calc.description) > 40, name


def test_a_zero_portfolio_does_not_divide_by_zero():
    """Somebody with no assessable portfolio who buys anything has put all of it
    in. Buying nothing with nothing is zero, not undefined."""
    computed = calcs.compute_all(existing_cents=0, amount_cents=1, portfolio_cents=0)
    assert computed["post_trade_crypto_bps"] == calcs.BPS
    assert computed["trade_share_bps"] == calcs.BPS

    empty = calcs.compute_all(existing_cents=0, amount_cents=0, portfolio_cents=0)
    assert empty["post_trade_crypto_bps"] == 0


def test_every_calc_returns_a_whole_number():
    """Invariant 3, at the only place in the engine that divides."""
    computed = calcs.compute_all(
        existing_cents=333_333, amount_cents=777_777, portfolio_cents=1_000_003
    )
    for name, value in computed.items():
        assert isinstance(value, int), f"{name} produced {value!r}"
        assert not isinstance(value, bool), name


# ------------------------------------------------------------- pack validation --


def _faults_for(mutate) -> list[str]:
    body = _body("au_v2")
    mutate(body)
    return validate(Pack.from_body(body))


def test_a_pack_naming_a_calc_that_does_not_exist_is_refused_with_a_suggestion():
    def rename(body):
        body["rules"][0]["predicate"] = {
            "op": "lte",
            "left": {"calc": "post_trade_crypto_pct"},
            "right": {"const": 100},
        }

    faults = _faults_for(rename)
    assert len(faults) == 1
    assert "post_trade_crypto_pct" in faults[0]
    assert "post_trade_crypto_cents" in faults[0], "no suggestion offered"


def test_a_pack_naming_a_threshold_it_does_not_define_is_refused():
    def typo(body):
        body["rules"][0]["predicate"] = {
            "op": "lte",
            "left": {"const": 1},
            "right": {"threshold": "max_crypto_concetration_bps"},
        }

    faults = _faults_for(typo)
    assert any("max_crypto_concentration_bps" in f for f in faults)


def test_a_pack_using_an_operator_that_does_not_exist_is_refused():
    def bad_op(body):
        body["rules"][0]["predicate"] = {
            "op": "greaterthan",
            "left": {"const": 1},
            "right": {"const": 2},
        }

    assert any("greaterthan" in f and "not an operator" in f for f in _faults_for(bad_op))


def test_a_float_constant_is_refused_by_the_validator_not_only_at_evaluation():
    """Invariant 3 caught while authoring rather than mid-determination."""

    def floaty(body):
        body["rules"][0]["predicate"] = {
            "op": "lte",
            "left": {"const": 1},
            "right": {"const": 18.5},
        }

    assert any("18.5" in f and "cents" in f for f in _faults_for(floaty))


def test_every_fault_in_one_line_is_reported_at_once():
    """A specialist who fixes the operator and is then told about the field name
    on the next run has been made to do two passes over one line."""

    def three_faults(body):
        body["rules"][0]["predicate"] = {
            "op": "greaterthan",
            "left": {"field": "clint.age_years"},
            "right": {"const": 18.5},
        }

    faults = _faults_for(three_faults)
    assert len(faults) == 3, faults
    assert any("clint" in f and "client" in f for f in faults)


def test_a_rule_may_not_claim_the_reserved_missing_data_code():
    def steal(body):
        body["rules"][0]["reason_code"] = DATA_MISSING

    assert any("reserved" in f for f in _faults_for(steal))


def test_a_rule_that_allows_on_failure_is_refused():
    """`on_fail: ALLOW` is a rule that cannot refuse anything, which is a rule
    somebody wrote by mistake rather than one they meant."""

    def toothless(body):
        body["rules"][0]["on_fail"] = "ALLOW"

    assert any("on_fail" in f for f in _faults_for(toothless))


def test_two_rules_sharing_an_id_are_refused():
    """Results are keyed by rule id, so the second would be invisible in the
    evidence — a rule that ran and left no trace."""

    def collide(body):
        body["rules"].append(copy.deepcopy(body["rules"][0]))

    assert any("share this id" in f for f in _faults_for(collide))


def test_a_rule_whose_reason_code_the_pack_does_not_define_is_refused():
    def orphan(body):
        body["rules"][0]["reason_code"] = "NO_SUCH_CODE"

    assert any("NO_SUCH_CODE" in f and "does not define" in f for f in _faults_for(orphan))


def test_check_raises_and_lists_every_fault():
    body = _body("au_v2")
    body["rules"][0]["reason_code"] = "NOPE"
    body["rules"][1]["on_fail"] = "MAYBE"

    with pytest.raises(PackInvalid) as raised:
        check(Pack.from_body(body))
    assert len(raised.value.faults) == 2
    assert "2 problem(s)" in str(raised.value)


def test_the_shipped_packs_all_pass_check():
    """The assertion that keeps every test above from being theoretical."""
    for path in sorted(PACKS.glob("*.json")):
        check(Pack.from_body(json.loads(path.read_text())))


def test_a_lookup_table_that_does_not_cover_every_asset_class_is_refused():
    """The fault no name-checking would catch.

    Every name resolves and the pack loads. It fails only when somebody trades
    the one asset whose class is missing from the table — as a crash, mid
    determination. Adding a class and forgetting one of the tables is exactly how
    it happens, so the check runs from the classes rather than from the tables.
    """

    def new_class(body):
        body["asset_classes"]["NEWCOIN"] = {
            "class": "memecoin",
            "volatility_band": 5,
            "leverage": False,
            "structural_flags": [],
        }

    faults = _faults_for(new_class)
    assert any("memecoin" in f and "no entry" in f for f in faults), faults


def test_the_declared_snapshot_fields_match_what_the_builder_produces():
    """`SNAPSHOT_FIELDS` is a declaration, and this is what stops it lying.

    The validator has to answer "does this field exist" with no snapshot in
    front of it — a pack is checked when it is loaded, before any client has
    been looked at. So the list is written by hand, and a hand-written list of
    what another function produces is a list that drifts. This compares it
    against a snapshot `build_snapshot` actually built.
    """
    from datetime import date

    from app.engine import build_snapshot
    from app.engine.validate import SNAPSHOT_FIELDS, UNENUMERABLE_SECTION

    built = build_snapshot(
        pack=_pack("au_v2"),
        client={
            "id": "c",
            "name": "C",
            "scenario": "meridian",
            "residency": "AU",
            "domicile": "AU",
            "dob": date(1985, 6, 1),
            "client_category": "retail",
            "knowledge_assessed": True,
            "knowledge_date": date(2026, 1, 1),
            "loss_capacity_band": 3,
            "vulnerability_flag": False,
            "assessable_portfolio_cents": 1_000_000,
            "prior_crypto_purchases": 2,
            "structural_acks": [],
        },
        positions={"crypto_value_cents": 0},
        asset={"id": "BTC", "symbol": "BTC", "name": "Bitcoin"},
        amount_cents=1000,
        as_of=date(2026, 6, 1),
        licensee_jurisdiction="AU",
    )

    actual = set()
    for section, value in built.items():
        if section == UNENUMERABLE_SECTION:
            continue
        if section == "calc":
            continue  # named through {"calc": ...}, not as field paths
        if isinstance(value, dict):
            actual.update(f"{section}.{field}" for field in value)
        else:
            actual.add(section)

    declared = set(SNAPSHOT_FIELDS)
    assert declared == actual, (
        "SNAPSHOT_FIELDS has drifted from build_snapshot.\n"
        f"  declared but not built: {sorted(declared - actual)}\n"
        f"  built but not declared: {sorted(actual - declared)}"
    )

    # And the same for what each one *holds*, added with Q-07. A declared type
    # that has drifted is worse than an absent one: the validator would refuse
    # a correct rule, or admit the boolean-against-integer comparison this list
    # exists to catch.
    from app.engine.validate import SNAPSHOT_FIELD_TYPES

    assert set(SNAPSHOT_FIELD_TYPES) == declared, (
        "SNAPSHOT_FIELD_TYPES and SNAPSHOT_FIELDS name different fields.\n"
        f"  typed but not declared: {sorted(set(SNAPSHOT_FIELD_TYPES) - declared)}\n"
        f"  declared but not typed: {sorted(declared - set(SNAPSHOT_FIELD_TYPES))}"
    )

    def kind_of(value):
        # `bool` before `int`, because `isinstance(True, int)` is True — which
        # is the whole reason Q-07 was possible.
        for name, python_type in (
            ("bool", bool),
            ("int", int),
            ("str", str),
            ("list", list),
        ):
            if isinstance(value, python_type):
                return name
        return None

    wrong = []
    for section, value in built.items():
        if section in (UNENUMERABLE_SECTION, "calc"):
            continue
        entries = value.items() if isinstance(value, dict) else [(None, value)]
        for field, held in entries:
            path = f"{section}.{field}" if field else section
            if held is None:
                continue  # nullable; the missing-data rule covers the absence
            actual_kind = kind_of(held)
            if actual_kind and SNAPSHOT_FIELD_TYPES[path] != actual_kind:
                wrong.append((path, SNAPSHOT_FIELD_TYPES[path], actual_kind))
    assert not wrong, f"SNAPSHOT_FIELD_TYPES disagrees with the builder: {wrong}"


def test_a_rule_reading_a_field_that_never_exists_is_refused_when_the_pack_loads():
    """A typo is a pack fault, not missing data.

    Before this check the rule loaded cleanly and referred every determination
    for missing data — which is the right answer for an absent *fact* and the
    wrong one for a misspelled *name*. Found by the fuzzer.
    """

    def typo(body):
        body["rules"][0]["predicate"] = {
            "op": "lte",
            "left": {"field": "client.loss_capacity_bnad"},
            "right": {"const": 5},
        }

    faults = _faults_for(typo)
    assert any("does not contain" in f for f in faults), faults
    assert any("client.loss_capacity_band" in f for f in faults), "no suggestion offered"


def test_a_cross_border_rule_may_read_a_jurisdiction_that_cannot_be_enumerated():
    """`jurisdictions.HK.asset.class` is keyed by pack id, so which paths exist
    depends on the client rather than on the pack. The validator must not refuse
    what it cannot list."""

    def cross_border(body):
        body["rules"][0]["predicate"] = {
            "op": "eq",
            "left": {"field": "jurisdictions.HK.asset.class"},
            "right": {"const": "major"},
        }

    assert _faults_for(cross_border) == []


# --------------------------------------------------------------- provenance --


def _prov(**overrides) -> dict:
    base = {
        "source_document": "ASIC RG 227",
        "section": "s4.2",
        "verified_by": "A Qualified Specialist",
        "verified_on": "2026-03-14",
    }
    return {**base, **overrides}


def test_a_rule_may_carry_where_its_content_came_from():
    """§S5 asks for this per rule and is specific that it is "recorded as data,
    not comments".

    A note saying "per ASIC RG 227 s4.2" is unsearchable, unverifiable and
    impossible to report on. Four fields are a table a specialist can be handed,
    sorted by verification date, when somebody asks which rules have been
    checked this year.
    """

    def with_provenance(body):
        body["rules"][0]["provenance"] = _prov()

    assert _faults_for(with_provenance) == []


def test_a_rule_with_no_provenance_is_still_valid():
    """Absent is legitimate. Illustrative content has no source document, and
    pretending otherwise would be the exact dishonesty `content_status` exists
    to prevent."""
    assert _faults_for(lambda body: None) == []


def test_half_a_provenance_is_refused():
    """It looks like the question was answered. A rule carrying a source
    document and no verifier reads as checked when nobody has checked it."""

    def half(body):
        body["rules"][0]["provenance"] = {
            "source_document": "ASIC RG 227",
            "section": "s4.2",
        }

    faults = _faults_for(half)
    assert any("incomplete" in f for f in faults)
    assert any("verified_by" in f and "verified_on" in f for f in faults)


def test_the_verification_date_is_a_date():
    """So that "which rules have not been verified since the amendment" is a
    query rather than a reading exercise."""
    faults = _faults_for(
        lambda body: body["rules"][0].__setitem__("provenance", _prov(verified_on="March"))
    )
    assert any("not a date" in f for f in faults)


def test_a_field_provenance_does_not_have_is_refused():
    """An invented field is one nothing reads. A specialist who records a
    confidence score believing it is stored has recorded nothing."""
    faults = _faults_for(
        lambda body: body["rules"][0].__setitem__(
            "provenance", {**_prov(), "confidence": 0.9}
        )
    )
    assert any("confidence" in f and "not part of it" in f for f in faults)


def test_provenance_may_carry_a_free_note_beside_the_four_fields():
    """The four are structured because they are queried. A note is prose because
    it is read, and a specialist will always have one more thing to say."""
    assert (
        _faults_for(
            lambda body: body["rules"][0].__setitem__(
                "provenance", {**_prov(), "note": "Read with the 2025 amendment."}
            )
        )
        == []
    )


def test_a_threshold_that_is_a_number_in_quotes_is_refused():
    """A number that lost its type, found by using the workbench.

    Typing a decimal into a threshold field produces a *string*, and the float
    check could not see it — so a pack with `"5.5"` where a number belonged
    validated clean and failed at evaluation instead. That is the moment this
    whole validator exists to move away from.

    `"500"` matters as much as `"5.5"`: a quoted number compares as text, so a
    rule reading it either fails or, worse, compares wrongly.
    """
    for value in ("5.5", "500", " 42 ", "-3"):
        faults = _faults_for(
            lambda body, v=value: body["thresholds"].__setitem__(
                "max_crypto_concentration_bps", v
            )
        )
        assert any("rather than a number" in f for f in faults), value


def test_a_threshold_that_is_genuinely_text_is_left_alone():
    """A category name or a code is a legitimate threshold value. The check asks
    "did somebody mean a number here", and text that does not parse as one
    means no."""
    assert (
        _faults_for(
            lambda body: body["thresholds"].__setitem__("some_category", "retail")
        )
        == []
    )
