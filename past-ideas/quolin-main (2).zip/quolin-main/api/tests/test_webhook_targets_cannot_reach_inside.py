"""A webhook is a URL a customer chooses and this system fetches on their behalf.

Report C's claim was that a low-privilege tenant can register a webhook pointing
at `169.254.169.254` and read the instance metadata service. Half of that is
**NOT PRESENT**: there is no registration endpoint. Webhook endpoints are rows
created by the seed, by tests and by the game-day drill, and no route in `/v1`
or anywhere else lets a customer add one.

The other half is real and worth closing before the route exists. `http_sender`
posts to whatever string is in the row, and the day somebody adds a registration
screen — which is an obvious next feature — the check has to already be in the
place that does the fetching. A validator on a form is a validator somebody
routes around; a validator at dispatch is one the request cannot avoid.

**Resolved, not pattern-matched.** `http://metadata.example.com/` that resolves
to `169.254.169.254` is the same attack as writing the address down, and a
string check does not see it. So the hostname is resolved and every address it
answers with has to be a public one.

**Redirects are not followed.** A target that answers 302 to
`http://169.254.169.254/` would otherwise walk straight past a check made on the
URL we were given.

**Private targets are allowed only where they are the point.** `make
webhook-receiver` runs a listener on localhost so a customer's engineer has a
working example of the signature check, and the demo posts to it. That is
switched on explicitly with `QUOLIN_WEBHOOK_ALLOW_PRIVATE`, not inferred, so a
deployed instance cannot acquire the exception by accident.
"""

from __future__ import annotations

import pytest

from app import webhooks

#: The address every cloud provider serves instance credentials from. Named
#: because it is the specific thing the claim was about; it is refused as a
#: link-local address rather than by being on a list.
METADATA = "http://169.254.169.254/latest/meta-data/iam/security-credentials/"

REFUSED = (
    METADATA,
    "http://127.0.0.1:8000/internal",
    "http://localhost/admin",
    "http://[::1]/admin",
    "http://10.0.0.5/private",
    "http://192.168.1.1/router",
    "http://172.16.0.1/private",
    "http://0.0.0.0/",
    # A scheme that is not HTTP at all. `file:///etc/passwd` is the other half
    # of the same class of bug.
    "file:///etc/passwd",
    "gopher://127.0.0.1:11211/",
    "ftp://internal.example/",
    # Nothing to resolve.
    "https:///no-host",
    "",
)


@pytest.fixture(autouse=True)
def deny_private(monkeypatch):
    """The deployed posture. Local dev opts out; a test must not inherit that."""
    monkeypatch.delenv("QUOLIN_WEBHOOK_ALLOW_PRIVATE", raising=False)


@pytest.mark.parametrize("url", REFUSED)
def test_a_target_that_reaches_inside_is_refused(url) -> None:
    with pytest.raises(webhooks.UnsafeTarget):
        webhooks.validate_target(url)


@pytest.fixture
def resolves_publicly(monkeypatch):
    """A hostname that answers with an ordinary public address.

    Stubbed rather than resolved for real: a suite that reached DNS would fail
    on an aeroplane and pass on a network with a wildcard resolver, and neither
    tells anybody anything about this check.
    """
    import socket as socket_module

    def answer(host, port, *args, **kwargs):
        # A genuinely globally-routable address. The documentation ranges
        # (192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24) are *not* `is_global`
        # in Python's `ipaddress`, and are correctly refused by the check — so
        # using one here would have tested the refusal, not the acceptance.
        return [
            (
                socket_module.AF_INET,
                socket_module.SOCK_STREAM,
                6,
                "",
                ("93.184.216.34", port or 443),
            )
        ]

    monkeypatch.setattr(webhooks.socket, "getaddrinfo", answer)


def test_an_ordinary_customer_endpoint_is_accepted(resolves_publicly) -> None:
    """The check must refuse the attack and not the product."""
    webhooks.validate_target("https://case-system.example.com/quolin")


def test_a_hostname_that_resolves_inside_is_refused(monkeypatch) -> None:
    """The half a string check cannot see.

    `webhooks.internal.example` is a perfectly ordinary-looking name that
    answers with a link-local address. Pattern-matching the URL admits it; this
    resolves the name and refuses what it finds.
    """
    import socket

    def resolves_to_metadata(host, *args, **kwargs):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("169.254.169.254", 80))]

    monkeypatch.setattr(webhooks.socket, "getaddrinfo", resolves_to_metadata)
    with pytest.raises(webhooks.UnsafeTarget) as refused:
        webhooks.validate_target("https://perfectly-normal.example.com/hook")
    assert "169.254.169.254" in str(refused.value)


def test_a_name_that_does_not_resolve_is_refused(monkeypatch) -> None:
    """Unresolvable is a refusal, not a pass.

    A name nothing can resolve is either a typo or a target waiting to be given
    an address later. Neither is a reason to attempt the request.
    """
    import socket

    def fails(host, *args, **kwargs):
        raise socket.gaierror("no such host")

    monkeypatch.setattr(webhooks.socket, "getaddrinfo", fails)
    with pytest.raises(webhooks.UnsafeTarget):
        webhooks.validate_target("https://nothing-here.example.com/hook")


def test_the_sender_checks_before_it_posts(monkeypatch) -> None:
    """At dispatch, not only at whatever validates a form.

    There is no registration route today. When one is added, this is the check
    it cannot be written around — and it is the only place a redirect or a
    changed DNS answer can be caught, because both happen after registration.
    """
    posted = []

    def should_not_be_called(*args, **kwargs):
        posted.append(args)
        raise AssertionError("the request was sent")

    monkeypatch.setattr(webhooks.httpx, "post", should_not_be_called)
    send = webhooks.http_sender()

    with pytest.raises(webhooks.UnsafeTarget):
        send(METADATA, "{}", {})
    assert not posted


def test_the_sender_does_not_follow_redirects(monkeypatch, resolves_publicly) -> None:
    """A 302 to the metadata service would walk past a check on the URL we were
    given."""
    seen = {}

    def capture(url, **kwargs):
        seen.update(kwargs)

        class Answer:
            status_code = 200

        return Answer()

    monkeypatch.setattr(webhooks.httpx, "post", capture)
    webhooks.http_sender()("https://case-system.example.com/hook", "{}", {})
    assert seen.get("follow_redirects") is False, (
        "the sender follows redirects, so a target can send it anywhere"
    )


def test_local_development_can_opt_in(monkeypatch) -> None:
    """`make webhook-receiver` is a listener on localhost, and is the point.

    Explicit rather than inferred from the environment name: a deployed instance
    must not be able to acquire the exception by having its `QUOLIN_ENVIRONMENT`
    set to something unexpected.
    """
    monkeypatch.setenv("QUOLIN_WEBHOOK_ALLOW_PRIVATE", "1")
    webhooks.validate_target("http://127.0.0.1:4010/hook")

    # And even then, not a scheme that is not HTTP.
    with pytest.raises(webhooks.UnsafeTarget):
        webhooks.validate_target("file:///etc/passwd")


def test_a_delivery_to_an_unsafe_target_dead_letters_rather_than_crashing() -> None:
    """The refusal arrives as a failed delivery, not as an exception out of the
    worker.

    `scripts/deliver_webhooks.py` works a queue. One poisoned row must not stop
    the rest of it — which is why `UnsafeTarget` is a plain `ValueError` and
    `attempt` already treats anything the sender raises as a failure.
    """
    from app import tenancy
    from app.db import SessionLocal
    from app.models import WebhookEndpoint
    from tests.conftest import DEMO_TENANT

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
        session = SessionLocal()
        try:
            endpoint = WebhookEndpoint(
                id="wh_ssrf_probe",
                url=METADATA,
                secret=webhooks.new_secret(),
                events=["decision.recorded"],
                status="active",
            )
            session.add(endpoint)
            session.flush()

            queued = webhooks.enqueue(
                session,
                event="decision.recorded",
                subject="probe",
                payload={"probe": True},
            )
            mine = [d for d in queued if d.endpoint_id == endpoint.id]
            assert mine, "the probe endpoint was not subscribed to the event"

            webhooks.attempt(
                session, mine[0], endpoint, send=webhooks.http_sender()
            )

            assert mine[0].status != "delivered", mine[0].status
            assert mine[0].last_error, "nothing was recorded about the refusal"
            assert "169.254.169.254" in mine[0].last_error, mine[0].last_error
        finally:
            session.rollback()
            session.close()
