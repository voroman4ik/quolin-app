"""The demo still runs on fixtures, and still says so.

S4's fourth gate item is one sentence: *demo tenant still runs on fixtures, still
labelled in `/integrations`.* It is the only gate item in the stage that is about
something **not** changing, and that is exactly why it needs a test.

The pressure this stage puts on it is real. S4 replaces mocked edges with
implementations, and the natural next step — pointing the demo at them, so the
demo shows the new thing — is the one that must not happen. The demo is the sales
asset. Its cast is invented, its positions are a fixture, and a demo quietly
running against a real custody adapter would be a demo showing a prospect
somebody's actual portfolio.

The failure mode this protects against is not dishonesty. It is somebody making
the demo *better* by connecting it to the working code that now exists, and the
label going stale into a lie one commit later.
"""

from __future__ import annotations

from conftest import DEMO_TENANT

from app import integrations, tenancy
from app.providers import FixturePositionsProvider


def test_the_demo_tenant_still_reads_positions_from_a_fixture(session):
    """Custody is the one that matters most.

    A client's positions are the input to the concentration rule, so a demo
    reading real custody would be a demo making determinations about somebody's
    actual holdings in front of a room.
    """
    with tenancy.acting_as(DEMO_TENANT):
        edges = {e["name"]: e for e in integrations.describe(session)}

    custody = next(e for name, e in edges.items() if "custod" in name.lower())
    assert custody["status"] == "fixture", (
        "the demo tenant is no longer reading positions from a fixture — see the "
        "note at the top of this file before changing this test"
    )

    # And the provider really is the fixture one, not merely labelled as such.
    provider = FixturePositionsProvider()
    assert provider.covered_ids(), "the fixture is empty, so the label proves nothing"


def test_every_edge_reports_one_of_the_three_statuses(session):
    """A badge nobody recognises is a badge nobody reads."""
    with tenancy.acting_as(DEMO_TENANT):
        edges = integrations.describe(session)

    assert edges
    for edge in edges:
        assert edge["status"] in integrations.STATUSES, edge
        assert edge["name"]
        # Every edge says what it would be in production. An edge that is mocked
        # and does not say what it stands in for is a gap with no shape.
        assert edge.get("note") or edge.get("detail") or edge.get("production"), edge


def test_the_screen_still_says_how_much_is_mocked(session):
    """The number a prospect is shown, computed rather than asserted.

    `/integrations` exists because a prototype that mocks an edge and does not
    say so reads exactly like one that has integrated it. A hardcoded count could
    go stale into a lie; this one cannot.
    """
    with tenancy.acting_as(DEMO_TENANT):
        summary = integrations.summary(session)

    assert summary["mocked"] >= 1, (
        "nothing is reported as mocked. Either every edge is genuinely live — in "
        "which case update this test deliberately — or the screen has stopped "
        "telling the truth."
    )


def test_the_summary_totals_match_the_edges_it_summarises(session):
    with tenancy.acting_as(DEMO_TENANT):
        edges = integrations.describe(session)
        summary = integrations.summary(session)

    assert summary["live"] == sum(1 for e in edges if e["status"] == "live")
    assert summary["mocked"] == sum(1 for e in edges if e["status"] != "live")


def test_stage_four_did_not_quietly_relabel_a_fixture_as_live(session):
    """The specific regression this stage could introduce.

    Building a working batch gateway and a working webhook sender makes it
    tempting to mark the corresponding edges live. They are live *as
    capabilities* and the demo does not use them, which is a different sentence —
    and `/integrations` describes what this deployment does, not what the product
    can do.
    """
    with tenancy.acting_as(DEMO_TENANT):
        edges = {e["name"]: e["status"] for e in integrations.describe(session)}

    mocked = [name for name, status in edges.items() if status != "live"]
    assert mocked, f"every edge now claims to be live: {edges}"
