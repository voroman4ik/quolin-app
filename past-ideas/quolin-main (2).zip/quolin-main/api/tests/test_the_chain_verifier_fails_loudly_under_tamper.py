"""The verifier must not go quiet at the moment its subject is tampering.

The Gate A audit's fifth finding, and in a product whose thesis is
tamper-evidence it is the worst available failure mode: not a false negative,
but a check that stops answering.

**The attack is the one the chain exists for.** `decisions` is append-only and
`quolin_app` holds `INSERT` and `SELECT` — deliberately, because a hash chain
makes an *appended* forgery visible rather than impossible. So an attacker with
a shell writes a row. Its `snapshot` column is `EncryptedJSON`, and whatever
bytes they put there are not ciphertext this tenant's key can open.

**And the verifier raised before it compared anything.** SQLAlchemy decrypts
while *materialising* the row, so `ValueError` came out of the column type
before `verify_chain` had a hash to check. Where it then went was different in
each caller and wrong in all of them:

* `alerts.check` has a blanket handler, so the page read *"the chain_integrity
  check could not run"* with the action *"fix the check before trusting the
  absence of the alerts it produces"*. Right severity, right exit code, and an
  instruction sending somebody to look at monitoring code while their evidence
  was being altered. Worse than a wrong severity, because it is actionable and
  the action is wrong.
* `scripts/nightly_replay.py` had no wrapper at all — and not only around
  `verify_chain`: `list(session.scalars(select(Decision)))` materialises every
  row before the per-decision handler, so one forged row ended a run that had
  four thousand determinations left to check.

`verify_chain` returns a graded verdict for every row-level problem now, with a
reason code naming the decision and the tenant — the treatment `replay` already
had, where a pack that will not load is `PACK_INVALID_AT_REPLAY` rather than an
exception.

**Nothing is committed into the demo firm**, and the one test that needs a
committed row uses a firm of its own. The first version of this file did commit
into `demo` and delete afterwards, and that spliced the demo chain for real —
found by `test_three_tap.py`, and it would have happened in CI. `TAMPER_PROBE`
below writes the sequence out; the short version is that a determination
recorded while the forgery is present chains onto it, and `decisions` is
append-only, so deleting the forgery leaves a break with no repair.
"""

from __future__ import annotations

import importlib
import json

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import select, text

from app import alerts, evidence, tenancy
from app.db import SessionLocal
from app.models import Decision

#: Bytes that are not ciphertext under anybody's key. Long enough to be past the
#: nonce and short enough to read in a failure message.
FORGERY = b"this row was not written by the application"


def _append_a_forged_row(session, *, tenant_id: str = DEMO_TENANT) -> int:
    """One extra decision, appended as the application role. Returns its id.

    Copied from a real row so that every NOT NULL column and every foreign key
    is satisfied — the point is a row that the database accepts and the verifier
    cannot read, not one the database refuses. The template is always read from
    the demo firm, because it is the only one with clients and assets; the row
    is written into whichever firm the caller names.

    Raw SQL rather than the ORM, because the ORM would encrypt the snapshot on
    the way in, which is the one thing this row must not have happen to it.
    """
    with tenancy.acting_as(DEMO_TENANT):
        template_session = SessionLocal()
        try:
            template = template_session.scalars(
                select(Decision).order_by(Decision.id.desc()).limit(1)
            ).one()
            template_session.expunge(template)
        finally:
            template_session.close()

    row = session.execute(
        text(
            """
            INSERT INTO decisions (
              tenant_id, client_id, asset_id, as_of, pack_id, pack_version,
              snapshot, rule_results, resolution, outcome, prev_hash, this_hash,
              created_at, payload_schema
            ) VALUES (
              :tenant_id, :client_id, :asset_id, :as_of, :pack_id, :pack_version,
              :snapshot, CAST(:rule_results AS jsonb), NULL, :outcome,
              :prev_hash, :this_hash, now(), 1
            )
            RETURNING id
            """
        ),
        {
            "tenant_id": tenant_id,
            "client_id": template.client_id,
            "asset_id": template.asset_id,
            "as_of": template.as_of,
            "pack_id": template.pack_id,
            "pack_version": template.pack_version,
            "snapshot": FORGERY,
            "rule_results": json.dumps({"results": []}),
            "outcome": "ALLOW",
            # A plausible link. The forgery is the snapshot; making the hashes
            # obviously wrong as well would let this pass for the wrong reason.
            "prev_hash": template.this_hash,
            "this_hash": "0" * 64,
        },
    )
    return int(row.scalar_one())


@pytest.fixture
def forged():
    """A session holding one forged row, rolled back afterwards.

    Its own session rather than the shared one: this transaction is discarded,
    and taking the suite's session down with it would leave every later test in
    this module reading a rolled-back identity map.
    """
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            decision_id = _append_a_forged_row(session)
            yield session, decision_id
        finally:
            session.rollback()
            session.close()


# ------------------------------------------------------------- the verifier --


def test_the_application_role_can_append_a_row_it_cannot_read_back(forged):
    """The premise, asserted rather than assumed.

    If `decisions` ever stopped accepting an INSERT from the application role,
    every test below would pass for a reason that has nothing to do with the
    verifier. It has not: `quolin_app` holds INSERT and SELECT and nothing else,
    which is the property working — a chain makes an appended forgery visible
    rather than impossible.
    """
    session, decision_id = forged
    assert decision_id > 0

    stored = session.scalars(
        select(Decision.id).where(Decision.id == decision_id)
    ).one()
    assert stored == decision_id


def test_a_forged_row_is_a_verdict_and_not_an_exception(forged):
    """The finding itself. `verify_chain` answers; it does not raise."""
    session, decision_id = forged

    try:
        result = evidence.verify_chain(session)
    except Exception as exc:  # pragma: no cover - this is the regression
        pytest.fail(
            f"{type(exc).__name__} escaped verify_chain: {exc}. A verifier that "
            "raises under tamper is a verifier that goes quiet at the one moment "
            "it exists for."
        )

    assert result["verified"] is False
    assert result["reason"] == evidence.UNDECRYPTABLE_SNAPSHOT
    assert result["broken_at_decision_id"] == decision_id
    assert result["tenant_id"] == DEMO_TENANT
    # And how far it got, so a reader knows whether the forgery is at the front
    # of the chain or the end of it.
    assert result["checked"] > 0


def test_the_verdict_names_the_decision_and_the_tenant(forged):
    """What a person woken at 3am needs before they can do anything.

    "The chain is broken" is a fact; "the chain is broken at determination
    #4,703 in `demo`, and that row's snapshot will not decrypt" is where to
    look and who to call.
    """
    session, decision_id = forged
    result = evidence.verify_chain(session)

    assert result["broken_at_decision_id"] == decision_id
    assert result["tenant_id"] == DEMO_TENANT
    assert result["detail"], "no detail on an undecryptable row"


def test_a_verifying_chain_carries_no_reason_at_all(session):
    """The healthy path, and it is the whole of what this asserts.

    H3, and the finding is about the name this test used to have. It was called
    `test_an_ordinary_hash_mismatch_still_reads_as_one` and asserted no such
    thing — it checked that a clean chain verifies and carries no reason code,
    which is worth asserting and is not what the name promised. A reviewer
    reading the list of test names would have counted the HASH_MISMATCH ⁄
    UNDECRYPTABLE distinction as covered here; it was covered in
    `test_evidence_chain.py`, and would have gone on reading as covered here if
    that had ever stopped being true.

    A misleading test name is a false confidence signal, and it is worse than a
    missing test because a missing test is visible.

    What this does assert is real: a caller must not be able to read a reason
    off a chain that is fine, because "no reason" and "a reason meaning nothing
    is wrong" are two states and only one of them is safe to branch on.
    """
    result = evidence.verify_chain(session)
    assert result["verified"] is True, "the demo chain does not verify"
    assert "reason" not in result


def test_an_ordinary_hash_mismatch_still_reads_as_one(session):
    """And the distinction the name always claimed, now made here.

    A row that decrypts and does not hash is a different incident from a row
    that will not decrypt: the first asks *what changed*, the second asks *who
    has write access to the database*, because `decisions` grants the
    application INSERT and SELECT and nothing else. `docs/runbooks/
    chain-mismatch.md` branches on exactly this, so conflating the two sends
    whoever is paged to the wrong question.

    Asserted in this file rather than left to `test_evidence_chain.py` because
    this file is the one about the verifier's verdicts under tamper, and a
    reason code is only a distinction if both sides of it are exercised where
    somebody looking for them will find them. The forged row here is the
    *undecryptable* half; this is its sibling.

    Written through the ORM, which encrypts the snapshot on the way in — the
    opposite of `_append_a_forged_row` above, and that opposition is the test:
    the row is a well-formed determination carrying hashes that are not its own.
    """
    DecisionRow = Decision

    with tenancy.acting_as(DEMO_TENANT):
        template = session.scalars(
            select(DecisionRow).order_by(DecisionRow.id.desc()).limit(1)
        ).one()
        forged = DecisionRow(
            tenant_id=template.tenant_id,
            client_id=template.client_id,
            asset_id=template.asset_id,
            as_of=template.as_of,
            pack_id=template.pack_id,
            pack_version=template.pack_version,
            snapshot=template.snapshot,
            rule_results=template.rule_results,
            resolution=template.resolution,
            outcome="ALLOW" if template.outcome != "ALLOW" else "BLOCK",
            prev_hash=template.this_hash,
            this_hash="0" * 64,
            payload_schema=template.payload_schema,
            manifest=template.manifest,
        )
        session.add(forged)
        session.flush()

        try:
            result = evidence.verify_chain(session)
            assert result["verified"] is False
            assert result["broken_at_decision_id"] == forged.id
            assert result["reason"] == evidence.HASH_MISMATCH, (
                "a row that decrypts and does not hash was reported as "
                f"{result.get('reason')!r}. The two reasons ask different first "
                "questions and the runbook branches on which."
            )
            assert result["expected_hash"] != result["stored_hash"]
        finally:
            session.rollback()


# ----------------------------------------------------------------- the alert --


def test_the_alert_names_the_chain_rather_than_the_check(forged):
    """The signal that actually arrives, which is the half that was degraded.

    `alerts.check`'s blanket handler meant a tampered chain produced
    `alerts.check_failed` — "fix the check before trusting the absence of the
    alerts it produces". This asserts the finding is about the chain, names the
    row, and carries the runbook.
    """
    session, decision_id = forged

    findings = alerts.chain_integrity(session)
    assert findings, "a tampered chain produced no finding"

    finding = findings[0]
    assert finding.severity == alerts.CRITICAL
    assert finding.kind == "chain.broken", (
        f"a tampered chain reported {finding.kind!r}. "
        "`alerts.check_failed` is the finding for a check that could not run, "
        "and a chain that does not verify is not that."
    )
    assert str(decision_id) in finding.summary
    assert evidence.UNDECRYPTABLE_SNAPSHOT in finding.summary
    assert "chain-mismatch.md" in finding.action
    assert finding.detail["broken_at_decision_id"] == decision_id
    assert finding.detail["reason"] == evidence.UNDECRYPTABLE_SNAPSHOT


def test_the_full_check_reports_it_as_the_chain_and_not_as_a_blind_spot(forged):
    """Through `alerts.check`, which is what the scheduled job calls."""
    session, _ = forged
    findings = alerts.check(session)

    kinds = {f.kind for f in findings}
    assert "chain.broken" in kinds, kinds
    assert "alerts.check_failed" not in kinds, (
        "the chain check raised and was caught by the blanket handler, which is "
        "the finding: the page said the check could not run rather than that "
        "the evidence does not verify."
    )


def test_a_process_with_no_key_is_a_check_that_could_not_run(session, monkeypatch):
    """The inverse, and it matters as much as the finding.

    A verifier that reported *every* decryption failure as tampering would page
    somebody about a forged record when the answer is an unset environment
    variable. Found by running the new verifier in a shell with no
    `QUOLIN_MASTER_KEY`: it confidently reported that decision 1 had been
    altered.

    So `KeysNotConfigured` and `NoDataKey` are re-raised rather than graded.
    They are not statements about a row, and `alerts.check` reporting them as a
    blind spot is exactly right for what they are.
    """
    from app import crypto

    def no_key():
        raise crypto.KeysNotConfigured("QUOLIN_MASTER_KEY is not set (test)")

    monkeypatch.setattr(crypto, "data_key", no_key)
    crypto.forget_keys()

    with pytest.raises(crypto.KeysNotConfigured):
        evidence.verify_chain(session)

    findings = alerts.chain_integrity(session)
    assert findings
    assert findings[0].kind == "chain.unverifiable", (
        "a missing key was reported as a broken chain. Those are different "
        "incidents and only one of them is somebody's fault."
    )
    assert findings[0].severity == alerts.CRITICAL

    crypto.forget_keys()


# ------------------------------------------------------------- the exit code --


def test_a_tampered_chain_produces_the_page_a_person_code(monkeypatch):
    """The end-to-end contract: exit 2, not exit 1.

    `docs/deployment.md`'s operating table says 2 when anything is wrong and 1
    when the checks could not run, and those are different instructions to
    whatever is watching. The real `Finding` a tampered chain produces is fed
    through the real `main`, so this is the mapping the scheduler sees rather
    than a restatement of it.
    """
    module = importlib.import_module("scripts.health_alerts")

    tampered = alerts.Finding(
        severity=alerts.CRITICAL,
        kind="chain.broken",
        summary="the evidence chain does not verify — determination #4703 cannot be read",
        action="Stop issuing artefacts and follow docs/runbooks/chain-mismatch.md.",
        detail={"reason": evidence.UNDECRYPTABLE_SNAPSHOT},
    )
    monkeypatch.setattr(alerts, "check", lambda session, **kw: [tampered])
    monkeypatch.setattr("sys.argv", ["health_alerts", "--no-page"])

    assert module.main() == 2, (
        "a tampered chain did not produce the exit code that means 'something "
        "is wrong'. Exit 1 means the checks could not run, which sends whoever "
        "is watching to look at the monitor rather than at the evidence."
    )


#: A firm of its own, whose chain is deliberately and permanently broken.
#:
#: **The first version of this test committed the forgery into the demo tenant
#: and deleted it afterwards, and that spliced the demo chain — for real, in the
#: development database, found by `test_three_tap.py`.** The sequence is worth
#: writing down because it is not obvious and it would have happened in CI.
#:
#: The forged row is appended and committed. Its `this_hash` is sixty-four
#: zeros. Any determination recorded while it is present reads it as the tip —
#: `evidence._tip_hash` is `ORDER BY id DESC LIMIT 1` — and writes those zeros
#: as its own `prev_hash`. The cleanup then deletes the forged row, and what is
#: left is a legitimate determination whose `prev_hash` names a row that does
#: not exist. `decisions` is append-only, so **there is no repair**: the demo
#: chain is broken from that point forever, and `make seed` is the only way out.
#:
#: A test that damages the evidence chain to prove the evidence chain works is
#: the wrong trade at any odds. So the forgery goes in a firm nobody else
#: writes to.
#:
#: `status` is deliberately not `active`: `maintenance.active_tenants` filters
#: on it, so a permanently broken chain here is invisible to `health_alerts`,
#: to `make game-day` and to every scheduled job. A probe firm that paged
#: somebody every five minutes forever would be its own finding.
TAMPER_PROBE = "chain-tamper-probe"


def _the_probe_firm() -> str:
    """A closed firm with an anchor, a key, and nothing else. Created once."""
    from app import crypto
    from app import evidence as evidence_mod
    from app.db import OwnerSessionLocal

    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "INSERT INTO tenants (id, name, region, tier, status, stage, "
                "config, created_at) VALUES (:id, 'Chain Tamper Probe', "
                "'ap-southeast-2', 'shared', 'closed', 'pilot', "
                "'{\"jurisdictions\": [\"AU\"]}'::jsonb, now()) "
                "ON CONFLICT (id) DO NOTHING"
            ),
            {"id": TAMPER_PROBE},
        )
        owner.commit()
        with tenancy.acting_as(TAMPER_PROBE):
            crypto.ensure_key(owner, TAMPER_PROBE)
            evidence_mod.ensure_anchor(owner, TAMPER_PROBE)
            owner.commit()
    finally:
        owner.close()
    return TAMPER_PROBE


def test_the_nightly_replay_reports_a_forged_row_rather_than_dying():
    """`scripts/nightly_replay.py` had no wrapper at all.

    Two places, and the second is the one nobody would look for:
    `list(session.scalars(select(Decision)))` materialises every row *before*
    the per-decision handler, so a single forged row ended a run with four
    thousand determinations left to check — and the message was "nightly replay
    could not run", which describes the job rather than the incident.

    Run through the module's own `_check_tenant` against a real, committed row,
    because that is the only way to reach code that opens its own session. See
    `TAMPER_PROBE` for why it is not the demo firm.

    Idempotent by reusing the forgery rather than appending another: the chain
    breaks at the *first* bad row, so a second run of a test that always
    appended would assert against an id that is no longer the one reported.
    """
    module = importlib.import_module("scripts.nightly_replay")
    probe = _the_probe_firm()

    with tenancy.acting_as(probe):
        session = SessionLocal()
        try:
            existing = session.scalars(
                select(Decision.id).order_by(Decision.id).limit(1)
            ).first()
            if existing is None:
                decision_id = _append_a_forged_row(session, tenant_id=probe)
                session.commit()
            else:
                decision_id = int(existing)
        finally:
            session.close()

    report = module._check_tenant(probe, inject=False)

    assert report["chain"]["verified"] is False
    assert report["chain"]["broken_at_decision_id"] == decision_id
    assert report["chain"]["reason"] == evidence.UNDECRYPTABLE_SNAPSHOT

    problems = [
        row for row in report["mismatches"] if row["decision_id"] == decision_id
    ]
    assert problems, (
        "the forged row was not reported as a mismatch. The replay loop either "
        "skipped it or died on it; either way the run is not a statement about "
        "the whole book."
    )
