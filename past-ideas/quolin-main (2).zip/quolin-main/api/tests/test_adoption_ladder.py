"""§S10's gate: a firm walks pilot → shadow → limited → full, with signatures.

    "A synthetic tenant walks pilot → shadow → limited → full with signed
     transitions; the comparison report renders divergences a compliance officer
     can read unaided"

The second half is the one worth being careful about. "Readable unaided" cannot
be asserted by a test — but its opposite can: a report that names a rule id and
no rule, that gives an outcome and no reason, or that quotes a percentage with
no denominator, is one somebody has to ask us about. Those are the assertions
below.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from sqlalchemy import select

from app import adoption, business_time, comparison, service, tenancy
from app.models import Client, Decision, Tenant, TenantStageChange

#: A tenant of this file's own, provisioned by the fixture below.
#:
#: Not `demo`, because moving its stage changes what every other test's
#: determinations are allowed to do. And not one of the tenants other test files
#: create — the first version borrowed `rival`, which exists only after
#: `test_rls.py` has run, so this file passed alone and errored in the suite
#: where it sorts first. A test that needs a tenant makes one.
SYNTHETIC = "adoption-probe"
ACTOR = "apc_bulk_sweep"
SIGNATORY = "Ruth Castellanos"


@pytest.fixture(scope="module")
def _provision():
    """A firm of this file's own, with one client to make determinations about.

    Created as the owner, because `tenants` is writable only by the owner — a
    request that could write that table could change its own id.

    Left behind afterwards. `tenant_stages` is append-only, so a tenant that has
    walked the ladder cannot be deleted without deleting the record of who
    signed for it, and that record is the point of the table.
    """
    from sqlalchemy import text

    from app.db import OwnerSessionLocal

    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "INSERT INTO tenants "
                "(id, name, region, tier, status, stage, config, created_at) "
                "VALUES (:id, 'Adoption Probe', 'ap-southeast-2', 'shared', "
                "'active', 'pilot', '{}'::jsonb, now()) "
                "ON CONFLICT (id) DO NOTHING"
            ),
            {"id": SYNTHETIC},
        )
        owner.commit()
    finally:
        owner.close()

    # The rest of what provisioning a tenant means: its own data key and its own
    # chain anchor. Doing this by hand here is a small piece of evidence that
    # there is no single "provision a tenant" call — every path that makes one
    # assembles it from the same three pieces, which is a thing to fix before
    # the first customer rather than after.
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        from app import crypto, evidence
        from app.db import OwnerSessionLocal as _Owner

        provisioning = _Owner()
        try:
            crypto.ensure_key(provisioning, SYNTHETIC)
            evidence.ensure_anchor(provisioning, SYNTHETIC)
            provisioning.commit()
        finally:
            provisioning.close()

    # A client, so the walk can produce a real determination in shadow. Written
    # through the application path so it is encrypted like any other.
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        from app.db import SessionLocal

        setup = SessionLocal()
        try:
            existing = setup.scalars(select(Client.id).limit(1)).first()
            if existing is None:
                setup.add(
                    Client(
                        id="probe-client",
                        name="A Probe Client",
                        scenario="meridian",
                        jurisdiction="AU",
                        dob=date(1982, 4, 17),
                        client_category="retail",
                        knowledge_assessed=True,
                        knowledge_date=date.today() - timedelta(days=90),
                        loss_capacity_band=4,
                        vulnerability_flag=False,
                        assessable_portfolio_cents=50_000_00,
                        prior_crypto_purchases=3,
                        structural_acks=[],
                        default_trade_amount_cents=1_000_00,
                    )
                )
                setup.commit()
        finally:
            setup.close()
    yield SYNTHETIC


@pytest.fixture
def synthetic(session, _provision):
    """The firm, at the bottom of the ladder, put back afterwards.

    `tenant_stages` is append-only, so the rows a walk writes stay — which is
    correct for a record of who signed for what, and means the fixture restores
    the *stage* rather than pretending the walk never happened.
    """
    # Rolled back first so the next statement *begins* a transaction inside the
    # tenancy context. `app.tenant_id` binds at transaction begin: with one
    # already open from a previous test, this reads as whatever tenant that
    # transaction started under, and row-level security correctly hides a row
    # belonging to somebody else. Alone this file passed; in the suite it did
    # not, which is the third time this repository has been taught the lesson.
    session.rollback()
    with tenancy.acting_as(SYNTHETIC):
        tenant = session.get(Tenant, SYNTHETIC)
        assert tenant is not None, f"{SYNTHETIC} was not provisioned"
        before_stage, before_config = tenant.stage, dict(tenant.config or {})
        tenant.stage = adoption.PILOT
        session.commit()
    try:
        yield tenant
    finally:
        session.rollback()
        with tenancy.acting_as(SYNTHETIC):
            tenant.stage = before_stage
            tenant.config = before_config
            session.commit()


# --- The walk ------------------------------------------------------------------


def test_a_firm_walks_the_whole_ladder_with_a_signature_on_every_rung(
    session, synthetic
):
    """§S10's gate, directly."""
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        assert adoption.stage_of(synthetic) == adoption.PILOT

        for rung, note in (
            (adoption.SHADOW, "book connected, nothing goes out"),
            (adoption.LIMITED, "live for the meridian segment only"),
            (adoption.FULL, "all flows live"),
        ):
            if rung == adoption.LIMITED:
                synthetic.config = {
                    **(synthetic.config or {}),
                    "limited_scope": {"scenarios": ["meridian"]},
                }
                session.flush()
            adoption.move(session, to_stage=rung, signed_by=SIGNATORY, note=note)
            session.commit()
            assert adoption.stage_of(synthetic) == rung

        walked = adoption.history(session)

    rungs = [entry["to"] for entry in walked][-3:]
    assert rungs == [adoption.SHADOW, adoption.LIMITED, adoption.FULL]
    for entry in walked[-3:]:
        assert entry["signed_by"] == SIGNATORY, "a rung with no signature"
        assert entry["note"], "a transition with no reason recorded"


def test_the_ladder_refuses_a_skip(session, synthetic):
    """Pilot to full in one move is the transition nobody should make by
    accident. A firm that is genuinely ready walks it in three steps on the same
    afternoon and has three signatures to show for it."""
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        with pytest.raises(adoption.LadderError) as exc:
            adoption.move(session, to_stage=adoption.FULL, signed_by=SIGNATORY)
        session.rollback()

    assert "skips" in str(exc.value)
    assert adoption.SHADOW in str(exc.value)


def test_the_ladder_refuses_an_unsigned_move(session, synthetic):
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        with pytest.raises(adoption.LadderError) as exc:
            adoption.move(session, to_stage=adoption.SHADOW, signed_by="   ")
        session.rollback()
    assert "needs a signature" in str(exc.value)


def test_a_firm_can_go_back_down(session, synthetic):
    """A customer having a bad week needs it to be possible, and the record is
    what makes it a decision rather than a disappearance."""
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        adoption.move(session, to_stage=adoption.SHADOW, signed_by=SIGNATORY)
        adoption.move(session, to_stage=adoption.LIMITED, signed_by=SIGNATORY)
        back = adoption.move(
            session,
            to_stage=adoption.SHADOW,
            signed_by=SIGNATORY,
            note="paused after a bad extract",
        )
        session.commit()

    assert back.from_stage == adoption.LIMITED
    assert back.to_stage == adoption.SHADOW
    assert back.note


def test_the_transition_log_cannot_be_edited(session, synthetic):
    from sqlalchemy import text
    from sqlalchemy.exc import DBAPIError

    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        adoption.move(session, to_stage=adoption.SHADOW, signed_by=SIGNATORY)
        session.commit()

        with pytest.raises(DBAPIError):
            session.execute(text("UPDATE tenant_stages SET signed_by = 'somebody else'"))
            session.flush()
        session.rollback()


# --- What each rung actually changes -------------------------------------------


def test_in_shadow_nothing_reaches_anybody(session, synthetic):
    """The promise the whole stage rests on. A determination is computed and
    recorded in full, and has no effect in the world."""
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        adoption.move(session, to_stage=adoption.SHADOW, signed_by=SIGNATORY)
        session.flush()
        effect = adoption.may_act(session, client_scenario="meridian", asset_id="BTC")

    assert effect.allowed is False
    assert "shadow" in effect.reason
    session.rollback()


def test_limited_is_live_for_the_named_slice_and_shadow_for_the_rest(
    session, synthetic
):
    """In `limited` one client is live and their colleague is not, which is why
    the question is asked per determination rather than per tenant."""
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        adoption.move(session, to_stage=adoption.SHADOW, signed_by=SIGNATORY)
        adoption.move(session, to_stage=adoption.LIMITED, signed_by=SIGNATORY)
        synthetic.config = {
            **(synthetic.config or {}),
            "limited_scope": {"scenarios": ["meridian"]},
        }
        session.flush()

        inside = adoption.may_act(session, client_scenario="meridian", asset_id="BTC")
        outside = adoption.may_act(session, client_scenario="sterling", asset_id="BTC")

    assert inside.allowed is True
    assert outside.allowed is False
    assert "outside the part of the book" in outside.reason
    session.rollback()


def test_limited_with_nothing_named_is_shadow(session, synthetic):
    """Treating an empty scope as "everything" would turn a missing config key
    into a firm going live, which is the worst possible reading of an absence."""
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        adoption.move(session, to_stage=adoption.SHADOW, signed_by=SIGNATORY)
        adoption.move(session, to_stage=adoption.LIMITED, signed_by=SIGNATORY)
        synthetic.config = {
            k: v for k, v in (synthetic.config or {}).items() if k != "limited_scope"
        }
        session.flush()
        effect = adoption.may_act(session, client_scenario="meridian", asset_id="BTC")

    assert effect.allowed is False
    assert "none is named yet" in effect.reason
    session.rollback()


def test_an_unknown_stage_reads_as_pilot(session, synthetic):
    """The failure mode of the other default is a determination reaching a
    client's adviser on the day a customer record was created by hand."""
    with tenancy.acting_as(SYNTHETIC):
        synthetic.stage = "whatever-somebody-typed"
        session.flush()
        assert adoption.stage_of(synthetic) == adoption.PILOT
        session.rollback()


def test_a_shadow_determination_is_recorded_in_full(session, synthetic):
    """Shadow is only worth anything if what it produces is what going live
    would have produced — same snapshot, same chain, same everything except the
    effect."""
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        adoption.move(session, to_stage=adoption.SHADOW, signed_by=SIGNATORY)
        session.flush()

        who = session.scalars(select(Client.id).limit(1)).first()
        assert who is not None, (
            f"the {SYNTHETIC} tenant holds no clients, so this cannot prove that "
            "a shadow determination is recorded in full"
        )

        decision = service.evaluate(session, client_id=who, asset_id="BTC")
        session.flush()

    assert decision.id and decision.this_hash and decision.snapshot
    assert decision.outcome in ("ALLOW", "REFER", "BLOCK")
    session.rollback()


# --- The comparison report -----------------------------------------------------


def _their_extract(session, *, disagree_on: int = 1) -> tuple[list[dict], list]:
    """An extract from the customer's own system, agreeing except where told.


    Built from our own determinations so the pairs line up — the point of the
    test is the comparison, not whether two independently invented datasets
    happen to overlap.
    """
    # One determination per pair, newest first. A client is assessed for the
    # same asset many times, and an extract that named the pair repeatedly would
    # be testing the ingest's deduplication rather than the comparison.
    ours = list(
        session.scalars(
            select(Decision)
            .distinct(Decision.client_id, Decision.asset_id)
            .order_by(Decision.client_id, Decision.asset_id, Decision.id.desc())
            .limit(8)
        )
    )
    assert ours, "no determinations to compare against"

    flip = {"ALLOW": "REFER", "REFER": "BLOCK", "BLOCK": "ALLOW"}
    rows = []
    for index, decision in enumerate(ours):
        outcome = flip[decision.outcome] if index < disagree_on else decision.outcome
        rows.append(
            {
                "client_id": decision.client_id,
                "asset_id": decision.asset_id,
                "outcome": outcome.lower(),
                "as_of": decision.as_of.isoformat(),
            }
        )
    return rows, ours


def test_the_report_shows_an_agreement_rate_with_a_denominator(session):
    """A percentage with no denominator is a number somebody has to ask us
    about — which is the definition of "not readable unaided"."""
    with tenancy.acting_as("demo"), tenancy.acting_as_user(ACTOR):
        rows, _ours = _their_extract(session, disagree_on=2)
        comparison.ingest(session, rows, source="their-extract.csv")
        session.flush()
        report = comparison.compare(session)
        session.rollback()

    assert report["compared"] >= len(rows)
    assert report["agreed"] + report["diverged"] == report["compared"]
    assert 0.0 <= report["agreement_rate"] <= 1.0
    assert report["their_rows"] and report["our_rows"]


def test_every_divergence_says_which_rule_and_why(session):
    """§S10's gate: readable unaided. A divergence naming a rule id and no rule,
    or an outcome and no reason, is one a compliance officer has to ask about."""
    with tenancy.acting_as("demo"), tenancy.acting_as_user(ACTOR):
        rows, _ours = _their_extract(session, disagree_on=3)
        comparison.ingest(session, rows, source="their-extract.csv")
        session.flush()
        report = comparison.compare(session)
        session.rollback()

    assert report["divergences"], "the extract disagreed and the report found nothing"
    for divergence in report["divergences"]:
        assert divergence["ours"] in comparison.OUTCOMES
        assert divergence["theirs"] in comparison.OUTCOMES
        assert divergence["explanation"], "a divergence with no explanation"
        assert divergence["theirs_raw"], "their own wording was not preserved"
        # Untriaged on purpose: a system that graded its own disagreements would
        # grade them in its own favour.
        assert divergence["triage"] == comparison.UNTRIAGED


def test_a_word_we_do_not_recognise_is_reported_rather_than_guessed(session):
    """A comparison that mapped `TIER_3` to the nearest-sounding outcome would
    manufacture agreement nobody decided."""
    with tenancy.acting_as("demo"), tenancy.acting_as_user(ACTOR):
        rows, ours = _their_extract(session, disagree_on=0)
        rows[0]["outcome"] = "TIER_3"
        tally = comparison.ingest(session, rows, source="their-extract.csv")
        session.flush()
        report = comparison.compare(session)
        session.rollback()

    assert tally["unmapped"] >= 1
    assert report["unmapped_outcomes"] >= 1
    # And it is not counted as agreement or disagreement, either way.
    assert report["compared"] == report["agreed"] + report["diverged"]


def test_a_customers_own_vocabulary_can_be_supplied(session):
    """Their words map onto ours because the customer said so, not because we
    guessed."""
    with tenancy.acting_as("demo"), tenancy.acting_as_user(ACTOR):
        rows, _ours = _their_extract(session, disagree_on=0)
        rows[0]["outcome"] = "TIER_3"
        tally = comparison.ingest(
            session,
            rows,
            source="their-extract.csv",
            vocabulary={"TIER_3": "REFER"},
        )
        session.flush()
        session.rollback()

    assert tally["unmapped"] == 0


def test_a_corrected_extract_supersedes_rather_than_overwrites(session):
    """A re-send is a correction, and the earlier answer is still evidence.

    **Rewritten for FP3-23, and the reasoning it replaces is worth keeping.**
    This used to assert `kept == [("BLOCK", "second.csv")]` — exactly one row,
    the corrected one — under migration 0021's rule:

        One answer per pair per date. A re-sent extract corrects the row it
        replaces rather than adding a second opinion nobody can choose between.

    That is sound about the reader's problem and it solved it by making the
    writer destructive. `comparison.ingest` did `existing.outcome = mapped`, and
    `incumbent_outcomes` had no append-only trigger and no revoked grants — so
    the number a shadow-mode engagement closes on, "we agree with you 97% of the
    time", was editable in place by the application role with nothing recording
    that it had changed. Every other figure in this system is chained precisely
    so that cannot be done to it.

    "Nobody can choose between them" is answered by choosing: the newest row
    wins, which is the rule `packs_repo` already applies to rule content. So
    both rows are kept and `latest_by_pair` is what every reader uses.
    """
    from app.models import IncumbentOutcome

    with tenancy.acting_as("demo"), tenancy.acting_as_user(ACTOR):
        rows, _ours = _their_extract(session, disagree_on=0)
        comparison.ingest(session, rows[:1], source="first.csv")
        session.flush()

        corrected = [{**rows[0], "outcome": "block"}]
        tally = comparison.ingest(session, corrected, source="second.csv")
        session.flush()

        held = session.scalars(
            select(IncumbentOutcome)
            .where(
                IncumbentOutcome.client_id == rows[0]["client_id"],
                IncumbentOutcome.asset_id == rows[0]["asset_id"],
            )
            .order_by(IncumbentOutcome.id)
        ).all()
        # Read before the rollback: rolling back expires every loaded attribute,
        # and reading one afterwards raises rather than returning the old value.
        kept = [(row.outcome, row.source) for row in held]
        newest = comparison.latest_by_pair(session)[
            (rows[0]["client_id"], rows[0]["asset_id"])
        ]
        winner = (newest.outcome, newest.source)
        session.rollback()

    assert tally["replaced"] == 1
    # Not an exact count: other tests in this file ingest the same pair, and a
    # test that asserted "exactly two" would be asserting the order it runs in.
    # What supersession means is that the earlier answer is still there and the
    # later one is what gets read.
    assert ("ALLOW", "first.csv") in kept, (
        f"the earlier answer was destroyed to record the later one: {kept}"
    )
    assert kept[-1] == ("BLOCK", "second.csv"), (
        f"the correction is not the newest row: {kept}"
    )
    assert winner == ("BLOCK", "second.csv"), (
        "the comparison does not read the newest answer"
    )


def test_an_empty_comparison_reports_no_rate_rather_than_a_perfect_one(session):
    """A rate computed over zero pairs is not a rate, and printing 100% for it
    would be the most misleading number this report could carry."""
    with tenancy.acting_as("demo"), tenancy.acting_as_user(ACTOR):
        future = date.today() + timedelta(days=3650)
        report = comparison.compare(session, since=future)

    assert report["compared"] == 0
    assert report["agreement_rate"] is None


def test_the_worst_disagreement_is_read_first(session):
    """A pair where we block and they allow matters most in both directions —
    either their process is letting something through, or ours is stopping
    something it should not."""
    with tenancy.acting_as("demo"), tenancy.acting_as_user(ACTOR):
        rows, _ours = _their_extract(session, disagree_on=8)
        comparison.ingest(session, rows, source="their-extract.csv")
        session.flush()
        report = comparison.compare(session)
        session.rollback()

    order = [d["ours"] for d in report["divergences"]]
    severity = {"BLOCK": 0, "REFER": 1, "ALLOW": 2}
    assert order == sorted(order, key=lambda o: severity.get(o, 3))


# --- Onboarding to shadow ------------------------------------------------------
#
# §S10's target metric: "onboarding to shadow in under two weeks from contract -
# instrument it." The instrument is only worth having if it can report badly, so
# both tests below check what it does when the answer is unflattering.


def firms_today(session) -> date:
    """Today as this firm counts days. FP3-05.

    These two tests set `contracted_at` from `date.today()` — the *runner's*
    calendar day — and asserted an exact number of days back from it. The
    measurement now counts the firm's calendar days between two of the firm's
    calendar dates, which is the stable answer: before, the same seven weeks
    read as 49 days or 48 depending on what time of day the stage change
    happened to land.

    Found by the dual-timezone CI run. Under `TZ=Australia/Sydney` the test's
    arithmetic and the metric disagreed by exactly one day, which is the whole
    finding in miniature.
    """
    with tenancy.acting_as(SYNTHETIC):
        return business_time.business_today(session)


def _reached_shadow_on(session) -> date:
    """The firm's calendar date the metric will actually measure *to*.

    Not today, and the difference is a pre-existing defect this fix-pack found
    on the way past. `adoption.onboarding` reads the **first** transition into
    shadow — correctly, because "how long did this firm take to reach shadow"
    means the first time it got there — and `tenant_stages` is append-only, so
    every previous run of the two tests below is still in the table. On a
    database more than a day old the metric measured to that first row's date
    while the tests counted back from today's, and the assertion was off by
    however many days the database had been alive.

    Green for as long as the table was young and red the first morning after,
    which is the same shape as the profile-change defect recorded in
    `docs/spec-changes.md` for 2026-08-28: a test that passes until something
    accumulates. Reading the date the measurement will use makes these tests
    statements about the metric rather than about the age of the database.
    """
    with tenancy.acting_as(SYNTHETIC):
        reached = session.scalars(
            select(TenantStageChange)
            .where(
                TenantStageChange.tenant_id == SYNTHETIC,
                TenantStageChange.to_stage == adoption.SHADOW,
            )
            .order_by(TenantStageChange.at)
        ).first()
        assert reached is not None, "the firm has not reached shadow"
        zone = business_time.zone_for(session.get(Tenant, SYNTHETIC))
        return reached.at.astimezone(zone).date()


def _measure_from(session, *, days_before: int) -> dict:
    """Move to shadow, then date the contract that many of the firm's days back.

    In that order, because the date to count back from is the one the metric
    counts forward from — see `_reached_shadow_on`. `contracted_at` is read when
    `onboarding` is called rather than when the move happens, so setting it
    afterwards changes nothing about what is being measured.
    """
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        adoption.move(session, to_stage=adoption.SHADOW, signed_by=SIGNATORY)
        session.commit()

    signed = _reached_shadow_on(session) - timedelta(days=days_before)

    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        row = session.get(Tenant, SYNTHETIC)
        row.config = {**(row.config or {}), "contracted_at": signed.isoformat()}
        session.commit()
        return adoption.onboarding(session)


def test_time_to_shadow_is_measured_from_the_contract(session, synthetic):
    """The clock starts where the customer thinks it starts."""
    measured = _measure_from(session, days_before=9)

    assert measured["measured"] is True
    assert measured["reached_shadow"] is True
    assert measured["days"] == 9
    assert measured["target_days"] == adoption.ONBOARDING_TARGET_DAYS
    assert measured["within_target"] is True


def test_a_slow_onboarding_is_reported_as_slow(session, synthetic):
    """The same firm, contracted seven weeks ago, misses the target.

    Written because the first version of this metric was tested only against a
    firm that met it, and a measurement that has never been seen to say "no" is
    not a measurement.
    """
    measured = _measure_from(session, days_before=49)

    assert measured["days"] == 49
    assert measured["within_target"] is False


def test_without_a_contract_date_the_metric_says_so(session, synthetic):
    """Unmeasured, rather than measured from whenever the row happened to appear.

    Falling back to `tenants.created_at` would produce a number for every firm
    and flatter us by however long it took somebody to create the record — which
    is exactly the kind of quietly-wrong metric a board deck gets built on.
    """
    with tenancy.acting_as(SYNTHETIC), tenancy.acting_as_user(ACTOR):
        synthetic.config = {
            key: value
            for key, value in (synthetic.config or {}).items()
            if key != "contracted_at"
        }
        adoption.move(session, to_stage=adoption.SHADOW, signed_by=SIGNATORY)
        session.commit()
        measured = adoption.onboarding(session)

    assert measured["measured"] is False
    assert "contract date" in measured["why_not"]
    # It still reports that the firm got there — the date is what is missing,
    # not the event.
    assert measured["reached_shadow_at"]


def test_the_agreement_rate_cannot_be_edited_in_place(session):
    """FP3-23, and the reason it is a migration rather than a code change.

    §S10's value is the sentence "we agree with you 97% of the time, and here
    are the 3%". That is the number a shadow-mode engagement converts on, and it
    was the one figure in this system that the application role could move — up
    to close a sale, or down to argue a divergence was the customer's.

    Made to happen rather than reasoned about: an UPDATE is attempted through
    the application's own connection and must be refused.
    """
    from sqlalchemy import text
    from sqlalchemy.exc import DBAPIError

    from app.db import engine

    # Nothing is written. Postgres checks privileges when it plans the
    # statement, before it looks at a row, so an empty table refuses just as
    # loudly — and this file's other tests read `incumbent_outcomes`, so adding
    # a committed row here would make their results depend on running order.
    with engine.begin() as conn:
        with pytest.raises(DBAPIError, match="permission denied|append-only"):
            conn.execute(text("UPDATE incumbent_outcomes SET outcome = 'ALLOW'"))

    with engine.begin() as conn:
        with pytest.raises(DBAPIError, match="permission denied|append-only"):
            conn.execute(text("DELETE FROM incumbent_outcomes"))
