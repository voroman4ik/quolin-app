"""The evidence chain must verify the same under any session timezone.

`_hashable` puts `created_at.isoformat()` into the decision payload. The column
is `timestamptz`, and psycopg renders one into a Python datetime carrying the
offset of the connection's `TimeZone` setting. Nothing pinned that setting.

So a chain written under a UTC session and verified under `Australia/Sydney`
produced `verified=False checked=0` — the first link failing, for every tenant,
every chain. Reproduced by execution before this file was written:

    UTC               -> {'verified': True,  'checked': 47}
    Australia/Sydney  -> {'verified': False, 'checked': 0}
    America/New_York  -> {'verified': False, 'checked': 0}

Two things make that worse than it looks. `docs/runbooks/` treats a chain
failure as a security incident, and there is nothing in the report that would
distinguish "somebody edited a determination" from "somebody changed a pooler
setting". And Sydney is the primary region in `infra/` — the timezone most
likely to be set by a well-meaning operator is the one that breaks every chain.

The fix normalises to UTC before serialising rather than hashing something new,
because that reproduces every hash already on file: a chain written under a UTC
session hashed an aware UTC datetime, and `astimezone(utc)` on one is the
identity. `test_the_seeded_chain_still_verifies_unchanged` is the assertion that
this is true rather than assumed — a fix that silently rechained stored evidence
would be a worse defect than the one it repaired.

`db.py` also pins `TimeZone=UTC` on every connection. That is defence in depth
and not the fix: these tests set the session timezone *after* the transaction
has begun, so what they exercise is the normalisation itself.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import text

from app import evidence, tenancy
from app.db import SessionLocal
from tests.conftest import DEMO_TENANT

#: Two real deployments and the baseline. Sydney because `infra/` puts the
#: primary region there; New York because it is west of UTC and a bug that only
#: showed on positive offsets would be missed by Sydney alone.
TIMEZONES = ("UTC", "Australia/Sydney", "America/New_York", "Asia/Kolkata")


def _verify_under(tz: str, which: str) -> dict:
    """Run one of the two chain verifications with the session in `tz`.

    `SET TIME ZONE` is issued after the transaction has begun, so it overrides
    anything `db.py` pinned. That is deliberate: what is under test is that the
    payload does not depend on the setting, not that the setting is pinned.
    """
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            session.execute(text(f"SET TIME ZONE '{tz}'"))
            settled = session.execute(text("SHOW TimeZone")).scalar()
            assert settled == tz, f"the session did not take {tz}; it reports {settled}"
            if which == "decisions":
                return dict(evidence.verify_chain(session))
            return dict(evidence.verify_audit_chain(session))
        finally:
            session.rollback()
            session.close()


@pytest.mark.parametrize("which", ("decisions", "audit"))
def test_a_chain_verifies_identically_under_every_session_timezone(which) -> None:
    """The finding, as one test. It would have caught the defect on its own."""
    baseline = _verify_under("UTC", which)
    assert baseline["verified"] is True, f"the {which} chain does not verify under UTC"
    assert baseline["checked"] > 0, "nothing was checked; this test would prove nothing"

    for tz in TIMEZONES:
        result = _verify_under(tz, which)
        assert result["verified"] is True, (
            f"the {which} chain does not verify with the session in {tz}: {result}. "
            "A pooler setting change would present as a tampering incident with "
            "nothing in the report to tell the two apart."
        )
        assert result["checked"] == baseline["checked"], (
            f"{tz} checked {result['checked']} links, UTC checked "
            f"{baseline['checked']}"
        )
        assert result["tip_hash"] == baseline["tip_hash"], (
            f"the {which} chain has a different tip under {tz}"
        )


def test_the_same_moment_hashes_the_same_however_it_is_expressed() -> None:
    """One instant, four spellings, one payload.

    Below the chain walk, because the walk can only be right if this is. An
    aware datetime is a moment plus a way of writing it down, and only the
    moment belongs in a hash.
    """
    instant = datetime(2026, 8, 23, 4, 5, 6, 123456, tzinfo=timezone.utc)
    spellings = [
        instant,
        instant.astimezone(timezone(timedelta(hours=11))),
        instant.astimezone(timezone(timedelta(hours=-4))),
        instant.astimezone(timezone(timedelta(hours=5, minutes=30))),
    ]

    payloads = [
        evidence._hashable(
            tenant_id=DEMO_TENANT,
            client_id="c",
            asset_id="a",
            as_of=instant.date(),
            pack_id="AU",
            pack_version=1,
            snapshot={},
            rule_results={},
            resolution=None,
            outcome="ALLOW",
            created_at=spelling,
            schema=1,
            execution_manifest=None,
        )
        for spelling in spellings
    ]

    first = payloads[0]["created_at"]
    for payload, spelling in zip(payloads, spellings, strict=True):
        assert payload["created_at"] == first, (
            f"{spelling.isoformat()} hashed as {payload['created_at']!r}, "
            f"not {first!r}. The same moment must produce the same bytes."
        )
    assert first.endswith("+00:00"), f"normalised to {first!r}, which is not UTC"


def test_a_naive_timestamp_is_read_as_utc_and_not_as_local_time() -> None:
    """The one case `astimezone` gets dangerously wrong on its own.

    `astimezone` on a naive datetime assumes the *machine's* local zone, so a
    laptop in London and a container in Sydney would hash the same row
    differently — the original defect, moved rather than fixed. Every timestamp
    this system writes is UTC-aware, so naive can only mean UTC, and it is said
    explicitly rather than left to the platform.
    """
    aware = datetime(2026, 8, 23, 4, 5, 6, tzinfo=timezone.utc)
    naive = aware.replace(tzinfo=None)
    assert evidence._utc_isoformat(naive) == evidence._utc_isoformat(aware)


def test_the_seeded_chain_still_verifies_unchanged() -> None:
    """Normalising must not have rechained anything already on file.

    The check the fix was conditional on. Every seeded decision was hashed under
    a UTC session, so `astimezone(utc)` is the identity for all of them and no
    stored hash moves. If that were ever untrue the right answer would be to
    stop and report, not to rewrite evidence — invariant 5.
    """
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            decisions = evidence.verify_chain(session)
            audit = evidence.verify_audit_chain(session)
        finally:
            session.rollback()
            session.close()

    assert decisions["verified"] is True, decisions
    assert audit["verified"] is True, audit
    assert decisions["checked"] > 0 and audit["checked"] > 0
