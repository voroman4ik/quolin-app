"""Replay reads a pack out of the database. It has to cope with a bad one.

Report B: a historical pack is loaded via `Pack.from_body` at replay with no
validation, so a stored body that has become invalid — a threshold renamed out
from under a rule, a reason code deleted, a calc that no longer exists — either
evaluates to something meaningless or raises out of the replay as an
unclassified error.

`packs` is append-only, so a body does not change on its own. What changes is
the *engine* around it: a calc removed, a snapshot field renamed, a DSL version
retired. That is exactly the drift the nightly replay exists to detect, and the
replay's own report is where it has to arrive — as a distinct outcome, not as a
crash and not as a rule-outcome mismatch, because those two mean entirely
different things to whoever is reading the alert at three in the morning.

So a replay validates the pack of record before evaluating it, and reports
`PACK_INVALID_AT_REPLAY` when it will not load.
"""

from __future__ import annotations

import copy

import pytest
from sqlalchemy import select

from app import evidence, packs_repo, service, tenancy
from app.db import SessionLocal
from app.engine.pack import Pack as EnginePack
from app.models import Decision
from tests.conftest import DEMO_TENANT


def _a_decision_and_its_pack():
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            decision = session.scalars(
                select(Decision).order_by(Decision.id.desc()).limit(1)
            ).one()
            pack = packs_repo.by_version(
                session, service._governing_pack_id(decision), decision.pack_version
            )
            others = service._other_packs(session, decision)
            session.expunge(decision)
            return decision, pack, others
        finally:
            session.close()


def test_a_healthy_pack_replays_and_says_nothing_about_validity() -> None:
    """The baseline. A valid pack must not acquire a finding for being valid."""
    decision, pack, others = _a_decision_and_its_pack()
    result = evidence.replay(decision, pack, others)
    assert result["match"] is True, result["differences"]
    assert result.get("pack_valid") is True
    assert result.get("outcome_code") != "PACK_INVALID_AT_REPLAY"


def test_a_pack_that_no_longer_validates_is_reported_as_such() -> None:
    """The finding: a distinct outcome, not a crash and not a rule mismatch.

    Corrupted the way real drift corrupts: a rule reads a threshold that is no
    longer in the table. Nothing edited the stored body — `packs` is
    append-only — but a pack authored against an engine that had a calc, or a
    field, which this one does not is in exactly this state.
    """
    decision, pack, others = _a_decision_and_its_pack()

    broken_body = copy.deepcopy(pack.source_body)
    broken_body["thresholds"] = {}
    broken = EnginePack.from_body(broken_body)

    result = evidence.replay(decision, broken, others)

    assert result["match"] is False
    assert result["outcome_code"] == "PACK_INVALID_AT_REPLAY", result
    assert result["pack_valid"] is False
    assert result["pack_faults"], "the report does not say what is wrong with it"
    assert any("threshold" in fault for fault in result["pack_faults"]), (
        result["pack_faults"]
    )


def test_it_is_told_apart_from_a_rule_outcome_mismatch() -> None:
    """The distinction is the point.

    "The rules of record no longer load" and "the engine now says something
    different" are different findings with different first moves. A replay that
    reported both as a list of rule differences would send somebody looking for
    a regression in the evaluator when the pack will not even parse.
    """
    decision, pack, others = _a_decision_and_its_pack()

    broken_body = copy.deepcopy(pack.source_body)
    broken_body["thresholds"] = {}
    result = evidence.replay(decision, EnginePack.from_body(broken_body), others)

    assert result["outcome_code"] == "PACK_INVALID_AT_REPLAY"
    assert result["differences"] == [], (
        "an invalid pack produced rule-level differences as well. The rules did "
        "not disagree; they did not load."
    )
    assert result["replayed_outcome"] is None, (
        "an outcome was reported for a pack that does not load"
    )


def test_an_invalid_pack_does_not_raise_out_of_the_replay() -> None:
    """A nightly job over a whole book must not stop on one bad row.

    `scripts/nightly_replay.py` walks every determination on file. An
    unclassified exception out of one of them ends the run, and the rest of the
    book goes unchecked — which is the failure this whole mechanism exists to
    prevent.
    """
    decision, pack, others = _a_decision_and_its_pack()

    nonsense = copy.deepcopy(pack.source_body)
    nonsense["rules"] = [
        {
            "rule_id": "BROKEN-01",
            "title": "Reads a calc that does not exist",
            "applies_to": {},
            "severity": 2,
            "on_fail": "BLOCK",
            "reason_code": "NOPE",
            "predicate": {
                "op": "gt",
                "left": {"calc": "a_calc_this_engine_never_had"},
                "right": {"const": 1},
            },
        }
    ]

    result = evidence.replay(decision, EnginePack.from_body(nonsense), others)
    assert result["outcome_code"] == "PACK_INVALID_AT_REPLAY"
    assert result["match"] is False


def test_the_nightly_job_reports_it_rather_than_failing_to_run() -> None:
    """And the same distinction reaches the operator's report."""
    import subprocess
    import sys
    from pathlib import Path

    repo = Path(__file__).resolve().parents[2]
    result = subprocess.run(
        [sys.executable, "-m", "scripts.nightly_replay", "--json"],
        cwd=repo,
        capture_output=True,
        text=True,
        timeout=600,
    )
    assert result.returncode == 0, result.stdout[-2000:] + result.stderr[-2000:]
    assert "PACK_INVALID_AT_REPLAY" not in result.stdout, (
        "a seeded determination's pack no longer loads"
    )
    assert pytest is not None
