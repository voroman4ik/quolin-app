"""Rule A: no test proves behaviour by reading source text.

Fix-pack 2 required that every fix ship with an end-to-end test of the workflow
it touched. The 27 August sweep complied in form — three tests named "the wiring
itself, asserted rather than assumed" — and every one of them was

    assert "notify_tenants" in path.read_text()

with the explanatory comment ten lines above the call containing the same
string. Delete the call, keep the comment, tests pass. That is not a
hypothetical: FP3-03 is a call that could not run in production for a week,
underneath a green test asserting it existed.

So the rule is mechanical now rather than intentional. A test may read a file to
make a claim about **documentation** — that a runbook exists, that the published
OpenAPI matches, that a migration's own text carries a reason — because the file
*is* the subject. It may not read a file under `api/app/` or `scripts/` to make
a claim about what that code does. For that, monkeypatch the target and run the
real entry point, or instrument the connection and read back what was touched.

The allow-list below is the complete set of exceptions, each with the reason it
is one. It is short on purpose: a long allow-list is this rule not being
enforced.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

TESTS = Path(__file__).resolve().parent
APP = Path(__file__).resolve().parents[1] / "app"
SCRIPTS = Path(__file__).resolve().parents[2] / "scripts"

#: The calls that read a file's text.
READERS = {"read_text", "getsource", "getsourcelines", "getsourcefile"}

#: Tests permitted to read source text, and why each is not proving behaviour.
#:
#: Two kinds of entry, and the difference is the whole rule.
#:
#: The first kind reads source in order to **change** it, then asserts on what
#: happened when the changed thing ran. That is not a text assertion at all —
#: the text is an input.
#:
#: The second kind performs **static analysis as the subject of the check**:
#: "the engine imports no clock", "no jurisdiction code appears as a constant",
#: "only one module constructs a pack row". These are structural properties of
#: the code, and reading the code is the only way to ask about them — it is what
#: the guards in `scripts/` do, and Tier 2 keeps the lexical guards as a fast
#: pre-check alongside the runtime enforcement rather than deleting them.
#:
#: What is banned is the third kind, which is not on this list and will not be:
#: grepping for a name to prove a call happens. `assert "notify_tenants" in
#: watch_tick.read_text()` is satisfied by the comment explaining the call, and
#: FP3-03 is a week of a broken production path underneath exactly that
#: assertion.
ALLOWED: dict[str, str] = {
    # Reads its own file to build the allow-list report. It is this rule.
    "test_no_test_reads_source.py": (
        "the file implementing Rule A, which necessarily parses test sources"
    ),
    # Copies the repository into a temp directory and injects violations. It
    # reads source in order to *change* it, and then runs the guard against the
    # changed tree — the assertion is on the guard's exit code, never on text.
    "test_guard_mutations.py": (
        "injects violations into a copy of the tree; asserts on exit codes"
    ),
    # Builds sacrificial alembic migrations from the real tree and applies them
    # to a scratch database. Same shape: reads to construct, asserts on the
    # catalog.
    "test_migration_linter.py": (
        "constructs sacrificial migrations; asserts on the database catalog"
    ),
    # --- static analysis, where the code's shape is the claim ---
    "test_packs.py": (
        "parses api/app/engine for jurisdiction constants — invariant 2 is a "
        "structural property and reading the source is how it is asked about"
    ),
    "test_watch.py": (
        "walks the engine's import graph and asks which module constructs a "
        "pack row; both are structural claims about the code's shape"
    ),
    "test_report_c_hypotheses.py": (
        "AST checks that the engine consults no clock and that calcs.py "
        "contains no float division"
    ),
    # The AST twin of `guard_no_owner_in_request_path.sh`. Its whole subject is
    # a structural property — "no module under api/app names the owner
    # connection, opens the owner_only door, holds the connection string, or
    # imports a package that does" — and parsing those modules is the only way
    # to ask about it. Its mutation cases assert on the guards' verdicts rather
    # than on text.
    #
    # F3 added the entry, and how it came to be needed is worth recording. This
    # file has always parsed `api/app`; it passed this rule only because
    # `_targets_application_code` looks at a nine-line window around each
    # `read_text()` and no comment inside that window happened to say `app/` or
    # `scripts/`. Refactoring the two parse calls into one `_tree` helper moved
    # it next to a comment that does. So the exemption was there all along and
    # unwritten, which is the state an allow-list exists to end.
    "test_no_request_reaches_the_schema_owner.py": (
        "the AST twin of the owner-in-request-path guard; parses api/app to ask "
        "a structural question, and asserts on both layers' verdicts"
    ),
    "test_chain_anchors.py": (
        "asserts rechain.py's UPDATE touches only the two hash columns. Its own "
        "docstring says why it is static: the run that would prove it "
        "dynamically is the one nobody should be able to trigger by accident"
    ),
}


def _test_files() -> list[Path]:
    return sorted(p for p in TESTS.rglob("test_*.py") if p.is_file())


def _reads_source(tree: ast.AST) -> list[tuple[int, str]]:
    """Every call to a text-reading function, with the line it is on."""
    found: list[tuple[int, str]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        name = None
        if isinstance(func, ast.Attribute):
            name = func.attr
        elif isinstance(func, ast.Name):
            name = func.id
        if name in READERS:
            found.append((node.lineno, name))
    return found


def _targets_application_code(source: str, line: int) -> bool:
    """Whether the read near this line is pointed at `api/app` or `scripts`.

    Deliberately crude — a window of source text around the call, looked at for
    the names of the two directories this rule protects. Resolving a `Path`
    expression properly would mean evaluating it, and a test that has to run the
    code it is judging in order to judge it is a worse trade than a few false
    positives that an allow-list entry can settle.
    """
    lines = source.splitlines()
    window = "\n".join(lines[max(0, line - 6) : line + 3])
    return any(
        marker in window
        for marker in ('"app"', "'app'", '"scripts"', "'scripts'", "app/", "scripts/")
    )


@pytest.mark.parametrize("path", _test_files(), ids=lambda p: p.name)
def test_a_test_does_not_read_application_source_to_prove_behaviour(path: Path) -> None:
    if path.name in ALLOWED:
        pytest.skip(f"allow-listed: {ALLOWED[path.name]}")

    source = path.read_text()
    offenders = [
        (line, name)
        for line, name in _reads_source(ast.parse(source))
        if _targets_application_code(source, line)
    ]

    assert not offenders, (
        f"{path.name} reads application source to make a claim about it: "
        + ", ".join(f"{name}() at line {line}" for line, name in offenders)
        + ".\n\nRule A: prove wiring by monkeypatching the target and running "
        "the real entry point; prove role separation by instrumenting "
        "`engine.connect` and asserting the set of DSNs touched; prove "
        "enforcement by making the violation happen and asserting it is "
        "refused. A grep for a name in a file is satisfied by the comment "
        "explaining the call — which is how FP3-03 shipped a call that could "
        "not run in production underneath a green test."
    )


def test_the_allow_list_names_only_files_that_exist() -> None:
    """An allow-list entry for a deleted file is a hole nobody can see.

    The entry stops applying to anything, so it is harmless today and becomes a
    silent exemption the moment somebody creates a file with that name again.
    """
    missing = [name for name in ALLOWED if not (TESTS / name).exists()]
    assert not missing, f"allow-listed tests that no longer exist: {missing}"


def test_the_allow_list_does_not_grow() -> None:
    """A long allow-list is this rule not being enforced.

    Not a style preference. Every entry is a file where the mechanical check is
    off, and the failure mode of exemptions is that they accumulate one
    reasonable case at a time until the rule means nothing.

    Seven was what it took, down from eight:
    `test_guards_cannot_be_vacuous.py` was deleted in Tier 2 and its entry went
    with it. The number is expected to keep falling. An eighth should be an
    argument somebody has, not a line somebody adds.

    **Eight, and here is the argument.** F3 added
    `test_no_request_reaches_the_schema_owner.py`, which is the AST twin of
    `guard_no_owner_in_request_path.sh`. It parses every module under `api/app`
    to ask a structural question — does anything here name the owner
    connection, open the `owner_only` door, hold the connection string, or
    import a package that does — and that is the second kind of entry this
    allow-list already describes, alongside "the engine imports no clock" and
    "no jurisdiction code appears as a constant". Nothing in it asserts that a
    name appears in a file.

    What makes it an entry rather than a refactor is that **the exemption was
    already in force and nobody had written it down.** That file has parsed
    `api/app` since it was created and passed this rule only because
    `_targets_application_code` reads a nine-line window around each
    `read_text()`, and no comment inside those windows happened to say `app/` or
    `scripts/`. Moving its two parse calls into one helper put it beside a
    comment that does, and the rule fired. Keeping the ceiling at seven would
    have meant moving a function to keep a check that, for this file, can only
    ever produce a false positive — and leaving its compliance resting on where
    a comment sits.

    So: eight, deliberately, in the commit that needed it. The next one is still
    an argument somebody has.
    """
    assert len(ALLOWED) <= 8, (
        f"{len(ALLOWED)} tests are exempt from Rule A. Each one is a place the "
        "check is off — if a new exemption is genuinely needed, say so here and "
        "raise this ceiling deliberately, in the same commit."
    )
