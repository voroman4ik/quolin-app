"""Two controls filing evidence at once must not overwrite each other.

F-04. `evidence_io.write` chose its filename like this:

    while (folder / f"{name}.json").exists():
        name = f"{base}-{attempt}"
    path.write_text(...)

The A1 fix added that loop and closed the *sequential* collision — a control run
twice inside one second no longer files one artefact. It does nothing about the
concurrent one. Two processes can both evaluate `.exists()` as false for the
same name and both go on to write it, and the later write wins. The evidence of
the earlier run is gone, with nothing anywhere saying it ever existed.

The size of the change is not the size of the finding. What this destroys is
exactly the artefacts the audit process relies on, and it destroys them
silently: `scripts/evidence_index.py` reports what the folder holds, and a
folder that never received the file has nothing to report. The digest check
cannot help either — the surviving file is internally consistent, because it is
a complete and correct artefact of the run that won.

`make game-day` fires every alert path on purpose and `make evidence-pack`
assembles a window, so more than one control filing inside the same second is
ordinary rather than exotic.

**Atomic exclusive creation is the fix.** `open(..., "x")` asks the operating
system for the name, and exactly one process can win. The loser sees
`FileExistsError` and takes the next number, which is what the counter was
always meant to express — the loop just had no way to make the claim stick.
"""

from __future__ import annotations

import json
import sys
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from scripts import evidence_io  # noqa: E402

#: One fixed moment for every writer, so they all compute the same base name.
#: The whole finding is what happens when the names collide, so the collision is
#: arranged rather than hoped for.
MOMENT = datetime(2026, 8, 27, 9, 30, 0, tzinfo=timezone.utc)

WRITERS = 12
CONTROL = "concurrent-writers-probe"


@pytest.fixture
def evidence_root(tmp_path) -> Path:
    """A folder of this test's own. The real one is the audit evidence room."""
    return tmp_path / "evidence"


def _writer(root: Path):
    def _file_one(index: int) -> Path:
        return evidence_io.write(
            "drills",
            CONTROL,
            {"writer": index},
            passed=True,
            summary=f"writer {index}",
            out=root,
            now=MOMENT,
        )

    return _file_one


def test_every_concurrent_writer_keeps_its_artefact(evidence_root) -> None:
    """The finding: twelve writers, twelve artefacts, none overwritten."""
    with ThreadPoolExecutor(max_workers=WRITERS) as pool:
        paths = list(pool.map(_writer(evidence_root), range(WRITERS)))

    assert len(set(paths)) == WRITERS, (
        f"{WRITERS} writers were given {len(set(paths))} distinct names — two "
        "processes agreed on a filename and one overwrote the other's evidence"
    )

    for path in paths:
        assert path.exists(), f"{path.name} was written and is no longer there"

    # Every writer is accounted for exactly once. A surviving file is a valid
    # artefact of *some* run, so counting files is not enough: the test has to
    # show that no run's record was lost.
    recorded = sorted(json.loads(p.read_text())["result"]["writer"] for p in paths)
    assert recorded == list(range(WRITERS)), (
        f"the folder describes writers {recorded}, not every one of them"
    )


def test_the_markdown_half_survives_too(evidence_root) -> None:
    """Both writes race, so both need the same protection.

    The `.md` file is the one a person opens. An artefact whose JSON survived
    and whose Markdown was overwritten by a different run is worse than a
    missing pair: it reads as a coherent record of a run that did not happen.
    """
    with ThreadPoolExecutor(max_workers=WRITERS) as pool:
        paths = list(pool.map(_writer(evidence_root), range(WRITERS)))

    for path in paths:
        markdown = path.with_suffix(".md")
        assert markdown.exists(), f"{markdown.name} is missing"

        body = json.loads(path.read_text())
        assert f"writer {body['result']['writer']}" in markdown.read_text(), (
            f"{markdown.name} describes a different run than {path.name} — the "
            "two halves of one artefact came from different writers"
        )


def test_every_artefact_still_verifies(evidence_root) -> None:
    """A racing writer must not leave a half-written or double-written file."""
    with ThreadPoolExecutor(max_workers=WRITERS) as pool:
        paths = list(pool.map(_writer(evidence_root), range(WRITERS)))

    for path in paths:
        ok, why = evidence_io.verify(path)
        assert ok, f"{path.name} does not verify: {why}"


def test_a_single_writer_still_gets_the_plain_name(evidence_root) -> None:
    """The control: the fix must not have made every filename a numbered one."""
    path = _writer(evidence_root)(0)
    assert path.name == f"{evidence_io.stamp(MOMENT)}-{CONTROL}.json", path.name


def test_sequential_runs_in_one_second_still_do_not_collide(evidence_root) -> None:
    """The A1 property, unchanged. It was right; it was just not enough."""
    first = _writer(evidence_root)(0)
    second = _writer(evidence_root)(1)

    assert first != second
    assert first.exists() and second.exists()
    assert json.loads(first.read_text())["result"]["writer"] == 0
    assert json.loads(second.read_text())["result"]["writer"] == 1
