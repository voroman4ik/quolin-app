"""The resolver, and the one thing it is not allowed to do.

Two halves. The first builds throwaway packs so a single ordering rule can be
tested on its own — real packs carry ten rules and a real decision exercises
all of them at once, which makes a failure hard to read. The second half checks
the seeded cross-border cast, because a rule that works in isolation and not on
the demo data is not working.

The load-bearing test in this file is the one that asserts the resolver
*refuses* to order a share-of-portfolio cap against a cash cap. Everything else
here protects a feature. That one protects the claim.
"""

from __future__ import annotations

from datetime import date

import pytest

from app import evidence, packs_repo, service
from app.engine import Pack, match_packs, resolve_across, select_packs
from app.engine.crossborder import NO_COMMON_SCALE, NOT_ORDERABLE, SINGLE_CONSTRAINT

# --- synthetic packs -----------------------------------------------------

DIRECTIONS = {"bps": "lower_is_stricter", "band": "higher_is_stricter", "days": "lower_is_stricter"}


def make_pack(
    pack_id: str,
    rules: list[dict],
    *,
    thresholds: dict | None = None,
    covers_states: list[str] | None = None,
    precedence: dict | None = None,
) -> Pack:
    return Pack.from_body(
        {
            "pack_id": pack_id,
            "version": 1,
            "effective_from": "2026-01-01",
            "effective_to": None,
            "signed_by": "test",
            "signed_at": "",
            "thresholds": thresholds or {},
            "asset_classes": {"X": {"class": "thing", "volatility_band": 2, "leverage": False}},
            "rules": rules,
            "covers_states": covers_states or [],
            "precedence": {"scales": DIRECTIONS} if precedence is None else precedence,
        }
    )


def rule(rule_id: str, dimension: str, scale: str, magnitude: int | None) -> dict:
    constraint = {"dimension": dimension, "scale": scale}
    if magnitude is not None:
        constraint["magnitude"] = {"const": magnitude}
    return {
        "rule_id": rule_id,
        "title": rule_id,
        "applies_to": {},
        "predicate": {"op": "eq", "left": {"const": 1}, "right": {"const": 1}},
        "constraint": constraint,
        "on_fail": "BLOCK",
        "reason_code": f"{rule_id}_FAILED",
        "severity": 1,
    }


def evaluation(pack: Pack, outcome: str, results: list[tuple[str, bool, str]]) -> dict:
    return {
        "outcome": outcome,
        "rule_results": [
            {
                "rule_id": rid,
                "title": rid,
                "passed": passed,
                "outcome": rule_outcome,
                "reason_code": None if passed else f"{rid}_FAILED",
            }
            for rid, passed, rule_outcome in results
        ],
        "rules_not_applicable": [],
    }


SNAPSHOT = {
    "licensee": {"jurisdiction": "ONE"},
    "client": {"residency": "TWO", "domicile": "ONE"},
    "jurisdictions": {},
}


# --- ordering ------------------------------------------------------------


def test_the_strictest_constraint_binds_and_the_others_are_recorded():
    one = make_pack("ONE", [rule("ONE-C-01", "concentration_cap", "bps", 1000)])
    two = make_pack("TWO", [rule("TWO-C-01", "concentration_cap", "bps", 500)])

    result = resolve_across(
        snapshot=SNAPSHOT,
        evaluations=[
            (one, evaluation(one, "ALLOW", [("ONE-C-01", True, "ALLOW")])),
            (two, evaluation(two, "ALLOW", [("TWO-C-01", True, "ALLOW")])),
        ],
        governing=one,
    )

    dimension = result["dimensions"][0]
    assert dimension["orderable"] is True
    assert dimension["ordering"] == "lower_is_stricter"
    assert [e["jurisdiction"] for e in dimension["binding"]] == ["TWO"]
    # Not dropped. "We looked and it did not bind" is a different statement from
    # "we did not look", and a regulator is entitled to the first one.
    assert [e["jurisdiction"] for e in dimension["evaluated_not_binding"]] == ["ONE"]


def test_direction_comes_from_the_governing_pack_not_from_arithmetic():
    """Same two numbers, opposite answers, because the two regimes disagree."""
    rules_one = [rule("ONE-B-01", "loss_capacity_floor", "band", 2)]
    rules_two = [rule("TWO-B-01", "loss_capacity_floor", "band", 4)]

    higher = make_pack("ONE", rules_one, precedence={"scales": {"band": "higher_is_stricter"}})
    lower = make_pack("ONE", rules_one, precedence={"scales": {"band": "lower_is_stricter"}})
    other = make_pack("TWO", rules_two)

    def binding_under(governing):
        result = resolve_across(
            snapshot=SNAPSHOT,
            evaluations=[
                (governing, evaluation(governing, "ALLOW", [("ONE-B-01", True, "ALLOW")])),
                (other, evaluation(other, "ALLOW", [("TWO-B-01", True, "ALLOW")])),
            ],
            governing=governing,
        )
        return [e["jurisdiction"] for e in result["dimensions"][0]["binding"]]

    assert binding_under(higher) == ["TWO"]
    assert binding_under(lower) == ["ONE"]


def test_a_failure_is_not_made_irrelevant_by_someone_else_being_stricter():
    one = make_pack("ONE", [rule("ONE-C-01", "concentration_cap", "bps", 1000)])
    two = make_pack("TWO", [rule("TWO-C-01", "concentration_cap", "bps", 500)])

    # ONE's cap is the laxer one and ONE's rule still failed. Both bind.
    result = resolve_across(
        snapshot=SNAPSHOT,
        evaluations=[
            (one, evaluation(one, "BLOCK", [("ONE-C-01", False, "BLOCK")])),
            (two, evaluation(two, "ALLOW", [("TWO-C-01", True, "ALLOW")])),
        ],
        governing=one,
    )

    dimension = result["dimensions"][0]
    assert {e["jurisdiction"] for e in dimension["binding"]} == {"ONE", "TWO"}
    assert dimension["evaluated_not_binding"] == []
    assert result["outcome"] == "BLOCK"


def test_a_lone_constraint_says_it_had_nothing_to_order_against():
    one = make_pack("ONE", [rule("ONE-T-01", "target_market", "band", 3)])
    two = make_pack("TWO", [])

    result = resolve_across(
        snapshot=SNAPSHOT,
        evaluations=[
            (one, evaluation(one, "ALLOW", [("ONE-T-01", True, "ALLOW")])),
            (two, evaluation(two, "ALLOW", [])),
        ],
        governing=one,
    )
    assert result["dimensions"][0]["reason"] == SINGLE_CONSTRAINT


# --- refusing to order ---------------------------------------------------


def test_a_share_cap_and_a_cash_cap_are_not_ranked():
    """The claim. A percentage and a dollar figure have no common ordering.

    Both bind, neither is called stricter, and the record says why. Inventing a
    comparison here would be the single most damaging thing this engine could
    do: it would produce a defensible-looking number that no compliance officer
    could defend when asked where it came from.
    """
    one = make_pack("ONE", [rule("ONE-E-01", "first_exposure_limit", "cents", 500_000)])
    two = make_pack("TWO", [rule("TWO-E-01", "first_exposure_limit", "bps", 200)])

    result = resolve_across(
        snapshot=SNAPSHOT,
        evaluations=[
            (one, evaluation(one, "REFER", [("ONE-E-01", False, "REFER")])),
            (two, evaluation(two, "REFER", [("TWO-E-01", False, "REFER")])),
        ],
        governing=one,
    )

    dimension = result["dimensions"][0]
    assert dimension["orderable"] is False
    assert dimension["ordering"] == "none"
    assert dimension["reason"] == NO_COMMON_SCALE
    assert dimension["scales"] == ["bps", "cents"]
    assert dimension["direction"] is None
    assert {e["jurisdiction"] for e in dimension["binding"]} == {"ONE", "TWO"}
    assert result["unordered_dimensions"] == ["first_exposure_limit"]
    # The sentence has to name both units and refuse to pick between them.
    # Asserted by content rather than by exact wording, so improving the prose
    # does not break the test — but dropping a unit, or claiming one of the two
    # is the stricter, still does.
    rationale = dimension["rationale"]
    assert "bps" in rationale and "cents" in rationale
    assert "independently binding" in rationale
    assert "so ONE binds" not in rationale and "so TWO binds" not in rationale


def test_a_qualitative_constraint_is_never_ordered():
    """No pack declares a direction for `qualitative`, so none can be invented."""
    one = make_pack("ONE", [rule("ONE-K-01", "knowledge_requirement", "qualitative", None)])
    two = make_pack("TWO", [rule("TWO-K-01", "knowledge_requirement", "qualitative", None)])

    result = resolve_across(
        snapshot=SNAPSHOT,
        evaluations=[
            (one, evaluation(one, "ALLOW", [("ONE-K-01", True, "ALLOW")])),
            (two, evaluation(two, "BLOCK", [("TWO-K-01", False, "BLOCK")])),
        ],
        governing=one,
    )
    dimension = result["dimensions"][0]
    assert dimension["orderable"] is False
    assert dimension["reason"] == NOT_ORDERABLE


def test_an_unresolvable_magnitude_stops_the_ordering_rather_than_shrinking_it():
    """Ordering a subset and presenting it as the answer would hide the rest."""
    one = make_pack("ONE", [rule("ONE-C-01", "concentration_cap", "bps", 1000)])
    missing = rule("TWO-C-01", "concentration_cap", "bps", None)
    missing["constraint"]["magnitude"] = {"threshold": "not_a_real_threshold"}
    two = make_pack("TWO", [missing])

    result = resolve_across(
        snapshot=SNAPSHOT,
        evaluations=[
            (one, evaluation(one, "ALLOW", [("ONE-C-01", True, "ALLOW")])),
            (two, evaluation(two, "ALLOW", [("TWO-C-01", True, "ALLOW")])),
        ],
        governing=one,
    )
    dimension = result["dimensions"][0]
    assert dimension["orderable"] is False
    assert dimension["reason"] == NOT_ORDERABLE
    assert len(dimension["binding"]) == 2


def test_a_rule_with_no_dimension_is_recorded_rather_than_dropped():
    naked = rule("ONE-Z-01", "x", "bps", 1)
    naked.pop("constraint")
    one = make_pack("ONE", [naked])

    result = resolve_across(
        snapshot=SNAPSHOT,
        evaluations=[(one, evaluation(one, "BLOCK", [("ONE-Z-01", False, "BLOCK")]))],
        governing=one,
    )
    assert result["dimensions"] == []
    assert result["rules_not_applicable"][0]["rule_id"] == "ONE-Z-01"
    # It still counts towards the determination even though it cannot be ranked.
    assert result["outcome"] == "BLOCK"


# --- selection -----------------------------------------------------------


def test_a_bloc_pack_is_matched_by_member_state():
    bloc = make_pack("BLOC", [], covers_states=["AA", "BB", "CC"])
    matched, unmatched = match_packs(["BB"], {"BLOC": bloc})
    assert matched == [bloc] and unmatched == []


def test_a_code_with_no_pack_is_reported_not_swallowed():
    one = make_pack("ONE", [])
    matched, unmatched = match_packs(["ONE", "NOWHERE"], {"ONE": one})
    assert matched == [one]
    assert unmatched == ["NOWHERE"]


def test_selection_reads_the_snapshot_and_nothing_else():
    one = make_pack("ONE", [])
    two = make_pack("TWO", [])
    matched, _ = select_packs(SNAPSHOT, {"ONE": one, "TWO": two})
    # Licensee first: it governs artefacts and supplies precedence.
    assert [p.pack_id for p in matched] == ["ONE", "TWO"]


def test_one_client_who_is_all_three_things_resolves_to_one_pack():
    one = make_pack("ONE", [])
    snapshot = {
        "licensee": {"jurisdiction": "ONE"},
        "client": {"residency": "ONE", "domicile": "ONE"},
    }
    matched, unmatched = select_packs(snapshot, {"ONE": one})
    assert matched == [one] and unmatched == []


def test_provenance_says_which_fact_pulled_each_regime_in():
    one = make_pack("ONE", [])
    two = make_pack("TWO", [])
    result = resolve_across(
        snapshot=SNAPSHOT,
        evaluations=[
            (one, evaluation(one, "ALLOW", [])),
            (two, evaluation(two, "ALLOW", [])),
        ],
        governing=one,
    )
    by_code = {a["jurisdiction"]: a for a in result["applicable"]}
    assert by_code["ONE"]["basis"] == ["licensee", "domicile"]
    assert by_code["ONE"]["governing"] is True
    assert by_code["TWO"]["basis"] == ["residency"]
    assert by_code["TWO"]["governing"] is False


# --- the seeded cast -----------------------------------------------------


@pytest.fixture(scope="module")
def cross_border(session):
    rows = {
        d.client_id: d
        for d in session.query(evidence.Decision).order_by(evidence.Decision.id)
        if d.resolution
    }
    if not rows:
        pytest.fail("no cross-border decisions seeded — run `make seed` first")
    return rows


def test_the_three_regime_client_differs_by_regime(cross_border):
    """The demo moment: allowed by one regulator, blocked by another."""
    decision = cross_border["wei-lin-chow"]
    by_jurisdiction = decision.resolution["outcome_by_jurisdiction"]

    assert by_jurisdiction == {"AU": "ALLOW", "HK": "BLOCK", "SG": "REFER"}
    assert decision.outcome == "BLOCK", "the strictest regime has to carry the determination"
    assert len(set(by_jurisdiction.values())) == 3, (
        "a demo where every regime agrees proves nothing"
    )


def test_the_three_regime_client_carries_both_kinds_of_answer(cross_border):
    dimensions = {d["dimension"]: d for d in cross_border["wei-lin-chow"].resolution["dimensions"]}

    ordered = dimensions["loss_capacity_floor"]
    assert ordered["orderable"] is True
    assert [e["jurisdiction"] for e in ordered["binding"]] == ["HK"]

    refused = dimensions["first_exposure_limit"]
    assert refused["orderable"] is False
    assert refused["reason"] == NO_COMMON_SCALE
    assert {e["jurisdiction"] for e in refused["binding"]} == {"HK", "SG"}


def test_a_member_state_client_is_governed_by_the_bloc_pack(cross_border):
    resolution = cross_border["ingrid-halvorsen"].resolution
    codes = {a["jurisdiction"] for a in resolution["applicable"]}

    # "DE" appears twice on the client and once in the requested list: a code is
    # a regime, and asking the same regime twice is still one regime.
    assert resolution["requested"] == ["AU", "DE"]
    assert codes == {"AU", "EU"}, "DE must be answered by the bloc pack, not left unmatched"
    assert resolution["unmatched"] == []
    bloc = next(a for a in resolution["applicable"] if a["jurisdiction"] == "EU")
    assert len(bloc["covers_states"]) > 20
    assert bloc["basis"] == ["residency", "domicile"]


def test_precedence_follows_the_licensee_not_the_reference_regime(cross_border):
    """A Singapore-licensed relationship is ordered by Singapore's precedence."""
    resolution = cross_border["marcus-tan"].resolution
    assert resolution["precedence_source"]["jurisdiction"] == "SG"
    assert resolution["governing"]["jurisdiction"] == "SG"
    assert "AU" not in resolution["outcome_by_jurisdiction"]


def test_a_regime_with_no_pack_is_stated_on_the_decision(cross_border):
    resolution = cross_border["marcus-tan"].resolution
    assert resolution["unmatched"] == ["US"]
    assert "US" in resolution["requested"]


def test_unreviewed_regimes_are_named_on_every_decision_they_touched(cross_border):
    for client_id, decision in cross_border.items():
        illustrative = set(decision.resolution["illustrative"])
        applied = {a["jurisdiction"] for a in decision.resolution["applicable"]}
        assert illustrative == applied - {"AU"}, client_id


def test_a_single_regime_client_gets_no_resolution(session):
    """Cross-border is about how many regimes reach a client, not which one."""
    decision = session.query(evidence.Decision).filter_by(client_id="chen-yu-hsuan").first()
    assert decision is not None
    assert decision.pack_id == "HK"
    assert decision.resolution is None
    assert (decision.rule_results or {}).get("other_jurisdictions") is None


def test_the_protected_cast_stayed_single_jurisdiction(session):
    """Tom Askew and Harold Bell carry the two moments the demo opens with."""
    for client_id in ("tom-askew", "harold-bell"):
        rows = session.query(evidence.Decision).filter_by(client_id=client_id).all()
        assert rows, client_id
        for decision in rows:
            assert decision.resolution is None, f"{client_id} gained a second regime"
            assert (decision.pack_id or "AU") == "AU"


def test_every_applicable_pack_was_actually_evaluated(session, cross_border):
    """A pack named in the provenance that never ran would be a lie on the page."""
    for client_id, decision in cross_border.items():
        named = {a["jurisdiction"] for a in decision.resolution["applicable"]}
        evaluated = set(decision.resolution["outcome_by_jurisdiction"])
        assert named == evaluated, client_id

        stored_others = set((decision.rule_results or {}).get("other_jurisdictions") or {})
        governing = service._governing_pack_id(decision)
        assert stored_others | {governing} == named, client_id


def test_the_recorded_resolution_matches_a_fresh_one(session, cross_border):
    """Same snapshot, same packs, same answer — or the resolver is not a function."""
    for client_id, decision in cross_border.items():
        pack = packs_repo.by_version(
            session, service._governing_pack_id(decision), decision.pack_version
        )
        result = evidence.replay(decision, pack, service._other_packs(session, decision))
        assert result["match"], (client_id, result["differences"])


def test_packs_are_read_back_at_the_version_of_record(session, cross_border):
    for decision in cross_border.values():
        for code, stored in (decision.rule_results["other_jurisdictions"]).items():
            pack = packs_repo.by_version(session, code, stored["pack_version"])
            assert pack.version == stored["pack_version"]
            assert pack.content_status == stored["content_status"]
            assert pack.effective_from <= decision.as_of
            assert pack.effective_to is None or pack.effective_to >= decision.as_of


def test_todays_shelf_carries_every_regime_the_cast_needs(session):
    shelf = packs_repo.active_all(session, date.today())
    assert set(shelf) == {"AU", "HK", "SG", "EU"}


# --- the findings a reader actually sees ----------------------------------


def test_a_cross_border_block_is_never_shown_with_no_findings(session, cross_border):
    """The screen that would have lost the room.

    Findings used to be taken from the governing pack alone. On Wei-Lin Chow
    that pack is the one regime which allowed the trade, so a red BLOCK banner
    sat directly above a green panel reading "every applicable rule passed" —
    true of AU, and a lie about the determination it was printed under.
    """
    for client_id, decision in cross_border.items():
        view = service.decision_view(session, decision)
        if view["outcome"] == "ALLOW":
            continue
        assert view["reasons"], f"{client_id} is a {view['outcome']} with nothing to show"


def test_every_finding_names_the_regime_that_raised_it(session, cross_border):
    """A finding attributed to the wrong regulator is worse than no attribution."""
    for client_id, decision in cross_border.items():
        view = service.decision_view(session, decision)
        applicable = {a["jurisdiction"] for a in decision.resolution["applicable"]}

        for reason in view["reasons"]:
            assert reason["jurisdiction"] in applicable, (client_id, reason["rule_id"])
            # The pack that raised it, read back at the version of record.
            pack = packs_repo.by_version(
                session, reason["jurisdiction"], reason["pack_version"]
            )
            assert reason["rule_id"] in {r["rule_id"] for r in pack.rules}


def test_the_findings_are_the_union_across_regimes(session, cross_border):
    """Nothing any applicable regime found is dropped on the way to the page."""
    for client_id, decision in cross_border.items():
        view = service.decision_view(session, decision)
        shown = {(r["jurisdiction"], r["rule_id"]) for r in view["reasons"]}
        expected = {
            (j["jurisdiction"], r["rule_id"])
            for j in view["jurisdictions"]
            for r in j["reasons"]
        }
        assert shown == expected, client_id


def test_findings_are_ordered_worst_first(session, cross_border):
    """A reader meets the finding that produced the determination first."""
    rank = {"BLOCK": 0, "REFER": 1, "ALLOW": 2}
    for client_id, decision in cross_border.items():
        view = service.decision_view(session, decision)
        ranks = [rank[r["outcome"]] for r in view["reasons"]]
        assert ranks == sorted(ranks), client_id
        if view["outcome"] in rank and view["reasons"]:
            assert view["reasons"][0]["outcome"] == view["outcome"], client_id


def test_a_single_regime_decision_keeps_its_findings_unlabelled(session):
    """The AU-only cast is untouched: no jurisdiction key appears on a finding.

    Tom Askew and Harold Bell open the demo. A cross-border field appearing on
    their determinations would be a cross-border claim about a client who has
    only ever answered to one regulator.
    """
    for client_id in ("tom-askew", "harold-bell"):
        rows = session.query(evidence.Decision).filter_by(client_id=client_id).all()
        assert rows, client_id
        for decision in rows:
            view = service.decision_view(session, decision)
            assert view["cross_border"] is False
            for reason in view["reasons"]:
                assert "jurisdiction" not in reason
