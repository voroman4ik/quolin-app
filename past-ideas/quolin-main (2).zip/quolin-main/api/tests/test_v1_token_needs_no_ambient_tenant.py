"""An integration must be able to authenticate on a server nobody has primed.

Found by execution, while writing the cross-site tests, and confirmed against a
real server over HTTP rather than through a test client:

    POST /v1/oauth/token   {"grant_type": "client_credentials", ...}
    -> 401 {"code": "invalid_client", "message": "Those credentials are not
            correct."}

with a credential that was active, unexpired, and whose secret verified. **Every
integration on a real deployment was refused.** The whole of §S4 — the API, the
webhooks, the nightly batch drop, everything a customer builds against — was
unreachable from a process that had not first been made to act for a tenant.

The cause is one line in the wrong place. `app.tenant_id` is bound on the
engine's `begin` event, so whichever statement opens the transaction fixes the
tenant for every statement after it. `issue_token` called `check_rate_limit`
before entering the tenant scope; that check queries `auth_attempts`, which
opened the transaction with `app.tenant_id = ''`. The `api_clients` lookup that
followed was inside `acting_as(...)` but in the *same* transaction, so it ran
under the empty tenant, matched nothing — `api_clients` is tenant-scoped — and
the endpoint reported the credential as wrong.

**The suite could not have caught this, and that is the more useful finding.**
`tests/conftest.py` opens `tenancy.acting_as(DEMO_TENANT)` in a session-scoped
fixture and holds it for the entire run, so under pytest there is always an
ambient tenant and the transaction opened correctly bound. Twenty-eight tests in
`test_v1.py` exercise this endpoint and all of them passed against an endpoint
that did not work.

So this file clears the ambient tenant on purpose. That is the state a real
process is in: the middleware binds nothing on a public path, and
`/v1/oauth/token` is public because it is how a session comes to exist.
"""

from __future__ import annotations

import pytest
from conftest import reset_rate_limit_for_tests
from fastapi.testclient import TestClient
from sqlalchemy import text

from app import passwords, tenancy
from app.db import OwnerSessionLocal
from app.main import app
from app.models import ApiClient
from tests.conftest import DEMO_TENANT

ACTOR = "apc_bulk_sweep"
CREDENTIAL = "apc_no_ambient_probe"
SECRET = "an integration secret, not a real one"


@pytest.fixture
def credential() -> str:
    """An active integration credential, created and left in place.

    Left rather than deleted for the reason `test_v1.py` gives: a credential
    that has acted cannot be removed without leaving the audit trail naming an
    actor that no longer exists.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            row = owner.get(ApiClient, CREDENTIAL)
            if row is None:
                owner.add(
                    ApiClient(
                        id=CREDENTIAL,
                        label="No-ambient-tenant probe",
                        secret_hash=passwords.hash_password(SECRET, email=CREDENTIAL),
                        roles=["operator", "viewer"],
                        status="active",
                        created_by="test",
                    )
                )
            else:
                row.secret_hash = passwords.hash_password(SECRET, email=CREDENTIAL)
                row.roles = ["operator", "viewer"]
                row.status = "active"
            owner.commit()
    finally:
        owner.close()
    return CREDENTIAL


@pytest.fixture
def no_ambient_tenant():
    """The state a real server is in, restored afterwards.

    Reaching into the context variable rather than using `acting_as`, because
    there is no `acting_as(nothing)` and the point is precisely the absence.
    `tests/test_worker_tenant_enumeration.py` does the same and for the same
    reason: a test about what happens with no tenant bound cannot run inside a
    fixture that binds one.
    """
    token = tenancy._current.set(None)
    try:
        yield
    finally:
        tenancy._current.reset(token)


def test_the_suite_normally_holds_a_tenant_open_for_the_whole_run(session) -> None:
    """Why this file exists, asserted rather than described.

    If this ever stops being true, the fixture above becomes unnecessary — and
    far more importantly, the twenty-eight tests in `test_v1.py` start
    exercising the endpoint in the state a real process is in.
    """
    assert tenancy.current_tenant_or_none() == DEMO_TENANT, (
        "conftest no longer holds an ambient tenant. Check whether "
        "`no_ambient_tenant` below is still doing anything."
    )
    assert session is not None


def test_a_credential_authenticates_with_no_tenant_bound(
    credential, no_ambient_tenant
) -> None:
    """The finding, as a test."""
    reset_rate_limit_for_tests()
    assert tenancy.current_tenant_or_none() is None, "the fixture did not take"

    with TestClient(app) as machine:
        res = machine.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": SECRET,
            },
        )

    assert res.status_code == 200, (
        f"an active credential was refused with no ambient tenant: "
        f"{res.status_code} {res.text}. This is the state every real process is "
        "in — the middleware binds no tenant on a public path — so every "
        "integration on a deployed instance was told its credentials were wrong."
    )
    assert res.json()["access_token"]
    assert res.json()["token_type"] == "Bearer"


def test_the_token_is_usable_afterwards(credential, no_ambient_tenant) -> None:
    """A token that authenticates and then reads nothing is not a fix.

    The tenant on the session comes from the credential, so a token minted under
    the corrected ordering has to carry the firm with it.
    """
    reset_rate_limit_for_tests()
    with TestClient(app) as machine:
        token = machine.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": SECRET,
            },
        ).json()["access_token"]
        machine.headers["Authorization"] = f"Bearer {token}"
        listing = machine.get("/v1/clients")

    assert listing.status_code == 200, listing.text
    assert listing.json(), "the token authenticated and then saw an empty firm"


def test_a_wrong_secret_is_still_refused_with_no_tenant_bound(
    credential, no_ambient_tenant
) -> None:
    """The fix must open the transaction correctly, not open the door.

    A change that made the lookup succeed by widening what an untenanted
    connection can see would pass the test above and be a far worse defect than
    the one it repaired.
    """
    reset_rate_limit_for_tests()
    with TestClient(app) as machine:
        res = machine.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": "not the secret",
            },
        )
    assert res.status_code == 401, res.text


def test_the_transaction_is_bound_before_the_first_query(no_ambient_tenant) -> None:
    """The mechanism underneath, stated once so the reason is not folklore.

    `set_config(..., true)` is transaction-scoped and is issued on `begin`. A
    query run before the tenant is entered fixes the binding for every query
    after it, in the same transaction, however carefully the later ones are
    wrapped.
    """
    from app.db import SessionLocal

    session = SessionLocal()
    try:
        # Opens the transaction with nothing bound.
        session.execute(text("SELECT 1"))
        with tenancy.acting_as(DEMO_TENANT):
            bound = session.execute(
                text("SELECT current_setting('app.tenant_id', true)")
            ).scalar()
        assert bound == "", (
            "entering a tenant scope after the transaction opened changed the "
            "binding. If that is now true, the ordering rule this endpoint was "
            "fixed for no longer applies and the comment in `v1.issue_token` "
            "should be corrected."
        )
    finally:
        session.rollback()
        session.close()

    with tenancy.acting_as(DEMO_TENANT):
        fresh = SessionLocal()
        try:
            assert (
                fresh.execute(
                    text("SELECT current_setting('app.tenant_id', true)")
                ).scalar()
                == DEMO_TENANT
            )
        finally:
            fresh.close()
