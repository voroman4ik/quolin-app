"""A firm whose determinations have effect may not run on unreviewed rules.

The execution plan says no jurisdiction ships to a production tenant on
in-house content, however good the in-house content looks, and that the only
mechanism which can clear the flag is a signature. The flag existed — every
pack carries `content_status`, and the AU packs say `PENDING_REVIEW` with the
signatory recorded as `[DDO consultant — pending engagement]`. Nothing enforced
it. `packs_repo.active` selected on jurisdiction and date, and a live customer
would have been served those rules.

**What "production" means here is the adoption ladder, not a name.** §S10
already answers "does this firm's determination affect anybody" — `pilot` and
`shadow` withhold every outbound effect, `limited` and `full` do not. So the
gate is the rung, and it needs no new flag and no comparison against a tenant
id. A firm that cannot act on a determination may compute one against
illustrative rules; a firm that can, may not.
"""

from __future__ import annotations

from datetime import date

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import text

from app import adoption, packs_repo, service, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.models import Tenant

ACTOR = "apc_bulk_sweep"
LIVE = "unsigned-probe"
PROBE_CLIENT = "unsigned-probe-client"

#: AU ships as PENDING_REVIEW — authored as a reference implementation, nobody
#: qualified has signed it. That is the state this file is about.
UNREVIEWED_JURISDICTION = "AU"


@pytest.fixture(scope="module")
def live_tenant():
    """A firm at `full`, which is the rung where a determination has effect."""
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "INSERT INTO tenants (id, name, region, tier, status, stage, config, created_at) "
                "VALUES (:id, 'Unsigned Probe', 'ap-southeast-2', 'shared', 'active', "
                "'full', '{\"jurisdictions\": [\"AU\"]}'::jsonb, now()) "
                "ON CONFLICT (id) DO UPDATE SET stage = 'full'"
            ),
            {"id": LIVE},
        )
        owner.commit()
        with tenancy.acting_as(LIVE), tenancy.acting_as_user(ACTOR):
            from app import crypto, evidence

            crypto.ensure_key(owner, LIVE)
            evidence.ensure_anchor(owner, LIVE)
            owner.commit()
    finally:
        owner.close()

    # A client of its own. `tom-askew` belongs to the demo firm and row-level
    # security correctly hides him here — which the first version of this file
    # discovered by failing on the client lookup before it ever reached the
    # pack.
    with tenancy.acting_as(LIVE), tenancy.acting_as_user(ACTOR):
        from app.models import Client

        setup = SessionLocal()
        try:
            if setup.get(Client, PROBE_CLIENT) is None:
                setup.add(
                    Client(
                        id=PROBE_CLIENT,
                        name="A Probe Client",
                        scenario="probe",
                        jurisdiction="AU",
                        dob=date(1980, 6, 1),
                        client_category="retail",
                        knowledge_assessed=True,
                        knowledge_date=date(2026, 1, 1),
                        loss_capacity_band=4,
                        vulnerability_flag=False,
                        assessable_portfolio_cents=50_000_00,
                        prior_crypto_purchases=3,
                        structural_acks=[],
                        default_trade_amount_cents=1_000_00,
                    )
                )
                setup.commit()
        finally:
            setup.close()
    return LIVE


def test_a_live_firm_is_refused_unreviewed_rules(live_tenant):
    """The finding, directly."""
    with tenancy.acting_as(LIVE), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            with pytest.raises(packs_repo.NoReviewedPackAvailable) as refused:
                packs_repo.active(session, UNREVIEWED_JURISDICTION, date.today())
        finally:
            session.close()

    assert UNREVIEWED_JURISDICTION in str(refused.value), (
        "the refusal has to name the jurisdiction — an operator reading it needs "
        "to know which specialist to engage"
    )


def test_a_firm_that_cannot_act_may_still_evaluate(session):
    """The demo sits at `full` and is the exception the seed makes deliberately.

    Asserted through a pilot tenant rather than through demo, because the point
    is the rung and not the name.
    """
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text("UPDATE tenants SET stage = 'pilot' WHERE id = :id"), {"id": LIVE}
        )
        owner.commit()
    finally:
        owner.close()

    with tenancy.acting_as(LIVE), tenancy.acting_as_user(ACTOR):
        probe = SessionLocal()
        try:
            pack = packs_repo.active(probe, UNREVIEWED_JURISDICTION, date.today())
            assert pack.pack_id == UNREVIEWED_JURISDICTION
            assert not pack.is_production_grade
        finally:
            probe.close()

    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text("UPDATE tenants SET stage = 'full' WHERE id = :id"), {"id": LIVE}
        )
        owner.commit()
    finally:
        owner.close()


def test_the_shelf_refuses_the_same_way(live_tenant):
    """`active_all` feeds the cross-border resolver, so it is a second door."""
    with tenancy.acting_as(LIVE), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            shelf = packs_repo.active_all(session, date.today())
        finally:
            session.close()

    assert UNREVIEWED_JURISDICTION not in shelf, (
        "an unreviewed pack reached a live firm through the shelf, which is the "
        "door the single-jurisdiction check does not cover"
    )


def test_the_database_refuses_a_reviewed_pack_with_a_placeholder_signatory():
    """The third layer: a row claiming review with nobody's name on it.

    `[DDO consultant — pending engagement]` is the convention for a signatory
    who has not been engaged. A row marked REVIEWED carrying one is either a
    mistake or somebody routing around the specialist, and the database is the
    place to refuse it because it is the layer no code path can skip.
    """
    owner = OwnerSessionLocal()
    try:
        with pytest.raises(Exception) as refused:
            owner.execute(
                text(
                    # `content_status` is generated from the body, so the
                    # status goes where a specialist actually sets it.
                    "INSERT INTO packs "
                    "(jurisdiction, version, effective_from, body, signed_by, signed_at) "
                    "VALUES ('ZZ', 1, '2026-01-01', "
                    "'{\"content_status\": \"REVIEWED\"}'::jsonb, "
                    "'[nobody — pending engagement]', '2026-01-01')"
                )
            )
            owner.commit()
    finally:
        owner.rollback()
        owner.close()

    assert "packs_reviewed_needs_a_signatory" in str(refused.value), refused.value


def test_a_live_firm_cannot_evaluate_at_all_on_unreviewed_content(live_tenant):
    """End to end: the refusal reaches the caller rather than a determination."""
    with tenancy.acting_as(LIVE), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            tenant = session.get(Tenant, LIVE)
            assert adoption.stage_of(tenant) == adoption.FULL
            with pytest.raises(packs_repo.NoReviewedPackAvailable):
                service.evaluate(
                    session,
                    client_id=PROBE_CLIENT,
                    asset_id="BTC",
                    as_of=date.today(),
                )
        finally:
            session.rollback()
            session.close()


def test_the_demo_still_works(session):
    """The three-tap regression's foundation: demo evaluates as it always did."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        pack = packs_repo.active(session, UNREVIEWED_JURISDICTION, date.today())
        assert pack.pack_id == UNREVIEWED_JURISDICTION


def test_a_document_is_not_produced_from_unsigned_rules(live_tenant):
    """§S13's rule reaching the artefact path.

    A determination refused at the loader is visible; a document produced by
    quietly falling back past the refusal is worse, because it carries a
    template, a title and the firm's name on it. `runner._scope` catches
    `LookupError` to answer "no pack is effective on this date" with a default
    scope, and the refusal subclasses it — so it has to be re-raised by name
    rather than swallowed with everything else.
    """
    from app.artefacts import runner
    from app.models import ArtefactJob

    with tenancy.acting_as(LIVE), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            job = ArtefactJob(
                kind="period_return",
                params={"jurisdiction": "AU", "period": "2026-Q1"},
                fingerprint="probe",
                subject="probe",
                status="queued",
            )
            with pytest.raises(packs_repo.NoReviewedPackAvailable):
                runner._scope(session, job)
        finally:
            session.rollback()
            session.close()
