"""Recording that a person checked a source nothing can poll.

§S13 declared some publications `MANUAL` — behind a login, or a search portal
whose front page moves without anything being published — and left this
unbuilt, saying so rather than pretending otherwise. The seed asserted a date so
the state was visible on screen; a real deployment would have watched its manual
sources drift to STALE with no way to say otherwise, which is honest and
useless.

Held to the same bar as signing rule content, because it is the same kind of
statement: a named person claiming what a regulator had published on a date,
which a compliance officer may later rely on.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

import pytest
from conftest import (
    DEMO_TENANT,
    SEED_PASSWORD,
    reset_rate_limit_for_tests,
    second_factor_code,
    sign_in,
)
from fastapi.testclient import TestClient
from sqlalchemy import select, text

from app import business_time, identity, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import AuditEvent, SourceVerification, WatchSource
from app.watch import fetchers, sources

ACTOR = "apc_bulk_sweep"
SIGNATORY = "aoife.brennan@quolin.example"


def _manual_source(session) -> WatchSource:
    """The source the shipped AU pack declares MANUAL."""
    row = session.scalars(
        select(WatchSource).where(WatchSource.polling_status == fetchers.MANUAL)
    ).first()
    assert row is not None, "no manual source — run `make seed`"
    return row


def _automatic_source(session) -> WatchSource:
    row = session.scalars(
        select(WatchSource).where(WatchSource.polling_status == fetchers.AUTOMATIC)
    ).first()
    assert row is not None
    return row


@pytest.fixture
def undo(session):
    """Remove attestations this file wrote, as the owner.

    `source_verifications` is append-only to the application role by trigger
    *and* revoked grant — which is the property working, and is why this takes
    the same route `scripts/rechain.py` does.

    **The shared session is rolled back first, and the lock has a timeout.**
    `ALTER TABLE … DISABLE TRIGGER` needs an ACCESS EXCLUSIVE lock, so a test
    that leaves a transaction open on this table makes teardown wait for it
    forever. That is exactly what happened while checking these tests against
    deliberately broken code: the suite *hung* rather than failing, which is
    worse than the mess the cleanup existed to remove. Rolling back removes the
    usual cause; the timeout makes the remaining ones fail loudly.
    """
    yield
    session.rollback()
    owner = OwnerSessionLocal()
    try:
        owner.execute(text("SET lock_timeout = '5s'"))
        owner.execute(
            text(
                "ALTER TABLE source_verifications "
                "DISABLE TRIGGER source_verifications_append_only"
            )
        )
        owner.execute(text("DELETE FROM source_verifications"))
        owner.execute(
            text(
                "ALTER TABLE source_verifications "
                "ENABLE TRIGGER source_verifications_append_only"
            )
        )
        owner.commit()
    finally:
        owner.close()


def test_a_verification_makes_a_manual_source_current(session, undo):
    """The whole point: a person looking is what keeps this source fresh."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        row = _manual_source(session)
        row.last_checked_at = datetime.now(timezone.utc) - timedelta(days=400)
        session.flush()
        assert (
            sources.freshness(
                row.last_checked_at,
                row.cadence_days,
                datetime.now(timezone.utc),
                polling_status=row.polling_status,
            )
            == sources.STALE
        )

        sources.verify_manually(
            session,
            row.id,
            verified_on=date.today(),
            verified_by=ACTOR,
            note="Read against the instruments this pack cites.",
        )

        after = sources.freshness(
            row.last_checked_at,
            row.cadence_days,
            datetime.now(timezone.utc),
            polling_status=row.polling_status,
        )

    # MANUAL, never CURRENT. Somebody remembering to check is not the same
    # assurance as a check that happens on its own, and §S13's severity order
    # exists to stop the badge saying it is.
    assert after == sources.MANUAL
    session.rollback()


def test_a_polled_source_cannot_be_attested_to(session, undo):
    """The refusal that stops an attestation covering for a broken poller.

    A human claim over an automatic source asserts what the poller already
    establishes — and worse, resets the freshness clock, so a poller that had
    silently stopped would show green because somebody said so.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        row = _automatic_source(session)
        with pytest.raises(sources.NotManual):
            sources.verify_manually(
                session, row.id, verified_on=date.today(), verified_by=ACTOR
            )
    session.rollback()


def test_a_future_date_is_refused(session, undo):
    """Freshness nobody has earned."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        row = _manual_source(session)
        with pytest.raises(ValueError) as refused:
            sources.verify_manually(
                session,
                row.id,
                verified_on=date.today() + timedelta(days=3),
                verified_by=ACTOR,
            )
    assert "future" in str(refused.value)
    session.rollback()


def test_recording_an_older_check_does_not_make_a_source_staler(session, undo):
    """Somebody catching up on paperwork must not undo a newer attestation."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        row = _manual_source(session)
        sources.verify_manually(
            session, row.id, verified_on=date.today(), verified_by=ACTOR
        )
        newest = row.last_checked_at

        sources.verify_manually(
            session,
            row.id,
            verified_on=date.today() - timedelta(days=30),
            verified_by=ACTOR,
            note="Friday's check, recorded late.",
        )

        assert row.last_checked_at == newest, "an older record moved the clock back"
        # And both attestations are kept. The older one is a real statement
        # somebody made, and losing it would be losing the record it exists as.
        assert len(sources.verifications(session, row.id)) == 2
    session.rollback()


def test_the_record_cannot_be_edited(session, undo):
    """Append-only, like every other attestation here."""
    from sqlalchemy.exc import SQLAlchemyError

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        row = _manual_source(session)
        recorded = sources.verify_manually(
            session, row.id, verified_on=date.today(), verified_by=ACTOR
        )
        session.commit()

        with pytest.raises(SQLAlchemyError):
            session.execute(
                text(
                    "UPDATE source_verifications SET note = 'something else' "
                    "WHERE id = :id"
                ),
                {"id": recorded.id},
            )
            session.commit()
    session.rollback()


def test_a_signatory_for_the_regime_can_record_one(session, undo):
    """End to end, as the person who would actually do it."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        source_id = _manual_source(session).id
        jurisdiction = _manual_source(session).jurisdiction

    reset_rate_limit_for_tests()
    with TestClient(app) as client:
        sign_in(client, SIGNATORY)
        response = client.post(
            f"/currency/sources/{source_id}/verify",
            json={
                "verified_on": date.today().isoformat(),
                "note": "Checked against the register.",
                "attachment_ref": "TICKET-4471",
            },
        )

    assert response.status_code == 200, response.text
    body = response.json()
    assert body["source_id"] == source_id
    assert body["freshness"] == sources.MANUAL
    assert body["verified_by"], "an attestation with nobody's name on it"

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        probe = SessionLocal()
        try:
            stored = probe.scalars(
                select(SourceVerification)
                .where(SourceVerification.source_id == source_id)
                .order_by(SourceVerification.id.desc())
                .limit(1)
            ).first()
            trail = probe.scalars(
                select(AuditEvent)
                .where(AuditEvent.action == "watch.source.verified")
                .order_by(AuditEvent.id.desc())
                .limit(1)
            ).first()
        finally:
            probe.close()

    assert stored is not None
    assert stored.attachment_ref == "TICKET-4471"
    # Chained with the rest of the audit trail — §S13's audit chain covers this
    # the same way it covers a determination.
    assert trail is not None and trail.this_hash, "the attestation left no chained row"
    assert jurisdiction  # the grant that allowed it named this regime


def test_somebody_who_is_not_a_signatory_is_refused(session, undo):
    """Competence to attest for a regime is a grant, not a login."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        source_id = _manual_source(session).id

    reset_rate_limit_for_tests()
    with TestClient(app) as client:
        sign_in(client, "dana.whitfield@quolin.example")  # an operator
        refused = client.post(
            f"/currency/sources/{source_id}/verify",
            json={"verified_on": date.today().isoformat()},
        )

    assert refused.status_code == 403, refused.text


def test_a_signatory_for_another_regime_is_refused(session, undo):
    """The route table cannot see which regime a source belongs to.

    So the handler checks it — the same shape as signing a draft, where a
    signatory for one jurisdiction may not sign for another.
    """
    email = "signatory.elsewhere@quolin.example"
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            user = identity.find_by_email(owner, email)
            if user is None:
                user = identity.create_user(
                    owner, email=email, display_name="Signatory Elsewhere"
                )
            identity.set_password(owner, user, SEED_PASSWORD)
            if not identity.roles_for(owner, user.id):
                identity.grant_role(
                    owner,
                    user_id=user.id,
                    role="pack_signatory",
                    jurisdiction="SG",
                    granted_by="test",
                )
            owner.commit()
    finally:
        owner.close()

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        source_id = _manual_source(session).id

    reset_rate_limit_for_tests()
    with TestClient(app) as client:
        # A privileged role with no second factor is confined to enrolling one,
        # so this account is refused at the door rather than at the grant — both
        # are the same answer to the caller, and the assertion below is that it
        # never records an attestation.
        started = client.post(
            "/auth/login", json={"email": email, "password": SEED_PASSWORD}
        )
        assert started.status_code == 200
        refused = client.post(
            f"/currency/sources/{source_id}/verify",
            json={"verified_on": date.today().isoformat()},
        )

    assert refused.status_code == 403, refused.text

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        probe = SessionLocal()
        try:
            assert not probe.scalars(select(SourceVerification)).all(), (
                "a refused attestation was recorded anyway"
            )
        finally:
            probe.close()


def test_the_screen_carries_the_attestation(session, undo):
    """`MANUAL` with no name against it is something somebody has to go and chase."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        row = _manual_source(session)
        sources.verify_manually(
            session,
            row.id,
            verified_on=date.today(),
            verified_by=ACTOR,
            note="Read against the register.",
        )
        session.flush()
        described = {s["id"]: s for s in sources.describe(session)}

    mine = described[row.id]
    assert mine["last_verification"] is not None
    assert mine["last_verification"]["note"] == "Read against the register."

    # And a polled source carries none, because it cannot have one.
    polled = [s for s in described.values() if s["polling_status"] == fetchers.AUTOMATIC]
    assert polled and all(s["last_verification"] is None for s in polled)
    session.rollback()


def test_second_factor_code_is_available_for_the_signatory():
    """Guards the fixture this file leans on rather than the feature."""
    assert second_factor_code(SIGNATORY), "the seeded signatory has no authenticator"


def test_the_attestation_history_can_be_read_back(client, session):
    """FP3-16. `verifications` was written, tested and reached by nothing.

    The attestations were stored and there was no way to read them. A specialist
    put their name to "I checked this publication on the 14th", and all anybody
    could see afterwards was that the source was fresh — the derived state, not
    the evidence for it.

    It matters most for exactly the sources it exists for: §S13 declared some
    publications MANUAL, so for those the attestation *is* the monitoring, and a
    green badge nobody can look behind is an opinion.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        row = _manual_source(session)
        source_id = row.id
        sources.verify_manually(
            session,
            source_id,
            verified_on=business_time.business_today(session),
            verified_by=ACTOR,
            note="checked the gazette by hand",
        )
        session.commit()

    got = client.get(f"/currency/sources/{source_id}/verifications")
    assert got.status_code == 200, got.text
    body = got.json()

    assert body["source_id"] == source_id
    assert body["verifications"], "the attestation was stored and cannot be read back"
    latest = body["verifications"][0]
    assert latest["verified_by"] == ACTOR
    assert latest["note"] == "checked the gazette by hand"


def test_an_unknown_source_is_a_404_not_an_empty_history(client):
    """An empty list for a source that does not exist reads as "nobody has
    checked it", which is a different and much more comfortable answer."""
    got = client.get("/currency/sources/no-such-source/verifications")
    assert got.status_code == 404, got.text
