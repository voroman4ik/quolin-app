"""One chain per tenant, and each chain's start is a record rather than a constant.

Before multi-tenancy the evidence chain began at sixty-four zeroes and ran
through every decision in the table. That shape does not survive a second
customer: each customer can only see their own rows, so a chain threaded
through everybody's would arrive at links naming hashes the reader has no
record of, and would report itself broken during ordinary use.

These are the assertions that the new shape holds — that a tenant's chain
starts where its anchor says, that the tenant is inside every hash, and that
the anchor is protected as strictly as the decisions hanging off it.
"""

from __future__ import annotations

import importlib.util
import subprocess
import sys
from datetime import date, datetime, timezone
from pathlib import Path

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import select, text
from sqlalchemy.exc import DBAPIError

from app import crypto, evidence, tenancy
from app.canonical import GENESIS
from app.db import OwnerSessionLocal, engine, owner_engine
from app.models import (
    Asset,
    AuditEvent,
    ChainAnchor,
    ChainRechain,
    Client,
    Decision,
    Tenant,
)

REPO = Path(__file__).resolve().parents[2]


def _load(name: str, path: Path):
    """Load a module by path.

    Both callers live outside the `app` package and cannot be imported the
    ordinary way: a migration's name starts with a digit (revisions have to
    sort), and `scripts/` sits above the directory the suite runs from.
    """
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _migration_module():
    versions = REPO / "api" / "migrations" / "versions"
    return _load("migration_0004", versions / "0004_chain_anchors.py")


def test_the_migrations_inlined_genesis_calculation_matches_the_live_one():
    """The one piece of duplicated hashing in the repository, checked.

    Migration 0004 cannot import `app.evidence` — a migration is a record of
    what was run, and importing from a package that keeps changing turns it
    into a record of what the package says today. So it inlines the two-key
    sha256 that computes an anchor. This is the test that stops the two copies
    drifting, which would mean anchors written by the migration and anchors
    written by `ensure_anchor` disagreeing about where the same tenant's chain
    begins.
    """
    created_at = datetime(2026, 8, 23, 4, 5, 6, tzinfo=timezone.utc)
    assert _migration_module()._genesis_hash(
        "demo", created_at.isoformat()
    ) == evidence.genesis_hash("demo", created_at)


def test_every_tenant_has_an_anchor(session):
    tenants = list(session.scalars(select(Tenant.id)))
    assert tenants, "no tenants visible; this test would prove nothing"
    for tenant_id in tenants:
        assert session.get(ChainAnchor, tenant_id) is not None, tenant_id


def test_the_chain_starts_at_the_anchor_and_not_at_the_global_constant(session, decisions):
    anchor = session.get(ChainAnchor, DEMO_TENANT)
    assert decisions[0].prev_hash == anchor.genesis_hash
    # The specific thing that changed. A tenant whose chain still began at the
    # old constant would be indistinguishable from every other tenant's start,
    # which is the property anchors exist to remove.
    assert anchor.genesis_hash != GENESIS


def test_the_api_says_which_decision_is_the_first_in_the_chain(client, decisions):
    """The evidence screen cannot work this out for itself any more.

    It used to: the first record's predecessor was sixty-four zeroes, and a
    regex on the client recognised it. An anchor looks like every other hash
    from out there, so the flag is computed where the anchor is known. Without
    this, the screen either labels nothing or labels the wrong record — and it
    is the screen the demo ends on.
    """
    first = client.get(f"/decisions/{decisions[0].id}").json()
    assert first["is_genesis"] is True

    later = client.get(f"/decisions/{decisions[-1].id}").json()
    assert later["is_genesis"] is False
    assert len(decisions) > 1, "one decision only; the negative case proves nothing"


def test_the_anchor_depends_on_both_the_tenant_and_the_moment():
    """Two tenants differ, and so do two provisionings of the same tenant.

    The second half is the reason the anchor is a stored row with a timestamp
    rather than `sha256(salt + tenant_id)`. A customer deleted and recreated
    under the same slug must not inherit the closed account's chain identity.
    """
    at = datetime(2026, 8, 23, tzinfo=timezone.utc)
    later = datetime(2026, 8, 24, tzinfo=timezone.utc)

    assert evidence.genesis_hash("a", at) != evidence.genesis_hash("b", at)
    assert evidence.genesis_hash("a", at) != evidence.genesis_hash("a", later)
    assert evidence.genesis_hash("a", at) == evidence.genesis_hash("a", at)


def test_the_tenant_is_inside_every_decision_hash(decisions):
    """A record re-filed under another customer is wrong on its own terms.

    Per-tenant ordering already catches the move — dropped into the middle of
    the receiving chain it breaks contiguity, appended at the end it names the
    wrong tip. This is the second, independent signal: the row's own hash no
    longer matches its own fields, so verification names *that record* rather
    than only reporting that something nearby stopped adding up.
    """
    decision = decisions[0]
    fields = dict(
        client_id=decision.client_id,
        asset_id=decision.asset_id,
        as_of=decision.as_of,
        pack_id=decision.pack_id,
        pack_version=decision.pack_version,
        snapshot=decision.snapshot,
        rule_results=decision.rule_results,
        resolution=decision.resolution,
        outcome=decision.outcome,
        created_at=decision.created_at,
    )
    mine = evidence._hashable(tenant_id=DEMO_TENANT, schema=1, execution_manifest=None, **fields)
    theirs = evidence._hashable(
        tenant_id="someone-else", schema=1, execution_manifest=None, **fields
    )
    assert mine != theirs


def test_verification_reports_which_chain_it_walked(session):
    result = evidence.verify_chain(session)
    assert result["verified"], result
    assert result["tenant_id"] == DEMO_TENANT
    assert result["genesis_hash"] == session.get(ChainAnchor, DEMO_TENANT).genesis_hash


def test_verification_reads_the_database_rather_than_the_session(session, decisions):
    """What the verifier is a statement about, and it is not the session.

    This test used to move a decision to another tenant **in memory** — never
    flushed, because `decisions` refuses UPDATE by trigger and by revoked grant
    — and assert that verification failed. It passed because `verify_chain`
    walked the ORM's identity map, so it was reporting on an object this
    process had altered rather than on a row anybody had written.

    That is comfortable in this direction and dangerous in the other. A session
    that had already loaded decision #N, on a connection an attacker then
    altered the row through, would have verified against the *cached* copy and
    reported the chain intact. A verifier whose answer depends on what the
    reading process happens to have in memory is not a verifier.

    `verify_chain` reads the columns now, so this asserts the inverse of what it
    used to: an uncommitted local mutation changes nothing, because nothing was
    written. The claim it gave up — that `tenant_id` inside the hash makes a
    re-filed record wrong on its own terms — is `test_the_tenant_is_inside_the_hash`
    above, and is proved against a row that actually exists in
    `test_the_chain_verifier_fails_loudly_under_tamper.py`.
    """
    victim = decisions[len(decisions) // 2]
    victim.tenant_id = "someone-else"
    try:
        assert evidence.verify_chain(session)["verified"] is True, (
            "verification changed its answer because of an unflushed attribute "
            "on an object in this session"
        )
    finally:
        victim.tenant_id = DEMO_TENANT
        session.expunge(victim)

    assert evidence.verify_chain(session)["verified"] is True


def test_a_brand_new_tenants_chain_is_empty_and_verifies():
    """An empty chain is a valid chain, and `ensure_anchor` is what starts it.

    Worth asserting because the alternative is that the very first check any
    new customer runs reports their evidence as broken — and a guarantee whose
    first appearance is a false alarm is one people learn to ignore.

    Rolled back rather than cleaned up: `chain_anchors` refuses DELETE, so a
    committed probe tenant could never be removed. A transaction that is never
    committed leaves nothing for the trigger to object to.
    """
    probe = "chain-anchor-probe"
    with tenancy.acting_as(probe):
        session = OwnerSessionLocal()
        try:
            session.add(Tenant(id=probe, name="Probe", region="ap-southeast-2"))
            session.flush()
            anchor = evidence.ensure_anchor(session, probe)

            result = evidence.verify_chain(session)
            assert result["verified"] is True
            assert result["checked"] == 0
            assert result["tip_hash"] == anchor.genesis_hash
        finally:
            session.rollback()
            session.close()


def test_a_tenant_without_an_anchor_refuses_rather_than_defaulting():
    """No fallback to the old constant.

    A tenant whose provisioning half-finished must not quietly begin writing
    decisions onto a chain that starts where every other unprovisioned tenant's
    does — that is how two customers end up with chains that verify against
    each other's records.
    """
    with tenancy.acting_as("never-provisioned"):
        session = OwnerSessionLocal()
        try:
            with pytest.raises(evidence.NoChainAnchor):
                evidence.verify_chain(session)
        finally:
            session.close()


def test_the_application_role_cannot_rewrite_an_anchor():
    """Rewriting an anchor rewrites the meaning of every hash beneath it.

    So it carries both of the locks `decisions` carries, and each is asserted
    against the role that can actually reach it — the grant here, the trigger
    below.
    """
    with engine.begin() as conn:
        with pytest.raises(DBAPIError, match="permission denied"):
            conn.execute(text("UPDATE chain_anchors SET genesis_hash = genesis_hash"))

    with engine.begin() as conn:
        with pytest.raises(DBAPIError, match="permission denied"):
            conn.execute(text("DELETE FROM chain_anchors"))


def test_anchors_reject_update_and_delete_even_from_the_owner():
    with tenancy.acting_as(DEMO_TENANT):
        with owner_engine.begin() as conn:
            rows = conn.execute(text("SELECT count(*) FROM chain_anchors")).scalar()
            assert rows, "chain_anchors is empty; this test would prove nothing"

        with owner_engine.begin() as conn:
            with pytest.raises(DBAPIError, match="append-only"):
                conn.execute(text("UPDATE chain_anchors SET genesis_hash = genesis_hash"))

        with owner_engine.begin() as conn:
            with pytest.raises(DBAPIError, match="append-only"):
                conn.execute(text("DELETE FROM chain_anchors"))


# ------------------------------------------------------------------ rechain --


def _rechain(*args: str) -> subprocess.CompletedProcess[str]:
    """The script as an operator runs it: a subprocess, from the repo root.

    Imported and called in-process it would share this suite's context
    variables and engines, and the thing most worth proving about a tool that
    rewrites evidence is that it behaves when run the way it is documented.
    """
    return subprocess.run(
        [sys.executable, "-m", "scripts.rechain", *args],
        cwd=REPO,
        capture_output=True,
        text=True,
    )


def test_rechain_leaves_a_healthy_chain_alone():
    """Idempotence, and the reason it matters.

    A re-chain that rewrote hashes it did not need to would produce a database
    where every hash differs from yesterday's export for no recorded reason.
    Finding nothing to do is the normal outcome and has to be the cheap one:
    note that the script returns before it ever suspends the append-only
    trigger, so the routine run does not open the hole at all. It does still
    record that somebody ran it — "did anyone rechain this firm" is a question
    an auditor asks, and a record kept only when the answer was
    yes-and-it-changed-something cannot answer it.

    `--reason` and `--by` are required with `--apply` since Tier 3: this is the
    one tool that rewrites evidence, and the only thing separating it from a
    tamper is that somebody meant it and said so.
    """
    result = _rechain(
        DEMO_TENANT,
        "--apply",
        "--reason",
        "routine check that a healthy chain is left alone",
        "--by",
        "the.suite@quolin.example",
    )
    assert result.returncode == 0, result.stderr
    assert "Nothing to do" in result.stdout, result.stdout


def test_rechain_defaults_to_a_dry_run():
    result = _rechain(DEMO_TENANT)
    assert result.returncode == 0, result.stderr
    assert "dry run" in result.stdout


def test_rechain_refuses_a_chain_that_does_not_verify(monkeypatch):
    """The guard on the tool's one dangerous failure mode.

    Recomputing hashes over a record somebody has altered makes the alteration
    consistent — it launders the tamper. From inside Postgres a payload change
    and an edit look identical, so the script refuses to guess and makes an
    operator assert which it is with `--force`.
    """
    rechain = _load("scripts_rechain", REPO / "scripts" / "rechain.py")

    monkeypatch.setattr(
        evidence,
        "verify_chain",
        lambda session, limit=None: {
            "verified": False,
            "checked": 3,
            "broken_at_decision_id": 4,
        },
    )
    with tenancy.acting_as(DEMO_TENANT):
        assert rechain._rechain_tenant(DEMO_TENANT, apply=True, force=False) is False


@pytest.fixture
def rival():
    """A second customer, with a chain of its own and one hash deliberately wrong.

    The apply path needs a chain that actually has something to repair, and the
    demo tenant's must not be it — a test that corrupts the data the demo is
    given minutes before a meeting is a bad trade for the coverage.

    Committed rather than rolled back, because the script runs in its own
    session and would not see an uncommitted row. That leaves a `rival` tenant
    behind in the dev and CI databases permanently: `chain_anchors` and
    `decisions` both refuse DELETE, so there is no cleaning it up, and `make
    seed` rebuilds from an empty schema anyway. Nothing the demo shows can see
    it, which is the isolation this stage exists to provide, working.
    """
    name = "rival"
    # The tenant is in scope only while the fixture writes. Holding it across
    # the `yield` would put every test that takes this fixture inside the rival
    # tenant, which is the opposite of what a fixture called `rival` should do.
    with tenancy.acting_as(name):
        session = OwnerSessionLocal()
        try:
            if session.get(Tenant, name) is None:
                session.add(Tenant(id=name, name="Rival Advisory", region="ap-southeast-2"))
                session.flush()
            evidence.ensure_anchor(session, name)
            # A tenant is not usable until it has a data key, in the same way it
            # is not usable until it has an anchor. The client below stores an
            # encrypted name and would otherwise fail on the insert.
            crypto.ensure_key(session, name)
            if session.get(Client, "rival-client") is None:
                session.add(
                    Client(
                        id="rival-client",
                        scenario="probe",
                        name="Rival Client",
                        dob=date(1980, 1, 1),
                        client_category="RETAIL",
                        knowledge_assessed=False,
                        loss_capacity_band=1,
                        vulnerability_flag=False,
                        assessable_portfolio_cents=100_000,
                        default_trade_amount_cents=10_000,
                    )
                )
            asset_id = session.scalars(select(Asset.id).order_by(Asset.id)).first()
            decision = Decision(
                client_id="rival-client",
                asset_id=asset_id,
                as_of=date(2026, 1, 1),
                pack_id="AU",
                pack_version=1,
                snapshot={"probe": True},
                rule_results={"results": [], "not_applicable": []},
                resolution=None,
                outcome="BLOCK",
                # Wrong on purpose, and wrong in the way a payload change makes
                # every hash wrong: the fields are intact, the arithmetic is not.
                prev_hash="0" * 64,
                this_hash="f" * 64,
                created_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
            )
            session.add(decision)
            session.commit()
            decision_id = decision.id
        finally:
            session.close()

    return name, decision_id


def test_rechain_repairs_a_chain_and_leaves_the_records_alone(rival):
    """The apply path, end to end, on a chain that genuinely needs rebuilding.

    This is the run that matters: `--force`, because a chain whose hashes are
    stale does not verify and the script refuses to guess; the trigger
    suspended and restored; and afterwards the chain verifying with the stored
    determination untouched. If a re-chain could change an outcome it would be
    a laundering tool rather than a maintenance one.
    """
    name, decision_id = rival
    rechain = _load("scripts_rechain", REPO / "scripts" / "rechain.py")

    with tenancy.acting_as(name):
        assert (
            rechain._rechain_tenant(
                name,
                apply=True,
                force=True,
                reason="repairing a chain this test broke on purpose",
                by="the.suite@quolin.example",
            )
            is True
        )

        session = OwnerSessionLocal()
        try:
            result = evidence.verify_chain(session)
            assert result["verified"] is True, result
            assert result["checked"] >= 1

            repaired = session.get(Decision, decision_id)
            assert repaired.outcome == "BLOCK"
            assert repaired.snapshot == {"probe": True}
            assert repaired.this_hash != "f" * 64

            # The rewrite is itself a fact about this tenant's evidence, so it
            # is in the evidence. Without these rows an auditor comparing two
            # exports finds every hash different and no recorded reason.
            #
            # Two events since Tier 3, not one. The `begin` event names the tip
            # the rewrite is about to leave, so an interrupted rewrite still
            # says somebody started it — a record written only on success is
            # absent exactly when something went wrong.
            actions = list(
                session.scalars(select(AuditEvent.action).where(AuditEvent.tenant_id == name))
            )
            assert "evidence.rechain.begin" in actions
            assert "evidence.rechain.done" in actions

            # And the row that lets the two exports be reconciled rather than
            # merely observed to differ.
            record = session.scalars(
                select(ChainRechain)
                .where(ChainRechain.tenant_id == name)
                .order_by(ChainRechain.id.desc())
                .limit(1)
            ).first()
            assert record is not None, "the rewrite left no record of itself"
            assert record.by_operator == "the.suite@quolin.example"
            assert record.reason
            assert record.tip_before and record.tip_after
            assert record.tip_before != record.tip_after, (
                "a rewrite that changed hashes recorded the same tip either side"
            )
            assert record.rows_changed >= 1
        finally:
            session.close()


def test_rechain_leaves_other_tenants_untouched(rival, session):
    """A repair for one customer is not a write to another's records."""
    name, _ = rival
    before = evidence.verify_chain(session)

    with tenancy.acting_as(name):
        _load("scripts_rechain", REPO / "scripts" / "rechain.py")._rechain_tenant(
            name, apply=True, force=True
        )

    session.expire_all()
    after = evidence.verify_chain(session)
    assert after["verified"] is True
    assert after["tip_hash"] == before["tip_hash"]


def test_rechain_never_edits_a_decisions_fields():
    """It recomputes hashes from stored fields; it does not touch the fields.

    Asserted against the statement itself rather than by running it, because
    the run that would prove it is the run nobody should be able to trigger by
    accident. If a later change makes this script write an `outcome` or a
    `snapshot`, this fails and the reviewer has to say why.
    """
    source = (REPO / "scripts" / "rechain.py").read_text()
    updates = [line for line in source.splitlines() if "UPDATE decisions SET" in line]
    assert updates, "no UPDATE found; this test would prove nothing"
    for line in updates:
        assert "prev_hash = :prev, this_hash = :this" in line, line
