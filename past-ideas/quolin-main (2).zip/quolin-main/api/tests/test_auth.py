"""
Authentication, and the two properties this phase exists to guarantee.

The load-bearing tests are `test_every_route_except_the_public_set_requires_a_session`
and `test_the_public_set_is_what_we_think_it_is`. Between them they assert the
default-deny property against the *live route table* rather than against a
hand-written list, so a route added next month is covered by a test written
today. Every other test here checks a specific mechanism.
"""

from __future__ import annotations

import pytest
from conftest import (
    ADMIN_EMAIL,
    TEST_PASSWORD,
    VIEWER_EMAIL,
    reset_rate_limit_for_tests,
    second_factor_code,
    sign_in,
)
from fastapi.testclient import TestClient
from starlette.routing import Match

from app import auth
from app.main import PUBLIC_PATHS, _declared_routes, app


@pytest.fixture
def anon():
    """A client that has never logged in. The point of most of this file."""
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        yield c


@pytest.fixture
def fresh():
    """A client with its own session, isolated from the module-scoped one."""
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        yield sign_in(c)


# --- the default-deny property -------------------------------------------


#: Stand-ins for path parameters, by the type the schema declares. The values
#: need not exist: the middleware refuses before routing reaches a handler, so
#: what is being proven is that the refusal happens first — not what the handler
#: would have said. `_routes_to` below is what stops that from being a licence
#: to build URLs that go nowhere.
_SAMPLES = {"integer": "1", "number": "1", "string": "sample", "boolean": "true"}


def _path_parameter_types() -> dict[tuple[str, str], list[tuple[str, str]]]:
    """Each documented operation's path parameters and their declared types.

    Read out of `app.openapi()` because that is where the types are stated. It is
    the *metadata* source, not the list of routes to walk — see `_surface`.
    """
    types: dict[tuple[str, str], list[tuple[str, str]]] = {}
    for template, operations in app.openapi()["paths"].items():
        for method, operation in operations.items():
            types[(method.upper(), template)] = [
                (p["name"], p.get("schema", {}).get("type", "string"))
                for p in operation.get("parameters", [])
                if p.get("in") == "path"
            ]
    return types


def _surface() -> list[tuple[str, str, str]]:
    """Every (method, template, concrete URL) the application serves.

    Generated rather than hand-listed, because the gate this file exists for is
    that *every* route refuses an anonymous caller and a hand-listed set is a set
    somebody forgets to extend. A route added next month is walked the moment it
    is declared.

    Built from the live route table and not from the OpenAPI document, which is a
    deliberate widening of what the execution document asked for. FastAPI does
    not describe its own `/docs`, `/redoc` and `/openapi.json` in that document —
    so a walk of the documented surface alone would skip exactly the four routes
    that publish the shape of every other one. Types for path parameters still
    come from OpenAPI; the list of things to walk comes from the router.

    A parameter whose type has no sample raises rather than being skipped.
    Skipping would quietly stop testing the route it belongs to, which is the one
    failure this test must not have.
    """
    types = _path_parameter_types()
    surface = []
    for method, template in _declared_routes():
        concrete = template
        for name, declared in types.get((method, template), []):
            sample = _SAMPLES.get(declared)
            assert sample is not None, (
                f"no sample value for a {declared} path parameter on {template}; "
                "add one to _SAMPLES rather than letting this route go unwalked"
            )
            concrete = concrete.replace(f"{{{name}}}", sample)
        assert "{" not in concrete, (
            f"{template} has a path parameter nothing declares a type for — "
            f"{concrete} would not route, and a 401 from it would prove nothing"
        )
        surface.append((method, template, concrete))
    return sorted(set(surface))


def _routes_to(method: str, url: str) -> bool:
    """Whether a real route would handle this URL.

    The check that keeps the walk honest. `require_session` runs as middleware,
    before routing — so a URL matching no route at all returns 401 exactly like a
    protected one does, and a walk that only asserted 401 would pass just as well
    against a list of typos. This asks the router the same question it will ask
    itself, the way `main._matched_route` does.
    """
    scope = {
        "type": "http",
        "method": method,
        "path": url,
        "root_path": "",
        "headers": [],
        "query_string": b"",
    }
    return any(route.matches(scope)[0] == Match.FULL for route in app.router.routes)


def test_the_generated_walk_reaches_a_real_handler_for_every_route():
    """The check that stops the walk below from passing vacuously.

    `require_session` is middleware, so it refuses *before* routing — which means
    a URL matching no route at all returns 401 exactly like a protected one does.
    A walk that only asserted 401 would therefore pass just as well against a
    list of typos. Every URL it builds is confirmed to reach a handler first.
    """
    surface = _surface()
    assert surface, "the route table is empty"

    unreachable = [(m, url) for m, _, url in surface if not _routes_to(m, url)]
    assert not unreachable, f"the walk builds URLs that route nowhere: {unreachable}"


def test_the_only_routes_openapi_does_not_describe_are_the_documentation_ones():
    """Named rather than tolerated, because the gate says "the OpenAPI surface".

    FastAPI does not describe `/docs`, `/redoc`, `/openapi.json` or the Swagger
    OAuth redirect in its own document. The walk covers them anyway by reading
    the router instead — but the gap is worth pinning, so that a *different*
    route going undocumented fails here rather than silently narrowing what a
    reader thinks is being tested.
    """
    documented = set(_path_parameter_types())
    undocumented = {template for _, template in set(_declared_routes()) - documented}
    assert undocumented == {
        app.docs_url,
        app.redoc_url,
        app.openapi_url,
        app.swagger_ui_oauth2_redirect_url,
    }


def test_every_route_except_the_public_set_requires_a_session(anon):
    """No endpoint is reachable without a cookie unless it is named public.

    The whole stage in one assertion, and the gate item the execution document
    words as "unauthenticated request rejected on every route (generated test
    walks the OpenAPI surface)". It reads the surface at run time, so adding an
    endpoint without thinking about authentication fails here rather than
    shipping an open one.
    """
    leaked = []
    for method, template, url in _surface():
        if template in PUBLIC_PATHS:
            continue
        res = anon.request(method, url)
        if res.status_code != 401:
            leaked.append((method, template, res.status_code))
    assert not leaked, f"reachable without a session: {leaked}"


def test_the_public_routes_are_the_only_ones_that_answer_anonymously(anon):
    """Stated from the other side, so the assertion above cannot hold vacuously.

    If the middleware refused everything — including the routes by which a
    session comes into existence — the test above would pass and nobody could
    log in. Every public path is therefore exercised too, and must answer with
    something other than 401.
    """
    answered = {}
    for method, template, url in _surface():
        if template not in PUBLIC_PATHS:
            continue
        # GET only: the public POSTs are login and logout, and walking those
        # with a sample body would either spend a rate-limit attempt or end the
        # session the rest of the file is using.
        if method != "GET":
            continue
        answered[template] = anon.request(method, url).status_code
    assert answered, "no public GET routes — the login flow cannot be reached"
    assert all(code != 401 for code in answered.values()), answered


def test_the_public_set_is_what_we_think_it_is():
    """The exempt list, pinned.

    A test that reads the constant it is testing proves nothing, so this states
    the paths independently. Widening the public set now takes two deliberate
    edits, which is the point: `/health` is public so a load balancer can probe
    it, and nothing that reads a client record ever should be.

    The two OIDC paths joined the list when federated sign-in landed, and they
    belong to the same category as `/auth/login` rather than being an exception
    to it: a route by which a session comes into existence cannot require one.
    Neither is unauthenticated in any useful sense — `/auth/oidc/callback`
    demands a signed state cookie and an identity token whose signature, issuer,
    audience, expiry and `nonce` all check out, which is a harder credential to
    produce than a password. `test_oidc.py` walks each way of failing it.

    `/v1/oauth/token` joined for the same reason again: it is the route by which
    an integration's session comes to exist, so it cannot require one. It is rate
    limited on the same counter as the login form, refuses every failure
    identically so that it cannot be used to discover which credentials exist,
    and takes the tenant from the credential rather than from anything the caller
    sends.

    `/auth/set-password` and `/auth/reset` joined with FP3-11, and the category
    is the same one a third time: they are how a person who has never signed in
    comes to hold a credential, and how somebody who has forgotten one gets
    another. A route that required a session to obtain a session is the defect
    FP3-11 is — `POST /admin/users` created, in its own words, "a person, created
    with no way to sign in yet", and nothing turned that into somebody who could.

    Both carry the defences the rest of this list does. `/auth/set-password`
    takes a single-use, expiring, hashed token, is rate limited by address, and
    answers expired, already-used and never-ours with one message — because
    which of the three applies is a fact about our records and the holder of a
    bad token is not entitled to it. `/auth/reset` answers identically whether or
    not the address names an account, so it is not an enumeration oracle on the
    one surface that has to be reachable by somebody locked out.
    """
    assert PUBLIC_PATHS == frozenset(
        {
            "/health",
            # Stage 9's status page. Public by definition: its purpose is to be
            # readable by somebody who cannot sign in, including when we are the
            # reason they cannot. It reports whether the engine answers and
            # whether the evidence chain verifies, and nothing per-customer —
            # which is what makes it safe to serve to anyone.
            "/status",
            "/auth/login",
            "/auth/logout",
            "/auth/session",
            "/auth/oidc/start",
            "/auth/oidc/callback",
            "/v1/oauth/token",
            "/auth/set-password",
            "/auth/reset",
        }
    )


def test_the_api_documentation_is_not_public(anon):
    """FastAPI serves /docs, /redoc and /openapi.json to anyone by default.

    No client record is behind them, so this is not a data leak — but they
    describe every path, parameter and schema in the system, which is free
    reconnaissance against a deployment whose entire claim is that it is
    private. Swagger still works perfectly well once you have logged in.
    """
    for path in ("/docs", "/redoc", "/openapi.json"):
        assert anon.get(path).status_code == 401, f"{path} is reachable anonymously"


def test_the_documentation_still_works_once_signed_in(client):
    """Closing it to strangers must not close it to a signed-in engineer."""
    assert client.get("/openapi.json").status_code == 200
    assert client.get("/docs").status_code == 200


def test_health_is_public_but_says_nothing_confidential(anon):
    """The one always-open endpoint, and the limit of what it discloses."""
    res = anon.get("/health")
    assert res.status_code == 200
    body = res.json()
    # Not a decision count. That was tenant data on a public endpoint, and
    # row-level security now says so by returning zero — see /health's note.
    #
    # `revision` joined this deliberately, and the whitelist stays a whitelist:
    # a blue-green cutover cannot be verified unless the new colour can be told
    # apart from the old one, and the value is a rotation label an operator
    # chooses. Anything more identifying than that — a build SHA, a hostname —
    # is disclosure to an unauthenticated caller for no operational gain, so
    # `main.py` says to keep it a label and this line is what notices when
    # something else appears beside it.
    assert set(body) == {"status", "packs", "revision"}
    assert body["revision"] == "unreported", (
        "the test environment sets no revision, so anything else here came "
        "from somewhere unintended"
    )


def test_no_client_data_is_reachable_without_a_session(anon):
    """Said again at the level a reader cares about, not the route level."""
    for path in ["/clients", "/decisions", "/queue", "/dashboard", "/currency"]:
        assert anon.get(path).status_code == 401


# --- login ----------------------------------------------------------------


def test_correct_credentials_start_a_session(anon):
    res = anon.post("/auth/login", json={"email": VIEWER_EMAIL, "password": TEST_PASSWORD})
    assert res.status_code == 200
    assert auth.COOKIE_NAME in res.cookies
    assert anon.get("/clients").status_code == 200


def test_a_wrong_password_is_refused_and_starts_nothing(anon):
    res = anon.post("/auth/login", json={"email": VIEWER_EMAIL, "password": "not the one"})
    assert res.status_code == 401
    assert auth.COOKIE_NAME not in res.cookies
    assert anon.get("/clients").status_code == 401


def test_the_session_says_who_is_holding_it(anon):
    """A session is a person now, and /auth/session says which one.

    The whole of Stage 2 in one assertion: before this, the only honest answer
    to "who did that?" was "whoever had the passcode".
    """
    anon.post("/auth/login", json={"email": VIEWER_EMAIL, "password": TEST_PASSWORD})
    body = anon.get("/auth/session").json()
    assert body["authenticated"] is True
    assert body["user"]["email"] == VIEWER_EMAIL
    assert body["roles"] == ["viewer"]


def test_the_refusal_message_does_not_say_which_half_was_wrong(anon):
    """One message for every failure.

    A distinct answer for "no such account" would turn the login form into an
    address-book oracle: post a list of addresses and keep the ones that come
    back "wrong password". So a bad address and a bad password read identically,
    and `identity.authenticate` spends the same Argon2 work on both.
    """
    messages = {
        anon.post("/auth/login", json={"email": e, "password": p}).json()["detail"]
        for e, p in [
            (VIEWER_EMAIL, "wrong"),
            (VIEWER_EMAIL, ""),
            ("nobody@quolin.example", TEST_PASSWORD),
            ("", ""),
        ]
    }
    assert messages == {"Those details are not correct."}


def test_the_cookie_is_not_readable_by_script(anon):
    """HttpOnly, so an XSS bug cannot turn into a stolen session."""
    res = anon.post("/auth/login", json={"email": VIEWER_EMAIL, "password": TEST_PASSWORD})
    header = res.headers["set-cookie"].lower()
    assert "httponly" in header
    assert "path=/" in header


def test_the_session_token_is_never_stored(session, anon):
    """The database holds a hash, and the hash is not the token.

    A dump of `auth_sessions` is therefore worth nothing to whoever obtains it.
    """
    res = anon.post("/auth/login", json={"email": VIEWER_EMAIL, "password": TEST_PASSWORD})
    token = res.cookies[auth.COOKIE_NAME]

    from app.models import AuthSession

    session.expire_all()
    rows = list(session.scalars(__import__("sqlalchemy").select(AuthSession)))
    stored = {r.token_hash for r in rows}
    assert token not in stored
    assert auth._hash(token) in stored


def test_no_password_is_stored_anywhere_in_the_clear(session):
    """Neither the session table nor the identity table holds a password.

    `user_identities.secret` holds an Argon2id encoding, which is not the
    password and cannot be turned back into one — asserted here at the level a
    reader cares about, rather than left to the hasher's own tests.
    """
    from sqlalchemy import select

    from app.models import AuthSession, UserIdentity

    session.expire_all()
    for row in session.scalars(select(AuthSession)):
        blob = f"{row.token_hash}{row.user_agent}{row.created_ip}"
        assert TEST_PASSWORD not in blob
    for identity_row in session.scalars(select(UserIdentity)):
        assert TEST_PASSWORD not in (identity_row.secret or "")


def test_a_session_with_no_person_behind_it_opens_nothing(session, anon):
    """The last way in that named nobody, closed.

    `auth_sessions.user_id` is nullable — it had to be, to be added to a table
    that already held rows — so a session with no person behind it is still
    constructible. This asserts that constructing one buys nothing: the
    middleware refuses it exactly as it refuses a forged cookie, and
    `/auth/session` reports it as signed out.

    Written as a test rather than left to the guard script because the two prove
    different things. The guard proves no code *creates* such a session; this
    proves that one created anyway would not work.
    """
    from conftest import DEMO_TENANT

    from app import tenancy

    with tenancy.acting_as(DEMO_TENANT):
        token = auth.create_session(session, tenant_id=DEMO_TENANT)
    try:
        anon.cookies.set(auth.COOKIE_NAME, token)
        assert anon.get("/clients").status_code == 401
        assert anon.get("/auth/session").json()["authenticated"] is False
    finally:
        with tenancy.acting_as(DEMO_TENANT):
            auth.destroy(session, token)


# --- step-up --------------------------------------------------------------


def test_signing_in_leaves_the_credential_fresh(fresh):
    """The clock that governs signing starts at sign-in, not at first use."""
    body = fresh.get("/auth/session").json()
    assert body["credential_fresh"] is True


def test_reauth_needs_the_right_password(fresh):
    assert fresh.post("/auth/reauth", json={"password": "not it"}).status_code == 401
    res = fresh.post(
        "/auth/reauth",
        json={"password": TEST_PASSWORD, "code": second_factor_code(ADMIN_EMAIL)},
    )
    assert res.status_code == 200
    assert res.json()["fresh_for_minutes"] == auth.REAUTH_MINUTES


def test_reauth_moves_the_credential_clock_without_moving_the_session(fresh):
    """Stepping up must not mint a new session.

    If it did, the draft on screen would be lost every time somebody confirmed
    their password — which is the reason this endpoint exists rather than
    telling people to sign out and back in.
    """
    before = fresh.cookies[auth.COOKIE_NAME]
    since = fresh.get("/auth/session").json()["since"]

    # A privileged account re-authenticating presents the second factor too —
    # §S13 enforces `MFA_REQUIRED_ROLES`, and re-authentication before signing
    # rule content is exactly where a stolen password must not be enough.
    assert (
        fresh.post(
            "/auth/reauth",
            json={"password": TEST_PASSWORD, "code": second_factor_code(ADMIN_EMAIL)},
        ).status_code
        == 200
    )

    assert fresh.cookies[auth.COOKIE_NAME] == before
    assert fresh.get("/auth/session").json()["since"] == since


def test_reauth_is_refused_without_a_session(anon):
    """It confirms a person the session already names. There is nobody to confirm."""
    assert anon.post("/auth/reauth", json={"password": TEST_PASSWORD}).status_code == 401


def test_reauth_cannot_re_point_a_session_at_another_account(fresh):
    """`ReauthRequest` carries no email, and this is why.

    An address accepted here would let whoever holds the cookie confirm *any*
    account's password and have the session treated as freshly authenticated —
    turning step-up, the control that guards signing, into the way around it.
    """
    from app.schemas import ReauthRequest

    assert "email" not in ReauthRequest.model_fields

    # Sent anyway, the way an attacker would. It is ignored, and the password
    # is checked against the session's own person — so a valid password for
    # somebody else is still a refusal.
    res = fresh.post(
        "/auth/reauth",
        json={"email": "someone.else@quolin.example", "password": "their password"},
    )
    assert res.status_code == 401


# --- logout ---------------------------------------------------------------


def test_logout_actually_ends_the_session(fresh):
    """Revocation is real, not just a cleared cookie.

    The cookie value is kept and replayed after logout. If the server were
    trusting a self-describing token this would still work, which is the whole
    argument for a server-side list.
    """
    token = fresh.cookies[auth.COOKIE_NAME]
    assert fresh.get("/clients").status_code == 200

    fresh.post("/auth/logout")
    assert fresh.get("/clients").status_code == 401

    fresh.cookies.set(auth.COOKIE_NAME, token)
    assert fresh.get("/clients").status_code == 401, "a revoked session was replayable"


def test_logout_is_fine_when_there_was_no_session(anon):
    res = anon.post("/auth/logout")
    assert res.status_code == 200
    assert res.json()["ended"] is False


def test_a_forged_cookie_is_not_a_session(anon):
    anon.cookies.set(auth.COOKIE_NAME, "not-a-real-token-just-made-up")
    assert anon.get("/clients").status_code == 401


# --- rate limiting --------------------------------------------------------


def _wrong(anon):
    return anon.post("/auth/login", json={"email": VIEWER_EMAIL, "password": "wrong"})


def _right(anon):
    return anon.post("/auth/login", json={"email": VIEWER_EMAIL, "password": TEST_PASSWORD})


def test_repeated_failures_are_locked_out(anon):
    """Brute force costs more than it earns."""
    for _ in range(auth.MAX_ATTEMPTS):
        _wrong(anon)
    res = _wrong(anon)
    assert res.status_code == 429
    assert "Retry-After" in res.headers


def test_the_lockout_holds_even_against_the_correct_password(anon):
    """The limit is on attempts, not on wrong attempts.

    Otherwise the lockout is trivially bypassed by whoever eventually guesses
    right — which is the one case it exists to stop.
    """
    for _ in range(auth.MAX_ATTEMPTS):
        _wrong(anon)
    assert _right(anon).status_code == 429


def test_a_correct_password_clears_earlier_failures(anon):
    """Fumbling a password twice must not leave you part-way to a lockout."""
    for _ in range(auth.MAX_ATTEMPTS - 1):
        _wrong(anon)
    assert _right(anon).status_code == 200
    for _ in range(auth.MAX_ATTEMPTS - 1):
        _wrong(anon)
    assert _right(anon).status_code == 200


# --- configuration --------------------------------------------------------


def test_cors_never_allows_a_wildcard_origin():
    """A wildcard cannot carry credentials, and should not be here anyway.

    Read from the configured app rather than the helper, so a middleware
    re-ordering that dropped the setting would still be caught.
    """
    from app.main import _allowed_origins

    origins = _allowed_origins()
    assert "*" not in origins
    assert origins, "an empty origin list would fail every browser request"
    assert all(o.startswith("http://") or o.startswith("https://") for o in origins)


def test_the_401_is_readable_by_the_browser_that_provoked_it(anon):
    """A 401 must carry CORS headers, or the client cannot see that it is a 401.

    This is an ordering property, not a configuration one. The auth check
    short-circuits with its own response instead of calling the route, so if it
    sits outside CORSMiddleware that response leaves without
    `Access-Control-Allow-Origin` and `fetch` rejects it as a network failure.

    The consequence is not cosmetic. The web client clears every cached client
    record on a 401 and keeps them on a network error, so the wrong ordering
    turns an expired session into "the engine is unreachable" with names, dates
    of birth and portfolio values still sitting on the screen. This was caught
    in a browser rather than by the suite, which is why there is now a test.
    """
    origin = "http://localhost:3000"  # in the default development allowlist
    res = anon.get("/clients", headers={"Origin": origin})

    assert res.status_code == 401
    assert res.headers.get("access-control-allow-origin") == origin
    assert res.headers.get("access-control-allow-credentials") == "true"


def test_cookie_policy_matches_the_deployment(monkeypatch):
    """Secure implies SameSite=None; insecure implies Lax.

    The pairing is what matters: SameSite=None without Secure is rejected by
    browsers outright, and would mean nobody can log in to the hosted demo.
    """
    monkeypatch.setenv("QUOLIN_COOKIE_SECURE", "true")
    kw = auth.cookie_kwargs()
    assert kw["secure"] is True and kw["samesite"] == "none"

    monkeypatch.setenv("QUOLIN_COOKIE_SECURE", "false")
    kw = auth.cookie_kwargs()
    assert kw["secure"] is False and kw["samesite"] == "lax"

    assert auth.cookie_kwargs()["httponly"] is True


def test_sessions_are_not_append_only():
    """Logging out must be able to delete the row.

    The append-only trigger protects the evidence tables. Applying it here
    would make revocation impossible, so this asserts the omission is
    deliberate rather than an oversight someone should "fix".
    """
    from app.models import APPEND_ONLY_TABLES

    assert "auth_sessions" not in APPEND_ONLY_TABLES


def test_the_session_list_never_leaks_a_token(fresh):
    """`/auth/sessions` shows enough to act on and nothing worth stealing."""
    token = fresh.cookies[auth.COOKIE_NAME]
    body = fresh.get("/auth/sessions").json()
    assert body["count"] >= 1
    raw = str(body)
    assert token not in raw
    assert auth._hash(token) not in raw, "the full hash is more than a UI needs"


def test_revoke_all_signs_out_every_browser(fresh):
    """Including the browser that asked, which is the honest behaviour."""
    other = TestClient(app)
    sign_in(other)
    assert other.get("/clients").status_code == 200

    assert fresh.post("/auth/revoke-all").json()["revoked"] >= 2
    assert other.get("/clients").status_code == 401
    assert fresh.get("/clients").status_code == 401


def test_cors_allows_every_method_the_route_table_uses():
    """A method missing from `allow_methods` is an endpoint no browser can call.

    And the failure is silent in the worst way: the browser's preflight is
    refused, so the real request is never sent and `fetch` rejects with a
    network error rather than a status. `PATCH /tenant/advance-policy` shipped
    that way for the length of one commit.
    """
    from app.main import app as live
    from app.rbac import ROUTE_ROLES

    allowed = None
    for layer in live.user_middleware:
        options = getattr(layer, "kwargs", {}) or {}
        if "allow_methods" in options:
            allowed = {m.upper() for m in options["allow_methods"]}
    assert allowed, "no CORS middleware with an explicit method list"

    used = {method.upper() for method, _path in ROUTE_ROLES}
    missing = used - allowed
    assert not missing, (
        f"{sorted(missing)} appear in the route table and not in CORS "
        "`allow_methods`. A browser cannot call those endpoints at all."
    )
