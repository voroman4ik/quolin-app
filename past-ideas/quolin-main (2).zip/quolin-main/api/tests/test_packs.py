"""Packs are content. These tests protect the content/engine separation."""

from __future__ import annotations

import re
from datetime import date
from pathlib import Path

import pytest

from app import packs_repo
from app.engine import Pack, match_packs

ENGINE_DIR = Path(__file__).resolve().parents[1] / "app" / "engine"


def test_effective_date_selects_the_right_pack(session):
    assert packs_repo.active(session, "AU", date(2025, 11, 14)).version == 1
    assert packs_repo.active(session, "AU", date(2026, 5, 31)).version == 1
    assert packs_repo.active(session, "AU", date(2026, 6, 1)).version == 2
    assert packs_repo.active(session, "AU", date.today()).version == 2


def test_no_pack_before_the_first_effective_date(session):
    with pytest.raises(LookupError):
        packs_repo.active(session, "AU", date(2025, 1, 1))


def test_v2_is_a_documented_delta_of_v1(pack_bodies):
    delta = packs_repo.diff(pack_bodies[("AU", 1)], pack_bodies[("AU", 2)])

    changed = {c["name"]: (c["from"], c["to"]) for c in delta["thresholds_changed"]}
    assert changed == {"max_crypto_concentration_bps": (1500, 1000)}
    assert [r["rule_id"] for r in delta["rules_added"]] == ["AU-KNOW-02"]
    assert delta["rules_removed"] == []


def test_pack_versions_do_not_overlap_in_time(pack_bodies):
    """Within a regime. Two regulators being in force at once is the point."""
    by_regime: dict[str, list] = {}
    for (pack_id, version), body in pack_bodies.items():
        by_regime.setdefault(pack_id, []).append(
            (
                date.fromisoformat(body["effective_from"]),
                date.fromisoformat(body["effective_to"]) if body["effective_to"] else date.max,
                version,
            )
        )

    for pack_id, windows in by_regime.items():
        windows.sort()
        for (_, end, earlier), (start, _, later) in zip(windows, windows[1:], strict=False):
            assert end < start, f"{pack_id} v{earlier} overlaps v{later}"


def test_every_rule_is_structurally_valid(pack_bodies):
    for (pack_id, version), body in pack_bodies.items():
        label = f"{pack_id} v{version}"
        seen = set()
        for rule in body["rules"]:
            assert rule["rule_id"] not in seen, f"{label}: duplicate rule {rule['rule_id']}"
            seen.add(rule["rule_id"])
            assert rule["on_fail"] in ("BLOCK", "REFER"), rule
            assert isinstance(rule["severity"], int)
            assert "predicate" in rule and "op" in rule["predicate"], rule
            assert rule.get("title"), f"{label}: {rule['rule_id']} has no title"
            # A rule id names its own regime. Without this a pack could ship a
            # rule that reads as another regulator's on a report.
            assert rule["rule_id"].startswith(f"{pack_id}-"), f"{label}: {rule['rule_id']}"
            assert rule["reason_code"] in body["reason_codes"], f"{label}: {rule['rule_id']}"


def test_every_rule_declares_a_constraint_the_resolver_can_read(pack_bodies):
    """A rule with no dimension cannot take part in a cross-border comparison.

    The resolver records such a rule rather than dropping it, but a pack that
    ships one has quietly opted that rule out of every conflict resolution, and
    that should be a deliberate act rather than an omission.
    """
    for (pack_id, version), body in pack_bodies.items():
        for rule in body["rules"]:
            constraint = rule.get("constraint")
            assert constraint, f"{pack_id} v{version}: {rule['rule_id']} declares no constraint"
            assert constraint.get("dimension"), rule["rule_id"]
            assert constraint.get("scale"), rule["rule_id"]


def test_precedence_never_claims_to_order_the_unorderable(pack_bodies):
    """`qualitative` must not appear in any precedence table.

    A knowledge requirement has no magnitude. If a pack ever declared a
    direction for it, the resolver would dutifully order two constraints that
    cannot be ordered, and the honest "no ordering was possible" answer would
    disappear from the record.
    """
    for (pack_id, version), body in pack_bodies.items():
        scales = body.get("precedence", {}).get("scales", {})
        assert scales, f"{pack_id} v{version}: no precedence block"
        assert "qualitative" not in scales, f"{pack_id} v{version}"
        assert set(scales.values()) <= {"lower_is_stricter", "higher_is_stricter"}


def test_unreviewed_content_says_so_in_the_pack(pack_bodies):
    """Invariant 7, and the reason the badge cannot be softened.

    The signatory line is what a reader trusts. A pack nobody has reviewed must
    say that in the field a document prints, not only in a note nobody renders.
    """
    for (pack_id, version), body in pack_bodies.items():
        status = body["content_status"]
        assert status in ("REVIEWED", "PENDING_REVIEW", "ILLUSTRATIVE"), status
        assert body["signed_by"], f"{pack_id} v{version} has no signatory"
        if status == "ILLUSTRATIVE":
            assert "ILLUSTRATIVE" in body["signed_by"], f"{pack_id} v{version}"
            assert "NOT PROFESSIONALLY REVIEWED" in body["signed_by"], f"{pack_id} v{version}"


def test_packs_reference_only_templates_that_exist(pack_bodies):
    template_dir = Path(__file__).resolve().parents[1] / "app" / "artefacts" / "templates"
    for (pack_id, version), body in pack_bodies.items():
        label = f"{pack_id} v{version}"
        for kind, filename in body["artefact_templates"].items():
            assert (template_dir / filename).exists(), f"{label}: missing {filename}"
            assert body["artefact_titles"].get(kind), f"{label}: {kind} has no title"


def test_committed_packs_match_what_is_loaded_in_the_database(session, pack_bodies):
    for (pack_id, version), body in pack_bodies.items():
        loaded = packs_repo.by_version(session, pack_id, version)
        assert loaded.thresholds == body["thresholds"]
        assert [r["rule_id"] for r in loaded.rules] == [r["rule_id"] for r in body["rules"]]


#: Mirrors `scripts/guard_no_jurisdiction_logic.sh`. Two copies exist on
#: purpose: the shell script gates the commit, this gates the test run, and a
#: regime added to one without the other is caught by the next test down.
JURISDICTION_CODES = ("AU", "HK", "SG", "EU")

JURISDICTION_LOGIC = re.compile(
    r"""\bif\b.*\bjurisdiction\b            # branching on jurisdiction
      | \bjurisdiction\s*==
      | \bpack_id\s*==
      | ["'](?:AU|HK|SG|EU)["']             # a hardcoded pack identifier
      | \b(?:AU|HK|SG|EU)-[A-Z]+-\d+        # a hardcoded rule id
    """,
    re.VERBOSE,
)


def test_the_guard_covers_every_regime_that_ships(pack_bodies):
    """A fifth pack must not arrive with the guard still watching four.

    This used to read `guard_no_jurisdiction_logic.sh` and assert each shipped
    code appeared in its text — a list in a script, checked by a list in a test,
    both maintained by hand.

    FP3-02 rewrote the guard to derive the codes from `packs/` itself, so the
    property is now true by construction and this asserts the derivation rather
    than a spelling. A fifth pack extends the guard by existing.
    """
    from scripts.engine_jurisdictions import pack_jurisdictions

    shipped = {pack_id.lower() for pack_id, _ in pack_bodies}
    assert shipped <= pack_jurisdictions(), (
        f"the guard derives {sorted(pack_jurisdictions())} from packs/ and does "
        f"not know {sorted(shipped - pack_jurisdictions())}"
    )


def test_engine_contains_no_jurisdiction_logic():
    """Definition of done §11. The pack format is the product thesis."""
    offenders = [
        f"{path.name}:{lineno}: {line.strip()}"
        for path in ENGINE_DIR.rglob("*.py")
        for lineno, line in enumerate(path.read_text().splitlines(), start=1)
        if JURISDICTION_LOGIC.search(line)
    ]
    assert not offenders, "jurisdiction logic leaked into the engine:\n" + "\n".join(offenders)


def test_pack_round_trips_through_the_typed_shape(pack_bodies):
    for body in pack_bodies.values():
        pack = Pack.from_body(body)
        assert pack.pack_id == body["pack_id"]
        assert len(pack.rules) == len(body["rules"])
        # Not a fixed class name: one regulator's major asset is another's
        # complex product, and asserting otherwise would bake AU's vocabulary
        # into a test that runs against every regime.
        assert pack.classify("BTC")["class"] == body["asset_classes"]["BTC"]["class"]
        with pytest.raises(KeyError):
            pack.classify("NOT-A-REAL-ASSET")


def test_a_bloc_pack_answers_for_its_member_states(pack_bodies):
    """One pack, many states — the claim the UI is allowed to make."""
    blocs = [Pack.from_body(b) for b in pack_bodies.values() if len(b.get("covers_states", [])) > 1]
    assert blocs, "no pack covers more than one state"

    for pack in blocs:
        for state in pack.covers_states:
            matched, unmatched = match_packs([state], {pack.pack_id: pack})
            assert matched == [pack], f"{pack.pack_id} does not answer for {state}"
            assert unmatched == []
