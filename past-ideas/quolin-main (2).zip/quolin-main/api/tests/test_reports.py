"""Reporting aggregates recorded evidence. These tests hold it to that.

A report is allowed to be a summary. It is not allowed to be a different
answer from the records it summarises, and it is not allowed to claim a
guarantee the storage does not provide.
"""

from __future__ import annotations

from collections import Counter
from datetime import date

import pytest

from app import reports
from app.models import Decision

# --- period bounds -------------------------------------------------------


@pytest.mark.parametrize(
    "period,start,end",
    [
        ("2026-01", date(2026, 1, 1), date(2026, 1, 31)),
        ("2026-02", date(2026, 2, 1), date(2026, 2, 28)),
        ("2024-02", date(2024, 2, 1), date(2024, 2, 29)),  # leap year
        ("2026-12", date(2026, 12, 1), date(2026, 12, 31)),  # year rollover
        ("2026-Q1", date(2026, 1, 1), date(2026, 3, 31)),
        ("2026-Q4", date(2026, 10, 1), date(2026, 12, 31)),
    ],
)
def test_period_bounds_are_inclusive_and_handle_the_edges(period, start, end):
    assert reports.period_bounds(period) == (start, end)


@pytest.mark.parametrize(
    "period", ["2026", "2026-13", "2026-00", "2026-Q5", "last month", "2026-01-01..2026-03-31"]
)
def test_only_named_periods_are_accepted(period):
    """A free date range would let a caller label an arbitrary window a period."""
    with pytest.raises(reports.PeriodError):
        reports.period_bounds(period)


def test_quarters_tile_the_year_without_gap_or_overlap():
    days = [
        d
        for q in range(1, 5)
        for d in _dates_between(*reports.period_bounds(f"2026-Q{q}"))
    ]
    assert len(days) == len(set(days)) == 365


def _dates_between(start: date, end: date) -> list[date]:
    from datetime import timedelta

    out, cursor = [], start
    while cursor <= end:
        out.append(cursor)
        cursor += timedelta(days=1)
    return out


# --- the return matches the records -------------------------------------


def test_offered_periods_all_contain_decisions(session):
    periods = reports.available_periods(session)
    assert periods
    assert all(p["decisions"] > 0 for p in periods)
    assert [p["period"] for p in periods] == sorted(
        (p["period"] for p in periods), reverse=True
    )


def _governed_by(decisions, jurisdiction=reports.DEFAULT_JURISDICTION):
    """The decisions a return for one regulator is allowed to count.

    A return is filed with one regulator. Rows with no `pack_id` predate
    multi-jurisdiction and are all from the reference regime.
    """
    return [
        d
        for d in decisions
        if (d.pack_id or reports.DEFAULT_JURISDICTION) == jurisdiction
    ]


def test_outcome_tallies_equal_the_decisions_in_the_window(session, decisions):
    period = reports.available_periods(session)[0]["period"]
    start, end = reports.period_bounds(period)
    report = reports.distribution_return(session, period=period)

    expected = Counter(d.outcome for d in _governed_by(decisions) if start <= d.as_of <= end)
    assert report["decisions_total"] == sum(expected.values())
    for row in report["outcomes"]:
        assert row["count"] == expected.get(row["outcome"], 0)


def test_offered_period_counts_match_the_scoped_report(session):
    """The dropdown count and the preview must not contradict each other."""
    for scenario in ("meridian", "sterling"):
        for row in reports.available_periods(session, scenario):
            report = reports.distribution_return(
                session, period=row["period"], scenario=scenario
            )
            assert row["decisions"] == report["decisions_total"]


def test_scenario_scoping_partitions_the_period(session):
    period = reports.available_periods(session)[0]["period"]
    whole = reports.distribution_return(session, period=period)
    parts = sum(
        reports.distribution_return(session, period=period, scenario=s)["decisions_total"]
        for s in ("meridian", "sterling")
    )
    assert parts == whole["decisions_total"]


def test_findings_count_only_failing_rules(session, decisions):
    period = reports.available_periods(session)[0]["period"]
    start, end = reports.period_bounds(period)
    report = reports.distribution_return(session, period=period)

    expected: Counter[tuple[str, str]] = Counter()
    for d in _governed_by(decisions):
        if not start <= d.as_of <= end:
            continue
        for r in d.rule_results["results"]:
            if not r["passed"] and r.get("reason_code"):
                expected[(r["rule_id"], r["reason_code"])] += 1

    actual = {(f["rule_id"], f["reason_code"]): f["count"] for f in report["findings"]}
    assert actual == dict(expected)
    # Every finding carries a human title, not a bare code.
    assert all(f["title"] != f["reason_code"] for f in report["findings"])


def test_a_return_counts_only_its_own_regulators_decisions(session, decisions):
    """A return is filed with one regulator, so it counts one regulator's determinations."""
    cross = [d for d in decisions if d.pack_id and d.pack_id != reports.DEFAULT_JURISDICTION]
    assert cross, "no non-AU decisions seeded"

    decision = cross[0]
    period = decision.as_of.strftime("%Y-%m")

    au = reports.distribution_return(session, period=period, jurisdiction="AU")
    theirs = reports.distribution_return(
        session, period=period, jurisdiction=decision.pack_id
    )

    assert theirs["decisions_total"] >= 1
    assert au["decisions_total"] == len(
        [d for d in _governed_by(decisions) if d.as_of.strftime("%Y-%m") == period]
    )
    # Every rule id in a regulator's return belongs to that regulator's pack.
    assert all(f["rule_id"].startswith(decision.pack_id) for f in theirs["findings"])
    assert all(p["pack_id"] == decision.pack_id for p in theirs["packs_in_force"])


def test_an_empty_period_reports_zero_rather_than_failing(session):
    """2020 predates the first pack's data but the period is still well-formed."""
    report = reports.distribution_return(session, period="2020-01")
    assert report["decisions_total"] == 0
    assert report["findings"] == []
    assert report["packs_in_force"] == []
    assert all(row["count"] == 0 for row in report["outcomes"])


def test_a_period_spanning_the_pack_change_lists_both_versions(session):
    """v1 runs to 2026-05-31 and v2 from 2026-06-01, so H1 straddles them."""
    versions = set()
    for period in ("2026-Q2", "2026-Q3"):
        report = reports.distribution_return(session, period=period)
        versions.update(p["version"] for p in report["packs_in_force"])
    assert versions == {1, 2}


def test_every_pack_listed_names_a_signatory(session):
    """Invariant 7: no version reports without a named human behind it."""
    for period in (p["period"] for p in reports.available_periods(session)):
        for pack in reports.distribution_return(session, period=period)["packs_in_force"]:
            assert pack["signed_by"].strip()


# --- the override register ----------------------------------------------


def test_override_entries_fall_inside_the_period(session):
    period = _period_with_overrides(session)
    start, end = reports.period_bounds(period)
    register = reports.override_register(session, period=period)

    assert register["overrides_total"] == len(register["entries"])
    for entry in register["entries"]:
        recorded = date.fromisoformat(entry["recorded_at"][:10])
        assert start <= recorded <= end


def test_every_override_names_an_approver_and_a_justification(session):
    period = _period_with_overrides(session)
    for entry in reports.override_register(session, period=period)["entries"]:
        assert entry["approver"].strip()
        assert len(entry["justification"].strip()) >= 20
        assert entry["outcome"] in ("REFER", "BLOCK")


def test_the_register_keeps_the_original_determination(session):
    """An override is an addition to the record, so the outcome it displaced
    must still be the outcome the decision row carries."""
    period = _period_with_overrides(session)
    for entry in reports.override_register(session, period=period)["entries"]:
        decision = session.get(Decision, entry["decision_id"])
        assert decision.outcome == entry["outcome"]
        assert decision.pack_version == entry["pack_version"]


def _period_with_overrides(session) -> str:
    for row in reports.available_periods(session):
        if reports.override_register(session, period=row["period"])["overrides_total"]:
            return row["period"]
    pytest.fail("no seeded overrides — run `make seed` first")


# --- audit export --------------------------------------------------------


def test_audit_export_is_ordered_and_bounded(session):
    everything = reports.audit_rows(session)
    assert everything
    assert [r["id"] for r in everything] == sorted(r["id"] for r in everything)

    bounded = reports.audit_rows(session, start=date(2026, 1, 1), end=date(2026, 12, 31))
    assert all(r["at"][:4] == "2026" for r in bounded)
    assert len(bounded) <= len(everything)


def test_audit_export_does_not_claim_tamper_evidence(client):
    """`audit_events` is append-only but not hash-chained. Saying otherwise, or
    saying nothing, would let a reader assume the decision chain's guarantee."""
    response = client.get("/audit/export")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/csv")
    assert response.headers["X-Quolin-Integrity"] == "append-only-trigger; not-hash-chained"

    lines = response.text.strip().splitlines()
    assert lines[0] == ",".join(reports.AUDIT_COLUMNS)
    assert len(lines) - 1 == int(response.headers["X-Quolin-Rows"])


# --- the documents -------------------------------------------------------


def test_both_period_kinds_are_pack_configured_in_every_version(pack_bodies):
    """Invariant 8: a title is pack content, never a hardcoded statutory claim."""
    for body in pack_bodies.values():
        for kind in ("regulatory_return", "override_report"):
            assert kind in body["artefact_templates"]
            assert body["artefact_titles"][kind].strip()

    # Not a fixed pair of strings: each regime names its own documents, and a
    # test that pinned one regime's names would be the hardcoded statutory
    # claim this invariant exists to prevent. What must hold is that no two
    # regimes are forced to share a name they did not choose.
    for (pack_id, version), body in pack_bodies.items():
        for kind in ("regulatory_return", "override_report"):
            title = body["artefact_titles"][kind]
            assert title == title.strip() and len(title) > 3, f"{pack_id} v{version}: {kind}"


def test_the_reporting_pack_is_the_one_in_force_at_period_end(client):
    """Q1 2026 closes under v1; Q3 2026 closes under v2."""
    first = client.post("/returns", json={"period": "2026-Q1"}).json()
    later = client.post("/returns", json={"period": "2026-Q3"}).json()
    assert first["template_version"] == "period_return_v1.html"
    assert later["template_version"] == "period_return_v2.html"


def test_return_generates_a_pdf_and_serves_it(client):
    artefact = client.post("/returns", json={"period": "2026-Q1"}).json()
    assert artefact["title"] == "Periodic Distribution Return"

    pdf = client.get(artefact["download_url"])
    assert pdf.status_code == 200
    assert pdf.headers["content-type"] == "application/pdf"
    assert pdf.content.startswith(b"%PDF")


def test_override_report_generates_a_pdf_and_serves_it(client, session):
    period = _period_with_overrides(session)
    artefact = client.post("/reports/overrides", json={"period": period}).json()
    assert artefact["title"] == "Override Register Extract"

    pdf = client.get(artefact["download_url"])
    assert pdf.status_code == 200
    assert pdf.content.startswith(b"%PDF")


def test_preview_matches_what_the_document_is_built_from(client):
    """The screen and the PDF must not be able to disagree."""
    period = "2026-Q1"
    first = client.get(
        "/reports/preview", params={"kind": "regulatory_return", "period": period}
    ).json()
    second = client.get(
        "/reports/preview", params={"kind": "regulatory_return", "period": period}
    ).json()
    assert first["outcomes"] == second["outcomes"]
    assert first["findings"] == second["findings"]


def test_malformed_periods_are_rejected_at_the_edge(client):
    assert client.post("/returns", json={"period": "last quarter"}).status_code == 422
    assert client.get(
        "/reports/preview", params={"kind": "regulatory_return", "period": "2026-13"}
    ).status_code == 422
    assert client.get(
        "/reports/preview", params={"kind": "nonsense", "period": "2026-Q1"}
    ).status_code == 422
