"""The class, not the route: no name sits against content nobody showed that person.

Four rounds closed a reported case and were beaten one route along each time.
F4 bound signature -> publication. B1 bound review -> signature. F1 bound
reading -> review, and stopped there, because that was the route in the report.
`SignRequest` twenty lines above `SecondReviewRequest` in the same file said
"Only the note travels", and the auditor ran F1's own sequence through it:

    signatory GET   /watch/drafts/{id}                 threshold 1000
    author    PATCH /watch/drafts/{id}  -> 9999                    200
    signatory POST  /watch/drafts/{id}/sign                        200

    row: status=signed, content_hash over the author's edit, and it publishes.

So this file is not another route's test. It is the test for the class — *an
identity recorded against content nobody proved that person saw* — and it is
written to fail when the seventh attestation route is added in six months
without a binding.

`CENSUS` below is the enumeration from `docs/spec-changes.md`, as data. Four
things are asserted about it:

  1. every state-changing route the application serves appears in it, so a new
     route fails this file until somebody classifies it;
  2. every entry still names a route that exists, so the census cannot rot into
     a description of a previous version of the app;
  3. every entry that binds content has a *required* body field named
     `*_content_hash`, typed `str`, `min_length >= 1`, with no default — read off
     the route's own Pydantic model rather than off a list kept somewhere else;
  4. every entry that does not bind content carries a written reason, so
     "probably fine" cannot be committed.

Then the reported sequence, over HTTP, end to end.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

import pytest
from conftest import DEMO_TENANT, SEED_PASSWORD, reset_rate_limit_for_tests
from fastapi.routing import APIRoute
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import identity, tenancy, totp
from app.db import OwnerSessionLocal
from app.main import app
from app.models import MfaCredential, PackDraft
from app.watch import drafts
from app.watch.lifecycle import content_hash

#: Far enough out that nothing here is ever the pack in force.
FAR_FUTURE = 3650

#: This file's own cast, for the reason the F1 file gives for having one: a
#: change to another file's accounts must not quietly change what this asserts.
AUTHOR_EMAIL = "census.author@quolin.example"
SIGNATORY_EMAIL = "census.signatory@quolin.example"

#: What the author changes while the signatory is reading. A threshold rather
#: than a note: the difference between "they did not see this word" and "they
#: did not see this number the engine decides on".
ATTACK_THRESHOLD = "max_crypto_concentration_bps"
ATTACK_VALUE = 9999


# ------------------------------------------------------------- the census ----


@dataclass(frozen=True)
class Attestation:
    """One state-changing route, and what it does with a person's identity.

    `binds` is the only field with three-valued meaning collapsed to two, and
    the collapse is deliberate. A route either has to say which bytes its
    attester saw or it does not; *why* it does not is `reason`, in prose, and
    the test refuses an empty one. There is no third flag for "probably fine".
    """

    method: str
    path: str
    #: What identity, if any, this route writes against content or a decision.
    #: Empty where it writes none.
    identity: str
    #: True when the person is attesting to content this system holds, and the
    #: route must therefore make them say which bytes they were shown.
    binds: bool
    #: Why not, for every entry where `binds` is False. Required by the test.
    reason: str = ""


#: Bound: the attester says which bytes, and the recorder compares exactly.
_BOUND = (
    Attestation(
        "POST",
        "/watch/drafts/{draft_id}/second-review",
        "second_reviewer, second_reviewer_user_id, second_reviewed_content_hash",
        binds=True,
    ),
    Attestation(
        "POST",
        "/watch/drafts/{draft_id}/sign",
        "signed_by, signed_by_user_id, signed_qualification_ref, content_hash",
        binds=True,
    ),
    Attestation(
        "POST",
        "/watch/drafts/{draft_id}/approve-publication",
        "publication_approvals.approved_by, .content_hash",
        binds=True,
    ),
    Attestation(
        "POST",
        "/watch/drafts/{draft_id}/publish",
        "published_by_user_id; the publisher counts as one of the two approvals",
        binds=True,
    ),
)

#: Bound already, by immutability. The attested object cannot move between the
#: read and the attestation, so there is no window and a hash would compare a
#: value to itself across a gap nothing can cross.
_IMMUTABLE = (
    Attestation(
        "POST",
        "/decisions/{decision_id}/override",
        "overrides.approver, overrides.approved_by",
        binds=False,
        reason=(
            "The attested object is a `decisions` row. `decisions` and `overrides` "
            "are append-only by trigger (migration 0001) and the decision is in the "
            "hash chain, so the bytes an approver read cannot be edited by anyone "
            "through any route or any shell. There is no window to bind."
        ),
    ),
    Attestation(
        "POST",
        "/advances/{advance_id}/take",
        "tenant_advances.advanced_by",
        binds=False,
        reason=(
            "The attested object is (jurisdiction, pack_version). `packs` is "
            "append-only by the same trigger and `watch.drafts.publish` is its only "
            "writer, so a version's bytes are fixed the moment it exists."
        ),
    ),
    Attestation(
        "POST",
        "/advances/{advance_id}/decline",
        "tenant_advances.advanced_by",
        binds=False,
        reason=(
            "As `take` above: the pack version being declined is an append-only row "
            "and cannot move between the read and the decline."
        ),
    ),
)

#: Attests to nothing content-shaped: a note, a state change, a request for
#: work, or an authorisation about a person rather than about a body.
_NOT_CONTENT = (
    Attestation(
        "POST",
        "/watch/drafts",
        "created_by, created_by_user_id",
        binds=False,
        reason=(
            "Authorship of content the author wrote. Nothing was shown to them to "
            "attest to — this is the act the other bindings defend against."
        ),
    ),
    Attestation(
        "PATCH",
        "/watch/drafts/{draft_id}",
        "audit actor only",
        binds=False,
        reason=(
            "An edit, for the same reason as creating one: the editor is the person "
            "changing the content, not somebody vouching for content they were "
            "shown. This is the act the other bindings defend against."
        ),
    ),
    Attestation(
        "POST",
        "/watch/drafts/{draft_id}/validate",
        "",
        binds=False,
        reason=(
            "Checks an edit without saving it — what the workbench calls as somebody "
            "types. It writes nothing at all, so there is no identity to bind."
        ),
    ),
    Attestation(
        "POST",
        "/watch/drafts/{draft_id}/submit",
        "submitted_by",
        binds=False,
        reason=(
            "A state change: this is ready for somebody to look at. It makes no "
            "claim about the content, and IN_REVIEW puts nothing in front of anybody."
        ),
    ),
    Attestation(
        "POST",
        "/watch/drafts/{draft_id}/reject",
        "rejected_by, rejected_by_user_id",
        binds=False,
        reason=(
            "Binding this one would be HARMFUL, not merely unnecessary. A reviewer "
            "moving to refuse bad content would meet 409 the moment its author "
            "edited anything, and would have to re-read the author's new version "
            "before being allowed to say no to it — which hands the author a way to "
            "keep a rejection off their draft by editing whenever one is attempted. "
            "The asymmetry is the reason: every other attestation here can put "
            "content in front of a firm and a rejection cannot. REJECTED is terminal "
            "(lifecycle.TRANSITIONS[REJECTED] == ()), so a rejection recorded against "
            "bytes that moved is at worst a note filed against a slightly different "
            "draft, never a name on content somebody is relying on."
        ),
    ),
    Attestation(
        "POST",
        "/watch/events/{event_id}/triage",
        "audit actor only",
        binds=False,
        reason=(
            "Queue workflow on `watch_events`, which is not rule content and is not "
            "in the hash chain. Every transition goes to `audit_events`, which is "
            "where who-did-what already lives."
        ),
    ),
    Attestation(
        "POST",
        "/currency/sources/{source_id}/verify",
        "source_verifications.verified_by",
        binds=False,
        reason=(
            "A real attestation to real content, held to the signature's bar — but "
            "the content is NOT OURS TO HASH. The signatory is attesting to what a "
            "regulator had published on a date, and those bytes are on somebody "
            "else's website. A hash would be either of a body we did not fetch or of "
            "a `watch_sources` row, which is configuration rather than the thing "
            "attested to. What binds it instead is `verified_on` and "
            "`attachment_ref`, which point at what they looked at."
        ),
    ),
    Attestation(
        "POST",
        "/adoption",
        "tenant_stages.signed_by, .signed_by_user_id",
        binds=False,
        reason=(
            "A rung on the adoption ladder: a stage change with no body. What the "
            "signer is agreeing to is the meaning of the stage, which is stated in "
            "`adoption.WHAT_EACH_MEANS` in code rather than held as data."
        ),
    ),
    Attestation(
        "POST",
        "/admin/users",
        "users.created_by",
        binds=False,
        reason=(
            "Provisioning a person. `created_by` answers who authorised an account "
            "to exist; there is no body anybody was shown and nothing to hash."
        ),
    ),
    Attestation(
        "POST",
        "/admin/users/{user_id}/roles",
        "user_roles.granted_by",
        binds=False,
        reason=(
            "Authorising a permission. A decision about a person, not about a body "
            "of content — and the quarterly access review is what reads it back."
        ),
    ),
    Attestation(
        "POST",
        "/admin/roles/{grant_id}/revoke",
        "user_roles.revoked_by",
        binds=False,
        reason=(
            "Ending a permission, as granting one: a decision about a person's "
            "access rather than about any body of content."
        ),
    ),
    Attestation(
        "POST",
        "/admin/users/{user_id}/suspend",
        "audit actor",
        binds=False,
        reason=(
            "Ending somebody's access. A decision about a person, with no content "
            "on either side of it."
        ),
    ),
    Attestation(
        "POST",
        "/admin/users/{user_id}/reinstate",
        "audit actor",
        binds=False,
        reason=(
            "Restoring somebody's access. A decision about a person, with no "
            "content on either side of it."
        ),
    ),
    Attestation(
        "POST",
        "/artefacts/{kind}",
        "artefacts.generated_by",
        binds=False,
        reason=(
            "Provenance of a request — who asked for this document, not who vouches "
            "for it. The document's own `content_hash` is over bytes this process "
            "produced deterministically from the facts."
        ),
    ),
    Attestation(
        "POST",
        "/artefacts/batch",
        "artefact_jobs.requested_by",
        binds=False,
        reason=(
            "Provenance of a request: who queued these renders. The documents do "
            "not exist yet, so there is nothing anybody could have been shown."
        ),
    ),
    Attestation(
        "POST",
        "/runs",
        "eval_runs.requested_by",
        binds=False,
        reason=(
            "Provenance of a request: who asked for a sweep. The outcomes it "
            "produces are determinations, which nobody is vouching for by asking."
        ),
    ),
    Attestation(
        "POST",
        "/import/clients",
        "import_runs.requested_by",
        binds=False,
        reason=(
            "Provenance of a request: who ran an import, over data the caller is "
            "supplying rather than being shown."
        ),
    ),
    Attestation(
        "POST",
        "/v1/clients",
        "import_runs.requested_by",
        binds=False,
        reason=(
            "Provenance of a request, over data the caller is supplying rather "
            "than being shown."
        ),
    ),
    Attestation(
        "POST",
        "/returns",
        "",
        binds=False,
        reason=(
            "Renders a periodic return from determinations that already exist. It "
            "writes an artefact, not an attestation."
        ),
    ),
    Attestation(
        "POST",
        "/reports/overrides",
        "",
        binds=False,
        reason=(
            "Renders a report over overrides that already exist. It writes an "
            "artefact, not an attestation."
        ),
    ),
    Attestation(
        "POST",
        "/comparison/ingest",
        "",
        binds=False,
        reason=(
            "Ingests an incumbent system's outcomes for comparison. Nobody is named "
            "against them and nothing is attested to."
        ),
    ),
    Attestation(
        "POST",
        "/evaluate",
        "decisions.decided_by",
        binds=False,
        reason=(
            "Who ran a determination, deliberately outside the hash — invariant 2 "
            "says the frozen snapshot is the only input and the operator is not one. "
            "Running a check is not vouching for its content."
        ),
    ),
    Attestation(
        "POST",
        "/v1/evaluations",
        "decisions.decided_by",
        binds=False,
        reason=(
            "As `/evaluate`: `decided_by` records who ran a determination and is "
            "deliberately outside the hash, because running a check is not "
            "vouching for what it produced."
        ),
    ),
    Attestation(
        "POST",
        "/v1/bulk",
        "decisions.decided_by",
        binds=False,
        reason=(
            "As `/evaluate`, many pairs in one call. Same reasoning: the caller is "
            "asking for determinations, not attesting to any."
        ),
    ),
    Attestation(
        "POST",
        "/decisions/{decision_id}/replay",
        "",
        binds=False,
        reason=(
            "Reproduces a determination from its frozen snapshot and reports whether "
            "it still agrees. It writes no attestation and no identity."
        ),
    ),
    Attestation(
        "POST",
        "/v1/decisions/{decision_id}/replay",
        "",
        binds=False,
        reason=(
            "As the console's replay: reproduces a determination and writes no "
            "attestation and no identity."
        ),
    ),
    Attestation(
        "PATCH",
        "/tenant/advance-policy",
        "audit actor",
        binds=False,
        reason=(
            "A setting: whether this firm advances automatically or is pinned. It "
            "records no name against any body, and the policy in force when a "
            "version arrives is copied onto the advance row at that moment."
        ),
    ),
    Attestation(
        "POST",
        "/watch/poll",
        "",
        binds=False,
        reason=(
            "A machine act: fetches regulator sources and records what changed. No "
            "person is named against anything it writes."
        ),
    ),
    Attestation(
        "POST",
        "/webhooks/deliveries/{delivery_id}/redeliver",
        "",
        binds=False,
        reason=(
            "A machine act: re-sends a webhook that failed. It writes a delivery "
            "attempt, not an attestation, and the payload is already fixed."
        ),
    ),
)

#: Authentication. Session rows and credentials; no content anywhere.
_AUTH = tuple(
    Attestation(
        "POST",
        path,
        "auth_sessions / credentials",
        binds=False,
        reason="Authentication. No content is attested to.",
    )
    for path in (
        "/auth/login",
        "/auth/logout",
        "/auth/reauth",
        "/auth/revoke-all",
        "/auth/mfa/enrol",
        "/auth/mfa/verify",
        "/auth/set-password",
        "/auth/reset",
        "/v1/oauth/token",
    )
)

CENSUS: tuple[Attestation, ...] = _BOUND + _IMMUTABLE + _NOT_CONTENT + _AUTH

#: The methods that can record anything. A GET cannot write a name against a
#: body, so the census is over the rest.
WRITE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})


def _routes_that_can_write() -> set[tuple[str, str]]:
    found = set()
    for route in app.routes:
        if not isinstance(route, APIRoute):
            continue
        for method in route.methods:
            if method in WRITE_METHODS:
                found.add((method, route.path))
    return found


def _body_model(method: str, path: str):
    """The Pydantic model this route parses its request body into, or None."""
    for route in app.routes:
        if isinstance(route, APIRoute) and route.path == path and method in route.methods:
            field = getattr(route, "body_field", None)
            return None if field is None else field.field_info.annotation
    raise AssertionError(f"no route {method} {path}")


# --------------------------------------------- the census covers the app -----


def test_every_state_changing_route_is_classified():
    """A new write route fails this until somebody says what it does with a name.

    This is the assertion that ends the sequence rather than shortening it. Four
    rounds fixed the route that was reported and were beaten by the next sibling;
    what makes a fifth sibling impossible is not a better fix but a list that the
    application cannot grow past silently.

    The failure message is written to be read by whoever added the route, because
    they are the person who has to classify it and they will meet this message
    before they meet the docs.
    """
    served = _routes_that_can_write()
    classified = {(entry.method, entry.path) for entry in CENSUS}

    unclassified = served - classified
    assert not unclassified, (
        "these state-changing routes are not in the attestation census:\n  "
        + "\n  ".join(f"{m} {p}" for m, p in sorted(unclassified, key=lambda x: x[1]))
        + "\n\nAdd each to CENSUS in this file and answer one question about it: "
        "does it record a person's identity against content, and if so is that "
        "content bound to what they were shown? If it binds, give the request a "
        "required `*_content_hash` field and compare it in the recorder. If it "
        "does not, say why in `reason` — the census is also in "
        "docs/spec-changes.md and the two are meant to say the same thing."
    )


def test_the_census_does_not_describe_routes_that_are_gone():
    """The other direction, so the list cannot rot.

    A census that still names a route somebody deleted is a census nobody
    believes, and the first thing an auditor does with a list is check whether it
    is current.
    """
    served = _routes_that_can_write()
    stale = {(e.method, e.path) for e in CENSUS} - served
    assert not stale, (
        "the census names routes this application no longer serves:\n  "
        + "\n  ".join(f"{m} {p}" for m, p in sorted(stale, key=lambda x: x[1]))
    )


def test_the_census_lists_each_route_once():
    """Two entries for one route would let a lax one shadow a strict one."""
    seen = [(e.method, e.path) for e in CENSUS]
    duplicated = {key for key in seen if seen.count(key) > 1}
    assert not duplicated, f"listed twice in the census: {sorted(duplicated)}"


# ------------------------------- and every content-attesting route binds -----


@pytest.mark.parametrize(
    "entry",
    [e for e in CENSUS if e.binds],
    ids=lambda e: f"{e.method}{e.path}",
)
def test_a_content_attesting_route_requires_the_hash_of_what_was_shown(entry):
    """The class assertion, read off the route rather than off a list of names.

    Four properties, and each of them is one that was actually wrong somewhere
    in this sequence:

      *the field exists* — `SignRequest` had none, and its docstring said so;
      *it is required* — an optional one is omitted, and an omitted one attests
        to whatever is on the row now, which is the defect restated;
      *it is a `str`* — so that the comparison in the recorder is a string
        comparison and not a coercion;
      *`min_length >= 1`* — so that the empty string is a 422 at the schema as
        well as a refusal at the recorder, and the two layers refuse the same
        caller for the same reason at two distances.
    """
    model = _body_model(entry.method, entry.path)
    assert model is not None, (
        f"{entry.method} {entry.path} attests to content and takes no request "
        "body at all, so its attester has no way to say what they read. This is "
        "how `approve-publication` and `publish` came to be the second and third "
        "instances of the same defect."
    )

    fields = {
        name: f
        for name, f in model.model_fields.items()
        if name.endswith("_content_hash")
    }
    assert fields, (
        f"{model.__name__} has no `*_content_hash` field, so "
        f"{entry.method} {entry.path} records {entry.identity or 'an identity'} "
        "against whatever is on the row when the POST arrives."
    )
    assert len(fields) == 1, (
        f"{model.__name__} carries {sorted(fields)}. Two hashes of two bodies in "
        "one request is how a client sends the wrong one — the same reason "
        "`view()` calls its field `current_content_hash` rather than "
        "`content_hash`."
    )

    name, field = next(iter(fields.items()))
    assert field.is_required(), (
        f"{model.__name__}.{name} has a default, so a caller may omit it — and a "
        "caller that omits it is attesting to whatever happens to be there now, "
        "which is the whole defect. Required, for the reason `SignRequest` has "
        "no `signatory` field."
    )
    assert field.annotation is str, (
        f"{model.__name__}.{name} is {field.annotation!r}; the recorder compares "
        "it to a string with `!=` and a non-string would compare unequal in ways "
        "nobody intends."
    )
    lengths = [
        getattr(m, "min_length", None)
        for m in field.metadata
        if getattr(m, "min_length", None) is not None
    ]
    assert lengths and max(lengths) >= 1, (
        f"{model.__name__}.{name} accepts the empty string. The recorder refuses "
        "it anyway — there is no truthiness branch — but the schema should refuse "
        "it first, so that a client sending nothing is told it sent nothing."
    )


@pytest.mark.parametrize(
    "entry",
    [e for e in CENSUS if not e.binds],
    ids=lambda e: f"{e.method}{e.path}",
)
def test_a_route_that_does_not_bind_says_why(entry):
    """No "probably fine". The reason is the artefact this step produces.

    An entry can be wrong and still be honest; what it cannot be is silent. The
    two entries this assertion exists for are `reject` — where binding would be
    harmful, and the reason says so — and `currency/sources/{id}/verify`, where
    the attested content is on a regulator's website and there is nothing here
    to hash.
    """
    assert entry.reason.strip(), (
        f"{entry.method} {entry.path} is classified as not binding content and "
        "gives no reason. Say what the person is attesting to and why it is "
        "either not content, or content that cannot move."
    )
    assert len(entry.reason.split()) >= 4, (
        f"{entry.method} {entry.path} gives a reason too short to be one: "
        f"{entry.reason!r}"
    )


def test_the_bound_routes_are_the_ones_that_can_put_content_in_front_of_a_firm():
    """The census's own claim about itself, so a future edit has to argue with it.

    Every route that binds is on the path from a draft to `packs`; nothing else
    on that path is unbound. Stated here rather than only in prose, because the
    temptation when a binding is inconvenient is to reclassify the route rather
    than to remove the binding, and reclassifying it would have to break this.
    """
    bound = {e.path for e in CENSUS if e.binds}
    assert bound == {
        "/watch/drafts/{draft_id}/second-review",
        "/watch/drafts/{draft_id}/sign",
        "/watch/drafts/{draft_id}/approve-publication",
        "/watch/drafts/{draft_id}/publish",
    }, (
        "the set of content-attesting routes changed. If a route was added to the "
        "path from a draft to a published pack, bind it and add it here. If one "
        "was removed from that path, say so in docs/spec-changes.md — this set is "
        "the answer to 'whose name can end up on rule content'."
    )


# --------------------------------------------------------- the cast ---------


def _person(email: str, *roles: tuple[str, str]) -> str:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            user = identity.find_by_email(owner, email)
            if user is None:
                user = identity.create_user(owner, email=email, display_name=email)
            held = {(g.role, g.jurisdiction) for g in identity.roles_for(owner, user.id)}
            for role, jurisdiction in roles:
                if (role, jurisdiction) in held:
                    continue
                identity.grant_role(
                    owner,
                    user_id=user.id,
                    role=role,
                    jurisdiction=jurisdiction,
                    granted_by="test",
                    qualification_ref="[illustrative — no engagement in place]",
                )
            owner.commit()
            return str(user.id)
    finally:
        owner.close()


@pytest.fixture(scope="module")
def cast() -> dict[str, str]:
    """An author holding `operator`, and an independent signatory.

    The author holds `operator` because `PATCH /watch/drafts/{id}` is an
    operator's act — the S5 workbench workflow, not a corner case. The signatory
    is a different person, so this is the ordinary path where somebody else signs
    an operator's draft, which is what makes it the primary attestation rather
    than the self-signed exception.
    """
    return {
        "author": _person(AUTHOR_EMAIL, ("pack_signatory", "AU"), ("operator", "")),
        "signatory": _person(SIGNATORY_EMAIL, ("pack_signatory", "AU")),
    }


def _sign_in(client, email: str) -> None:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            user = identity.find_by_email(owner, email)
            assert user is not None
            identity.set_password(owner, user, SEED_PASSWORD)
            credential = owner.scalars(
                select(MfaCredential).where(MfaCredential.user_id == user.id)
            ).first()
            if credential is None:
                credential, _ = identity.enrol_totp(owner, user, label="test")
                owner.flush()
                identity.confirm_totp(
                    owner, credential, totp.code_at(str(credential.secret))
                )
            credential.last_used_counter = 0
            owner.commit()
            code = totp.code_at(str(credential.secret))
    finally:
        owner.close()

    res = client.post(
        "/auth/login", json={"email": email, "password": SEED_PASSWORD, "code": code}
    )
    assert res.status_code == 200, res.text


def _cut_a_draft(client, *, title: str) -> int:
    cut = client.post(
        "/watch/drafts",
        json={
            "jurisdiction": "AU",
            "effective_from": (date.today() + timedelta(days=FAR_FUTURE)).isoformat(),
            "title": title,
            "rationale": (
                "Written by "
                "tests/test_an_attestation_is_of_the_bytes_the_attester_saw.py"
            ),
        },
    )
    assert cut.status_code == 200, cut.text
    return int(cut.json()["id"])


def _a_draft(session, *, title: str) -> PackDraft:
    return drafts.create(
        session,
        jurisdiction="AU",
        on=date.today(),
        effective_from=date.today() + timedelta(days=FAR_FUTURE),
        title=title,
        rationale=(
            "Written by tests/test_an_attestation_is_of_the_bytes_the_attester_saw.py"
        ),
        author="The Author",
    )


def _edit_the_body(draft: PackDraft) -> None:
    """Change the content, as the workbench's PATCH does.

    Assigned rather than mutated in place: `PackDraft.body` is a JSON column and
    SQLAlchemy does not see a mutation of the dictionary it handed out, so a test
    that mutated would flush nothing and pass while asserting the opposite of
    what it says.
    """
    body = dict(draft.body)
    body["thresholds"] = dict(body["thresholds"]) | {ATTACK_THRESHOLD: ATTACK_VALUE}
    draft.body = body


# ------------------------------------------------ the auditor's sequence -----


def test_read_then_the_author_edits_then_the_signatory_signs_is_refused(cast):
    """The reported sequence, over the routes a workbench actually has.

    Three ordinary acts in an order nobody had walked: a signatory reads, an
    author edits, the signatory signs. Before this round that ended in a 200 and
    a signature over the edit — verified on the clean tree before anything was
    written. It now ends at the third step, which is the step where the false
    statement would have been recorded.

    409 rather than 403: the signatory's `pack_signatory` grant for AU is right
    and the door was the right door. What is wrong is that the draft moved
    underneath them, which is a fact about the draft.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="Edited while it was being read")

        with TestClient(app) as signatory:
            _sign_in(signatory, SIGNATORY_EMAIL)

            # 1. The signatory reads it. This is the screen they are looking at.
            read = signatory.get(f"/watch/drafts/{draft_id}")
            assert read.status_code == 200, read.text
            what_they_read = read.json()["current_content_hash"]
            assert what_they_read, "view returned no hash for the body it rendered"
            assert (
                read.json()["body"]["thresholds"].get(ATTACK_THRESHOLD) != ATTACK_VALUE
            ), "the draft already carries the attack value, so this asserts nothing"

            # 2. The author edits it while they read. An ordinary PATCH by the
            #    principal the S5 workflow describes.
            current = author.get(f"/watch/drafts/{draft_id}")
            assert current.status_code == 200, current.text
            edited = author.patch(
                f"/watch/drafts/{draft_id}",
                json={
                    "thresholds": dict(current.json()["body"]["thresholds"])
                    | {ATTACK_THRESHOLD: ATTACK_VALUE}
                },
            )
            assert edited.status_code == 200, edited.text

            # 3. The signatory signs what they read — and is refused, because it
            #    is not what is there.
            refused = signatory.post(
                f"/watch/drafts/{draft_id}/sign",
                json={"note": "I read it.", "signed_content_hash": what_they_read},
            )

    assert refused.status_code == 409, refused.text
    detail = refused.json()["detail"]
    assert "changed while it was being read" in detail, detail

    # Nothing was written. Not a signature later found to be wrong — no
    # signature, no name, no account, no qualification reference and no hash.
    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row is not None
        assert row.status == drafts.DRAFT
        assert row.signed_by == ""
        assert row.signed_by_user_id is None
        assert row.signed_at is None
        assert row.signed_qualification_ref == ""
        assert not row.content_hash
    finally:
        owner.close()


def test_the_signature_the_auditor_obtained_is_the_one_that_is_now_refused(cast):
    """The same sequence stated as the property it violates.

    The auditor's report ends "the signatory's name is recorded against bytes
    they never read, and it publishes". So: assert that the hash on the row, if
    a signature is ever recorded, is the hash of what the signatory said they
    read — and that the only way to get one is to say something true.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="What the row records is what was read")

        with TestClient(app) as signatory:
            _sign_in(signatory, SIGNATORY_EMAIL)
            read = signatory.get(f"/watch/drafts/{draft_id}")
            what_they_read = read.json()["current_content_hash"]
            signed = signatory.post(
                f"/watch/drafts/{draft_id}/sign",
                json={"note": "I read it.", "signed_content_hash": what_they_read},
            )

    assert signed.status_code == 200, signed.text

    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row.status == drafts.SIGNED
        assert row.content_hash == what_they_read, (
            "the row records a different hash from the one the signatory said "
            "they read, which is the defect with the comparison passing"
        )
        assert content_hash(row.body) == what_they_read
    finally:
        owner.close()


def test_the_ordinary_read_then_sign_still_succeeds(cast):
    """The other half of every refusal, and the half that decides whether this
    is a control or an obstacle.

    A signatory who reads a draft and signs it must be able to. A check that
    refused this would be one somebody removes.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="Read, then signed, unchanged")

        with TestClient(app) as signatory:
            _sign_in(signatory, SIGNATORY_EMAIL)
            read = signatory.get(f"/watch/drafts/{draft_id}")
            assert read.status_code == 200, read.text
            signed = signatory.post(
                f"/watch/drafts/{draft_id}/sign",
                json={
                    "note": "Read it, and it is right.",
                    "signed_content_hash": read.json()["current_content_hash"],
                },
            )

    assert signed.status_code == 200, signed.text
    view = signed.json()
    assert view["status"] == drafts.SIGNED
    assert view["signed_by_user_id"] == cast["signatory"]
    assert view["signed_by_its_author"] is False


def test_the_route_refuses_a_signature_that_omits_the_hash_entirely(cast):
    """422 at the schema, before the handler runs.

    The field is required rather than defaulted, so the caller that would have
    been attesting to whatever is on the row does not reach the recorder at all.
    Asserted at the route because that is the layer a client meets.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="A signature with nothing to compare")

        with TestClient(app) as signatory:
            _sign_in(signatory, SIGNATORY_EMAIL)
            refused = signatory.post(
                f"/watch/drafts/{draft_id}/sign", json={"note": "Trust me."}
            )

    assert refused.status_code == 422, refused.text

    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row.status == drafts.DRAFT
        assert row.signed_by_user_id is None
    finally:
        owner.close()


# ------------------------------------- a hash that is not this draft's -------


def test_a_hash_from_an_earlier_version_of_the_draft_is_refused(session, cast):
    """A stale hash is not a missing one, and must not be treated as either.

    The signatory read version A, the body moved to version B, and they send A's
    hash. That is the attack's own shape without the assumption that the author
    was hostile — a second browser tab left open is enough — and it must refuse
    for the same reason.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="A hash from before the edit")
            session.flush()
            stale = content_hash(draft.body)
            _edit_the_body(draft)
            session.flush()
            assert content_hash(draft.body) != stale

        with tenancy.acting_as_user(cast["signatory"]):
            with pytest.raises(drafts.SignedBytesMoved) as raised:
                drafts.sign(
                    session,
                    draft.id,
                    signatory="The Signatory",
                    signed_content_hash=stale,
                )

        assert raised.value.submitted == stale
        assert draft.signed_by_user_id is None
        assert not draft.content_hash
        assert draft.status == drafts.DRAFT
        session.rollback()


@pytest.mark.parametrize(
    "submitted",
    [
        pytest.param("", id="empty"),
        pytest.param("   ", id="blank"),
        pytest.param("not-a-hash", id="nonsense"),
        pytest.param("0" * 64, id="right-shape-wrong-value"),
        # The two shapes a hasty comparison gets wrong: a prefix of the real
        # value, and the real value with something appended. Both are computed
        # from the body inside the test, so neither can go stale.
        pytest.param(None, id="a-prefix-of-the-real-hash"),
        pytest.param(..., id="the-real-hash-with-a-suffix"),
    ],
)
def test_a_malformed_or_empty_hash_is_refused_rather_than_treated_as_matching(
    session, cast, submitted
):
    """The failure mode a nullable field invites, asserted rather than argued.

    `if submitted and submitted != current` reads as defensive and is the bug: it
    makes an empty hash mean "nothing to compare, so assume it matches", which is
    the pre-fix behaviour restored by a truthiness check. Every value here must
    refuse, including the two that are the correct value with one character
    wrong.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title=f"Refusing {submitted!r}")
            session.flush()

        real = content_hash(draft.body)
        if submitted is None:
            submitted = real[:-1]
        elif submitted is ...:
            submitted = real + "0"
        assert submitted != real

        with tenancy.acting_as_user(cast["signatory"]):
            with pytest.raises(drafts.SignedBytesMoved):
                drafts.sign(
                    session,
                    draft.id,
                    signatory="The Signatory",
                    signed_content_hash=submitted,
                )

        assert draft.signed_by_user_id is None
        assert not draft.content_hash
        session.rollback()


# ------------------------------------- both bindings on one row at once ------


def test_an_author_signing_their_own_reviewed_draft_carries_both_bindings(
    session, cast
):
    """The self-signature path, which already had one binding and now has two.

    An author may sign their own draft only because somebody independent read
    *this* content — `ReviewedBytesChanged` — and now they must also say which
    bytes *they* are signing. Two comparisons against the same body, and the
    result has to be that the ordinary case still passes: a check that made the
    self-signed path unreachable would have removed the escape hatch that lets a
    firm with one specialist change its rules at all.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Reviewed, then signed by its author")
            session.flush()

        with tenancy.acting_as_user(cast["signatory"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
            )
            session.flush()

        with tenancy.acting_as_user(cast["author"]):
            signed = drafts.sign(
                session,
                draft.id,
                signatory="The Author",
                signed_content_hash=content_hash(draft.body),
            )

        assert signed.status == drafts.SIGNED
        assert signed.signed_by_user_id == cast["author"]
        assert signed.second_reviewer_user_id == cast["signatory"]
        # The two bindings agree, because they are of the same body. If they ever
        # disagreed on a signed row, one of the two comparisons was not made.
        assert signed.content_hash == signed.second_reviewed_content_hash
        session.rollback()


def test_the_signatorys_own_binding_is_checked_before_the_reviewers(session, cast):
    """Which refusal an author meets when both bindings are broken at once.

    Two things can be wrong on a self-signed draft: the review is of superseded
    content (`ReviewedBytesChanged`, addressed to the author about their draft)
    and the signatory's screen is stale (`SignedBytesMoved`, addressed to them
    about their screen). When the body moved after both, the author gets
    `SignedBytesMoved` — because the first thing to tell somebody is that what
    they are looking at is not what is there, and re-reading fixes it. Asserted,
    so that reordering the checks is visible rather than silent.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Both bindings broken at once")
            session.flush()

        with tenancy.acting_as_user(cast["signatory"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
            )
            session.flush()

        stale = content_hash(draft.body)
        with tenancy.acting_as_user(cast["author"]):
            _edit_the_body(draft)
            session.flush()
            with pytest.raises(drafts.SignedBytesMoved):
                drafts.sign(
                    session,
                    draft.id,
                    signatory="The Author",
                    signed_content_hash=stale,
                )

        assert draft.signed_by_user_id is None
        session.rollback()


# ------------------- the two the census found, over HTTP ---------------------


#: `@quolin.test` rather than `@quolin.example`, and the domain is load-bearing.
#: `test_publication_is_platform_scoped_with_dual_control` asserts that platform
#: publication is held by exactly the two named humans the seed creates, and
#: excludes the suite's own synthetic domain from that claim. An account minted
#: here on `@quolin.example` would read as a third real person acquiring the
#: grant that puts rule content in front of every firm — which is the finding
#: that test exists to catch, and it should keep catching it.
APPROVER_EMAIL = "census.approver@quolin.test"
PUBLISHER_EMAIL = "census.publisher@quolin.test"


@pytest.fixture(scope="module")
def publishers() -> dict[str, str]:
    """Two platform publishers who can also read a draft.

    They hold `operator` beside `quolin_operator`, and until this round that
    combination was the only way to be a publisher who could see what they were
    publishing: `POST …/publish` was held to `quolin_operator` and
    `GET /watch/drafts/{id}` was not, so a publisher with no firm role got 403
    from the route that shows a draft and 200 from the route that puts it live.
    The read is `STAFF | {quolin_operator}` now; the grant here is what makes
    these accounts ordinary rather than what makes the test work.
    """
    from conftest import a_platform_publisher

    approver = _person(APPROVER_EMAIL, ("quolin_operator", ""), ("operator", ""))
    publisher = _person(PUBLISHER_EMAIL, ("quolin_operator", ""), ("operator", ""))
    a_platform_publisher(approver)
    a_platform_publisher(publisher)
    return {"approver": approver, "publisher": publisher}


def test_a_publisher_who_read_before_the_signature_is_refused(cast, publishers):
    """The census's own findings, walked over HTTP.

    Wider than the signatory's window because it spans the signature, and every
    step is ordinary:

        the approver and the publisher read the draft while it is in review
          -> its author edits a threshold
          -> a signatory reads the edit and signs it, honestly
          -> the approver approves, and the publisher publishes

    Before this round both of those were 200 and AU gained a version carrying
    9999 with two accounts against it that had read 1000. Verified on the clean
    tree before anything was written.

    Note that the signature here is sound: the signatory read what they signed.
    That is the point — closing the signature's own window would not have closed
    this one, which is why the census exists rather than a fifth targeted fix.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="Read before the signature")

        with (
            TestClient(app) as approver,
            TestClient(app) as publisher,
            TestClient(app) as signatory,
        ):
            _sign_in(approver, APPROVER_EMAIL)
            _sign_in(publisher, PUBLISHER_EMAIL)
            _sign_in(signatory, SIGNATORY_EMAIL)

            # 1. Both publishers read it while it is still a draft, which is when
            #    somebody decides whether they are willing to put it live.
            read = approver.get(f"/watch/drafts/{draft_id}")
            assert read.status_code == 200, read.text
            what_they_read = read.json()["current_content_hash"]
            assert publisher.get(f"/watch/drafts/{draft_id}").status_code == 200

            # 2. The author edits it.
            current = author.get(f"/watch/drafts/{draft_id}")
            assert (
                author.patch(
                    f"/watch/drafts/{draft_id}",
                    json={
                        "thresholds": dict(current.json()["body"]["thresholds"])
                        | {ATTACK_THRESHOLD: ATTACK_VALUE}
                    },
                ).status_code
                == 200
            )

            # 3. A signatory reads the edit and signs it. Nothing is wrong with
            #    this signature; it is of the bytes they were shown.
            after = signatory.get(f"/watch/drafts/{draft_id}")
            signed = signatory.post(
                f"/watch/drafts/{draft_id}/sign",
                json={
                    "note": "Read the edit and signed it.",
                    "signed_content_hash": after.json()["current_content_hash"],
                },
            )
            assert signed.status_code == 200, signed.text
            assert (
                after.json()["body"]["thresholds"][ATTACK_THRESHOLD] == ATTACK_VALUE
            ), "the signatory did not sign the edited body, so this asserts nothing"

            # 4. The approver approves what *they* read, and is refused.
            refused_approval = approver.post(
                f"/watch/drafts/{draft_id}/approve-publication",
                json={"approved_content_hash": what_they_read},
            )
            assert refused_approval.status_code == 409, refused_approval.text
            assert (
                "not the content this approval was given on"
                in refused_approval.json()["detail"]
            )

            # 5. The approver re-reads and approves honestly, so that the only
            #    thing left wrong is the publisher's own stale screen — otherwise
            #    `NeedsASecondApprover` would answer first and this would assert
            #    nothing about the publisher's binding.
            fresh = approver.get(f"/watch/drafts/{draft_id}").json()[
                "current_content_hash"
            ]
            approved = approver.post(
                f"/watch/drafts/{draft_id}/approve-publication",
                json={"approved_content_hash": fresh},
            )
            assert approved.status_code == 200, approved.text

            # 6. And the publisher is refused for the same reason.
            refused_publication = publisher.post(
                f"/watch/drafts/{draft_id}/publish",
                json={"published_content_hash": what_they_read},
            )

    assert refused_publication.status_code == 409, refused_publication.text
    assert (
        "not the content this approval was given on"
        in refused_publication.json()["detail"]
    )

    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row.status == drafts.SIGNED, "it published anyway"
        assert row.published_by_user_id is None
        assert row.published_pack_id is None
    finally:
        owner.close()


def test_the_publication_routes_refuse_a_request_with_no_body_at_all(
    cast, publishers
):
    """422, and it is the shape of the original defect stated as a test.

    Both routes took no body until the census, so this request — a bare POST —
    was the *normal* one and recorded an approval against whatever was on the
    row. It is now the request that cannot say what it read, and is refused
    before the handler runs.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="A bare approval")

        with TestClient(app) as signatory, TestClient(app) as approver:
            _sign_in(signatory, SIGNATORY_EMAIL)
            _sign_in(approver, APPROVER_EMAIL)
            read = signatory.get(f"/watch/drafts/{draft_id}")
            assert (
                signatory.post(
                    f"/watch/drafts/{draft_id}/sign",
                    json={
                        "note": "Signed.",
                        "signed_content_hash": read.json()["current_content_hash"],
                    },
                ).status_code
                == 200
            )

            bare_approval = approver.post(
                f"/watch/drafts/{draft_id}/approve-publication"
            )
            bare_publication = approver.post(f"/watch/drafts/{draft_id}/publish")

    assert bare_approval.status_code == 422, bare_approval.text
    assert bare_publication.status_code == 422, bare_publication.text


def test_the_ordinary_read_then_approve_then_publish_still_works(cast, publishers):
    """The half that decides whether this is a control or an obstacle.

    Two publishers read a signed draft and put it live. If this did not pass,
    nothing could be published at all and the binding would be removed by
    whoever discovered that on a Friday.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="Read, approved, published")

        with (
            TestClient(app) as signatory,
            TestClient(app) as approver,
            TestClient(app) as publisher,
        ):
            _sign_in(signatory, SIGNATORY_EMAIL)
            _sign_in(approver, APPROVER_EMAIL)
            _sign_in(publisher, PUBLISHER_EMAIL)

            read = signatory.get(f"/watch/drafts/{draft_id}")
            assert (
                signatory.post(
                    f"/watch/drafts/{draft_id}/sign",
                    json={
                        "note": "Signed.",
                        "signed_content_hash": read.json()["current_content_hash"],
                    },
                ).status_code
                == 200
            )

            approved = approver.post(
                f"/watch/drafts/{draft_id}/approve-publication",
                json={
                    "approved_content_hash": approver.get(
                        f"/watch/drafts/{draft_id}"
                    ).json()["current_content_hash"]
                },
            )
            assert approved.status_code == 200, approved.text

            published = publisher.post(
                f"/watch/drafts/{draft_id}/publish",
                json={
                    "published_content_hash": publisher.get(
                        f"/watch/drafts/{draft_id}"
                    ).json()["current_content_hash"]
                },
            )

    assert published.status_code == 200, published.text
    assert published.json()["jurisdiction"] == "AU"

    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row.status == drafts.PUBLISHED
        assert row.published_by_user_id == publishers["publisher"]
    finally:
        owner.close()


def test_a_publisher_holding_no_firm_role_can_read_what_they_publish(cast):
    """The finding on the way past, asserted so it cannot come back.

    `POST …/approve-publication` and `POST …/publish` are held to
    `quolin_operator`. `GET /watch/drafts/{id}` was held to the firm roles only,
    so a platform publisher holding nothing else got 403 from the route that
    shows a draft and 200 from the route that puts it in front of every customer
    on the platform. They were pressing a button on a draft id.

    It is also what makes the binding satisfiable: `current_content_hash` is
    emitted by this route and nowhere else, so a publisher who cannot read a
    draft cannot say what they read.
    """
    from conftest import a_platform_publisher

    email = "census.bare-publisher@quolin.test"
    a_platform_publisher(_person(email, ("quolin_operator", "")))

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="Readable by whoever publishes it")

        with TestClient(app) as bare:
            _sign_in(bare, email)
            read = bare.get(f"/watch/drafts/{draft_id}")

    assert read.status_code == 200, (
        "a platform publisher cannot read the draft they are entitled to "
        f"publish: {read.text}"
    )
    assert read.json()["current_content_hash"], (
        "the draft read back without the hash the publication routes require, so "
        "this publisher could not approve or publish it truthfully"
    )


# --------------------------------------- the three windows are all named -----


def test_each_window_has_its_own_refusal_and_they_are_told_apart():
    """Five refusals, five audiences, and none of them collapsible.

    The naming is load-bearing. `*BytesMoved` means the attester's screen was
    stale and re-reading fixes it; `*BytesChanged` means the draft moved after
    somebody attested to it, which is a fact about the draft that re-reading does
    not fix. Collapsing a pair would hand one person a message written for
    another — the argument F1 made about its two, extended to all five as the
    census added two more.
    """
    windows = {
        drafts.ReviewedBytesMoved: "reading -> second review",
        drafts.SignedBytesMoved: "reading -> signature",
        drafts.ApprovedBytesMoved: "reading -> approval and publication",
        drafts.ReviewedBytesChanged: "second review -> signature",
        drafts.SignedBytesChanged: "signature -> publication",
    }
    assert len(set(windows)) == 5, "two windows are the same class"
    for refusal in windows:
        assert issubclass(refusal, PermissionError), (
            f"{refusal.__name__} is not a PermissionError, so a caller that "
            "catches the family would miss it"
        )

    moved = (
        drafts.ReviewedBytesMoved(1, "abc"),
        drafts.SignedBytesMoved(1, "abc"),
        drafts.ApprovedBytesMoved(1, "abc"),
    )
    for exc in moved:
        assert "Nothing has been" in str(exc) or "nothing has been" in str(exc), (
            f"{type(exc).__name__} does not tell the person that nothing was "
            "recorded, which is the first thing they need to know"
        )
        assert exc.submitted == "abc", (
            f"{type(exc).__name__} drops what the caller said it read, which is "
            "the value that answers which version they had"
        )
