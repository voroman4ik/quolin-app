"""§S7's gate: a hundred documents queued, and the API still answering.

    "100 artefacts queued render without blocking the API"

The temptation is to assert a wall-clock number, which would be a flaky test of
this machine's load rather than of the design. What actually has to be true is
structural: **enqueueing renders nothing**. So the renderer is replaced with one
that raises, a hundred documents are queued through the API, and the API is
expected not to notice — which is a claim about the code path, and true on a
slow machine and a fast one alike.

The rest of the file is what a queue has to survive: two workers, a worker
killed mid-render, a job that will never succeed, and the same document asked
for three times.
"""

from __future__ import annotations

from datetime import timedelta

import pytest
from sqlalchemy import func, select

from app import tenancy
from app.artefacts import queue, runner
from app.main import _aggregate
from app.models import Artefact, ArtefactJob, Decision

DEMO_TENANT = "demo"
ACTOR = "usr_test_queue"


@pytest.fixture
def undo(session):
    """Undo what a test queued, including through the API.

    Two mechanisms, because there are two ways rows get here. A rollback deals
    with what this session flushed — the shared session means rows left pending
    are committed by whichever test commits next. But `client.post` runs the
    real endpoint on its own session and *commits*, so a hundred queued jobs
    survive any rollback here. Those are deleted by id.

    Deleting is fine: `artefact_jobs` is workflow, not evidence. The artefacts a
    drained job produced are left alone — rendering is deterministic, so a
    re-run updates the same row with the same bytes.
    """
    with tenancy.acting_as(DEMO_TENANT):
        high_water = session.scalar(select(func.max(ArtefactJob.id))) or 0
    try:
        yield
    finally:
        session.rollback()
        with tenancy.acting_as(DEMO_TENANT):
            session.query(ArtefactJob).filter(ArtefactJob.id > high_water).delete(
                synchronize_session=False
            )
            session.commit()


def _decisions(session, count: int) -> list[int]:
    ids = list(
        session.scalars(
            select(Decision.id)
            .where(Decision.pack_id == "AU")
            .order_by(Decision.id.desc())
            .limit(count)
        )
    )
    assert len(ids) >= count, f"seed has fewer than {count} AU determinations"
    return ids


def _hundred_documents(session) -> list[dict]:
    """A hundred *distinct* documents, which is not the same as a hundred jobs.

    Asking twice for the same document returns the first job — deliberately, and
    tested below — so a hundred repetitions would queue one. A hundred distinct
    ones is what the gate is about, and a freshly seeded demo does not have
    enough determinations to reach it from those alone: 43 AU determinations
    times two per-determination kinds is 86. The remainder comes from period
    documents, which is closer to a real month-end anyway — a firm producing a
    hundred documents at once is producing both shapes.
    """
    from app import reports

    documents = [
        {"kind": kind, "decision_id": i}
        for i in _decisions(session, 40)
        for kind in ("tmd", "evidence_pack")
    ]
    periods = reports.available_periods(session, jurisdiction="AU")
    for entry in periods:
        for kind in ("regulatory_return", "override_report"):
            if len(documents) >= 100:
                break
            documents.append(
                {"kind": kind, "period": entry["period"], "jurisdiction": "AU"}
            )

    assert len(documents) == 100, (
        f"the seed can only supply {len(documents)} distinct documents; the gate "
        "is a hundred. Run `make seed`."
    )
    return documents


# --- The gate ----------------------------------------------------------------


def test_a_hundred_documents_queue_without_rendering_any_of_them(
    client, session, undo, monkeypatch
):
    """§S7's gate, as a claim about the code path rather than about the clock.

    A renderer that raises on sight. If enqueueing touched it — even once, even
    for the first document — this fails. That is a stronger statement than any
    timing assertion: it holds on a loaded machine, and it keeps holding when
    somebody later adds a "render the first one eagerly so the UI feels fast"
    shortcut.
    """
    def refuse(*args, **kwargs):
        raise AssertionError("a document was rendered inside the request")

    monkeypatch.setattr("app.artefacts.renderer._to_pdf", refuse)

    with tenancy.acting_as(DEMO_TENANT):
        documents = _hundred_documents(session)

    got = client.post("/artefacts/batch", json={"jobs": documents})

    assert got.status_code == 202, got.text
    jobs = got.json()["jobs"]
    assert len(jobs) == 100
    assert all(j["status"] == queue.QUEUED for j in jobs)
    assert all(j["artefact_id"] is None for j in jobs)


def test_the_api_still_answers_while_a_hundred_are_outstanding(client, session, undo):
    """The other half of the same gate: a full queue is not a busy API.

    Nothing is rendering — that is the point — so the determination endpoint,
    which shares the pool, is unaffected by the depth of the queue.
    """
    with tenancy.acting_as(DEMO_TENANT):
        documents = _hundred_documents(session)
    client.post("/artefacts/batch", json={"jobs": documents})

    health = client.get("/health")
    assert health.status_code == 200

    listed = client.get("/artefacts/jobs")
    assert listed.status_code == 200
    assert listed.json()["depth"][queue.QUEUED] >= 100


def test_the_worker_drains_what_the_api_queued(client, session, undo):
    """And the documents are real ones, with provenance, at the end of it.

    Ten rather than a hundred: rendering is the slow part and this test is about
    the queue draining, not about how many PDFs a laptop can produce in a
    minute. The hundred is asserted above, where it costs nothing.
    """
    with tenancy.acting_as(DEMO_TENANT):
        ids = _decisions(session, 10)

    queued = client.post(
        "/artefacts/batch",
        json={"jobs": [{"kind": "tmd", "decision_id": i} for i in ids]},
    ).json()["jobs"]

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        tally = runner.drain(session, aggregate=_aggregate, limit=50)

    assert tally["failed"] == 0, "a document failed to render"
    assert tally["done"] >= 10

    with tenancy.acting_as(DEMO_TENANT):
        for entry in queued:
            job = session.get(ArtefactJob, entry["id"])
            assert job.status == queue.DONE
            artefact = session.get(Artefact, job.artefact_id)
            assert artefact is not None
            assert artefact.content_hash and artefact.pack_version


# --- What a queue has to survive ---------------------------------------------


def test_two_workers_never_take_the_same_job(session, undo):
    """`FOR UPDATE SKIP LOCKED`, which is the whole of the concurrency control.

    Two sessions, one job. The second must come away with nothing rather than
    waiting for the first — a queue where workers block on each other is a queue
    with one worker.
    """
    from app.db import SessionLocal

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        ids = _decisions(session, 1)
        queue.enqueue(session, kind="tmd", params={"decision_id": str(ids[0])})
        session.commit()

        first = queue.claim(session)
        assert first is not None

        other = SessionLocal()
        try:
            second = queue.claim(other)
            assert second is None or second.id != first.id, (
                "two workers claimed the same job"
            )
        finally:
            other.rollback()
            other.close()


def test_a_worker_killed_mid_render_loses_only_that_document(session, undo):
    """The claim is a row update, so a process that dies leaves a `running` row
    with an old `started_at`. Once the lease expires another worker takes it —
    which is what makes a mid-run kill a delay rather than a stuck job."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        ids = _decisions(session, 1)
        job, _ = queue.enqueue(session, kind="tmd", params={"decision_id": str(ids[0])})
        session.flush()

        claimed = queue.claim(session)
        assert claimed is not None and claimed.id == job.id

        # Nobody can take it while the lease holds.
        assert queue.claim(session) is None

        # The worker died. Its claim ages out.
        job.started_at = job.started_at - timedelta(minutes=30)
        session.flush()
        reclaimed = queue.claim(session)

    assert reclaimed is not None and reclaimed.id == job.id
    assert reclaimed.attempts == 2, "a reclaim should count as another attempt"


def test_a_job_that_cannot_succeed_stops_and_says_why(session, undo):
    """Bounded retries, and the reason left on the row. A document somebody
    asked for and never received has to be findable — by them, and by whoever is
    asked why it never arrived."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        job, _ = queue.enqueue(
            session, kind="tmd", params={"decision_id": "999999999"}
        )
        # Committed, not just flushed: `drain` rolls back a failed render, which
        # would otherwise discard the job row along with it. A worker's session
        # starts clean, so this is what actually happens — the enqueue was
        # committed by the request that made it.
        session.commit()

        for _ in range(queue.MAX_ATTEMPTS + 2):
            tally = runner.drain(session, aggregate=_aggregate, limit=5)
            if tally == {"done": 0, "failed": 0}:
                break

        session.expire_all()
        dead = session.get(ArtefactJob, job.id)

    assert dead.status == queue.FAILED
    assert dead.attempts == queue.MAX_ATTEMPTS, "retried more than the limit"
    assert "999999999" in dead.last_error or "unknown decision" in dead.last_error


def test_asking_twice_for_the_same_document_queues_it_once(session, undo):
    """A screen with an eager button, a retrying client and a month-end schedule
    all asking at once would otherwise render it three times and leave three rows
    claiming to be the document that was filed."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        ids = _decisions(session, 1)
        params = {"decision_id": str(ids[0])}
        first, created_first = queue.enqueue(session, kind="tmd", params=params)
        second, created_second = queue.enqueue(session, kind="tmd", params=params)
        session.flush()

    assert created_first is True
    assert created_second is False
    assert second.id == first.id


def test_a_finished_job_does_not_block_a_deliberate_regeneration(session, undo):
    """Regenerating on purpose is a thing people do — the figures changed, the
    pack was corrected. Deterministic rendering means an unnecessary one costs a
    render and changes nothing."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        ids = _decisions(session, 1)
        params = {"decision_id": str(ids[0])}
        first, _ = queue.enqueue(session, kind="tmd", params=params)
        session.flush()
        runner.drain(session, aggregate=_aggregate, limit=5)

        again, created = queue.enqueue(session, kind="tmd", params=params)
        session.flush()

    assert created is True
    assert again.id != first.id


def test_the_fingerprint_ignores_key_order(session):
    """Two callers building the same request differently are asking for the same
    document."""
    a = queue.fingerprint("regulatory_return", {"period": "2026-08", "jurisdiction": "AU"})
    b = queue.fingerprint("regulatory_return", {"jurisdiction": "AU", "period": "2026-08"})
    assert a == b


def test_a_period_document_queues_and_renders_from_its_period(client, session, undo):
    """The other job shape. A return is asked for by period and regime, and the
    figures are computed by the worker rather than carried through the queue —
    so a return queued on the 31st and rendered on the 1st reports the period,
    not whatever was known when the button was pressed."""
    from app import reports

    with tenancy.acting_as(DEMO_TENANT):
        periods = reports.available_periods(session, jurisdiction="AU")
        assert periods

    got = client.post(
        "/artefacts/batch",
        json={
            "jobs": [
                {
                    "kind": "regulatory_return",
                    "period": periods[0]["period"],
                    "jurisdiction": "AU",
                }
            ]
        },
    )
    assert got.status_code == 202, got.text
    job_id = got.json()["jobs"][0]["id"]

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        runner.drain(session, aggregate=_aggregate, limit=5)
        session.expire_all()
        job = session.get(ArtefactJob, job_id)
        artefact = session.get(Artefact, job.artefact_id) if job.artefact_id else None

    assert job.status == queue.DONE, job.last_error
    assert artefact is not None
    assert artefact.window_start is not None and artefact.window_end is not None
    assert artefact.window_start <= artefact.window_end


# --- Delivery ----------------------------------------------------------------


def test_a_finished_document_tells_the_customers_systems(session, undo):
    """§S7: returns "delivered to console + webhook". The console half is the
    queue screen; this is the other. A customer who queued a month-end return
    should not have to poll for it."""
    from app import webhooks
    from app.identity import new_id
    from app.models import WebhookDelivery, WebhookEndpoint

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        endpoint = WebhookEndpoint(
            id=new_id("whe"),
            url="https://case-system.example/quolin",
            label="Queue test endpoint",
            secret=webhooks.new_secret(),
            events=[],
            status="active",
        )
        session.add(endpoint)
        ids = _decisions(session, 1)
        queue.enqueue(session, kind="tmd", params={"decision_id": str(ids[0])})
        session.commit()
        try:
            runner.drain(session, aggregate=_aggregate, limit=5)
            sent = session.scalars(
                select(WebhookDelivery).where(
                    WebhookDelivery.endpoint_id == endpoint.id,
                    WebhookDelivery.event == "artefact.ready",
                )
            ).all()

            assert sent, "a finished document told nobody"
            payload = sent[0].payload
            assert payload["download_url"].startswith("/artefacts/")
            assert payload["content_hash"]
            assert payload["pack_version"]
        finally:
            session.query(WebhookDelivery).filter_by(endpoint_id=endpoint.id).delete(
                synchronize_session=False
            )
            session.delete(session.get(WebhookEndpoint, endpoint.id))
            session.commit()


def test_a_document_that_never_rendered_says_so_out_loud(session, undo):
    """The half that matters more. A document asked for and never produced is
    exactly what a customer must not discover for themselves at the end of a
    reporting period — and it is only announced once retrying has stopped, since
    telling somebody it failed and then producing it teaches them to ignore us.
    """
    from app import webhooks
    from app.identity import new_id
    from app.models import WebhookDelivery, WebhookEndpoint

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        endpoint = WebhookEndpoint(
            id=new_id("whe"),
            url="https://case-system.example/quolin",
            label="Queue failure endpoint",
            secret=webhooks.new_secret(),
            events=[],
            status="active",
        )
        session.add(endpoint)
        queue.enqueue(session, kind="tmd", params={"decision_id": "999999999"})
        session.commit()
        try:
            announcements = []
            # `limit=1`, so each call is one attempt. A larger limit exhausts
            # every retry inside a single call, which would make "nothing was
            # said on the first failure" untestable — the first call would
            # already have reached the last attempt.
            for _ in range(queue.MAX_ATTEMPTS + 2):
                tally = runner.drain(session, aggregate=_aggregate, limit=1)
                announcements.append(
                    session.scalars(
                        select(WebhookDelivery).where(
                            WebhookDelivery.endpoint_id == endpoint.id,
                            WebhookDelivery.event == "artefact.failed",
                        )
                    ).all()
                )
                if tally == {"done": 0, "failed": 0}:
                    break

            # Nothing said on the first failure, exactly one thing said in the end.
            assert announcements[0] == []
            assert len(announcements[-1]) == 1
            assert announcements[-1][0].payload["error"]
        finally:
            session.query(WebhookDelivery).filter_by(endpoint_id=endpoint.id).delete(
                synchronize_session=False
            )
            session.delete(session.get(WebhookEndpoint, endpoint.id))
            session.commit()


# --- Priority: a batch must not bury a person ---------------------------------
#
# §S12: "bulk runs not starving interactive traffic (queue priorities)". The
# failure is specific and quiet — ten thousand documents go in for a quarter's
# returns, the officer who then asks for one determination's TMD is behind all
# of them, and nothing is broken. The render is simply scheduled for tomorrow.


def test_one_persons_document_is_not_buried_behind_a_batch(session, undo):
    """The batch is queued first and still waits.

    Written with the batch first on purpose: with FIFO this test fails, which is
    the only arrangement that proves the priority does anything.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        ids = _decisions(session, 1)

        for n in range(25):
            queue.enqueue(
                session,
                kind="period_return",
                params={"period": f"2026-{n % 12 + 1:02d}", "jurisdiction": "AU"},
                scope="period",
            )
        # And then a person asks for one document.
        wanted, _ = queue.enqueue(
            session,
            kind="tmd",
            params={"decision_id": str(ids[0])},
            scope="decision",
        )
        session.commit()

        claimed = queue.claim(session)
        assert claimed is not None
        assert claimed.id == wanted.id, (
            "the batch was claimed first — a person is waiting behind 25 "
            "documents nobody is watching"
        )


def test_within_a_priority_it_is_still_first_in_first_out(session, undo):
    """Priority reorders between classes of work, not inside one.

    Otherwise the second document somebody asks for could overtake the first,
    which is a different unfairness with the same shape.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        ids = _decisions(session, 3)
        queued = [
            queue.enqueue(
                session,
                kind="tmd",
                params={"decision_id": str(decision_id)},
                scope="decision",
            )[0]
            for decision_id in ids
        ]
        session.commit()

        order = []
        for _ in queued:
            claimed = queue.claim(session)
            assert claimed is not None
            order.append(claimed.id)
            session.commit()

    assert order == [job.id for job in queued], "order changed inside one priority"


def test_a_job_queued_without_a_scope_is_treated_as_batch(session, undo):
    """The safe direction to be wrong in.

    A caller that has not been taught about scopes should not be able to promote
    its work by omission. A batch served early is a delay; an interactive job
    served late is a person waiting.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        ids = _decisions(session, 1)
        job, _ = queue.enqueue(session, kind="tmd", params={"decision_id": str(ids[0])})
        session.commit()
        assert job.priority == queue.BATCH


def test_a_steady_trickle_of_urgent_work_still_lets_a_batch_through(session, undo):
    """The failure the second sort key exists to prevent.

    Priority alone is a starvation machine pointed the other way: if interactive
    work always wins, a batch queued on Monday is still queued on Friday. This
    does not prove liveness under a real trickle — nothing here runs for a week
    — but it does prove that the claim is ordered rather than filtered, so an
    empty interactive class hands the queue straight back to the batch.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        batch, _ = queue.enqueue(
            session,
            kind="period_return",
            params={"period": "2026-03", "jurisdiction": "AU"},
            scope="period",
        )
        ids = _decisions(session, 1)
        urgent, _ = queue.enqueue(
            session, kind="tmd", params={"decision_id": str(ids[0])}, scope="decision"
        )
        session.commit()

        first = queue.claim(session)
        session.commit()
        second = queue.claim(session)
        session.commit()

    assert first is not None and second is not None
    assert first.id == urgent.id
    assert second.id == batch.id, "the batch never came back"
