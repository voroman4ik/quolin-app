"""FP3-10: the three lists that disagreed about `artefacts`, reconciled.

  * `scripts/lint_migrations.sh` guarded five table names, `artefacts` among
    them.
  * `models.APPEND_ONLY_TABLES` named eleven, `artefacts` **not** among them.
  * The database enforced thirteen triggers, `artefacts` **not** among them.

No two matched, and the reconciliation took three attempts because the first two
were guesses at what the answer should be rather than readings of what the code
does.

**It is not append-only**, and that is the answer rather than a concession.
`artefacts/renderer.py` re-renders an existing document — same kind, same
`ref_id`, same pack version — and updates the row. That is §S7's design: a
return regenerated after more determinations have landed in its window is a
different document and the row follows it.

**And `content_hash` is not unconditionally write-once either**, which was the
second wrong guess. What §S7 actually claims, and what `renderer.py` actually
enforces, is narrower and more useful: the same *inputs* must produce the same
*bytes*. Different inputs, different hash, and the row is refreshed.

Migration 0041 gives that claim its second lock, in the database, so it no
longer rests on a single application-level `if`.
"""

from __future__ import annotations

import pytest
from sqlalchemy import text

from app.db import owner_engine
from app.models import APPEND_ONLY_TABLES


def _probe_row(conn, ref: str, content_hash: str, inputs_hash: str) -> int:
    """One artefact row, inside a transaction that is rolled back."""
    return int(
        conn.execute(
            text(
                "INSERT INTO artefacts (tenant_id, kind, ref_id, title, "
                "template_version, pdf_ref, content_hash, inputs_hash, "
                "created_at) VALUES ('demo', 'probe', :ref, 'Determinism probe', "
                "'v1', 'x.pdf', :content, :inputs, now()) RETURNING id"
            ),
            {"ref": ref, "content": content_hash, "inputs": inputs_hash},
        ).scalar()
    )


def test_artefacts_is_deliberately_not_append_only():
    """Stated as an assertion so the next reconciliation starts from the answer.

    A comment saying "we decided artefacts is mutable" is a comment somebody
    deletes. This fails if it is ever added to the tuple without the renderer
    being restructured first.
    """
    assert "artefacts" not in APPEND_ONLY_TABLES, (
        "artefacts was added to APPEND_ONLY_TABLES. `artefacts/renderer.py` "
        "updates an existing row when a document is re-rendered, which is §S7's "
        "design — sixteen tests say so. If that has genuinely changed, this "
        "assertion is the place to say why."
    )


def test_the_same_inputs_cannot_produce_a_different_document():
    """§S7's determinism gate, asserted against the database rather than the code.

    Made to happen rather than reasoned about: a row is written with one pair of
    hashes and then updated to claim different bytes from the same inputs, which
    is precisely what `NotDeterministic` exists to refuse. The application check
    is not in the path here — this is the second lock, on its own.
    """
    conn = owner_engine.connect()
    transaction = conn.begin()
    try:
        artefact_id = _probe_row(conn, "fp3-10a", "aaaa", "inputs-1")

        with pytest.raises(Exception, match="impossible"):
            conn.execute(
                text(
                    "UPDATE artefacts SET content_hash = 'bbbb' WHERE id = :id"
                ),
                {"id": artefact_id},
            )
    finally:
        transaction.rollback()
        conn.close()


def test_different_inputs_may_produce_a_different_document():
    """The other half, and the reason the trigger is conditional.

    A return regenerated after more determinations have landed in its window
    legitimately has different bytes. A trigger that refused this would break
    every report in the suite — which is how the second draft of this was found.
    """
    conn = owner_engine.connect()
    transaction = conn.begin()
    try:
        artefact_id = _probe_row(conn, "fp3-10b", "aaaa", "inputs-1")

        conn.execute(
            text(
                "UPDATE artefacts SET content_hash = 'bbbb', "
                "inputs_hash = 'inputs-2' WHERE id = :id"
            ),
            {"id": artefact_id},
        )
        now = conn.execute(
            text("SELECT content_hash FROM artefacts WHERE id = :id"),
            {"id": artefact_id},
        ).scalar()
        assert now == "bbbb"
    finally:
        transaction.rollback()
        conn.close()


def test_an_empty_hash_may_still_be_filled_in():
    """Rows written before provenance existed carry none.

    The bytes in front of us are what they describe, so filling an empty hash is
    a fact rather than a rewrite.
    """
    conn = owner_engine.connect()
    transaction = conn.begin()
    try:
        artefact_id = _probe_row(conn, "fp3-10c", "", "inputs-1")

        conn.execute(
            text("UPDATE artefacts SET content_hash = 'cccc' WHERE id = :id"),
            {"id": artefact_id},
        )
    finally:
        transaction.rollback()
        conn.close()
