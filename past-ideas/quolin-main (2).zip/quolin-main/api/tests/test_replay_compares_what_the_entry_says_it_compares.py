"""FP3-07: `replay` compared less than the F10 entry claimed.

`evidence.record` stores two keys under `rule_results`: `results`, and
`not_applicable` — the rules a pack contains that did not apply to this client.
`evidence.replay` compared the first and never read the second.

That made F10's own justification false about the list it was arguing from:

    `rules_not_applicable` is stored on every decision row and compared
    field-by-field by `evidence.replay`

It is stored. It was not compared.

**What that missed is a real class of change.** A rule whose applicability moves
— a client category added to its `applies_to`, a threshold deciding whether it
is in scope at all — changes *which* rules ran without necessarily changing the
outcome of the ones that did. Replay reproduced the outcome, reported no
differences, and the determination on file went on saying a rule was out of
scope while today's content says it is in.

**Checked before it was changed, as the standing rule requires.** All 6457
seeded decisions replay with no mismatch after this, and `make nightly-replay
ARGS=--inject` still catches a forced outcome. Nothing on file moved.
"""

from __future__ import annotations

import pytest
from sqlalchemy import select

from app import evidence, packs_repo, service, tenancy
from app.db import SessionLocal
from app.models import Decision
from tests.conftest import DEMO_TENANT


@pytest.fixture
def a_decision_and_its_pack():
    with tenancy.acting_as(DEMO_TENANT):
        with SessionLocal() as session:
            decision = session.scalars(
                select(Decision)
                .where(Decision.pack_id.is_not(None))
                .order_by(Decision.id)
            ).first()
            assert decision is not None, "no seeded decisions — run `make seed`"
            pack = packs_repo.by_version(
                session, decision.pack_id or "AU", decision.pack_version
            )
            others = service._other_packs(session, decision)
            yield session, decision, pack, others


def test_a_decision_on_file_still_replays_exactly(a_decision_and_its_pack):
    """The control. Adding a comparison must not manufacture a mismatch.

    A replay mismatch is what the chain-mismatch runbook says to treat as
    tampering, so a change that widens what replay checks has to be shown not to
    make every determination on file look tampered with.
    """
    _, decision, pack, others = a_decision_and_its_pack
    result = evidence.replay(decision, pack, others)
    assert result["differences"] == [], result["differences"]
    assert result["replayed_outcome"] == decision.outcome


def test_the_stored_not_applicable_is_actually_read(a_decision_and_its_pack):
    """The finding, made to fire.

    The stored list is altered in memory — nothing is written, `decisions` is
    append-only and this is not a test that would be worth breaking that for —
    and replay must now notice. Before FP3-07 it reported no differences at all.
    """
    _, decision, pack, others = a_decision_and_its_pack

    stored = dict(decision.rule_results)
    assert "not_applicable" in stored, (
        "this decision predates F10 and carries no not_applicable list, so it "
        "cannot exercise the comparison"
    )
    stored["not_applicable"] = list(stored["not_applicable"]) + ["rule-that-never-ran"]
    decision.rule_results = stored

    result = evidence.replay(decision, pack, others)

    fields = [d["field"] for d in result["differences"]]
    assert any(f.endswith("not_applicable") for f in fields), (
        "replay did not notice that the stored list of rules-that-did-not-apply "
        f"disagrees with the pack: {result['differences']}"
    )


def test_reordering_the_list_is_not_a_mismatch(a_decision_and_its_pack):
    """Compared as a set, and deliberately.

    The stored value is built by walking the pack's rules in order, so a pack
    edit that reorders two rules neither of which changed would otherwise report
    every determination on file as a replay mismatch — and the runbook says to
    treat one of those as tampering. Order here carries no meaning.
    """
    _, decision, pack, others = a_decision_and_its_pack

    stored = dict(decision.rule_results)
    entries = list(stored["not_applicable"])
    if len(entries) < 2:
        pytest.skip("this decision has fewer than two inapplicable rules to reorder")

    stored["not_applicable"] = list(reversed(entries))
    decision.rule_results = stored

    result = evidence.replay(decision, pack, others)
    fields = [d["field"] for d in result["differences"]]
    assert not any(f.endswith("not_applicable") for f in fields), (
        f"reordering the list was reported as a mismatch: {result['differences']}"
    )


def test_a_decision_recorded_before_f10_is_not_reported_as_broken(
    a_decision_and_its_pack,
):
    """Absent is not a difference.

    `not_applicable` arrived with F10. Every determination made before it has no
    such key, and replaying one must not manufacture a mismatch out of a field
    that did not exist when it was recorded — which would turn an upgrade into a
    tampering alert across a customer's whole history.
    """
    _, decision, pack, others = a_decision_and_its_pack

    stored = {k: v for k, v in decision.rule_results.items() if k != "not_applicable"}
    decision.rule_results = stored

    result = evidence.replay(decision, pack, others)
    fields = [d["field"] for d in result["differences"]]
    assert not any(f.endswith("not_applicable") for f in fields), result["differences"]


def test_reordering_what_a_rule_read_is_not_a_mismatch(a_decision_and_its_pack):
    """FP3-20. Replay was bound to the evaluator's walk order.

    `inputs_read` records what a rule consulted and is built by walking the
    predicate, so its order is `evaluate_condition`'s traversal order — an
    implementation detail, not a claim about the determination. It was compared
    by list equality inside the whole-result comparison.

    So **any refactor that reordered resolution would make every determination
    on file fail to reproduce with the outcome unchanged**, and
    `docs/runbooks/` says to treat a replay mismatch as a possible tamper. A
    tidy-up inside the evaluator would have produced a platform-wide security
    incident containing no security event.

    Checked before changing anything: all 12,311 seeded decisions replay with no
    mismatch after this.
    """
    _, decision, pack, others = a_decision_and_its_pack

    stored = dict(decision.rule_results)
    results = [dict(r) for r in stored["results"]]

    reordered = 0
    for result in results:
        reads = result.get("inputs_read") or []
        if len(reads) > 1:
            result["inputs_read"] = list(reversed(reads))
            reordered += 1
    if not reordered:
        pytest.skip("no rule on this decision read more than one input")

    stored["results"] = results
    decision.rule_results = stored

    outcome = evidence.replay(decision, pack, others)
    assert outcome["differences"] == [], (
        "reversing the order a rule read its inputs was reported as a replay "
        f"mismatch, which the runbook says to treat as tampering: "
        f"{outcome['differences']}"
    )


def test_a_changed_value_is_still_a_mismatch(a_decision_and_its_pack):
    """The other half, and the one that matters.

    Comparing provenance as a set discards the order and must not discard the
    contents — otherwise the fix has bought reproducibility by no longer
    checking anything.
    """
    _, decision, pack, others = a_decision_and_its_pack

    stored = dict(decision.rule_results)
    results = [dict(r) for r in stored["results"]]

    changed = False
    for result in results:
        reads = [dict(r) for r in (result.get("inputs_read") or [])]
        if reads:
            reads[0]["value"] = "a value this rule never read"
            result["inputs_read"] = reads
            changed = True
            break
    if not changed:
        pytest.skip("no rule on this decision recorded an input to alter")

    stored["results"] = results
    decision.rule_results = stored

    outcome = evidence.replay(decision, pack, others)
    assert outcome["differences"], (
        "a rule's recorded input was changed to a value it never read and "
        "replay reported no difference"
    )
