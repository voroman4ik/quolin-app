"""F1: the review binds to what the reviewer read, not to the row at POST time.

B1 bound a second review to content — and hashed that content when the approval
arrived. The reviewer read the draft some minutes earlier. Everything between
those two moments was unguarded, and the auditor walked it against this tree:

    the reviewer opens the draft and reads
    `max_crypto_concentration_bps = 1000`
      -> its author, who holds `operator`, PATCHes it to 9999
      -> the reviewer POSTs their approval
      -> the author signs their own draft

    200. Signed by the author, with the reviewer's account recorded against
    bytes they had never seen.

Every B1 check passed and each of them was right about what it asked.
`record_second_review` hashed the body it found and stored it; `sign` compared
that hash against the same body and matched; `pack_drafts_self_signature_
reviewed_these_bytes` compared two columns that agreed. The review was bound to
the content — to the *author's* content, which is not the claim a second review
makes.

So the reviewer now says which bytes they read, and the server refuses if the
row has moved since. `view` returns `current_content_hash` for the client to
send back; `SecondReviewRequest.reviewed_content_hash` is required, with no
default, because a caller that could omit it would be attesting to whatever is
there now; and `record_second_review` raises `ReviewedBytesMoved`.

**`ReviewedBytesMoved` and `ReviewedBytesChanged` are distinct on purpose**, and
the tests below assert which one a caller meets. `ReviewedBytesChanged` tells an
*author* that their draft moved after the review, so they may not sign it.
`ReviewedBytesMoved` tells a *reviewer* that what they are about to approve is
not what they were shown. Collapsing them would hand a reviewer a message about
somebody else's signature.

The four cases the fix has to survive are the four here: the attack; the
ordinary read-then-approve, which must still work; a hash from a version that
has been superseded; and a hash that is empty, blank or nonsense, which must
fail rather than be treated as "nothing to compare, so assume it matches".
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from conftest import (
    DEMO_TENANT,
    SEED_PASSWORD,
    reset_rate_limit_for_tests,
    the_bytes_on_the_row,
    what_this_client_reads,
)
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import identity, tenancy, totp
from app.db import OwnerSessionLocal
from app.main import app
from app.models import MfaCredential, PackDraft
from app.watch import drafts
from app.watch.lifecycle import content_hash

#: Far enough out that nothing here is ever the pack in force.
FAR_FUTURE = 3650

#: This file's own cast, for the reason
#: `test_a_review_is_bound_to_the_content_it_reviewed.py` gives for having one:
#: a change to another file's accounts must not quietly change what this asserts.
AUTHOR_EMAIL = "f1.author@quolin.example"
REVIEWER_EMAIL = "f1.reviewer@quolin.example"

#: What the author changes while the reviewer is reading. A threshold rather
#: than a note: the difference between "the reviewer did not see this word" and
#: "the reviewer did not see this number the engine decides on".
ATTACK_THRESHOLD = "max_crypto_concentration_bps"
ATTACK_VALUE = 9999


def _person(email: str, *roles: tuple[str, str]) -> str:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            user = identity.find_by_email(owner, email)
            if user is None:
                user = identity.create_user(owner, email=email, display_name=email)
            held = {(g.role, g.jurisdiction) for g in identity.roles_for(owner, user.id)}
            for role, jurisdiction in roles:
                if (role, jurisdiction) in held:
                    continue
                identity.grant_role(
                    owner,
                    user_id=user.id,
                    role=role,
                    jurisdiction=jurisdiction,
                    granted_by="test",
                    qualification_ref="[illustrative — no engagement in place]",
                )
            owner.commit()
            return str(user.id)
    finally:
        owner.close()


@pytest.fixture(scope="module")
def cast() -> dict[str, str]:
    """The author holds `operator` as well as `pack_signatory`, and that is F1.

    `PATCH /watch/drafts/{id}` is an operator's act and `POST …/sign` is a
    signatory's, so the sequence needs one principal holding both — which is the
    S5 gate item's own description of the workbench, "the AU specialist
    authoring and signing a real pack".
    """
    return {
        "author": _person(AUTHOR_EMAIL, ("pack_signatory", "AU"), ("operator", "")),
        "reviewer": _person(REVIEWER_EMAIL, ("pack_signatory", "AU")),
    }


def _sign_in(client, email: str) -> None:
    """A signatory signed in, with a current second-factor code.

    Reviewing demands a second factor and a credential presented in the last few
    minutes, for the reason signing does: an unattended screen must not be able
    to supply the independence that lets an author's own signature through.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            user = identity.find_by_email(owner, email)
            assert user is not None
            identity.set_password(owner, user, SEED_PASSWORD)
            credential = owner.scalars(
                select(MfaCredential).where(MfaCredential.user_id == user.id)
            ).first()
            if credential is None:
                credential, _ = identity.enrol_totp(owner, user, label="test")
                owner.flush()
                identity.confirm_totp(
                    owner, credential, totp.code_at(str(credential.secret))
                )
            credential.last_used_counter = 0
            owner.commit()
            code = totp.code_at(str(credential.secret))
    finally:
        owner.close()

    res = client.post(
        "/auth/login", json={"email": email, "password": SEED_PASSWORD, "code": code}
    )
    assert res.status_code == 200, res.text


def _cut_a_draft(client, *, title: str) -> int:
    cut = client.post(
        "/watch/drafts",
        json={
            "jurisdiction": "AU",
            "effective_from": (date.today() + timedelta(days=FAR_FUTURE)).isoformat(),
            "title": title,
            "rationale": "Written by tests/test_a_review_is_of_the_bytes_the_reviewer_read.py",
        },
    )
    assert cut.status_code == 200, cut.text
    return int(cut.json()["id"])


def _a_draft(session, *, title: str) -> PackDraft:
    return drafts.create(
        session,
        jurisdiction="AU",
        on=date.today(),
        effective_from=date.today() + timedelta(days=FAR_FUTURE),
        title=title,
        rationale="Written by tests/test_a_review_is_of_the_bytes_the_reviewer_read.py",
        author="The Author",
    )


def _edit_the_body(draft: PackDraft) -> None:
    """Change the content, as the workbench's PATCH does.

    Assigned rather than mutated in place: `PackDraft.body` is a JSON column and
    SQLAlchemy does not see a mutation of the dictionary it handed out, so a
    test that mutated would flush nothing and pass while asserting the opposite
    of what it says.
    """
    body = dict(draft.body)
    body["thresholds"] = dict(body["thresholds"]) | {ATTACK_THRESHOLD: ATTACK_VALUE}
    draft.body = body


# --------------------------------------------------------- the attack itself --


def test_read_then_the_author_edits_then_the_reviewer_approves_is_refused(cast):
    """The auditor's sequence, over the routes a workbench actually has.

    Four ordinary acts in an order nobody had walked: a reviewer reads, an
    author edits, the reviewer approves, the author signs. Before F1 that ended
    in a 200 and a signature. It now ends at the third step, which is the step
    where the false statement would have been recorded.

    409 rather than 403: the reviewer's grant is right and the door was the
    right door. What is wrong is that the draft moved underneath them, which is
    a fact about the draft.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="Edited while it was being read")

        with TestClient(app) as reviewer:
            _sign_in(reviewer, REVIEWER_EMAIL)

            # 1. The reviewer reads it. This is the screen they are looking at,
            #    and `current_content_hash` is what it was of.
            read = reviewer.get(f"/watch/drafts/{draft_id}")
            assert read.status_code == 200, read.text
            what_they_read = read.json()["current_content_hash"]
            assert what_they_read, "view returned no hash for the body it rendered"
            assert (
                read.json()["body"]["thresholds"].get(ATTACK_THRESHOLD) != ATTACK_VALUE
            ), "the draft already carries the attack value, so this asserts nothing"

            # 2. The author edits it while they read. An ordinary PATCH, by the
            #    principal the S5 workflow describes.
            current = author.get(f"/watch/drafts/{draft_id}")
            assert current.status_code == 200, current.text
            edited = author.patch(
                f"/watch/drafts/{draft_id}",
                json={
                    "thresholds": dict(current.json()["body"]["thresholds"])
                    | {ATTACK_THRESHOLD: ATTACK_VALUE}
                },
            )
            assert edited.status_code == 200, edited.text

            # 3. The reviewer approves what they read — and is refused, because
            #    it is not what is there.
            refused = reviewer.post(
                f"/watch/drafts/{draft_id}/second-review",
                json={
                    "note": "Read it.",
                    "reviewed_content_hash": what_they_read,
                },
            )

        assert refused.status_code == 409, refused.text
        detail = refused.json()["detail"]
        assert "changed while it was being reviewed" in detail, detail

        # 4. And so the fourth step is refused as well, for the reason it was
        #    always meant to be: there is no independent read on this draft.
        signed = author.post(
            f"/watch/drafts/{draft_id}/sign",
            json={
                "note": "Mine.",
                "signed_content_hash": what_this_client_reads(author, draft_id),
            },
        )

    assert signed.status_code == 409, signed.text
    assert "somebody other than its author" in signed.json()["detail"]

    # Nothing was written. Not a review that is later found to be wrong — no
    # review, no reviewer, no hash, and no signature.
    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row is not None
        assert row.second_reviewer_user_id is None
        assert row.second_reviewer == ""
        assert row.second_reviewed_at is None
        assert row.second_reviewed_content_hash is None
        assert row.signed_by_user_id is None
        assert row.status == drafts.DRAFT
    finally:
        owner.close()


# ------------------------------------------------ and the ordinary path works --


def test_read_then_approve_with_nothing_in_between_still_succeeds(cast):
    """The other half of every refusal, and the half that decides whether this
    is a control or an obstacle.

    A reviewer who reads a draft and approves it must be able to, and the author
    must then be able to sign it — which is the whole reason the second-review
    route exists. A check that refused this would be one somebody removes.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="Read, then approved, unchanged")

        with TestClient(app) as reviewer:
            _sign_in(reviewer, REVIEWER_EMAIL)
            read = reviewer.get(f"/watch/drafts/{draft_id}")
            assert read.status_code == 200, read.text
            reviewed = reviewer.post(
                f"/watch/drafts/{draft_id}/second-review",
                json={
                    "note": "Read it.",
                    "reviewed_content_hash": read.json()["current_content_hash"],
                },
            )
        assert reviewed.status_code == 200, reviewed.text
        view = reviewed.json()
        assert view["second_reviewer_user_id"] == cast["reviewer"]
        assert view["second_review_covers_this_body"] is True

        signed = author.post(
            f"/watch/drafts/{draft_id}/sign",
            json={
                "note": "Mine.",
                "signed_content_hash": what_this_client_reads(author, draft_id),
            },
        )

    assert signed.status_code == 200, signed.text
    assert signed.json()["signed_by_its_author"] is True
    assert signed.json()["second_reviewer_user_id"] == cast["reviewer"]


def test_the_hash_a_reviewer_reads_is_of_the_body_the_same_response_carries(
    session, cast
):
    """`current_content_hash` describes *this* response, not the signature.

    Asserted directly because the field's whole value is that a client can trust
    it without knowing how it was produced — and because `PackDraft.content_hash`
    means something else entirely (the bytes that were signed), which is why this
    one carries the extra word.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(cast["author"]):
        draft = _a_draft(session, title="A view of its own body")
        session.flush()
        assert drafts.view(draft)["current_content_hash"] == content_hash(draft.body)

        _edit_the_body(draft)
        session.flush()
        assert drafts.view(draft)["current_content_hash"] == content_hash(
            draft.body
        ), "the hash did not follow the body it is supposed to be of"
        session.rollback()


# ---------------------------------------------------- a hash that is not this --


def test_a_hash_from_an_earlier_version_of_the_draft_is_refused(session, cast):
    """A stale hash is not a missing one, and must not be treated as either.

    The reviewer read version A, the body moved to version B, and they send A's
    hash. That is the attack's own shape without the assumption that the author
    was hostile — a second browser tab left open is enough — and it must refuse
    for the same reason.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="A hash from before the edit")
            session.flush()
            stale = content_hash(draft.body)
            _edit_the_body(draft)
            session.flush()
            assert content_hash(draft.body) != stale

        with tenancy.acting_as_user(cast["reviewer"]):
            with pytest.raises(drafts.ReviewedBytesMoved) as raised:
                drafts.record_second_review(
                    session,
                    draft.id,
                    reviewer_name="The Reviewer",
                    reviewed_content_hash=stale,
                )

        assert raised.value.submitted == stale
        assert draft.second_reviewer_user_id is None
        assert draft.second_reviewed_content_hash is None
        session.rollback()


@pytest.mark.parametrize(
    "submitted",
    [
        pytest.param("", id="empty"),
        pytest.param("   ", id="blank"),
        pytest.param("not-a-hash", id="nonsense"),
        pytest.param("0" * 64, id="right-shape-wrong-value"),
        # The two shapes a hasty comparison gets wrong: a prefix of the real
        # value, and the real value with something appended. Both are computed
        # from the body inside the test, so neither can go stale.
        pytest.param(None, id="a-prefix-of-the-real-hash"),
        pytest.param(..., id="the-real-hash-with-a-suffix"),
    ],
)
def test_a_malformed_or_empty_hash_is_refused_rather_than_treated_as_matching(
    session, cast, submitted
):
    """The failure mode a nullable field invites, asserted rather than argued.

    `if submitted and submitted != current` reads as defensive and is the bug:
    it makes an empty hash mean "nothing to compare, so assume it matches",
    which is the pre-F1 behaviour restored by a truthiness check. Every value
    here must refuse, including the two that are the correct value with one
    character wrong.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title=f"Refusing {submitted!r}")
            session.flush()

        real = content_hash(draft.body)
        if submitted is None:
            submitted = real[:-1]
        elif submitted is ...:
            submitted = real + "0"
        assert submitted != real

        with tenancy.acting_as_user(cast["reviewer"]):
            with pytest.raises(drafts.ReviewedBytesMoved):
                drafts.record_second_review(
                    session,
                    draft.id,
                    reviewer_name="The Reviewer",
                    reviewed_content_hash=submitted,
                )

        assert draft.second_reviewer_user_id is None
        assert draft.second_reviewed_content_hash is None
        session.rollback()


def test_the_route_refuses_a_request_that_omits_the_hash_entirely(cast):
    """422 at the schema, and it must stay a refusal rather than become a default.

    The field has no default for the same reason `SignRequest` has no
    `signatory`: a caller that could leave it out would be approving whatever
    the row says when its POST lands, which is exactly what F1 closes. This is
    the assertion that would fail if somebody made it optional to unbreak a
    client.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="An approval that says nothing")

        with TestClient(app) as reviewer:
            _sign_in(reviewer, REVIEWER_EMAIL)
            omitted = reviewer.post(
                f"/watch/drafts/{draft_id}/second-review", json={"note": "Read it."}
            )
            blank = reviewer.post(
                f"/watch/drafts/{draft_id}/second-review",
                json={"note": "Read it.", "reviewed_content_hash": ""},
            )

    assert omitted.status_code == 422, omitted.text
    assert blank.status_code == 422, blank.text

    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row is not None
        assert row.second_reviewer_user_id is None
    finally:
        owner.close()


def test_the_two_refusals_are_told_apart(session, cast):
    """`ReviewedBytesMoved` and `ReviewedBytesChanged` answer different people.

    Both mean "these are not the bytes somebody read", and collapsing them would
    hand a reviewer a message about an author's signature. Walked here in one
    test because the distinction only exists in the pair.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Two refusals, two readers")
            session.flush()
            stale = content_hash(draft.body)
            _edit_the_body(draft)
            session.flush()

        # The reviewer, approving what they read. Their screen is out of date.
        with tenancy.acting_as_user(cast["reviewer"]):
            with pytest.raises(drafts.ReviewedBytesMoved) as moved:
                drafts.record_second_review(
                    session,
                    draft.id,
                    reviewer_name="The Reviewer",
                    reviewed_content_hash=stale,
                )
            # Now they re-read and approve what is actually there, which works.
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
            )
            session.flush()

        # The author, editing again after that review and then signing.
        with tenancy.acting_as_user(cast["author"]):
            _edit_the_body(draft)
            body = dict(draft.body)
            body["thresholds"] = dict(body["thresholds"]) | {ATTACK_THRESHOLD: 1234}
            draft.body = body
            session.flush()
            with pytest.raises(drafts.ReviewedBytesChanged) as changed:
                drafts.sign(
                    session,
                    draft.id,
                    signatory="The Author",
                    signed_content_hash=the_bytes_on_the_row(session, draft),
                )

    assert "changed while it was being reviewed" in str(moved.value)
    assert "has changed since" in str(changed.value)
    assert str(moved.value) != str(changed.value)
    session.rollback()
