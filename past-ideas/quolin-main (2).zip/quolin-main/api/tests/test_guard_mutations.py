"""Rule B: every guard is watched failing at the thing it claims to catch.

A guard that exits 0 to mean "the invariant holds" is worth exactly what its
failure cases are worth, and until this file existed several of them had none.
`test_guards_cannot_be_vacuous.py` checked that each guard was *reachable* —
that running it produced output and an exit code — which is a different and much
weaker claim than that it refuses a violation.

The shape of every case here is the same:

  1. copy the tree to a temp directory with no `.git`;
  2. inject one specific violation the guard says it catches;
  3. assert the guard exits non-zero;

plus, for every guard, that a missing target directory and an override variable
pointing at nothing are both failures rather than quiet passes.

Injecting into a copy rather than the real tree matters more than it looks: two
of these violations are things that would otherwise be left behind in the
working copy if a test failed part-way, and one of them — `ALTER ROLE
quolin_app BYPASSRLS` — is cluster-scoped and cannot be contained by a copy at
all. That one lives in `test_migration_linter.py`, where the linter restores the
role afterwards and says so.

`lint_migrations.sh` is covered by `test_migration_linter.py`, which builds real
alembic migrations and applies them to a scratch database. The mutation cases
for the remaining guards are here.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
SCRIPTS = REPO / "scripts"


def tree(tmp_path: Path) -> Path:
    """A copy of the repository with no `.git`, for a case that **mutates** it.

    Only for those. A copy is about half a gigabyte and this file has seventy-odd
    cases; on a full-suite run that is thirty-five gigabytes of temporary trees,
    and pytest keeps the last three runs. A laptop that had run the suite a dozen
    times had a hundred and sixty-nine gigabytes of them and the copies started
    failing — which arrives as twenty `ERROR`s in a file about guards, describing
    nothing about guards.

    So a case that only *reads* the tree runs against the repository itself, via
    `run(..., cwd=REPO)`. Guards are read-only by construction — that is what
    they are — and `test_every_guard_still_passes_on_the_real_tree` was already
    saying so in its name while copying anyway.
    """
    dst = tmp_path / "repo"
    shutil.copytree(
        REPO,
        dst,
        # The same list `IGNORED_DIRS` in `scripts/guard_lib.sh` keeps the
        # guards away from, and for the same reason: none of it is source, and a
        # guard whose verdict depends on what happens to be installed is not a
        # guard.
        #
        # `.terraform` was missing and cost more than everything else here put
        # together. `tofu init` downloads about seven hundred megabytes of
        # provider plugins into it, so every copy this file made was seven
        # hundred megabytes — twenty of them per run, three runs kept by pytest.
        # A laptop that had run the suite a dozen times held a hundred and
        # sixty-nine gigabytes of them, the copies started failing, and it
        # arrived as twenty `ERROR`s in a file about guards that said nothing
        # about guards. Six megabytes a copy now.
        ignore=shutil.ignore_patterns(
            ".git",
            "__pycache__",
            ".venv",
            "node_modules",
            ".next",
            ".terraform",
            ".hypothesis",
            "artefacts_out",
            "evidence",
            "drop",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
        ),
        symlinks=True,
    )
    return dst


def run(guard: str, *, cwd: Path, env: dict[str, str] | None = None):
    """A guard, through its shell entry point, the way CI calls it."""
    full = {**os.environ}
    if env:
        full.update(env)
    return subprocess.run(
        ["bash", str(cwd / "scripts" / guard)],
        cwd=cwd,
        env=full,
        capture_output=True,
        text=True,
    )


# --------------------------------------------------------------------------
# guard_task_credentials.sh — FP3-04, audit G-02
# --------------------------------------------------------------------------

COMPUTE = "infra/compute.tf"


def _edit(root: Path, relative: str, old: str, new: str) -> None:
    path = root / relative
    text = path.read_text()
    assert old in text, f"{relative} no longer contains the anchor {old!r}"
    path.write_text(text.replace(old, new, 1))


def test_the_api_task_may_not_take_back_the_owner_connection(tmp_path):
    """The finding itself, injected. FP3-04.

    `DATABASE_URL` is the role that owns every append-only trigger, is exempt
    from FORCE row-level security, and is what rewrites evidence hashes. It was
    in the request-serving task for thirteen stages and no guard mentioned it,
    because every guard was a deny-list of things somebody had already thought
    of.
    """
    root = tree(tmp_path)
    _edit(
        root,
        COMPUTE,
        '''      {
        name      = "APP_DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:app_database_url::"
      },''',
        '''      {
        name      = "DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:database_url::"
      },
      {
        name      = "APP_DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:app_database_url::"
      },''',
    )
    result = run("guard_task_credentials.sh", cwd=root)
    assert result.returncode != 0, result.stdout
    assert "DATABASE_URL" in result.stdout


def test_renaming_the_watch_resource_does_not_make_the_guard_vacuous(tmp_path):
    """Audit G-02. The old check 5 grepped for the literal name `"watch"`.

    Renaming the resource made it find nothing, and finding nothing was a pass.
    This guard is keyed on the container's command, so the rename changes
    nothing about what is checked — asserted by renaming it and requiring the
    guard to still hold.
    """
    root = tree(tmp_path)
    _edit(
        root,
        COMPUTE,
        'resource "aws_ecs_task_definition" "watch" {',
        'resource "aws_ecs_task_definition" "watch_sweep" {',
    )
    clean = run("guard_task_credentials.sh", cwd=root)
    assert clean.returncode == 0, (
        "renaming the resource changed the verdict, which means the guard is "
        f"keyed on the name again.\n{clean.stdout}"
    )

    # And with the rename in place it still refuses a real violation, which is
    # the half a reachability test cannot distinguish.
    _edit(
        root,
        COMPUTE,
        '''      {
        name      = "WATCH_DATABASE_URL"''',
        '''      {
        name      = "DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:database_url::"
      },
      {
        name      = "WATCH_DATABASE_URL"''',
    )
    result = run("guard_task_credentials.sh", cwd=root)
    assert result.returncode != 0, result.stdout


@pytest.mark.parametrize("task", ["health", "comparison"])
def test_the_tasks_nothing_used_to_check_may_not_take_a_model_credential(tmp_path, task):
    """Audit G-02: the health and comparison tasks were checked by nothing.

    §S6's boundary is that a determination is never one environment variable
    away from a model. That was enforced for the watch task alone, so either of
    these could have been handed one silently.
    """
    root = tree(tmp_path)
    text = (root / COMPUTE).read_text()
    marker = f'resource "aws_ecs_task_definition" "{task}" {{'
    assert marker in text
    at = text.index(marker)
    anchor = '''      {
        name      = "QUOLIN_MASTER_KEY"'''
    insert = text.index(anchor, at)
    injected = (
        text[:insert]
        + '''      {
        name      = "ANTHROPIC_API_KEY"
        valueFrom = "${aws_secretsmanager_secret.app.arn}:anthropic_api_key::"
      },
'''
        + text[insert:]
    )
    (root / COMPUTE).write_text(injected)

    result = run("guard_task_credentials.sh", cwd=root)
    assert result.returncode != 0, result.stdout
    assert "ANTHROPIC_API_KEY" in result.stdout


def test_a_new_task_nobody_reviewed_is_a_failure_not_a_pass(tmp_path):
    """An allow-list, so an unlisted command fails rather than slipping through.

    This is the difference between this guard and the one it replaces. A
    deny-list can only refuse what somebody predicted; FP3-04 was a credential
    nobody had put on a list.
    """
    root = tree(tmp_path)
    with (root / COMPUTE).open("a") as handle:
        handle.write(
            '''
resource "aws_ecs_task_definition" "exfiltrate" {
  family = "${local.name}-exfiltrate"
  container_definitions = jsonencode([{
    name    = "exfiltrate"
    command = ["python", "-m", "scripts.not_reviewed"]
    environment = [
      { name = "AWS_REGION", value = var.region },
    ]
    secrets = [
      {
        name      = "DATABASE_URL"
        valueFrom = "${aws_secretsmanager_secret.database.arn}:database_url::"
      },
    ]
  }])
}
'''
        )
    result = run("guard_task_credentials.sh", cwd=root)
    assert result.returncode != 0, result.stdout
    assert "not in the allow-list" in result.stdout


def test_a_missing_infra_directory_is_a_failure(tmp_path):
    root = tree(tmp_path)
    shutil.rmtree(root / "infra")
    assert run("guard_task_credentials.sh", cwd=root).returncode != 0


def test_an_empty_infra_directory_is_a_failure(tmp_path):
    root = tree(tmp_path)
    shutil.rmtree(root / "infra")
    (root / "infra").mkdir()
    assert run("guard_task_credentials.sh", cwd=root).returncode != 0


def test_the_override_variable_pointing_at_nothing_is_a_failure(tmp_path):
    """`INFRA_DIR=/tmp/does-not-exist` must not be a quiet pass.

    Audit G-07 found `guard_no_hardcoded_region.sh` exiting 0 with "nothing to
    check" in exactly this case, while its own header said it should fail.
    """
    result = run(
        "guard_task_credentials.sh",
        cwd=REPO,
        env={"INFRA_DIR": str(tmp_path / "nowhere")},
    )
    assert result.returncode != 0, result.stdout
    assert "FAIL" in result.stdout


def test_the_guard_passes_on_the_real_tree():
    """The normal case has to be quiet or nobody keeps the guard."""
    result = run("guard_task_credentials.sh", cwd=REPO)
    assert result.returncode == 0, result.stdout + result.stderr


# --------------------------------------------------------------------------
# guard_engine_is_pure.sh — audit G-04
#
# Every case below passed the old lexical guard with exit 0, reproduced on this
# tree before it was rewritten. They are injected into `dsl.resolve`, which the
# corpus reaches on every evaluation — an import inside a function nothing calls
# cannot make a determination irreproducible, so injecting there would be
# testing a property nobody claims.
# --------------------------------------------------------------------------

HOT_PATH = "api/app/engine/dsl.py"
HOT_PATH_ANCHOR = """    if not isinstance(term, dict) or len(term) == 0:
        raise PackError(f"malformed term: {term!r}")"""


def _inject_into_the_evaluator(root: Path, statement: str) -> None:
    _edit(root, HOT_PATH, HOT_PATH_ANCHOR, HOT_PATH_ANCHOR + f"\n    {statement}")


@pytest.mark.parametrize(
    "statement,label",
    [
        ('_x = __import__("datetime").datetime.now()', "aliased datetime.now"),
        (
            '_x = __import__("importlib").import_module("os").environ.get("HOME")',
            "importlib.import_module('os')",
        ),
        ('_x = __import__("time").time()', "__import__('time').time()"),
        ('_x = __import__("uuid").uuid4()', "uuid.uuid4()"),
        ('_x = __import__("random").random()', "random.random()"),
    ],
)
def test_the_engine_may_not_reach_the_clock_or_the_environment(tmp_path, statement, label):
    root = tree(tmp_path)
    _inject_into_the_evaluator(root, statement)
    result = run("guard_engine_is_pure.sh", cwd=root)
    assert result.returncode != 0, (
        f"the engine purity guard allowed {label}\n{result.stdout}\n{result.stderr}"
    )


def test_the_engine_purity_guard_passes_on_the_real_tree():
    result = run("guard_engine_is_pure.sh", cwd=REPO)
    assert result.returncode == 0, result.stdout + result.stderr


def test_a_missing_engine_directory_is_a_failure(tmp_path):
    root = tree(tmp_path)
    shutil.rmtree(root / "api" / "app" / "engine")
    assert run("guard_engine_is_pure.sh", cwd=root).returncode != 0


# --------------------------------------------------------------------------
# guard_no_jurisdiction_logic.sh — audit G-05
#
# Three of these six passed the old regex guard and three were caught;
# reproduced individually rather than taking the audit's "all six" on trust.
# --------------------------------------------------------------------------


@pytest.mark.parametrize(
    "statement",
    [
        'if pack_id.startswith("hk"):\n        return 1',
        'if pack_id in ("au", "sg"):\n        return 2',
        'if jurisdiction.lower() == "eu":\n        return 3',
        'if jurisdiction in {"DE", "FR"}:\n        return 4',
        "x = 'AU'",
        "x = 'A' + 'U'",
    ],
)
def test_the_engine_may_not_name_a_jurisdiction(tmp_path, statement):
    root = tree(tmp_path)
    probe = (
        "\n\ndef _probe(pack_id='x', jurisdiction='x'):\n    " + statement + "\n"
    )
    with (root / "api" / "app" / "engine" / "evaluate.py").open("a") as handle:
        handle.write(probe)

    result = run("guard_no_jurisdiction_logic.sh", cwd=root)
    assert result.returncode != 0, (
        f"the jurisdiction guard allowed {statement!r}\n{result.stdout}"
    )


def test_a_regime_added_to_packs_extends_the_guard_by_existing(tmp_path):
    """The half that needs no list at all.

    A fifth pack used to mean somebody had to remember to add its code to the
    guard *and* to `test_packs.py`. The codes are derived from `packs/` now, so
    a regime nobody has told the guard about is still refused.
    """
    root = tree(tmp_path)
    (root / "packs" / "zz_v1.json").write_text(
        '{"jurisdiction": "ZZ", "version": 1, "rules": [], "thresholds": {}}'
    )
    with (root / "api" / "app" / "engine" / "evaluate.py").open("a") as handle:
        handle.write('\n\n_PROBE_REGIME = "zz"\n')

    result = run("guard_no_jurisdiction_logic.sh", cwd=root)
    assert result.returncode != 0, result.stdout


# --------------------------------------------------------------------------
# guard_no_hardcoded_region.sh — audit G-07
# --------------------------------------------------------------------------


def test_a_region_hardcoded_in_application_code_is_refused(tmp_path):
    """The one that mattered: it was the default for every new tenant row.

    A European customer created through the API was recorded as Sydney-resident
    by a keyword argument, and the guard scanned only `infra/`.
    """
    root = tree(tmp_path)
    with (root / "api" / "app" / "models.py").open("a") as handle:
        handle.write('\n\n_PROBE_REGION = "ap-southeast-2"\n')
    assert run("guard_no_hardcoded_region.sh", cwd=root).returncode != 0


def test_a_region_hardcoded_in_terraform_is_refused(tmp_path):
    root = tree(tmp_path)
    with (root / "infra" / "compute.tf").open("a") as handle:
        handle.write('\n\nlocals {\n  probe = "eu-west-1"\n}\n')
    assert run("guard_no_hardcoded_region.sh", cwd=root).returncode != 0


def test_the_region_guard_pointed_at_nothing_is_a_failure(tmp_path):
    """Audit G-07 exactly: this exited 0 with "nothing to check".

    The refusal comes from `require_paths` in `guard_lib.sh` now, which writes
    to stderr — a guard's diagnostics belong there, and this assertion reading
    only stdout was what made the check look narrower than it is.
    """
    result = run(
        "guard_no_hardcoded_region.sh",
        cwd=REPO,
        env={"INFRA_DIR": str(tmp_path / "nowhere")},
    )
    assert result.returncode != 0, result.stdout
    assert "FAIL" in (result.stdout + result.stderr)


# --------------------------------------------------------------------------
# guard_no_shared_passcode.sh — audit G-07
# --------------------------------------------------------------------------


@pytest.mark.parametrize(
    "relative",
    [
        # The two the old eleven-directory TARGETS list did not name.
        "web/public/probe.js",
        "web/e2e/probe.spec.ts",
        # And one it did, so the widening did not lose anything.
        "api/app/probe_passcode.py",
    ],
)
def test_a_shared_passcode_anywhere_in_the_tree_is_refused(tmp_path, relative):
    root = tree(tmp_path)
    target = root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text('const x = "QUOLIN_PASSCODE";\n')
    assert run("guard_no_shared_passcode.sh", cwd=root).returncode != 0


def test_the_passcode_guard_pointed_at_nothing_is_a_failure(tmp_path):
    result = run(
        "guard_no_shared_passcode.sh",
        cwd=REPO,
        env={"SCAN_ROOT": str(tmp_path / "nowhere")},
    )
    assert result.returncode != 0, result.stdout


# --------------------------------------------------------------------------
# guard_no_naive_today.sh — FP3-05
# --------------------------------------------------------------------------


@pytest.mark.parametrize(
    "statement,where",
    [
        ("_x = date.today()", "api/app/probe_date.py"),
        ("_x = datetime.now()", "api/app/probe_naive.py"),
        ("_x = datetime.now(timezone.utc).date()", "api/app/probe_derived.py"),
    ],
)
def test_a_business_date_from_the_container_clock_is_refused(tmp_path, statement, where):
    root = tree(tmp_path)
    (root / where).write_text(
        "from datetime import date, datetime, timezone\n\n\ndef probe():\n    "
        + statement
        + "\n"
    )
    assert run("guard_no_naive_today.sh", cwd=root).returncode != 0


def test_the_business_date_guard_pointed_at_nothing_is_a_failure(tmp_path):
    result = run(
        "guard_no_naive_today.sh",
        cwd=REPO,
        env={"SCAN_DIRS": str(tmp_path / "nowhere")},
    )
    assert result.returncode != 0, result.stdout


# --------------------------------------------------------------------------
# guard_no_tier_divergence.sh — audit G-06
# --------------------------------------------------------------------------


@pytest.mark.parametrize(
    "statement,where",
    [
        ('if tier != "shared":\n        return 1', "api/app/probe_tier.py"),
        ('if tier in ("dedicated",):\n        return 2', "api/app/probe_tier2.py"),
    ],
)
def test_a_tier_branch_in_application_code_is_refused(tmp_path, statement, where):
    root = tree(tmp_path)
    (root / where).write_text(f"def probe(tier='x'):\n    {statement}\n")
    assert run("guard_no_tier_divergence.sh", cwd=root).returncode != 0


def test_a_resource_gated_by_a_tier_local_is_refused(tmp_path):
    """Audit G-06's third case, and the one the greps could not reach.

    `count = local.is_dedicated ? 1 : 0` mentions neither `var.tenancy` nor a
    tier name. The fork is one name away, in the `locals` block, which is
    exactly where a grep for `var.tenancy` beside `count` stops looking.
    """
    root = tree(tmp_path)
    with (root / "infra" / "compute.tf").open("a") as handle:
        handle.write(
            "\n\nlocals {\n"
            '  probe_is_dedicated = contains(["dedicated"], var.tenancy)\n'
            "}\n\n"
            'resource "aws_s3_bucket" "probe" {\n'
            "  count  = local.probe_is_dedicated ? 1 : 0\n"
            '  bucket = "probe"\n'
            "}\n"
        )
    result = run("guard_no_tier_divergence.sh", cwd=root)
    assert result.returncode != 0, result.stdout
    assert "probe_is_dedicated" in result.stdout


def test_a_tier_local_that_gates_nothing_is_allowed(tmp_path):
    """The other half, so the guard is a rule rather than a ban on a word.

    A local that computes something about tenancy for a tag is not a fork. A
    guard that refused it would be one people route around, and the next thing
    they route around is a `count`.
    """
    root = tree(tmp_path)
    with (root / "infra" / "compute.tf").open("a") as handle:
        handle.write(
            "\n\nlocals {\n"
            '  probe_label = contains(["dedicated"], var.tenancy) ? "d" : "s"\n'
            "}\n"
        )
    result = run("guard_no_tier_divergence.sh", cwd=root)
    assert result.returncode == 0, result.stdout


def test_a_tier_branch_under_envs_is_refused(tmp_path):
    """The fourth case: the old infra half globbed `infra/*.tf` and stopped."""
    root = tree(tmp_path)
    target = root / "infra" / "envs" / "probe" / "main.tf"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        'resource "aws_s3_bucket" "probe" {\n'
        '  count  = var.tenancy == "dedicated" ? 1 : 0\n'
        '  bucket = "probe"\n'
        "}\n"
    )
    assert run("guard_no_tier_divergence.sh", cwd=root).returncode != 0


# --------------------------------------------------------------------------
# Every path parameter of every guard — the Gate A audit's third finding.
#
# `guard_no_hardcoded_region.sh` validated `INFRA_DIR` and never validated
# `SCAN_ROOT`, which was added by the same commit and used unchecked on the grep
# line. `SCAN_ROOT=/tmp/nowhere` therefore produced no matches, exited 0 and
# printed a success message: G-07's defect, surviving in the second parameter of
# the guard whose first one G-07 fixed.
#
# The cases above cover *one* parameter each, and that is exactly how the second
# one went uncovered. So this table is derived from the guards rather than
# written per guard: a guard with a path parameter nothing mutates is a guard
# with an untested way to pass vacuously, and the table below is the list of
# them.
#
# Two kinds of mutation for each, because they fail differently:
#
#   * pointed at a path that does not exist — `require_paths` refuses;
#   * pointed at a real directory holding nothing the guard can read —
#     `require_scan` refuses, and this is the subtler one. A directory of
#     Markdown greps exactly like a missing one for a guard looking at Python,
#     and only the file count can tell them apart.
# --------------------------------------------------------------------------

#: (guard, variable). Every path a guard takes from the environment.
#:
#: `lint_migrations.sh` and its `MIGRATIONS_DIR` are covered by
#: `test_migration_linter.py`, which needs a scratch database and lives there
#: for that reason.
PATH_PARAMETERS = [
    ("guard_no_owner_in_request_path.sh", "APP_DIR"),
    ("guard_no_hardcoded_region.sh", "INFRA_DIR"),
    ("guard_no_hardcoded_region.sh", "SCAN_ROOT"),
    ("guard_no_shared_passcode.sh", "SCAN_ROOT"),
    ("guard_no_naive_today.sh", "SCAN_DIRS"),
    ("guard_task_credentials.sh", "INFRA_DIR"),
    ("guard_engine_is_pure.sh", "ENGINE_DIR"),
    ("guard_no_jurisdiction_logic.sh", "ENGINE_DIR"),
    ("guard_no_watch_in_engine.sh", "ENGINE_DIR"),
    ("guard_no_watch_in_engine.sh", "WATCH_DIR"),
    ("guard_no_watch_in_engine.sh", "SCAN_ROOT"),
]


@pytest.mark.parametrize(
    "guard,variable", PATH_PARAMETERS, ids=[f"{g}:{v}" for g, v in PATH_PARAMETERS]
)
def test_every_path_parameter_pointed_at_nothing_is_a_failure(tmp_path, guard, variable):
    """A guard pointed somewhere that does not exist must fail, not pass.

    Against the repository rather than a copy: nothing here modifies the tree,
    and a copy per case is what filled a laptop's disk. See `tree`.
    """
    result = run(guard, cwd=REPO, env={variable: str(tmp_path / "nowhere")})
    assert result.returncode != 0, (
        f"{guard} passed with {variable} pointing at a path that does not "
        f"exist.\n{result.stdout}\n{result.stderr}"
    )
    assert "FAIL" in (result.stdout + result.stderr)


@pytest.mark.parametrize(
    "guard,variable", PATH_PARAMETERS, ids=[f"{g}:{v}" for g, v in PATH_PARAMETERS]
)
def test_every_path_parameter_pointed_at_an_unreadable_tree_is_a_failure(
    tmp_path, guard, variable
):
    """The subtler half: a directory that exists and holds nothing to read.

    A folder of Markdown produces the same silence as a missing one, and the
    silence is what every one of these guards used to treat as a clean tree.
    """
    empty = tmp_path / "no-source-here"
    empty.mkdir()
    (empty / "README.md").write_text("Not source, and not nothing.\n")

    result = run(guard, cwd=REPO, env={variable: str(empty)})
    assert result.returncode != 0, (
        f"{guard} passed with {variable} pointing at a directory holding no "
        f"file it can read.\n{result.stdout}\n{result.stderr}"
    )
    assert "FAIL" in (result.stdout + result.stderr)


@pytest.mark.parametrize(
    "guard",
    sorted({guard for guard, _ in PATH_PARAMETERS}),
)
def test_every_guard_still_passes_on_the_real_tree(guard):
    """The other half of every mutation case. A guard nobody can keep green is
    a guard somebody removes from CI.

    The real tree, which is what it says. It used to copy one, which meant it
    was asserting that the guards pass on a *copy* — true, and not the claim in
    the name, and the copy is what made this file expensive."""
    result = run(guard, cwd=REPO)
    assert result.returncode == 0, result.stdout + result.stderr


# --------------------------------------------------------------------------
# guard_no_owner_in_request_path.sh — the Gate A audit's seventh finding
#
# `app/owner_only.py` refuses to import without `DATABASE_URL`, so that code
# reaching for the schema owner in a process with no business holding one fails
# at the import. Its own docstring names the hole: "importing this from anything
# a request can reach is a mistake this cannot prevent." `main.py`'s
# `/admin/users` made it by a different route — `from .db import
# OwnerSessionLocal`, inside the handler — so `owner_only` was never involved.
# --------------------------------------------------------------------------


@pytest.mark.parametrize(
    "statement",
    [
        # The finding itself: the import written inside a function, which is
        # where it was and is what a grep for a module-level import misses.
        "    from .db import OwnerSessionLocal\n    _s = OwnerSessionLocal()",
        # And at module scope, which is the obvious spelling.
        "from app.db import OwnerSessionLocal",
        # The two ways to reach the same connection without naming it.
        "    from .db import owner_engine\n    _c = owner_engine.connect()",
        '    import os\n    _u = os.getenv("OWNER_DATABASE_URL")',
    ],
)
def test_a_request_handler_may_not_reach_the_schema_owner(tmp_path, statement):
    root = tree(tmp_path)
    with (root / "api" / "app" / "main.py").open("a") as handle:
        handle.write("\n\ndef _probe():\n" + statement + "\n")

    result = run("guard_no_owner_in_request_path.sh", cwd=root)
    assert result.returncode != 0, (
        "the guard passed with the schema owner reached from a request "
        f"handler:\n{statement}\n{result.stdout}"
    )


def test_the_two_files_that_may_name_the_owner_still_do():
    """The other half. A guard that refused `db.py` constructing the engine, or
    `owner_only.py` using it, would be one somebody deletes rather than one
    somebody satisfies — and the two legitimate callers would go somewhere
    worse."""
    for relative in ("api/app/db.py", "api/app/owner_only.py"):
        assert "OwnerSessionLocal" in (REPO / relative).read_text(), (
            f"{relative} no longer names the owner connection, so this test is "
            "asserting nothing"
        )
    assert run("guard_no_owner_in_request_path.sh", cwd=REPO).returncode == 0


# --------------------------------------------------------------------------
# B2 — the same guard, closing the class rather than three spellings.
#
# It keyed on `OwnerSessionLocal`, `owner_engine` and `OWNER_DATABASE_URL`.
# Both Gate A follow-up audits walked past it with `from app import owner_only;
# owner_only.active_tenant_ids()` — no connection named, the schema owner
# reached, exit 0. One of them ran it. In the deployment a runtime `ImportError`
# mitigates it, because the API task holds no `DATABASE_URL`; on a laptop and in
# this suite — the environment the original defect was reachable in — it works.
# --------------------------------------------------------------------------


@pytest.mark.parametrize(
    "statement",
    [
        # The audit's own bypass, verbatim, at module scope.
        "from app import owner_only",
        # And the shape it was reported in: imported inside the handler, which
        # is where the FP3-04 defect was written and what a module-level scan
        # misses.
        "    from app import owner_only\n    _t = owner_only.active_tenant_ids()",
        # The relative spelling, which is what a module inside the package
        # would actually write.
        "    from . import owner_only\n    _t = owner_only.active_tenant_ids()",
        # Straight at the callable, either way round.
        "    from .owner_only import active_tenant_ids\n    _t = active_tenant_ids()",
        "from app.owner_only import reset_rate_limit",
        # The dotted module itself.
        "    import app.owner_only\n    _t = app.owner_only.active_tenant_ids()",
        # And by name, which no import statement scan sees at all.
        '    import importlib\n    _m = importlib.import_module("app.owner_only")',
    ],
)
def test_a_request_handler_may_not_open_the_owner_only_door(tmp_path, statement):
    """Every spelling of the bypass, and the guard fails on each.

    Parametrised rather than written once, because the finding is not that one
    line got through — it is that the check was lexical about the wrong thing,
    and a lexical check is only as good as the list of ways to write what it
    forbids.
    """
    root = tree(tmp_path)
    with (root / "api" / "app" / "main.py").open("a") as handle:
        handle.write("\n\ndef _probe():\n" + statement + "\n")

    result = run("guard_no_owner_in_request_path.sh", cwd=root)
    assert result.returncode != 0, (
        "the guard passed with app.owner_only imported from a request-path "
        f"module:\n{statement}\n{result.stdout}"
    )


@pytest.mark.parametrize("door", ["api/app/db.py", "api/app/owner_only.py"])
def test_each_allowed_door_is_a_door_and_not_a_hole(door):
    """The allow-list, mutated one entry at a time.

    An allow-list is the part of a lexical guard that goes stale: an entry
    added for a reason that later stops holding is an opening nobody notices,
    because the guard's verdict does not change when the reason does. So each
    named file is asserted to *still be doing the thing it was exempted for* —
    if it is not, the exemption is hiding nothing and belongs deleted.

    **Two entries, and the list has only ever got shorter.** `source_alerts.py`
    was one: `all_tenant_ids` was a delegation to `owner_only` with no caller
    left in the tree, and B2 deleted it rather than allowlisting it. `auth.py`
    was another until F2, and its removal is the same move a size larger — see
    `test_the_removed_door_cannot_be_reopened_quietly` below. What is left is
    the two files that exist because a connection has to be constructed
    somewhere and locked up somewhere.
    """
    text = (REPO / door).read_text()
    if door.endswith("owner_only.py"):
        assert "OwnerSessionLocal" in text, (
            "owner_only.py no longer holds the owner connection, so it is not a "
            "door and the exemption should go"
        )
        return
    assert "OwnerSessionLocal" in text, (
        "db.py no longer constructs the owner sessionmaker, so its "
        "exemption is hiding nothing"
    )


def test_the_removed_door_cannot_be_reopened_quietly(tmp_path):
    """F2. `auth.py` was allowlisted; putting the import back must now fail.

    This is the mutation case the removal is worth: an allow-list entry that is
    deleted and a guard that would still pass on the code the entry existed for
    is a deletion of the documentation and not of the opening.

    `auth` is imported by everything that serves a request, and what sat behind
    this import disabled `auth_attempts_append_only` as the schema owner and
    deleted every row — invariant 4 and the login rate limit, reachable from any
    handler, for a caller that lives in the suite.
    """
    root = tree(tmp_path)
    path = root / "api" / "app" / "auth.py"
    with path.open("a") as handle:
        handle.write(
            "\n\ndef _reset_rate_limit_for_tests(session=None):\n"
            "    from .owner_only import reset_rate_limit\n\n"
            "    reset_rate_limit(session)\n"
        )
    result = run("guard_no_owner_in_request_path.sh", cwd=root)
    assert result.returncode != 0, (
        "auth.py opened app.owner_only again and the guard passed. The "
        f"exemption was removed by F2; this is what removing it means.\n{result.stdout}"
    )


def test_a_module_that_stops_opening_the_door_does_not_fail_the_guard(tmp_path):
    """The allow-list is permission, not obligation — and now it is unused.

    A guard that failed when a request-path module stopped reaching the owner
    would be one that punished the fix. Nothing under `api/app` opens this door
    any more, so the assertion is simply that the guard is green on that tree —
    which is what the AST twin's `MAY_OPEN_IT` being empty says from the other
    side. Written against a copy with the two exempt files' prose stripped of
    backticks, so that what is asserted is the *code* rule and not the prose
    filter doing the work.
    """
    root = tree(tmp_path)
    assert run("guard_no_owner_in_request_path.sh", cwd=root).returncode == 0


# --------------------------------------------------------------------------
# F2 — the key, and the neighbours who hold it.
#
# Rules 1 and 2 forbid the door and three names for what is behind it. Neither
# forbade a module building its own engine from the environment, and neither
# forbade importing `seed` or `scripts` — both of which sit beside `api/app` on
# `sys.path` here and in the built image, and both of which re-export
# `OwnerSessionLocal` at module scope because holding the owner is what a worker
# is for.
#
# Injected into the real tree's `main.py` rather than a scratch directory, which
# is the difference between this file's cases and the twin's: here the exemption
# patterns are matched against the real paths, so a rule that accidentally
# exempted `api/app/main.py` would pass the scratch cases and fail these.
# --------------------------------------------------------------------------


@pytest.mark.parametrize(
    "statement",
    [
        # The whole point of rule 3: no door, no owner name, same role.
        '    import os\n'
        '    from sqlalchemy import create_engine\n'
        '    _e = create_engine(os.environ["DATABASE_URL"])',
        # `create_engine` reached through the package, which an import scan
        # keyed on the name alone would miss.
        '    import sqlalchemy\n    _e = sqlalchemy.create_engine("postgresql://")',
        # The key on its own. A module that can read it can build anything.
        '    import os\n    _u = os.environ["DATABASE_URL"]',
        # And the application role\'s, because no request-path module has any
        # business naming a connection string for any role.
        '    import os\n    _u = os.environ["APP_DATABASE_URL"]',
        # SQLAlchemy left out of it entirely.
        '    import psycopg\n    _c = psycopg.connect("dbname=quolin")',
    ],
)
def test_a_request_handler_may_not_hold_the_key(tmp_path, statement):
    root = tree(tmp_path)
    with (root / "api" / "app" / "main.py").open("a") as handle:
        handle.write("\n\ndef _probe():\n" + statement + "\n")

    result = run("guard_no_owner_in_request_path.sh", cwd=root)
    assert result.returncode != 0, (
        "the guard passed with a request-path module holding the owner's "
        f"connection string:\n{statement}\n{result.stdout}"
    )


@pytest.mark.parametrize(
    "statement",
    [
        # `seed/seed.py` line 21 is `from app.db import OwnerSessionLocal,
        # owner_engine`, at module scope. Importing the package is importing it.
        "    import seed.seed\n    _s = seed.seed.OwnerSessionLocal()",
        "    from seed.seed import OwnerSessionLocal\n    _s = OwnerSessionLocal()",
        # Every worker under `scripts/` does the same thing.
        "    from scripts import health_alerts\n    _h = health_alerts",
        "    import scripts.rechain\n    _r = scripts.rechain",
        # And by name, which no import-statement scan sees at all — the
        # spelling B2 had to add for the door, applied to the neighbours before
        # somebody has to find it the hard way.
        '    import importlib\n    _m = importlib.import_module("seed.seed")',
        '    import importlib\n    _m = importlib.import_module("scripts.health_alerts")',
    ],
)
def test_a_request_handler_may_not_import_a_sibling_package(tmp_path, statement):
    root = tree(tmp_path)
    with (root / "api" / "app" / "main.py").open("a") as handle:
        handle.write("\n\ndef _probe():\n" + statement + "\n")

    result = run("guard_no_owner_in_request_path.sh", cwd=root)
    assert result.returncode != 0, (
        "the guard passed with a request-path module importing a package that "
        f"re-exports the schema owner:\n{statement}\n{result.stdout}"
    )


def test_removing_the_application_package_is_a_failure(tmp_path):
    """A guard that cannot find what it guards must fail."""
    root = tree(tmp_path)
    shutil.rmtree(root / "api" / "app")
    result = run("guard_no_owner_in_request_path.sh", cwd=root)
    assert result.returncode != 0
    assert "FAIL" in (result.stdout + result.stderr)


# --------------------------------------------------------------------------
# H5 — `require_scan` counted files and claimed it had validated readable ones.
#
# The same defect `scripts/guard_lib.sh` exists to end, one size smaller: an
# unreadable file greps exactly like an absent one, because `grep -r` writes its
# permission error to stderr — which every guard here discards — and contributes
# no matches. A tree nobody could open was counted and reported as examined.
# --------------------------------------------------------------------------


@pytest.mark.skipif(
    os.geteuid() == 0,
    reason=(
        "root reads a mode-000 file, so `require_scan`'s `[ -r ]` is true for "
        "every file here and this case would pass without testing anything. "
        "Skipped rather than left to pass vacuously in a root CI container — "
        "the readability check is unasserted on such a runner, and this line is "
        "where that is said."
    ),
)
def test_a_directory_of_unreadable_files_is_not_a_clean_scan(tmp_path):
    """The guard fails rather than reporting a scan of files it cannot open.

    Not `chmod` on the real tree — this builds a directory of its own and points
    the guard at it with `APP_DIR`, which is the parameter the guard already
    takes. Modes are restored in a `finally` so a failure here does not leave an
    unreadable directory behind for `tmp_path` cleanup to trip over.
    """
    scan = tmp_path / "app"
    scan.mkdir()
    files = [scan / "a.py", scan / "b.py"]
    for path in files:
        path.write_text("x = 1\n")
        path.chmod(0o000)

    try:
        result = run(
            "guard_no_owner_in_request_path.sh",
            cwd=REPO,
            env={**os.environ, "APP_DIR": str(scan)},
        )
        assert result.returncode != 0, (
            "the guard reported a clean scan of files it cannot read:\n"
            + result.stdout
            + result.stderr
        )
        assert "found nothing to examine" in (result.stdout + result.stderr)
    finally:
        for path in files:
            path.chmod(0o644)


def test_a_directory_of_readable_files_still_scans(tmp_path):
    """The other half. A readability check that failed on readable files would
    be a guard nobody could keep green, which is a guard somebody deletes."""
    scan = tmp_path / "app"
    scan.mkdir()
    (scan / "a.py").write_text("x = 1\n")

    result = run(
        "guard_no_owner_in_request_path.sh",
        cwd=REPO,
        env={**os.environ, "APP_DIR": str(scan)},
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "1 file(s)" in result.stdout
