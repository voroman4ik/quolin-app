"""A client we hold no positions for must not be assessed as holding nothing.

`service.evaluate` builds every snapshot from `FixturePositionsProvider`. A
client who arrived by CSV, by nightly file drop or through `POST /v1/clients`
has no entry in that fixture, so `get` returns zero holdings with
`source: "none_on_file"` — and the concentration calcs are computed from that
zero. A client with a large existing crypto holding and a proposed purchase that
would breach the limit came out ALLOW, and the determination is hash-chained and
replays that way forever.

The system already *noticed*. The snapshot records `positions.source` as
`none_on_file`, the client screen distinguishes it from a genuine zero, and
every import response carries `custody_warning` saying so in plain words.
Neither is a gate. A note on a screen does not stop a determination.

Two demo decisions were already on file in that state when this was written.

**The custody adapter is out of scope; this is the interim gate.** Absent
custody is the same class of fact as an absent snapshot field, and DSL v2
already has the right answer for one of those: refer to a human, naming the
field. So the concentration calcs are withheld from the snapshot when nothing is
on file, and the existing missing-data mechanism does the rest.

**Nothing already recorded moves.** Replay re-evaluates the *stored* snapshot,
so a determination made before this change reads back the calcs it was actually
decided on — including the two that were wrong. Correcting them would be
rewriting evidence to make a defect tidier, which is invariant 5 broken for
cosmetics. The right answer is that they stand, and that no new one joins them.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient

from app import service, tenancy
from app.db import SessionLocal
from app.engine.dsl import DATA_MISSING
from app.main import app
from app.models import Client
from app.providers import FixturePositionsProvider
from tests.conftest import DEMO_TENANT, OPERATOR_EMAIL, sign_in

ACTOR = "apc_bulk_sweep"

#: A crypto asset the AU pack classifies as complex, so a concentration rule
#: actually looks at it. Read from the seeded book rather than named, so this
#: keeps working if the demo assets are renamed.
CRYPTO_SYMBOL = "BTC"

#: Five per cent of the portfolio below. Small enough that every rule not about
#: concentration is satisfied, so what the determination turns on is the one
#: fact nobody has supplied.
TRADE_CENTS = 5_000_00

#: Someone whose determination turns entirely on what custody says.
#:
#: A modest purchase against a large portfolio, so nothing else in the pack has
#: anything to object to: assessed knowledge, a middling loss-capacity band, no
#: vulnerability flag, four prior purchases. With custody unknown, the only
#: number that could make this trade wrong is the one nobody has supplied — and
#: before the gate the system supplied a zero and allowed it.
#:
#: Every ingest path creates the same person, so the three tests differ only in
#: how the row arrived.
def _client_values(client_id: str) -> dict:
    return {
        "id": client_id,
        "name": "Imported Person",
        "jurisdiction": "AU",
        "residency": "AU",
        "domicile": "AU",
        "dob": date(1975, 4, 12),
        "client_category": "retail",
        "knowledge_assessed": True,
        "knowledge_date": date.today() - timedelta(days=90),
        "loss_capacity_band": 3,
        "vulnerability_flag": False,
        "assessable_portfolio_cents": 100_000_00,
        "prior_crypto_purchases": 4,
        "structural_acks": [],
        "default_trade_amount_cents": TRADE_CENTS,
        "note": "",
    }


def _csv_for(client_id: str) -> str:
    """One row, with the columns the importer actually requires.

    Built from `importer.ALL_COLUMNS` rather than typed out, so a column added
    to the format fails here as a missing key rather than as a confusing
    rejection three tests later.
    """
    from app import importer

    values = _client_values(client_id)
    cells = {
        "id": client_id,
        "scenario": "meridian",
        "name": values["name"],
        "dob": values["dob"].isoformat(),
        "client_category": "retail",
        "knowledge_assessed": "true",
        "knowledge_date": values["knowledge_date"].isoformat(),
        "loss_capacity_band": "3",
        "vulnerability_flag": "false",
        "assessable_portfolio_cents": str(values["assessable_portfolio_cents"]),
        "prior_crypto_purchases": "4",
        "structural_acks": "",
        "default_trade_amount_cents": str(values["default_trade_amount_cents"]),
        "jurisdiction": "AU",
        "residency": "AU",
        "domicile": "AU",
        "note": "",
    }
    missing = set(importer.ALL_COLUMNS) - set(cells)
    assert not missing, f"the import format grew columns this test does not set: {missing}"
    header = ",".join(importer.ALL_COLUMNS)
    row = ",".join(cells[column] for column in importer.ALL_COLUMNS)
    return f"{header}\n{row}\n"


def _crypto_asset_id(session) -> str:
    from sqlalchemy import select

    from app.models import Asset

    asset = session.scalars(select(Asset).where(Asset.symbol == CRYPTO_SYMBOL)).first()
    assert asset is not None, f"the seeded book has no {CRYPTO_SYMBOL}"
    return asset.id


def _evaluate(client_id: str) -> dict:
    """Run a real determination for this client and hand back the record."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            decision = service.evaluate(
                session,
                client_id=client_id,
                asset_id=_crypto_asset_id(session),
                amount_cents=TRADE_CENTS,
            )
            session.commit()
            return {
                "outcome": decision.outcome,
                "snapshot": dict(decision.snapshot),
                "rule_results": list(decision.rule_results["results"]),
            }
        finally:
            session.close()


def _assert_referred_for_absent_custody(record: dict, client_id: str) -> None:
    """The shape the interim gate must produce, whichever path brought the row in."""
    assert record["snapshot"]["positions"]["source"] == "none_on_file", (
        "this client has custody positions on file, so the test is not "
        "exercising what it claims to"
    )

    # The rule-level assertion first, because it is the one that is precisely
    # true. `worst_of` means a client who breaches something unrelated still
    # comes out BLOCK, and BLOCK is not a wrong answer — what must not happen is
    # a concentration rule reporting a verdict computed from a fabricated zero.
    referred = [
        r for r in record["rule_results"] if r.get("reason_code") == DATA_MISSING
    ]
    assert referred, (
        f"{client_id} produced no DATA_MISSING result with nothing on file from "
        "custody. Every concentration rule that ran was decided on a zero that "
        "means 'nobody has told us', not 'they hold nothing'."
    )
    # The field is named in the provenance, which is where the reason card
    # reads it from — see `evaluate._referred_for_missing_data`.
    named = {
        str(read["ref"])
        for result in referred
        for read in result["inputs_read"]
        if read["kind"] == "missing"
    }
    assert any(field.startswith("calc.") for field in named if field), (
        f"DATA_MISSING was reported without naming a concentration calc: {named}. "
        "The person picking this up needs to know which fact is absent."
    )
    for result in referred:
        assert result["outcome"] == "REFER", result

    assert record["outcome"] != "ALLOW", (
        f"{client_id} evaluated ALLOW with no custody positions on file. That "
        "determination is hash-chained and replays that way forever."
    )


@pytest.fixture(scope="module")
def api_client():
    with TestClient(app) as c:
        yield sign_in(c, OPERATOR_EMAIL)


def test_a_client_created_through_the_api_is_referred_not_allowed(api_client) -> None:
    """Path one: `POST /v1/clients`, the integration route."""
    client_id = "q06-api-client"
    values = _client_values(client_id)
    payload = {
        **values,
        "dob": values["dob"].isoformat(),
        "knowledge_date": values["knowledge_date"].isoformat(),
    }
    res = api_client.post("/v1/clients", json=payload)
    assert res.status_code == 200, res.text

    assert not FixturePositionsProvider().has_record(client_id)
    _assert_referred_for_absent_custody(_evaluate(client_id), client_id)


def test_a_client_imported_from_a_csv_is_referred_not_allowed(api_client) -> None:
    """Path two: the CSV upload a firm uses to load its book."""
    client_id = "q06-csv-client"
    csv = _csv_for(client_id)

    res = api_client.post("/import/clients", json={"csv_text": csv, "commit": True})
    assert res.status_code == 200, res.text
    body = res.json()
    assert body["committed"], body
    assert body["custody_warning"], "the warning that is not a gate should still be said"

    _assert_referred_for_absent_custody(_evaluate(client_id), client_id)


def test_a_client_arriving_by_file_drop_is_referred_not_allowed(tmp_path) -> None:
    """Path three: the nightly drop, which has no person watching it at all."""
    from app import batch

    client_id = "q06-drop-client"
    payload = _csv_for(client_id)

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        root = batch.ensure_drop(tmp_path, DEMO_TENANT)
        (root / batch.INCOMING / "book.csv").write_text(payload)
        session = SessionLocal()
        try:
            report = batch.sweep(
                session, tenant_id=DEMO_TENANT, base=tmp_path, started_by=ACTOR
            )
            session.commit()
        finally:
            session.close()
    assert report, report

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            assert session.get(Client, client_id) is not None, (
                f"the drop did not create {client_id}: {report}"
            )
        finally:
            session.close()

    _assert_referred_for_absent_custody(_evaluate(client_id), client_id)


def test_the_seeded_book_evaluates_exactly_as_it_did_before() -> None:
    """The 210 demo clients have fixture positions and must be untouched.

    The gate only fires on `none_on_file`. A change that also moved a client
    with custody on file would be a change to what the demo book decides, which
    is a much larger claim than the one being made here.
    """
    from sqlalchemy import select

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            custody = FixturePositionsProvider()
            covered = [
                row_id
                for row_id in session.scalars(select(Client.id).order_by(Client.id))
                if custody.has_record(row_id)
            ]
            assert len(covered) > 100, f"only {len(covered)} clients have positions"
            asset_id = _crypto_asset_id(session)

            for client_id in covered[:25]:
                decision = service.evaluate(
                    session, client_id=client_id, asset_id=asset_id
                )
                snapshot = dict(decision.snapshot)
                assert snapshot["positions"]["source"] == "fixture"
                assert "post_trade_crypto_bps" in snapshot["calc"], (
                    f"{client_id} has custody on file and lost its concentration "
                    "calc. The gate has fired on the wrong clients."
                )
                assert decision.outcome in ("ALLOW", "REFER", "BLOCK")
            session.commit()
        finally:
            session.close()


def test_a_decision_made_before_the_gate_still_replays_exactly_as_recorded() -> None:
    """Invariant 5: what is on file stays on file, defect and all.

    Determinations were made on an absent custody record before this gate
    existed — two were sitting in the demo tenant when Q-06 was written, with a
    concentration figure computed from a zero nobody had supplied. Replay reads
    the *stored* snapshot, so they reproduce exactly as recorded, which is the
    correct outcome. Rewriting them to what the system would say today would be
    editing evidence to make a past defect look tidier.

    Constructed here rather than searched for, and that is the point: a fresh
    `make seed` no longer produces any, because the gate is in the seed's path
    too. A test that hunted for pre-gate rows would quietly stop testing
    anything the first time somebody reseeded.
    """
    from app import evidence, packs_repo

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            # A snapshot in exactly the shape the defect produced: custody
            # absent, and the concentration calcs present anyway.
            recent = _evaluate("q06-api-client")
            pre_gate = dict(recent["snapshot"])
            assert pre_gate["positions"]["source"] == "none_on_file"
            pre_gate["positions"] = {
                k: v for k, v in pre_gate["positions"].items() if k != "withheld_calcs"
            }
            pre_gate["calc"] = dict(pre_gate["calc"])
            pre_gate["calc"].update(
                {
                    "existing_crypto_cents": 0,
                    "post_trade_crypto_cents": TRADE_CENTS,
                    "post_trade_crypto_bps": 500,
                }
            )

            governing = packs_repo.active(session, "AU", date.today())
            from app.engine import evaluate_snapshot

            evaluation = evaluate_snapshot(governing, pre_gate)
            decision = evidence.record(
                session,
                client_id="q06-api-client",
                asset_id=_crypto_asset_id(session),
                as_of=date.today(),
                pack_id=governing.pack_id,
                pack_version=governing.version,
                snapshot=pre_gate,
                evaluation=evaluation,
            )
            session.commit()

            # It records what it was actually decided on: a concentration
            # computed from an absent reading. That is the defect, preserved.
            assert "post_trade_crypto_bps" in decision.snapshot["calc"]

            result = evidence.replay(
                decision,
                packs_repo.by_version(session, governing.pack_id, governing.version),
                service._other_packs(session, decision),
            )
        finally:
            session.close()

    assert result["match"], (
        f"a determination made before the gate no longer reproduces: "
        f"{result['differences']}. Replay reads the stored snapshot; changing "
        "how snapshots are *built* must not change how old ones read back."
    )


def test_the_document_says_the_custody_figure_is_absent_rather_than_zero() -> None:
    """A withheld calc must not become `$0.00` in a document somebody files.

    Found by running the suite rather than by reading it: the AU Target Market
    Determination reads `snapshot.calc.existing_crypto_cents` directly, so the
    first determination made under this gate produced a document that would not
    render at all. Printing zero would have been worse than the crash — it is
    the same fabrication as the ALLOW this finding is about, in a form a
    regulator reads.
    """
    from app.artefacts import renderer

    _evaluate("q06-api-client")
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            from sqlalchemy import select

            from app.models import Decision

            decision = next(
                d
                for d in session.scalars(
                    select(Decision)
                    .where(Decision.client_id == "q06-api-client")
                    .order_by(Decision.id.desc())
                    .limit(20)
                )
                if (d.snapshot.get("positions") or {}).get("withheld_calcs")
            )
            from app import packs_repo

            governing = packs_repo.by_version(
                session, decision.pack_id, decision.pack_version
            )
            html = renderer.preview(
                session,
                body=governing.source_body,
                kind="tmd",
                decision_id=decision.id,
            )
            session.rollback()
        finally:
            session.close()

    assert renderer.NOT_ON_FILE in html, (
        "the document does not say the custody figure is absent"
    )
    assert "$0.00" not in html, (
        "the document prints a zero where custody has told us nothing. That is "
        "the finding, restated in a filed document."
    )
    assert "No custody positions on file" in html, (
        "the document states the figures without explaining why they are absent"
    )
