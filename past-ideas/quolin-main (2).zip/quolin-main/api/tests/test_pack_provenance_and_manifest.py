"""Replay must be able to prove it read the same rules with the same engine.

Two findings that are really one. Replay re-evaluates a stored snapshot against
"the pack of record", and until now it identified that pack by an integer.

**Nothing made the integer unique.** `packs` had no constraint on
`(jurisdiction, version)`, `drafts.create` allocated `highest + 1` at *draft*
time, and the §14 rolling track has several drafts open against one base at
once — so two drafts cut on the same afternoon both proposed the same number and
both could publish it. `by_version` then read with `.first()` and no `ORDER BY`,
which is a coin toss decided by the plan.

**And the integer is all the decision committed to.** The hash covers
`pack_version`, not pack content, so a replay that read the wrong pack row
reproduced a different answer and reported it as a rule-outcome difference —
indistinguishable from the engine having changed its mind. Worse, a replay that
read the right row under a *different evaluator* reported success: "replays
forever" was a drift detector, not an archival guarantee.

So a decision now carries an execution manifest: the pack content it was
actually decided on, the snapshot it was decided from, the language version, the
evaluator that ran, and the snapshot-construction inputs. Replay compares that
against the environment it is running in and reports drift *as drift*.

**Invariant 5 is why this is a payload schema, not an extra key.** Adding a
field to `_hashable` would change the recomputed hash of every determination
already on file — the chain would break on rows nobody had touched. Decisions
carry `payload_schema`; rows written before this are hashed and verified under
schema 1, which does not know the manifest exists, and new ones under schema 2.
The seeded chain must still verify unchanged, and there is a test for that.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from conftest import publish_with_dual_control, the_bytes_on_the_row
from sqlalchemy import func, select

from app import evidence, manifest, packs_repo, service, tenancy
from app.canonical import content_hash
from app.db import OwnerSessionLocal, SessionLocal
from app.models import Asset, Decision
from app.models import Pack as PackRow
from tests.conftest import DEMO_TENANT

ACTOR = "apc_bulk_sweep"

#: Far enough out that nothing published here is ever the pack in force.
FAR_FUTURE = 3650


# --------------------------------------------------------- version allocation --


def test_two_drafts_cut_from_the_same_base_publish_to_different_versions() -> None:
    """The ordinary case in the §14 rolling track, which used to collide.

    Both drafts are cut before either is published, which is the whole point:
    the number was allocated at draft time, so both carried `highest + 1` and
    the second publication either overwrote the first's identity or sat beside
    it with the same name.
    """
    from app.watch import drafts

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("user-a"):
        session = SessionLocal()
        try:
            today = date.today()
            first = drafts.create(
                session,
                jurisdiction="AU",
                on=today,
                effective_from=today + timedelta(days=FAR_FUTURE),
                title="Concurrent draft one",
                rationale="Written by a test.",
                author="The Provenance Suite",
            )
            second = drafts.create(
                session,
                jurisdiction="AU",
                on=today,
                effective_from=today + timedelta(days=FAR_FUTURE),
                title="Concurrent draft two",
                rationale="Written by a test.",
                author="The Provenance Suite",
            )
            session.flush()

            with tenancy.acting_as_user("user-signatory"):
                drafts.sign(
                    session,
                    first.id,
                    signatory="A. Signatory",
                    signed_content_hash=the_bytes_on_the_row(session, first),
                )
                drafts.sign(
                    session,
                    second.id,
                    signatory="A. Signatory",
                    signed_content_hash=the_bytes_on_the_row(session, second),
                )
            row_one = publish_with_dual_control(session, first.id)
            row_two = publish_with_dual_control(session, second.id)
            session.flush()

            assert row_one.version != row_two.version, (
                f"two drafts cut from the same base both published as "
                f"v{row_one.version}. Every determination made under one of them "
                "names a version that identifies two different pieces of rule "
                "content."
            )
        finally:
            session.rollback()
            session.close()


def test_the_database_refuses_a_second_pack_with_the_same_jurisdiction_and_version() -> None:
    """The lock under the allocation. Code can be edited; a constraint cannot."""
    from sqlalchemy.exc import IntegrityError

    owner = OwnerSessionLocal()
    try:
        existing = owner.scalars(
            select(PackRow).where(PackRow.jurisdiction == "AU").order_by(PackRow.version)
        ).first()
        assert existing is not None
        owner.add(
            PackRow(
                jurisdiction=existing.jurisdiction,
                version=existing.version,
                effective_from=date.today() + timedelta(days=FAR_FUTURE * 2),
                effective_to=None,
                body=dict(existing.body),
                signed_by="A. Duplicate",
                signed_at="",
            )
        )
        with pytest.raises(IntegrityError):
            owner.flush()
    finally:
        owner.rollback()
        owner.close()


def test_the_seed_holds_no_version_collisions() -> None:
    """Checked rather than assumed, because the constraint could not be added
    to a database that already had one."""
    owner = OwnerSessionLocal()
    try:
        collisions = owner.execute(
            select(PackRow.jurisdiction, PackRow.version, func.count())
            .group_by(PackRow.jurisdiction, PackRow.version)
            .having(func.count() > 1)
        ).all()
    finally:
        owner.close()
    assert not collisions, f"packs share a (jurisdiction, version): {collisions}"


def test_the_shelf_resolves_the_same_row_every_time() -> None:
    """`active` and `active_rows` had no tiebreak, and ties are ordinary.

    Several packs share an `effective_from` in any database this suite has run
    against, so "the newest on that date" was decided by whatever order the plan
    happened to return — a determination made twice in one second could have
    been made against two different packs.
    """
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            on = date.today() + timedelta(days=FAR_FUTURE + 30)
            seen = {packs_repo.active_rows(session, on)["AU"].id for _ in range(8)}
            assert len(seen) == 1, f"`active_rows` returned {seen} across eight calls"

            versions = {packs_repo.active(session, "AU", on).version for _ in range(8)}
            assert len(versions) == 1, f"`active` returned {versions} across eight calls"

            # And it is the greatest (effective_from, id), not merely a stable
            # arbitrary one. A tiebreak that consistently picked the *oldest*
            # would be repeatable and wrong.
            candidates = list(
                session.scalars(
                    select(PackRow)
                    .where(PackRow.jurisdiction == "AU")
                    .where(PackRow.effective_from <= on)
                )
            )
            expected = max(candidates, key=lambda r: (r.effective_from, r.id))
            assert packs_repo.active_rows(session, on)["AU"].id == expected.id
        finally:
            session.close()


# ------------------------------------------------------------- the manifest --


#: This file's own client, rather than one of the demo cast.
#:
#: The first version picked "whichever client the first decision names", which
#: is `harold-bell` — the client the three-tap walkthrough replays. Every run
#: added five determinations to him, `GET /decisions` returns the fifty most
#: recent, and after a few runs the 2025 determination the demo is *about* fell
#: off the end of the list. A test that quietly degrades the demo is a worse
#: outcome than the defect it was written for.
PROBE_CLIENT = "q04-manifest-probe"


def _probe_client(session) -> str:
    """A client of our own, created once and left in place."""
    from app.models import Client

    if session.get(Client, PROBE_CLIENT) is None:
        session.add(
            Client(
                id=PROBE_CLIENT,
                name="Manifest Probe",
                scenario="meridian",
                jurisdiction="AU",
                residency="AU",
                domicile="AU",
                dob=date(1979, 3, 2),
                client_category="retail",
                knowledge_assessed=True,
                knowledge_date=date.today() - timedelta(days=120),
                loss_capacity_band=3,
                vulnerability_flag=False,
                assessable_portfolio_cents=250_000_00,
                prior_crypto_purchases=3,
                structural_acks=[],
                default_trade_amount_cents=1_000_00,
            )
        )
        session.flush()
    return PROBE_CLIENT


@pytest.fixture(scope="module")
def fresh_decision() -> Decision:
    """One determination for the whole module, carrying a manifest.

    Module-scoped rather than per test: `decisions` is append-only, so every
    call leaves a row nothing can remove, and one determination is all these
    assertions need.
    """
    return _fresh_decision()


def _fresh_decision() -> Decision:
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            asset = session.scalars(select(Asset).where(Asset.symbol == "BTC")).first()
            decision = service.evaluate(
                session, client_id=_probe_client(session), asset_id=asset.id
            )
            session.commit()
            session.expunge(decision)
            return decision
        finally:
            session.close()


def test_every_new_decision_carries_an_execution_manifest(fresh_decision) -> None:
    decision = fresh_decision
    assert decision.payload_schema == manifest.CURRENT_PAYLOAD_SCHEMA
    recorded = decision.manifest
    assert recorded, "a determination was recorded with no manifest"

    for key in (
        "dsl_version",
        "pack_content_hash",
        "snapshot_hash",
        "evaluator",
        "snapshot_inputs",
    ):
        assert key in recorded, f"the manifest does not record {key!r}: {sorted(recorded)}"

    assert isinstance(recorded["dsl_version"], int)
    assert len(recorded["pack_content_hash"]) == 64
    assert len(recorded["snapshot_hash"]) == 64
    assert recorded["evaluator"], "the evaluator that ran is unnamed"


def test_the_manifest_commits_to_the_pack_the_decision_was_actually_decided_on(
    fresh_decision,
) -> None:
    decision = fresh_decision
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            row = session.scalars(
                select(PackRow)
                .where(PackRow.jurisdiction == service._governing_pack_id(decision))
                .where(PackRow.version == decision.pack_version)
            ).one()
        finally:
            session.close()

    assert decision.manifest["pack_content_hash"] == content_hash(row.body), (
        "the manifest names a pack content hash that is not the hash of the pack "
        "row the decision points at"
    )


def test_a_published_pack_records_its_own_content_hash() -> None:
    """So "what is this pack's hash" is answerable without evaluating anything."""
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            rows = list(
                session.scalars(
                    select(PackRow).where(PackRow.content_hash != "").limit(20)
                )
            )
        finally:
            session.close()
    assert rows, "no pack records a content hash"
    for row in rows:
        assert row.content_hash == content_hash(row.body), (
            f"{row.jurisdiction} v{row.version} records a hash that is not its "
            "body's"
        )


def test_replay_reports_a_provenance_mismatch_rather_than_an_outcome_difference(
    fresh_decision,
) -> None:
    """The whole point: replay against altered content must say *what* changed.

    Reading the wrong pack and the engine changing its mind used to look
    identical — both arrived as a list of rule-level differences. One is a
    provenance failure and needs the pack chased down; the other is a
    regression in the evaluator. An operator has to be able to tell them apart.
    """
    decision = fresh_decision
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            pack = packs_repo.by_version(
                session, service._governing_pack_id(decision), decision.pack_version
            )
            honest = evidence.replay(decision, pack, service._other_packs(session, decision))
            assert honest["match"], honest["differences"]
            assert honest["provenance"]["content_matches"] is True

            # The same pack version, with content that is not what was decided
            # on. Exactly the shape of "replay read the wrong row".
            tampered = packs_repo.Pack.from_body(
                {**pack_body(session, decision), "notes": "not the content of record"}
            )
            result = evidence.replay(
                decision, tampered, service._other_packs(session, decision)
            )
        finally:
            session.close()

    assert result["match"] is False, "replay accepted content it was not decided on"
    assert result["provenance"]["content_matches"] is False
    assert "pack_content_hash" in result["provenance"]["drift"], result["provenance"]
    assert result["provenance"]["drift"]["pack_content_hash"]["recorded"] == (
        decision.manifest["pack_content_hash"]
    )


def pack_body(session, decision) -> dict:
    row = session.scalars(
        select(PackRow)
        .where(PackRow.jurisdiction == service._governing_pack_id(decision))
        .where(PackRow.version == decision.pack_version)
    ).one()
    return dict(row.body)


def test_a_changed_evaluator_is_reported_as_drift_and_not_as_a_wrong_answer(
    fresh_decision, monkeypatch
) -> None:
    """"It still replays" means nothing if nobody checked what ran.

    The rules can reproduce perfectly under an evaluator three years newer than
    the one that made the determination, and that is a fact worth stating rather
    than swallowing. Reported separately from the outcome, because it is not by
    itself a failure — it is the thing an auditor asks about next.
    """
    decision = fresh_decision
    monkeypatch.setattr(manifest, "evaluator_release", lambda: "some-other-build")

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            pack = packs_repo.by_version(
                session, service._governing_pack_id(decision), decision.pack_version
            )
            result = evidence.replay(
                decision, pack, service._other_packs(session, decision)
            )
        finally:
            session.close()

    assert "evaluator" in result["provenance"]["drift"], result["provenance"]
    assert result["provenance"]["matches"] is False, "the drift was not reported"

    # Reported, and *not* a failure. Every deploy changes the evaluator's build
    # identifier. A verdict that flipped on it would report a firm's whole
    # history as broken the first time anything shipped — which is exactly what
    # happened when this was first written: 1818 determinations "failed to
    # reproduce" with an empty list of differences.
    assert result["provenance"]["content_matches"] is True
    assert result["match"] is True, result["differences"]
    assert not result["differences"], result["differences"]
    assert result["replayed_outcome"] == result["stored_outcome"]


# ------------------------------------------------------------- invariant 5 --


def test_a_decision_hashed_under_schema_one_still_verifies_in_the_same_chain(
    fresh_decision,
) -> None:
    """The invariant-5 check, built rather than borrowed.

    A row written before Q-04 is hashed by a payload with no manifest in it, and
    must go on verifying forever — in the *same* chain as the rows written
    after it, because a database that has been running since before this change
    has both.

    Written here rather than looked up among the seeded decisions, and that is
    the point: a fresh `make seed` produces only schema-2 rows, so a test that
    searched for old ones would quietly stop testing anything the first time
    somebody reseeded. This constructs one, links it at the tip the way
    `evidence.record` does, and then asks the ordinary verifier to walk the
    whole chain.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            # This file's own client, so the row lands on the probe rather than
            # on a member of the demo cast — see the note on PROBE_CLIENT.
            recent = session.scalars(
                select(Decision)
                .where(Decision.client_id == PROBE_CLIENT)
                .order_by(Decision.id.desc())
                .limit(1)
            ).first()
            assert recent is not None, "no probe decision to copy the shape of"

            created_at = evidence.datetime.now(evidence.timezone.utc)
            prev_hash = evidence._tip_hash(session)
            legacy = dict(
                tenant_id=DEMO_TENANT,
                client_id=recent.client_id,
                asset_id=recent.asset_id,
                as_of=recent.as_of,
                pack_id=recent.pack_id,
                pack_version=recent.pack_version,
                snapshot=recent.snapshot,
                rule_results=recent.rule_results,
                resolution=recent.resolution,
                outcome=recent.outcome,
                created_at=created_at,
            )
            payload = evidence._hashable(**legacy, schema=1, execution_manifest=None)
            assert "manifest" not in payload

            session.add(
                Decision(
                    **legacy,
                    prev_hash=prev_hash,
                    this_hash=evidence.chain_hash(prev_hash, payload),
                    payload_schema=1,
                    manifest=None,
                )
            )
            session.commit()

            chain = evidence.verify_chain(session)
        finally:
            session.close()

    assert fresh_decision is not None
    assert chain["verified"] is True, (
        f"a chain holding both payload schemas does not verify: {chain}. Rows "
        "written before the manifest existed must be recomputed under the shape "
        "they were written with."
    )
    assert chain["checked"] > 1


def test_replay_of_a_manifestless_decision_reports_no_provenance_either_way() -> None:
    """Three-valued on purpose: absent is not the same as mismatched.

    Every determination recorded before Q-04 has no manifest. Reporting those as
    provenance failures would have turned the whole of a firm's history into
    findings on the day this shipped, which is how a real signal gets switched
    off.
    """
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            decision = session.scalars(
                select(Decision)
                .where(Decision.payload_schema == 1)
                .order_by(Decision.id.desc())
                .limit(1)
            ).first()
            assert decision is not None, "no schema-1 decision on file"
            pack = packs_repo.by_version(
                session, service._governing_pack_id(decision), decision.pack_version
            )
            result = evidence.replay(
                decision, pack, service._other_packs(session, decision)
            )
        finally:
            session.close()

    assert result["provenance"]["matches"] is None
    assert result["provenance"]["content_matches"] is None
    assert result["provenance"]["drift"] == {}
    assert result["match"] is True, result["differences"]


def test_the_two_payload_schemas_produce_different_bytes_for_the_same_decision() -> None:
    """The schemas have to actually differ, or the versioning is theatre."""
    common = dict(
        tenant_id=DEMO_TENANT,
        client_id="c",
        asset_id="a",
        as_of=date.today(),
        pack_id="AU",
        pack_version=2,
        snapshot={},
        rule_results={},
        resolution=None,
        outcome="ALLOW",
        created_at=evidence.datetime.now(evidence.timezone.utc),
    )
    v1 = evidence._hashable(**common, schema=1, execution_manifest=None)
    v2 = evidence._hashable(
        **common, schema=2, execution_manifest={"evaluator": "x"}
    )
    assert "manifest" not in v1, "schema 1 must not know the manifest exists"
    assert v1 != v2
