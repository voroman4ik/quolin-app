"""Sign-in, second factors, and the session that remembers who did it.

The primitives are proven next door — `test_totp.py` against the RFC's own
numbers, `test_passwords.py` against Argon2's parameters. What is left, and what
is here, is the part nobody publishes vectors for: the order the checks happen
in, what each failure is allowed to tell the person who provoked it, and whether
a one-time code stays one-time across the two different operations that spend
one.

Everything runs through the application's database role, not the owner's, so the
row-level-security bootstrap that sign-in depends on is exercised rather than
bypassed. A test that reached for `OwnerSessionLocal` here would pass on a
database where the policies were all dropped.
"""

from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import select, text

from app import auth, identity, passwords, tenancy, totp
from app.db import OwnerSessionLocal, SessionLocal
from app.models import AuthSession, MfaCredential, User, UserIdentity, UserRole
from tests.conftest import DEMO_TENANT

#: Deterministic rather than random, so a run killed part-way leaves rows the
#: next run cleans up instead of a growing pile of orphans nothing knows about.
EMAIL = "identity-probe@example.invalid"
PASSWORD = "a passphrase of ordinary words"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _purge() -> None:
    """Remove the probe user and everything hanging off it, in FK order."""
    with tenancy.acting_as(DEMO_TENANT):
        owner = OwnerSessionLocal()
        try:
            ids = [
                row
                for row in owner.scalars(select(User.id).where(User.email == EMAIL))
            ]
            if not ids:
                return
            # `tenant_members` is append-only and holds a foreign key to
            # `users`, so the probe row cannot be removed without lifting the
            # trigger — which is correct rather than inconvenient. Migration
            # 0047 exists because a membership that could be quietly removed is
            # a membership somebody could remove to make an actor stop
            # resolving, and nothing in production deletes a person at all.
            # This is a throwaway probe account that never existed outside this
            # file, so the trigger comes off for the length of the teardown and
            # goes straight back on.
            owner.execute(
                text("ALTER TABLE tenant_members DISABLE TRIGGER tenant_members_append_only")
            )
            try:
                for user_id in ids:
                    for table in (
                        "user_roles",
                        "tenant_members",
                        "mfa_credentials",
                        "user_identities",
                        "auth_sessions",
                    ):
                        owner.execute(
                            text(f"delete from {table} where user_id = :u"),
                            {"u": user_id},
                        )
                    owner.execute(
                        text("delete from users where id = :u"), {"u": user_id}
                    )
            finally:
                owner.execute(
                    text(
                        "ALTER TABLE tenant_members ENABLE TRIGGER "
                        "tenant_members_append_only"
                    )
                )
            owner.commit()
        finally:
            owner.close()


@pytest.fixture
def person():
    """A user with a password and nothing else, torn down afterwards.

    Committed rather than held open in a transaction: several of these tests
    open a second session to check what another connection can see, and an
    uncommitted row is invisible to it.
    """
    _purge()
    with tenancy.acting_as(DEMO_TENANT):
        db = SessionLocal()
        try:
            user = identity.create_user(
                db, email=EMAIL, display_name="Priya Nandakumar"
            )
            identity.set_password(db, user, PASSWORD)
            db.commit()
            yield user
        finally:
            db.close()
    _purge()


@pytest.fixture
def db():
    """A plain application session acting for the demo firm."""
    with tenancy.acting_as(DEMO_TENANT):
        s = SessionLocal()
        try:
            yield s
        finally:
            s.rollback()
            s.close()


# ------------------------------------------------------------------ sign-in --


def test_a_person_with_a_password_signs_in(person, db) -> None:
    result = identity.authenticate(db, email=EMAIL, password=PASSWORD)
    assert result, result.outcome
    assert result.user is not None and result.user.id == person.id
    assert result.mfa_satisfied is False, "no second factor was presented"


def test_the_address_is_one_identity_however_it_is_typed(person, db) -> None:
    """Otherwise a unique index holds two people who are one person."""
    assert identity.authenticate(db, email="  IDENTITY-Probe@Example.INVALID ", password=PASSWORD)


def test_a_wrong_password_and_an_unknown_address_are_the_same_answer(person, db) -> None:
    """Both refused, and neither one faster than the other.

    An endpoint that returns in microseconds for an address it has never seen
    and a tenth of a second for one it has is a list of who works at the firm,
    readable by anyone with a script and a dictionary of names.
    """
    assert not identity.authenticate(db, email=EMAIL, password="the wrong passphrase")
    assert not identity.authenticate(db, email="nobody@example.invalid", password=PASSWORD)

    def elapsed(email: str) -> float:
        runs = []
        for _ in range(3):
            started = time.perf_counter()
            identity.authenticate(db, email=email, password="the wrong passphrase")
            runs.append(time.perf_counter() - started)
        return sorted(runs)[1]

    known = elapsed(EMAIL)
    unknown = elapsed("nobody@example.invalid")
    assert 0.4 < unknown / known < 2.5, (
        f"an unknown address took {unknown:.3f}s against {known:.3f}s for a known "
        "one, which turns the login route into a staff directory"
    )


def test_a_suspended_account_is_refused_only_after_the_password_is_checked(person, db) -> None:
    """Order matters, and this is the assertion that pins it.

    Checking status first would be the obvious way to write it and would report
    which former employees still have rows, to anyone who guesses an address.
    So the wrong password on a suspended account has to be indistinguishable
    from the wrong password on a live one.
    """
    person.status = "suspended"
    identity._scope_to_user(db, person.id)
    db.merge(person)
    db.commit()

    wrong = identity.authenticate(db, email=EMAIL, password="wrong")
    assert wrong.outcome is identity.Outcome.WRONG_PASSWORD
    right = identity.authenticate(db, email=EMAIL, password=PASSWORD)
    assert right.outcome is identity.Outcome.NOT_ACTIVE


def test_a_person_who_only_uses_their_idp_has_no_password_to_guess(person, db) -> None:
    """An empty secret is a real state, not a corrupted row — and not a way in."""
    identity._scope_to_user(db, person.id)
    row = db.scalars(
        select(UserIdentity).where(UserIdentity.user_id == person.id)
    ).one()
    row.secret = ""
    db.commit()

    result = identity.authenticate(db, email=EMAIL, password=PASSWORD)
    assert result.outcome is identity.Outcome.WRONG_PASSWORD
    assert result.outcome is not identity.Outcome.NO_SUCH_USER, "revealed that the account exists"


def test_a_stale_hash_is_upgraded_during_the_one_moment_it_can_be(person, db) -> None:
    """Raising the parameters has to reach hashes that already exist.

    Rehashing needs the plaintext, and the only moment the plaintext is both
    present and known correct is a successful sign-in. So this is not an
    optimisation — it is the entire upgrade path.
    """
    from argon2 import PasswordHasher

    weak = PasswordHasher(time_cost=1, memory_cost=8 * 1024, parallelism=1)
    identity._scope_to_user(db, person.id)
    row = db.scalars(select(UserIdentity).where(UserIdentity.user_id == person.id)).one()
    row.secret = weak.hash(PASSWORD)
    db.commit()
    before = row.secret

    assert identity.authenticate(db, email=EMAIL, password=PASSWORD)
    db.commit()

    identity._scope_to_user(db, person.id)
    db.expire_all()
    after = db.scalars(select(UserIdentity).where(UserIdentity.user_id == person.id)).one().secret
    assert after != before, "the sign-in did not upgrade a hash it knew was stale"
    assert passwords.verify(after, PASSWORD) == (True, False)


# ------------------------------------------------------------ second factor --


def test_an_unconfirmed_enrolment_neither_counts_nor_locks_anyone_out(person, db) -> None:
    """The half-finished state, which is the one that strands people.

    Between showing a QR code and the user proving they scanned it, the
    credential must do nothing at all: counting it would lock out someone whose
    phone never saved it, and deleting the row on any error would lose an
    enrolment that actually worked.
    """
    identity.enrol_totp(db, person, label="phone")
    db.commit()

    assert identity.second_factors(db, person.id) == []
    assert identity.authenticate(db, email=EMAIL, password=PASSWORD).mfa_satisfied is False


def test_a_confirmed_factor_becomes_required_and_then_sufficient(person, db) -> None:
    credential, uri = identity.enrol_totp(db, person, label="phone")
    assert f"secret={credential.secret}" in uri
    # Confirmed with the *previous* window's code, so the current one is still
    # unspent and this test is about requirement rather than about replay.
    assert identity.confirm_totp(
        db, credential, totp.code_at(credential.secret, time.time() - totp.PERIOD)
    )
    db.commit()

    without = identity.authenticate(db, email=EMAIL, password=PASSWORD)
    assert without.outcome is identity.Outcome.MFA_REQUIRED
    assert (
        identity.authenticate(db, email=EMAIL, password=PASSWORD, code="000000").outcome
        is identity.Outcome.MFA_WRONG
    )

    # A wrong code is still a wrong code even with the wrong password, and says
    # nothing more than the password failure would have.
    assert identity.authenticate(db, email=EMAIL, password="wrong", code="000000").outcome is (
        identity.Outcome.WRONG_PASSWORD
    )

    result = identity.authenticate(
        db, email=EMAIL, password=PASSWORD, code=totp.code_at(credential.secret)
    )
    assert result, result.outcome
    assert result.mfa_satisfied is True


def test_the_code_that_confirmed_the_enrolment_cannot_then_sign_in(person, db) -> None:
    """Replay across two different operations, which is where a per-endpoint
    guard would miss it.

    The counter lives on the credential rather than in either operation, so the
    code spent proving the phone works is spent for every purpose, not just for
    enrolment.
    """
    credential, _ = identity.enrol_totp(db, person)
    code = totp.code_at(credential.secret)
    assert identity.confirm_totp(db, credential, code)
    db.commit()

    result = identity.authenticate(db, email=EMAIL, password=PASSWORD, code=code)
    assert result.outcome is identity.Outcome.MFA_WRONG, "the enrolment code signed someone in"


def test_a_code_is_spent_the_first_time_it_is_accepted(person, db) -> None:
    credential, _ = identity.enrol_totp(db, person)
    earlier = totp.code_at(credential.secret, time.time() - totp.PERIOD)
    identity.confirm_totp(db, credential, earlier)
    db.commit()

    code = totp.code_at(credential.secret)
    assert identity.authenticate(db, email=EMAIL, password=PASSWORD, code=code)
    db.commit()
    assert (
        identity.authenticate(db, email=EMAIL, password=PASSWORD, code=code).outcome
        is identity.Outcome.MFA_WRONG
    ), "the same code was accepted twice"


def test_a_second_factor_is_unreadable_without_the_platform_key(person, db) -> None:
    credential, _ = identity.enrol_totp(db, person)
    db.commit()

    with tenancy.acting_as(DEMO_TENANT):
        owner = OwnerSessionLocal()
        try:
            raw = owner.execute(
                text("select secret from mfa_credentials where id = :i"),
                {"i": credential.id},
            ).scalar_one()
        finally:
            owner.close()
    assert credential.secret.encode() not in raw, "a TOTP seed is sitting in the clear"


# -------------------------------------------------------------------- roles --


def test_a_grant_belongs_to_the_firm_that_made_it(person, db) -> None:
    identity.grant_role(db, user_id=person.id, role="approver", granted_by="test")
    db.commit()

    identity._scope_to_user(db, person.id)
    held = [row.role for row in identity.roles_for(db, person.id)]
    assert held == ["approver"]

    with tenancy.acting_as("stranger-firm"):
        other = SessionLocal()
        try:
            assert other.scalars(
                select(UserRole).where(UserRole.user_id == person.id)
            ).all() == []
        finally:
            other.close()


def test_a_grant_that_has_run_out_stops_working_at_the_moment_it_runs_out(person, db) -> None:
    """Not at the next time a cleanup job happens to run.

    `quolin_support` grants are time-boxed by the execution document, and a
    time-boxed grant policed by a sweeper is a grant that lasts until the
    sweeper's next tick.
    """
    row = identity.grant_role(db, user_id=person.id, role="quolin_support", granted_by="test")
    row.expires_at = _now() - timedelta(seconds=1)
    db.commit()

    identity._scope_to_user(db, person.id)
    assert identity.roles_for(db, person.id) == []
    assert db.get(UserRole, row.id) is not None, "the row was deleted rather than expired"


# ------------------------------------------------------- sessions and step-up --


def test_a_session_records_the_person_and_how_they_proved_it(person, db) -> None:
    token = auth.create_session(
        db, tenant_id=DEMO_TENANT, user_id=person.id, mfa_satisfied=True
    )
    row = auth.resolve(db, token)
    assert row is not None
    assert row.user_id == person.id
    assert row.mfa_satisfied is True
    assert auth.credential_is_fresh(row)


def test_a_live_session_is_not_the_same_thing_as_a_present_person(person, db) -> None:
    """The two timestamps, and why there are two.

    `last_seen_at` says the browser is still there — an unattended laptop keeps
    it fresh indefinitely. `authenticated_at` says the person is. A signature is
    worth only the second one.
    """
    token = auth.create_session(db, tenant_id=DEMO_TENANT, user_id=person.id)
    row = auth.resolve(db, token)
    assert row is not None

    row.authenticated_at = _now() - timedelta(minutes=auth.REAUTH_MINUTES + 1)
    db.commit()

    assert not auth.credential_is_fresh(row)
    with pytest.raises(auth.ReauthenticationRequired) as refused:
        auth.require_fresh_credential(row, action="Signing this pack")
    assert "Signing this pack" in str(refused.value)

    # And the session itself is still perfectly live — this is a step-up, not a
    # logout. Anything that did not need a fresh credential still works.
    assert auth.resolve(db, token) is not None


def test_confirming_a_password_again_restores_the_freshness(person, db) -> None:
    token = auth.create_session(
        db, tenant_id=DEMO_TENANT, user_id=person.id, mfa_satisfied=True
    )
    row = auth.resolve(db, token)
    assert row is not None
    row.authenticated_at = _now() - timedelta(hours=2)
    db.commit()

    assert identity.authenticate(db, email=EMAIL, password=PASSWORD)
    auth.mark_reauthenticated(db, row, mfa_satisfied=False)

    auth.require_fresh_credential(row, action="Signing this pack")
    assert row.mfa_satisfied is False, (
        "a re-confirmation with only a password left the session claiming a "
        "second factor it did not present this time"
    )


def test_a_session_with_no_person_behind_it_is_inert(db) -> None:
    """Rows written before Stage 2 are grandfathered into nothing.

    `user_id` still has a default, because the column had to be nullable to be
    added to a populated table, and a row can therefore still be constructed
    with no person behind it. What must not follow is that such a row *works*:
    the middleware treats a session with no user as no session at all, so the
    only thing an old cookie can still do is be refused.

    Asserted at the session layer rather than over HTTP so it holds even for a
    caller that never goes through the middleware.
    """
    token = auth.create_session(db, tenant_id=DEMO_TENANT)
    row = auth.resolve(db, token)
    assert row is not None
    assert row.user_id is None, "nothing should mint an unattributed session any more"
    auth.destroy(db, token)


def test_another_firm_cannot_enumerate_sessions_but_a_cookie_still_resolves(person, db) -> None:
    """Two facts that look contradictory and are not, so both are pinned here.

    A firm listing `auth_sessions` sees only its own — the ordinary tenant
    policy. But `auth.resolve` finds a row from *any* tenant context, because
    resolving a cookie is what decides the tenant and so cannot be filtered by
    the tenant it has not decided yet. The `session_self` policy in migration
    0003 admits exactly one row: the one whose hash the caller already named.

    That is not a hole. Presenting the token is the same act as presenting the
    cookie, and the middleware immediately narrows to `row.tenant_id`. The hole
    would be the opposite arrangement, where a row was only visible to a tenant
    already in scope and login therefore had to trust something in the request.
    """
    token = auth.create_session(db, tenant_id=DEMO_TENANT, user_id=person.id)
    try:
        with tenancy.acting_as("stranger-firm"):
            other = SessionLocal()
            try:
                assert other.scalars(select(AuthSession)).all() == [], (
                    "another firm's sessions were listable"
                )
                resolved = auth.resolve(other, token)
                assert resolved is not None
                assert resolved.tenant_id == DEMO_TENANT
            finally:
                other.close()
    finally:
        auth.destroy(db, token)


def test_the_identity_tables_are_only_reachable_through_a_granted_role(person, db) -> None:
    """The containment property, restated from the sign-in side.

    `users` has no `tenant_id`, so what makes a staff list private is that a
    firm sees a person exactly when it has granted them a role. Before the
    grant, the probe user is invisible to the demo firm too — which is the point.
    """
    with tenancy.acting_as(DEMO_TENANT):
        looker = SessionLocal()
        try:
            assert looker.get(User, person.id) is None
            assert looker.scalars(
                select(MfaCredential).where(MfaCredential.user_id == person.id)
            ).all() == []
        finally:
            looker.close()

    identity.grant_role(db, user_id=person.id, role="viewer", granted_by="test")
    db.commit()

    with tenancy.acting_as(DEMO_TENANT):
        looker = SessionLocal()
        try:
            assert looker.get(User, person.id) is not None
        finally:
            looker.close()
