"""The watch service, and the two things it must never be able to do.

Most of this file is ordinary coverage. Two tests are not, and they are the
reason the phase is defensible at all:

  * `test_no_draft_becomes_rule_content_without_a_signature`
  * `test_no_watch_path_reaches_the_evaluator`

If either of those ever fails, the correct response is to stop shipping, not to
adjust the test. Everything else in the system rests on a determination being
the product of content a named person signed.
"""

from __future__ import annotations

import ast
import subprocess
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import pytest
from conftest import publish_with_dual_control, the_bytes_on_the_row
from sqlalchemy import select

from app import packs_repo, tenancy
from app.models import Pack as PackRow
from app.models import PackDraft, WatchEvent, WatchSource
from app.watch import currency, drafts, poll, sources, triage

ROOT = Path(__file__).resolve().parents[2]
API = ROOT / "api"


# --- The gate ---------------------------------------------------------------


def test_no_draft_becomes_rule_content_without_a_signature(session):
    """An unsigned draft cannot be published, by any route this module exposes.

    The check is a single condition in `drafts.publish`, and this test is what
    keeps it single: every other path to the `packs` table would have to go
    through here, and the guard script fails CI if a second one appears.
    """
    today = date.today()
    draft = drafts.create(
        session,
        jurisdiction="AU",
        on=today,
        effective_from=today + timedelta(days=45),
        title="Unsigned draft that must not become content",
        rationale="Written by a test to be refused.",
        author=drafts.WATCH_SERVICE_NAME,
        author_user_id=drafts.WATCH_SERVICE,
        threshold_changes={"max_crypto_concentration_bps": 111},
    )
    assert draft.status == drafts.DRAFT

    before = session.scalar(select(PackRow.id).order_by(PackRow.id.desc()))
    with pytest.raises(drafts.NotSigned) as exc:
        drafts.publish(
            session,
            draft.id,
            published_content_hash=the_bytes_on_the_row(session, draft),
        )

    # The refusal has to name the draft and its status, because the person who
    # sees it needs to know what to do next, not merely that something failed.
    assert str(draft.id) in str(exc.value)
    assert drafts.SIGNED in str(exc.value)

    after = session.scalar(select(PackRow.id).order_by(PackRow.id.desc()))
    assert after == before, "a refused publish wrote a pack row"
    assert session.get(PackDraft, draft.id).status == drafts.DRAFT
    assert session.get(PackDraft, draft.id).published_pack_id is None
    session.rollback()


def test_a_signature_needs_a_name(session):
    """A blank signature is worse than none: it looks like the gate was passed."""
    today = date.today()
    draft = drafts.create(
        session,
        jurisdiction="AU",
        on=today,
        effective_from=today + timedelta(days=45),
        title="Blank signature",
        rationale="Written by a test.",
        author=drafts.WATCH_SERVICE_NAME,
        author_user_id=drafts.WATCH_SERVICE,
    )
    for blank in ("", "   ", "\t\n"):
        with pytest.raises(ValueError):
            drafts.sign(
                session,
                draft.id,
                signatory=blank,
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
    assert session.get(PackDraft, draft.id).status == drafts.DRAFT
    session.rollback()


def test_a_signed_draft_publishes_and_carries_its_signatory_into_the_pack(session):
    today = date.today()
    draft = drafts.create(
        session,
        jurisdiction="AU",
        on=today,
        effective_from=today + timedelta(days=60),
        title="Signed draft",
        rationale="Written by a test.",
        author=drafts.WATCH_SERVICE_NAME,
        author_user_id=drafts.WATCH_SERVICE,
        threshold_changes={"max_crypto_concentration_bps": 900},
    )
    # Two people, because publication is a second pair of eyes and `publish`
    # refuses to be the same pair as the signature.
    with tenancy.acting_as_user("user-signatory"):
        drafts.sign(
            session,
            draft.id,
            signatory="A. Signatory",
            signed_content_hash=the_bytes_on_the_row(session, draft),
            note="Reviewed.",
        )
    # FP3-27: two platform publishers, neither of them the signer.
    row = publish_with_dual_control(session, draft.id)

    assert row.signed_by == "A. Signatory"
    # The name must be inside the body too, not only in the column. The body is
    # what a pack viewer renders and what a future draft would be cut from.
    assert row.body["signed_by"] == "A. Signatory"
    assert row.body["thresholds"]["max_crypto_concentration_bps"] == 900
    assert session.get(PackDraft, draft.id).status == drafts.PUBLISHED
    assert session.get(PackDraft, draft.id).published_pack_id == row.id
    session.rollback()


def test_a_published_draft_cannot_be_published_twice(session):
    today = date.today()
    draft = drafts.create(
        session,
        jurisdiction="AU",
        on=today,
        effective_from=today + timedelta(days=60),
        title="Double publish",
        rationale="Written by a test.",
        author=drafts.WATCH_SERVICE_NAME,
        author_user_id=drafts.WATCH_SERVICE,
    )
    with tenancy.acting_as_user("user-signatory"):
        drafts.sign(
            session,
            draft.id,
            signatory="A. Signatory",
            signed_content_hash=the_bytes_on_the_row(session, draft),
        )
    publish_with_dual_control(session, draft.id)
    with tenancy.acting_as_user("user-publisher"):
        with pytest.raises(drafts.NotSigned):
            drafts.publish(
                session,
                draft.id,
                published_content_hash=the_bytes_on_the_row(session, draft),
            )
    session.rollback()


def test_a_draft_may_not_invent_a_threshold_the_pack_does_not_declare(session):
    """Changing a number is an edit. Adding one is a rule change.

    A threshold with no rule reading it is dead weight that looks like content,
    and the screen offering the edit has no way to write the rule that would use
    it. Refused here rather than accepted and quietly ignored.
    """
    today = date.today()
    with pytest.raises(KeyError):
        drafts.create(
            session,
            jurisdiction="AU",
            on=today,
            effective_from=today + timedelta(days=30),
            title="Invented threshold",
            rationale="Written by a test.",
            author=drafts.WATCH_SERVICE_NAME,
        author_user_id=drafts.WATCH_SERVICE,
            threshold_changes={"a_threshold_no_pack_declares": 1},
        )
    session.rollback()


# --- The wall ---------------------------------------------------------------


def _imported_modules(path: Path) -> set[str]:
    tree = ast.parse(path.read_text())
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(a.name for a in node.names)
        elif isinstance(node, ast.ImportFrom):
            # Relative imports carry the leading dots in `level`, not in
            # `module`, so a `from ..watch import x` shows up as module='watch'.
            names.add(node.module or "")
            names.update(f"{node.module or ''}.{a.name}" for a in node.names)
    return names


def test_no_watch_path_reaches_the_evaluator():
    """No module under api/app/engine imports the watch service.

    Parsed rather than grepped: a string mentioning `watch` in a docstring is
    fine and a grep would trip on it, while `import` inside a function body is
    not fine and a grep for a line-start pattern would miss it. The AST sees
    exactly the imports and nothing else.
    """
    offenders = []
    for path in sorted((API / "app" / "engine").rglob("*.py")):
        for name in _imported_modules(path):
            if "watch" in name.split("."):
                offenders.append(f"{path.relative_to(ROOT)} imports {name}")
    assert not offenders, offenders


def test_the_watch_service_never_evaluates():
    """And the reverse: nothing under api/app/watch imports the engine.

    Reading pack *bodies* is allowed and is what `sources.py` does. Reading the
    evaluator is not, which is why `packs_repo.active_rows` returns rows rather
    than `engine.Pack`.
    """
    offenders = []
    for path in sorted((API / "app" / "watch").rglob("*.py")):
        for name in _imported_modules(path):
            parts = name.split(".")
            if "engine" in parts or "service" in parts:
                offenders.append(f"{path.relative_to(ROOT)} imports {name}")
    assert not offenders, offenders


def test_the_guard_script_agrees_with_these_tests():
    """CI runs a shell guard as well. If they ever disagree, one of them is wrong."""
    result = subprocess.run(
        ["bash", "scripts/guard_no_watch_in_engine.sh"],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr


def test_only_drafts_py_can_write_a_pack_row():
    """The signature gate is worth nothing if a second door exists."""
    offenders = []
    for path in sorted((API / "app" / "watch").rglob("*.py")):
        if path.name == "drafts.py":
            continue
        source = path.read_text()
        if "PackRow(" in source:
            offenders.append(str(path.relative_to(ROOT)))
    assert not offenders, offenders


# --- Triage -----------------------------------------------------------------


VOCAB = [
    {"term": "design and distribution obligations", "touches": ["X-TMD-01"]},
    {"term": "leverage", "touches": ["X-LEV-01", "leverage_prohibited_categories"]},
]


def test_triage_reports_what_matched_rather_than_a_score():
    verdict = triage.classify(
        title="Consultation on design and distribution obligations",
        summary="",
        vocabulary=VOCAB,
        has_active_pack=True,
    )
    assert verdict["tier"] == triage.TOUCHES_RULE_CONTENT
    assert verdict["matched"] == [
        {"term": "design and distribution obligations", "touches": ["X-TMD-01"]}
    ]


def test_triage_matches_whole_words_only():
    """'deleveraged' is not 'leverage'.

    Substring matching would put unrelated items at the top of a queue, and a
    queue whose top is untrustworthy is a queue that gets read from the bottom.
    """
    verdict = triage.classify(
        title="Review of deleveraged product distribution",
        summary="",
        vocabulary=VOCAB,
        has_active_pack=True,
    )
    assert verdict["tier"] == triage.IN_SCOPE
    assert verdict["matched"] == []


def test_triage_is_case_insensitive_and_tolerates_whitespace():
    verdict = triage.classify(
        title="DESIGN AND\n  DISTRIBUTION   OBLIGATIONS updated",
        summary="",
        vocabulary=VOCAB,
        has_active_pack=True,
    )
    assert verdict["tier"] == triage.TOUCHES_RULE_CONTENT


def test_an_item_about_a_regime_with_no_pack_says_so():
    verdict = triage.classify(
        title="Anything at all", summary="", vocabulary=None, has_active_pack=False
    )
    assert verdict["tier"] == triage.UNMATCHED
    assert verdict["matched"] == []


def test_triage_is_deterministic_and_ordered_by_the_pack():
    """Two runs over the same text produce identical output, in pack order."""
    text = "Leverage and design and distribution obligations both appear here."
    first = triage.matches(text, VOCAB)
    second = triage.matches(text, VOCAB)
    assert first == second
    assert [m["term"] for m in first] == [v["term"] for v in VOCAB]


def test_tier_order_puts_rule_content_first():
    assert triage.TIERS[0] == triage.TOUCHES_RULE_CONTENT
    assert sorted(triage.TIERS, key=triage.sort_key) == list(triage.TIERS)
    # An unknown tier sorts last rather than raising: a queue that crashes on a
    # row it does not recognise is worse than one that shows it at the bottom.
    assert triage.sort_key("SOMETHING_NEW") == len(triage.TIERS)


def test_every_tier_has_a_label_and_an_explanation():
    for tier in triage.TIERS:
        assert triage.TIER_LABELS[tier]
        assert triage.TIER_EXPLANATIONS[tier]


# --- Sources and freshness --------------------------------------------------


def test_freshness_bands():
    now = datetime(2026, 8, 20, tzinfo=timezone.utc)
    assert sources.freshness(now - timedelta(days=3), 7, now) == sources.CURRENT
    assert sources.freshness(now - timedelta(days=7), 7, now) == sources.CURRENT
    assert sources.freshness(now - timedelta(days=9), 7, now) == sources.DUE
    assert sources.freshness(now - timedelta(days=14), 7, now) == sources.DUE
    assert sources.freshness(now - timedelta(days=15), 7, now) == sources.STALE


def test_a_source_never_checked_is_stale_not_a_fourth_state(session):
    now = datetime(2026, 8, 20, tzinfo=timezone.utc)
    assert sources.freshness(None, 30, now) == sources.STALE


def test_a_regime_with_no_sources_is_stale_not_current():
    """Unmonitored is not up to date. The badge must not reward having nothing."""
    assert sources.worst([]) == sources.STALE
    assert sources.worst([sources.CURRENT, sources.STALE]) == sources.STALE
    assert sources.worst([sources.CURRENT, sources.DUE]) == sources.DUE
    assert sources.worst([sources.CURRENT, sources.CURRENT]) == sources.CURRENT


def test_sources_come_from_pack_content_not_from_code(session):
    """Every declared source traces back to a `watch.sources` entry in a pack."""
    today = date.today()
    declared = sources.declared(session, today)
    assert declared, "no sources declared by any in-force pack"

    from_packs = set()
    for jurisdiction, row in packs_repo.active_rows(session, today).items():
        for spec in ((row.body or {}).get("watch") or {}).get("sources", []):
            from_packs.add((jurisdiction, spec["id"]))
    assert {(s["jurisdiction"], s["id"]) for s in declared} == from_packs


def test_no_regulator_or_jurisdiction_name_is_hardcoded_in_the_watch_package():
    """Same discipline as invariant 1, one directory over.

    A source URL or a regulator's phrase for a concept is a fact about a regime.
    The moment one is written in Python, adding a fifth regime means editing code
    again, and the portability claim quietly stops being true.
    """
    codes = ("AU", "HK", "SG", "EU")
    offenders = []
    for path in sorted((API / "app" / "watch").rglob("*.py")):
        for lineno, line in enumerate(path.read_text().splitlines(), 1):
            if line.lstrip().startswith("#"):
                continue
            for code in codes:
                if f"'{code}'" in line or f'"{code}"' in line:
                    offenders.append(f"{path.relative_to(ROOT)}:{lineno}: {line.strip()}")
    assert not offenders, offenders


def test_default_mode_is_replay(monkeypatch):
    """The other default is a demo that quietly contacts four regulators."""
    monkeypatch.delenv("WATCH_MODE", raising=False)
    assert sources.mode() == sources.REPLAY
    monkeypatch.setenv("WATCH_MODE", "nonsense")
    assert sources.mode() == sources.REPLAY
    monkeypatch.setenv("WATCH_MODE", "LIVE")
    assert sources.mode() == sources.LIVE


def test_live_mode_never_falls_back_to_the_fixture(session, monkeypatch):
    """A silent fallback is the worst available behaviour.

    The screen would say `live`, the data would be invented, and nobody
    downstream could tell the difference. Stage 6 built real fetching, so what
    live mode does now depends on what pack content declares — but the thing it
    must never do is unchanged, and this is the test of it: no fixture event is
    ever written by a live sweep.

    Only the EU pack declares a feed this build can read, and it points at a
    host no test contacts. Every other source has no adapter, so a live sweep
    here records failures against them and writes nothing. See
    `test_source_slas.py` for the fetching itself, driven against a stub.
    """
    monkeypatch.setenv("WATCH_MODE", "live")
    before = session.scalar(select(WatchEvent.id).order_by(WatchEvent.id.desc()))

    def refuse_to_leave_the_building(spec, *, today, client=None):
        raise poll.fetchers.FetchError(spec["id"], "no network in tests")

    monkeypatch.setattr(poll.fetchers, "fetch", refuse_to_leave_the_building)
    result = poll.poll(session, date.today())
    session.flush()

    after = session.scalar(select(WatchEvent.id).order_by(WatchEvent.id.desc()))
    assert after == before, "a live sweep wrote an event it did not fetch"
    assert result["new_events"] == 0
    session.rollback()


def test_each_source_records_the_mode_of_its_own_last_check(session):
    """A screen must not be able to relabel history by changing an env var."""
    rows = session.scalars(select(WatchSource)).all()
    assert rows, "no watch sources — run `make seed` first"
    for row in rows:
        if row.last_checked_at is not None:
            # §S13 added a third: a source that cannot be polled is checked by
            # a person, and recording that as `replay` or `live` would claim a
            # machine did something it did not.
            assert row.last_mode in sources.MODES


def test_the_fixture_says_it_is_invented():
    """Nobody should have to already know the events are made up."""
    import json

    body = json.loads((ROOT / "fixtures" / "watch_events.json").read_text())
    assert "INVENTED" in body["note"]
    assert "No regulator published any of it" in body["note"]


# --- Polling ----------------------------------------------------------------


def test_polling_twice_raises_nothing_the_second_time(session):
    """Re-running a poll must not resurrect items an officer has dismissed."""
    today = date.today()
    dismissed = session.scalars(
        select(WatchEvent).where(WatchEvent.status == "dismissed")
    ).first()
    assert dismissed is not None, "seed should leave one dismissed item"

    result = poll.poll(session, today)
    assert result["new_events"] == 0
    assert result["already_seen"] > 0
    session.expire(dismissed)
    assert dismissed.status == "dismissed"
    session.rollback()


def test_a_digest_is_stable_across_runs():
    a = poll.digest_for("s", "https://example.test/x", "Title", "2026-08-01")
    b = poll.digest_for("s", "https://example.test/x", "Title", "2026-08-01")
    assert a == b
    assert a != poll.digest_for("s", "https://example.test/y", "Title", "2026-08-01")


def test_the_seeded_queue_has_something_in_every_tier(session):
    """Including the coverage-gap tier — a demo that never shows it proves nothing."""
    tiers = set(session.scalars(select(WatchEvent.tier)))
    assert triage.TOUCHES_RULE_CONTENT in tiers
    assert triage.IN_SCOPE in tiers
    assert triage.UNMATCHED in tiers


def test_an_item_about_a_regime_with_no_pack_is_filed_under_that_regime(session):
    """Not under the regulator that happened to publish it."""
    row = session.scalars(
        select(WatchEvent).where(WatchEvent.tier == triage.UNMATCHED)
    ).first()
    assert row is not None
    held = set(packs_repo.active_rows(session, date.today()))
    assert row.jurisdiction not in held
    assert row.source_id in {s["id"] for s in sources.declared(session, date.today())}


# --- Future effectivity -----------------------------------------------------


def test_a_future_dated_pack_changes_nothing_today(session):
    """The property that makes it safe to store one at all.

    The seed publishes a pack effective three weeks out. If `active()` were to
    pick it up, every determination made today would silently move to content
    nobody has started applying yet — and the decision record would still say
    the version it was made under, so the discrepancy would be invisible.
    """
    today = date.today()
    pending = packs_repo.pending_rows(session, today)
    assert pending, "seed should leave a future-dated pack"

    for row in pending:
        assert row.effective_from > today
        in_force = packs_repo.active(session, row.jurisdiction, today)
        assert in_force.version != row.version
        assert in_force.effective_from <= today


def test_pending_packs_carry_a_countdown(session):
    today = date.today()
    pending = currency.pending_packs(session, today)
    assert pending
    for entry in pending:
        assert entry["days_until_effective"] > 0
        assert entry["signed_by"], "a published pack always has a signatory"


def test_a_pending_pack_takes_effect_on_its_own_date(session):
    """And on that date, `active()` returns it without anything being edited.

    No row is updated to make the handover happen: `packs` is append-only and the
    selection is by date. This test is the proof that the append-only constraint
    and version supersession are compatible.
    """
    today = date.today()
    row = packs_repo.pending_rows(session, today)[0]
    later = packs_repo.active(session, row.jurisdiction, row.effective_from)
    assert later.version == row.version


# --- The currency screen ----------------------------------------------------


def test_the_overview_states_its_mode_and_what_that_means(session):
    view = currency.overview(session)
    assert view["mode"] in (sources.REPLAY, sources.LIVE)
    assert "No regulator is contacted" in view["mode_note"]
    assert "has changed a rule" in view["statement"]


def test_the_overview_rolls_freshness_up_worst_first(session):
    view = currency.overview(session)
    assert view["freshness"] in sources.FRESHNESS
    per = {j["jurisdiction"]: j["freshness"] for j in view["jurisdictions"]}
    assert view["freshness"] == sources.worst(list(per.values()))


def test_the_overview_shows_a_draft_waiting_for_a_signature(session):
    """The demo moment. If this list is empty the phase has nothing to show."""
    view = currency.overview(session)
    awaiting = view["drafts_awaiting_signature"]
    assert awaiting, "seed should leave one unsigned draft"
    for entry in awaiting:
        assert entry["status"] == drafts.DRAFT
        assert entry["signed_by"] == ""
        assert entry["signed_at"] is None
        assert entry["is_live"] is False
        assert entry["rationale"]


def test_a_jurisdiction_that_declares_no_sources_is_marked_unwatched(session):
    view = currency.overview(session)
    for entry in view["jurisdictions"]:
        if not entry["watched"]:
            assert entry["freshness"] == sources.STALE
