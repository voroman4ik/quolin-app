"""`binds=True` is a claim about a recorder, and this is where it is charged for.

The census file next door ends the sequence at the *classification* layer: a new
write route cannot reach a green CI without somebody saying what it does with a
person's name, and a route that says "it binds" must carry a required
`*_content_hash` field on its request model. Both of those are real, and both
were found by the round after it to be satisfiable without enforcing anything.
Two things were injected into a scratch copy of the tree and the whole suite
stayed green:

  1. a route classified `binds=False` with a plausible five-word reason — the
     census asks for a reason and cannot ask whether it is true;
  2. a route classified `binds=True`, with a hash field added to its Pydantic
     model, **whose handler never read the field**. The schema assertion passed
     because the field existed. Nothing looked at the recorder.

So a future route could carry `signed_content_hash: str = Field(min_length=1)`
for show, never compare it, and claim a binding in the same table as the four
that have one. The census's own docstring says the thing this file exists to
make true — *"reclassifying it would have to break this"* — and says it about
the classification layer. This file extends it to the enforcement layer:

    a route cannot claim `binds=True` and pass CI unless something concrete
    breaks when its recorder stops comparing.

Four probes, one per bound route, each over HTTP against the real recorder, and
each proving both halves:

  * a wrong hash is refused with 409, **and the column that route exists to
    write is still unset and the draft's status has not advanced** — a refusal
    that returned 409 and wrote the row anyway would pass a status-code
    assertion and fail the only thing that matters;
  * the *same* draft, re-read and attested to honestly, succeeds — because a
    check that refuses the ordinary path is a check somebody removes on a
    Friday, and a probe that only asserts refusal cannot tell a binding from a
    route that is simply broken.

And a fifth test walks `CENSUS` and refuses to let a `binds=True` entry exist
without a probe registered against it. That is what turns "four routes happen to
be probed" into "no route can claim a binding without proving it".

Verified by reversion, which is the only way to know a test tests anything. Each
of the four recorders was put back to the pre-census behaviour in turn — the
call to `_the_bytes_that_were_read` replaced by the hash of the body the call
found, which is B1's shape and the defect this whole sequence is about — and
each time exactly that route's probe here failed and the other three passed.
The census file's schema test passed every time, on every one of the four
reversions, which is the finding this file answers.

Each failure landed on the refusal assertion, because a recorder that has
stopped comparing answers 200 and the probe never reaches its column checks.
Those checks are not therefore decorative: they are what catches the other
shape, a route that refuses with the right status code and writes the row
anyway. Nothing in this tree does that today, and a status code is not evidence
that nothing was written.
"""

from __future__ import annotations

import inspect
from typing import Callable

import pytest
from conftest import a_platform_publisher, reset_rate_limit_for_tests
from fastapi.testclient import TestClient
from sqlalchemy import select

# From the census file rather than restated here, and the import is the point.
# A registry checked against a *copy* of the census would go green the moment
# the two copies disagreed, which is the failure mode the census's own
# "does not describe routes that are gone" test exists to prevent one layer up.
# The account helpers come with it for the same reason `cast` is module-scoped
# there: a change to how this suite mints a signatory must change both files at
# once or neither.
from test_an_attestation_is_of_the_bytes_the_attester_saw import (
    APPROVER_EMAIL,
    ATTACK_THRESHOLD,
    ATTACK_VALUE,
    AUTHOR_EMAIL,
    CENSUS,
    PUBLISHER_EMAIL,
    SIGNATORY_EMAIL,
    _cut_a_draft,
    _person,
    _sign_in,
)

from app.db import OwnerSessionLocal
from app.main import app
from app.models import PackDraft, PublicationApproval
from app.watch import drafts

# ------------------------------------------------------------ the registry ---

#: (method, path) -> the probe function that attacks that route over HTTP.
#:
#: Populated by the decorator below at import time, so the walking test reads
#: what is actually in this file rather than a list somebody maintains beside
#: it. A list would be a third copy of the census and would rot like the other
#: two would have.
PROBES: dict[tuple[str, str], Callable] = {}


def probes(method: str, path: str):
    """Register a test as the HTTP enforcement probe for one census route.

    The path is written exactly as the census writes it — the FastAPI template,
    `{draft_id}` and all — because the walking test compares these keys with
    `CENSUS` directly and a probe filed under a path spelled differently is a
    probe the census cannot find.
    """

    def register(fn: Callable) -> Callable:
        if (method, path) in PROBES:
            raise AssertionError(
                f"two probes are registered for {method} {path}: "
                f"{PROBES[(method, path)].__name__} and {fn.__name__}. One route "
                "has one enforcement probe; a second would let a weak one stand "
                "in for a strong one."
            )
        PROBES[(method, path)] = fn
        return fn

    return register


# ----------------------------------------------------------------- the cast --


@pytest.fixture(scope="module")
def cast() -> dict[str, str]:
    """An author who may edit, and an independent signatory who may attest.

    The same two accounts the census file uses, minted by the same helper. The
    author holds `operator` because the edit in the middle of every probe below
    is the S5 workbench act rather than a contrivance.
    """
    return {
        "author": _person(AUTHOR_EMAIL, ("pack_signatory", "AU"), ("operator", "")),
        "signatory": _person(SIGNATORY_EMAIL, ("pack_signatory", "AU")),
    }


@pytest.fixture(scope="module")
def publishers() -> dict[str, str]:
    """Two platform publishers, on `@quolin.test` and the domain is load-bearing.

    `test_publication_is_platform_scoped_with_dual_control` asserts that platform
    publication is held by exactly the two named humans the seed creates, and
    excludes this suite's synthetic domain from that claim. An account minted
    here on `@quolin.example` would read as a third real person acquiring the
    grant that puts rule content in front of every firm.
    """
    approver = _person(APPROVER_EMAIL, ("quolin_operator", ""), ("operator", ""))
    publisher = _person(PUBLISHER_EMAIL, ("quolin_operator", ""), ("operator", ""))
    a_platform_publisher(approver)
    a_platform_publisher(publisher)
    return {"approver": approver, "publisher": publisher}


def _body_of(probe: Callable) -> str:
    """A probe's source with its own decorators removed.

    `inspect.getsource` hands back the decorator lines too, and the decorator
    line *is* `@probes("POST", ".../sign")` — so a path check over the whole
    source would be satisfied by the registration it is supposed to be checking
    against. Two probes registered against each other's routes passed that check
    until this function existed; the mutation is in the round's spec-changes
    entry because it is the shape of thing this file is about.

    Note for anybody checking this against Rule A: the source read here is a
    *test's* source, never `api/app` or `scripts`. Nothing in this file makes a
    claim about application behaviour by reading application text — the claims
    about the four recorders are all made by attacking them over HTTP and
    reading the resulting rows out of the database.
    """
    source = inspect.getsource(probe)
    lines = source.splitlines(keepends=True)
    for index, line in enumerate(lines):
        if line.lstrip().startswith("def "):
            return "".join(lines[index:])
    raise AssertionError(f"no def line in the source of {probe.__name__}")


def _the_row(draft_id: int) -> PackDraft:
    """The draft as the database holds it, not as a route chose to render it.

    Every assertion about what was or was not written reads the row. `view()` is
    a projection with opinions — `signed_by_its_author`, `current_content_hash`,
    a second review reported as valid only while it matches the body — and a
    probe that asked `view()` whether a signature happened would be asking the
    same code that would have to be wrong for the write to have happened.
    """
    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row is not None, f"draft {draft_id} is gone"
        owner.refresh(row)
        return row
    finally:
        owner.close()


def _approvals(draft_id: int) -> list[PublicationApproval]:
    owner = OwnerSessionLocal()
    try:
        return list(
            owner.scalars(
                select(PublicationApproval).where(
                    PublicationApproval.draft_id == draft_id
                )
            )
        )
    finally:
        owner.close()


def _edit(author: TestClient, draft_id: int) -> None:
    """The author moves a threshold while somebody else is reading.

    A threshold rather than a note, for the census file's reason: the difference
    between "they did not see this word" and "they did not see this number the
    engine decides on".
    """
    current = author.get(f"/watch/drafts/{draft_id}")
    assert current.status_code == 200, current.text
    edited = author.patch(
        f"/watch/drafts/{draft_id}",
        json={
            "thresholds": dict(current.json()["body"]["thresholds"])
            | {ATTACK_THRESHOLD: ATTACK_VALUE}
        },
    )
    assert edited.status_code == 200, edited.text


def _hash_now(client: TestClient, draft_id: int) -> str:
    read = client.get(f"/watch/drafts/{draft_id}")
    assert read.status_code == 200, read.text
    current = read.json()["current_content_hash"]
    assert current, "view returned no hash for the body it rendered"
    return current


# ---------------------------------------------------- the four enforcement ---
#
# Each probe is one draft carried through both outcomes rather than two drafts
# carried through one each. Doing it on one row is what proves the refusal is a
# *window* and not a wall: the same person, the same draft, the same session,
# refused for reading a stale screen and accepted the moment they read the
# current one. Two drafts would leave open that the refusal was about the draft.


@probes("POST", "/watch/drafts/{draft_id}/second-review")
def test_a_second_review_of_bytes_that_moved_is_refused_and_writes_no_reviewer(
    cast,
):
    """`reviewed_content_hash` is compared, or `second_reviewer_user_id` lies.

    This route was the first one bound (F1) and the last one probed over HTTP:
    the census file attacks `sign`, `approve-publication` and `publish` through
    the API and reaches `record_second_review` only in-process, through
    `drafts.record_second_review` directly. So the *route* — its 409 mapping,
    its payload wiring, the field name it forwards — was never attacked from
    outside. It is here now.
    """
    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="A review of bytes that moved")

        with TestClient(app) as reviewer:
            _sign_in(reviewer, SIGNATORY_EMAIL)

            what_they_read = _hash_now(reviewer, draft_id)
            _edit(author, draft_id)

            refused = reviewer.post(
                f"/watch/drafts/{draft_id}/second-review",
                json={
                    "note": "I read it.",
                    "reviewed_content_hash": what_they_read,
                },
            )
            assert refused.status_code == 409, refused.text

            # The write did not happen. Not a review later found to be of the
            # wrong bytes — no reviewer, no account, no time, no hash.
            row = _the_row(draft_id)
            assert row.second_reviewer_user_id is None
            assert row.second_reviewer == ""
            assert row.second_reviewed_at is None
            assert not row.second_reviewed_content_hash
            assert row.status == drafts.DRAFT

            # And the same reviewer, on the same draft, having re-read it.
            after = _hash_now(reviewer, draft_id)
            assert after != what_they_read, "the edit did not move the body"
            accepted = reviewer.post(
                f"/watch/drafts/{draft_id}/second-review",
                json={"note": "Read the edit.", "reviewed_content_hash": after},
            )
            assert accepted.status_code == 200, accepted.text

    row = _the_row(draft_id)
    assert row.second_reviewer_user_id == cast["signatory"]
    assert row.second_reviewed_content_hash == after


@probes("POST", "/watch/drafts/{draft_id}/sign")
def test_a_signature_over_bytes_that_moved_is_refused_and_writes_no_signature(cast):
    """`signed_content_hash` is compared, or `signed_by` names an unread body.

    The reported sequence, stated as the enforcement property rather than as the
    auditor's narrative: what must be true is that the four columns a signature
    writes are all still empty after the refusal. `content_hash` among them,
    because a row carrying a hash and no signatory would be a draft that had
    been half-signed.
    """
    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="A signature over bytes that moved")

        with TestClient(app) as signatory:
            _sign_in(signatory, SIGNATORY_EMAIL)

            what_they_read = _hash_now(signatory, draft_id)
            _edit(author, draft_id)

            refused = signatory.post(
                f"/watch/drafts/{draft_id}/sign",
                json={"note": "I read it.", "signed_content_hash": what_they_read},
            )
            assert refused.status_code == 409, refused.text

            row = _the_row(draft_id)
            assert row.signed_by == ""
            assert row.signed_by_user_id is None
            assert row.signed_at is None
            assert row.signed_qualification_ref == ""
            assert not row.content_hash
            assert row.status == drafts.DRAFT

            after = _hash_now(signatory, draft_id)
            assert after != what_they_read, "the edit did not move the body"
            accepted = signatory.post(
                f"/watch/drafts/{draft_id}/sign",
                json={"note": "Read the edit.", "signed_content_hash": after},
            )
            assert accepted.status_code == 200, accepted.text

    row = _the_row(draft_id)
    assert row.status == drafts.SIGNED
    assert row.signed_by_user_id == cast["signatory"]
    assert row.content_hash == after


@probes("POST", "/watch/drafts/{draft_id}/approve-publication")
def test_an_approval_of_bytes_that_moved_is_refused_and_writes_no_approval(
    cast, publishers
):
    """`approved_content_hash` is compared, or `publication_approvals` lies.

    The approver's window is wider than the signatory's because it spans the
    signature, so the edit here sits *before* a sound signature rather than
    after one: the approver reads while the draft is still being worked on, its
    author edits, a signatory reads the edit and signs it honestly, and the
    approver's screen is the only stale thing left. That ordering matters — it
    is what makes this a test of the approver's own binding rather than of
    `SignedBytesChanged`, which would answer first if the body had moved after
    the signature.

    The write this route makes is a row in another table, so the assertion is
    that the table is empty for this draft rather than that a column is unset.
    """
    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="An approval of bytes that moved")

        with TestClient(app) as approver, TestClient(app) as signatory:
            _sign_in(approver, APPROVER_EMAIL)
            _sign_in(signatory, SIGNATORY_EMAIL)

            what_they_read = _hash_now(approver, draft_id)
            _edit(author, draft_id)

            signed = signatory.post(
                f"/watch/drafts/{draft_id}/sign",
                json={
                    "note": "Read the edit and signed it.",
                    "signed_content_hash": _hash_now(signatory, draft_id),
                },
            )
            assert signed.status_code == 200, signed.text

            refused = approver.post(
                f"/watch/drafts/{draft_id}/approve-publication",
                json={"approved_content_hash": what_they_read},
            )
            assert refused.status_code == 409, refused.text

            assert _approvals(draft_id) == [], (
                "an approval was recorded by a request the route refused"
            )
            row = _the_row(draft_id)
            assert row.status == drafts.SIGNED, "it advanced past a refusal"
            assert row.published_by_user_id is None
            assert row.published_pack_id is None

            after = _hash_now(approver, draft_id)
            assert after != what_they_read, "the edit did not move the body"
            accepted = approver.post(
                f"/watch/drafts/{draft_id}/approve-publication",
                json={"approved_content_hash": after},
            )
            assert accepted.status_code == 200, accepted.text

    recorded = _approvals(draft_id)
    assert len(recorded) == 1
    assert recorded[0].approved_by == publishers["approver"]
    assert recorded[0].content_hash == after


@probes("POST", "/watch/drafts/{draft_id}/publish")
def test_a_publication_of_bytes_that_moved_is_refused_and_publishes_nothing(
    cast, publishers
):
    """`published_content_hash` is compared, or a pack goes out under a stale read.

    Two checks answer before this one — `NeedsASecondApprover` and
    `SignedBytesChanged` — and both are arranged away deliberately, so that the
    409 this probe asserts can only have come from the publisher's own binding.
    The approver approves honestly first, which meets the quorum; the body has
    not moved since the signature, so nothing was altered after somebody
    attested to it. What is left wrong is one thing: the publisher is looking at
    a screen from before the edit.

    If the recorder stopped comparing, this test would not merely fail — a pack
    version would exist, in `packs`, in front of every firm under AU, with an
    account against it that had read a different body. That is the outcome the
    whole sequence is about, and it is what this probe costs the tree if the
    check is removed.
    """
    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        draft_id = _cut_a_draft(author, title="A publication of bytes that moved")

        with (
            TestClient(app) as approver,
            TestClient(app) as publisher,
            TestClient(app) as signatory,
        ):
            _sign_in(approver, APPROVER_EMAIL)
            _sign_in(publisher, PUBLISHER_EMAIL)
            _sign_in(signatory, SIGNATORY_EMAIL)

            what_they_read = _hash_now(publisher, draft_id)
            _edit(author, draft_id)

            signed = signatory.post(
                f"/watch/drafts/{draft_id}/sign",
                json={
                    "note": "Read the edit and signed it.",
                    "signed_content_hash": _hash_now(signatory, draft_id),
                },
            )
            assert signed.status_code == 200, signed.text

            # The quorum, met honestly, so `NeedsASecondApprover` cannot be the
            # thing that answers below.
            approved = approver.post(
                f"/watch/drafts/{draft_id}/approve-publication",
                json={"approved_content_hash": _hash_now(approver, draft_id)},
            )
            assert approved.status_code == 200, approved.text

            refused = publisher.post(
                f"/watch/drafts/{draft_id}/publish",
                json={"published_content_hash": what_they_read},
            )
            assert refused.status_code == 409, refused.text

            row = _the_row(draft_id)
            assert row.status == drafts.SIGNED, "it published anyway"
            assert row.published_by_user_id is None
            assert row.published_pack_id is None

            after = _hash_now(publisher, draft_id)
            assert after != what_they_read, "the edit did not move the body"
            accepted = publisher.post(
                f"/watch/drafts/{draft_id}/publish",
                json={"published_content_hash": after},
            )
            assert accepted.status_code == 200, accepted.text

    row = _the_row(draft_id)
    assert row.status == drafts.PUBLISHED
    assert row.published_by_user_id == publishers["publisher"]
    assert row.published_pack_id is not None


# ------------------------------------------- and no route escapes the rule ---


def test_every_route_that_claims_to_bind_has_an_http_enforcement_probe():
    """The mechanical half, and the reason this file is not just four tests.

    Four routes being probed today is a fact about today. What makes it a
    property is this: a fifth entry added to `CENSUS` with `binds=True` fails
    here until somebody writes a probe that attacks it over HTTP and registers
    it. The census one layer up already refuses an *unclassified* route; this
    refuses a route classified as binding that nothing would catch if its
    recorder stopped comparing.

    Three things are checked, and the second and third are what stop the
    registry becoming ceremony:

      *coverage* — every `binds=True` entry has a probe, and no probe is
        registered against a route the census does not call bound (a probe left
        behind by a reclassification is a probe nobody runs against anything);
      *the probe addresses that route* — its source contains the route's own
        path template, so a probe registered under one path and attacking
        another is refused here rather than passing forever;
      *the probe asserts both outcomes* — a refusal and a success. A probe that
        only asserted 409 could not tell a working binding from a route that
        refuses everything, and the check people delete is the one that refuses
        the ordinary path.

    The last two read the probe's source, which is a blunt instrument and is
    meant to be. They cannot prove a probe is good; they can stop the three ways
    a probe becomes decorative without anybody noticing.
    """
    bound = {(e.method, e.path) for e in CENSUS if e.binds}

    unprobed = bound - set(PROBES)
    assert not unprobed, (
        "these routes claim `binds=True` in the census and nothing proves their "
        "recorder enforces it:\n  "
        + "\n  ".join(f"{m} {p}" for m, p in sorted(unprobed, key=lambda x: x[1]))
        + "\n\nA `*_content_hash` field on the request model is not a binding — "
        "a handler that never reads the field satisfies the census's schema test "
        "and enforces nothing, which is exactly what was injected into a scratch "
        "tree and passed. Write a probe in this file that POSTs a wrong hash to "
        "the route, asserts the refusal AND that the column it writes is still "
        "unset, then re-reads and asserts success. Register it with "
        "@probes(method, path)."
    )

    orphaned = set(PROBES) - bound
    assert not orphaned, (
        "these probes are registered against routes the census does not call "
        "bound:\n  "
        + "\n  ".join(
            f"{m} {p} -> {PROBES[(m, p)].__name__}"
            for m, p in sorted(orphaned, key=lambda x: x[1])
        )
        + "\n\nEither the route was reclassified and its probe should go with it, "
        "or the registration names a path the census spells differently."
    )

    for (method, path), probe in sorted(PROBES.items(), key=lambda kv: kv[0][1]):
        source = _body_of(probe)
        assert path in source, (
            f"{probe.__name__} is registered as the probe for {method} {path} "
            f"and its body never names that path. A probe that attacks a "
            "different route than the one it is filed under would let the route "
            "it is filed under go unenforced forever."
        )
        assert "409" in source, (
            f"{probe.__name__} never asserts a refusal, so it cannot show that a "
            "wrong hash is refused."
        )
        assert "200" in source, (
            f"{probe.__name__} never asserts a success. Refusal alone does not "
            "distinguish a binding from a route that refuses everything, and a "
            "check that blocks the ordinary path is a check somebody removes."
        )


def test_the_probes_are_tests_pytest_will_actually_run():
    """Registration is not execution, and the decorator cannot tell the difference.

    `@probes(...)` returns the function unchanged, so a probe renamed out of
    pytest's `test_*` convention would still register, still satisfy the walking
    test above, and never run again. One line, and it closes the gap between
    "there is a probe" and "the probe runs".
    """
    not_collected = [
        f"{m} {p} -> {fn.__name__}"
        for (m, p), fn in sorted(PROBES.items(), key=lambda kv: kv[0][1])
        if not fn.__name__.startswith("test_")
    ]
    assert not not_collected, (
        "these probes are registered but pytest will not collect them:\n  "
        + "\n  ".join(not_collected)
    )
