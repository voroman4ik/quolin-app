"""§S13: two officers working at once must not fork the evidence chain.

The defect this file exists for was found by §S13's second restore drill, in the
one tenant §S12's load test had driven with twenty concurrent sessions: ten
determinations sharing a single `prev_hash`, written within twenty milliseconds
of each other. Each writer read the tip, hashed from it, and inserted. All ten
were valid links from the same parent, and a chain with ten children is a tree —
`verify_chain` walks by id, so it broke at the second sibling and reported that
firm's evidence as unverifiable.

**Every chain test in this suite passed the whole time.** A determination is made
by a person, the demo firm has one firm's staff, and the bulk sweep is one worker
per tenant by construction, so nothing had ever appended to one chain from two
connections at once. The guarantee the product is sold on would have failed the
first afternoon two compliance officers worked at the same time.

So this test does the thing nothing else does: real threads, real connections,
one tenant, at the same moment. It is slower than the rest of the suite and it
is the only test here that can catch this.
"""

from __future__ import annotations

import threading
from datetime import date

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import func, select, text

from app import evidence, service, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.models import Decision

ACTOR = "apc_bulk_sweep"
WRITERS = 8
CLIENT = "tom-askew"


@pytest.fixture
def undo():
    """Remove what this file wrote, as the owner.

    `decisions` is append-only to the application role by trigger and by grant,
    which is the property working. The suite's own fixtures take the same route
    for the same reason — a test that could delete evidence through the
    application would be evidence that the application can.
    """
    before = _count()
    yield
    owner = OwnerSessionLocal()
    try:
        owner.execute(text("ALTER TABLE decisions DISABLE TRIGGER decisions_append_only"))
        owner.execute(
            text("DELETE FROM decisions WHERE tenant_id = :t AND id > :id"),
            {"t": DEMO_TENANT, "id": before},
        )
        owner.execute(text("ALTER TABLE decisions ENABLE TRIGGER decisions_append_only"))
        owner.commit()
    finally:
        owner.close()


def _count() -> int:
    owner = OwnerSessionLocal()
    try:
        return owner.scalar(
            select(func.max(Decision.id)).where(Decision.tenant_id == DEMO_TENANT)
        ) or 0
    finally:
        owner.close()


def test_eight_officers_at_once_leave_one_chain(undo):
    """The whole point. Eight connections, one firm, one instant.

    Fails without `evidence._lock_chain`, and the *way* it fails is worth
    knowing: with the lock removed the writers now collide on the unique index
    and raise, rather than forking silently as they did when this was found. So
    the first assertion below catches it. The second — that the chain still
    verifies — is what catches it if the index is ever dropped as well, which is
    the state the defect was actually discovered in.
    """
    start = threading.Barrier(WRITERS)
    errors: list[Exception] = []
    lock = threading.Lock()

    def write(n: int) -> None:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            session = SessionLocal()
            try:
                start.wait(timeout=30)
                service.evaluate(
                    session,
                    client_id=CLIENT,
                    asset_id="BTC",
                    as_of=date.today(),
                )
                session.commit()
            except Exception as exc:  # noqa: BLE001 — collected and asserted below
                session.rollback()
                with lock:
                    errors.append(exc)
            finally:
                session.close()

    threads = [threading.Thread(target=write, args=(n,)) for n in range(WRITERS)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=60)

    assert not errors, f"a writer failed: {errors[0]!r}"

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            result = evidence.verify_chain(session)
        finally:
            session.close()

    assert result["verified"], (
        f"eight concurrent determinations forked the chain: {result}. This is "
        "the guarantee the product is sold on, and it fails silently — every "
        "write succeeds and the break only appears when somebody verifies."
    )


def test_no_two_determinations_share_a_parent(undo):
    """The second lock, asserted directly.

    A unique index on `(tenant_id, prev_hash)` means a path that appends without
    taking the chain lock fails loudly rather than forking. Checked as a
    property of the table rather than through the write path, because the write
    path is exactly what the index is insurance against.
    """
    owner = OwnerSessionLocal()
    try:
        forks = owner.execute(
            text(
                "SELECT tenant_id, prev_hash, count(*) FROM decisions "
                "GROUP BY tenant_id, prev_hash HAVING count(*) > 1"
            )
        ).all()
        indexes = {
            row[0]
            for row in owner.execute(
                text("SELECT indexname FROM pg_indexes WHERE tablename = 'decisions'")
            ).all()
        }
    finally:
        owner.close()

    assert not forks, f"a chain has already forked: {forks}"
    assert "ix_decisions_one_child_per_parent" in indexes, (
        "the unique index is gone — the lock in evidence.record is the only "
        "thing left, and one mechanism is one thing to forget"
    )
