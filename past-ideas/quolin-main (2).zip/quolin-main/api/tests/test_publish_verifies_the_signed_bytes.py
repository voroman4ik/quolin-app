"""What a signatory signed has to be what goes live under their name.

F4, reported independently by two reviewers.

`sign` records the bytes it was shown:

    draft.content_hash = content_hash(draft.body)

`publish` computes a hash of its own, over a body it has just mutated — the
allocated version, the signature block, the attested content status — and stores
that beside the pack row. **Nothing ever compared the two.** `publish` took
`status == SIGNED` as proof that the body in front of it was the body that was
signed.

`pack_drafts` is mutable working state by design, and the docstring on `publish`
says so. So a concurrent edit-and-sign, or any `UPDATE pack_drafts SET body =
...` from a shell, publishes bytes the signatory never saw — under their name,
their user id and their qualification reference. That reads as reviewed content
with a named specialist behind it, which is worse than unsigned content, because
unsigned content is refused to any acting firm and this is not.

`main.edit_draft` refuses on status alone and takes no row lock, so the window
is real rather than theoretical.

**The signed hash had nowhere permanent to live.** It sat on the mutable row it
was supposed to protect. Nothing append-only linked "these bytes were signed" to
"these bytes are live", so after the fact there was no way to check the claim
either. `pack_publications.signed_content_hash` is that link: an append-only
table, written at publication, beside the hash of what was published.

**The residual, which is not fixed here and must not be read as fixed.** The
signed hash still cannot be rebuilt from the published pack alone. The signed
body carries `version`, `signed_by`, `signed_at` and `content_status` as
inherited placeholders that `publish` overwrites, so `content_hash(published)`
can never equal `content_hash(signed)`. Making it rebuildable changes what a
signature covers and invalidates every `content_hash` on file. That is a
recorded decision for the project — see "Decisions requested" in
docs/spec-changes.md — and not something a fix pack settles.
"""

from __future__ import annotations

import json
from datetime import date, timedelta

import pytest
from conftest import publish_through_the_api, what_this_client_reads
from fastapi.testclient import TestClient
from sqlalchemy import select, text

from app import identity, tenancy, totp
from app.canonical import content_hash
from app.db import OwnerSessionLocal
from app.main import app
from app.models import MfaCredential, PackDraft, PackPublication
from app.models import Pack as PackRow
from seed.seed import SEED_PASSWORD
from tests.conftest import DEMO_TENANT, OPERATOR_EMAIL, sign_in

ACTOR = "apc_bulk_sweep"

#: Far enough out that these packs never become the one in force, so nothing
#: else in the suite starts deciding against them. `packs` is append-only, so a
#: published pack cannot be removed at teardown.
FAR_FUTURE = 3650

SIGNATORY_EMAIL = "aoife.brennan@quolin.example"


def _sign_in_signatory(client, email: str) -> None:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            user = identity.find_by_email(owner, email)
            assert user is not None
            credential = owner.scalars(
                select(MfaCredential).where(MfaCredential.user_id == user.id)
            ).first()
            assert credential is not None
            credential.last_used_counter = 0
            owner.commit()
            code = totp.code_at(str(credential.secret))
    finally:
        owner.close()

    res = client.post(
        "/auth/login", json={"email": email, "password": SEED_PASSWORD, "code": code}
    )
    assert res.status_code == 200, res.text


def _cut_draft(title: str) -> int:
    with TestClient(app) as operator:
        sign_in(operator, OPERATOR_EMAIL)
        res = operator.post(
            "/watch/drafts",
            json={
                "jurisdiction": "AU",
                "effective_from": (
                    date.today() + timedelta(days=FAR_FUTURE)
                ).isoformat(),
                "title": title,
                "rationale": "Written by tests/test_publish_verifies_the_signed_bytes.py",
            },
        )
    assert res.status_code == 200, res.text
    return int(res.json()["id"])


def _sign(draft_id: int) -> None:
    with TestClient(app) as signatory:
        _sign_in_signatory(signatory, SIGNATORY_EMAIL)
        # Read, then sign what was read. This file is about the window *after*
        # the signature — `SignedBytesChanged` — so the signature itself has to
        # be an ordinary honest one, which is a signatory looking at the draft
        # and sending back the hash of what they were shown.
        res = signatory.post(
            f"/watch/drafts/{draft_id}/sign",
            json={
                "note": "Reviewed.",
                "signed_content_hash": what_this_client_reads(signatory, draft_id),
            },
        )
    assert res.status_code == 200, res.text


def _publish(draft_id: int):
    """Publish over HTTP, with the second approval FP3-27 requires.

    `PUBLISHER_EMAIL` used to be enough. It holds `quolin_operator`, which is
    what lets somebody reach the endpoint, and no platform grant — so it reaches
    the endpoint and is refused the act, which is the whole of FP3-27 and is
    asserted directly in
    `test_publication_is_platform_scoped_with_dual_control.py`.
    """

    def _as(email: str):
        client = TestClient(app)
        client.__enter__()
        sign_in(client, email)
        return client

    return publish_through_the_api(_as, draft_id)


def _tamper(draft_id: int) -> None:
    """Change the body on the row, the way a shell or a racing edit would.

    Deliberately not through the API. `edit_draft` refuses a signed draft on
    status, which is the control this test is about going around — the point is
    that `pack_drafts` is ordinary mutable state and the status check is not a
    lock on the bytes.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            draft = owner.get(PackDraft, draft_id)
            assert draft is not None
            body = json.loads(json.dumps(draft.body))
            thresholds = dict(body["thresholds"])
            # A change a signatory would certainly have wanted to see: the
            # concentration cap loosened by a factor of five.
            thresholds["max_crypto_concentration_bps"] = 5_000
            body["thresholds"] = thresholds
            owner.execute(
                text("UPDATE pack_drafts SET body = CAST(:body AS jsonb) WHERE id = :id"),
                {"body": json.dumps(body), "id": draft_id},
            )
            owner.commit()
    finally:
        owner.close()


def _packs_in(jurisdiction: str) -> set[int]:
    owner = OwnerSessionLocal()
    try:
        return {
            row.id
            for row in owner.scalars(
                select(PackRow).where(PackRow.jurisdiction == jurisdiction)
            )
        }
    finally:
        owner.close()


def test_a_draft_edited_after_signature_is_refused_at_publication() -> None:
    """The finding: the bytes that went live were not the bytes that were signed."""
    draft_id = _cut_draft("Signed bytes, then changed underneath")
    _sign(draft_id)
    before = _packs_in("AU")

    _tamper(draft_id)

    res = _publish(draft_id)

    assert res.status_code == 409, (
        f"a draft whose body changed after signature published anyway: "
        f"{res.status_code} {res.text}. Those bytes are now live rule content "
        "under a named specialist's signature and qualification reference."
    )
    assert "sign" in res.text.lower()

    assert _packs_in("AU") == before, (
        "a pack row was created despite the refusal — nothing may reach `packs`"
    )

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            draft = owner.get(PackDraft, draft_id)
            assert draft.published_pack_id is None
            assert draft.status == "signed", (
                "the draft moved out of `signed` on a refused publication"
            )
    finally:
        owner.close()


def test_an_untouched_draft_publishes_and_records_both_hashes() -> None:
    """The other half: the check must not refuse the ordinary case.

    And the attestation is recorded where it can be checked afterwards — in
    `pack_publications`, which is append-only, beside the hash of what was
    actually published.
    """
    draft_id = _cut_draft("Signed bytes, published unchanged")
    _sign(draft_id)

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            signed_hash = owner.get(PackDraft, draft_id).content_hash
    finally:
        owner.close()
    assert signed_hash, "signing recorded no hash of the bytes it was shown"

    res = _publish(draft_id)
    assert res.status_code == 200, res.text
    pack_id = int(res.json()["pack_id"])

    owner = OwnerSessionLocal()
    try:
        published = owner.get(PackRow, pack_id)
        record = owner.get(PackPublication, pack_id)
        assert published is not None and record is not None

        assert record.signed_content_hash == signed_hash, (
            "the publication record does not carry the hash of the bytes that "
            "were signed, so the attestation cannot be checked after the fact"
        )
        assert record.content_hash == published.content_hash
        assert record.content_hash, "no hash of what was published"
    finally:
        owner.close()


def test_the_two_hashes_are_deliberately_different() -> None:
    """The residual, asserted so nobody reads this fix as more than it is.

    `publish` overwrites `version`, `signed_by`, `signed_at` and
    `content_status` in the body before hashing it, so the published hash cannot
    equal the signed one. That means the signed hash is still not rebuildable
    from the published pack alone: it can be *compared*, which is what this fix
    buys, but not *recomputed* by a third party holding only the pack.

    Making it rebuildable changes what a signature covers and invalidates every
    content_hash on file. Recorded as a decision, not fixed here.
    """
    draft_id = _cut_draft("Signed and published hashes differ")
    _sign(draft_id)

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            signed_hash = owner.get(PackDraft, draft_id).content_hash
    finally:
        owner.close()

    res = _publish(draft_id)
    assert res.status_code == 200, res.text
    pack_id = int(res.json()["pack_id"])

    owner = OwnerSessionLocal()
    try:
        published = owner.get(PackRow, pack_id)
        assert content_hash(published.body) == published.content_hash, (
            "the published hash does not describe the published body"
        )
        assert published.content_hash != signed_hash, (
            "the two hashes now agree, which would mean publish no longer "
            "rewrites the signature block — if that is deliberate, the "
            "rebuildability decision has been taken and this test should say so"
        )
    finally:
        owner.close()


def test_publication_records_already_on_file_are_left_alone(session) -> None:
    """The new column is additive: nothing existing is rewritten.

    `pack_publications` is append-only, so a migration that backfilled it would
    have had to go around the trigger. It does not, and the rows the seed wrote
    keep a null `signed_content_hash` — which is the honest answer, because
    nobody recorded one at the time.
    """
    rows = list(session.scalars(select(PackPublication)))
    assert rows, "no publication records at all — run `make seed`"
    for row in rows:
        assert row.content_hash, f"publication {row.pack_id} lost its content hash"


@pytest.mark.parametrize("attempt", [1, 2])
def test_the_refusal_is_repeatable(attempt: int) -> None:
    """A refused publication leaves the draft publishable once corrected.

    A check that refused and also wedged the draft would push somebody towards
    the database to unstick it, which is the path this whole workflow exists to
    close.
    """
    draft_id = _cut_draft(f"Refused then corrected {attempt}")
    _sign(draft_id)
    _tamper(draft_id)

    assert _publish(draft_id).status_code == 409

    # Re-signing over the changed bytes is the correction: a specialist looks at
    # what the body now says and attests to it.
    _sign_again(draft_id)

    res = _publish(draft_id)
    assert res.status_code == 200, (
        f"a draft re-signed over its current bytes was still refused: {res.text}"
    )


def _sign_again(draft_id: int) -> None:
    """Re-sign a draft that is already `signed`.

    `sign` refuses anything outside DRAFT/IN_REVIEW, so the correction path is
    to put it back for review first — which is what a specialist looking at
    changed content would be doing anyway.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            owner.execute(
                text("UPDATE pack_drafts SET status = 'in_review' WHERE id = :id"),
                {"id": draft_id},
            )
            owner.commit()
    finally:
        owner.close()
    _sign(draft_id)
