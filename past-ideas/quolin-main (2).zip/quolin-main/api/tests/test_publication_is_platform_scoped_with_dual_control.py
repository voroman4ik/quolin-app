"""FP3-27: a global capability was authorised by a tenant-local row.

`quolin_operator` is the role that may publish. It is granted through
`user_roles`, which is **tenant-scoped** — the grant belongs to one firm and is
filtered by that firm's row-level security. `POST
/watch/drafts/{draft_id}/publish` writes to `packs`, which is **global**: the
same AU content governs every customer on the platform.

So compromise of a single firm's role set — or of anybody able to write one —
reached every other firm's regulatory content. Q-12 saw that publishing is
Quolin's act rather than a customer's and expressed it as "a role only we
grant"; the storage never caught up with the reasoning, and a role is a row.

The test the finding asks for is `test_a_tenants_entire_role_set_cannot_publish`:
every role, granted in one tenant, and none of it reaches the act.
"""

from __future__ import annotations

import json
import secrets
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

import pytest
from conftest import (
    DEMO_TENANT,
    PUBLISHER_EMAIL,
    reset_rate_limit_for_tests,
    sign_in,
    the_bytes_on_the_row,
)
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import identity, tenancy
from app.db import OwnerSessionLocal
from app.main import app
from app.models import PlatformPublisher, PublicationApproval, User
from app.watch import drafts as drafts_module

#: The two named humans the seed grants platform publication to.
FOUNDER = "volodymyr.romanenko@quolin.example"
SECOND = "su-lee.oei@quolin.example"

#: Every role a tenant can grant. If a new one is added and is not here, the
#: first test below stops covering it — so it is derived rather than typed.
from app.rbac import ROUTE_ROLES  # noqa: E402

TENANT_ROLES = sorted({role for roles in ROUTE_ROLES.values() for role in roles})


def _user(email: str) -> User:
    with OwnerSessionLocal() as s:
        row = s.scalars(select(User).where(User.email == email)).one()
        s.expunge(row)
        return row


@contextmanager
def _a_signed_draft(*, commit: bool = False):
    """A draft in `signed`, manufactured rather than found.

    Tier 2's rule: "the condition under test is absent" is neither a reason to
    skip nor a reason to fail. The seed publishes its only signed draft, so both
    tests below used to vanish on a freshly seeded database — which is every
    database.

    Rolled back afterwards. `commit=True` is for the one test that drives the
    HTTP route, which needs the row visible to another connection; its draft is
    left behind in `signed`, which is a state the workbench already shows and
    nothing else reads.
    """
    from app.models import PackDraft

    owner = OwnerSessionLocal()
    transaction = None if commit else owner.begin()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            signer = owner.scalars(
                select(User).where(User.email == "aoife.brennan@quolin.example")
            ).one()
            # The body comes from a shipped pack, not from "the newest draft".
            #
            # The first version copied the latest `pack_drafts` row, and in a
            # full run that is whichever draft another test most recently made
            # deliberately malformed — `test_publish_verifies_the_signed_bytes`
            # writes `effective_from: 'not-a-date'` on purpose. The publish
            # route validates the body before it reaches the platform check, so
            # this test got a 422 about the pack instead of the 403 it exists
            # for, and only ever in a full run.
            body = json.loads(
                (Path(__file__).resolve().parents[2] / "packs" / "au_v2.json").read_text()
            )
            template = owner.scalars(
                select(PackDraft).order_by(PackDraft.id.desc())
            ).first()
            assert template is not None, "no pack draft in the seed to copy"

            draft = PackDraft(
                jurisdiction=body["pack_id"],
                base_version=int(body["version"]),
                proposed_version=int(body["version"]) + 90,
                effective_from=template.effective_from,
                title="FP3-27 probe",
                rationale="Manufactured so the dual-control tests do not skip.",
                body=body,
                event_ids=[],
                status="signed",
                signed_by="Aoife Brennan",
                signature_note="probe",
                created_at=datetime.now(timezone.utc),
                signed_at=datetime.now(timezone.utc),
                # Authored by somebody other than its signatory, which migration
                # 0049 requires of every row and this probe would otherwise not
                # have said anything about. Constructed directly rather than
                # through `drafts.create` — the shape under test is a draft
                # already in `signed`, and the point of this file is what
                # happens *after* that.
                created_by="An Operator",
                created_by_user_id="usr_dual_control_probe",
            )
            draft.signed_by_user_id = signer.id
            owner.add(draft)
            owner.flush()
            if commit:
                owner.commit()
            yield owner, draft, signer.id
    finally:
        if transaction is not None:
            transaction.rollback()
        owner.close()


def test_the_seeded_publishers_are_the_two_named_humans():
    """Named individuals, not the engineering role and not a service account.

    Asserted because the point of the list is who is on it. A platform grant
    that quietly acquired a third holder would be the finding again.
    """
    with OwnerSessionLocal() as s:
        held = {
            row.email
            for row in s.scalars(
                select(User).join(
                    PlatformPublisher, PlatformPublisher.user_id == User.id
                )
            )
        }

    # `@quolin.test` is the suite's own synthetic domain — `conftest.
    # a_platform_publisher` mints those so that tests which publish can. Real
    # accounts are `@quolin.example`, which is what the seed and any deployment
    # use, and the claim is about those.
    #
    # Excluded rather than the assertion loosened: "the two named humans, plus
    # whatever the tests made" is still a precise statement, and it is the one
    # that would notice a third real person acquiring the grant.
    real = {email for email in held if not email.endswith("@quolin.test")}
    assert real == {FOUNDER, SECOND}, (
        f"platform publication is held by {sorted(real)}"
    )


def test_a_tenants_entire_role_set_cannot_publish():
    """The finding, stated as the finding states it.

    Somebody holding **every** role a tenant can grant, granted inside that
    tenant, and none of it reaches publication. Before FP3-27 `quolin_operator`
    alone did.
    """
    email = f"fp3-27-everything-{secrets.token_hex(6)}@quolin.example"

    # Rolled back rather than committed, and not for tidiness: somebody holding
    # every role at once *is* a separation-of-duties conflict, and
    # `access_review.py` is right to say so. Committing this made
    # `test_access_review.py::test_a_planted_conflict_is_found_against_the_real_
    # database` fail — the review finding its own planted conflict plus mine.
    #
    # A test that plants a permanent conflict to prove a point about a different
    # control is a test that breaks the control that notices conflicts.
    owner = OwnerSessionLocal()
    transaction = owner.begin()
    try:
        person = identity.create_user(
            owner, email=email, display_name="Holds everything"
        )
        owner.flush()
        with tenancy.acting_as(DEMO_TENANT):
            for role in TENANT_ROLES:
                identity.grant_role(
                    owner,
                    user_id=person.id,
                    role=role,
                    jurisdiction="AU" if role == "pack_signatory" else "",
                    granted_by="fp3-27-test",
                )
        owner.flush()

        assert not drafts_module.is_platform_publisher(owner, person.id), (
            "somebody holding every role a tenant can grant also holds platform "
            "publication — which is the finding: a global capability conferred "
            "by a tenant-local row"
        )
    finally:
        transaction.rollback()
        owner.close()


def test_a_tenant_scoped_grant_cannot_create_a_platform_grant():
    """`platform_publishers` has no `tenant_id`, and that is the control.

    A table with no tenant column cannot be written by a tenant-scoped write,
    and there is nothing for a compromised firm's role set to say. Asserted
    against the schema rather than against a comment, because the absence is
    what does the work.
    """
    from sqlalchemy import inspect

    from app.db import owner_engine

    columns = {c["name"] for c in inspect(owner_engine).get_columns("platform_publishers")}
    assert "tenant_id" not in columns, (
        "platform_publishers grew a tenant_id, so a tenant-scoped policy now "
        "governs a platform-wide capability"
    )


def test_the_application_role_cannot_mint_a_platform_publisher():
    """Minting one is an owner operation, at the same bar as a migration.

    Made to happen rather than reasoned about: the application's own connection
    attempts the insert and must be refused.
    """
    from sqlalchemy import text
    from sqlalchemy.exc import DBAPIError

    from app.db import engine

    with engine.begin() as conn:
        with pytest.raises(DBAPIError, match="permission denied"):
            conn.execute(
                text(
                    "INSERT INTO platform_publishers (user_id, note, granted_at) "
                    "VALUES ('usr_probe', 'x', now())"
                )
            )


def test_there_is_no_route_that_grants_platform_publication():
    """Deliberately absent, and asserted so it stays that way.

    A route would put the platform's most consequential capability behind
    whatever that route's own RBAC said — which is exactly the indirection
    FP3-27 is about.
    """
    paths = {getattr(route, "path", "") for route in app.routes}
    offenders = [p for p in paths if "platform" in p and "publisher" in p]
    assert not offenders, (
        f"a route now grants or edits platform publication: {offenders}. It is "
        "an owner operation on purpose."
    )


def test_publication_needs_two_approvers():
    """One compromised account cannot publish, and neither can one plus a
    signature it also holds."""
    assert drafts_module.REQUIRED_APPROVALS == 2


def test_the_required_count_is_not_configurable(monkeypatch):
    """A number in a settings table is a number somebody sets to one.

    The whole value of dual control is that it cannot be relaxed by whoever is
    in a hurry.

    Asserted by *trying* rather than by reading the source — Rule A, which this
    fix-pack wrote. Every plausible spelling of the variable is set and the
    module is reimported; the answer must still be two.
    """
    import importlib

    for name in (
        "QUOLIN_REQUIRED_APPROVALS",
        "QUOLIN_PUBLICATION_APPROVALS",
        "REQUIRED_APPROVALS",
        "QUOLIN_DUAL_CONTROL",
    ):
        monkeypatch.setenv(name, "1")

    reloaded = importlib.reload(drafts_module)
    try:
        assert reloaded.REQUIRED_APPROVALS == 2, (
            "the approval count moved when an environment variable was set, so "
            "dual control can be switched off by whoever is deploying"
        )
    finally:
        monkeypatch.undo()
        importlib.reload(drafts_module)


def test_the_seeded_publication_was_approved_by_a_second_person():
    """The demo data is built the way a real publication happens.

    The seed used to publish as the tenant administrator, through a direct call
    that no API route can make. A demo whose evidence was produced by a path
    nothing takes is showing a system that does not exist.
    """
    with OwnerSessionLocal() as s:
        approvals = list(s.scalars(select(PublicationApproval)))
    assert approvals, "no seeded publication carries a second approval"

    approver_ids = {a.approved_by for a in approvals}
    with OwnerSessionLocal() as s:
        publishers = {
            row.user_id for row in s.scalars(select(PlatformPublisher))
        }
    assert approver_ids <= publishers, (
        "a publication was approved by somebody without platform publication"
    )


def test_an_approver_may_not_be_the_signer():
    """A signatory approving their own content is one person agreeing with
    themselves, which is what the second pair of eyes exists to prevent."""
    assert issubclass(drafts_module.SelfReview, Exception)

    with _a_signed_draft() as (s, draft, signer_id):
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(signer_id):
            # The signer is not a platform publisher, so this raises on the
            # platform check — which is itself the right refusal, and either
            # exception means the second pair of eyes held.
            with pytest.raises(
                (drafts_module.SelfReview, drafts_module.NotAPlatformPublisher)
            ):
                drafts_module.approve_publication(
                    s,
                    draft.id,
                    approved_content_hash=the_bytes_on_the_row(s, draft),
                )


def test_the_publish_route_refuses_somebody_without_the_platform_grant():
    """End to end: `quolin_operator` in a tenant is no longer enough.

    The seeded `sofia.marchetti` holds `quolin_operator` and is deliberately
    *not* a platform publisher, so she is the exact account the finding is
    about — able to reach the endpoint, not able to perform the act.
    """
    with _a_signed_draft(commit=True) as (_s, draft, _signer):
        draft_id = draft.id

        # A second approval is recorded first, so the refusal below can only be
        # about the platform grant. Without it the route would refuse for
        # `NeedsASecondApprover` and this would pass while testing nothing.
        with OwnerSessionLocal() as owner:
            with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(
                _user(SECOND).id
            ):
                drafts_module.approve_publication(
                    owner,
                    draft_id,
                    approved_content_hash=the_bytes_on_the_row(owner, draft_id),
                )
                owner.commit()

        # The address counter is shared across the whole suite, and by the time
        # this runs in a full pass it has seen every deliberate failure every
        # other file produced. Cleared here so a 429 cannot be mistaken for the
        # 403 under test — which is what happened, and only in the full run.
        reset_rate_limit_for_tests()

        with TestClient(app) as c:
            operator = sign_in(c, PUBLISHER_EMAIL)
            # A truthful hash, so the refusal under test is the platform grant
            # rather than a 422 about the field the census made required.
            refused = operator.post(
                f"/watch/drafts/{draft_id}/publish",
                json={
                    "published_content_hash": the_bytes_on_the_row(None, draft_id)
                },
            )

    assert refused.status_code == 403, (
        f"an account holding quolin_operator in a tenant, and no platform "
        f"grant, published global rule content: {refused.status_code} "
        f"{refused.text}"
    )
    assert "platform publication" in refused.text
