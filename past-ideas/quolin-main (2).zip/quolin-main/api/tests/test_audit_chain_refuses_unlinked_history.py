"""Two gaps in what the evidence chain actually guarantees.

**An unlinked row was not a failure.** `verify_audit_chain` walks the tenant's
audit trail and skips any row carrying an empty `this_hash`, counting it as
"unlinked" and continuing. That is right for the rows it was written for: two
tenants created by migration never went through `ensure_anchor`, and their early
audit rows are outside the guarantee until `make rechain` links them. Saying
"unverified" about those is the honest answer.

It is wrong for everything after. Once a chain has started, an unlinked row is
not history that predates the mechanism — it is a row inserted past the point
where the mechanism applies, and skipping it means an attacker who can write to
`audit_events` can insert whatever they like by leaving one column empty. The
verification then reports `verified: True` over invented history.

So: unlinked rows are permitted only *before* the first chained row. After that,
one is a break. The count is still reported separately, because "we verified 40
of 1200 rows" and "we verified 1200 rows" are different sentences.

**And attribution.** `decisions.decided_by` sits outside the decision hash by
design — invariant 2 says the frozen snapshot is the only input to a
determination, and the operator is not one. Widening the hash to cover it would
make the person part of the determination, which is the wrong fix. What was
never asserted is that the attribution is chained *somewhere*: the audit event
for the determination carries the acting person, and that event is chained, so
the two together are as tamper-evident as the decision itself. This file states
that relationship rather than leaving it as a coincidence of two functions
reading the same context variable.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import select, text

from app import evidence, service, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.models import AuditEvent
from tests.conftest import DEMO_TENANT

ACTOR = "apc_bulk_sweep"


def _verify() -> dict:
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            return dict(evidence.verify_audit_chain(session))
        finally:
            session.close()


def _insert_raw(**columns) -> int:
    """Write an audit row past the application, the way an attacker would.

    As the owner, because the application role holds INSERT and the trigger
    forbids UPDATE — an inserted row is the shape of the attack this is about,
    and it has to be inserted the way one would be.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            keys = ", ".join(columns)
            values = ", ".join(f":{k}" for k in columns)
            row_id = owner.execute(
                text(f"INSERT INTO audit_events ({keys}) VALUES ({values}) RETURNING id"),
                columns,
            ).scalar()
            owner.commit()
            return int(row_id)
    finally:
        owner.close()


def _delete_raw(row_id: int) -> None:
    """Remove a planted row. Needs the trigger down, which is why this is a test."""
    owner = OwnerSessionLocal()
    try:
        owner.execute(text("ALTER TABLE audit_events DISABLE TRIGGER audit_events_append_only"))
        owner.execute(text("DELETE FROM audit_events WHERE id = :id"), {"id": row_id})
        owner.execute(text("ALTER TABLE audit_events ENABLE TRIGGER audit_events_append_only"))
        owner.commit()
    finally:
        owner.close()


# --------------------------------------------------------- unlinked history --


def test_the_chain_verifies_to_begin_with() -> None:
    """The baseline everything below rests on."""
    result = _verify()
    assert result["verified"] is True, result
    assert result["checked"] > 0, "nothing was checked; these tests prove nothing"


def test_an_unlinked_row_inserted_after_the_tip_fails_verification() -> None:
    """The finding, directly.

    A row with an empty `this_hash`, written after the chain has started, is not
    history that predates the mechanism. It is history inserted past the point
    where the mechanism applies — and it was being skipped, so the verifier
    reported success over it.
    """
    before = _verify()
    assert before["verified"] is True

    planted = _insert_raw(
        tenant_id=DEMO_TENANT,
        actor="somebody-who-was-never-here",
        action="override.approve",
        subject="a thing that did not happen",
        at=datetime.now(timezone.utc),
        prev_hash="",
        this_hash="",
    )
    try:
        after = _verify()
        assert after["verified"] is False, (
            "an unlinked audit row inserted after the chain tip was skipped and "
            "the chain reported as verified. Anybody who can write to "
            "`audit_events` can insert history by leaving one column empty."
        )
        assert after.get("broken_at_audit_id") == planted, after
    finally:
        _delete_raw(planted)

    assert _verify()["verified"] is True, "the planted row was not cleaned up"


def test_the_unlinked_count_is_still_reported_separately() -> None:
    """The honest half of the old behaviour is kept.

    "We verified 40 of 1200 rows" and "we verified 1200 rows" are different
    sentences, and an auditor is entitled to the first one.
    """
    result = _verify()
    assert "unlinked" in result
    assert isinstance(result["unlinked"], int)


def test_a_tampered_row_still_fails_the_way_it_always_did() -> None:
    """The pre-existing guarantee, unchanged by the above.

    Asserted here because the fix touches the loop that produces it: a change
    that made unlinked rows fail while quietly stopping *edited* rows from
    failing would trade one hole for a worse one.
    """
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            row = session.scalars(
                select(AuditEvent)
                .where(AuditEvent.this_hash != "")
                .order_by(AuditEvent.id.desc())
                .limit(1)
            ).one()
            original_actor = row.actor
            recomputed = evidence.chain_hash(
                row.prev_hash, evidence._audit_payload(row)
            )
            assert recomputed == row.this_hash, "the row does not verify to begin with"

            row.actor = "somebody else entirely"
            assert (
                evidence.chain_hash(row.prev_hash, evidence._audit_payload(row))
                != row.this_hash
            ), (
                "changing who did something did not change the hash. Attribution "
                "is not covered by the chain."
            )
            row.actor = original_actor
        finally:
            session.rollback()
            session.close()


# ------------------------------------------------------------- attribution --


def test_a_determination_is_attributed_in_a_row_that_is_chained() -> None:
    """`decided_by` is outside the decision hash, and that is right.

    Invariant 2: the frozen snapshot is the only input to a determination, and
    the operator is not one. Widening the decision hash to cover them would make
    the person part of what was decided, and would rehash every determination on
    file to do it.

    What has to be true instead is that the attribution is chained *somewhere*.
    It is: the audit event written alongside the determination carries the
    acting person, and that event is hash-chained. This states the relationship,
    which was previously a coincidence of two functions reading the same context
    variable.
    """
    from app.models import Asset, Client

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            asset = session.scalars(select(Asset)).first()
            client = session.scalars(
                select(Client).where(Client.is_cast.is_(True)).limit(1)
            ).first()
            assert asset is not None and client is not None
            decision = service.evaluate(
                session, client_id=client.id, asset_id=asset.id
            )
            session.commit()
            decision_id = decision.id
            decided_by = decision.decided_by

            event = session.scalars(
                select(AuditEvent)
                .where(AuditEvent.action == "decision.evaluate")
                .where(AuditEvent.subject == f"decision:{decision_id}")
            ).one()
        finally:
            session.close()

    assert decided_by, "the determination names nobody"
    assert event.actor == decided_by, (
        f"the determination says {decided_by!r} decided it and its audit event "
        f"says {event.actor!r}. Attribution is only chained if the two agree."
    )
    assert event.this_hash, "the attributing event is not chained"
    assert evidence.chain_hash(event.prev_hash, evidence._audit_payload(event)) == (
        event.this_hash
    )


def test_the_decision_hash_still_does_not_cover_the_operator() -> None:
    """Invariant 2, asserted from the other side.

    A later change that quietly folded `decided_by` into the payload would
    rehash every determination on file, and this is what would say so.
    """
    payload = evidence._hashable(
        tenant_id=DEMO_TENANT,
        client_id="c",
        asset_id="a",
        as_of=datetime.now(timezone.utc).date(),
        pack_id="AU",
        pack_version=2,
        snapshot={},
        rule_results={},
        resolution=None,
        outcome="ALLOW",
        created_at=datetime.now(timezone.utc),
        schema=2,
        execution_manifest=None,
    )
    assert "decided_by" not in payload
    assert "actor" not in payload
    assert timedelta is not None


@pytest.mark.parametrize("column", ("actor", "action", "subject"))
def test_every_field_of_an_audit_event_is_covered_by_its_hash(column) -> None:
    """A field outside the hash is a field somebody can change.

    Checked field by field rather than by reading `_audit_payload`, because the
    thing worth knowing is that no column of this table is unprotected — and a
    column added next year is what this catches.
    """
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            row = session.scalars(
                select(AuditEvent)
                .where(AuditEvent.this_hash != "")
                .order_by(AuditEvent.id.desc())
                .limit(1)
            ).one()
            before = evidence.chain_hash(row.prev_hash, evidence._audit_payload(row))
            setattr(row, column, f"tampered-{column}")
            after = evidence.chain_hash(row.prev_hash, evidence._audit_payload(row))
        finally:
            session.rollback()
            session.close()

    assert before != after, f"{column} is not covered by the audit event hash"
