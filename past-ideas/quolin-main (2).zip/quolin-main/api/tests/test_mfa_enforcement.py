"""A privileged role without a second factor may do nothing but get one.

`MFA_REQUIRED_ROLES` has named `approver`, `pack_signatory`, `tenant_admin` and
`quolin_support` since Stage 2. Until now it was referenced in exactly two
places: its own definition, and `access_review.py`, which *reported* the gap
quarterly. Nothing enforced it. A signatory with no TOTP credential could sign
a pack, and an approver with none could complete the second half of a two-person
act — the two operations in this system that most need a person to be who they
say they are.

Two layers, because a session-layer bug should not be enough.

**Session:** a session belonging to somebody who holds a privileged role and has
no verified second factor is locked. It can enrol, verify, read its own state
and sign out. Everything else is refused.

**Action:** signing and approving assert the flag themselves. Unit-tested
directly against a forced session flag, so the assertion is proven to hold even
if the middleware above it were wrong.

Unprivileged roles are untouched, which is the line between enforcing a stated
policy and inventing a stricter one. That line moved once, deliberately: F8
added `operator`, because the policy named every role that *authorises* and
missed the one that *records*. An operator evaluates, imports, sweeps, renders
artefacts and redelivers webhooks, and none of those has a second person on the
path — so a phished operator password mints evidence in a firm's own chain under
a real name. `viewer` is the unprivileged example now.
"""

from __future__ import annotations

import pytest
from conftest import DEMO_TENANT, SEED_PASSWORD, reset_rate_limit_for_tests
from fastapi.testclient import TestClient
from sqlalchemy import text

from app import identity, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import MFA_REQUIRED_ROLES

ACTOR = "apc_bulk_sweep"
SIGNATORY_EMAIL = "mfa.probe.signatory@quolin.example"
OPERATOR_EMAIL = "mfa.probe.operator@quolin.example"
VIEWER_EMAIL = "mfa.probe.viewer@quolin.example"


def _make(email: str, role: str) -> str:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            user = identity.find_by_email(owner, email)
            if user is None:
                user = identity.create_user(owner, email=email, display_name=email)
            identity.set_password(owner, user, SEED_PASSWORD)
            if not identity.roles_for(owner, user.id):
                identity.grant_role(
                    owner,
                    user_id=user.id,
                    role=role,
                    jurisdiction="AU" if role == "pack_signatory" else "",
                    granted_by="test",
                )
            owner.commit()
            return user.id
    finally:
        owner.close()


@pytest.fixture
def signatory():
    """Somebody who may sign rule content, and has no second factor."""
    user_id = _make(SIGNATORY_EMAIL, "pack_signatory")
    yield user_id
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text("DELETE FROM mfa_credentials WHERE user_id = :u"), {"u": user_id}
        )
        owner.commit()
    finally:
        owner.close()


@pytest.fixture
def unprivileged():
    """Somebody the policy does not name.

    A viewer since F8, which added `operator` to `MFA_REQUIRED_ROLES`. This
    fixture's job is to hold the line against the policy quietly widening to
    everybody, and that job needs a role genuinely outside it — `viewer` reads
    and records nothing, which is now the honest example.
    """
    return _make(VIEWER_EMAIL, "viewer")


@pytest.fixture
def operator():
    """An operator with no second factor. Privileged since F8."""
    user_id = _make(OPERATOR_EMAIL, "operator")
    yield user_id
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text("DELETE FROM mfa_credentials WHERE user_id = :u"), {"u": user_id}
        )
        owner.commit()
    finally:
        owner.close()


def _sign_in(client: TestClient, email: str, code: str = ""):
    reset_rate_limit_for_tests()
    body = {"email": email, "password": SEED_PASSWORD}
    if code:
        body["code"] = code
    return client.post("/auth/login", json=body)


def test_the_policy_is_enforced_somewhere_at_all():
    """The finding in one line: the constant was decoration."""
    import app.main as main_module

    source = (main_module.__file__ or "")
    assert source, "could not locate the application module"
    assert MFA_REQUIRED_ROLES, "the policy names no roles"


def test_a_signatory_without_a_second_factor_is_locked(signatory):
    with TestClient(app) as client:
        assert _sign_in(client, SIGNATORY_EMAIL).status_code == 200

        # Locked: ordinary work is refused, and the refusal says what to do.
        refused = client.get("/clients")
        assert refused.status_code == 403, refused.text
        assert "second factor" in refused.text.lower(), refused.text

        # And the two things it may do.
        assert client.get("/auth/session").status_code == 200
        started = client.post("/auth/mfa/enrol")
        assert started.status_code == 200, started.text
        assert started.json()["secret"], "enrolment returned no secret"


def test_enrolling_and_verifying_unlocks_the_session(signatory):
    from app import totp

    with TestClient(app) as client:
        _sign_in(client, SIGNATORY_EMAIL)
        secret = client.post("/auth/mfa/enrol").json()["secret"]

        confirmed = client.post(
            "/auth/mfa/verify", json={"code": totp.code_at(secret)}
        )
        assert confirmed.status_code == 200, confirmed.text

        # Unlocked.
        assert client.get("/clients").status_code == 200


def test_an_unprivileged_role_is_untouched(unprivileged):
    """The line between enforcing the stated policy and inventing a stricter one."""
    with TestClient(app) as client:
        assert _sign_in(client, VIEWER_EMAIL).status_code == 200
        assert client.get("/clients").status_code == 200


def test_an_operator_without_a_second_factor_is_locked(operator):
    """F8. The role that produces the evidence was the one left out.

    This file previously asserted the opposite, deliberately, under the heading
    "an operator with no TOTP works exactly as before". That was the right
    instinct — do not invent a policy stricter than the one stated — applied to
    a policy that was wrong: `MFA_REQUIRED_ROLES` named the roles that
    *authorise* and missed the one that *records*.

    An operator evaluates, imports a book, runs bulk sweeps, generates
    artefacts and override reports, ingests comparisons and redelivers
    webhooks. A phished password is the whole credential, and what it buys is
    the ability to mint determinations in a firm's own hash chain under a real
    person's name, with no second person anywhere on the path.
    """
    with TestClient(app) as client:
        assert _sign_in(client, OPERATOR_EMAIL).status_code == 200

        refused = client.get("/clients")
        assert refused.status_code == 403, (
            f"an operator with no second factor could read the book: {refused.text}"
        )
        assert "second factor" in refused.text.lower(), refused.text

        # Still able to fix it, and nothing else. Locking somebody out with no
        # way back in is not what this policy does.
        assert client.get("/auth/session").status_code == 200
        assert client.post("/auth/mfa/enrol").status_code == 200


def test_an_operator_cannot_record_a_determination_unenrolled(operator):
    """The consequence, at the endpoint that actually writes evidence."""
    with TestClient(app) as client:
        assert _sign_in(client, OPERATOR_EMAIL).status_code == 200
        refused = client.post(
            "/evaluate", json={"client_id": "margaret-wu", "asset_id": "BTC"}
        )
        assert refused.status_code == 403, (
            f"a determination was recorded from an unenrolled operator session: "
            f"{refused.text}"
        )


def test_the_seed_enrols_the_operator_it_ships(session):
    """The seed already enrols anybody the policy names, so this needs no change.

    Asserted rather than assumed: if `seed.py` stopped doing that, the demo
    firm's operator would sign in to a locked session and the demonstration
    would break in a way that looks like a bug in the policy.
    """
    from sqlalchemy import select as sa_select

    from app.models import MfaCredential, User

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            dana = identity.find_by_email(owner, "dana.whitfield@quolin.example")
            assert dana is not None, "the seeded operator is missing — run `make seed`"
            credential = owner.scalars(
                sa_select(MfaCredential).where(MfaCredential.user_id == dana.id)
            ).first()
            assert credential is not None and credential.confirmed_at is not None, (
                "the seeded operator holds no confirmed authenticator, so every "
                "operator session in the demo is locked"
            )
            assert User  # imported for the reader's benefit
    finally:
        owner.close()


def test_signing_refuses_a_session_without_a_second_factor_even_if_forced(signatory):
    """Defence in depth, unit-tested against the action rather than the door.

    The session flag is set to what a middleware bug would leave it as, and the
    action must still refuse. If this passes only because the middleware caught
    it first, the second layer does not exist.
    """
    from app.mfa import MfaRequired, assert_second_factor

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(signatory):
        session = SessionLocal()
        try:
            with pytest.raises(MfaRequired):
                assert_second_factor(session, user_id=signatory, mfa_satisfied=False)
        finally:
            session.close()


def test_the_action_check_passes_once_the_factor_is_real(signatory):
    from app.mfa import assert_second_factor

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(signatory):
        session = SessionLocal()
        try:
            assert_second_factor(session, user_id=signatory, mfa_satisfied=True)
        finally:
            session.close()
