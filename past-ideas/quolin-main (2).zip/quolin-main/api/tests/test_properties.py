"""Properties that must hold for every pack and every snapshot, not just ours.

The tests elsewhere assert what the engine does with the inputs we thought of.
These assert what it does with the inputs we did not — which is the difference
between "our examples pass" and "we understand the engine", and it is the
question a technical diligence team is actually asking when they ask why they
should trust a homemade rules engine.

Four properties, each of which would be a serious defect if it failed:

* **Determinism.** The same pack and snapshot always give the same answer, and
  the same evidence. Without this, invariant 5 is unenforceable — replay would
  be comparing a result against a coin flip.
* **Order independence.** Shuffling a pack's rules changes nothing. This is what
  makes the result explainable: every failing rule stands on its own, so no
  reader has to reason about which rule ran first.
* **No floats, under adversarial content.** A pack carrying a decimal number is
  refused rather than producing a determination that will not reproduce.
* **Resolver commutativity.** Cross-border resolution gives the same answer
  whichever order the regimes arrive in — because the order they arrive in is an
  implementation detail of a dictionary, and a determination must not depend on
  one.

The execution document asks for determinism over 10,000 random pairs. That
number runs in the nightly job; the per-commit run is smaller, because a suite
somebody switches off because it takes four minutes proves nothing. See
`profiles` below.
"""

from __future__ import annotations

import copy
import json
import os
import random
from pathlib import Path

import pytest
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st
from strategies import packs, packs_with_floats, snapshots

from app.engine import Pack, PackError, evaluate_snapshot, validate

PACKS = Path(__file__).resolve().parents[2] / "packs"

#: Two speeds, one suite. The per-commit profile is sized so the whole property
#: file stays under a couple of seconds; `QUOLIN_PROPERTY_EXAMPLES` raises it for
#: the nightly run, which is where the execution document's 10,000 lives.
#: Environment rather than a marker, so the nightly job changes a variable rather
#: than a command line nobody can find later.
EXAMPLES = int(os.getenv("QUOLIN_PROPERTY_EXAMPLES", "60"))

settings.register_profile(
    "quolin",
    max_examples=EXAMPLES,
    deadline=None,  # a slow first example is fontconfig, not the engine
    suppress_health_check=[HealthCheck.too_slow, HealthCheck.data_too_large],
)
settings.load_profile("quolin")


# ------------------------------------------------------------- determinism --


@given(body=packs(), snapshot=snapshots())
def test_the_same_inputs_always_produce_the_same_determination(body, snapshot):
    """Invariant 2, as a property rather than as an example.

    Both the outcome *and* the evidence, because a decision that reproduced its
    verdict while reporting different reads would replay green and be wrong —
    the worst available failure, since it would pass every check that exists.
    """
    pack = Pack.from_body(body)
    first = evaluate_snapshot(pack, snapshot)
    second = evaluate_snapshot(pack, copy.deepcopy(snapshot))
    assert first == second


@given(body=packs(), snapshot=snapshots())
def test_a_determination_is_json_serialisable_and_survives_a_round_trip(body, snapshot):
    """Because it is stored as JSONB and read back years later.

    A result holding a tuple, a set or a date would serialise into something
    that does not compare equal to what came out of the engine — and replay
    compares them. This is the property that would break the day somebody
    returned a `set` of rule ids for tidiness.
    """
    result = evaluate_snapshot(Pack.from_body(body), snapshot)
    assert json.loads(json.dumps(result)) == result


# ------------------------------------------------------- order independence --


@given(body=packs(), snapshot=snapshots(), seed=st.integers(min_value=0, max_value=10_000))
def test_shuffling_the_rules_changes_nothing(body, snapshot, seed):
    """No rule can depend on another having run, or on having run first.

    A pack is a set of independent constraints and the outcome is the worst of
    them. If order mattered, "every failing rule explains the outcome on its own"
    would be false, and the reason cards would be a story about evaluation order
    rather than about the client.
    """
    shuffled = copy.deepcopy(body)
    random.Random(seed).shuffle(shuffled["rules"])

    original = evaluate_snapshot(Pack.from_body(body), snapshot)
    reordered = evaluate_snapshot(Pack.from_body(shuffled), snapshot)

    assert original == reordered, "rule order changed the determination"


#: Spelled out here rather than imported, and that is the point of this constant.
#: An earlier version of the test below asserted the outcome against
#: `engine.worst_of` — the same function the engine had just used — so it could
#: not fail. A deliberate mutation of `worst_of` was caught by the shuffle test
#: and sailed past this one. The severity order is part of what is being
#: asserted, so the test has to carry its own copy of it.
SEVERITY = {"ALLOW": 0, "REFER": 1, "BLOCK": 2}


@given(body=packs(), snapshot=snapshots())
def test_the_outcome_is_the_worst_of_the_rules_that_ran(body, snapshot):
    """No weighting, no netting, no rule overriding another.

    Stated as a property because it is the claim `docs/dsl-spec.md` makes to a
    diligence team, and an engine that quietly scored would still pass every
    example test written against packs where the worst rule happens to win.
    """
    result = evaluate_snapshot(Pack.from_body(body), snapshot)
    ran = [r["outcome"] for r in result["rule_results"]]

    expected = max(ran, key=lambda o: SEVERITY[o]) if ran else "ALLOW"
    assert result["outcome"] == expected
    # And one BLOCK is enough, however many rules passed around it.
    if "BLOCK" in ran:
        assert result["outcome"] == "BLOCK"
    elif "REFER" in ran:
        assert result["outcome"] == "REFER"


@given(body=packs(), snapshot=snapshots())
def test_every_rule_is_either_evaluated_or_recorded_as_not_applicable(body, snapshot):
    """Nothing is silently dropped.

    A rule that neither ran nor was recorded as inapplicable is a constraint the
    evidence does not mention — which is indistinguishable, to a reader, from a
    constraint that passed.
    """
    pack = Pack.from_body(body)
    result = evaluate_snapshot(pack, snapshot)

    accounted = {r["rule_id"] for r in result["rule_results"]} | set(
        result["rules_not_applicable"]
    )
    assert accounted == {r["rule_id"] for r in pack.rules}


# ----------------------------------------------------------------- no floats --


@given(body=packs_with_floats())
@settings(max_examples=max(EXAMPLES // 2, 20))
def test_a_pack_carrying_a_decimal_number_never_produces_a_determination(body):
    """Invariant 3, under content written to break it.

    Either the validator refuses the pack or the evaluator raises. What must not
    happen is a determination: a stored number that came from floating-point
    arithmetic is a number that will not compare equal to itself in 2031, and the
    decision would replay as a mismatch with nothing to point at.
    """
    pack = Pack.from_body(body)
    faults = validate(pack)
    if faults:
        assert any("decimal" in f for f in faults), faults
        return
    # Both float sites are now caught by the validator, so reaching here means
    # the generator found a third one — which is worth knowing about rather than
    # silently falling through to the evaluator check below.

    # The validator let it through — it only inspects constants, and a float can
    # also arrive in a threshold. The evaluator is the second line, and it must
    # raise rather than compute.
    snapshot = {
        "as_of": "2026-01-01",
        "licensee": {"jurisdiction": "GEN"},
        "client": {
            "age_years": 40,
            "loss_capacity_band": 3,
            "assessable_portfolio_cents": 1_000_000,
            "prior_crypto_purchases": 1,
            "knowledge_assessed": True,
            "vulnerability_flag": False,
            "client_category": "retail",
            "residency": "retail",
            "domicile": "retail",
            "knowledge_assessed_days_ago": 10,
            "structural_acks": [],
        },
        "asset": {
            "class": pack.asset_classes["GEN-ASSET"]["class"],
            "volatility_band": 2,
            "leverage": False,
            "structural_flags": [],
        },
        "jurisdictions": {},
        "trade": {"amount_cents": 1000},
        "calc": {
            "existing_crypto_cents": 0,
            "post_trade_crypto_cents": 1000,
            "post_trade_crypto_bps": 10,
            "trade_share_bps": 10,
        },
    }
    with pytest.raises(PackError) as raised:
        evaluate_snapshot(pack, snapshot)
    assert "float" in str(raised.value)


@given(body=packs(), snapshot=snapshots())
def test_no_number_in_a_determination_is_a_float(body, snapshot):
    """The positive form: a valid pack never produces one either.

    Checked over the whole result rather than over the fields we expect to be
    numeric, because the failure mode is a float appearing somewhere nobody was
    looking — inside a provenance entry, say.
    """
    result = evaluate_snapshot(Pack.from_body(body), snapshot)

    def walk(node):
        if isinstance(node, float):
            raise AssertionError(f"float in the determination: {node!r}")
        if isinstance(node, dict):
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(result)


# ------------------------------------------------------- the shipped packs --


@pytest.mark.parametrize("path", sorted(PACKS.glob("*.json")), ids=lambda p: p.stem)
@given(snapshot=snapshots())
@settings(max_examples=max(EXAMPLES // 3, 15), deadline=None)
def test_the_real_packs_never_crash_on_a_well_formed_snapshot(path, snapshot):
    """The properties above use generated packs; this one uses the real ones.

    A generated pack exercises the engine. Only the shipped packs exercise the
    *content* — and content is where a lookup table with a missing row or a rule
    reading a field nobody populates would hide.
    """
    body = json.loads(path.read_text())
    pack = Pack.from_body(body)

    # The generated snapshot classifies its asset as one of the four generic
    # classes; a real pack keys its tables on its own classification, so the
    # asset is relabelled to something this pack knows.
    known = next(iter(pack.asset_classes.values()))
    snapshot = copy.deepcopy(snapshot)
    snapshot["asset"]["class"] = known["class"]
    snapshot["asset"]["volatility_band"] = known["volatility_band"]

    result = evaluate_snapshot(pack, snapshot)
    assert result["outcome"] in ("ALLOW", "REFER", "BLOCK")
