"""A tenant can subscribe to `source.stale`, so a stale source has to send one.

`webhooks.EVENTS` lists `source.stale` as an event a tenant may subscribe to,
and §S4 names "freshness alerts" among the outbound webhooks the integrations
stage delivers. `source_alerts.notify_tenants` is the function that produces it,
and its own docstring says so in as many words:

    `source.stale` has been a declared event with no producer since the
    integrations stage — this is what produces it.

Nothing called it. Neither it nor its companion `all_tenant_ids` had a single
reference anywhere in `api/app` or `scripts`, so a customer could subscribe to
`source.stale`, watch a regulator's feed go dark for a week, and never be told —
by an endpoint that reported itself as configured and working.

`scripts/watch_tick.py` computed the breaches, paged *internally* through
`source_alerts.page`, printed them and exited 2. All of that is the specialist
owner being told. None of it is the customer being told, and those are different
obligations to different people: §S6 asks for the page, §S4 asks for the webhook.

**Scoped to the regimes a firm is actually in.** A firm licensed only in
Australia has no interest in an ESMA feed being down, and telling them anyway is
how a customer learns to ignore our alerts.
"""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import select, text

from app import source_alerts, tenancy
from app.db import OwnerSessionLocal, SessionLocal, WatchSessionLocal
from app.models import (
    SourceBreach,
    SourceBreachNotice,
    WatchSource,
    WebhookDelivery,
    WebhookEndpoint,
)
from tests.conftest import DEMO_TENANT

ACTOR = "apc_bulk_sweep"

#: A firm licensed where the stale source serves. It must hear about it.
#:
#: Its own tenant rather than the demo firm, and that is not fastidiousness:
#: an extra endpoint on the demo tenant changes what `webhooks.enqueue` returns
#: for every other test that uses it, and three in `test_webhooks.py` failed
#: exactly that way before this was isolated.
SUBSCRIBER = "stale-probe-au"

#: A firm in a regime the breach does not touch. It must hear nothing.
ELSEWHERE = "stale-probe-elsewhere"


def _make_tenant(tenant_id: str, name: str, regimes: str) -> None:
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "INSERT INTO tenants (id, name, region, tier, status, stage, config, created_at) "
                "VALUES (:id, :name, 'ap-southeast-2', 'shared', "
                "'active', 'pilot', CAST(:config AS jsonb), now()) "
                "ON CONFLICT (id) DO UPDATE SET config = CAST(:config AS jsonb)"
            ),
            {"id": tenant_id, "name": name, "config": regimes},
        )
        owner.commit()
        with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
            from app import crypto, evidence

            crypto.ensure_key(owner, tenant_id)
            evidence.ensure_anchor(owner, tenant_id)
            owner.commit()
    finally:
        owner.close()


@pytest.fixture(scope="module")
def two_firms():
    """One licensed where the source serves, one licensed elsewhere."""
    _make_tenant(SUBSCRIBER, "Stale probe AU", '{"jurisdictions": ["AU"]}')
    _make_tenant(ELSEWHERE, "Stale probe elsewhere", '{"jurisdictions": ["SG"]}')
    _endpoint_for(SUBSCRIBER)
    _endpoint_for(ELSEWHERE)
    return SUBSCRIBER


def _endpoint_for(tenant_id: str) -> None:
    """Somewhere for the notification to go. Without one, nothing is enqueued."""
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            existing = session.scalars(select(WebhookEndpoint)).first()
            if existing is None:
                session.add(
                    WebhookEndpoint(
                        id=f"whe_stale_{tenant_id}",
                        url="https://example.invalid/hook",
                        secret="not a real secret",
                        events=["source.stale"],
                        status="active",
                    )
                )
                session.commit()
        finally:
            session.close()


@contextmanager
def an_au_source_in_breach():
    """Put a real AU source over its alert threshold, and put it back after.

    `watch_sources` is global rather than tenant-scoped, so a source left in
    breach is left in breach for every test that runs afterwards.
    `test_source_slas.py` restores what it changes for the same reason.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            row = session.scalars(
                select(WatchSource).where(WatchSource.jurisdiction == "AU")
            ).first()
            assert row is not None, "no AU watch source — run `make seed`"
            before = (row.consecutive_failures, row.last_error, row.last_failed_at)
            row.consecutive_failures = row.alert_after_failures
            row.last_error = "HTTP 503 from example.invalid"
            row.last_failed_at = datetime.now(timezone.utc) - timedelta(hours=2)
            session.commit()
            breaches = source_alerts.open_breaches(session)
            assert breaches, "the source did not read as in breach"
            yield breaches
        finally:
            row.consecutive_failures, row.last_error, row.last_failed_at = before
            session.commit()
            session.close()


def _stale_deliveries(tenant_id: str) -> list[WebhookDelivery]:
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            return list(
                session.scalars(
                    select(WebhookDelivery).where(
                        WebhookDelivery.event == "source.stale"
                    )
                )
            )
        finally:
            session.close()


def _record_as_the_watch_role(breaches) -> int:
    """Write the breaches the way the deployed sweep does: watch role, watch DSN.

    Not a mock of the watch task — the real `quolin_watch` credential, through
    the real engine, against the real grant. If migration 0038 had not granted
    INSERT on `source_breaches` to this role, this fails here, which is the
    point of doing it this way rather than through the owner.
    """
    session = WatchSessionLocal()
    try:
        written = source_alerts.record_breaches(session, breaches)
        session.commit()
        return written
    finally:
        session.close()


def _fan_out_as_the_application(tenant_id: str) -> int:
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            sent = source_alerts.fan_out(session, tenant_id)
            session.commit()
            return sent
        finally:
            session.close()


def test_the_watch_role_can_record_a_breach_and_nothing_more(two_firms):
    """The half the watch task performs, with the only credential it holds.

    FP3-03. The previous arrangement had the sweep call `notify_tenants`, which
    opens `APP_DATABASE_URL`, having first called `all_tenant_ids`, which opens
    `DATABASE_URL`. The watch ECS task holds neither and the guard fails the
    build if it is given either, so in production both fell back to
    `localhost:5433` and the sweep raised on every run with a source in breach.
    """
    with an_au_source_in_breach() as breaches:
        written = _record_as_the_watch_role(breaches)

    assert written == len(breaches)

    session = WatchSessionLocal()
    try:
        rows = list(session.scalars(select(SourceBreach)))
    finally:
        session.close()
    assert rows, "the sweep's own credential could not write what it saw"


def test_the_watch_role_cannot_mark_a_breach_as_already_told(two_firms):
    """A compromised sweep must not be able to silence the fan-out.

    Writing a notice is how a breach stops being sent. If the watch role could
    write one it could mark every breach as delivered without deleting anything,
    and the absence would look exactly like a quiet week.
    """
    from sqlalchemy.exc import ProgrammingError

    session = WatchSessionLocal()
    try:
        session.add(SourceBreachNotice(breach_id=1, tenant_id=SUBSCRIBER))
        with pytest.raises(ProgrammingError):
            session.commit()
    finally:
        session.rollback()
        session.close()


def test_a_stale_source_reaches_the_firms_in_that_regime(two_firms):
    """The finding, end to end across the two credentials it takes."""
    before = len(_stale_deliveries(SUBSCRIBER))

    with an_au_source_in_breach() as breaches:
        _record_as_the_watch_role(breaches)

    sent = _fan_out_as_the_application(SUBSCRIBER)
    after = _stale_deliveries(SUBSCRIBER)

    assert sent > 0, (
        "a source has been unreachable past its alert threshold and no tenant "
        "was told. `source.stale` is subscribable, so a customer watching for "
        "one waits for ever."
    )
    assert len(after) > before, "no source.stale delivery was enqueued for the AU firm"
    assert after[-1].event == "source.stale"


def test_a_firm_in_another_regime_hears_nothing(two_firms):
    """Telling a firm about a regulator they are not licensed under is how a
    customer learns to ignore our alerts."""
    before = len(_stale_deliveries(ELSEWHERE))

    with an_au_source_in_breach() as breaches:
        _record_as_the_watch_role(breaches)

    _fan_out_as_the_application(ELSEWHERE)

    assert len(_stale_deliveries(ELSEWHERE)) == before, (
        "an SG-only firm was told an AU source is stale"
    )


def test_the_fan_out_does_not_send_the_same_breach_twice(two_firms):
    """Idempotent by construction, because the worker runs on a schedule.

    `source_breach_notices` carries one row per (breach, tenant), so the second
    run selects nothing rather than the worker having to remember where it got
    to — which is state that goes wrong the first time two of them overlap.
    """
    with an_au_source_in_breach() as breaches:
        _record_as_the_watch_role(breaches)

    first = _fan_out_as_the_application(SUBSCRIBER)
    second = _fan_out_as_the_application(SUBSCRIBER)

    assert first > 0
    assert second == 0, "the same breach was sent to the same firm twice"


def test_an_out_of_regime_breach_is_not_reconsidered_for_ever(two_firms):
    """"Told" and "decided not to tell" are both answers, and both get recorded.

    Without the second, every out-of-regime breach would be re-examined on every
    run of the worker for the life of the deployment.
    """
    with an_au_source_in_breach() as breaches:
        _record_as_the_watch_role(breaches)
    _fan_out_as_the_application(ELSEWHERE)

    with tenancy.acting_as(ELSEWHERE), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            pending = source_alerts.pending_breaches(session, ELSEWHERE)
        finally:
            session.close()

    assert pending == [], (
        "an AU breach an SG-only firm will never be told about is still queued "
        "for it, and will be reconsidered on every run"
    )


def test_no_breaches_records_nothing(two_firms):
    """The quiet case has to be quiet, or the alert stops meaning anything."""
    assert _record_as_the_watch_role([]) == 0
