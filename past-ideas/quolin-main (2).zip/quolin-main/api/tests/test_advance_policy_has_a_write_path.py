"""A firm's headline change-control lever, settable by the firm.

`advance.policy_for` reads `advance_policy` off the tenant and decides whether a
new pack version applies the moment it becomes effective or waits behind a
window the firm gets to check it in. That is the answer to "how do you control
vendor changes?", which is the first question a bank's diligence team asks about
a rules vendor.

Nothing set it. There was no endpoint, no screen, no API — a customer wanting to
pin their rules had to ask somebody at Quolin to run an UPDATE. The lever
existed, was read on every version arrival, and was reachable only from a psql
prompt.

Held to the same bar as the adoption ladder, because it is the same kind of act:
a change to what happens to this firm's determinations without anybody being
asked again. `tenant_admin`, a second factor, a credential presented recently,
and an audit event naming what moved.

The vocabulary is closed. An unrecognised policy would be read as `pinned` by
`policy_for` — which is the safe direction and exactly why it must not be
reachable through an API: a firm that typed `automatic` and was told "ok" would
believe they were on `auto` and be on `pinned`, or the reverse if the default
ever changed.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import advance, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import AuditEvent, Tenant
from tests.conftest import ADMIN_EMAIL, DEMO_TENANT, OPERATOR_EMAIL, sign_in

ROUTE = "/tenant/advance-policy"


@pytest.fixture
def restore_policy():
    """Put the demo firm's policy back, whatever a test did to it."""
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            before = dict(owner.get(Tenant, DEMO_TENANT).config or {})
    finally:
        owner.close()
    yield before
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            owner.get(Tenant, DEMO_TENANT).config = before
            owner.commit()
    finally:
        owner.close()


def _policy() -> tuple[str, int]:
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            return advance.policy_for(session.get(Tenant, DEMO_TENANT))
        finally:
            session.close()


def test_the_policy_can_be_read(restore_policy) -> None:
    with TestClient(app) as admin:
        sign_in(admin, ADMIN_EMAIL)
        res = admin.get(ROUTE)
    assert res.status_code == 200, res.text
    body = res.json()
    assert body["policy"] in advance.POLICIES
    assert isinstance(body["window_days"], int)
    assert set(body["policies"]) == set(advance.POLICIES)
    assert body["means"], "the screen has no words to show for the current policy"


def test_the_policy_can_be_set_and_reads_back(restore_policy) -> None:
    """The finding, directly."""
    with TestClient(app) as admin:
        sign_in(admin, ADMIN_EMAIL)
        res = admin.patch(ROUTE, json={"policy": advance.AUTO, "window_days": 21})
    assert res.status_code == 200, res.text
    assert res.json()["policy"] == advance.AUTO

    policy, window = _policy()
    assert policy == advance.AUTO, (
        "the policy was accepted and the engine still reads the old one"
    )
    assert window == 21


def test_setting_it_writes_an_audit_event(restore_policy) -> None:
    """A change to how vendor changes reach this firm is a change worth naming."""
    before = _policy()[0]
    wanted = advance.AUTO if before != advance.AUTO else advance.PINNED

    with TestClient(app) as admin:
        sign_in(admin, ADMIN_EMAIL)
        assert admin.patch(ROUTE, json={"policy": wanted}).status_code == 200

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            event = session.scalars(
                select(AuditEvent)
                .where(AuditEvent.action == "tenant.advance_policy")
                .order_by(AuditEvent.id.desc())
                .limit(1)
            ).first()
        finally:
            session.close()

    assert event is not None, "the policy changed and nothing recorded it"
    assert before in event.subject and wanted in event.subject, (
        f"the audit event does not say what moved: {event.subject!r}"
    )
    assert event.this_hash, "the record of the change is not chained"


@pytest.mark.parametrize("bad", ("automatic", "PINNED", "", "none", "auto "))
def test_an_unrecognised_policy_is_refused(bad, restore_policy) -> None:
    """Refused, not coerced.

    `policy_for` reads anything it does not recognise as `pinned`, which is the
    safe direction and exactly why this must not be reachable: a firm that typed
    `automatic` and was told "ok" would believe they were on one policy and be
    on the other.
    """
    before = _policy()
    with TestClient(app) as admin:
        sign_in(admin, ADMIN_EMAIL)
        res = admin.patch(ROUTE, json={"policy": bad})
    assert res.status_code == 422, res.text
    assert _policy() == before, "a refused change was applied anyway"


@pytest.mark.parametrize("bad", (0, -1, 400))
def test_an_impossible_window_is_refused(bad, restore_policy) -> None:
    """A zero-day window is `auto` wearing the word `pinned`."""
    before = _policy()
    with TestClient(app) as admin:
        sign_in(admin, ADMIN_EMAIL)
        res = admin.patch(ROUTE, json={"policy": advance.PINNED, "window_days": bad})
    assert res.status_code == 422, res.text
    assert _policy() == before


def test_an_operator_cannot_set_it(restore_policy) -> None:
    """It is a change-control decision, not part of the compliance work."""
    before = _policy()
    with TestClient(app) as operator:
        sign_in(operator, OPERATOR_EMAIL)
        res = operator.patch(ROUTE, json={"policy": advance.AUTO})
    assert res.status_code == 403, res.text
    assert _policy() == before


def test_a_stale_credential_is_refused(restore_policy) -> None:
    """The same freshness the adoption ladder requires, for the same reason.

    This is the setting that decides whether a firm's rules can change without
    anybody being asked again. An unattended screen must not be able to move it.
    """
    from datetime import timedelta

    from app import auth

    before = _policy()
    with TestClient(app) as admin:
        sign_in(admin, ADMIN_EMAIL)
        owner = OwnerSessionLocal()
        try:
            with tenancy.acting_as(DEMO_TENANT):
                row = auth.resolve(owner, admin.cookies.get(auth.COOKIE_NAME))
                assert row is not None
                row.authenticated_at = row.authenticated_at - timedelta(days=1)
                owner.commit()
        finally:
            owner.close()

        res = admin.patch(ROUTE, json={"policy": advance.AUTO})

    assert res.status_code == 401, res.text
    assert res.headers.get("X-Quolin-Reauth") == "required"
    assert _policy() == before


def test_the_advance_policy_is_still_kept_apart_from_the_permit(restore_policy) -> None:
    """Writing `config` through this route must not resurrect Q-11.

    The permit for unreviewed content used to live in the same JSON blob, and
    the reason it was moved to a column is that any path which rewrites `config`
    carries it. This is such a path.
    """
    with TestClient(app) as admin:
        sign_in(admin, ADMIN_EMAIL)
        assert admin.patch(
            ROUTE, json={"policy": advance.PINNED, "window_days": 14}
        ).status_code == 200

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            tenant = owner.get(Tenant, DEMO_TENANT)
            assert "illustrative_content_permitted" not in (tenant.config or {})
            assert tenant.illustrative_content_permitted is True, (
                "the demonstration firm lost its permit to a config rewrite"
            )
    finally:
        owner.close()
