"""§S9's alerting, and the property that makes it worth having.

An alert is only useful if it fires when the thing happens and stays quiet when
it does not. Both halves are tested here, because a check that fires constantly
gets muted and a check that never fires gets trusted — and the second failure is
the one nobody notices.

The game-day drill (`make game-day`) exercises the same paths end to end against
a real system. This file is the fast version that runs in CI on every commit.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from app import alerts, auth, observability, tenancy
from app.models import ArtefactJob

DEMO_TENANT = "demo"
ACTOR = "apc_bulk_sweep"


def _now() -> datetime:
    return datetime.now(timezone.utc)


@pytest.fixture
def undo(session):
    """Roll back what a test wrote.

    `security_events` is append-only, so anything committed here would stay
    forever — which is correct for the table and inconvenient for a test. So
    nothing is committed: the rows are flushed, queried, and rolled back.
    """
    try:
        yield
    finally:
        session.rollback()


# --- Each check fires when it should ------------------------------------------


def test_the_thresholds_are_what_the_runbooks_say():
    """Pinned as literals, so that a test cannot move with the thing it tests.

    The tests below count out a fixed number of events rather than
    `range(alerts.AUTH_FAILURES_PER_ACCOUNT)` — which passes at any threshold,
    including one so high the alert never fires. Stage 8 had a lease test with
    exactly this shape and it could not fail; this is the same mistake caught
    earlier, and the fix is to assert the constant here and use numbers there.
    """
    assert alerts.AUTH_FAILURES_PER_ACCOUNT == 10
    assert alerts.AUTH_FAILURES_PER_SOURCE == 30
    assert alerts.RLS_DENIALS == 1
    assert alerts.QUEUE_DEPTH == 1000
    assert alerts.DEAD_LETTERS == 1


def test_repeated_failures_against_one_account_page_somebody(session, undo):
    """Ten is the threshold: a person mistyping a password gives up around three
    and a password manager does not mistype at all."""
    # Written with the same call the login handler makes, into the same table.
    # This test used to fabricate `security_events` rows instead, and passed for
    # months against a check that could never have fired on a real sign-in —
    # `security_events` needs a tenant and `/auth/login` has none, so every real
    # failure was silently discarded. A monitor test that writes its own input
    # through a path the system does not use is a monitor testing itself.
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        for _ in range(10):
            auth.record_failure(session, "203.0.113.9", user_id="usr_under_attack")
        session.flush()
        found = alerts.auth_anomalies(session)

    # Found by account rather than by position. The suite's own tests sign in
    # wrongly on purpose, so a real seeded account can be over the threshold too
    # — and on CI it was, which made `matching[0]` somebody else entirely. A
    # check that alerts on several accounts at once is the check working; the
    # assertion was what was wrong.
    mine = [
        f
        for f in found
        if f.kind == "auth.failures_against_account"
        and f.detail.get("user_id") == "usr_under_attack"
    ]
    assert mine, (
        "ten failures against one account did not page anybody; findings were "
        f"{[f.detail.get('user_id') for f in found]}"
    )
    assert mine[0].severity == alerts.CRITICAL
    assert "runbooks/suspected-breach.md" in mine[0].action


def test_nine_failures_do_not(session, undo):
    """The other half. A check that fires below its own threshold is one that
    gets muted, and a muted check is not a check."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        for _ in range(9):
            observability.record(
                session,
                kind=observability.AUTH_FAILED,
                user_id="usr_merely_forgetful",
                source_ip="203.0.113.10",
                detail="wrong password",
            )
        session.flush()
        found = alerts.auth_anomalies(session)

    assert not [
        f
        for f in found
        if f.detail.get("user_id") == "usr_merely_forgetful"
    ]


def test_yesterdays_incident_does_not_page_today(session, undo):
    """The window is why these checks can be run every five minutes without
    paging somebody about something they dealt with last week."""
    old = _now() - timedelta(days=2)
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        for _ in range(20):
            event = observability.record(
                session,
                kind=observability.AUTH_FAILED,
                user_id="usr_last_week",
                source_ip="203.0.113.11",
            )
            if event is not None:
                event.at = old
        session.flush()
        found = alerts.auth_anomalies(session)

    assert not [f for f in found if f.detail.get("user_id") == "usr_last_week"]


def test_one_denial_is_enough(session, undo):
    """Row-level security refusing a query means either an attack or a code path
    that lost its tenant. There is no third explanation, and both are the same
    day's work."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        observability.record(
            session,
            kind=observability.RLS_DENIED,
            detail="a query reached across tenants",
        )
        session.flush()
        found = alerts.rls_denials(session)

    assert found and found[0].severity == alerts.CRITICAL


def test_a_replay_mismatch_pages(session, undo):
    """The alert that could not fire until the game day found it: the kind it
    looks for was not one the recorder would accept."""
    assert observability.REPLAY_MISMATCH in observability.KINDS

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        observability.record(
            session,
            kind=observability.REPLAY_MISMATCH,
            detail="determination #1 did not reproduce",
        )
        session.flush()
        found = alerts.replay_mismatches(session)

    assert found and found[0].severity == alerts.CRITICAL


def test_a_deep_queue_is_a_warning_rather_than_a_page(session, undo, monkeypatch):
    """Somebody should look before customers do — which is not the same as
    waking them.

    The threshold is lowered for the test rather than a thousand rows written.
    Writing `alerts.QUEUE_DEPTH` rows would scale with the constant — and did,
    briefly, until a deliberately broken threshold of ten million made this test
    try to insert ten million rows. A test that cannot fail is bad; one that
    hangs the suite when it should fail is worse.
    """
    from app.artefacts import queue

    monkeypatch.setattr(alerts, "QUEUE_DEPTH", 3)
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        for index in range(3):
            session.add(
                ArtefactJob(
                    kind="tmd",
                    params={"decision_id": "0"},
                    fingerprint=queue.fingerprint("tmd", {"probe": index}),
                    subject="probe",
                    status="queued",
                )
            )
        session.flush()
        found = alerts.queue_depth(session)

    assert found and found[0].severity == alerts.WARNING
    assert "worker" in found[0].action


def test_a_healthy_system_says_nothing(session, undo):
    """The property that makes the rest worth having.

    Checked against the chain rather than the whole set, because the seeded
    database legitimately carries the game-day drill's own security events —
    which is the drill working, not a failure.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        assert alerts.chain_integrity(session) == []


# --- The shape of a finding ----------------------------------------------------


def test_every_finding_tells_somebody_what_to_do(session, undo):
    """"chain verification failed" is a fact. An alert that requires the reader
    to work out the next step is one that gets acknowledged and left."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        observability.record(session, kind=observability.RLS_DENIED, detail="probe")
        for _ in range(10):
            observability.record(
                session, kind=observability.AUTH_FAILED, user_id="usr_probe"
            )
        session.flush()
        found = alerts.check(session)

    assert found
    for finding in found:
        assert finding.action, f"{finding.kind} says what is wrong and not what to do"
        assert finding.severity in (alerts.CRITICAL, alerts.WARNING)


def test_the_worst_finding_is_read_first(session, undo):
    """Sorting by count would put a deep queue above a broken chain, which is
    the wrong way round on the only day it matters."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        observability.record(session, kind=observability.RLS_DENIED, detail="probe")
        session.flush()
        found = alerts.check(session)

    severities = [f.severity for f in found]
    assert severities == sorted(severities, key=lambda s: 0 if s == alerts.CRITICAL else 1)


def test_a_check_that_breaks_is_reported_rather_than_skipped(session, monkeypatch, undo):
    """A blind spot is not an all-clear. The failure mode of monitoring is to go
    quiet, so a check that cannot run has to be as loud as one that fails."""

    def explode(session, **kwargs):
        raise RuntimeError("the database is on fire")

    monkeypatch.setattr(alerts, "CHECKS", ((explode, False),))
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        found = alerts.check(session)

    assert found and found[0].kind == "alerts.check_failed"
    assert found[0].severity == alerts.CRITICAL
    assert "blind spot" in found[0].action


# --- What a security event may and may not hold --------------------------------


def test_a_failed_sign_in_never_records_the_address_that_was_typed(session, undo):
    """A table of addresses people typed at a login form is a list of who might
    have an account here — exactly what an attacker wants, and what the rest of
    this schema takes trouble to encrypt."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        event = observability.record(
            session,
            kind=observability.AUTH_FAILED,
            source_ip="203.0.113.12",
            detail="NO_SUCH_USER",
        )
        session.flush()

    assert event is not None
    assert event.user_id is None
    assert "@" not in event.detail
    assert "@" not in (event.source_ip or "")


def test_an_unknown_kind_is_refused(session, undo):
    """A closed list, because an alert rule that matches a string somebody typed
    is one that stops matching when they type it differently."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with pytest.raises(ValueError) as exc:
            observability.record(session, kind="auth.oops")
    assert "unknown security event" in str(exc.value)


def test_security_events_cannot_be_edited(session, undo):
    """Append-only, like the audit trail. This is what somebody reads after an
    incident."""
    from sqlalchemy import text
    from sqlalchemy.exc import DBAPIError

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        observability.record(session, kind=observability.RLS_DENIED, detail="probe")
        session.flush()

        with pytest.raises(DBAPIError):
            session.execute(text("UPDATE security_events SET detail = 'edited'"))
            session.flush()
        session.rollback()

        with pytest.raises(DBAPIError):
            session.execute(text("DELETE FROM security_events"))
            session.flush()
        session.rollback()


# --- The status page -----------------------------------------------------------


def test_the_status_page_reports_the_chain_and_no_customer_data():
    """Public by definition: its purpose is to be readable by somebody who
    cannot sign in, including when we are the reason they cannot.

    Fetched with a client that has never signed in — the point is that it
    answers without a session, so borrowing one would test the wrong thing.
    """
    from fastapi.testclient import TestClient

    from app.main import app

    with TestClient(app) as anonymous:
        got = anonymous.get("/status")
    assert got.status_code == 200

    body = got.json()
    assert body["evidence_chain"] in ("verified", "NOT VERIFIED", "nothing recorded yet")
    assert body["engine"]
    assert "not an uptime average" in body["statement"]

    # Nothing per-customer. The whole page is served to anyone who asks.
    text = got.text.lower()
    for leak in ("client", "decision_id", "tenant"):
        assert leak not in text, f"the public status page mentions {leak!r}"
