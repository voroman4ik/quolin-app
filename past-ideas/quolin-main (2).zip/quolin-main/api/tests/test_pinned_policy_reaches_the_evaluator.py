"""The advance policy a firm chose has to reach the determination it records.

F1. Q-15 landed the write path for §S5's advance policy — `advance.notice`
stages a version, `advance.advance` takes it, `advance.decline` refuses it — and
the read path it feeds was never wired. `advance.effective_version_for` shipped
carrying a docstring about how damaging its failure would be, and nothing in
`api/app` ever called it. `packs_repo.active_all` assembled the shelf from
`effective_from <= as_of` and handed the newest pack to every determination,
whatever the firm had agreed to.

So a firm that chose `pinned`, was shown a fourteen-day review window and never
took the version still had its live determinations recorded and hash-chained
under that version. Their own evidence is what proves it: the decision rows name
a `pack_version` they never adopted.

**These tests assert the recorded determination, never the helper.** The
predecessor in `test_lifecycle.py` —
`test_a_pinned_tenant_is_not_moved_by_a_version_becoming_effective` —
calls itself the most important test in its file and asserts
`effective_version_for`'s return value — which was true the whole time F1 was
live, because nothing called it. A test of a pin has to read the `decisions` row
back: that is the artefact an auditor is handed, and the only thing that can
tell you the pin reached the evaluator rather than merely returning the right
number to nobody.

**The scenario is historical, and that is what keeps it out of everybody's way.**
`packs` is append-only, so a pack a test inserts cannot be removed at teardown,
and a new regime effective *today* joins the shelf every other tenant reads —
`test_crossborder.py` asserts today's shelf is exactly `{AU, HK, SG, EU}`, and
it is right to. These packs are dated in the past with their windows closed, so
`active_all(date.today())` never returns one. The determinations are made with
an explicit historical `as_of`, which is when they were in force.

That also makes the scenario the honest one for the second semantic: the version
the firm sits on has been *superseded*, so the effective-date query cannot
return it at all and it has to be read by number.
"""

from __future__ import annotations

import json
from datetime import date, timedelta
from pathlib import Path

import pytest
from sqlalchemy import select, text

from app import advance, crypto, evidence, packs_repo, service, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.models import Client, Decision, Tenant

ACTOR = "apc_pin_probe"

#: A firm of its own, at `full` — the rung where a determination has effect and
#: so the rung where being moved onto rules you never took actually matters.
PINNED_TENANT = "pin-probe"
PROBE_CLIENT = "pin-probe-client"

#: A regime nothing else reads. See the module docstring.
REGIME = "TT"

#: The same shape for the unreviewed-pin case, which needs its own version
#: history: a signed version in force above the unsigned one the firm sits on.
UNSIGNED_REGIME = "TU"
UNSIGNED_TENANT = "pin-probe-unsigned"
UNSIGNED_CLIENT = "pin-probe-unsigned-client"

PACKS_DIR = Path(__file__).resolve().parents[2] / "packs"

#: The history these determinations are made against. Every window is closed
#: and every date is in the past, so today's shelf is untouched.
TAKEN_FROM = date(2020, 1, 1)
TAKEN_UNTIL = date(2020, 12, 31)
IN_FORCE_FROM = date(2021, 1, 1)
IN_FORCE_UNTIL = date(2021, 12, 31)
NOT_YET_FROM = date(2021, 9, 1)
AS_OF = date(2021, 6, 1)

#: The threshold the two versions disagree about, and the trade that falls
#: between them. 800 bps of the portfolio: inside v2's cap, outside v3's.
LOOSE_CAP_BPS = 1_000
TIGHT_CAP_BPS = 500
PORTFOLIO_CENTS = 100_000_00
TRADE_CENTS = 8_000_00

#: A signatory the `packs_reviewed_needs_a_signatory` constraint accepts: not
#: bracketed, not `ILLUSTRATIVE`, not `pending engagement`.
SIGNATORY = "R. Mensah, Specialist Counsel"


def _pack_body(*, pack_id: str, version: int, cap_bps: int, status: str) -> dict:
    """A pack for a test regime, derived from the shipped AU content.

    Derived rather than authored so the rule set under test is the real one —
    eleven rules, a real precedence table, a real asset classification. What
    this changes is the regime it answers for, the version, the review status
    and the one threshold the two versions are supposed to disagree about.

    The `watch` block is dropped. It is the AU regulator's publication sources,
    and carrying it over would register watch sources for a regime that does not
    exist — which `test_source_verification.py` finds by picking "the first
    manual source" and getting somebody else's.
    """
    body = json.loads((PACKS_DIR / "au_v2.json").read_text())
    body["pack_id"] = pack_id
    body["version"] = version
    body["jurisdiction_name"] = f"Test Regime {pack_id}"
    body["content_status"] = status
    body["signed_by"] = SIGNATORY
    body["signed_at"] = "2020-01-01"
    body["watch"] = []
    # Answers for its own code and nothing else, so no other firm's
    # cross-border selection can reach it.
    body["covers_states"] = []
    body["thresholds"] = {**body["thresholds"], "max_crypto_concentration_bps": cap_bps}
    return body


def _ensure_pack(
    owner,
    *,
    jurisdiction: str,
    version: int,
    effective_from: date,
    effective_to: date,
    cap_bps: int,
    status: str = "REVIEWED",
) -> None:
    """Insert a pack row if this regime and version is not already stored.

    Idempotent because `packs` is append-only: a second run of the suite against
    the same database must find the row it left rather than collide with it.
    """
    body = _pack_body(
        pack_id=jurisdiction, version=version, cap_bps=cap_bps, status=status
    )
    body["effective_from"] = effective_from.isoformat()
    body["effective_to"] = effective_to.isoformat()
    owner.execute(
        text(
            "INSERT INTO packs "
            "(jurisdiction, version, effective_from, effective_to, body, signed_by, signed_at) "
            "VALUES (:j, :v, :eff, :until, CAST(:body AS jsonb), :by, :at) "
            "ON CONFLICT (jurisdiction, version) DO NOTHING"
        ),
        {
            "j": jurisdiction,
            "v": version,
            "eff": effective_from.isoformat(),
            "until": effective_to.isoformat(),
            "body": json.dumps(body),
            "by": SIGNATORY,
            "at": "2020-01-01",
        },
    )


def _ensure_tenant(owner, tenant_id: str, jurisdiction: str) -> None:
    owner.execute(
        text(
            "INSERT INTO tenants (id, name, region, tier, status, stage, config, created_at) "
            "VALUES (:id, :name, 'ap-southeast-2', 'shared', 'active', 'full', "
            "CAST(:config AS jsonb), now()) "
            "ON CONFLICT (id) DO UPDATE SET stage = 'full', config = CAST(:config AS jsonb)"
        ),
        {
            "id": tenant_id,
            "name": f"Pin Probe {tenant_id}",
            "config": json.dumps(
                {"jurisdictions": [jurisdiction], "advance_policy": advance.PINNED}
            ),
        },
    )


def _ensure_client(tenant_id: str, client_id: str, jurisdiction: str) -> None:
    """A client every rule in the pack passes, except the one under test."""
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
        setup = SessionLocal()
        try:
            if setup.get(Client, client_id) is None:
                setup.add(
                    Client(
                        id=client_id,
                        name="A Pinned Firm's Client",
                        scenario="pin-probe",
                        jurisdiction=jurisdiction,
                        dob=date(1980, 6, 1),
                        client_category="retail",
                        knowledge_assessed=True,
                        # Relative to the determination's `as_of`, not to today:
                        # a knowledge assessment dated after the determination
                        # would be a fact the firm did not have.
                        knowledge_date=AS_OF - timedelta(days=30),
                        loss_capacity_band=5,
                        vulnerability_flag=False,
                        assessable_portfolio_cents=PORTFOLIO_CENTS,
                        prior_crypto_purchases=3,
                        structural_acks=[],
                        default_trade_amount_cents=TRADE_CENTS,
                    )
                )
                setup.commit()
        finally:
            setup.close()


@pytest.fixture(scope="module", autouse=True)
def _custody_has_heard_of_the_probe_clients():
    """Custody holds a record for these clients, saying they hold nothing.

    Not decoration. `FixturePositionsProvider` answers `none_on_file` for a
    client it has never heard of, and the snapshot carries that through as
    `custody_known: False` — at which point the concentration rule has no
    reading to compare and the determination is a `REFER` about missing data
    under every version. Both packs would then agree, and a test whose two
    versions agree cannot see a pin.

    A zero *reading* is what makes the cap the thing under test: 800 bps of the
    portfolio, inside v2's cap and outside v3's.
    """
    from app.providers import fixtures as custody

    original = custody._positions_fixture
    known = {
        PROBE_CLIENT: {"crypto_value_cents": 0, "holdings": []},
        UNSIGNED_CLIENT: {"crypto_value_cents": 0, "holdings": []},
    }
    custody._positions_fixture = lambda: {**original(), **known}
    try:
        yield
    finally:
        custody._positions_fixture = original


def _set_policy(tenant_id: str, policy: str) -> None:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(tenant_id):
            tenant = owner.get(Tenant, tenant_id)
            tenant.config = {**(tenant.config or {}), "advance_policy": policy}
            owner.commit()
    finally:
        owner.close()


def _take(tenant_id: str, jurisdiction: str, version: int) -> None:
    """The firm is told about a version and takes it, through the real path."""
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            row = advance.notice(
                session,
                tenant_id=tenant_id,
                jurisdiction=jurisdiction,
                pack_version=version,
            )
            if row.status == advance.PENDING:
                advance.advance(
                    session, row.id, actor=ACTOR, note="Checked against our book."
                )
            session.commit()
        finally:
            session.close()


@pytest.fixture(scope="module")
def pinned_firm():
    """A firm on `pinned`, sitting on v2, with v3 in force over it at `AS_OF`."""
    owner = OwnerSessionLocal()
    try:
        _ensure_tenant(owner, PINNED_TENANT, REGIME)
        _ensure_pack(
            owner,
            jurisdiction=REGIME,
            version=2,
            effective_from=TAKEN_FROM,
            effective_to=TAKEN_UNTIL,
            cap_bps=LOOSE_CAP_BPS,
        )
        _ensure_pack(
            owner,
            jurisdiction=REGIME,
            version=3,
            effective_from=IN_FORCE_FROM,
            effective_to=IN_FORCE_UNTIL,
            cap_bps=TIGHT_CAP_BPS,
        )
        _ensure_pack(
            owner,
            jurisdiction=REGIME,
            version=4,
            effective_from=NOT_YET_FROM,
            effective_to=IN_FORCE_UNTIL,
            cap_bps=TIGHT_CAP_BPS,
        )
        owner.commit()
        with tenancy.acting_as(PINNED_TENANT), tenancy.acting_as_user(ACTOR):
            crypto.ensure_key(owner, PINNED_TENANT)
            evidence.ensure_anchor(owner, PINNED_TENANT)
            owner.commit()
    finally:
        owner.close()

    _ensure_client(PINNED_TENANT, PROBE_CLIENT, REGIME)
    _take(PINNED_TENANT, REGIME, 2)
    return PINNED_TENANT


def _determine(tenant_id: str, client_id: str) -> Decision:
    """One determination, recorded, read back as the database holds it."""
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            decision = service.evaluate(
                session,
                client_id=client_id,
                asset_id="BTC",
                as_of=AS_OF,
                amount_cents=TRADE_CENTS,
            )
            session.commit()
            decision_id = decision.id
        finally:
            session.close()

        read_back = SessionLocal()
        try:
            return read_back.get(Decision, decision_id)
        finally:
            read_back.close()


def test_a_pinned_firms_determination_is_recorded_under_the_version_it_took(
    pinned_firm,
):
    """F1, as the auditor sees it.

    v3 is in force at `AS_OF` and the firm has not taken it. The determination
    they record must name v2 — the version they reviewed and adopted — and must
    carry v2's answer. v2's own window closed six months earlier, so the pin
    also has to read it by number rather than by date.
    """
    _set_policy(PINNED_TENANT, advance.PINNED)

    decision = _determine(PINNED_TENANT, PROBE_CLIENT)

    assert decision.pack_version == 2, (
        "a pinned firm's determination was recorded under a version they never "
        f"took (got v{decision.pack_version}). Their evidence now says they "
        "decided under rules they were still reviewing."
    )
    assert decision.outcome == "ALLOW", (
        "the recorded outcome is not the one v2's cap gives, so the pin did not "
        "reach the rules the determination was actually made against"
    )


def test_the_same_firm_on_auto_is_recorded_under_the_version_in_force(pinned_firm):
    """The other half, and the reason this is a pin rather than a freeze.

    Nothing about the packs changes between this test and the one above. The
    only difference is the policy the firm chose, and it has to change the
    determination — otherwise the pin above would be indistinguishable from
    the shelf simply never having reached v3.
    """
    _set_policy(PINNED_TENANT, advance.AUTO)
    try:
        decision = _determine(PINNED_TENANT, PROBE_CLIENT)
    finally:
        _set_policy(PINNED_TENANT, advance.PINNED)

    assert decision.pack_version == 3, (
        "a firm on `auto` was not moved onto the version in force"
    )
    assert decision.outcome == "BLOCK", (
        "v3's tighter cap did not reach the determination"
    )


def test_taking_a_version_early_does_not_bring_it_into_force_early(pinned_firm):
    """A pin holds a firm back; it never pushes them forward.

    The firm here has taken v2 and then v4, and v4's date has not arrived at
    `AS_OF`. They must stay on **v2**: it is the newest version they have both
    taken and seen become effective. Carrying them to v3 would be the pin
    pushing a firm onto content they never looked at, which is the failure it
    exists to prevent, and carrying them to v4 would bring an unreleased version
    into force early.
    """
    _set_policy(PINNED_TENANT, advance.PINNED)
    _take(PINNED_TENANT, REGIME, 4)

    decision = _determine(PINNED_TENANT, PROBE_CLIENT)

    assert decision.pack_version != 4, (
        "taking a version before its date arrived brought it into force early"
    )
    assert decision.pack_version == 2, (
        "a firm that took v2 and then a not-yet-effective v4 was moved onto v3, "
        "which they never took"
    )


@pytest.fixture(scope="module")
def firm_pinned_to_unsigned_content():
    """A firm sitting on an unsigned version, with a signed one in force above it."""
    owner = OwnerSessionLocal()
    try:
        _ensure_tenant(owner, UNSIGNED_TENANT, UNSIGNED_REGIME)
        _ensure_pack(
            owner,
            jurisdiction=UNSIGNED_REGIME,
            version=1,
            effective_from=TAKEN_FROM,
            effective_to=TAKEN_UNTIL,
            cap_bps=LOOSE_CAP_BPS,
            status="PENDING_REVIEW",
        )
        _ensure_pack(
            owner,
            jurisdiction=UNSIGNED_REGIME,
            version=2,
            effective_from=IN_FORCE_FROM,
            effective_to=IN_FORCE_UNTIL,
            cap_bps=LOOSE_CAP_BPS,
        )
        owner.commit()
        with tenancy.acting_as(UNSIGNED_TENANT), tenancy.acting_as_user(ACTOR):
            crypto.ensure_key(owner, UNSIGNED_TENANT)
            evidence.ensure_anchor(owner, UNSIGNED_TENANT)
            owner.commit()
    finally:
        owner.close()

    _ensure_client(UNSIGNED_TENANT, UNSIGNED_CLIENT, UNSIGNED_REGIME)
    _take(UNSIGNED_TENANT, UNSIGNED_REGIME, 1)
    return UNSIGNED_TENANT


def test_a_firm_pinned_to_unsigned_content_is_refused_rather_than_advanced(
    firm_pinned_to_unsigned_content,
):
    """The pin may not become a way back onto content nobody signed.

    An acting firm sitting on an unsigned version is a refusal, not a quiet
    promotion to the signed one above it: advancing them would be the pin
    failing open, and the whole point of the pin is that a version changes under
    this firm only when they say so. `NoReviewedPackAvailable` names the regime
    so an operator knows which specialist to engage.
    """
    _set_policy(UNSIGNED_TENANT, advance.PINNED)

    with tenancy.acting_as(UNSIGNED_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            with pytest.raises(packs_repo.NoReviewedPackAvailable) as refused:
                service.evaluate(
                    session,
                    client_id=UNSIGNED_CLIENT,
                    asset_id="BTC",
                    as_of=AS_OF,
                    amount_cents=TRADE_CENTS,
                )
        finally:
            session.rollback()
            session.close()

    assert UNSIGNED_REGIME in str(refused.value)


def test_the_pin_records_nothing_when_it_refuses(firm_pinned_to_unsigned_content):
    """A refusal is not a determination, so it leaves no row behind."""
    _set_policy(UNSIGNED_TENANT, advance.PINNED)

    with tenancy.acting_as(UNSIGNED_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            recorded = list(
                session.scalars(
                    select(Decision).where(Decision.client_id == UNSIGNED_CLIENT)
                )
            )
        finally:
            session.close()

    assert recorded == [], "a refused determination was recorded anyway"


def test_todays_shelf_is_untouched_by_this_files_packs(session):
    """This file's guard on everybody else.

    Every pack above is dated in the past with its window closed, so none of
    them may appear on the shelf a determination made today would read. If one
    does, the regime leaked and `test_crossborder.py` is about to fail for a
    reason that has nothing to do with cross-border resolution.
    """
    shelf = packs_repo.active_all(session, date.today())

    assert REGIME not in shelf and UNSIGNED_REGIME not in shelf, (
        f"a test regime reached today's shelf: {sorted(shelf)}"
    )
