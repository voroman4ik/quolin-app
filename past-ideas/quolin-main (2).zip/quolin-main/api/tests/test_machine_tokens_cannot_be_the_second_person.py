"""A credential is not a second pair of eyes.

Report C claimed a machine token bypasses the separation-of-duties check because
it has a NULL user id. That is not what the code does — `service.override`
compares the decision's `decided_by` against the acting principal, and for a
machine that principal is the API client's id, so a machine overriding its own
determination is caught like anybody else.

Two real things were found underneath it.

**`acting is None` was a pass.** The self-approval check reads
`if acting is not None and decision.decided_by == acting`. A caller with no
principal in scope skipped the check entirely rather than being refused. Nothing
reaches that state through the API today — the middleware always binds one — and
"nothing reaches it today" is the wrong shape for the one rule that stops a
person approving their own work.

**Nothing stopped a machine holding a two-person role.**
`access_review.ROLES_A_MACHINE_SHOULD_NOT_HOLD` has listed `approver`,
`pack_signatory` and `tenant_admin` since it was written, and it is a *report*:
it names the problem quarterly and prevents none of it. An integration granted
`approver` could override a determination a person made, which is a second
signature from a credential in a config file.

So a machine principal cannot exercise those roles at all. Not "should not" —
the middleware drops them before the route table is consulted, so the refusal
covers every endpoint that needs one, including the ones added next year.
"""

from __future__ import annotations

import pytest
from conftest import reset_rate_limit_for_tests, the_bytes_on_the_row
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import passwords, service, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import (
    ROLES_A_MACHINE_MAY_NOT_EXERCISE,
    ApiClient,
    Decision,
)
from tests.conftest import DEMO_TENANT

ACTOR = "apc_bulk_sweep"
CREDENTIAL = "apc_two_person_probe"
SECRET = "an integration secret, not a real one"


@pytest.fixture
def machine():
    """An integration granted every role a person would need to act twice."""
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            row = owner.get(ApiClient, CREDENTIAL)
            if row is None:
                row = ApiClient(
                    id=CREDENTIAL,
                    label="Two-person probe",
                    secret_hash=passwords.hash_password(SECRET, email=CREDENTIAL),
                    status="active",
                    created_by="test",
                )
                owner.add(row)
            row.secret_hash = passwords.hash_password(SECRET, email=CREDENTIAL)
            row.status = "active"
            # Granted deliberately. The point is that holding the role is not
            # enough — a report that says a machine *should not* hold one
            # prevents nothing.
            row.roles = ["operator", "approver", "pack_signatory", "quolin_operator"]
            owner.commit()
    finally:
        owner.close()


    reset_rate_limit_for_tests()
    with TestClient(app) as client:
        token = client.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": CREDENTIAL,
                "client_secret": SECRET,
            },
        )
        assert token.status_code == 200, token.text
        client.headers["Authorization"] = f"Bearer {token.json()['access_token']}"
        yield client


def test_the_roles_a_machine_may_not_exercise_are_declared_once() -> None:
    """One list, beside the role vocabulary, read by both the guard and the report.

    `access_review` had its own copy. Two lists of the same thing drift, and the
    one that drifts is the one that lets something through.
    """
    from app import access_review

    assert set(ROLES_A_MACHINE_MAY_NOT_EXERCISE) >= {
        "approver",
        "pack_signatory",
        "tenant_admin",
        "quolin_operator",
    }
    assert (
        access_review.ROLES_A_MACHINE_SHOULD_NOT_HOLD is ROLES_A_MACHINE_MAY_NOT_EXERCISE
    ), "the access review keeps a second copy of this list"


def test_a_machine_cannot_override_a_determination(machine) -> None:
    """The two-person rule, from the side a credential comes in on."""
    from app.models import Override

    def overrides_on(decision_id: int) -> int:
        with tenancy.acting_as(DEMO_TENANT):
            session = SessionLocal()
            try:
                return len(
                    list(
                        session.scalars(
                            select(Override).where(Override.decision_id == decision_id)
                        )
                    )
                )
            finally:
                session.close()

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            decision_id = session.scalars(
                select(Decision.id).where(Decision.outcome != "ALLOW").limit(1)
            ).first()
        finally:
            session.close()
    assert decision_id is not None

    # Counted rather than asserted absent: the seed records resolved overrides
    # on some determinations, so "none exists" would be a claim about the seed
    # rather than about this request.
    before = overrides_on(decision_id)

    res = machine.post(
        f"/decisions/{decision_id}/override",
        json={"justification": "An integration decided this was fine."},
    )
    assert res.status_code == 403, (
        f"an integration overrode a determination: {res.status_code} {res.text}. "
        "The whole argument for separation of duties is that two people acted; a "
        "secret in a config file is not the second one."
    )
    assert overrides_on(decision_id) == before, "the refused override was recorded"


def test_a_machine_cannot_sign_or_publish_rule_content(machine) -> None:
    """The other two-person act. `packs` is global — this one reaches everybody."""
    from datetime import date, timedelta

    from app.models import PackDraft
    from app.watch import drafts

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            draft = drafts.create(
                session,
                jurisdiction="AU",
                on=date.today(),
                effective_from=date.today() + timedelta(days=3650),
                title="For the machine-token tests",
                rationale="Written by a test.",
                author="The Machine-Token Suite",
            )
            with tenancy.acting_as_user("user-some-signatory"):
                drafts.sign(
                    session,
                    draft.id,
                    signatory="A. Signatory",
                    signed_content_hash=the_bytes_on_the_row(session, draft),
                )
            session.commit()
            draft_id = draft.id
        finally:
            session.close()

    signed = machine.post(f"/watch/drafts/{draft_id}/sign", json={"note": ""})
    assert signed.status_code == 403, signed.text

    published = machine.post(
        f"/watch/drafts/{draft_id}/publish",
        json={"published_content_hash": the_bytes_on_the_row(None, draft_id)},
    )
    assert published.status_code == 403, (
        f"an integration published rule content to the global pack table: "
        f"{published.status_code} {published.text}"
    )

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            assert session.get(PackDraft, draft_id).published_pack_id is None
        finally:
            session.close()


def test_a_machine_keeps_the_roles_it_has_a_reason_for(machine) -> None:
    """The refusal must be narrow. An integration running checks is the product.

    A fix that refused a machine everything would have taken §S4 out with it.
    """
    res = machine.get("/v1/clients")
    assert res.status_code == 200, res.text


def test_an_override_with_no_principal_in_scope_is_refused() -> None:
    """`acting is None` was a pass, and it is the wrong shape for this rule.

    Nothing reaches this state through the API — the middleware always binds a
    principal — but "nothing reaches it today" is not the property to rest the
    one rule that stops a person approving their own work on.
    """
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            decision = session.scalars(select(Decision).limit(1)).first()
            assert decision is not None
            token = tenancy._current_user.set(None)
            try:
                with pytest.raises(service.SelfApproval):
                    service.override(
                        session,
                        decision,
                        justification="Nobody in particular decided this.",
                        approver="Nobody",
                    )
            finally:
                tenancy._current_user.reset(token)
        finally:
            session.rollback()
            session.close()
