"""Every row in the audit trail names a person who exists.

Before this stage, `audit_events.actor` said `demo.officer` on every row. That
string reads like a person right up until somebody asks who it is, which is the
worst property an audit trail can have: it is not a gap, it is a gap wearing a
name. The rule now is that the actor comes from the session and nowhere else,
and that a write with nobody behind it raises rather than inventing one.

The load-bearing test here is `test_the_trail_names_only_people_who_exist`. It
reads every row the suite has produced and resolves each actor against `users`,
so an endpoint added next month that writes an unattributed row fails this test
without anybody remembering to extend it.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import select

from app import service, tenancy
from app.models import AuditEvent, User

REPO = Path(__file__).resolve().parents[2]


def test_the_trail_names_only_actors_that_exist(client, session):
    """Every actor resolves to a row, or the trail is naming nobody.

    Resolved by id rather than checked for non-emptiness, because "not blank" is
    exactly the bar `demo.officer` cleared.

    **Stage 4 widened what counts as an actor, and the widening is the point
    rather than a concession.** A nightly file drop at 02:00 has no person behind
    it. Under Stage 2's rule `service.audit` refused to write for it, which was
    correct — and the answer is not to exempt batch from attribution but to
    recognise that the thing acting is a machine credential. `api_clients` exists
    for exactly that, and a batch run names the credential that owns the drop.

    What this does *not* weaken: an actor still has to be a row somebody
    provisioned, in this tenant, that the access review will ask about. Two kinds
    of actor, both accountable. What it would have weakened is the version of
    this test that accepted any non-empty string, which is why the union below is
    spelled out rather than the assertion relaxed.
    """
    from app.models import ApiClient

    client.post("/evaluate", json={"client_id": "margaret-wu", "asset_id": "BTC"})
    session.expire_all()

    actors = set(session.scalars(select(AuditEvent.actor)))
    assert actors, "the suite produced no audit events, so this proves nothing"

    people = set(session.scalars(select(User.id)))
    machines = set(session.scalars(select(ApiClient.id)))
    assert actors <= people | machines, (
        f"audit rows naming nobody: {sorted(actors - people - machines)}"
    )


def test_a_write_with_nobody_behind_it_raises(session):
    """The absence is refused, not filled in.

    A placeholder would make the unattributed row indistinguishable from an
    attributed one — which is the failure this whole task exists to remove, and
    the reason `Unattributed` is an exception rather than a default.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(None):
        with pytest.raises(service.Unattributed) as exc:
            service.audit(session, "test.action", "test:subject")
    assert "no acting user in scope" in str(exc.value)
    session.rollback()


def test_two_people_acting_produce_two_different_actors(client, approver, session):
    """The actor tracks the session, not the process.

    A single request-scoped read that happened to be a module global would pass
    every test above and still file both people's work under whoever signed in
    first. Two clients, one act each, and the rows must differ.
    """
    decision = client.post(
        "/evaluate", json={"client_id": "priya-nair", "asset_id": "ETH"}
    ).json()
    approver.post(
        f"/decisions/{decision['id']}/override",
        json={"justification": "Reviewed against the supplementary suitability file."},
    )
    session.expire_all()

    subject = f"decision:{decision['id']}"
    by_action = {
        row.action: row.actor
        for row in session.scalars(select(AuditEvent).where(AuditEvent.subject == subject))
    }
    assert by_action["decision.evaluate"] != by_action["decision.override"]

    names = {
        uid: session.get(User, uid).display_name for uid in by_action.values()
    }
    assert names[by_action["decision.evaluate"]] == "Dana Whitfield"
    assert names[by_action["decision.override"]] == "Marcus Oyelaran"


def test_a_decision_records_the_account_that_ran_it(client, session):
    """`decided_by` is what the override rule compares, so it has to be written.

    Outside the hash on purpose — invariant 2 says the frozen snapshot is the
    only input to a determination, and the operator is not one — which makes it
    a column that nothing else would notice if it silently stopped being filled.
    """
    from app.models import Decision

    body = client.post(
        "/evaluate", json={"client_id": "tom-askew", "asset_id": "SOL"}
    ).json()
    session.expire_all()

    row = session.get(Decision, body["id"])
    assert row is not None
    assert row.decided_by is not None
    assert session.get(User, row.decided_by).display_name == "Dana Whitfield"


def test_no_placeholder_actor_survives_anywhere_in_the_source():
    """The shared officer is deleted, not disabled — the same bar as the passcode.

    A grep rather than a behavioural assertion, because what is being proven is
    that the code path is gone. A disabled placeholder is one edit away from
    being a live one, and the edit looks like a bug fix.

    This file is excluded, for the same reason
    `scripts/guard_no_shared_passcode.sh` excludes itself: a test cannot search
    for a string without naming it, and prose explaining what was removed is the
    check working rather than a violation of it. Worth knowing that the
    exclusion was not there originally and the test still passed — `git grep`
    reads tracked files only, so it was silently ignoring this one until the
    moment it was committed. It would have failed on the first CI run.
    """
    hits = subprocess.run(
        [
            "git",
            "grep",
            "-n",
            "demo.officer",
            "--",
            "api",
            "web",
            "scripts",
            f":(exclude){Path(__file__).relative_to(REPO)}",
        ],
        cwd=REPO,
        capture_output=True,
        text=True,
    )
    assert hits.stdout == "", f"placeholder actor still present:\n{hits.stdout}"
