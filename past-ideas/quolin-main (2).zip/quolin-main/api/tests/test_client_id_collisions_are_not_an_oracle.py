"""A client id another firm holds must not answer differently from a free one.

F5. `clients.id` is `PRIMARY KEY (id)` — unique platform-wide, not per tenant —
and `decisions.client_id` references it. Under row-level security a firm cannot
*see* another firm's client, so `session.get(Client, id)` returns `None` and the
upsert inserts; the insert then meets a constraint that spans every tenant.

Two consequences, and only one of them is fixed here.

**A cross-tenant existence oracle.** The 500 that came back from an
`IntegrityError` is a different answer from the 200 a free id gets, so any
customer could enumerate whether a given client id exists somewhere else on the
platform. `C-1001` and `ACC-0042` are ordinary CRM ids, so this is not a
theoretical distinguisher — it leaks the shape of another bank's book, one id at
a time, through an endpoint every integration already has.

**A squatting denial.** A second bank whose CRM ids collide with an existing
customer's cannot load its book at all. That is not fixed here and cannot be:
the repair is a composite key `(tenant_id, id)` and a composite foreign key from
`decisions`, which is DDL on the evidence table and its append-only trigger.
Recorded under "Decisions requested" in docs/spec-changes.md.

So this closes the *cause disclosure*, which is what can be closed without DDL.
Every integrity failure answers 409 with one message that names no constraint,
no table, no tenant and no holder — so a refusal no longer distinguishes "an id
another firm holds" from anything else the database declines, and no 500 carries
`clients_pkey` into the logs and the error tracker.

**It does not make the id's availability unobservable, and must not be read as
doing so.** A caller can still tell a refused write from an accepted one,
because that is the answer the endpoint exists to give. Removing that signal
means the composite key, which is deferred. `test_the_residual_is_still_present`
below states this, so the next reader does not have to infer it.
"""

from __future__ import annotations

import json
from datetime import date

import pytest
from conftest import reset_rate_limit_for_tests
from fastapi.testclient import TestClient
from sqlalchemy import text

from app import crypto, evidence, passwords, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import ApiClient, Client
from tests.conftest import DEMO_TENANT, OPERATOR_EMAIL, sign_in

ACTOR = "apc_bulk_sweep"

#: The neighbouring firm, and a client only it holds.
NEIGHBOUR = "collision-neighbour"
NEIGHBOUR_CLIENT = "C-1001-held-next-door"

#: An id nobody holds. Deliberately the same shape as the one above, so the two
#: requests differ in exactly one thing: whether somebody else has the id.
FREE_CLIENT = "C-1001-held-by-nobody"

CREDENTIAL = "apc_collision_probe"
SECRET = "an integration secret, not a real one"


@pytest.fixture(scope="module")
def neighbour_holds_a_client():
    """Another firm, with a client this firm cannot see."""
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "INSERT INTO tenants (id, name, region, tier, status, stage, config, created_at) "
                "VALUES (:id, 'Collision neighbour', 'ap-southeast-2', 'shared', "
                "'active', 'pilot', '{}'::jsonb, now()) "
                "ON CONFLICT (id) DO NOTHING"
            ),
            {"id": NEIGHBOUR},
        )
        owner.commit()
        with tenancy.acting_as(NEIGHBOUR), tenancy.acting_as_user(ACTOR):
            crypto.ensure_key(owner, NEIGHBOUR)
            evidence.ensure_anchor(owner, NEIGHBOUR)
            owner.commit()
    finally:
        owner.close()

    with tenancy.acting_as(NEIGHBOUR), tenancy.acting_as_user(ACTOR):
        setup = SessionLocal()
        try:
            if setup.get(Client, NEIGHBOUR_CLIENT) is None:
                setup.add(
                    Client(
                        id=NEIGHBOUR_CLIENT,
                        name="Somebody Else's Client",
                        scenario="neighbour",
                        jurisdiction="AU",
                        dob=date(1985, 2, 2),
                        client_category="retail",
                        knowledge_assessed=True,
                        knowledge_date=date(2026, 1, 1),
                        loss_capacity_band=3,
                        vulnerability_flag=False,
                        assessable_portfolio_cents=100_000_00,
                        prior_crypto_purchases=1,
                        structural_acks=[],
                        default_trade_amount_cents=1_000_00,
                    )
                )
                setup.commit()
        finally:
            setup.close()

    # And this firm genuinely cannot see it, which is what makes the upsert
    # try to insert rather than update.
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        looking = SessionLocal()
        try:
            assert looking.get(Client, NEIGHBOUR_CLIENT) is None, (
                "the demo firm can see the neighbour's client, so row-level "
                "security is not doing what this test assumes"
            )
        finally:
            looking.close()

    return NEIGHBOUR_CLIENT


@pytest.fixture
def credential() -> str:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            row = owner.get(ApiClient, CREDENTIAL)
            if row is None:
                owner.add(
                    ApiClient(
                        id=CREDENTIAL,
                        label="Client collision probe",
                        secret_hash=passwords.hash_password(SECRET, email=CREDENTIAL),
                        roles=["operator", "viewer"],
                        status="active",
                        created_by="test",
                    )
                )
            else:
                row.secret_hash = passwords.hash_password(SECRET, email=CREDENTIAL)
                row.roles = ["operator", "viewer"]
                row.status = "active"
            owner.commit()
    finally:
        owner.close()
    return CREDENTIAL


def _body(client_id: str) -> dict:
    return {
        "id": client_id,
        "name": "A New Client",
        "scenario": "sterling",
        "jurisdiction": "AU",
        "dob": "1990-04-04",
        "client_category": "retail",
        "knowledge_assessed": True,
        "knowledge_date": "2026-02-01",
        "loss_capacity_band": 3,
        "vulnerability_flag": False,
        "assessable_portfolio_cents": 50_000_00,
        "prior_crypto_purchases": 2,
        "structural_acks": [],
        "default_trade_amount_cents": 1_000_00,
    }


def _post(token_client: TestClient, client_id: str):
    return token_client.post("/v1/clients", json=_body(client_id))


@pytest.fixture
def api(credential) -> TestClient:

    reset_rate_limit_for_tests()
    machine = TestClient(app)
    token = machine.post(
        "/v1/oauth/token",
        json={
            "grant_type": "client_credentials",
            "client_id": credential,
            "client_secret": SECRET,
        },
    ).json()["access_token"]
    machine.headers["Authorization"] = f"Bearer {token}"
    return machine


def test_an_id_held_by_another_firm_answers_409_not_500(
    api, neighbour_holds_a_client
) -> None:
    """The finding: the oracle's 'yes' answer."""
    res = _post(api, neighbour_holds_a_client)

    assert res.status_code == 409, (
        f"an id held by another firm answered {res.status_code}: {res.text}. A "
        "500 here tells any customer whether a given client id exists somewhere "
        "else on the platform."
    )


def test_a_free_id_is_still_created(api) -> None:
    """The control: the fix must not have made every upsert a conflict."""
    res = _post(api, FREE_CLIENT)
    assert res.status_code in (200, 201), res.text
    assert res.json()["id"] == FREE_CLIENT


def test_the_two_answers_are_indistinguishable_apart_from_the_id(
    api, neighbour_holds_a_client
) -> None:
    """What "not an oracle" actually means.

    A 409 that said "this id belongs to another tenant" would be the same leak
    wearing a different status code. The refusal has to look identical to one
    caused by anything else the database declines, and must not name the holder,
    the tenant, the constraint or the table.
    """
    held = _post(api, neighbour_holds_a_client)
    assert held.status_code == 409

    detail = json.dumps(held.json()).lower()
    for leak in (
        NEIGHBOUR,
        "tenant",
        "clients_pkey",
        "primary key",
        "another firm",
        "already exists",
        "integrityerror",
        "duplicate key",
    ):
        assert leak.lower() not in detail, (
            f"the refusal mentions {leak!r}, which tells the caller something "
            f"about who holds the id: {held.text}"
        )


def test_a_second_attempt_answers_the_same_way(api, neighbour_holds_a_client) -> None:
    """The refusal is stable, so retrying reveals nothing either.

    A first attempt that 409s and a second that 500s would restore the
    distinguisher — and a rolled-back session that poisoned the next request
    would be a worse bug than the one being fixed.
    """
    first = _post(api, neighbour_holds_a_client)
    second = _post(api, neighbour_holds_a_client)

    assert first.status_code == second.status_code == 409
    assert first.json() == second.json()


def test_the_firms_own_client_still_updates(api) -> None:
    """An id this firm holds is an update, which is what upsert means.

    The failure mode of a blanket `IntegrityError` catch is turning every
    ordinary re-send of a book into a conflict, which is exactly what the
    endpoint's docstring says must not happen.
    """
    created = _post(api, FREE_CLIENT)
    assert created.status_code in (200, 201), created.text

    body = _body(FREE_CLIENT)
    body["loss_capacity_band"] = 5
    again = api.post("/v1/clients", json=body)

    assert again.status_code in (200, 201), (
        f"re-sending a client this firm already holds was refused: {again.text}"
    )
    assert again.json()["created"] is False

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            stored = session.get(Client, FREE_CLIENT)
            assert stored is not None and stored.loss_capacity_band == 5
        finally:
            session.close()


def test_the_residual_is_still_present(api, neighbour_holds_a_client) -> None:
    """What this pack did *not* close, asserted rather than left implied.

    A held id is refused and a free one is accepted, so a caller can still
    establish whether a given id is usable — which, under a platform-wide
    primary key, means establishing whether somebody else holds it. Closing that
    needs `(tenant_id, id)` and a composite foreign key from `decisions`, which
    is DDL on the evidence table and its append-only trigger.

    Written as a passing test rather than an xfail because it is not a defect
    awaiting a fix in this branch: it is the recorded scope of the decision.
    When the composite key lands, this test fails and should be deleted, which
    is exactly the reminder it exists to be.
    """
    held = _post(api, neighbour_holds_a_client)
    free = _post(api, "C-1001-also-held-by-nobody")

    assert held.status_code == 409
    assert free.status_code in (200, 201)
    assert held.status_code != free.status_code, (
        "the availability signal is gone, which means the composite client key "
        "has landed — delete this test and the decision it records"
    )


def test_the_csv_importer_answers_the_same_way(neighbour_holds_a_client) -> None:
    """The second upsert path, which has the same shape and the same finding."""
    row = ",".join(
        [
            neighbour_holds_a_client,
            "sterling",
            "Imported Collision",
            "1990-01-01",
            "retail",
            "true",
            "2026-01-15",
            "3",
            "false",
            "5000000",
            "2",
            "",
            "100000",
            "AU",
            "",
            "",
        ]
    )
    header = (
        "id,scenario,name,dob,client_category,knowledge_assessed,knowledge_date,"
        "loss_capacity_band,vulnerability_flag,assessable_portfolio_cents,"
        "prior_crypto_purchases,structural_acks,default_trade_amount_cents,"
        "jurisdiction,residency,domicile"
    )

    with TestClient(app) as operator:
        sign_in(operator, OPERATOR_EMAIL)
        res = operator.post(
            "/import/clients",
            json={"csv_text": f"{header}\n{row}\n", "commit": True},
        )

    assert res.status_code in (200, 409), res.text
    if res.status_code == 409:
        detail = json.dumps(res.json()).lower()
        assert NEIGHBOUR not in detail and "tenant" not in detail, res.text
