"""§S7: documents that can be regenerated, and accounted for.

The gate has three parts. Two are about a single document and are here:

  * *each carries full provenance* — template version, pack version, data
    window, generator identity, on the row rather than inferable from the
    filename.
  * *a regenerated return is byte-identical for the same period and pack
    version* — which is the interesting one, because it is a claim about the
    absence of every hidden input a renderer usually has: the clock, the
    environment, dictionary ordering, a random document id.

The third part — a hundred queued renders that do not block the API — is in
`test_artefact_queue.py`, because it is about the worker rather than the
document.
"""

from __future__ import annotations

import hashlib
from datetime import date

import pytest
from sqlalchemy import select

from app import artefacts, reports, tenancy
from app.artefacts import renderer
from app.artefacts.renderer import NotDeterministic, _to_pdf, branding
from app.models import Artefact, Decision

DEMO_TENANT = "demo"
ACTOR = "usr_test_artefacts"


def _a_decision(session) -> Decision:
    row = session.scalars(
        select(Decision).where(Decision.pack_id == "AU").order_by(Decision.id.desc())
    ).first()
    assert row is not None, "no AU determination — run `make seed` first"
    return row


def _a_report(session):
    periods = reports.available_periods(session, jurisdiction="AU")
    assert periods, "no period with determinations in it — run `make seed` first"
    return reports.distribution_return(
        session, period=periods[0]["period"], jurisdiction="AU", scenario=None
    )


# --- The bytes are a function of the facts -----------------------------------


def test_the_renderer_embeds_no_timestamp_of_its_own():
    """The floor the whole guarantee stands on.

    WeasyPrint 69 writes no creation date, no modification date and no document
    id, so a PDF is a pure function of its markup. Asserted rather than assumed:
    a version bump that starts stamping the clock would otherwise break
    regeneration silently, and the symptom — "the return we filed in March no
    longer matches" — would surface a long way from the cause.
    """
    markup = "<html><body><p>Same input, same bytes.</p></body></html>"
    first = _to_pdf(markup)
    second = _to_pdf(markup)
    assert first == second, "the same markup produced two different PDFs"
    for stamp in (b"/CreationDate", b"/ModDate", b"/ID ", b"/Producer"):
        assert stamp not in first, f"the renderer now embeds {stamp.decode()}"


def _where_they_differ(first: bytes, second: bytes) -> str:
    """Locate a PDF difference precisely enough to act on.

    Byte offsets are a start and not an answer. What decides the next step is
    *which object* the bytes belong to and, when it is a compressed stream,
    whether the two streams decompress to the same thing — because "the same
    content compressed differently" and "different content" point at completely
    different culprits.
    """
    import zlib

    shortest = min(len(first), len(second))
    at = next((i for i in range(shortest) if first[i] != second[i]), shortest)
    window = slice(max(0, at - 40), at + 40)
    lines = [
        f"  sizes: {len(first)} and {len(second)}",
        f"  first difference at byte {at}: {first[at]:#04x} vs {second[at]:#04x}",
        f"  A: {first[window]!r}",
        f"  B: {second[window]!r}",
    ]

    # The object this offset falls inside, and its dictionary.
    header = first.rfind(b" obj", 0, at)
    start = first.rfind(b"\n", 0, max(header, 0)) + 1
    if header != -1:
        lines.append(f"  enclosing object: {first[start:header + 4].decode('latin-1')}")
        dictionary = first[header : first.find(b"stream", header)][:200]
        lines.append(f"  object header: {dictionary.decode('latin-1')!r}")

    # If both sides are the same Flate stream, does the *content* differ?
    def stream_at(data: bytes) -> bytes | None:
        opening = data.rfind(b"stream", 0, at)
        closing = data.find(b"endstream", at)
        if opening == -1 or closing == -1:
            return None
        body = data[opening + len(b"stream") : closing]
        return body.lstrip(b"\r\n")

    raw_a, raw_b = stream_at(first), stream_at(second)
    if raw_a is not None and raw_b is not None:
        try:
            plain_a, plain_b = zlib.decompress(raw_a), zlib.decompress(raw_b)
        except zlib.error as exc:
            lines.append(f"  stream did not decompress ({exc}) — raw bytes differ")
        else:
            if plain_a == plain_b:
                lines.append(
                    "  the streams decompress to IDENTICAL bytes: same content, "
                    "different compression"
                )
            else:
                short = min(len(plain_a), len(plain_b))
                where = next(
                    (i for i in range(short) if plain_a[i] != plain_b[i]), short
                )
                near = slice(max(0, where - 30), where + 30)
                lines.append(
                    f"  the streams decompress DIFFERENTLY at byte {where} of "
                    f"{len(plain_a)}/{len(plain_b)}:"
                )
                lines.append(f"    A: {plain_a[near]!r}")
                lines.append(f"    B: {plain_b[near]!r}")
                # A TrueType `head` table carries created/modified timestamps,
                # which is the classic reason a font subset varies per render.
                for tag in (b"head", b"name", b"post"):
                    if tag in plain_a:
                        lines.append(f"    (stream contains a {tag.decode()} table)")
    return "\n".join(lines)


def test_real_documents_render_the_same_way_twice(session):
    """The trivial markup above was too weak, and CI proved it twice.

    First it passed while every regeneration of an actual document failed — a
    one-paragraph document exercises none of what a real one does: embedded and
    subset fonts, several faces, tables, page counters. Then the real-document
    version passed too, while regenerations of *particular* documents kept
    failing — because it rendered the newest determination, which happens to be
    a simple one.

    So this renders several, including the awkward ones: an overridden
    determination and a cross-border determination both carry sections a plain
    ALLOW does not. On mismatch it reports where the two diverge, because
    "different bytes" is not a lead and "they differ at byte 41,208, inside a
    font stream" is.
    """
    from app import packs_repo
    from app.models import Override
    from app.service import decision_view

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        overridden = set(session.scalars(select(Override.decision_id)))
        candidates = []
        newest = _a_decision(session)
        candidates.append(("newest", newest))
        if overridden:
            candidates.append(
                ("overridden", session.get(Decision, sorted(overridden)[-1]))
            )
        crossed = session.scalars(
            select(Decision)
            .where(Decision.resolution.is_not(None))
            .order_by(Decision.id.desc())
        ).first()
        if crossed is not None:
            candidates.append(("cross-border", crossed))

        markups = []
        for label, decision in candidates:
            if decision is None:
                continue
            pack = packs_repo.by_version(session, decision.pack_id, decision.pack_version)
            for kind in ("tmd", "evidence_pack"):
                template_name = pack.artefact_templates.get(kind)
                if template_name is None:
                    continue
                markups.append(
                    (
                        f"{label} #{decision.id} {kind}",
                        renderer._env.get_template(template_name).render(
                            title=pack.artefact_titles.get(kind, kind),
                            kind=kind,
                            decision=decision_view(session, decision, pack),
                            pack=pack,
                            branding=branding(session),
                        ),
                    )
                )

    assert markups, "no documents to render"
    for label, markup in markups:
        first, second = _to_pdf(markup), _to_pdf(markup)
        if first != second:
            raise AssertionError(
                f"{label} rendered twice produced different bytes.\n"
                + _where_they_differ(first, second)
            )


def test_regenerating_a_return_is_byte_identical(session):
    """§S7's gate, directly.

    Same period, same pack version, same figures — so the same document. A
    return that changed between renders would mean the copy on file and the copy
    a regulator asked us to reproduce are different documents with the same
    name, and no amount of explanation makes that a good conversation.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        report = _a_report(session)
        first = artefacts.render_period(session, kind="regulatory_return", report=report)
        session.flush()
        first_bytes = artefacts.read_pdf(first.pdf_ref)

        second = artefacts.render_period(session, kind="regulatory_return", report=report)
        session.flush()
        second_bytes = artefacts.read_pdf(second.pdf_ref)

    assert first_bytes is not None and second_bytes is not None
    assert first_bytes == second_bytes, "a regenerated return differs from the original"
    assert first.content_hash == hashlib.sha256(first_bytes).hexdigest()
    assert second.id == first.id, "regeneration wrote a second row for the same document"


def test_regenerating_a_determination_document_is_byte_identical(session):
    """The same property for the per-decision documents. §S7 asks for it on
    returns; there is no reason a Target Market Determination should be weaker,
    and the two share a renderer."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        decision = _a_decision(session)
        first = artefacts.render(session, kind="tmd", decision_id=decision.id)
        session.flush()
        first_bytes = artefacts.read_pdf(first.pdf_ref)
        second = artefacts.render(session, kind="tmd", decision_id=decision.id)
        session.flush()
        second_bytes = artefacts.read_pdf(second.pdf_ref)

    assert first_bytes == second_bytes
    assert second.id == first.id


def test_a_document_that_stopped_being_reproducible_is_refused_loudly(session, monkeypatch):
    """If the guarantee ever breaks, the failure has to be immediate.

    Silently replacing the stored hash would destroy the evidence that the two
    ever differed, which is the only interesting thing about the event.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        report = _a_report(session)
        artefacts.render_period(session, kind="regulatory_return", report=report)
        session.flush()

        # A renderer that has started reading something it should not.
        real = _to_pdf
        monkeypatch.setattr(
            renderer, "_to_pdf", lambda html: real(html) + b"%drifted\n"
        )
        with pytest.raises(NotDeterministic) as exc:
            artefacts.render_period(session, kind="regulatory_return", report=report)

    assert "identical inputs" in str(exc.value)
    assert "reading the clock" in str(exc.value)
    session.rollback()


# --- Provenance --------------------------------------------------------------


def test_every_artefact_records_what_produced_it(session):
    """Template version, pack version, data window, generator identity — §S7's
    words. The question is what a regulator asks about a document in front of
    them, and none of it is reconstructible from the PDF."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        report = _a_report(session)
        # Any earlier copy is removed first, so this exercises the *create*
        # path. A regeneration deliberately keeps the original requester —
        # whoever first asked for the document is who the row is about — which
        # makes "who asked" unassertable here unless the row is new.
        session.query(Artefact).filter(
            Artefact.kind == "regulatory_return",
            Artefact.ref_id == f"AU:{report['period']}:all",
        ).delete(synchronize_session=False)
        artefact = artefacts.render_period(
            session, kind="regulatory_return", report=report
        )
        session.flush()

    assert artefact.template_version.endswith(".html")
    assert artefact.pack_id == "AU"
    assert artefact.pack_version and artefact.pack_version > 0
    assert artefact.window_start == date.fromisoformat(report["period_start"])
    assert artefact.window_end == date.fromisoformat(report["period_end"])
    assert artefact.generated_by == ACTOR, "the document does not say who asked for it"
    assert len(artefact.content_hash) == 64


def test_a_determination_document_records_the_day_it_was_assessed_as_its_window(session):
    """A determination's window is the day it was assessed *as at*, not the day
    it was recorded — the same field the rules were selected by."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        decision = _a_decision(session)
        artefact = artefacts.render(session, kind="tmd", decision_id=decision.id)
        session.flush()

    assert artefact.window_start == decision.as_of
    assert artefact.window_end == decision.as_of
    assert artefact.pack_version == decision.pack_version


# --- Branding ----------------------------------------------------------------


def test_the_letterhead_comes_from_tenant_config(session):
    from app.models import Tenant

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        tenant = session.get(Tenant, DEMO_TENANT)
        before = dict(tenant.config or {})
        tenant.config = {**before, "branding": {"name": "Sterling Private Wealth"}}
        session.flush()
        try:
            marks = branding(session)
            assert marks["name"] == "Sterling Private Wealth"
        finally:
            tenant.config = before
            session.flush()


def test_a_tenant_cannot_retitle_a_statutory_document(session):
    """Invariant 8, restated where §S7 could have broken it.

    Branding is presentation. A firm that could set its own `artefact_titles`
    would be filing a Target Market Determination under a name it invented, and
    the title has to stay pack content for the same reason the thresholds do.
    """
    from app.models import Tenant

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        tenant = session.get(Tenant, DEMO_TENANT)
        before = dict(tenant.config or {})
        tenant.config = {
            **before,
            "branding": {
                "name": "A Firm",
                # Both ignored: branding carries a name and contact details and
                # nothing that changes what the document asserts.
                "title": "Not A Target Market Determination",
                "artefact_titles": {"tmd": "Something Else Entirely"},
            },
        }
        session.flush()
        try:
            decision = _a_decision(session)
            artefact = artefacts.render(session, kind="tmd", decision_id=decision.id)
            session.flush()
            assert "Target Market Determination" in artefact.title
            assert "Something Else" not in artefact.title
        finally:
            tenant.config = before
            session.flush()


# --- The certificate ---------------------------------------------------------


def test_the_certificate_recomputes_the_chain_rather_than_reporting_a_stored_answer(
    client, session
):
    """§S7: "audit export with chain-verification certificate".

    A stored "verified" is a claim about a moment that has passed, and the
    moment it goes stale is exactly the moment it matters. So the certificate
    walks the chain when it is asked for, and says how many links it checked.
    """
    got = client.get("/audit/certificate")
    assert got.status_code == 200, got.text
    body = got.json()

    assert body["verified"] is True
    assert body["checked"] > 0, "a certificate that checked nothing proves nothing"
    assert body["tip_hash"] and body["genesis_hash"]
    assert body["checked_at"]


def test_the_certificate_and_the_export_make_different_claims(client):
    """The two halves say different things, which is the point of having both.

    The CSV is `audit_events`: append-only at the database level and not
    hash-chained. The certificate is `decisions`: every link recomputed. A
    reader holding both should know which guarantee covers which file rather
    than inferring one from the other.
    """
    export = client.get("/audit/export")
    assert export.status_code == 200
    assert export.headers["X-Quolin-Integrity"] == "append-only-trigger; not-hash-chained"

    certificate = client.get("/audit/certificate").json()
    assert certificate["covers"] == "decisions"
    assert "not hash-chained" in certificate["statement"]
    assert "/audit/export" in certificate["statement"]


# --- Formats are content, the pipeline is engineering -------------------------


def test_a_pack_can_declare_a_document_the_code_has_never_heard_of(session):
    """§S7, in its own words: "return formats are pack content, engineering is
    the pipeline".

    Until this stage a document kind was a tuple in the renderer and a list in
    the API, so a regime adding a statutory document needed a deploy and a code
    review of a decision the content team owns. This renders a kind that appears
    nowhere in the source — only in a pack — and the only thing the code
    supplies is the pipeline.
    """
    # Built from the AU pack in force, with one document added — so this is a
    # *content edit*, which is exactly the claim being tested. Constructing a
    # pack body by hand would test the constructor instead.
    from app import packs_repo
    from app.engine import Pack as EnginePack

    with tenancy.acting_as(DEMO_TENANT):
        in_force = packs_repo.active_rows(session, date.today())["AU"]
    body = dict(in_force.body)
    body["artefact_templates"] = {
        **body["artefact_templates"],
        "board_pack": "period_return_v2.html",
    }
    body["artefact_titles"] = {**body["artefact_titles"], "board_pack": "Quarterly Board Pack"}
    body["artefact_scopes"] = {"board_pack": "period"}
    pack = EnginePack.from_body(body)

    assert renderer.scope_of("board_pack", pack) == renderer.PERIOD_SCOPE
    assert "board_pack" in renderer.kinds_for(pack)
    assert "board_pack" in renderer.kinds_for(pack, scope=renderer.PERIOD_SCOPE)


def test_a_pack_that_says_nothing_keeps_the_behaviour_it_had(session):
    """Silence must not change an existing pack. Every document this system made
    before periods existed was about one determination, so an unmapped kind is a
    per-determination document — and the two that were period documents before
    the map existed still are."""
    from app import packs_repo
    from app.engine import Pack as EnginePack

    with tenancy.acting_as(DEMO_TENANT):
        in_force = packs_repo.active_rows(session, date.today())["AU"]
    body = dict(in_force.body)
    body.pop("artefact_scopes", None)
    silent = EnginePack.from_body(body)
    assert renderer.scope_of("regulatory_return", silent) == renderer.PERIOD_SCOPE
    assert renderer.scope_of("override_report", silent) == renderer.PERIOD_SCOPE
    assert renderer.scope_of("tmd", silent) == renderer.DECISION_SCOPE
    assert renderer.scope_of("something_new", silent) == renderer.DECISION_SCOPE


def test_asking_for_a_document_the_pack_does_not_declare_says_what_it_does(client):
    """A 404 that lists what the pack actually declares, rather than a list
    maintained in the API that would go stale the first time a pack changed."""
    got = client.post(
        "/artefacts/batch",
        json={"jobs": [{"kind": "invented_document", "jurisdiction": "AU"}]},
    )
    assert got.status_code == 404
    detail = got.json()["detail"]
    assert "invented_document" in detail
    assert "tmd" in detail, "the refusal should say which documents exist"


def test_an_override_makes_a_new_document_rather_than_a_broken_renderer(session):
    """The regression CI found, and the reason the fingerprint is the markup.

    A determination's document shows whether it was later overridden. An
    override lives in its own table and is deliberately *not* part of the
    determination's chain hash — so a fingerprint built from that hash said the
    inputs were unchanged while the document had visibly changed, and the guard
    called a correct regeneration a defect.

    Three inputs were missed this way before the fingerprint became the rendered
    markup: the firm's letterhead, the figures in a return, and this. There was
    no reason to think the fourth would have been the last.
    """
    from app.models import Override

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        # A determination nobody has overridden. Not one cleared for the test:
        # `overrides` is append-only and refuses DELETE for exactly the reason
        # this document exists — an override that could be removed would make
        # the document deniable.
        overridden = set(session.scalars(select(Override.decision_id)))
        decision = session.scalars(
            select(Decision)
            .where(Decision.pack_id == "AU", Decision.id.not_in(overridden or {0}))
            .order_by(Decision.id.desc())
        ).first()
        assert decision is not None, "every AU determination has been overridden"

        before = artefacts.render(session, kind="tmd", decision_id=decision.id)
        session.flush()
        before_hash, before_inputs = before.content_hash, before.inputs_hash

        session.add(
            Override(
                decision_id=decision.id,
                justification="Client provided a statement of assets.",
                approver="Marcus Oyelaran",
            )
        )
        session.flush()

        # No exception: the document changed because the facts did.
        after = artefacts.render(session, kind="tmd", decision_id=decision.id)
        session.flush()

        assert after.id == before.id, "a changed document should update its row"
        assert after.content_hash != before_hash, "the override is not in the document"
        assert after.inputs_hash != before_inputs, (
            "the fingerprint did not notice an input that changed"
        )
        session.rollback()


def test_the_font_timestamp_is_pinned(session):
    """The root cause of §S7's gate failing, pinned so it cannot come back.

    WeasyPrint subsets embedded fonts through HarfBuzz, and a TrueType `head`
    table carries a `modified` timestamp. HarfBuzz stamps the current time into
    the subset — so two renders of identical markup that straddle a second
    boundary differ by exactly one in the `head` table's checksum, and by
    nothing else. On a fast machine they usually land in the same second, which
    is why this reproduced on CI and not on a laptop.

    `SOURCE_DATE_EPOCH` is the reproducible-builds convention for exactly this.
    Asserted here rather than trusted, because the failure it prevents is a
    single byte inside a compressed stream in a font nobody wrote — which took
    four wrong explanations to find the first time.
    """
    import os

    assert os.environ.get("SOURCE_DATE_EPOCH") == renderer.FONT_TIMESTAMP_EPOCH, (
        "the font timestamp is no longer pinned; subset fonts will vary per render"
    )


def test_a_document_is_the_same_across_a_second_boundary(session):
    """The reproduction, made deliberate.

    Rendering twice with a second in between is what CI was doing by accident.
    Slow, and worth it: this is the exact condition the whole guarantee failed
    under, and a test that only renders back to back would pass on a machine
    where the guarantee is broken.
    """
    import time

    from app import packs_repo
    from app.service import decision_view

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        decision = _a_decision(session)
        pack = packs_repo.by_version(session, decision.pack_id, decision.pack_version)
        markup = renderer._env.get_template(pack.artefact_templates["evidence_pack"]).render(
            title=pack.artefact_titles.get("evidence_pack", "evidence_pack"),
            kind="evidence_pack",
            decision=decision_view(session, decision, pack),
            pack=pack,
            branding=branding(session),
        )

    first = _to_pdf(markup)
    time.sleep(1.1)
    second = _to_pdf(markup)
    if first != second:
        raise AssertionError(
            "the same document rendered a second later differs.\n"
            + _where_they_differ(first, second)
        )
