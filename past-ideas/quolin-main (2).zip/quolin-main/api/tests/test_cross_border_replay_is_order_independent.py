"""A cross-border determination has to replay in the order it was resolved in.

F3. `resolve_across` is order-sensitive by construction, and legitimately so:
`rules_not_applicable`, the `binding` and `evaluated_not_binding` lists within
each dimension, and every rationale sentence are all built by walking the
evaluations in the order they arrive.

Recording walks them in `applicable_codes` order — licensee, then residency,
then domicile, which is the order the regimes actually reached the client.
Replay walked `sorted(stored_others.items())`, which is alphabetical. The two
agree only by luck.

They disagree the moment the residency code sorts after the domicile code. A
Hong Kong-licensed client resident in Singapore and domiciled in Germany is
recorded as `[SG, EU]` and replayed as `[EU, SG]`, and the resolution rebuilt
from the second order is not the one on file.

**Nothing caught it because the seed has one three-regime client and it is
HK/SG**, which sorts the same both ways. The corpus, the property suite and the
nightly replay all walk the same book, so all three were blind to it together.

That matters more than an ordinary reproduction failure.
`docs/runbooks/chain-mismatch.md` instructs that a replay mismatch be treated as
a security incident — evidence that somebody has altered stored decisions. So
the first customer with a three-regime client whose codes sort the wrong way
pages the on-call team as a tampering event, at whatever hour the nightly replay
runs.

**The order is re-derived from the frozen snapshot, not read back.** The
recorded `other_jurisdictions` is jsonb, and jsonb does not preserve object key
order, so the order the determination used cannot be recovered from it. It can
be recomputed exactly, because it is a function of three frozen facts:
`applicable_codes` over the stored snapshot, matched to packs the same way
recording matched them — through `covers_states`, so the EU pack answers for DE.
"""

from __future__ import annotations

import itertools
from datetime import date

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import select, text

from app import crypto, evidence, service, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.engine.crossborder import applicable_codes, match_packs
from app.models import Client, Decision

ACTOR = "apc_bulk_sweep"

#: A firm of this file's own.
#:
#: The clients below could have lived in the demo tenant — it holds the HK and
#: SG licences this needs — but eighteen extra clients and their determinations
#: land in the demo firm's dashboard, and
#: `test_api.py::test_dashboard_counts_are_scenario_scoped` asserts that the two
#: seeded scenarios partition the whole book. A test that has to be counted by
#: another test is a test that will break one.
#:
#: `pilot` because the packs these regimes ship are ILLUSTRATIVE, and a firm
#: that cannot act on a determination may compute one against unreviewed rules
#: — see `packs_repo.ACTING_STAGES`. What is under test is replay, not content
#: status.
XB_TENANT = "xb-order-probe"

#: A regime the demo firm is licensed in, so it can be a licensee.
LICENSEES = ("HK", "SG")

#: Codes a client can be resident or domiciled in. `DE` is the interesting one:
#: no `DE` pack exists, the EU pack answers for it through `covers_states`, and
#: `"DE" < "SG"` while `"EU" > "DE"` — which is what makes the recorded order and
#: the alphabetical order disagree.
ELSEWHERE = ("HK", "SG", "DE")

ASSET = "BTC"


def _client_id(licensee: str, residency: str, domicile: str) -> str:
    return f"xb-order-{licensee}-{residency}-{domicile}".lower()


@pytest.fixture(scope="module", autouse=True)
def xb_tenant():
    """The firm these determinations belong to, created once."""
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "INSERT INTO tenants (id, name, region, tier, status, stage, config, created_at) "
                "VALUES (:id, 'Cross-border order probe', 'ap-southeast-2', 'shared', "
                "'active', 'pilot', CAST(:config AS jsonb), now()) "
                "ON CONFLICT (id) DO UPDATE SET stage = 'pilot'"
            ),
            {"id": XB_TENANT, "config": '{"jurisdictions": ["HK", "SG"]}'},
        )
        owner.commit()
        with tenancy.acting_as(XB_TENANT), tenancy.acting_as_user(ACTOR):
            crypto.ensure_key(owner, XB_TENANT)
            evidence.ensure_anchor(owner, XB_TENANT)
            owner.commit()
    finally:
        owner.close()
    return XB_TENANT


def _ensure_client(licensee: str, residency: str, domicile: str) -> str:
    client_id = _client_id(licensee, residency, domicile)
    with tenancy.acting_as(XB_TENANT), tenancy.acting_as_user(ACTOR):
        setup = SessionLocal()
        try:
            if setup.get(Client, client_id) is None:
                setup.add(
                    Client(
                        id=client_id,
                        name=f"Cross-border {licensee}/{residency}/{domicile}",
                        scenario="cross-border-order",
                        jurisdiction=licensee,
                        residency=residency,
                        domicile=domicile,
                        dob=date(1979, 3, 14),
                        client_category="retail",
                        knowledge_assessed=True,
                        knowledge_date=date.today(),
                        loss_capacity_band=3,
                        vulnerability_flag=False,
                        assessable_portfolio_cents=250_000_00,
                        prior_crypto_purchases=2,
                        structural_acks=[],
                        default_trade_amount_cents=5_000_00,
                    )
                )
                setup.commit()
        finally:
            setup.close()
    return client_id


#: Every combination worth running. Licensee is restricted to the two regimes
#: the demo firm holds a licence in — a client whose licensee is `DE` would have
#: no governing pack at all, which is a different finding.
COMBINATIONS = [
    (licensee, residency, domicile)
    for licensee in LICENSEES
    for residency, domicile in itertools.product(ELSEWHERE, repeat=2)
]


@pytest.mark.parametrize("licensee,residency,domicile", COMBINATIONS)
def test_every_combination_of_regimes_replays_exactly(licensee, residency, domicile):
    """The finding, across the whole space rather than at the one case that broke.

    A determination is recorded and then replayed through the database, which is
    what the nightly job does. `match` must be true for all of them: the stored
    determination and the replayed one have to be the same determination.
    """
    client_id = _ensure_client(licensee, residency, domicile)

    with tenancy.acting_as(XB_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            decision = service.evaluate(
                session, client_id=client_id, asset_id=ASSET, amount_cents=5_000_00
            )
            session.commit()
            decision_id = decision.id
        finally:
            session.close()

        checking = SessionLocal()
        try:
            stored = checking.get(Decision, decision_id)
            result = service.replay(checking, stored)
        finally:
            checking.rollback()
            checking.close()

    assert result["match"] is True, (
        f"a {licensee}/{residency}/{domicile} determination did not reproduce: "
        f"stored {result['stored_outcome']}, replayed {result['replayed_outcome']}, "
        f"differences {result['differences']}. The runbook says to treat this as "
        "tampering, so a customer with this client pages the on-call team."
    )


def test_the_recorded_order_is_the_one_replay_rebuilds():
    """The mechanism, named rather than inferred from an outcome.

    The case the alphabetical sort got wrong: recorded `[SG, EU]`, replayed
    `[EU, SG]`. Asserting the order directly means a future change that makes
    the outcomes agree by coincidence — two regimes that happen to say the same
    thing — cannot hide the ordering going wrong again.
    """
    client_id = _ensure_client("HK", "SG", "DE")

    with tenancy.acting_as(XB_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            decision = service.evaluate(
                session, client_id=client_id, asset_id=ASSET, amount_cents=5_000_00
            )
            session.commit()
            decision_id = decision.id
        finally:
            session.close()

        checking = SessionLocal()
        try:
            stored = checking.get(Decision, decision_id)
            others = service._other_packs(checking, stored)
            snapshot = dict(stored.snapshot)
            recorded = list(
                (stored.rule_results.get("other_jurisdictions") or {}).keys()
            )
            rebuilt = evidence._replay_order(snapshot, recorded, others)
        finally:
            checking.rollback()
            checking.close()

    # Derived from the snapshot, so it states what the determination did rather
    # than what this test hopes it did.
    matched, _unmatched = match_packs(applicable_codes(snapshot), others)
    expected = [p.pack_id for p in matched]

    assert expected == ["SG", "EU"], (
        f"the scenario is not the one under test any more: {expected}"
    )
    assert rebuilt == expected, (
        f"replay would walk {rebuilt} where the determination walked {expected}"
    )
    assert sorted(recorded) != expected, (
        "this client no longer distinguishes recorded order from alphabetical "
        "order, so it cannot see F3 — pick different regimes"
    )


def test_a_single_regime_decision_still_replays():
    """The ordinary case, which has no `other_jurisdictions` at all."""
    client_id = _ensure_client("HK", "HK", "HK")

    with tenancy.acting_as(XB_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            decision = service.evaluate(
                session, client_id=client_id, asset_id=ASSET, amount_cents=5_000_00
            )
            session.commit()
            decision_id = decision.id
        finally:
            session.close()

        checking = SessionLocal()
        try:
            result = service.replay(checking, checking.get(Decision, decision_id))
        finally:
            checking.rollback()
            checking.close()

    assert result["match"] is True
    assert result["cross_border"] is False


def test_the_seeded_cross_border_book_still_replays(session):
    """The regression guard on everything already on file.

    The seed's cross-border decisions were recorded before this change and must
    reproduce identically after it. If re-deriving the order altered any of
    them, the fix would have rewritten history rather than repaired replay.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        rows = [
            row
            for row in session.scalars(select(Decision).order_by(Decision.id))
            if (row.rule_results or {}).get("other_jurisdictions")
        ]
        assert rows, "no cross-border decisions on file — run `make seed`"

        for row in rows:
            result = evidence.replay(row, *_packs_for(session, row))
            assert result["match"] is True, (
                f"seeded decision {row.id} stopped reproducing: {result['differences']}"
            )


def _packs_for(session, decision):
    from app import packs_repo

    governing = packs_repo.by_version(
        session, decision.pack_id, decision.pack_version
    )
    return governing, service._other_packs(session, decision)
