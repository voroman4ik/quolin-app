"""The watch service's database role, and the one thing it cannot do.

§S6's first gate item: *watch deployed separately; an attempted pack write from
the watch role fails at the database.*

This is the file to open when somebody asks "what stops your gazette reader from
editing the rules?". Until Stage 6 the answer was three good arguments — a guard
script that fails CI if a watch module constructs a pack row, a signature check
in `drafts.publish`, and an import boundary — and each of them is a statement
about code that somebody with a shell can edit. This is a statement about
privileges, which they cannot.

Assertions here are made by *connecting as the role*, not by reading a
migration. A grant that was written and never verified is a comment.
"""

from __future__ import annotations

import os
from datetime import date

import pytest
from sqlalchemy import create_engine, text

ROLE = "quolin_watch"

#: The watch process's own connection. Separate from `APP_DATABASE_URL` for the
#: same reason the roles are separate: a deployment where both processes hold
#: the same credential has the separation on the org chart and not in the
#: database.
WATCH_DATABASE_URL = os.getenv(
    "WATCH_DATABASE_URL",
    "postgresql+psycopg://quolin_watch:quolin_watch@localhost:5433/quolin",
)


@pytest.fixture(scope="module")
def watch_conn():
    engine = create_engine(WATCH_DATABASE_URL, future=True, pool_pre_ping=True)
    try:
        with engine.connect() as conn:
            yield conn
    finally:
        engine.dispose()


def _refused(conn, statement: str, **params) -> str:
    """Run something that must fail, and return the reason it did.

    Returned rather than merely asserted so each test can say *which* refusal it
    got. "Insufficient privilege" and "row-level security" are both failures and
    only one of them is the failure that test is about.
    """
    from sqlalchemy.exc import DBAPIError

    with pytest.raises(DBAPIError) as exc:
        conn.execute(text(statement), params)
        conn.commit()
    conn.rollback()
    return str(exc.value)


# --- The gate ---------------------------------------------------------------


def test_the_watch_role_cannot_insert_a_pack(watch_conn):
    """The whole claim, in one statement.

    Not "the application refuses to" — the database refuses, before any code of
    ours is consulted. A watch process compromised end to end still cannot put
    rule content in front of a client.
    """
    reason = _refused(
        watch_conn,
        "INSERT INTO packs (jurisdiction, version, effective_from, body, signed_by) "
        "VALUES ('AU', 999, :today, '{}'::jsonb, 'nobody')",
        today=date.today(),
    )
    assert "permission denied" in reason.lower(), reason


def test_the_watch_role_cannot_update_a_pack(watch_conn):
    """Editing an existing pack is the quieter version of the same attack, and
    the more dangerous one: nobody is looking for a version that did not appear."""
    reason = _refused(watch_conn, "UPDATE packs SET signed_by = 'nobody'")
    assert "permission denied" in reason.lower(), reason


def test_the_watch_role_cannot_delete_a_pack(watch_conn):
    reason = _refused(watch_conn, "DELETE FROM packs")
    assert "permission denied" in reason.lower(), reason


def test_the_watch_role_can_read_packs(watch_conn):
    """Reading is the job. Triage compares publications against pack content, so
    a role that could not read packs could not do the work — and a test that only
    proved it cannot write would pass equally well against a role locked out
    entirely, which would prove nothing about this deployment."""
    count = watch_conn.execute(text("SELECT count(*) FROM packs")).scalar_one()
    assert count > 0, "no packs to read — run `make seed` first"


# --- What it is supposed to be able to do -----------------------------------


def test_the_watch_role_can_record_what_it_found(watch_conn):
    """Its own workflow tables are writable, or the service cannot run at all.

    Cleaned up in a `finally`, because this connection is shared with the tests
    below and a statement that fails halfway leaves the transaction aborted —
    every later assertion would then fail with "current transaction is aborted"
    and prove nothing about privileges.
    """
    try:
        watch_conn.execute(
            text(
                "INSERT INTO watch_sources "
                "(id, jurisdiction, name, url, cadence_days, last_mode, enabled) "
                "VALUES ('test-role-probe', 'AU', 'Probe', '', 7, '', false)"
            )
        )
        watch_conn.execute(
            text(
                "UPDATE watch_sources SET last_mode = 'replay' "
                "WHERE id = 'test-role-probe'"
            )
        )
        watch_conn.execute(text("DELETE FROM watch_sources WHERE id = 'test-role-probe'"))
        watch_conn.commit()
    finally:
        watch_conn.rollback()


def test_the_watch_role_cannot_rewrite_history(watch_conn):
    """`pack_draft_transitions` is append-only for everybody, and the grant says
    so a second time in case the trigger is ever dropped."""
    reason = _refused(watch_conn, "UPDATE pack_draft_transitions SET note = 'edited'")
    assert "permission denied" in reason.lower(), reason


def test_the_watch_role_cannot_edit_the_audit_trail(watch_conn):
    reason = _refused(watch_conn, "DELETE FROM audit_events")
    assert "permission denied" in reason.lower(), reason


# --- The attributes that would make all of the above decorative -------------


def test_the_watch_role_is_not_a_superuser_and_does_not_bypass_rls(watch_conn):
    """Any one of these three attributes turns every grant and every policy above
    into a comment. Asserted rather than assumed, because the failure is silent:
    a role with BYPASSRLS reads exactly like a role that is being filtered."""
    row = watch_conn.execute(
        text(
            "SELECT rolsuper, rolbypassrls, rolcreaterole, rolcreatedb "
            "FROM pg_roles WHERE rolname = :role"
        ),
        {"role": ROLE},
    ).one()
    assert row.rolsuper is False, "the watch role is a superuser"
    assert row.rolbypassrls is False, "the watch role bypasses row-level security"
    assert row.rolcreaterole is False
    assert row.rolcreatedb is False


def test_the_watch_role_does_not_own_the_tables_it_writes(watch_conn):
    """A table's owner can drop its policies and disable its triggers. The append-
    only guarantee on the transition log is worth exactly as much as this."""
    owners = watch_conn.execute(
        text(
            "SELECT tablename, tableowner FROM pg_tables WHERE schemaname = 'public'"
        )
    ).all()
    assert owners, "no tables found"
    mine = [t for t, owner in owners if owner == ROLE]
    assert mine == [], f"the watch role owns tables it should only be granted on: {mine}"
