"""Source SLAs: cadence, failure counting, and paging a named owner.

§S6 asks for per-source check frequency and alert thresholds, and for a source
unreachable for three consecutive checks to page its specialist owner. The
property worth protecting here is narrow and easy to lose:

**A failed check is not a check.** If a timeout advanced `last_checked_at`, a
source that had been dark for a month would show as freshly checked, and the one
thing the currency screen exists to catch would be the one thing it hid.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

import httpx
import pytest
from sqlalchemy import select

from app import source_alerts, tenancy
from app.models import AuditEvent, WatchSource
from app.watch import fetchers, poll, sources

DEMO_TENANT = "demo"
ACTOR = "usr_test_sla"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _a_source(session, **kw) -> WatchSource:
    """A throwaway source row, not one the packs declare.

    Named with a prefix no pack uses so `sources.sync` disables it rather than
    fighting over it, and so a failure here can never be a real source's state.
    """
    row = WatchSource(
        id=kw.pop("id", "test-sla-source"),
        jurisdiction=kw.pop("jurisdiction", "AU"),
        name=kw.pop("name", "A source that exists only in this test"),
        url="https://example.invalid/feed",
        cadence_days=kw.pop("cadence_days", 7),
        owner=kw.pop("owner", "content-au@quolin.example"),
        alert_after_failures=kw.pop("alert_after_failures", 3),
        enabled=True,
        # Every field this fixture's callers reason about, set explicitly.
        #
        # `alerted_at` was the one it left alone, and `page` only pages a
        # breach nobody has been told about — so a row left alerted by an
        # earlier run made `test_an_outage_pages_once_but_keeps_showing` fail on
        # the *first* page, which reads as the paging being broken rather than
        # as the fixture inheriting yesterday's state.
        #
        # Found by running the watch sweep by hand while reproducing FP3-03,
        # which is the ordinary way this table gets touched between runs. A
        # fixture that establishes some of a row's state and inherits the rest
        # is a test whose result depends on what ran before it.
        alerted_at=kw.pop("alerted_at", None),
        last_error=kw.pop("last_error", ""),
        last_failed_at=kw.pop("last_failed_at", None),
    )
    for key, value in kw.items():
        setattr(row, key, value)
    session.merge(row)
    session.flush()
    return session.get(WatchSource, row.id)


# --- What pack content declares reaches the row -----------------------------


def test_every_declared_source_names_an_owner(session):
    """An alert with nobody's name on it is one everybody assumes is somebody
    else's. Ownership is pack content, so this is a content assertion."""
    declared = sources.declared(session, date.today())
    assert declared, "no sources declared — run `make seed` first"
    for spec in declared:
        assert spec["owner"], f"{spec['id']} declares no owner"
        assert spec["alert_after_failures"] >= 1


def test_sync_carries_ownership_from_content_onto_the_row(session):
    """A pack edit reassigning a source is how a specialist hands it over. A row
    that kept the old name would page somebody who has left."""
    sources.sync(session, date.today())
    declared = {s["id"]: s for s in sources.declared(session, date.today())}
    for source_id, spec in declared.items():
        row = session.get(WatchSource, source_id)
        assert row is not None
        assert row.owner == spec["owner"]
        assert row.alert_after_failures == spec["alert_after_failures"]


# --- A failed check is not a check ------------------------------------------


def test_a_failed_check_does_not_advance_the_check_timestamp(session):
    """The single most misleading thing this screen could say is that a dead
    source was checked."""
    checked = _now() - timedelta(days=3)
    row = _a_source(session, last_checked_at=checked, last_mode=sources.REPLAY)

    sources.mark_failed(session, row.id, _now(), "HTTP 503 from example.invalid")
    session.flush()

    assert row.last_checked_at == checked, "a timeout must not count as a check"
    assert row.consecutive_failures == 1
    assert row.last_error == "HTTP 503 from example.invalid"
    assert row.last_failed_at is not None


def test_a_success_clears_the_failure_count_and_the_page_marker(session):
    """A source answering again is not in breach — and leaving `alerted_at` set
    would mean the *next* outage went unannounced."""
    row = _a_source(session, consecutive_failures=3, alerted_at=_now(), last_error="down")

    sources.mark_checked(session, row.id, _now(), sources.REPLAY)
    session.flush()

    assert row.consecutive_failures == 0
    assert row.alerted_at is None
    assert row.last_error == ""


def test_breach_uses_the_sources_own_threshold(session):
    """A daily feed and a monthly one earn their alert at different speeds."""
    monthly = _a_source(session, id="test-sla-monthly", alert_after_failures=2)
    weekly = _a_source(session, id="test-sla-weekly", alert_after_failures=3)

    for _ in range(2):
        sources.mark_failed(session, monthly.id, _now(), "no answer")
        sources.mark_failed(session, weekly.id, _now(), "no answer")
    session.flush()

    assert sources.is_breaching(monthly), "two misses is the monthly source's threshold"
    assert not sources.is_breaching(weekly), "three is the weekly source's"


# --- Cadence ----------------------------------------------------------------


def test_a_source_checked_within_its_cadence_is_not_due(session):
    row = _a_source(session, cadence_days=30, last_checked_at=_now() - timedelta(days=2))
    assert sources.due([row], _now()) == []


def test_a_source_never_checked_is_always_due(session):
    """Waiting a cadence before the first read would leave a new source silently
    unwatched for as long as its cadence."""
    row = _a_source(session, cadence_days=30, last_checked_at=None)
    assert sources.due([row], _now()) == [row]


def test_a_disabled_source_is_never_due(session):
    row = _a_source(session, enabled=False, last_checked_at=None)
    assert sources.due([row], _now()) == []


# --- Paging -----------------------------------------------------------------


def test_the_page_names_the_owner_the_outage_and_the_reason(session):
    """It is read at 7am by somebody deciding whether it is theirs."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        row = _a_source(
            session,
            id="test-sla-paged",
            consecutive_failures=3,
            last_error="HTTP 503 from example.invalid",
        )
        sent = source_alerts.page(session)

    mine = [s for s in sent if s["source_id"] == row.id]
    assert mine, "a source past its threshold was not paged"
    message = mine[0]["message"]
    assert "content-au@quolin.example" in message
    assert "3 consecutive checks" in message
    assert "HTTP 503" in message


def test_an_outage_pages_once_but_keeps_showing(session):
    """An alert every ten minutes gets filtered into a folder nobody opens — and
    silence after the first page is how an outage gets forgotten. Both."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        row = _a_source(session, id="test-sla-once", consecutive_failures=3)
        first = source_alerts.page(session)
        second = source_alerts.page(session)
        still_open = source_alerts.open_breaches(session)

    assert any(s["source_id"] == row.id for s in first)
    assert not any(s["source_id"] == row.id for s in second), "re-paged the same outage"
    assert any(b["source_id"] == row.id for b in still_open), "outage vanished once paged"


def test_paging_writes_an_audit_row(session):
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        _a_source(session, id="test-sla-audited", consecutive_failures=4)
        source_alerts.page(session)
        session.flush()
        rows = session.scalars(
            select(AuditEvent)
            .where(AuditEvent.action == "watch.source.unreachable")
            .order_by(AuditEvent.id.desc())
        ).all()

    assert any("test-sla-audited" in r.subject for r in rows)


def test_a_source_with_no_owner_still_pages_and_says_so(session):
    """Silence would be the wrong answer: an unowned source that has gone dark is
    worse than an owned one, not better."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        _a_source(session, id="test-sla-unowned", owner="", consecutive_failures=3)
        sent = source_alerts.page(session)

    mine = [s for s in sent if s["source_id"] == "test-sla-unowned"]
    assert mine
    assert "names no owner" in mine[0]["message"]


# --- Reading a feed ---------------------------------------------------------

ATOM = """<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <title>A regulator</title>
  <entry>
    <title>Consultation on distribution obligations</title>
    <link href="https://example.invalid/cp-401"/>
    <published>2026-08-01T09:00:00Z</published>
    <summary>We propose to change the concentration limit.</summary>
  </entry>
</feed>"""

RSS = """<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0"><channel>
  <title>A regulator</title>
  <item>
    <title>Guidance note on suitability</title>
    <link>https://example.invalid/gn-12</link>
    <pubDate>Tue, 05 Aug 2026 11:30:00 GMT</pubDate>
    <description>Wording only.</description>
  </item>
</channel></rss>"""


def test_atom_and_rss_parse_into_the_same_shape_the_fixture_holds():
    """One shape for both modes, so nothing downstream can behave differently in
    the mode that is harder to test."""
    today = date(2026, 8, 24)
    atom = fetchers.parse(ATOM, kind=fetchers.ATOM, source_id="s1", today=today)
    rss = fetchers.parse(RSS, kind=fetchers.RSS, source_id="s1", today=today)

    for items in (atom, rss):
        assert len(items) == 1
        item = items[0]
        assert set(item) == {"source_id", "title", "summary", "url", "published_at"}
        assert item["source_id"] == "s1"
        assert item["title"]
        assert item["url"].startswith("https://example.invalid/")

    assert atom[0]["published_at"] == "2026-08-01"
    assert rss[0]["published_at"] == "2026-08-05"


def test_an_entry_with_an_unreadable_date_is_kept_not_dropped():
    """A real feed does this — ESMA's publishes entries with an empty pubDate.
    Dropping them would turn our parser's strictness into a missed rule change."""
    feed = RSS.replace(
        "<pubDate>Tue, 05 Aug 2026 11:30:00 GMT</pubDate>", "<pubDate></pubDate>"
    )
    today = date(2026, 8, 24)
    items = fetchers.parse(feed, kind=fetchers.RSS, source_id="s1", today=today)
    assert len(items) == 1
    assert items[0]["published_at"] == today.isoformat()


def test_a_hostile_or_broken_feed_is_a_named_failure_not_a_crash():
    with pytest.raises(fetchers.FetchError) as exc:
        fetchers.parse("<not xml", kind=fetchers.RSS, source_id="s1", today=date.today())
    assert "did not parse" in str(exc.value)


def test_a_page_source_is_read_by_comparing_a_digest():
    """§S13 changed this, and the old assertion was the finding.

    A landing page is what a human opens and it is not a feed — so this used to
    refuse to read one at all, which meant eight of the nine shipped sources
    could never be checked live and "CURRENT across all four regimes" was a
    claim nothing could earn.

    A page is read now, by digesting it and comparing with last time. That says
    *something changed* rather than *what was published*, which is exactly the
    signal the triage tiers already work on. What it must not do is invent a
    publication: the item it raises says plainly that a page moved.
    """
    page = "<html><body><h1>Guidance</h1><p>Something new.</p></body></html>"
    transport = httpx.MockTransport(lambda request: httpx.Response(200, text=page))
    spec = {
        "id": "s1",
        "url": "https://example.invalid/news",
        "content_hash": "a-different-digest-from-last-time",
    }
    with httpx.Client(transport=transport) as client:
        result = fetchers.fetch(spec, today=date.today(), client=client)

    assert result.content_hash, "the digest has to come back so it can be stored"
    assert len(result.items) == 1
    assert "changed" in result.items[0]["title"]
    assert result.items[0]["url"] == spec["url"]


def test_an_unchanged_page_raises_nothing():
    """The other half. A source that published nothing is a healthy source."""
    page = "<html><body>Unchanged.</body></html>"
    transport = httpx.MockTransport(lambda request: httpx.Response(200, text=page))
    with httpx.Client(transport=transport) as client:
        first = fetchers.fetch(
            {"id": "s1", "url": "https://example.invalid/n", "content_hash": ""},
            today=date.today(),
            client=client,
        )
        # The first ever read records the digest and raises nothing — there is
        # no previous state, and reporting "changed" on first sight would give
        # every source a spurious item the day it was added.
        assert first.items == []

        again = fetchers.fetch(
            {
                "id": "s1",
                "url": "https://example.invalid/n",
                "content_hash": first.content_hash,
            },
            today=date.today(),
            client=client,
        )
    assert again.items == []


def test_a_digest_ignores_what_a_page_changes_on_every_read():
    """Otherwise every poll reports a change and the queue becomes noise."""
    first = fetchers.digest(
        '<html><head><script>var t=1</script></head><body>'
        '<p>Rules</p><span>14:32:07</span><meta name="csrf-token" content="abc123">'
        "</body></html>"
    )
    second = fetchers.digest(
        '<html><head><script>var t=2</script></head><body>'
        '<p>Rules</p><span>09:11:44</span><meta name="csrf-token" content="zzz999">'
        "</body></html>"
    )
    assert first == second, "a clock and a token made the page look different"

    moved = fetchers.digest("<html><body><p>Rules, amended</p></body></html>")
    assert moved != first, "a real edit was digested as unchanged"


def test_a_source_that_cannot_be_polled_at_all_has_no_adapter():
    """MANUAL is content saying "a machine cannot read this".

    Some publications need a login, or the URL is a search form with no stable
    result. Inventing a poll for one of those produces a source that reports
    itself checked every hour and notices nothing, which is worse than saying
    so.
    """
    with pytest.raises(fetchers.NoAdapter):
        fetchers.fetch(
            {
                "id": "s1",
                "url": "https://example.invalid/secure",
                "polling_status": "MANUAL",
            },
            today=date.today(),
        )

    # And a source with nothing usable to fetch.
    with pytest.raises(fetchers.NoAdapter):
        fetchers.fetch({"id": "s2", "url": ""}, today=date.today())


def test_an_http_error_names_the_host_and_the_status():
    transport = httpx.MockTransport(lambda request: httpx.Response(503))
    with httpx.Client(transport=transport) as client:
        with pytest.raises(fetchers.FetchError) as exc:
            fetchers.fetch(
                {"id": "s1", "feed": {"kind": "rss", "url": "https://example.invalid/f"}},
                today=date.today(),
                client=client,
            )
    assert "503" in str(exc.value)
    assert "example.invalid" in str(exc.value)


def test_a_timeout_is_a_failure_with_a_duration_in_it():
    def timeout(request):
        raise httpx.ConnectTimeout("too slow", request=request)

    with httpx.Client(transport=httpx.MockTransport(timeout)) as client:
        with pytest.raises(fetchers.FetchError) as exc:
            fetchers.fetch(
                {"id": "s1", "feed": {"kind": "rss", "url": "https://example.invalid/f"}},
                today=date.today(),
                client=client,
            )
    assert "no answer within" in str(exc.value)


# --- A live sweep -----------------------------------------------------------


def test_a_live_sweep_records_what_answered_and_what_did_not(session, monkeypatch):
    """A partly failed sweep is a successful poll with recorded failures, not an
    error. One regulator being down must not stop the other three being read."""
    monkeypatch.setenv("WATCH_MODE", "live")

    reachable = {
        "id": "test-live-ok",
        "jurisdiction": "EU",
        "name": "A publisher that answers",
        "url": "https://example.invalid/news",
        "cadence_days": 7,
        "owner": "content-eu@quolin.example",
        "alert_after_failures": 3,
        "feed": {"kind": "rss", "url": "https://example.invalid/ok.xml"},
    }
    dark = {**reachable, "id": "test-live-dark", "name": "A publisher that is down"}
    dark["feed"] = {"kind": "rss", "url": "https://example.invalid/dark.xml"}

    monkeypatch.setattr(sources, "declared", lambda s, on: [reachable, dark])
    monkeypatch.setattr(sources, "vocabulary", lambda s, on: {"EU": []})

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("ok.xml"):
            return httpx.Response(200, text=RSS)
        return httpx.Response(500)

    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        result = poll.poll(session, date.today(), client=client)
    session.flush()

    assert result["mode"] == "live"
    assert result["sources_failed"] == 1
    assert result["failures"][0]["source_id"] == "test-live-dark"

    ok = session.get(WatchSource, "test-live-ok")
    down = session.get(WatchSource, "test-live-dark")
    assert ok.last_checked_at is not None and ok.last_mode == "live"
    assert down.consecutive_failures == 1
    assert down.last_checked_at is None, "a failed fetch must not count as a check"
    session.rollback()


def test_live_mode_refuses_only_when_nothing_can_be_read(session, monkeypatch):
    """A sweep where some sources have feeds and some do not is a real sweep with
    recorded failures. Refusing the whole thing would throw away the half that
    works."""
    monkeypatch.setenv("WATCH_MODE", "live")
    monkeypatch.setattr(
        sources,
        "declared",
        lambda s, on: [
            {
                "id": "test-live-none",
                "jurisdiction": "AU",
                "name": "No feed declared",
                "url": "https://example.invalid/news",
                "cadence_days": 7,
                "owner": "content-au@quolin.example",
                "alert_after_failures": 3,
                "feed": None,
            }
        ],
    )
    with pytest.raises(poll.LiveModeUnavailable) as exc:
        poll.poll(session, date.today())
    assert "no declared source names a feed" in str(exc.value)
    session.rollback()


def test_a_source_with_no_feed_is_a_backlog_item_not_an_outage(session, monkeypatch):
    """Paging a specialist because *we* never wrote the adapter would tell them
    their network is broken when it is our content backlog. Both are worth
    reporting; only one is worth waking somebody for."""
    monkeypatch.setenv("WATCH_MODE", "live")
    with_feed = {
        "id": "test-gap-ok",
        "jurisdiction": "EU",
        "name": "Readable",
        "url": "https://example.invalid/news",
        "cadence_days": 7,
        "owner": "content-eu@quolin.example",
        "alert_after_failures": 3,
        "feed": {"kind": "rss", "url": "https://example.invalid/ok.xml"},
    }
    # §S13: "no feed block" is no longer a gap — a source with a URL is read as
    # a page. What is still a gap is a source a machine genuinely cannot read,
    # which pack content declares by marking it MANUAL.
    without = {
        **with_feed,
        "id": "test-gap-none",
        "name": "Needs a login",
        "feed": None,
        "polling_status": "MANUAL",
    }

    monkeypatch.setattr(sources, "declared", lambda s, on: [with_feed, without])
    monkeypatch.setattr(sources, "vocabulary", lambda s, on: {"EU": []})

    # Start from no history for these two ids.
    #
    # In live mode a sweep only checks sources that are *due*, so a row left
    # behind by an earlier run of this file — with `last_checked_at` set inside
    # its cadence — is skipped, and the assertion below sees an empty list for
    # a reason that has nothing to do with adapters. This test asserts what a
    # sweep does when it runs; it has to be able to make one run.
    for source_id in (with_feed["id"], without["id"]):
        stale = session.get(WatchSource, source_id)
        if stale is not None:
            session.delete(stale)
    session.flush()

    with httpx.Client(
        transport=httpx.MockTransport(lambda r: httpx.Response(200, text=RSS))
    ) as client:
        result = poll.poll(session, date.today(), client=client)
    session.flush()

    assert result["sources_failed"] == 0, "a missing adapter is not an outage"
    assert [g["source_id"] for g in result["no_adapter"]] == ["test-gap-none"]

    gap = session.get(WatchSource, "test-gap-none")
    assert gap.consecutive_failures == 0
    assert not sources.is_breaching(gap)
    session.rollback()


# --- The sweep a scheduler actually runs -------------------------------------


def test_the_sweep_pages_once_and_stays_non_zero_while_a_source_is_dark(session):
    """The script, run the way a scheduler runs it.

    This is here because the unit tests above all passed while the script itself
    was broken: it entered the tenancy context around a transaction that had
    already begun, so `app.tenant_id` was never bound and row-level security
    refused the audit row the page writes. The sweep died after committing the
    poll, which means every outage would have gone unannounced. Nothing short of
    running the real script would have caught it.

    The publisher is made unreachable with a proxy pointed at a closed local
    port. That is a real connection failure — the same code path a regulator's
    outage takes — without this test depending on the internet.
    """
    import os
    import subprocess
    import sys

    feeds = [s for s in sources.declared(session, date.today()) if s["feed"]]
    assert feeds, (
        "no pack declares a readable feed, so there is no source this test can "
        "watch fail. See the `feed` block in packs/eu_v1.json."
    )
    source_id = feeds[0]["id"]

    root = __import__("pathlib").Path(__file__).resolve().parents[2]

    # Exactly what `infra/compute.tf` gives the watch container, and nothing
    # else. FP3-03: this used to be `{**os.environ, ...}`, which on a laptop and
    # in CI carries `DATABASE_URL` and `APP_DATABASE_URL` — so the one test that
    # ran the real script proved it works in an environment production does not
    # provide, and the sweep's call into `notify_tenants` (which needs both) was
    # invisible here for exactly as long as it existed.
    import sys as _sys

    _sys.path.insert(0, str(root))
    from scripts.task_environment import task_definitions

    env = {name: "" for name in sorted(task_definitions()["watch"].names)}
    env["PATH"] = os.environ.get("PATH", "/usr/bin:/bin")
    env["HOME"] = os.environ.get("HOME", "/tmp")
    env["WATCH_DATABASE_URL"] = os.environ.get(
        "WATCH_DATABASE_URL",
        "postgresql+psycopg://quolin_watch:quolin_watch@localhost:5433/quolin",
    )
    env["WATCH_MODE"] = "live"
    # Not in the task definition, and correctly not: this is how the test makes
    # a publisher unreachable. In production the equivalent is the regulator's
    # site being down, which needs no variable.
    env["HTTP_PROXY"] = "http://127.0.0.1:9"
    env["HTTPS_PROXY"] = "http://127.0.0.1:9"

    def sweep():
        # Due again each time: a failed check deliberately does not advance
        # `last_checked_at`, but the first *successful* one would, and the point
        # here is the failure path.
        session.execute(
            __import__("sqlalchemy").text(
                "UPDATE watch_sources SET last_checked_at = now() - interval '90 days' "
                "WHERE id = :id"
            ),
            {"id": source_id},
        )
        session.commit()
        # The interpreter running these tests, not `uv run`. The Makefile
        # target invokes `api/.venv/bin/python` for the same reason: `uv run`
        # from the repository root resolves against the root project, which has
        # none of the API's dependencies — and, worse, goes away and tries to
        # build an environment while it works that out.
        return subprocess.run(
            [sys.executable, "-m", "scripts.watch_tick"],
            cwd=root,
            env=env,
            capture_output=True,
            text=True,
        )

    row = session.get(WatchSource, source_id)
    before = (row.consecutive_failures, row.alerted_at, row.last_checked_at)
    try:
        def paged_lines(run):
            """Only the pages about *this* source.

            Scoped, because another source being in breach — a real one left
            unreachable by an earlier sweep — would otherwise make this test
            fail for a reason that has nothing to do with what it asserts.
            """
            return [
                ln for ln in run.stdout.splitlines() if "PAGED" in ln and source_id in ln
            ]

        first = sweep()
        assert "1 in a row" in first.stdout, first.stdout + first.stderr
        assert paged_lines(first) == [], "paged on the first miss"

        sweep()
        third = sweep()

        assert third.returncode == 2, (
            f"a sweep with a source in breach should exit 2, got {third.returncode}\n"
            + third.stdout
            + third.stderr
        )
        assert paged_lines(third), third.stdout
        assert "in breach" in third.stderr

        fourth = sweep()
        assert paged_lines(fourth) == [], "re-paged the same outage"
        assert fourth.returncode == 2, "went quiet while the source was still dark"
        assert "in breach" in fourth.stderr

        # FP3-03. The sweep saw a breach and wrote it down, holding only
        # `WATCH_DATABASE_URL` — which is the thing that could not happen
        # before, because the previous version tried to enumerate tenants and
        # enqueue webhooks from here and needed two connection strings this
        # environment deliberately does not contain.
        #
        # Asserted in the one test that produces a *real* breach. A replay sweep
        # cannot: `sources.sync` disables any source no pack declares, and every
        # declared source is re-checked and reset on every replay run, so the
        # only way to a genuine breach is a genuine connection failure — which
        # is what the dead proxy above is.
        from app.models import SourceBreach

        session.expire_all()
        written = session.scalars(
            __import__("sqlalchemy")
            .select(SourceBreach)
            .where(SourceBreach.source_id == source_id)
        ).all()
        assert written, (
            "the sweep saw a source in breach and recorded nothing. The "
            "notification path starts here and the watch task holds no other "
            "credential to start it with."
        )
    finally:
        session.expire_all()
        row = session.get(WatchSource, source_id)
        row.consecutive_failures, row.alerted_at, row.last_checked_at = before
        row.last_error = ""
        row.last_failed_at = None
        session.commit()


# --- The currency screen, scoped to one customer ----------------------------


def test_the_currency_screen_covers_the_regimes_this_firm_is_in(client, session):
    """§S6: the screen gains tenancy.

    A firm licensed only in Australia reading a rollup that goes amber because an
    ESMA feed is late learns to ignore the rollup. The badge has to mean *your*
    monitoring or it means nothing.
    """
    from app.models import Tenant

    with tenancy.acting_as(DEMO_TENANT):
        tenant = session.get(Tenant, DEMO_TENANT)
        declared = set((tenant.config or {}).get("jurisdictions") or [])
    assert declared, "the demo firm declares no regimes — run `make seed` first"

    got = client.get("/currency")
    assert got.status_code == 200
    body = got.json()

    shown = {j["jurisdiction"] for j in body["jurisdictions"]}
    assert shown == declared, f"showed {sorted(shown)}, this firm is in {sorted(declared)}"
    assert set(body["regimes"]) == declared


def test_a_firm_that_has_not_said_which_regimes_sees_all_of_them(session):
    """Not the same as seeing none. A screen reporting perfect currency because
    it is watching nothing is the worst answer available here."""
    from app.watch import currency

    with tenancy.acting_as(DEMO_TENANT):
        everything = currency.overview(session, regimes=None)
    assert len(everything["jurisdictions"]) >= 4
    assert everything["regimes"] is None, "an unscoped answer must say so"


def test_a_source_that_has_stopped_answering_is_shown_as_such(session):
    """"We are behind" and "the publisher is down" are different answers, and a
    customer asking why their regime is stale deserves the right one."""
    from app.watch import currency

    with tenancy.acting_as(DEMO_TENANT):
        row = session.scalars(
            select(WatchSource).where(WatchSource.jurisdiction == "AU")
        ).first()
        assert row is not None
        before = (row.consecutive_failures, row.last_error)
        row.consecutive_failures = row.alert_after_failures
        row.last_error = "HTTP 503 from example.invalid"
        session.flush()
        try:
            body = currency.overview(session, regimes={"AU"})
            au = next(j for j in body["jurisdictions"] if j["jurisdiction"] == "AU")
            assert any(u["id"] == row.id for u in au["unreachable"])
            assert body["unreachable"] >= 1
        finally:
            row.consecutive_failures, row.last_error = before
            session.flush()


def test_an_unreachable_source_is_never_shown_as_current(session):
    """Found by looking at the screen rather than by a test failing.

    Freshness is derived from the last *successful* check, and a failed check
    deliberately does not advance it — so a source that went dark yesterday still
    sits inside its cadence and reads CURRENT. On a monthly source that is a
    green badge on a dead feed for a month, which is the exact situation this
    screen exists to make visible.
    """
    row = _a_source(
        session,
        id="test-sla-dark-but-recent",
        cadence_days=30,
        last_checked_at=_now() - timedelta(days=1),
        last_mode=sources.REPLAY,
    )
    assert sources.freshness(row.last_checked_at, row.cadence_days, _now()) == sources.CURRENT

    row.consecutive_failures = row.alert_after_failures
    row.last_error = "no answer"
    session.flush()

    described = {s["id"]: s for s in sources.describe(session)}
    assert described[row.id]["freshness"] != sources.CURRENT
    assert described[row.id]["breaching"] is True
