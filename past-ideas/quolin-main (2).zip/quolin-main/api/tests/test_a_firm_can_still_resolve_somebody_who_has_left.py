"""Belonging to a firm is not the same fact as holding a role in it.

Migration 0047. A firm could revoke somebody's last grant and, in doing so,
make every audit event naming that person unresolvable to itself — because
`user_reachable` answered "may this firm see this person?" with "has it granted
them a role?", and revoking deletes the row.

FP3-13 had already settled the principle: nothing in production deletes a
person, because decisions, overrides and audit events all name one. Revoking the
last grant went around it, and a second sequence reached the same state with no
revocation at all — `identity.invitation.consumed` names the invited person as
its actor, correctly, at a moment when they hold nothing.

Membership is now its own create-only table and the reachability policies read
it. What this file has to prove is that the fix did the one thing and not the
other: that a person who has left still *resolves*, and that they can no longer
*do* anything, and that a firm still cannot see somebody it has never had.

Everything here is proved by performing the act and reading the result. No test
asserts on the shape of a policy.
"""

from __future__ import annotations

import uuid

import pytest
from conftest import DEMO_TENANT, PUBLISHER_EMAIL, VIEWER_EMAIL, sign_in
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import identity, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import ApiClient, AuditEvent, Tenant, TenantMember, User, UserRole

ACTOR = "apc_seed"
NEIGHBOUR = "neighbour"


@pytest.fixture(scope="module", autouse=True)
def a_neighbouring_firm():
    """A second firm, created here rather than assumed to exist.

    The cross-tenant tests below need one, and `neighbour` is created by a
    fixture in `test_rls.py` — which sorts *after* this file, so on a database
    built from zero it does not exist yet and granting a role in it fails the
    foreign key. That passed on a developer machine for exactly one reason: the
    tenant was left behind by an earlier run. CI, which starts from nothing
    every time, found it on the first attempt.

    The same defect this repository keeps finding, committed by the person
    writing it up. Depending on another module's fixture is depending on
    collection order.
    """
    owner = OwnerSessionLocal()
    try:
        if owner.get(Tenant, NEIGHBOUR) is None:
            owner.add(
                Tenant(id=NEIGHBOUR, name="Neighbour Wealth", region="ap-southeast-2")
            )
            owner.commit()
    finally:
        owner.close()


@pytest.fixture(scope="module")
def operator():
    """`quolin_operator`, the only role that may provision or revoke."""
    with TestClient(app) as c:
        yield sign_in(c, PUBLISHER_EMAIL)


@pytest.fixture
def a_newcomer(operator):
    """Somebody this firm has just provisioned, through the real route.

    Provisioned rather than inserted, because the thing under test is what the
    provisioning path writes. Their grants are removed afterwards and the person
    is not: deleting them would be the very act this migration exists to stop
    anybody doing accidentally.
    """
    email = f"leaver-{uuid.uuid4().hex[:8]}@quolin.example"
    created = operator.post(
        "/admin/users", json={"email": email, "display_name": "A Leaver"}
    )
    assert created.status_code == 200, created.text
    user_id = created.json()["id"]
    try:
        yield user_id, email
    finally:
        owner = OwnerSessionLocal()
        try:
            with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
                for grant in owner.scalars(
                    select(UserRole).where(UserRole.user_id == user_id)
                ):
                    owner.delete(grant)
                owner.commit()
        finally:
            owner.close()


def _resolves(user_id: str) -> User | None:
    """What this firm can see of a person, under its own scope and policies."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            return session.get(User, user_id)


# --------------------------------------------------------- the finding, twice


def test_revoking_a_last_grant_leaves_the_person_resolvable(operator, a_newcomer):
    """The defect, reproduced as a sequence somebody performs on a Tuesday.

    Grant, revoke, and the person is still somebody this firm can look up. Before
    0047 the second call made every audit row naming them point at nobody.
    """
    user_id, email = a_newcomer

    granted = operator.post(f"/admin/users/{user_id}/roles", json={"role": "viewer"})
    assert granted.status_code == 200, granted.text
    grant_id = granted.json()["id"]

    revoked = operator.post(f"/admin/roles/{grant_id}/revoke")
    assert revoked.status_code == 200, revoked.text

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            live = session.scalars(
                select(UserRole).where(UserRole.user_id == user_id)
            ).all()
    assert live == [], "the revocation did not remove the grant"

    person = _resolves(user_id)
    assert person is not None, (
        "revoking somebody's last role made them unresolvable to the firm — "
        "every audit event naming them now points at nobody"
    )
    assert person.email == email


def test_somebody_who_has_only_accepted_an_invitation_resolves(a_newcomer):
    """The second sequence, which no screen could have guarded.

    `identity.invitation.consumed` names the invited person as its actor at a
    moment when they hold no grant. The fixture has provisioned them and granted
    nothing, which is exactly that moment.
    """
    user_id, _email = a_newcomer

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            held = session.scalars(
                select(UserRole).where(UserRole.user_id == user_id)
            ).all()
    assert held == [], "the fixture granted something, so this proves nothing"

    assert _resolves(user_id) is not None, (
        "a person between accepting an invitation and being granted a role is "
        "invisible to the firm that invited them"
    )


def test_the_audit_trail_names_nobody_this_firm_cannot_resolve(operator, a_newcomer):
    """The assertion that failed, run against the sequence that broke it.

    `test_attribution.py` makes this claim over whatever the suite happens to
    have produced. This makes it after deliberately performing the act.
    """
    user_id, _ = a_newcomer
    granted = operator.post(f"/admin/users/{user_id}/roles", json={"role": "viewer"})
    operator.post(f"/admin/roles/{granted.json()['id']}/revoke")

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            actors = set(session.scalars(select(AuditEvent.actor)))
            people = set(session.scalars(select(User.id)))
            machines = set(session.scalars(select(ApiClient.id)))

    assert actors <= people | machines, (
        f"audit rows naming nobody: {sorted(actors - people - machines)}"
    )


def test_the_roster_still_lists_somebody_whose_last_role_was_revoked(
    operator, a_newcomer
):
    """Revoking must not remove its own undo.

    The administration screen listed grant-holders, so before the roster was
    moved onto `tenant_members` a revocation made the person vanish from the one
    screen an administrator would use to re-grant the role or to suspend them.
    Found by revoking a last grant through the UI.

    They are listed with an empty `roles`, which is a true statement: still one
    of this firm's people, currently holding nothing.
    """
    user_id, email = a_newcomer
    granted = operator.post(f"/admin/users/{user_id}/roles", json={"role": "viewer"})
    operator.post(f"/admin/roles/{granted.json()['id']}/revoke")

    listed = operator.get("/admin/users")
    assert listed.status_code == 200, listed.text
    person = next(
        (p for p in listed.json()["users"] if p["email"] == email), None
    )

    assert person is not None, (
        "revoking somebody's last role removed them from the screen that would "
        "re-grant it — the act deleted its own undo"
    )
    assert person["roles"] == [], (
        "the roster is reporting a grant that was revoked"
    )
    # And the acts that remain possible are the ones that should be.
    assert person["status"] == "active"


# ------------------------------------------- and it took nothing else with it


def test_revoking_still_takes_the_authority_away(operator, a_newcomer):
    """The half that must not have been softened.

    The rejected alternative was to keep revoked grants as soft-deleted rows and
    match those, which puts "is this grant live?" into every query that reads the
    table — and the failure mode of missing one is a revoked role that still
    authorises. Membership deliberately confers nothing, and this is the
    assertion that says so.
    """
    user_id, _ = a_newcomer
    granted = operator.post(f"/admin/users/{user_id}/roles", json={"role": "viewer"})
    assert granted.status_code == 200

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            before = {g.role for g in identity.roles_for(session, user_id)}
    assert before == {"viewer"}

    operator.post(f"/admin/roles/{granted.json()['id']}/revoke")

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            after = {g.role for g in identity.roles_for(session, user_id)}
    assert after == set(), (
        "the person still holds a role after it was revoked — membership is "
        "conferring authority, which it must never do"
    )


def test_a_membership_cannot_be_deleted(a_newcomer):
    """Append-only, because the alternative is the defect with an extra step.

    A membership somebody could delete is a membership somebody could delete to
    make an actor stop resolving.
    """
    user_id, _ = a_newcomer
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            row = session.scalars(
                select(TenantMember).where(TenantMember.user_id == user_id)
            ).one()
            session.delete(row)
            with pytest.raises(Exception) as exc:
                session.flush()
            assert "append" in str(exc.value).lower() or "denied" in str(exc.value).lower()
        finally:
            session.rollback()
            session.close()


# ------------------------------------------------ isolation, still fail-closed


def test_a_firm_cannot_see_somebody_it_has_never_had(a_newcomer):
    """The property the old policy existed for, asserted against the new one.

    `users` has no `tenant_id` and cannot have one — a consultant serving three
    firms is one human. The policy is what makes a staff list tenant-private, and
    replacing the table it reads must not have widened it.
    """
    user_id, _ = a_newcomer

    with tenancy.acting_as(NEIGHBOUR), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            seen = session.get(User, user_id)

    assert seen is None, (
        "another firm can see a person it has never granted anything and never "
        "provisioned — the reachability policy has been widened, not moved"
    )


def test_a_neighbour_cannot_enumerate_this_firms_people():
    """The same property in the direction somebody would actually attack it.

    Not "can it read one row I named", but "what does the whole table look like
    from over there" — a policy that leaked would leak in bulk.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            ours = {u.id for u in session.scalars(select(User))}

    with tenancy.acting_as(NEIGHBOUR), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            theirs = {u.id for u in session.scalars(select(User))}
            their_members = {
                m.user_id for m in session.scalars(select(TenantMember))
            }

    assert ours, "this firm can see nobody, so this proves nothing"
    leaked = theirs - their_members
    assert leaked == set(), (
        f"a neighbouring firm can see people it has no membership for: {sorted(leaked)}"
    )


def test_a_person_serving_two_firms_is_visible_to_both(operator, a_newcomer):
    """The case `users` has no `tenant_id` for, and it still works.

    A membership is per firm, so somebody the demo tenant provisioned and the
    neighbour granted appears to both — and nothing about the first firm's
    revocation changes what the second can see.
    """
    user_id, _ = a_newcomer
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(NEIGHBOUR), tenancy.acting_as_user(ACTOR):
            with identity.bootstrapping():
                identity.grant_role(
                    owner,
                    user_id=user_id,
                    role="viewer",
                    granted_by=identity.BOOTSTRAP,
                )
            owner.commit()

        with tenancy.acting_as(NEIGHBOUR), tenancy.acting_as_user(ACTOR):
            with SessionLocal() as session:
                assert session.get(User, user_id) is not None, (
                    "granting a role in a second firm did not make the person "
                    "visible there"
                )
        assert _resolves(user_id) is not None, (
            "a grant in another firm changed what this one can see"
        )
    finally:
        with tenancy.acting_as(NEIGHBOUR), tenancy.acting_as_user(ACTOR):
            for grant in owner.scalars(
                select(UserRole).where(UserRole.user_id == user_id)
            ):
                owner.delete(grant)
            owner.commit()
        owner.close()


def test_a_grant_cannot_exist_without_the_membership_it_implies(a_newcomer):
    """`grant_role` writes both, so no call site can get half of it right.

    A grant without a membership is somebody holding a role in a firm that
    cannot see them, which fails closed in the worst direction: they would be
    refused by the policies while the access review reported them as holding
    access.
    """
    user_id, _ = a_newcomer
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            with identity.bootstrapping():
                identity.grant_role(
                    owner,
                    user_id=user_id,
                    role="operator",
                    granted_by=identity.BOOTSTRAP,
                )
            owner.flush()
            member = owner.scalars(
                select(TenantMember).where(TenantMember.user_id == user_id)
            ).all()
        assert len(member) == 1, (
            f"a grant produced {len(member)} membership rows, expected exactly one"
        )
    finally:
        owner.rollback()
        owner.close()


def test_the_seeded_firm_can_still_see_its_own_staff():
    """The backfill, checked against somebody the suite depends on.

    A migration that moved the predicate and forgot to bring the existing rows
    would show up as every seeded person vanishing, and the failure would land
    in tests about something else entirely.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            viewer = identity.find_by_email(owner, VIEWER_EMAIL)
    finally:
        owner.close()
    assert viewer is not None
    assert _resolves(viewer.id) is not None, (
        "a seeded member of the firm is not resolvable — the backfill missed them"
    )
