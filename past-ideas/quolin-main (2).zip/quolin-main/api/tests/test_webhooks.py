"""Outbound webhooks, and the gate item about an endpoint that never answers.

S4's gate names one behaviour for this module by itself: *webhook delivery
survives a dead endpoint (retries, then dead-letters visibly)*. Every clause is
tested below, and "visibly" is the one that matters most — a silently dropped
alert is worse than one that never existed, because the customer believes they
are being told.

The sender is injected throughout, which is what lets a test express "this
endpoint fails four times and then works" as four lines rather than as a fixture
that runs a server. What is being tested is the retry policy, and a real socket
would add nothing to that while making the test slow and flaky.

The signature tests verify our own output with `webhooks.verify` — the same
function `docs/integrations.md` describes to a customer's engineer. A signing
scheme nobody has checked from the receiving side is a signing scheme with an
off-by-one in it.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import select

from app import tenancy, webhooks
from app.identity import new_id
from app.models import WebhookDelivery, WebhookEndpoint


def now_clock() -> datetime:
    """The clock the retry tests drive `run_once` with.

    A function, not a module constant, and that is not a style preference.
    `enqueue` stamps `next_attempt_at` with the real time; `due()` compares the
    two. A clock fixed when this module is *imported* is therefore behind every
    row written after collection — which is all of them, once the suite has run
    for a second — and `due()` then silently returns nothing.

    This file held a literal `2026-08-24 12:00`. It passed all morning and six
    tests began failing at noon UTC on the day it named, for reasons that had
    nothing to do with webhooks. Replacing it with an import-time `now()` moved
    the failure rather than fixing it: the tests passed alone and failed in the
    full suite, because by then the constant was two seconds old.

    A second ahead, deliberately: `enqueue` and this would otherwise race on
    equal microseconds, and `due()` compares with `<=`.
    """
    return datetime.now(timezone.utc) + timedelta(seconds=1)


@pytest.fixture
def endpoint(session):
    """One tenant's endpoint, removed afterwards.

    Created through the model rather than the API so that these tests are about
    delivery rather than about the route that registers an endpoint — that has
    its own tests.
    """
    with tenancy.acting_as(DEMO_TENANT):
        row = WebhookEndpoint(
            id=new_id("whe"),
            url="https://case-system.example/quolin",
            label="Test case system",
            secret=webhooks.new_secret(),
            events=[],
            status="active",
        )
        session.add(row)
        session.commit()
    yield row
    with tenancy.acting_as(DEMO_TENANT):
        session.query(WebhookDelivery).filter_by(endpoint_id=row.id).delete()
        session.delete(row)
        session.commit()


class Recorder:
    """A sender that answers however the test tells it to, and remembers.

    `answers` is consumed one per call; when it runs out the last one repeats,
    so "fails forever" is `[500]` and "fails twice then works" is `[500, 500,
    200]`.
    """

    def __init__(self, answers):
        self.answers = list(answers)
        self.calls = []

    def __call__(self, url, body, headers):
        self.calls.append({"url": url, "body": body, "headers": headers})
        answer = self.answers.pop(0) if len(self.answers) > 1 else self.answers[0]
        if isinstance(answer, Exception):
            raise answer
        return answer


# ------------------------------------------------------------------ signing --


def test_a_signature_verifies_against_the_algorithm_we_document():
    secret = webhooks.new_secret()
    body = webhooks.canonical({"b": 2, "a": 1})
    assert webhooks.verify(secret, body, webhooks.sign(secret, body))


def test_a_signature_does_not_verify_under_a_different_secret():
    body = webhooks.canonical({"a": 1})
    signature = webhooks.sign(webhooks.new_secret(), body)
    assert not webhooks.verify(webhooks.new_secret(), body, signature)


def test_a_signature_does_not_cover_a_body_somebody_edited():
    secret = webhooks.new_secret()
    signature = webhooks.sign(secret, webhooks.canonical({"outcome": "REFER"}))
    assert not webhooks.verify(secret, webhooks.canonical({"outcome": "ALLOW"}), signature)


def test_an_old_signature_is_refused_however_valid_it_was():
    """The timestamp is inside the signed material, not beside it.

    A signature over the body alone is replayable forever by anyone who captures
    one — which for a decision webhook means replaying last year's ALLOW at a
    customer's case system today.
    """
    secret = webhooks.new_secret()
    body = webhooks.canonical({"a": 1})
    old = webhooks.sign(secret, body, at=datetime.now(timezone.utc) - timedelta(hours=2))

    assert not webhooks.verify(secret, body, old)
    # And it is the age that refuses it, not the contents.
    assert webhooks.verify(secret, body, old, tolerance_seconds=10_000)


def test_the_signed_bytes_are_the_bytes_that_are_sent():
    """The single most common reason a first webhook integration does not work,
    and it is our fault when it happens: a payload serialised one way for signing
    and another way for sending."""
    first = webhooks.canonical({"z": 1, "a": {"n": 2, "m": 3}})
    second = webhooks.canonical({"a": {"m": 3, "n": 2}, "z": 1})
    assert first == second
    assert " " not in first


# ------------------------------------------------------------------ enqueue --


def test_enqueueing_writes_a_row_and_opens_no_socket(session, endpoint):
    """Nothing in a request path may wait on a customer's endpoint.

    A determination has been made and recorded; telling somebody about it is a
    separate obligation with a separate failure mode. If `enqueue` sent, a slow
    case system would slow down every determination in that tenant.
    """
    with tenancy.acting_as(DEMO_TENANT):
        created = webhooks.enqueue(
            session,
            event="decision.recorded",
            subject="decision:1",
            payload={"decision_id": 1, "outcome": "BLOCK"},
        )
        session.commit()

    assert len(created) == 1
    assert created[0].status == "pending"
    assert created[0].attempts == 0


def test_an_endpoint_that_subscribed_to_other_events_is_not_told(session, endpoint):
    with tenancy.acting_as(DEMO_TENANT):
        endpoint.events = ["pack.published"]
        session.commit()
        created = webhooks.enqueue(
            session, event="decision.recorded", subject="decision:1", payload={}
        )
        session.commit()
    assert created == []


def test_an_endpoint_that_chose_nothing_is_told_everything(session, endpoint):
    """The safe default for an alerting channel: a tenant who has not chosen
    wants to hear everything rather than nothing."""
    assert endpoint.events == []
    with tenancy.acting_as(DEMO_TENANT):
        for event in webhooks.EVENTS:
            assert webhooks.enqueue(session, event=event, subject="x", payload={})
        session.rollback()


def test_an_unknown_event_name_raises_rather_than_subscribing_nobody(session, endpoint):
    """A typo that silently matched no endpoint would leave a customer not being
    told about something they asked to be told about — the exact failure this
    module exists to prevent."""
    with tenancy.acting_as(DEMO_TENANT):
        with pytest.raises(ValueError) as raised:
            webhooks.enqueue(session, event="decision.recored", subject="x", payload={})
    assert "decision.recorded" in str(raised.value)


# ----------------------------------------------------- the gate: a dead endpoint --


def test_a_dead_endpoint_is_retried_then_dead_lettered_visibly(session, endpoint):
    """S4's gate for this module, in one test.

    Retried the documented number of times, with the backoff growing between
    attempts, and then left in the log marked `dead` with the last error still
    readable. Not deleted, not silently abandoned: a customer must be able to
    see that we tried and that their endpoint never answered.
    """
    with tenancy.acting_as(DEMO_TENANT):
        webhooks.enqueue(
            session, event="decision.recorded", subject="decision:9", payload={"id": 9}
        )
        session.commit()

        never = Recorder([ConnectionError("connection refused")])
        clock = now_clock()
        for expected_attempt in range(1, webhooks.MAX_ATTEMPTS + 1):
            tally = webhooks.run_once(session, send=never, now=clock)
            row = session.scalars(
                select(WebhookDelivery).where(WebhookDelivery.endpoint_id == endpoint.id)
            ).one()
            assert row.attempts == expected_attempt

            if expected_attempt < webhooks.MAX_ATTEMPTS:
                assert row.status == "pending", "gave up too early"
                assert row.next_attempt_at > clock, "no backoff between attempts"
                clock = row.next_attempt_at
            else:
                assert row.status == "dead"
                assert tally["dead"] == 1

        assert never.calls, "it never actually tried"
        assert len(never.calls) == webhooks.MAX_ATTEMPTS
        # Visibly: the reason is still there to be read.
        assert "connection refused" in row.last_error
        assert row.delivered_at is None
        assert row.next_attempt_at is None, "a dead delivery must not be picked up again"


def test_a_dead_delivery_is_not_attempted_again(session, endpoint):
    """Otherwise a permanently broken endpoint is an infinite worker loop."""
    with tenancy.acting_as(DEMO_TENANT):
        webhooks.enqueue(session, event="decision.recorded", subject="s", payload={})
        session.commit()

        never = Recorder([ConnectionError("nope")])
        clock = now_clock()
        for _ in range(webhooks.MAX_ATTEMPTS):
            webhooks.run_once(session, send=never, now=clock)
            clock += timedelta(hours=2)

        before = len(never.calls)
        webhooks.run_once(session, send=never, now=clock + timedelta(days=1))
        assert len(never.calls) == before, "a dead delivery was retried"


def test_an_endpoint_that_recovers_is_delivered_to(session, endpoint):
    """The other half of the gate. A retry policy that never succeeds is a retry
    policy nobody has tested."""
    with tenancy.acting_as(DEMO_TENANT):
        webhooks.enqueue(session, event="queue.referred", subject="decision:3", payload={})
        session.commit()

        flaky = Recorder([503, 500, ConnectionError("reset"), 200])
        clock = now_clock()
        for _ in range(4):
            webhooks.run_once(session, send=flaky, now=clock)
            row = session.scalars(
                select(WebhookDelivery).where(WebhookDelivery.endpoint_id == endpoint.id)
            ).one()
            if row.status == "delivered":
                break
            clock = row.next_attempt_at

    assert row.status == "delivered"
    assert row.attempts == 4
    assert row.delivered_at is not None
    assert row.last_error == "", "a delivered row still carries an error message"


def test_a_redirect_is_not_success(session, endpoint):
    """A receiver that answers 302 has not taken it, whatever it meant by that."""
    with tenancy.acting_as(DEMO_TENANT):
        webhooks.enqueue(session, event="pack.published", subject="AU v3", payload={})
        session.commit()
        webhooks.run_once(session, send=Recorder([302]), now=now_clock())
        row = session.scalars(
            select(WebhookDelivery).where(WebhookDelivery.endpoint_id == endpoint.id)
        ).one()
    assert row.status == "pending"
    assert row.last_error == "HTTP 302"


def test_every_success_code_is_accepted(session, endpoint):
    """204 is what a well-written receiver answers, and it has no body."""
    for code in (200, 201, 202, 204):
        with tenancy.acting_as(DEMO_TENANT):
            webhooks.enqueue(session, event="pack.staged", subject=f"s{code}", payload={})
            session.commit()
            webhooks.run_once(session, send=Recorder([code]), now=now_clock())
            row = session.scalars(
                select(WebhookDelivery)
                .where(WebhookDelivery.subject == f"s{code}")
            ).one()
            assert row.status == "delivered", code


def test_an_endpoint_with_deliveries_on_file_cannot_simply_be_deleted(session, endpoint):
    """The delivery log outlives the endpoint, and the database is what says so.

    `run_once` carries a branch for a delivery whose endpoint has vanished, and
    writing a test for it is how I found out it cannot happen: the foreign key
    refuses to delete an endpoint any delivery still points at. That is the
    stronger guarantee and the right one — a customer asking "did you tell us
    about decision 4,182" must not be answered with a row pointing at nothing.

    Retiring an endpoint is therefore a status change rather than a deletion,
    which is what `status` is for. The defensive branch stays, because it is one
    schema change away from being reachable again and its cost is four lines.
    """
    from sqlalchemy.exc import IntegrityError

    with tenancy.acting_as(DEMO_TENANT):
        webhooks.enqueue(session, event="source.stale", subject="au-asic-rg", payload={})
        session.commit()

        with pytest.raises(IntegrityError):
            session.delete(endpoint)
            session.flush()
        session.rollback()

    # Retiring it instead stops new deliveries without disturbing the old ones.
    with tenancy.acting_as(DEMO_TENANT):
        endpoint.status = "retired"
        session.commit()
        assert webhooks.enqueue(
            session, event="source.stale", subject="another", payload={}
        ) == []
        assert session.scalars(
            select(WebhookDelivery).where(WebhookDelivery.endpoint_id == endpoint.id)
        ).all()
        endpoint.status = "active"
        session.commit()


# --------------------------------------------------------------- the payload --


def test_the_request_carries_the_headers_a_receiver_needs(session, endpoint):
    """Event, delivery id and signature. The delivery id is what lets a receiver
    make their own handling idempotent, which is the thing we ask of them in
    exchange for retrying."""
    # The real clock, with no offset at all — unlike `now_clock()`, which the
    # retry tests nudge a second ahead. `verify` refuses a signature outside its
    # tolerance, which is the whole point of putting the timestamp inside the
    # signed material, so a clock that is even deliberately wrong would fail for
    # the right reason and tell us nothing about the headers.
    with tenancy.acting_as(DEMO_TENANT):
        webhooks.enqueue(
            session,
            event="decision.recorded",
            subject="decision:11",
            payload={"decision_id": 11, "outcome": "REFER"},
        )
        session.commit()
        sender = Recorder([200])
        webhooks.run_once(session, send=sender, now=datetime.now(timezone.utc))

    sent = sender.calls[0]
    assert sent["headers"][webhooks.EVENT_HEADER] == "decision.recorded"
    assert sent["headers"][webhooks.DELIVERY_HEADER].startswith("whd_")
    assert sent["headers"]["Content-Type"] == "application/json"
    assert webhooks.verify(
        endpoint.secret, sent["body"], sent["headers"][webhooks.SIGNATURE_HEADER]
    )


def test_deliveries_drain_in_the_order_things_happened(session, endpoint):
    """A customer reading their case system should see a determination before
    the override that reversed it."""
    with tenancy.acting_as(DEMO_TENANT):
        for i in range(3):
            webhooks.enqueue(
                session, event="decision.recorded", subject=f"decision:{i}", payload={"i": i}
            )
            session.commit()

        sender = Recorder([200])
        webhooks.run_once(session, send=sender, now=now_clock())

    subjects = [
        webhooks.canonical({"i": i}) for i in range(3)
    ]
    assert [c["body"] for c in sender.calls] == subjects


# ------------------------------------------------------------- the producers --
#
# The module above is machinery. These are the tests that it is actually fed —
# for three commits it was not, and a gate item claimed as closed rested on a
# module nothing called.


def test_a_determination_queues_a_delivery(session, endpoint):
    """The wiring that makes the rest of this file matter."""
    from app import identity, service

    with tenancy.acting_as(DEMO_TENANT):
        person = identity.find_by_email(session, "dana.whitfield@quolin.example")
        session.commit()

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(person.id):
        decision = service.evaluate(session, client_id="margaret-wu", asset_id="BTC")
        session.commit()

    with tenancy.acting_as(DEMO_TENANT):
        queued = session.scalars(
            select(WebhookDelivery).where(WebhookDelivery.endpoint_id == endpoint.id)
        ).all()

    events = {d.event for d in queued}
    assert "decision.recorded" in events
    body = next(d for d in queued if d.event == "decision.recorded").payload
    assert body["decision_id"] == decision.id
    assert body["outcome"] == decision.outcome
    assert body["pack_id"] and body["pack_version"]


def test_a_referral_is_its_own_event_not_a_flag_on_the_first(session, endpoint):
    """A firm routes determinations to one place and things needing a person to
    another. Making them filter one stream by outcome would be handing them our
    schema to work around."""
    from app import identity, service

    with tenancy.acting_as(DEMO_TENANT):
        person = identity.find_by_email(session, "dana.whitfield@quolin.example")
        session.commit()

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(person.id):
        decision = service.evaluate(session, client_id="priya-nair", asset_id="ETH")
        session.commit()
    assert decision.outcome == "REFER", "this test needs a referral to be about one"

    with tenancy.acting_as(DEMO_TENANT):
        events = {
            d.event
            for d in session.scalars(
                select(WebhookDelivery).where(WebhookDelivery.endpoint_id == endpoint.id)
            )
        }
    assert {"decision.recorded", "queue.referred"} <= events


def test_a_tenant_with_no_endpoints_still_gets_its_determination(session):
    """A notification must never be able to fail the thing that caused it.

    The decision has been made and written to an append-only chain; telling
    somebody about it is a separate obligation with a separate failure mode.
    """
    from app import identity, service

    with tenancy.acting_as(DEMO_TENANT):
        person = identity.find_by_email(session, "dana.whitfield@quolin.example")
        session.commit()

    # No `endpoint` fixture here — deliberately nothing subscribed.
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(person.id):
        decision = service.evaluate(session, client_id="tom-askew", asset_id="SOL")
        session.commit()
    assert decision.id and decision.outcome == "BLOCK"


def test_a_broken_notification_does_not_fail_the_determination(session, monkeypatch):
    """The defensive path, exercised rather than assumed.

    If enqueueing raised — a schema change, a bad payload — a determination that
    had already been recorded would appear to fail to its caller, and the client
    would retry and record it twice.
    """
    from app import identity, service
    from app import webhooks as wh

    def explode(*_args, **_kwargs):
        raise RuntimeError("the webhook table is on fire")

    monkeypatch.setattr(wh, "enqueue", explode)

    with tenancy.acting_as(DEMO_TENANT):
        person = identity.find_by_email(session, "dana.whitfield@quolin.example")
        session.commit()

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(person.id):
        decision = service.evaluate(session, client_id="margaret-wu", asset_id="BTC")
        session.commit()

    assert decision.id, "a failing notification took the determination down with it"

    # And the failure is audited rather than swallowed. A notification nobody was
    # told about and nobody recorded failing is how a customer discovers months
    # later that they were never being told.
    from app.models import AuditEvent

    with tenancy.acting_as(DEMO_TENANT):
        session.expire_all()
        actions = set(session.scalars(select(AuditEvent.action)))
    assert "webhook.enqueue_failed" in actions
