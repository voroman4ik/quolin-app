"""The asynchronous execution tier exists in the deployment, not only in `make`.

The Gate A audit's sixth finding, and it is the 27-August "written but never
called" finding at topology level. Five scripts appeared in the Makefile and in
zero Terraform files:

* `deliver_webhooks` — every `decision.recorded`, `queue.referred` and
  `pack.published` a customer had subscribed to sat in the table unsent, while
  `docs/integrations.md` told them in writing that a dropped alert is worse than
  one that never existed *because you believe you are being told*;
* `artefact_worker` — §S7 moved rendering off the request path and nothing was
  on the other side of it;
* `bulk_worker` — a run planned by a pack becoming effective stayed `planned`,
  so the delta report and the pinned-tenant UAT flow were both dead, and pinning
  is the answer to "how do you control vendor changes?";
* `settle_packs` — a signed, published, future-dated pack never took force;
* `batch_sweep` — the file drop was never swept.

`docs/deployment.md` already stated the rule that would have caught two of them:
*"anything added to that table needs adding to
`aws_iam_role_policy.watch_scheduler` in the same change"*. A rule stated in
prose is a rule enforced by whoever remembers it.

**This file is the assertion the finding asks for, in both directions**, and
`scripts/deployed_workers.py` is the mechanical form of it that CI runs. The
tests below are deliberately thin over that module rather than a second
implementation of the same comparison: two implementations of one rule is two
places for it to be wrong, and this repository has the guard-list history to
prove it.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from scripts.deployed_workers import (  # noqa: E402
    DEFERRED,
    check,
    make_targets,
    module_of,
    operating_table,
    scheduled_and_permitted,
)
from scripts.task_environment import task_definitions  # noqa: E402

INFRA = REPO / "infra"
MAKEFILE = REPO / "Makefile"
DEPLOYMENT = REPO / "docs" / "deployment.md"

#: The five the finding names. Named here rather than derived, because the point
#: is that these specific things were undeployed and a derived list would have
#: been empty at the moment it mattered.
THE_FIVE = (
    "scripts.deliver_webhooks",
    "scripts.artefact_worker",
    "scripts.bulk_worker",
    "scripts.settle_packs",
    "scripts.batch_sweep",
)


def _agreement():
    return check(infra_dir=INFRA, makefile=MAKEFILE, deployment_md=DEPLOYMENT)


def test_the_table_the_schedules_and_the_policy_agree():
    """The whole rule, in one assertion, the way CI runs it."""
    problems, _ = _agreement()
    assert problems == [], "\n\n".join(problems)


@pytest.mark.parametrize("module", THE_FIVE)
def test_each_of_the_five_is_scheduled_or_says_why_not(module):
    """Deployed, or deferred in the operating table with a reason beside it.

    "Not deployed" with nothing next to it reads exactly like an omission, which
    is what four of these were: nobody decided not to deploy them.
    """
    scheduled, _ = scheduled_and_permitted(INFRA)
    if module in scheduled:
        return

    targets = make_targets(MAKEFILE)
    rows = operating_table(DEPLOYMENT)
    named = [
        row for row in rows if targets.get(row["command"]) == module
    ]
    assert named, (
        f"{module} is neither scheduled in infra/ nor named in "
        "docs/deployment.md's operating table. It has a make target and nothing "
        "runs it, which is this finding exactly."
    )
    row = named[0]
    assert row["deferred"], (
        f"the operating table says `make {row['command']}` runs "
        f"{row['cadence']!r} and nothing schedules it."
    )
    reason = row["row"].split(DEFERRED, 1)[1].strip(" |—-")
    assert len(reason) > 40, (
        f"`make {row['command']}` is deferred with no real reason: {reason!r}"
    )


@pytest.mark.parametrize("module", THE_FIVE[:4])
def test_the_four_that_are_deployed_are_scheduled_and_permitted(module):
    """Both halves, because either alone is the silent failure.

    A schedule with no IAM permission is denied on every firing and nothing in a
    plan says so. A permission with no schedule is authority nobody reviewed the
    need for.
    """
    scheduled, permitted = scheduled_and_permitted(INFRA)
    assert module in scheduled, f"{module} is not scheduled by anything in infra/"
    assert scheduled[module] in permitted, (
        f"aws_ecs_task_definition.{scheduled[module]} runs {module} on a "
        "schedule and is not in aws_iam_role_policy.watch_scheduler — a "
        "schedule that exists and is denied every time it fires."
    )


def test_every_scheduled_task_has_a_launch_failure_alarm():
    """EventBridge reports success when `RunTask` is *accepted*.

    So the IAM omission this file's other tests catch at build time has a
    runtime twin, and it is the one that matters on the deploy where the build
    check was skipped. `local.scheduled_rules` is the list the alarms are built
    from; a rule missing from it is a schedule whose failure to start is
    invisible.
    """
    text = "\n".join(path.read_text() for path in sorted(INFRA.rglob("*.tf")))
    block = text.split("scheduled_rules = {", 1)
    assert len(block) == 2, "no local.scheduled_rules in infra/"
    alarmed = {
        line.split("=", 1)[1].strip()
        for line in block[1].split("}", 1)[0].splitlines()
        if "=" in line
    }

    scheduled, _ = scheduled_and_permitted(INFRA)
    for module, resource in sorted(scheduled.items()):
        rule = f"aws_cloudwatch_event_rule.{resource}.name"
        # The watch sweep's rule is named for the sweep rather than for its task.
        alternatives = {rule, "aws_cloudwatch_event_rule.watch_sweep.name"}
        assert alternatives & alarmed, (
            f"aws_ecs_task_definition.{resource} runs {module} on a schedule "
            "with no FailedInvocations alarm. EventBridge reports success when "
            "RunTask is accepted, so a denied invocation is silent without one."
        )


def test_a_worker_serving_every_firm_holds_the_connection_that_can_enumerate():
    """Or it serves one firm and reports success, which is worse than not running.

    Under FORCE row-level security a query for "all tenants" returns the one in
    scope. `deliver_webhooks`, `settle_packs` and `batch_sweep` defaulted to
    `tenancy.configured_tenant()` — so deployed as they were, each would have
    served whichever firm `QUOLIN_TENANT` named and exited 0. That is Q-01's
    shape: an enumeration that returns one thing and a caller that reads it as
    everything.

    They enumerate through `maintenance.active_tenant_ids` now, which needs the
    owner connection — the same trade `health` and `comparison` already make,
    and `scripts/guard_task_credentials.py` is where it is reviewed.
    """
    tasks = task_definitions(INFRA)
    scheduled, _ = scheduled_and_permitted(INFRA)

    for module, resource in sorted(scheduled.items()):
        if module == "scripts.watch_tick":
            # The one exception, and it is invariant 6. The sweep holds
            # `WATCH_DATABASE_URL` alone; giving it the owner connection is what
            # `guard_no_watch_in_engine.sh` fails the build over.
            continue
        assert "DATABASE_URL" in tasks[resource].names, (
            f"aws_ecs_task_definition.{resource} runs {module} for every firm "
            "and holds no connection that can enumerate them. It would serve "
            "one and report success."
        )


def test_the_module_link_ignores_arguments_and_not_the_module():
    """The comparison is keyed on the module, and this says why.

    The deployed comparison task passes `--json` and `make comparison-report`
    does not — the same job, formatted for a log rather than for a person. A
    check comparing whole command lines would have failed on that, and the
    lesson somebody takes from a check that fails on a harmless difference is to
    loosen it.
    """
    assert module_of(("python", "-m", "scripts.x", "--json")) == "scripts.x"
    assert module_of(("python", "-m", "scripts.x")) == "scripts.x"
    assert module_of(("sh", "-c", "uvicorn app.main:app")) is None
    assert module_of(()) is None


# ------------------------------------------------------- duplicates, H4 --
#
# The check collapsed modules into dictionaries — `documented[module] = row`
# and `scheduled[module] = resource` — so a second row or a second schedule for
# the same job silently replaced the first and the report described one of them.
# A document that says two things about one job, and a check that reads only
# one of them, is worse than a document that says nothing: the operator reads
# whichever row their eye lands on and the guard agrees with them either way.
#
# Written against synthetic inputs rather than by mutating the real tree,
# because what is under test is the *detection* and the real tree has no
# duplicates to find. `tmp_path` copies are cheap; a mutated repository is not.


def _table(rows: list[str]) -> str:
    """A `docs/deployment.md` holding exactly the operating-table rows given."""
    return "\n".join(
        [
            "# Deployment",
            "",
            "### The scheduled jobs",
            "",
            "| Command | Cadence | Exit codes |",
            "|---|---|---|",
            *rows,
            "",
            "## Something else",
            "",
        ]
    )


def test_two_rows_for_one_command_are_reported_and_not_collapsed(tmp_path):
    """The same job documented twice, most likely with one cadence stale.

    Raised rather than returned as a problem, because `operating_table` cannot
    produce a coherent list of rows to hand the rest of the check — and the
    caller's answer to a raise is exit 2, "this could not be checked", which is
    the honest verdict rather than a pass over a document nobody can read.
    """
    document = tmp_path / "deployment.md"
    document.write_text(
        _table(
            [
                "| `make health-alerts` | every 5 minutes | 2 when anything is wrong |",
                "| `make health-alerts` | daily | 2 when anything is wrong |",
            ]
        )
    )

    with pytest.raises(ValueError) as raised:
        operating_table(document)
    assert "two rows for `make health-alerts`" in str(raised.value)


def test_two_rows_resolving_to_one_module_are_reported(tmp_path):
    """Different commands, one script. The collapse that had no marker at all.

    The rows above share a command and a reader might spot them. These do not:
    two `make` targets that run the same module read as two jobs, and every
    check in this module links a row to the deployment *through the module*, so
    the two rows are two answers to every question it asks.
    """
    makefile = tmp_path / "Makefile"
    makefile.write_text(
        "health-alerts:\n\tpython -m scripts.health_alerts\n\n"
        "health-check:\n\tpython -m scripts.health_alerts\n"
    )
    document = tmp_path / "deployment.md"
    document.write_text(
        _table(
            [
                "| `make health-alerts` | every 5 minutes | 2 when anything is wrong |",
                "| `make health-check` | daily | 2 when anything is wrong |",
            ]
        )
    )

    problems, _ = check(infra_dir=INFRA, makefile=makefile, deployment_md=document)
    duplicates = [p for p in problems if "documents scripts.health_alerts twice" in p]
    assert duplicates, (
        "two operating-table rows resolving to one module were collapsed into "
        f"one dictionary entry rather than reported:\n{problems}"
    )


def test_two_schedules_for_one_module_are_reported(tmp_path):
    """One job, two cadences, nothing reconciling them.

    Terraform accepts it happily — the two task definitions have different
    resource names — and `scheduled[module] = resource` kept whichever sorted
    last. The job then runs twice on schedules that disagree, and the operating
    table can describe only one of them.
    """
    infra = tmp_path / "infra"
    infra.mkdir()
    (infra / "main.tf").write_text(
        '''
resource "aws_ecs_task_definition" "health" {
  family = "health"
  container_definitions = jsonencode([{
    name    = "health"
    command = ["python", "-m", "scripts.health_alerts"]
  }])
}

resource "aws_ecs_task_definition" "health_again" {
  family = "health-again"
  container_definitions = jsonencode([{
    name    = "health-again"
    command = ["python", "-m", "scripts.health_alerts"]
  }])
}

resource "aws_cloudwatch_event_target" "a" {
  task_definition_arn = aws_ecs_task_definition.health.arn
}

resource "aws_cloudwatch_event_target" "b" {
  task_definition_arn = aws_ecs_task_definition.health_again.arn
}

resource "aws_iam_role_policy" "watch_scheduler" {
  policy = jsonencode({
    Resource = [
      aws_ecs_task_definition.health.arn_without_revision,
      aws_ecs_task_definition.health_again.arn_without_revision,
    ]
  })
}
'''
    )

    with pytest.raises(ValueError) as raised:
        scheduled_and_permitted(infra)
    assert "both run scripts.health_alerts on a schedule" in str(raised.value)


def test_the_real_tree_has_none_of_these():
    """The other half of every duplicate check.

    Three detectors that never fire on the tree they run against are three
    detectors nobody would notice had broken. This is what makes the three
    above worth having and this one worth reading: the real repository is
    asserted clean by the same code paths.
    """
    rows = operating_table(DEPLOYMENT)
    commands = [row["command"] for row in rows]
    assert len(commands) == len(set(commands)), (
        f"the real operating table repeats a command: {sorted(commands)}"
    )

    targets = make_targets(MAKEFILE)
    documented = [targets[c] for c in commands if c in targets]
    assert len(documented) == len(set(documented)), (
        f"the real operating table documents one module twice: {sorted(documented)}"
    )

    scheduled, _ = scheduled_and_permitted(INFRA)
    assert len(scheduled) == len(set(scheduled.values())), (
        "two schedules in infra/ point at task definitions running one module"
    )


# ---------------------------------------------- the task that never ran, H6 --


def _infra_text() -> str:
    return "\n".join(path.read_text() for path in sorted(INFRA.rglob("*.tf")))


def test_a_task_that_stops_without_an_exit_code_reaches_a_person():
    """H6. The gap between the two alarms that existed.

    `task_stopped_badly` matches `containers.exitCode = [{"anything-but": 0}]`,
    and an EventBridge field filter requires the field to be present — so it
    matches a container that ran and exited, and not one that never ran. An
    image that will not pull, a task that cannot be placed, a secret ARN the
    execution role may not read: all three stop the task with `stoppedReason`
    set and no exit code.

    `schedule_never_fired` does not cover it either. It reads
    `FailedInvocations`, which counts EventBridge failing to *start* the task,
    and EventBridge succeeded — `RunTask` was accepted and the failure happened
    afterwards, inside ECS.

    So a scheduled job could execute no line of code and page nobody. Narrow,
    and the whole of the asynchronous tier sits behind it.
    """
    text = _infra_text()
    assert 'resource "aws_cloudwatch_event_rule" "task_never_started"' in text, (
        "nothing in infra/ matches a task that stopped without an exit code. "
        "`task_stopped_badly` cannot: an anything-but filter requires the field "
        "to be present, and a container that never ran has no exit code."
    )
    assert '"exists" : false' in text or '"exists": false' in text, (
        "the rule exists and does not match on the *absence* of an exit code, "
        "which is the only thing that distinguishes this incident"
    )


def test_both_stop_rules_may_publish_to_the_pager():
    """A rule missing from the topic policy fires and is refused, silently.

    The same shape as a task definition missing from
    `aws_iam_role_policy.watch_scheduler` — the thing exists, the thing is
    denied every time it acts, and nothing in a plan or a log says so. Asserted
    because adding the second rule without adding it here would have produced
    exactly that: an alarm that looks deployed and reaches nobody.
    """
    text = _infra_text()
    policy = text.split('resource "aws_sns_topic_policy" "pager_accepts_events"', 1)
    assert len(policy) == 2, "no aws_sns_topic_policy.pager_accepts_events in infra/"
    body = policy[1]

    for rule in ("task_stopped_badly", "task_never_started"):
        assert f"aws_cloudwatch_event_rule.{rule}.arn" in body, (
            f"aws_cloudwatch_event_rule.{rule} is not named in the pager's topic "
            "policy, so SNS refuses its publish and the page is never sent."
        )
