"""An artefact template may format what it is given and nothing else.

`renderer.py` built its Jinja environment with `jinja2.Environment`, which
permits a template to walk from any object it is handed to the interpreter:

    {{ decision.__class__.__init__.__globals__ }}

Every template under `TEMPLATE_DIR` ships in this repository and goes through
review, so nothing hostile is being rendered today and the exploitability is
low. What makes the one-line swap worth making anyway is where §S7 says
templates are going: *return formats are pack content, engineering is the
pipeline*. `artefact_templates` already lives in the pack body, and the day a
template arrives as content rather than as a file in this repository, a plain
environment turns rule content into code execution — arriving through the pack
workflow, which is not a change anyone would review as a security change.

`SandboxedEnvironment` governs what a template may *reach*;
`select_autoescape(["html"])` governs what it may *emit*. Both are wanted and
both are asserted here, because a swap that quietly dropped escaping would trade
one hole for another.
"""

from __future__ import annotations

import pytest
from jinja2.exceptions import SecurityError
from jinja2.sandbox import SandboxedEnvironment

from app.artefacts import renderer


class _Passed:
    """Stands in for any object a template is handed — a decision, a pack."""

    def __init__(self) -> None:
        self.name = "A Client"


def test_the_environment_is_a_sandboxed_one() -> None:
    assert isinstance(renderer._env, SandboxedEnvironment), (
        "artefact templates render in a plain Jinja environment, which can "
        "reach the interpreter through any object passed to it"
    )


def test_autoescaping_survived_the_swap() -> None:
    """The sandbox must not have arrived at the cost of escaping."""
    rendered = renderer._env.from_string("{{ value }}").render(
        value="<script>alert(1)</script>"
    )
    # `from_string` has no filename, so `select_autoescape` cannot classify it;
    # what matters is that the policy is still installed for the `.html`
    # templates the renderer actually loads.
    assert renderer._env.autoescape, "autoescaping was dropped"
    assert rendered is not None


def test_a_template_cannot_walk_out_of_an_object_it_is_given() -> None:
    """The escape the sandbox exists to refuse, attempted directly."""
    template = renderer._env.from_string("{{ passed.__class__.__init__.__globals__ }}")

    with pytest.raises(SecurityError):
        template.render(passed=_Passed())


def test_a_template_cannot_reach_the_interpreter_through_a_subclass_walk() -> None:
    """The other half of the standard walk, which ends at `os.system`."""
    template = renderer._env.from_string(
        "{{ passed.__class__.__mro__[1].__subclasses__() }}"
    )

    with pytest.raises(SecurityError):
        template.render(passed=_Passed())


def test_an_ordinary_template_still_renders() -> None:
    """The control: the sandbox refuses the walk and nothing else.

    Every real template formats attributes off the objects it is handed, which
    is exactly what must go on working.
    """
    rendered = renderer._env.from_string("Client: {{ passed.name }}").render(
        passed=_Passed()
    )
    assert rendered == "Client: A Client"


def test_the_shipped_templates_all_still_load() -> None:
    """Nothing in the repository relied on what the sandbox now refuses."""
    names = renderer._env.list_templates()
    assert names, "no artefact templates found at all"
    for name in names:
        renderer._env.get_template(name)
