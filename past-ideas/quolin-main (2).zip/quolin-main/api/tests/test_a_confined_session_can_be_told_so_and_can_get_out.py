"""FP3-12: the two ways a live session refuses, and how a client is meant to act.

Stage 13 gave the API two states that are not "signed out" and had, on the web,
exactly one answer between them — throw the person back to the lock screen.

**Confined.** `MFA_REQUIRED_ROLES` names four roles; a session holding one with
no verified second factor may reach four paths and nothing else. Enrolment was
one of them and had no screen, so a privileged account's first sign-in produced
403s on everything with nothing anywhere saying what to do about it.

**Stale.** `authenticated_at` is when a credential was last presented, and
signing, publishing, provisioning and the advance policy all demand one from the
last few minutes. The refusal is a 401 carrying `X-Quolin-Reauth: required`, and
a client that reads only the status logs the person out and loses their draft.

Both halves are asserted here from the outside, through the API a browser
actually talks to, because the client work in `web/` is only correct if these
are the answers it is reading.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from conftest import (
    ADMIN_EMAIL,
    DEMO_TENANT,
    TEST_PASSWORD,
    VIEWER_EMAIL,
    second_factor_code,
    sign_in,
)
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import auth, identity, tenancy, totp
from app.db import OwnerSessionLocal
from app.main import app
from app.models import AuthSession, MfaCredential, UserRole

ACTOR = "apc_seed"


# ------------------------------------------------------------ FP3-12(a) ----


@pytest.fixture
def a_privileged_account_with_no_authenticator():
    """A seeded person handed a role that demands a second factor they lack.

    This is the state a real firm's first approver is in on their first morning,
    and it cannot be waited for in a suite whose seeded privileged accounts are
    all enrolled — so it is manufactured, and everything it creates is removed
    afterwards. The credential in particular: leaving one behind would silently
    change what every other test's `sign_in` as this person has to type.
    """
    owner = OwnerSessionLocal()
    grant_id = None
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            person = identity.find_by_email(owner, VIEWER_EMAIL)
            assert person is not None, "the seeded viewer is missing"
            with identity.bootstrapping():
                grant = identity.grant_role(
                    owner,
                    user_id=person.id,
                    role="approver",
                    granted_by=identity.BOOTSTRAP,
                )
            owner.commit()
            grant_id = grant.id
        yield person.id
    finally:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            for credential in owner.scalars(
                select(MfaCredential).where(MfaCredential.user_id == person.id)
            ):
                owner.delete(credential)
            if grant_id is not None:
                held = owner.get(UserRole, grant_id)
                if held is not None:
                    owner.delete(held)
            owner.commit()
        owner.close()


def test_the_session_says_it_is_confined_rather_than_leaving_the_client_to_guess(
    a_privileged_account_with_no_authenticator,
) -> None:
    """The finding. A 403 on every screen is not an instruction.

    `mfa_required` is answered by the server, from the same `mfa.locked_out`
    the middleware enforces with, rather than by the client comparing roles
    against its own copy of the policy list. A duplicated list drifts, and it
    drifts in the direction where a role added on the server produces 403s the
    client cannot explain and offers no way out of.
    """
    with TestClient(app) as c:
        sign_in(c, VIEWER_EMAIL)
        state = c.get("/auth/session").json()

        assert state["authenticated"] is True, (
            "a privileged account with no second factor was refused a session "
            "altogether, which locks them out with no way to enrol"
        )
        assert state["mfa_required"] is True
        assert state["mfa_satisfied"] is False
        assert "approver" in state["roles"]

        # And the confinement is real, not merely reported.
        assert c.get("/clients").status_code == 403


def test_a_confined_session_can_enrol_and_the_confinement_lifts(
    a_privileged_account_with_no_authenticator,
) -> None:
    """The whole journey the enrolment screen walks, end to end.

    Sign in, be told, enrol, confirm, and find the app open — without signing
    out in between, because there is no enrolment that does not need a session.
    """
    with TestClient(app) as c:
        sign_in(c, VIEWER_EMAIL)
        assert c.get("/clients").status_code == 403

        started = c.post("/auth/mfa/enrol")
        assert started.status_code == 200, started.text
        body = started.json()
        assert body["secret"], "no secret to put into an authenticator"
        assert body["otpauth_url"].startswith("otpauth://"), (
            "nothing a camera can scan, so enrolment is a typing exercise"
        )
        assert body["status"] == "unconfirmed"

        wrong = c.post("/auth/mfa/verify", json={"code": "000000"})
        assert wrong.status_code == 401, (
            "an unconfirmed enrolment was accepted without proving the "
            "authenticator produces the right code"
        )
        assert c.get("/clients").status_code == 403, (
            "a failed confirmation lifted the confinement"
        )

        confirmed = c.post(
            "/auth/mfa/verify", json={"code": totp.code_at(body["secret"])}
        )
        assert confirmed.status_code == 200, confirmed.text
        assert confirmed.json()["mfa_satisfied"] is True

        after = c.get("/auth/session").json()
        assert after["mfa_required"] is False
        assert after["mfa_satisfied"] is True
        assert c.get("/clients").status_code == 200, (
            "the confinement did not lift, so enrolling achieved nothing"
        )


def test_an_ordinary_account_is_not_told_to_enrol(
    a_privileged_account_with_no_authenticator,
) -> None:
    """The negative half, and the reason it is not "everyone should enrol".

    The fixture is present so this runs while a confined session is genuinely
    possible: a field that is always `false` would pass this test on a build
    where the whole mechanism had been deleted.
    """
    with TestClient(app) as c:
        sign_in(c, ADMIN_EMAIL)
        state = c.get("/auth/session").json()
    assert state["mfa_required"] is False
    assert state["authenticated"] is True


# ------------------------------------------------------------ FP3-12(c) ----


@pytest.fixture
def an_admin_whose_credential_can_be_aged():
    """A tenant admin, and a handle on when they last proved it.

    Only this client's own session is touched. Moving `authenticated_at` on
    every live row would reach into other modules' clients and break their
    step-up acts with 401s that look like a bug in whatever they were testing.
    """
    with TestClient(app) as c:
        sign_in(c, ADMIN_EMAIL)
        token = c.cookies.get(auth.COOKIE_NAME)
        assert token, "no session cookie to age"

        owner = OwnerSessionLocal()
        with tenancy.acting_as(DEMO_TENANT):
            row = owner.scalars(
                select(AuthSession).where(
                    AuthSession.token_hash == auth._hash(token)
                )
            ).one()
            was = row.authenticated_at

        def age_by(minutes: int) -> None:
            with tenancy.acting_as(DEMO_TENANT):
                row.authenticated_at = datetime.now(timezone.utc) - timedelta(
                    minutes=minutes
                )
                owner.commit()

        try:
            yield c, age_by
        finally:
            with tenancy.acting_as(DEMO_TENANT):
                row.authenticated_at = was
                owner.commit()
            owner.close()


def _step_up_act(c):
    """A step-up act with no lasting effect: set the policy to what it already is.

    Any of them would do — signing, publishing, provisioning and this all read
    the same `REAUTH_MINUTES`. This one is chosen because it can be performed
    truthfully without staging a draft, and because setting a value to itself
    leaves the firm exactly as it was.
    """
    current = c.get("/tenant/advance-policy")
    assert current.status_code == 200, current.text
    now = current.json()
    return c.patch(
        "/tenant/advance-policy",
        json={"policy": now["policy"], "window_days": now["window_days"]},
    )


def test_a_credential_ten_minutes_old_still_signs(
    an_admin_whose_credential_can_be_aged,
) -> None:
    """The finding, and the reason the old five-minute window was wrong.

    Five minutes claimed in its own comment to be "long enough to read the draft
    that is about to be signed". It was not: a pack draft is a rule document
    with a diff, a validation report and a preview, and anybody who reads one
    before signing takes longer than that. What the window actually enforced was
    a habit of signing first and reading afterwards.
    """
    c, age_by = an_admin_whose_credential_can_be_aged
    age_by(10)
    res = _step_up_act(c)
    assert res.status_code == 200, (
        "a credential presented ten minutes ago was refused, so there is still "
        "not time to read what is being signed: " + res.text
    )


def test_a_credential_that_is_genuinely_old_is_refused(
    an_admin_whose_credential_can_be_aged,
) -> None:
    """The window is longer, not gone.

    Twenty minutes is past it. What this bounds is somebody walking up to a
    machine its owner left signed in, and that is only bounded if the window
    ends.
    """
    c, age_by = an_admin_whose_credential_can_be_aged
    age_by(20)
    res = _step_up_act(c)
    assert res.status_code == 401, (
        f"a credential twenty minutes old was accepted for a step-up act: "
        f"{res.status_code}"
    )
    assert res.headers.get("X-Quolin-Reauth") == "required", (
        "the refusal is indistinguishable from a dead session, so a client can "
        "only answer it by signing the person out and losing their draft"
    )


def test_reauthenticating_in_place_lets_the_same_act_through(
    an_admin_whose_credential_can_be_aged,
) -> None:
    """FP3-12(b)'s server half: the retry the dialog performs actually works.

    The client's contract is: catch the 401 that carries the header, ask for the
    password, POST `/auth/reauth`, and run the *original* request again. That is
    only worth writing if the second attempt succeeds on the same session and
    the same cookie — no new sign-in, no lost page.
    """
    c, age_by = an_admin_whose_credential_can_be_aged
    age_by(20)
    assert _step_up_act(c).status_code == 401

    code = second_factor_code(ADMIN_EMAIL)
    body: dict[str, str] = {"password": TEST_PASSWORD}
    if code:
        body["code"] = code
    again = c.post("/auth/reauth", json=body)
    assert again.status_code == 200, again.text

    retried = _step_up_act(c)
    assert retried.status_code == 200, (
        "re-authenticating in place did not let the act through, so the only "
        "remaining answer is signing out: " + retried.text
    )


def test_the_session_states_the_window_rather_than_the_client_guessing_it(
    an_admin_whose_credential_can_be_aged,
) -> None:
    """So the dialog can say how long it lasts without a number of its own.

    Checked against behaviour, not against the constant: the value the session
    reports has to be one that the ten-minute act above is inside of.
    """
    c, _age_by = an_admin_whose_credential_can_be_aged
    state = c.get("/auth/session").json()
    assert state["credential_fresh_minutes"] > 10, (
        "the window the client is told about is shorter than one it has just "
        "been shown to accept"
    )
