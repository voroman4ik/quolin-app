"""FP3-26: user administration had five writes and no read.

`POST /admin/users`, `/roles`, `/roles/{id}/revoke`, `/suspend` and
`/reinstate` have existed since Stage 2. Nothing could list the people they act
on. Every other screen in FP3-26 consumes a route that was already there and
already published; this is the one place where the screen genuinely could not be
built without new API surface, so the surface was added and the change log says
so rather than the screen being quietly dropped.

Three properties, and the second is the one that makes it a tenant read rather
than a directory dump:

  * the people this firm has granted something to are listed, with their grants;
  * somebody who holds no grant here is not, even though the `users` row exists;
  * reading is bounded by the same role that bounds the writes, and by nothing
    weaker — but *not* by credential freshness, which the writes have and a read
    must not, or the screen cannot be opened at all without retyping a password.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import pytest
from conftest import DEMO_TENANT, PUBLISHER_EMAIL, VIEWER_EMAIL, sign_in
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import auth, identity, tenancy
from app.db import OwnerSessionLocal
from app.main import app
from app.models import AuthSession, UserRole


@pytest.fixture(scope="module")
def operator():
    """The account that may administer people. `quolin_operator`, deliberately.

    Not the firm's own `operator`: provisioning access is Quolin's act on the
    firm's behalf, which `rbac.ROUTE_ROLES` has said since Stage 2 and the
    reading route is held to identically.
    """
    with TestClient(app) as c:
        yield sign_in(c, PUBLISHER_EMAIL)


@pytest.fixture
def a_stranger_with_no_grant_here():
    """A real `users` row that this firm has granted nothing.

    The interesting case. The row exists platform-wide, so a listing built by
    walking `users` would show them; a listing built from this firm's grants
    does not. Manufactured rather than hoped for, and rolled back.
    """
    owner = OwnerSessionLocal()
    email = f"stranger-{uuid.uuid4().hex[:8]}@elsewhere.example"
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_seed"):
            person = identity.create_user(
                owner, email=email, display_name="Not This Firm's"
            )
            owner.flush()
            yield person.id, email
    finally:
        owner.rollback()
        owner.close()


def test_the_people_this_firm_granted_something_are_listed(operator) -> None:
    res = operator.get("/admin/users")
    assert res.status_code == 200, res.text
    body = res.json()

    assert body["tenant_id"] == DEMO_TENANT
    listed = {person["email"] for person in body["users"]}
    assert VIEWER_EMAIL in listed, (
        "a seeded person holding a role in this firm is missing from its roster"
    )

    person = next(p for p in body["users"] if p["email"] == VIEWER_EMAIL)
    assert person["roles"], "a person is listed with no grant, which is why they were listed"
    held = {grant["role"] for grant in person["roles"]}
    assert "viewer" in held
    for grant in person["roles"]:
        # What the screen needs to revoke one, and what makes a grant
        # accountable rather than merely present.
        assert grant["id"]
        assert grant["granted_by"]
        assert grant["granted_at"]


def test_the_grants_listed_are_the_grants_recorded(operator, session) -> None:
    """Read back against the table rather than against a second copy of the API.

    An endpoint that agreed with itself would pass a test written from its own
    response shape. This compares the answer with `user_roles`.
    """
    res = operator.get("/admin/users")
    from_api = {
        (person["email"], grant["id"])
        for person in res.json()["users"]
        for grant in person["roles"]
    }

    from_table = set()
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_seed"):
            for grant in session.scalars(select(UserRole)):
                person = identity.find_by_id(owner, grant.user_id)
                if person is not None:
                    from_table.add((person.email, grant.id))
    finally:
        owner.close()

    assert from_api == from_table, (
        "the roster and `user_roles` disagree about who holds what"
    )


def test_somebody_this_firm_has_not_granted_anything_is_invisible(
    operator, a_stranger_with_no_grant_here
) -> None:
    """The reason this is a tenant read and not a directory listing.

    A consultant serving three firms appears in three rosters and not in a
    fourth, and the mechanism is that the roster is built from this tenant's own
    `user_roles` — which RLS confines — rather than from `users`, which has no
    `tenant_id` at all.
    """
    _user_id, email = a_stranger_with_no_grant_here
    res = operator.get("/admin/users")
    listed = {person["email"] for person in res.json()["users"]}
    assert email not in listed, (
        "a person this firm has granted nothing appears on its roster — the "
        "listing is walking `users` rather than this tenant's grants"
    )


def test_the_whole_firm_may_read_it_and_only_we_may_change_it() -> None:
    """Reading is open to the firm; every write on the screen is not.

    The first draft of this route held the read to `quolin_operator`, and
    `test_reading_is_open_to_the_firm_and_writing_is_not` refused it. That test
    is right and this one records why: a firm's own directory of who holds what
    is the clearest case of "every role can see the firm's work, and what
    separates them is what they can make happen". It also discloses nothing new
    — every person listed already appears by name on the decisions and audit
    events they made.
    """
    with TestClient(app) as c:
        sign_in(c, VIEWER_EMAIL)
        read = c.get("/admin/users")
        wrote = c.post(
            "/admin/users",
            json={"email": "viewer-probe@quolin.example", "display_name": "No"},
        )

    assert read.status_code == 200, (
        f"a viewer cannot see who has access to their firm's data: {read.text}"
    )
    assert read.json()["users"], "the roster read back empty for a viewer"
    assert wrote.status_code == 403, (
        f"a viewer provisioned an account: {wrote.status_code} {wrote.text}"
    )


def test_an_unauthenticated_caller_is_told_to_sign_in() -> None:
    with TestClient(app) as c:
        res = c.get("/admin/users")
    assert res.status_code == 401


def test_reading_does_not_demand_a_freshly_typed_password(operator) -> None:
    """The difference between looking and doing, asserted rather than argued.

    Every write on this screen calls `_provisioning_principal`, which refuses
    unless a credential was presented in the last few minutes. Applying that to
    the read would mean the administration screen could not load until somebody
    retyped a password — which teaches people to retype passwords whenever a
    screen asks, and that is the habit phishing is made of.

    Proved by staling the credential and reading anyway: the write refuses with
    the header the client acts on, and the read still answers.
    """
    # Only this client's own session is staled. An earlier draft moved
    # `authenticated_at` on every live row, which is a fixture that reaches into
    # other modules' clients and breaks their step-up actions with 401s that
    # look like a bug in whatever they were testing.
    token = operator.cookies.get(auth.COOKIE_NAME)
    assert token, "the operator client holds no session cookie"

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            row = owner.scalars(
                select(AuthSession).where(
                    AuthSession.token_hash == auth._hash(token)
                )
            ).one()
            was = row.authenticated_at
            row.authenticated_at = datetime.now(timezone.utc) - timedelta(days=1)
            owner.commit()

        read = operator.get("/admin/users")
        assert read.status_code == 200, (
            "reading the roster demanded a freshly typed password: " + read.text
        )

        write = operator.post(
            "/admin/users",
            json={"email": "freshness-probe@quolin.example", "display_name": "P"},
        )
        assert write.status_code == 401, (
            "provisioning went through on a stale credential — the freshness "
            "check that makes the read's exemption meaningful is not firing"
        )
        assert write.headers.get("X-Quolin-Reauth") == "required", (
            "the refusal carries no header, so the client cannot tell a stale "
            "credential from a dead session and will sign the person out"
        )
    finally:
        with tenancy.acting_as(DEMO_TENANT):
            row.authenticated_at = was
            owner.commit()
        owner.close()
