"""The LLM boundary: what a model may do here, and what it structurally cannot.

"Is an AI writing your rules?" is the question every customer asks, and §S6 says
the answer must be provable rather than promised. This file is the proof, and it
is written to be read by somebody who does not trust us.

The claim has three parts and each has tests below:

  1. A model can only raise a hand. There is no code path from a suggestion to a
     tier, a threshold, a rule or a determination.
  2. Uncertainty escalates. No confidence score is low enough to make an item
     quieter — the failure this ordering prevents is the expensive one.
  3. Every call is retained, in a table that refuses UPDATE and DELETE.

If any test in this file fails, the correct response is to stop shipping rather
than to adjust the test.
"""

from __future__ import annotations

import subprocess
from datetime import date
from pathlib import Path

import pytest
from sqlalchemy import select, text

from app.models import WatchAssistCall, WatchEvent
from app.watch import assist, poll, triage

REPO = Path(__file__).resolve().parents[2]


def _suggestion(**kw) -> assist.Suggestion:
    base = {
        "summary": "The regulator proposes a change to concentration limits.",
        "touches_rule_content": True,
        "confidence": 0.9,
        "reason": "It names the concentration limit directly.",
        "model": "claude-opus-5",
        "prompt": "(the prompt)",
        "output": "{}",
    }
    return assist.Suggestion(**{**base, **kw})


class _StubClient:
    """A model that says whatever the test needs, without a credential.

    This module has to be testable without crossing the boundary it describes —
    otherwise the only way to exercise it would be to cross it.
    """

    def __init__(self, payload: str):
        self.payload = payload
        self.calls: list[dict] = []
        self.messages = self

    def create(self, **kwargs):
        self.calls.append(kwargs)

        # A real `TextBlock`, not a look-alike. The reader in `assist.read`
        # narrows on the SDK's own type, so a duck-typed stub would pass a test
        # that the SDK would fail — which is the wrong way round for a file
        # whose whole job is to be believed.
        from anthropic.types import TextBlock

        class _Response:
            def __init__(self, text_: str):
                self.content = [TextBlock(type="text", text=text_)]

        return _Response(self.payload)


# --- 1. A model can only raise a hand ---------------------------------------


def test_a_confident_model_cannot_lower_an_item_the_pack_matched():
    """The pack is the authority on what its own content is.

    A model saying "this does not matter" about a publication that matched the
    vocabulary is exactly the case where deferring to it would be a model
    overruling a rule.
    """
    dismissive = _suggestion(touches_rule_content=False, confidence=0.99)
    escalate, reason = assist.apply(
        dismissive, deterministic_tier=triage.TOUCHES_RULE_CONTENT
    )
    assert escalate is False
    assert reason == ""


def test_apply_returns_a_boolean_and_never_a_tier():
    """The signature is the guarantee. `apply` cannot return a tier because there
    is nowhere in its type for one to go."""
    result = assist.apply(_suggestion(), deterministic_tier=triage.IN_SCOPE)
    assert isinstance(result, tuple)
    escalate, reason = result
    assert isinstance(escalate, bool)
    assert isinstance(reason, str)


def test_the_tier_is_settled_before_the_model_is_asked(session, monkeypatch):
    """Ordering, asserted rather than assumed.

    `_ask_the_model` is handed an event that already carries its rule-derived
    tier. A model that returned something wild changes the `escalated` flag on a
    retention row and nothing else.
    """
    seen = {}

    def spy(*, title, summary, jurisdiction, vocabulary=None, client=None):
        seen["tier_at_call_time"] = event.tier
        return _suggestion()

    monkeypatch.setattr(assist, "available", lambda: True)
    monkeypatch.setattr(assist, "read", spy)

    event = WatchEvent(
        source_id="au-asic-media",
        jurisdiction="AU",
        digest="test-boundary-order",
        title="A publication",
        summary="",
        url="",
        published_at=date.today(),
        tier=triage.IN_SCOPE,
        matched=[],
        status="new",
    )
    session.add(event)
    session.flush()
    try:
        poll._ask_the_model(session, event, [])
        assert seen["tier_at_call_time"] == triage.IN_SCOPE
        assert event.tier == triage.IN_SCOPE, "the model changed the tier"
    finally:
        session.rollback()


# --- 2. Uncertainty escalates ------------------------------------------------


@pytest.mark.parametrize("confidence", [0.0, 0.1, 0.5, 0.69])
def test_an_unsure_model_escalates_whatever_it_said(confidence):
    """Both directions. A hesitant "yes" and a hesitant "no" both go to a person,
    because what is being acted on is the hesitation."""
    for verdict in (True, False):
        escalate, reason = assist.apply(
            _suggestion(touches_rule_content=verdict, confidence=confidence),
            deterministic_tier=triage.IN_SCOPE,
        )
        assert escalate is True, (verdict, confidence)
        assert "unsure" in reason


def test_a_confident_model_can_raise_something_the_vocabulary_missed():
    """The case the assistant exists for: a hand-written vocabulary has gaps, and
    a publication that uses a word nobody thought of still matters."""
    escalate, reason = assist.apply(
        _suggestion(touches_rule_content=True, confidence=0.95),
        deterministic_tier=triage.IN_SCOPE,
    )
    assert escalate is True
    assert "did not match" in reason or "Nothing in this publication matched" in reason


def test_a_failed_call_escalates_rather_than_disappearing(session, monkeypatch):
    """A model being unreachable must not quietly become "nothing to see here"."""
    monkeypatch.setattr(assist, "available", lambda: True)

    def explode(**kwargs):
        raise RuntimeError("the model is on fire")

    monkeypatch.setattr(assist, "read", explode)

    event = WatchEvent(
        source_id="au-asic-media",
        jurisdiction="AU",
        digest="test-boundary-failure",
        title="A publication",
        summary="",
        url="",
        published_at=date.today(),
        tier=triage.IN_SCOPE,
        matched=[],
        status="new",
    )
    session.add(event)
    session.flush()
    try:
        assert poll._ask_the_model(session, event, []) is True
        session.flush()
        row = session.scalars(
            select(WatchAssistCall).where(WatchAssistCall.event_id == event.id)
        ).one()
        assert row.escalated is True
        assert "on fire" in row.output, "the failure was not retained"
    finally:
        session.rollback()


def test_a_sweep_survives_the_model_being_unavailable(session, monkeypatch):
    """The sweep's job is to notice what regulators published. That must not
    depend on an optional summariser being up."""
    monkeypatch.setattr(assist, "available", lambda: True)
    monkeypatch.setattr(
        assist, "read", lambda **kw: (_ for _ in ()).throw(RuntimeError("down"))
    )
    result = poll.poll(session, date.today())
    assert result["sources_checked"] > 0
    session.rollback()


# --- 3. Everything is retained ----------------------------------------------


def test_the_prompt_and_the_answer_are_both_kept(session, monkeypatch):
    """"What did it actually say" has to be answerable in two years by somebody
    who does not trust our description of it."""
    monkeypatch.setattr(assist, "available", lambda: True)
    monkeypatch.setattr(
        assist,
        "read",
        lambda **kw: _suggestion(
            prompt="the exact words the model was shown",
            output='{"summary": "what it answered"}',
            confidence=0.82,
        ),
    )
    event = WatchEvent(
        source_id="au-asic-media",
        jurisdiction="AU",
        digest="test-boundary-retention",
        title="A publication",
        summary="",
        url="",
        published_at=date.today(),
        tier=triage.TOUCHES_RULE_CONTENT,
        matched=[],
        status="new",
    )
    session.add(event)
    session.flush()
    try:
        poll._ask_the_model(session, event, [])
        session.flush()
        row = session.scalars(
            select(WatchAssistCall).where(WatchAssistCall.event_id == event.id)
        ).one()
        assert row.prompt == "the exact words the model was shown"
        assert row.output == '{"summary": "what it answered"}'
        assert row.model == "claude-opus-5"
        assert row.confidence_pct == 82
        assert row.deterministic_tier == triage.TOUCHES_RULE_CONTENT
    finally:
        session.rollback()


def test_the_retention_table_refuses_to_be_edited(session):
    """Append-only, like `decisions`. A retention record that can be rewritten
    answers a different question: what do you *say* it said."""
    from sqlalchemy.exc import DBAPIError

    with pytest.raises(DBAPIError):
        session.execute(text("UPDATE watch_assist_calls SET output = 'edited'"))
        session.flush()
    session.rollback()

    with pytest.raises(DBAPIError):
        session.execute(text("DELETE FROM watch_assist_calls"))
        session.flush()
    session.rollback()


# --- The credential, and where the code may live ----------------------------


def test_nothing_outside_the_watch_service_imports_a_model_client():
    """The structural half of "summarisation runs inside watch only".

    A grep, because what is being proven is that the import does not exist
    anywhere else — a behavioural test would only cover the paths it happened to
    walk. `guard_no_watch_in_engine.sh` makes the same check in CI; this is here
    so that a developer sees it before CI does.
    """
    hits = subprocess.run(
        [
            "git",
            "grep",
            "-lE",
            r"^\s*(import|from)\s+anthropic",
            "--",
            "api",
            "scripts",
            "web",
            ":(exclude)api/app/watch/assist.py",
            f":(exclude){Path(__file__).relative_to(REPO)}",
        ],
        cwd=REPO,
        capture_output=True,
        text=True,
    )
    assert hits.stdout == "", f"a model client is imported outside watch:\n{hits.stdout}"


def test_the_assistant_is_off_unless_a_credential_is_present(monkeypatch):
    """Core-api holds no credential, so this is False there even though the code
    is in the same image. The credential is the boundary."""
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    assert assist.available() is False
    with pytest.raises(assist.AssistUnavailable):
        assist.read(title="anything", jurisdiction="AU")


def test_asking_for_a_model_with_no_credential_is_loud_rather_than_silent(monkeypatch):
    """A deployment that meant to have the assistant on should find out, not run
    for a month producing rule-based triage somebody believes is model-assisted."""
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    with pytest.raises(assist.AssistUnavailable) as exc:
        assist.read(title="anything", jurisdiction="AU")
    assert "docs/llm-boundary.md" in str(exc.value)


# --- The call itself --------------------------------------------------------


def test_the_prompt_carries_the_packs_own_vocabulary():
    """Giving the model a different notion of relevance from the deterministic
    tier would make the two incomparable, and comparing them is the entire use."""
    stub = _StubClient(
        '{"summary": "s", "touches_rule_content": true, "confidence": 0.9, "reason": "r"}'
    )
    assist.read(
        title="A consultation on leverage",
        summary="",
        jurisdiction="AU",
        vocabulary=[{"term": "concentration limit", "touches": ["AU-CONC-01"]}],
        client=stub,
    )
    prompt = stub.calls[0]["messages"][0]["content"]
    assert "concentration limit" in prompt
    assert "AU" in prompt
    assert "not deciding anything" in prompt


def test_the_model_is_asked_for_a_schema_rather_than_asked_nicely():
    """A parse failure in a sweep is a silent gap in the retention record."""
    stub = _StubClient(
        '{"summary": "s", "touches_rule_content": false, "confidence": 0.4, "reason": "r"}'
    )
    suggestion = assist.read(title="t", jurisdiction="AU", client=stub)
    fmt = stub.calls[0]["output_config"]["format"]
    assert fmt["type"] == "json_schema"
    assert set(fmt["schema"]["required"]) == {
        "summary",
        "touches_rule_content",
        "confidence",
        "reason",
    }
    assert suggestion.confidence == 0.4
    assert suggestion.output == stub.payload
