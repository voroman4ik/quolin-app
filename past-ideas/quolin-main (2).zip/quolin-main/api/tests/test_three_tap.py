"""The three taps the product is demonstrated with, asserted as one sequence.

The execution document names this as a standing obligation rather than a stage's
work: *the three-tap demo regression survives every stage*. Check, Replay,
Generate — the three things a compliance officer is shown in six minutes, and
the three things that must still be true after each stage rearranges the
machinery underneath them.

Each tap is covered somewhere else in the suite already, in the file that owns
the mechanism it exercises. This file exists anyway, and the duplication is the
point: those tests can each be changed for a good local reason without anybody
noticing that the demo no longer runs. This one is named after the demo, walks
the taps in order through one signed-in client, and fails as a unit — which is
the form the gate check at the end of every stage actually needs.

It is written against the seeded cast on purpose, with the same client, asset
and decision the script names, because "the demo works" is a claim about those
specific rows and not about the endpoints in general.
"""

from __future__ import annotations

import pytest
from conftest import OPERATOR_EMAIL, reset_rate_limit_for_tests, sign_in
from fastapi.testclient import TestClient

from app.main import app

#: Straight out of docs/demo-script.md. Changing anything here means the script
#: is wrong, the seed is wrong, or the demo has changed — all three of which are
#: things somebody should have to notice.
BLOCKING_CLIENT = "tom-askew"
BLOCKING_ASSET = "SOL"
REPLAY_CLIENT = "harold-bell"


@pytest.fixture
def officer():
    """One person, signed in, doing all three taps.

    A single client rather than the module-scoped one, because the demo is a
    sequence performed by one operator in one sitting and this file is the only
    place that shape is asserted.
    """
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        yield sign_in(c, OPERATOR_EMAIL)


def test_the_three_tap_demo_still_runs(officer):
    """Check, Replay, Generate, in order, against the cast the script names.

    One test rather than three, because the failure that matters is "the demo
    broke" and a reader looking at a red build wants that sentence rather than a
    third of it.
    """
    # --- tap one: the machine refuses, and says why -----------------------
    decision = officer.post(
        "/evaluate", json={"client_id": BLOCKING_CLIENT, "asset_id": BLOCKING_ASSET}
    ).json()
    assert decision["outcome"] == "BLOCK"
    assert len(decision["reasons"]) == 3, "the script says three failing rules"
    for reason in decision["reasons"]:
        # The reason a compliance officer reads, not a rule id they cannot act
        # on. The whole first tap is that the refusal is explained.
        assert reason["reason_plain_english"]
        assert reason["rule_id"]

    # --- tap two: a determination from last year reproduces exactly --------
    history = officer.get("/decisions", params={"client_id": REPLAY_CLIENT}).json()
    oldest = min(history, key=lambda d: d["as_of"])
    assert oldest["pack_version"] == 1, "the replay tap is the one made under v1"

    replay = officer.post(f"/decisions/{oldest['id']}/replay").json()
    assert replay["match"] is True
    assert replay["differences"] == []
    assert replay["stored_outcome"] == replay["replayed_outcome"]
    # The claim the product is sold on: not merely that it reproduces, but that
    # the record it reproduced from has not been altered since.
    assert replay["chain"]["verified"] is True

    # --- tap three: the document comes out --------------------------------
    artefact = officer.post(
        "/artefacts/tmd", json={"decision_id": decision["id"]}
    ).json()
    assert artefact["title"] == "Target Market Determination"

    pdf = officer.get(artefact["download_url"])
    assert pdf.status_code == 200
    assert pdf.headers["content-type"] == "application/pdf"
    assert pdf.content.startswith(b"%PDF"), "a real file, not a stub or a redirect"


def test_the_demo_survives_the_identity_work_that_now_sits_under_it(officer):
    """Stage 2's own version of the standing obligation.

    Every tap above now runs as a named person rather than as whoever held a
    shared passcode, and each writes an audit row attributed to them. That is the
    change this stage made underneath the demo, so it is what this stage owes an
    assertion about: the taps still work, *and* they are now attributable.
    """
    me = officer.get("/auth/session").json()
    assert me["authenticated"] is True
    assert me["user"]["email"] == OPERATOR_EMAIL

    decision = officer.post(
        "/evaluate", json={"client_id": BLOCKING_CLIENT, "asset_id": BLOCKING_ASSET}
    ).json()

    detail = officer.get(f"/decisions/{decision['id']}").json()
    assert detail["outcome"] == "BLOCK"

    # And the operator cannot complete the second half of a two-person act, which
    # is the rule the stage added. Asserted here rather than only in
    # test_separation_of_duties.py because the demo is where somebody would
    # first notice it had stopped being true.
    refused = officer.post(
        f"/decisions/{decision['id']}/override",
        json={"justification": "An operator should not be able to do this at all."},
    )
    assert refused.status_code == 403, refused.text
