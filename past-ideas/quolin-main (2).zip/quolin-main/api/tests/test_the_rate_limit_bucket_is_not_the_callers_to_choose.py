"""FP3-02: the only rate limit was keyed on a header the attacker writes.

`_client_ip` took `X-Forwarded-For.split(",")[0]` and its docstring said that
was "the position the edge appends the real client at". A proxy appends, so the
real client is *last* and the first entry is whatever the caller sent. Behind
the ALB in `infra/`, a fresh `X-Forwarded-For: 10.0.0.<n>` per request bought a
fresh bucket per request.

Reproduced before it was fixed, and the numbers are worth keeping: eight failed
sign-ins with no header reached 429; thirty with a rotating spoofed header
reached nothing at all, and `auth_attempts` held thirty distinct addresses of
the attacker's choosing — the table Stage 9 calls the record of an attack that
survives the attacker, recording the attacker's fiction.

**No test in the suite sent this header.** That is why it survived two
fix-packs: every rate-limit test used the default client address, where the code
was correct, and the one line that mattered was never exercised.
"""

from __future__ import annotations

import pytest
from conftest import OPERATOR_EMAIL, reset_rate_limit_for_tests, second_factor_code
from fastapi.testclient import TestClient
from sqlalchemy import func, select

from app import auth
from app.db import SessionLocal
from app.main import app
from app.models import AuthAttempt

#: The shape an ALB produces: whatever the caller sent, then the address the
#: ALB actually saw, appended on the right.
ALB_SHAPED = "10.0.0.{n}, 203.0.113.7"

UNKNOWN = "nobody@example.test"


@pytest.fixture
def anonymous():
    """A client that has not signed in, and a clean slate either side."""
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        yield c
    reset_rate_limit_for_tests()


def _fail(c, header: str | None = None, email: str = UNKNOWN, code: str | None = None):
    body = {"email": email, "password": "not-the-password"}
    if code is not None:
        body["code"] = code
    headers = {"X-Forwarded-For": header} if header else {}
    return c.post("/auth/login", json=body, headers=headers)


def test_a_spoofed_forwarded_header_does_not_buy_a_fresh_bucket(anonymous):
    """The reproduction, inverted into an assertion.

    Thirty attempts, a different first entry every time, from one real address.
    Before the fix every one of these was 401 and the limiter never fired once.
    """
    codes = [_fail(anonymous, ALB_SHAPED.format(n=n)).status_code for n in range(30)]
    assert 429 in codes, (
        "thirty failed sign-ins with a rotating X-Forwarded-For reached no rate "
        f"limit: {sorted(set(codes))}"
    )


def test_the_recorded_address_is_never_the_callers_first_entry(anonymous):
    """What gets written down is an address, not a claim."""
    _fail(anonymous, ALB_SHAPED.format(n=1))

    with SessionLocal() as s:
        recorded = s.scalars(
            select(AuthAttempt.source_ip).where(AuthAttempt.outcome == auth.FAILED)
        ).all()

    assert recorded, "the attempt was not recorded at all"
    assert "10.0.0.1" not in recorded, (
        "the caller's own first X-Forwarded-For entry was recorded as their address"
    )


def test_the_raw_header_is_kept_but_kept_apart(anonymous):
    """A spoofed header is evidence. It is just not an address.

    Recorded in its own column, named so that nothing reads it as provenance,
    and never written into `source_ip`.
    """
    header = ALB_SHAPED.format(n=42)
    _fail(anonymous, header)

    with SessionLocal() as s:
        row = s.scalars(
            select(AuthAttempt)
            .where(AuthAttempt.outcome == auth.FAILED)
            .order_by(AuthAttempt.id.desc())
        ).first()

    assert row is not None
    assert row.forwarded_for_untrusted == header
    assert row.source_ip != "10.0.0.42"


def test_an_account_is_locked_even_when_every_address_is_different(anonymous):
    """The counter the address bucket cannot replace.

    Resolving the address properly stops an attacker *choosing* it. It does
    nothing about an attacker who genuinely holds a thousand hosts, which is
    what a password spray is.

    The failures are recorded here as coming from genuinely different addresses
    rather than sent through the client, because a `TestClient` has one peer
    address by construction — so driving them through it would be testing the
    address counter again under a different name. What is under test is that the
    *account* is refused from an address with no history of its own at all.
    """
    with SessionLocal() as s:
        target = None
        from app import identity

        target = identity.account_id_for(s, OPERATOR_EMAIL)
        assert target is not None, "the seeded operator should exist"

        for n in range(auth.MAX_ACCOUNT_ATTEMPTS):
            auth.record_failure(s, f"198.51.100.{n}", user_id=target)
        s.commit()

    refused = _fail(anonymous, email=OPERATOR_EMAIL)
    assert refused.status_code == 429, (
        "an account guessed at from a different address every time was never "
        f"locked: {refused.status_code}"
    )


def test_the_second_factor_has_a_tighter_counter_than_the_password():
    """Six digits inside one live window is a much smaller space than a password.

    And a wrong code means something different from a wrong password: whoever
    sent it already holds the password. The two are counted apart for that
    reason, and the code counter is the smaller one.
    """
    assert auth.MAX_SECOND_FACTOR_ATTEMPTS < auth.MAX_ACCOUNT_ATTEMPTS
    assert auth.MAX_SECOND_FACTOR_ATTEMPTS < auth.MAX_ATTEMPTS


def test_a_wrong_code_is_counted_as_a_second_factor_failure(anonymous):
    """The counter is only as good as the thing it counts.

    The seeded operator holds an authenticator (F8 put `operator` in
    `MFA_REQUIRED_ROLES`), so a correct password with a wrong code reaches
    `MFA_WRONG` — which is the only path that should mark the row.
    """
    if not second_factor_code(OPERATOR_EMAIL):
        pytest.skip("the seeded operator has no authenticator enrolled")

    from conftest import TEST_PASSWORD

    anonymous.post(
        "/auth/login",
        json={"email": OPERATOR_EMAIL, "password": TEST_PASSWORD, "code": "000000"},
    )

    with SessionLocal() as s:
        marked = s.scalar(
            select(func.count())
            .select_from(AuthAttempt)
            .where(
                AuthAttempt.outcome == auth.FAILED,
                AuthAttempt.detail == auth.SECOND_FACTOR,
            )
        )
    assert marked >= 1, "a wrong six-digit code was not counted as a second-factor failure"


def test_uvicorn_is_not_configured_to_trust_every_proxy():
    """`--forwarded-allow-ips='*'` is not a laxer setting. It is the finding.

    uvicorn's `get_trusted_client_address` returns `x_forwarded_for_hosts[0]`
    when every proxy is trusted — the entry the caller chose. Asserted against
    uvicorn's own middleware rather than against our configuration, because the
    claim is about what that code does and it is the kind of thing that changes
    between versions.
    """
    from uvicorn.middleware.proxy_headers import _TrustedHosts

    everything = _TrustedHosts("*")
    assert everything.get_trusted_client_address("10.0.0.1, 203.0.113.7")[0] == "10.0.0.1"

    vpc_only = _TrustedHosts("10.0.0.0/16")
    assert vpc_only.get_trusted_client_address("10.0.0.1, 203.0.113.7")[0] == "203.0.113.7"
