"""Import brings reference data in. These tests hold it to being honest about it.

An importer is trusted twice: once when it accepts a file, and once when it
rejects one. Accepting a row it should have refused puts a number nobody typed
into the evidence chain. Rejecting without saying which row and which column
makes a spreadsheet an iterative game against the validator.

The third thing under test is what the import does *not* bring. A client CSV
carries no custody positions, and a client with no custody record is assessed as
holding nothing. That has to be stated, not discovered.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from app import importer
from app.models import Client
from app.providers import FixturePositionsProvider

SAMPLE = Path(__file__).resolve().parents[2] / "fixtures" / "sample_client_book.csv"

HEADER = ",".join(importer.REQUIRED_COLUMNS)

GOOD_ROW = (
    "imp-test-one,sterling,Test One,1990-01-01,retail,true,"
    "2026-01-15,3,false,10000000,2,,500000"
)


def _csv(*rows: str, header: str = HEADER) -> str:
    return "\n".join((header, *rows)) + "\n"


# --- the shape of the file ----------------------------------------------


def test_the_sample_book_is_valid():
    """The file we ship as an example must survive our own validator."""
    report = importer.parse(SAMPLE.read_text())
    assert report.ok, [e.as_dict() for e in report.errors]
    assert report.total_rows == len(report.valid) == 5


def test_a_missing_column_names_the_column():
    header = ",".join(c for c in importer.REQUIRED_COLUMNS if c != "loss_capacity_band")
    with pytest.raises(importer.ImportError_, match="loss_capacity_band"):
        importer.parse(_csv(GOOD_ROW, header=header))


def test_an_unrecognised_column_is_refused_not_ignored():
    """A column silently dropped is a field the author believed they supplied."""
    with pytest.raises(importer.ImportError_, match="loss_capcity_band"):
        importer.parse(_csv(GOOD_ROW + ",7", header=HEADER + ",loss_capcity_band"))


@pytest.mark.parametrize("text", ["", "   \n", HEADER])
def test_an_empty_or_headerless_file_is_refused(text):
    with pytest.raises(importer.ImportError_):
        importer.parse(text if text else "")


def test_blank_lines_are_skipped_not_counted():
    report = importer.parse(_csv(GOOD_ROW, ",,,,,,,,,,,,", GOOD_ROW.replace("one", "two")))
    assert report.total_rows == 2


# --- per-row validation --------------------------------------------------


@pytest.mark.parametrize(
    "column,bad_value,fragment",
    [
        ("id", "Not An Id", "not a valid id"),
        ("scenario", "atlantis", "not a known book"),
        ("name", "", "required"),
        ("dob", "14/03/1990", "YYYY-MM-DD"),
        ("client_category", "institutional", "retail"),
        ("loss_capacity_band", "9", "between 1 and 5"),
        ("loss_capacity_band", "abc", "not a whole number"),
        ("prior_crypto_purchases", "-1", "0 or more"),
        ("vulnerability_flag", "maybe", "yes/no"),
    ],
)
def test_a_bad_cell_is_reported_with_its_row_and_column(column, bad_value, fragment):
    cells = dict(zip(importer.REQUIRED_COLUMNS, GOOD_ROW.split(","), strict=True))
    cells[column] = bad_value
    report = importer.parse(_csv(",".join(cells[c] for c in importer.REQUIRED_COLUMNS)))

    assert not report.ok
    match = [e for e in report.errors if e.column == column]
    assert match, [e.as_dict() for e in report.errors]
    assert match[0].row == 2  # row 1 is the header, as a spreadsheet would show it
    assert fragment in match[0].message


@pytest.mark.parametrize("amount", ["1234.56", '"1,234"'])
def test_a_decimal_in_a_cents_column_is_refused_and_explained(amount):
    """Invariant 3: cents are integers. A CSV is where a float gets in.

    Rounding silently would put a number in the evidence chain that nobody
    typed, so the error names the real mistake rather than 'invalid number'.
    The thousands-separated case is quoted, because that is how a spreadsheet
    exports it — unquoted it would simply be two columns.
    """
    cells = dict(zip(importer.REQUIRED_COLUMNS, GOOD_ROW.split(","), strict=True))
    cells["assessable_portfolio_cents"] = amount
    report = importer.parse(_csv(",".join(cells[c] for c in importer.REQUIRED_COLUMNS)))

    error = next(e for e in report.errors if e.column == "assessable_portfolio_cents")
    assert "whole cents" in error.message
    assert "123456" in error.message


def test_assessed_knowledge_without_a_date_is_refused():
    """AU v2 refers on the assessment's age, which it cannot compute from nothing."""
    cells = dict(zip(importer.REQUIRED_COLUMNS, GOOD_ROW.split(","), strict=True))
    cells["knowledge_assessed"], cells["knowledge_date"] = "true", ""
    report = importer.parse(_csv(",".join(cells[c] for c in importer.REQUIRED_COLUMNS)))

    assert any(e.column == "knowledge_date" for e in report.errors)


def test_unassessed_knowledge_without_a_date_is_fine():
    cells = dict(zip(importer.REQUIRED_COLUMNS, GOOD_ROW.split(","), strict=True))
    cells["knowledge_assessed"], cells["knowledge_date"] = "false", ""
    report = importer.parse(_csv(",".join(cells[c] for c in importer.REQUIRED_COLUMNS)))

    assert report.ok, [e.as_dict() for e in report.errors]
    assert report.valid[0].values["knowledge_date"] is None


def test_every_problem_in_a_row_is_reported_not_just_the_first():
    """Otherwise fixing a spreadsheet is a guessing game, one column per attempt."""
    bad = "BAD ID,atlantis,,not-a-date,institutional,maybe,,99,maybe,1.5,-2,,0"
    report = importer.parse(_csv(bad))
    assert len({e.column for e in report.errors}) >= 6


def test_a_duplicate_id_inside_one_file_points_at_the_earlier_row():
    report = importer.parse(_csv(GOOD_ROW, GOOD_ROW))
    error = next(e for e in report.errors if "already appears" in e.message)
    assert error.row == 3 and "row 2" in error.message


def test_acknowledgements_are_pipe_separated_into_a_list():
    cells = dict(zip(importer.REQUIRED_COLUMNS, GOOD_ROW.split(","), strict=True))
    cells["structural_acks"] = "leveraged_products|complex_structures"
    report = importer.parse(_csv(",".join(cells[c] for c in importer.REQUIRED_COLUMNS)))

    assert report.valid[0].values["structural_acks"] == [
        "leveraged_products",
        "complex_structures",
    ]


def test_a_future_date_of_birth_is_refused():
    cells = dict(zip(importer.REQUIRED_COLUMNS, GOOD_ROW.split(","), strict=True))
    cells["dob"] = "2099-01-01"
    report = importer.parse(_csv(",".join(cells[c] for c in importer.REQUIRED_COLUMNS)))
    assert any(e.column == "dob" for e in report.errors)


# --- the three jurisdiction columns --------------------------------------


def _with(**overrides: str) -> str:
    """One row, with named optional columns appended in a fixed order."""
    columns = importer.REQUIRED_COLUMNS + tuple(overrides)
    return _csv(
        GOOD_ROW + "".join(f",{v}" for v in overrides.values()),
        header=",".join(columns),
    )


def test_a_book_that_names_no_jurisdiction_imports_as_it_always_did():
    """Every row written before these columns existed described one regime."""
    values = importer.parse(_csv(GOOD_ROW)).valid[0].values
    assert values["jurisdiction"] == importer.DEFAULT_JURISDICTION
    assert values["residency"] == values["domicile"] == values["jurisdiction"]


def test_residency_and_domicile_default_to_the_licence_not_to_australia():
    """A firm advising out of Singapore should not import Australian clients."""
    values = importer.parse(_with(jurisdiction="SG")).valid[0].values
    assert values["jurisdiction"] == "SG"
    assert values["residency"] == values["domicile"] == "SG"


def test_the_three_facts_are_kept_apart():
    values = importer.parse(
        _with(jurisdiction="au", residency="hk", domicile="sg")
    ).valid[0].values
    assert (values["jurisdiction"], values["residency"], values["domicile"]) == (
        "AU",
        "HK",
        "SG",
    )


@pytest.mark.parametrize("column", ["jurisdiction", "residency", "domicile"])
def test_a_code_that_is_not_a_code_is_refused_in_every_one_of_them(column):
    """A client filed under the wrong regulator is a decision under the wrong rules."""
    report = importer.parse(_with(**{column: "Hong Kong"}))
    assert [e.column for e in report.errors] == [column]


def test_a_regime_with_no_pack_on_the_shelf_still_imports():
    """The shape is checked, never the list of regimes we happen to ship.

    Rejecting `NZ` because no NZ pack is loaded would make adding a jurisdiction
    a change in two places, which is the thing the pack architecture exists to
    prevent. The consequence is stated on the decision instead: the resolver
    records the code as unmatched rather than quietly dropping it.
    """
    report = importer.parse(_with(residency="NZ"))
    assert report.ok and report.valid[0].values["residency"] == "NZ"


def test_a_cross_border_row_survives_the_round_trip(client, session):
    """Imported and seeded clients must be the same kind of thing."""
    text = _csv(
        "imp-test-cb,sterling,Test Cross,1990-01-01,retail,true,2026-01-15,3,"
        "false,10000000,2,,500000,AU,HK,SG",
        header=",".join(
            importer.REQUIRED_COLUMNS + ("jurisdiction", "residency", "domicile")
        ),
    )
    assert client.post(
        "/import/clients", json={"csv_text": text, "commit": True}
    ).json()["committed"]

    body = client.get("/clients/imp-test-cb").json()
    assert body["cross_border"] is True
    assert {j["jurisdiction"] for j in body["applicable_jurisdictions"]} == {
        "AU",
        "HK",
        "SG",
    }


# --- preview and commit --------------------------------------------------


def test_preview_is_the_default_and_writes_nothing(client, session):
    before = session.query(Client).count()
    response = client.post("/import/clients", json={"csv_text": SAMPLE.read_text()})

    assert response.status_code == 200
    body = response.json()
    assert body["ok"] and body["committed"] is False
    assert body["new_clients"] + body["updated_clients"] == 5
    session.expire_all()
    assert session.query(Client).count() == before


def test_a_file_with_any_bad_row_writes_nothing(client, session):
    """All-or-nothing: a partial import leaves a book nobody chose."""
    before = session.query(Client).count()
    text = _csv(GOOD_ROW, "BAD ID,atlantis,,,,,,,,,,,")
    response = client.post("/import/clients", json={"csv_text": text, "commit": True})

    body = response.json()
    assert body["ok"] is False and body["committed"] is False
    session.expire_all()
    assert session.query(Client).count() == before


def test_committing_creates_the_clients_and_is_audited(client, session):
    text = _csv(GOOD_ROW)
    body = client.post("/import/clients", json={"csv_text": text, "commit": True}).json()

    # New-vs-updated is not asserted here: the test database persists between
    # runs, so this row is new the first time and an update every time after.
    # What must hold either way is that the row lands exactly once.
    assert body["committed"] is True
    assert body["new_clients"] + body["updated_clients"] == 1
    session.expire_all()
    row = session.get(Client, "imp-test-one")
    assert row is not None and row.name == "Test One"
    assert row.scenario == "sterling" and row.loss_capacity_band == 3

    events = client.get("/audit/export").text
    assert "import.clients" in events


def test_reimporting_updates_rather_than_duplicating(client, session):
    """A CRM record legitimately changes. `clients` is not append-only."""
    client.post("/import/clients", json={"csv_text": _csv(GOOD_ROW), "commit": True})
    changed = GOOD_ROW.replace("Test One", "Test One Renamed").replace(",3,false", ",4,false")
    body = client.post(
        "/import/clients", json={"csv_text": _csv(changed), "commit": True}
    ).json()

    assert body["updated_clients"] == 1 and body["new_clients"] == 0
    session.expire_all()
    row = session.get(Client, "imp-test-one")
    assert row.name == "Test One Renamed" and row.loss_capacity_band == 4


def test_an_update_does_not_reach_backwards_into_a_recorded_decision(client, session):
    """The safety here is structural: replay reads the frozen snapshot."""
    client.post("/import/clients", json={"csv_text": _csv(GOOD_ROW), "commit": True})
    decision = client.post(
        "/evaluate", json={"client_id": "imp-test-one", "asset_id": "BTC"}
    ).json()
    band_at_decision = decision["snapshot"]["client"]["loss_capacity_band"]

    changed = GOOD_ROW.replace(",3,false", ",5,false")
    client.post("/import/clients", json={"csv_text": _csv(changed), "commit": True})

    replay = client.post(f"/decisions/{decision['id']}/replay", json={}).json()
    assert replay["match"] is True
    assert replay["differences"] == []
    stored = client.get(f"/decisions/{decision['id']}").json()
    assert stored["snapshot"]["client"]["loss_capacity_band"] == band_at_decision


def test_the_result_always_states_that_custody_is_not_imported(client):
    """The consequential mock. Silence here reads as 'this client holds nothing'."""
    body = client.post("/import/clients", json={"csv_text": SAMPLE.read_text()}).json()
    warning = body["custody_warning"]
    assert "custody" in warning.lower()
    assert "holds nothing" in warning


# --- the custody boundary is visible ------------------------------------


def test_custody_distinguishes_absent_from_empty():
    custody = FixturePositionsProvider()
    assert custody.has_record("margaret-wu") is True
    assert custody.has_record("nobody-by-this-name") is False
    # Both still return the same figures — which is exactly why has_record exists.
    assert custody.get("nobody-by-this-name", None)["crypto_value_cents"] == 0


def test_an_imported_client_is_flagged_as_having_no_custody_record(client, session):
    client.post("/import/clients", json={"csv_text": _csv(GOOD_ROW), "commit": True})
    detail = client.get("/clients/imp-test-one").json()

    assert detail["custody_on_file"] is False
    assert detail["positions"]["holdings"] == []
    seeded = client.get("/clients/margaret-wu").json()
    assert seeded["custody_on_file"] is True


def test_an_imported_client_does_not_join_the_demo_cast(client, session):
    """The home screen is a walkthrough, not a client list.

    Cast membership used to be inferred from `note` being non-empty, which meant
    any imported row with a note in it appeared on the home screen alongside the
    six clients the demo was written around. A CSV column should not be able to
    grant that.
    """
    row = GOOD_ROW + ",AU,A note that must not promote this client"
    header = ",".join(importer.REQUIRED_COLUMNS + ("jurisdiction", "note"))
    client.post("/import/clients", json={"csv_text": f"{header}\n{row}\n", "commit": True})

    cast = client.get("/clients?cast_only=true").json()
    ids = [c["id"] for c in cast]
    assert "imp-test-one" not in ids
    assert "margaret-wu" in ids
    # And the client is still a client — it is only absent from the walkthrough.
    assert client.get("/clients/imp-test-one").status_code == 200


# --- the integrations register -------------------------------------------


def test_every_edge_declares_a_status_and_what_it_stands_for(client):
    body = client.get("/integrations").json()
    assert body["edges"]
    for edge in body["edges"]:
        assert edge["status"] in ("live", "fixture", "local")
        assert edge["stands_for"].strip()
        assert edge["implementation"].strip()
        assert len(edge["detail"].strip()) >= 40


def test_every_mocked_edge_names_the_protocol_that_replaces_it(client):
    """Invariant: mocks sit behind a protocol, so replacing one is not a rewrite."""
    for edge in client.get("/integrations").json()["edges"]:
        if edge["status"] != "live":
            assert edge["replaced_by"], edge["id"]


def test_custody_is_declared_mocked_and_states_its_consequence(client):
    custody = next(e for e in client.get("/integrations").json()["edges"] if e["id"] == "custody")
    assert custody["status"] == "fixture"
    assert "concentration" in custody["consequence"].lower()


def test_the_register_counts_rather_than_asserts(client, session):
    """A hardcoded label goes stale into a lie; a computed one cannot."""
    crm = next(e for e in client.get("/integrations").json()["edges"] if e["id"] == "crm")
    assert str(session.query(Client).count()) in crm["detail"]


def test_nothing_claims_to_be_connected_to_an_external_system(client):
    body = client.get("/integrations").json()
    assert body["mocked"] >= 2
    for edge in body["edges"]:
        if edge["status"] == "live":
            # "live" means real code on real data here, never an outbound integration.
            assert "external" not in edge["detail"].lower() or "not" in edge["detail"].lower()
