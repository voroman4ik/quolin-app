"""T3: the audit trail is tamper-evident now, not merely append-only.

`docs/threat-model.md` recorded this as **not closed** from §S9 until §S13's
external review named it the largest unmitigated item in the document.
Determinations were hash-chained; audit events were append-only and nothing
more. Append-only stops the application role editing or deleting a row. It does
nothing about a privileged actor inserting history that never happened, and the
CSV export carried no arithmetic proof that the sequence was intact — an auditor
reading it had our word.

The distinction that survives this change: tamper-**evident**, not tamper-proof.
The owning database role is still a trust boundary. What it can no longer do is
alter the record without the alteration being visible.
"""

from __future__ import annotations

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import select, text

from app import evidence, service, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.models import AuditEvent

ACTOR = "apc_bulk_sweep"


def _highest() -> int:
    owner = OwnerSessionLocal()
    try:
        return (
            owner.scalar(
                text(
                    "SELECT COALESCE(MAX(id), 0) FROM audit_events "
                    "WHERE tenant_id = :t"
                ),
                {"t": DEMO_TENANT},
            )
            or 0
        )
    finally:
        owner.close()


@pytest.fixture
def undo():
    """Remove what this file wrote, as the owner and with the trigger down.

    The same route `scripts/rechain.py` takes, and for the same reason: the
    table refuses the application role, which is the property working.
    """
    high = _highest()
    yield
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text("ALTER TABLE audit_events DISABLE TRIGGER audit_events_append_only")
        )
        owner.execute(
            text("DELETE FROM audit_events WHERE tenant_id = :t AND id > :id"),
            {"t": DEMO_TENANT, "id": high},
        )
        owner.execute(
            text("ALTER TABLE audit_events ENABLE TRIGGER audit_events_append_only")
        )
        owner.commit()
    finally:
        owner.close()


def test_new_audit_rows_chain(undo):
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            for n in range(4):
                service.audit(session, "probe.write", f"row {n}")
            session.commit()
            result = evidence.verify_audit_chain(session)
        finally:
            session.close()

    assert result["verified"], result
    assert result["checked"] >= 4


def test_a_forged_row_is_caught(undo):
    """The whole point: history that never happened does not verify.

    Edited as the owner with the trigger down — precisely the actor the threat
    model names as a trust boundary, and exactly what this chain exists to make
    visible.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            for n in range(3):
                service.audit(session, "probe.write", f"row {n}")
            session.commit()
        finally:
            session.close()

    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text("ALTER TABLE audit_events DISABLE TRIGGER audit_events_append_only")
        )
        owner.execute(
            text(
                "UPDATE audit_events SET subject = 'a thing that did not happen' "
                "WHERE id = (SELECT MAX(id) FROM audit_events WHERE tenant_id = :t)"
            ),
            {"t": DEMO_TENANT},
        )
        owner.execute(
            text("ALTER TABLE audit_events ENABLE TRIGGER audit_events_append_only")
        )
        owner.commit()
    finally:
        owner.close()

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            result = evidence.verify_audit_chain(session)
        finally:
            session.close()

    assert not result["verified"], "an edited audit row verified"
    assert result["broken_at_audit_id"], result


def test_rows_written_before_the_chain_are_unlinked_not_broken(undo):
    """An absence reported as an absence.

    The seeded history predates the chain. Reporting it as a break would be as
    wrong as reporting it as verified, and both would train somebody to ignore
    the number.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            result = evidence.verify_audit_chain(session)
        finally:
            session.close()

    assert result["verified"], result
    assert "unlinked" in result, "the count has to be reported separately"


def test_the_audit_chain_is_this_tenants_own(undo):
    """Two firms, two chains, and neither genesis is the other's."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            mine = evidence.audit_genesis(session)
        finally:
            session.close()

    # Provisioned here rather than borrowed. `neighbour` exists only after
    # `test_rls.py` has run, so a test that assumes it passes alone and errors
    # in the suite — which this repository has learned twice already.
    other_tenant = "audit-chain-probe"
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "INSERT INTO tenants "
                "(id, name, region, tier, status, stage, config, created_at) "
                "VALUES (:id, 'Audit Chain Probe', 'ap-southeast-2', 'shared', "
                "'active', 'pilot', '{}'::jsonb, now()) "
                "ON CONFLICT (id) DO NOTHING"
            ),
            {"id": other_tenant},
        )
        owner.commit()
        with tenancy.acting_as(other_tenant), tenancy.acting_as_user(ACTOR):
            evidence.ensure_anchor(owner, other_tenant)
            owner.commit()
    finally:
        owner.close()

    with tenancy.acting_as(other_tenant), tenancy.acting_as_user(ACTOR):
        other = SessionLocal()
        try:
            theirs = evidence.audit_genesis(other)
        finally:
            other.close()

    assert mine != theirs, "two firms share an audit genesis"


def test_the_audit_genesis_is_not_the_decision_genesis(undo):
    """One anchor, two chains. Splicing one onto the other must not verify."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            assert evidence.audit_genesis(session) != evidence.anchor_hash(session)
        finally:
            session.close()


def test_two_writers_cannot_fork_the_audit_chain(undo):
    """The §S13 lesson, applied before it can be learned twice.

    The determination chain forked under concurrent writes because nothing
    serialised appends within a tenant. This chain takes the same lock and
    carries the same unique index, so the failure cannot repeat here.
    """
    owner = OwnerSessionLocal()
    try:
        indexes = {
            row[0]
            for row in owner.execute(
                text(
                    "SELECT indexname FROM pg_indexes WHERE tablename = 'audit_events'"
                )
            ).all()
        }
        forks = owner.execute(
            text(
                "SELECT tenant_id, prev_hash, count(*) FROM audit_events "
                "WHERE prev_hash <> '' GROUP BY tenant_id, prev_hash "
                "HAVING count(*) > 1"
            )
        ).all()
    finally:
        owner.close()

    assert "ix_audit_events_one_child_per_parent" in indexes
    assert not forks, f"an audit chain has forked: {forks}"


def test_the_chain_does_not_change_what_the_trail_says(undo):
    """A row's meaning is its fields, and the hash commits to all of them."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            service.audit(session, "probe.readback", "unchanged")
            session.commit()
            row = session.scalars(
                select(AuditEvent)
                .where(AuditEvent.action == "probe.readback")
                .order_by(AuditEvent.id.desc())
                .limit(1)
            ).first()
            assert row is not None
            assert row.actor == ACTOR
            assert row.subject == "unchanged"
            assert row.this_hash and row.prev_hash
        finally:
            session.close()


def test_a_tenant_with_no_anchor_still_gets_its_audit_row(undo):
    """The coupling that must not exist, found by CI on the fix that made it.

    `service.audit` is called on the way through almost every mutation, so an
    audit write that raises takes the action with it. Chaining the trail must
    never be able to stop the trail being written — and two tenants created by
    migration have no chain anchor, because they never went through
    `ensure_anchor`.

    The row is written unlinked. `verify_audit_chain` counts those separately
    and `rechain --table audit_events` links them once an anchor exists, so the
    absence is reported rather than hidden.
    """
    from sqlalchemy import func

    owner = OwnerSessionLocal()
    try:
        anchorless = owner.scalars(
            text(
                "SELECT t.id FROM tenants t "
                "LEFT JOIN chain_anchors a ON a.tenant_id = t.id "
                "WHERE a.tenant_id IS NULL LIMIT 1"
            )
        ).first()
    finally:
        owner.close()

    # R2 §8.1. This used to skip when every tenant had an anchor — which is what
    # a fully migrated database looks like, so the test vanished in exactly the
    # state the deployment is in. A negative test that disappears when the
    # dangerous condition is absent has never run against the condition it was
    # written for.
    #
    # So the state is manufactured: a tenant with no `chain_anchors` row, inside
    # a transaction that is rolled back. `chain_anchors` is append-only, so this
    # cannot be done by deleting one — the tenant is created without ever
    # getting an anchor, which is the state a half-provisioned firm is in and
    # the state this test exists for.
    if anchorless is None:
        owner = OwnerSessionLocal()
        try:
            owner.execute(
                text(
                    "INSERT INTO tenants (id, name, region, tier, status, stage, "
                    "config, created_at) VALUES ('anchorless-probe', "
                    "'Anchorless probe', 'ap-southeast-2', 'shared', 'active', "
                    "'pilot', '{}'::jsonb, now()) ON CONFLICT (id) DO NOTHING"
                )
            )
            owner.commit()
            anchorless = "anchorless-probe"
        finally:
            owner.close()

    with tenancy.acting_as(anchorless), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            before = session.scalar(
                select(func.count(AuditEvent.id)).where(
                    AuditEvent.tenant_id == anchorless
                )
            )
            service.audit(session, "probe.anchorless", "written anyway")
            session.commit()
            after = session.scalar(
                select(func.count(AuditEvent.id)).where(
                    AuditEvent.tenant_id == anchorless
                )
            )
            newest = session.scalars(
                select(AuditEvent)
                .where(AuditEvent.tenant_id == anchorless)
                .order_by(AuditEvent.id.desc())
                .limit(1)
            ).first()
        finally:
            session.close()

    assert after == before + 1, "an audit row was lost because the chain refused it"
    assert newest is not None and newest.this_hash == "", (
        "the row should be unlinked, not linked to a chain that has no start"
    )
