"""The linter that guards the schema, itself guarded — by alembic, not by SQL.

A guard nobody has watched fail is a guard nobody knows works. The execution
document asks for the migration linter to be proven with a sacrificial
migration; doing that in CI rather than by hand means it stays proven after the
person who wrote it has forgotten it exists.

**Every case here is a real alembic migration**, and that is the finding this
file was rewritten around. The previous version wrote raw `.sql` files into a
temp directory and asserted the linter refused them — which it did. Meanwhile
all thirty-five migrations in this repository are alembic Python, and FP3-01
established by execution that the same seven violations written the way they
would actually be written all passed with exit 0. The test suite was proving the
guard worked against inputs the guard would never see.

So each sacrificial case below is chained onto the real head, applied to a
scratch database by alembic, and the linter's verdict is read from what the
catalog says afterwards. A case that does not survive `alembic upgrade` is not a
case: it has to be a migration somebody could really merge.
"""

from __future__ import annotations

import shutil
import subprocess
import textwrap
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
LINTER = REPO / "scripts" / "lint_migrations.sh"
REAL_MIGRATIONS = REPO / "api" / "migrations"


def head_revision() -> str:
    """The revision a new migration in this repository would chain onto."""
    from alembic.config import Config
    from alembic.script import ScriptDirectory

    config = Config()
    config.set_main_option("script_location", str(REAL_MIGRATIONS))
    return ScriptDirectory.from_config(config).get_current_head()


def sacrificial(tmp_path: Path, body: str, *, imports: str = "") -> Path:
    """A copy of the real tree with one more migration on the end of it."""
    tree = tmp_path / "migrations"
    shutil.copytree(REAL_MIGRATIONS, tree, ignore=shutil.ignore_patterns("__pycache__"))
    # Built without an outer dedent on purpose: dedent would run over the body
    # after substitution and recompute a common prefix across both the template
    # and the injected lines, which silently reindents multi-line bodies into a
    # migration that will not parse. The header is written flush and the body is
    # indented once, so what the body looks like here is what alembic loads.
    source = "\n".join(
        [
            '"""A migration written to be refused."""',
            "",
            "from __future__ import annotations",
            "",
            "import sqlalchemy as sa",
            "from alembic import op",
            "from sqlalchemy.dialects import postgresql",
            imports,
            "",
            'revision = "9999_sacrificial"',
            f'down_revision = "{head_revision()}"',
            "branch_labels = None",
            "depends_on = None",
            "",
            "",
            "def upgrade() -> None:",
            textwrap.indent(textwrap.dedent(body).strip(), "    "),
            "",
            "",
            "def downgrade() -> None:",
            '    raise NotImplementedError("sacrificial")',
            "",
        ]
    )
    (tree / "versions" / "9999_sacrificial.py").write_text(source)
    return tree


def run(tree: Path, *args: str) -> subprocess.CompletedProcess[str]:
    """The linter, through the shell entry point CI calls."""
    import os

    env = dict(os.environ)
    env["MIGRATIONS_DIR"] = str(tree)
    return subprocess.run(
        ["bash", str(LINTER), "--since", head_revision(), *args],
        cwd=REPO,
        env=env,
        capture_output=True,
        text=True,
    )


# Every bullet FP3-01 listed, written the way alembic writes it. Each of these
# passed the regex linter with exit 0.
ALEMBIC_CASES = [
    pytest.param(
        'op.drop_column("decisions", "prev_hash")',
        "prev_hash",
        id="drop_column-chain",
    ),
    pytest.param(
        'op.drop_column("decisions", "this_hash")',
        "this_hash",
        id="drop_column-this-hash",
    ),
    pytest.param(
        'op.execute("GRANT ALL ON decisions TO quolin_app;")',
        "append-only",
        id="grant-all",
    ),
    pytest.param(
        'op.execute("""\n'
        "    GRANT UPDATE,\n"
        "          DELETE\n"
        "    ON decisions TO quolin_app;\n"
        '""")',
        "append-only",
        id="grant-across-lines",
    ),
    pytest.param(
        'op.execute("""\n'
        "    CREATE OR REPLACE FUNCTION quolin_append_only() RETURNS trigger AS $$\n"
        "    BEGIN RETURN NEW; END;\n"
        "    $$ LANGUAGE plpgsql;\n"
        '""")',
        "quolin_append_only",
        id="replace-trigger-function",
    ),
    pytest.param(
        'op.add_column("decisions", sa.Column("fee", sa.Double()))',
        "double precision",
        id="sa-double",
    ),
    pytest.param(
        'op.add_column("decisions", sa.Column("fee", postgresql.DOUBLE_PRECISION()))',
        "double precision",
        id="postgresql-double-precision",
    ),
    pytest.param(
        'op.execute("ALTER TABLE decisions ADD COLUMN fee MONEY;")',
        "money",
        id="money",
    ),
    pytest.param(
        'op.add_column("decisions", sa.Column("fee", sa.Numeric(10, 2)))',
        "numeric",
        id="numeric",
    ),
    pytest.param(
        'op.execute("ALTER ROLE quolin_app BYPASSRLS;")',
        "BYPASSRLS",
        id="bypassrls",
    ),
    pytest.param(
        'op.execute("DROP POLICY tenant_isolation ON clients;")',
        "drops policy",
        id="drop-policy",
    ),
    pytest.param(
        'op.execute("ALTER TABLE clients DISABLE ROW LEVEL SECURITY;")',
        "disables row-level security",
        id="disable-rls",
    ),
    pytest.param(
        'op.execute("ALTER TABLE clients NO FORCE ROW LEVEL SECURITY;")',
        "un-forces row-level security",
        id="no-force-rls",
    ),
    pytest.param(
        'op.execute("ALTER TABLE decisions OWNER TO quolin_app;")',
        "changes the owner",
        id="owner-to",
    ),
    pytest.param(
        'op.execute("DROP TRIGGER decisions_append_only ON decisions;")',
        "drops trigger",
        id="drop-trigger",
    ),
    pytest.param(
        'op.execute("ALTER TABLE decisions DISABLE TRIGGER decisions_append_only;")',
        "disables trigger",
        id="disable-trigger",
    ),
]


@pytest.mark.parametrize("body,expected", ALEMBIC_CASES)
def test_an_alembic_migration_that_undoes_an_invariant_is_refused(
    tmp_path: Path, body: str, expected: str
) -> None:
    result = run(sacrificial(tmp_path, body), "--no-downgrades")
    assert result.returncode == 1, (
        f"linter allowed {body!r}\nstdout:\n{result.stdout}\nstderr:\n{result.stderr}"
    )
    assert expected in result.stdout, result.stdout


# The eight append-only tables the old five-name regex did not cover. Each of
# these is evidence, and a grant on any of them passed the previous guard
# silently because its list was typed by hand and the schema moved on.
@pytest.mark.parametrize(
    "table",
    [
        "chain_anchors",
        "pack_draft_transitions",
        "watch_assist_calls",
        "security_events",
        "tenant_stages",
        "auth_attempts",
        "source_verifications",
        "pack_publications",
        "chain_rechains",
    ],
)
def test_a_grant_on_an_append_only_table_outside_the_old_regex_is_refused(
    tmp_path: Path, table: str
) -> None:
    body = f'op.execute("GRANT UPDATE, DELETE ON {table} TO quolin_app;")'
    result = run(sacrificial(tmp_path, body), "--no-downgrades")
    assert result.returncode == 1, f"linter allowed a write grant on {table}"
    assert "append-only" in result.stdout


# One raw-SQL case per rule as well. The guard reads the catalog, so the
# spelling is irrelevant by construction — these exist to keep that true rather
# than because anybody expects them to behave differently.
@pytest.mark.parametrize(
    "statement,expected",
    [
        ("GRANT UPDATE ON decisions TO quolin_app;", "append-only"),
        ("DROP TRIGGER audit_events_append_only ON audit_events;", "drops trigger"),
        ("ALTER TABLE decisions ADD COLUMN fee NUMERIC(10,2);", "numeric"),
        ("ALTER TABLE audit_events DROP COLUMN this_hash;", "this_hash"),
        ("DROP POLICY tenant_isolation ON decisions;", "drops policy"),
        ("ALTER ROLE quolin_watch BYPASSRLS;", "BYPASSRLS"),
    ],
)
def test_the_same_violation_written_as_raw_sql_is_refused(
    tmp_path: Path, statement: str, expected: str
) -> None:
    result = run(sacrificial(tmp_path, f'op.execute("{statement}")'), "--no-downgrades")
    assert result.returncode == 1, f"linter allowed {statement!r}"
    assert expected in result.stdout


def test_an_ordinary_migration_passes(tmp_path: Path) -> None:
    """The linter has to be quiet about the normal case or nobody will keep it."""
    body = """
    op.add_column("clients", sa.Column("preferred_name", sa.Text(), nullable=True))
    op.add_column(
        "decisions",
        sa.Column("amount_cents", sa.BigInteger(), nullable=False, server_default="0"),
    )
    op.create_index("ix_decisions_as_of_probe", "decisions", ["as_of"])
    """
    result = run(sacrificial(tmp_path, body), "--no-downgrades")
    assert result.returncode == 0, result.stdout + result.stderr


def test_the_real_tree_is_clean_in_both_directions() -> None:
    """Including every downgrade, which is where 0026 was hiding.

    This is the assertion the old linter reported as OK while migration 0026's
    downgrade dropped both audit-chain columns. It runs the full walk — no
    `--since`, no `--no-downgrades` — because the point of it is the direction
    nobody was looking at.
    """
    result = subprocess.run(
        ["bash", str(LINTER)], cwd=REPO, capture_output=True, text=True
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "OK:" in result.stdout


def test_0026_still_refuses_to_reverse() -> None:
    """The counter-example, pinned so it cannot come back.

    0026's downgrade dropped `prev_hash` and `this_hash` from `audit_events`.
    The decision recorded in FP3-01 was to make it refuse rather than to
    allow-list it: twelve migrations in this tree already decline to reverse for
    the same class of reason, so refusing is the repository's existing idiom
    rather than a new one invented for this finding.
    """
    from alembic.config import Config
    from alembic.script import ScriptDirectory

    config = Config()
    config.set_main_option("script_location", str(REAL_MIGRATIONS))
    script = ScriptDirectory.from_config(config)
    module = script.get_revision("0026_audit_chain").module

    with pytest.raises(NotImplementedError, match="not reversible"):
        module.downgrade()


def test_a_missing_migrations_directory_is_a_failure_not_a_pass(tmp_path: Path) -> None:
    """F12's rule, kept, and now asserted against the rewritten guard."""
    import os

    env = dict(os.environ)
    env["MIGRATIONS_DIR"] = str(tmp_path / "nowhere")
    result = subprocess.run(
        ["bash", str(LINTER)], cwd=REPO, env=env, capture_output=True, text=True
    )
    assert result.returncode == 1
    assert "FAIL" in result.stdout


def test_an_empty_migrations_directory_is_a_failure_not_a_pass(tmp_path: Path) -> None:
    import os

    (tmp_path / "versions").mkdir(parents=True)
    env = dict(os.environ)
    env["MIGRATIONS_DIR"] = str(tmp_path)
    result = subprocess.run(
        ["bash", str(LINTER)], cwd=REPO, env=env, capture_output=True, text=True
    )
    assert result.returncode == 1
    assert "FAIL" in result.stdout
