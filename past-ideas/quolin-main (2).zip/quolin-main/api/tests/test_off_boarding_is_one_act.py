"""FP3-13: there was no way to end somebody's access.

`user.status` is checked at sign-in — `identity.authenticate` refuses anything
that is not `active` — and was set by nothing but the seed. So the control
existed, worked, and could not be used.

What off-boarding actually took was revoking each of a person's grants one at a
time, and that leaves two things wrong:

  * **The trail records N revocations and no statement that somebody left.** An
    access review reading it has to infer the event from the absence of grants,
    which is not the same claim and is not one anybody signed.
  * **Nothing ends their live sessions.** A browser open at the moment the last
    grant went keeps working until the cookie expires, and a person with no
    grants still holds an account that authenticates.

One act now: status, sessions, and one audit event naming who decided and why.
"""

from __future__ import annotations

import pytest
from conftest import (
    ADMIN_EMAIL,
    DEMO_TENANT,
    PUBLISHER_EMAIL,
    TEST_PASSWORD,
    reset_rate_limit_for_tests,
    sign_in,
)
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import auth, identity, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import AuditEvent, AuthSession, User, UserRole

PROBE_EMAIL = "fp3-13-probe@quolin.example"


@pytest.fixture
def publisher():
    """Signed in as the role that provisions. `quolin_operator` holds it."""
    with TestClient(app) as c:
        yield sign_in(c, PUBLISHER_EMAIL)


@pytest.fixture
def a_provisioned_person(publisher):
    """Somebody to off-board, created through the API like anybody else."""
    made = publisher.post(
        "/admin/users",
        json={"email": PROBE_EMAIL, "display_name": "FP3-13 probe"},
    )
    assert made.status_code in (200, 201), made.text
    user_id = made.json()["id"]

    # Reinstated unconditionally, because most of the tests below suspend them
    # and `POST /admin/users` is idempotent — it returns the existing person
    # rather than refusing, so there is no "already exists" branch to hang this
    # on. Without it the first test to suspend leaves every later one starting
    # from a suspended account, and "a suspended account cannot sign in" passes
    # whatever the route does.
    with OwnerSessionLocal() as s:
        identity.set_status(s, user_id=user_id, status=identity.ACTIVE)
        s.commit()

    # A grant, because `/auth/login` refuses an account with no business in this
    # firm before it ever looks at `status` — so without one, "a suspended
    # account cannot sign in" would pass for the wrong reason.
    #
    # Checked before granting rather than granted and forgiven: `POST
    # /admin/users` is idempotent and returns the existing person, so on the
    # second run of this suite the account is already there with the role, and
    # re-granting hits `user_roles_grant_key`.
    with OwnerSessionLocal() as s:
        held = s.scalars(
            select(UserRole).where(
                UserRole.user_id == user_id, UserRole.role == "viewer"
            )
        ).first()
    if held is None:
        granted = publisher.post(
            f"/admin/users/{user_id}/roles", json={"role": "viewer"}
        )
        assert granted.status_code in (200, 201), granted.text
    return user_id


def _status(user_id: str) -> str:
    """Read through the owner connection.

    `users` is a platform table: its policy makes a row invisible until
    `app.user_id` is set, which is what stops one person enumerating another's
    account. A test asserting *about* an account is exactly the case that has no
    such scope, so it reads as the owner rather than pretending to be somebody.
    """
    with OwnerSessionLocal() as s:
        row = s.get(User, user_id)
        assert row is not None, f"no user {user_id}"
        return row.status


def test_a_person_can_be_suspended_in_one_act(publisher, a_provisioned_person):
    """The finding: there was no route at all."""
    result = publisher.post(
        f"/admin/users/{a_provisioned_person}/suspend",
        json={"reason": "left the firm on 28 August"},
    )
    assert result.status_code == 200, result.text
    assert result.json()["account_status"] == "suspended"
    assert _status(a_provisioned_person) == "suspended"


def test_suspension_ends_the_sessions_they_already_hold(publisher, a_provisioned_person):
    """The half a status column cannot do on its own.

    Revoking grants one at a time leaves an open browser working until its
    cookie expires. This is the moment their access actually stops.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with SessionLocal() as s:
            auth.create_session(
                s,
                tenant_id=DEMO_TENANT,
                user_id=a_provisioned_person,
                mfa_satisfied=True,
                user_agent="probe",
                ip="203.0.113.9",
            )
            s.commit()

    result = publisher.post(
        f"/admin/users/{a_provisioned_person}/suspend",
        json={"reason": "credential reached the wrong person"},
    )
    assert result.status_code == 200, result.text
    assert result.json()["sessions_ended"] >= 1

    with tenancy.acting_as(DEMO_TENANT):
        with SessionLocal() as s:
            left = s.scalars(
                select(AuthSession).where(
                    AuthSession.user_id == a_provisioned_person
                )
            ).all()
    assert left == [], "a suspended person still holds a live session"


def test_one_audit_event_says_who_decided_and_why(publisher, a_provisioned_person):
    """The statement an access review is looking for.

    N revocations are not it: they record that grants went, not that a person
    left, and nobody signed the inference.
    """
    publisher.post(
        f"/admin/users/{a_provisioned_person}/suspend",
        json={"reason": "resigned, last day 28 August"},
    )

    with tenancy.acting_as(DEMO_TENANT):
        with SessionLocal() as s:
            events = s.scalars(
                select(AuditEvent)
                .where(AuditEvent.action == "user.suspended")
                .order_by(AuditEvent.id.desc())
            ).all()

    assert events, "suspending somebody wrote no audit event"
    latest = events[0]
    assert a_provisioned_person in latest.subject
    assert "resigned" in latest.subject, "the stated reason is not in the trail"
    assert latest.actor, "the event names nobody as having decided"
    # Inside the chain migration 0026 added, like every other audit row.
    assert latest.this_hash, "the suspension is outside the audit hash chain"


def test_a_suspended_person_cannot_sign_in(publisher, a_provisioned_person):
    """The control that already existed, now reachable.

    Asserted end to end rather than against `user.status`, because the column
    being set and sign-in refusing are two claims and only the second one is
    what off-boarding means.
    """
    with OwnerSessionLocal() as s:
        identity.set_password(s, s.get(User, a_provisioned_person), TEST_PASSWORD)
        s.commit()

    with TestClient(app) as fresh:
        before = fresh.post(
            "/auth/login", json={"email": PROBE_EMAIL, "password": TEST_PASSWORD}
        )
        assert before.status_code == 200, (
            f"the probe could not sign in before suspension, so this proves "
            f"nothing: {before.text}"
        )

    publisher.post(
        f"/admin/users/{a_provisioned_person}/suspend",
        json={"reason": "off-boarded"},
    )
    reset_rate_limit_for_tests()

    with TestClient(app) as fresh:
        after = fresh.post(
            "/auth/login", json={"email": PROBE_EMAIL, "password": TEST_PASSWORD}
        )
    assert after.status_code == 401, "a suspended account still signs in"


def test_reinstating_puts_them_back(publisher, a_provisioned_person):
    """A suspension nobody can undo is one nobody uses for a person on leave.

    And a suspension people avoid using is one that does not happen when
    somebody actually leaves.
    """
    publisher.post(
        f"/admin/users/{a_provisioned_person}/suspend", json={"reason": "on leave"}
    )
    back = publisher.post(
        f"/admin/users/{a_provisioned_person}/reinstate",
        json={"reason": "returned from leave"},
    )
    assert back.status_code == 200, back.text
    assert _status(a_provisioned_person) == "active"


def test_an_administrator_cannot_suspend_themselves(publisher):
    """Locking the door from the outside.

    On a firm with one administrator this is an outage only we can fix, so it is
    refused rather than left to whoever is having a bad afternoon.
    """
    with OwnerSessionLocal() as s:
        me = s.scalars(select(User).where(User.email == PUBLISHER_EMAIL)).one().id

    refused = publisher.post(
        f"/admin/users/{me}/suspend", json={"reason": "testing the guard"}
    )
    assert refused.status_code == 422, refused.text
    assert _status(me) == "active"


def test_a_reason_is_required(publisher, a_provisioned_person):
    """"Who decided and on what grounds" is the first question a review asks."""
    refused = publisher.post(
        f"/admin/users/{a_provisioned_person}/suspend", json={"reason": ""}
    )
    assert refused.status_code == 422, refused.text


def test_an_ordinary_role_may_not_off_board_anybody(a_provisioned_person):
    """Provisioning is `quolin_operator`, and so is un-provisioning.

    A `tenant_admin` who could suspend accounts could suspend the people who
    review their overrides.
    """
    with TestClient(app) as c:
        admin = sign_in(c, ADMIN_EMAIL)
        refused = admin.post(
            f"/admin/users/{a_provisioned_person}/suspend",
            json={"reason": "should not be allowed"},
        )
    assert refused.status_code in (401, 403), refused.text
    assert _status(a_provisioned_person) == "active"
