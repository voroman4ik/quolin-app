"""The one tool that rewrites evidence, made to leave a record of having done so.

`scripts/rechain.py` is a legitimate maintenance tool and it is also the only
thing in this system that rewrites hashes on rows already written. Its own module
note has said so since it was written: *"this is the one tool here that looks
exactly like a tamper"*.

It refused a chain that does not verify, it was a dry run unless told otherwise,
and it wrote one audit event afterwards. Three things were missing.

**Nobody had to say why, or who they were.** `--apply` was enough. A rewrite of
a firm's evidence with no stated reason and no named operator is indistinguishable
from the thing it looks like.

**The old tip was not preserved.** The event named the new one. An auditor
holding an export from before the rechain and one from after has every hash
different and nothing to reconcile them against, which is exactly the position
this tool's own docstring says it puts them in.

**And the audit event it wrote was not chained.** It constructed `AuditEvent`
directly and never called `link_audit`, so the row went in with an empty hash —
which, since Q-13 made an unlinked row after the chain tip a verification
failure, means running `--apply` broke the audit chain it had just repaired.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest
from sqlalchemy import select

from app import evidence, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.models import ChainRechain
from tests.conftest import DEMO_TENANT

REPO = Path(__file__).resolve().parents[2]


def _run(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "-m", "scripts.rechain", *args],
        cwd=REPO,
        capture_output=True,
        text=True,
        timeout=300,
    )


def _rechain_records() -> list[ChainRechain]:
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            return list(
                session.scalars(
                    select(ChainRechain).order_by(ChainRechain.id)
                )
            )
        finally:
            session.close()


# ------------------------------------------------------------- the refusals --


def test_applying_without_a_reason_is_refused() -> None:
    """A rewrite of a firm's evidence with no stated reason is indistinguishable
    from the thing it looks like."""
    result = _run("--apply")
    assert result.returncode != 0, result.stdout
    assert "--reason" in (result.stdout + result.stderr)


def test_applying_without_a_named_operator_is_refused() -> None:
    """"The system did it" is not an answer to "who rewrote this"."""
    result = _run("--apply", "--reason", "migrated across a payload change")
    assert result.returncode != 0, result.stdout
    assert "--by" in (result.stdout + result.stderr)


def test_a_dry_run_needs_neither() -> None:
    """Reading is not rewriting.

    The default has to stay usable without ceremony, or the tool stops being run
    to *find out* whether a rechain is needed — which is what it is mostly for.
    """
    result = _run()
    assert result.returncode == 0, result.stdout + result.stderr
    assert "Dry run" in result.stdout or "Nothing to do" in result.stdout


# --------------------------------------------------------------- the record --


def test_an_applied_rechain_records_itself(tmp_path) -> None:
    """Both tips, the reason, the operator, and the count.

    Run against a chain that is already correct, so nothing is rewritten and the
    demo database is not disturbed — what is under test is that the act is
    *recorded*, and a no-op rechain is still an act somebody performed.
    """
    before = len(_rechain_records())

    result = _run(
        "--apply",
        "--reason",
        "checking that a rechain records itself",
        "--by",
        "a.named.operator@quolin.example",
    )
    assert result.returncode == 0, result.stdout + result.stderr

    records = _rechain_records()
    assert len(records) == before + 1, (
        "an applied rechain left no record of itself. The tool that rewrites "
        "evidence is the one that most needs to."
    )
    latest = records[-1]
    assert latest.by_operator == "a.named.operator@quolin.example"
    assert latest.reason == "checking that a rechain records itself"
    assert latest.table_name == "decisions"
    assert latest.tip_before, "the tip before the rewrite was not preserved"
    assert latest.tip_after, "the tip after the rewrite was not recorded"
    assert isinstance(latest.rows_changed, int)


def test_the_record_is_append_only() -> None:
    """A rechain that could be un-recorded is a rechain that was never recorded."""
    from sqlalchemy import text
    from sqlalchemy.exc import DBAPIError

    # R2 §8.2. This used to skip when no rechain was on file, which means a
    # fully migrated database — the ordinary case — made the test vanish. A
    # negative test that disappears when the dangerous state is absent is a test
    # that has never run in the state it was written for.
    #
    # The row is manufactured instead, inside a transaction that is rolled back,
    # so the assertion is the same whether or not anybody has rechained.
    owner = OwnerSessionLocal()
    transaction = owner.begin()
    try:
        records = _rechain_records()
        if records:
            target = records[-1].id
        else:
            target = owner.execute(
                text(
                    "INSERT INTO chain_rechains (tenant_id, table_name, reason, "
                    "tip_before, tip_after, rows_changed, actor, at) VALUES "
                    "('demo', 'decisions', 'probe', 'a', 'b', 0, 'probe', now()) "
                    "RETURNING id"
                )
            ).scalar()
            owner.flush()

        with pytest.raises(DBAPIError):
            owner.execute(
                text("UPDATE chain_rechains SET reason = 'something else' WHERE id = :i"),
                {"i": target},
            )
            owner.flush()
    finally:
        transaction.rollback()
        owner.close()


def test_the_audit_chain_still_verifies_after_a_rechain() -> None:
    """The defect Q-13 exposed.

    The audit event this tool writes was constructed directly and never chained,
    so it went in with an empty hash. Once an unlinked row after the chain tip
    became a verification failure, running `--apply` broke the audit chain it had
    just been asked to repair.
    """
    _run(
        "--apply",
        "--reason",
        "checking the audit chain survives a rechain",
        "--by",
        "a.named.operator@quolin.example",
    )

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            audit = evidence.verify_audit_chain(session)
            decisions = evidence.verify_chain(session)
        finally:
            session.close()

    assert audit["verified"] is True, (
        f"the audit chain does not verify after a rechain: {audit}. The event "
        "recording the rechain was written without being chained."
    )
    assert decisions["verified"] is True, decisions


def test_both_audit_events_name_the_tips() -> None:
    """One before and one after, so an auditor holding two exports can reconcile
    them.

    The tool's own docstring says every hash is different afterwards and that
    an auditor comparing exports will see it. Naming only the new tip left them
    with the observation and not the answer.
    """
    from app.models import AuditEvent

    _run(
        "--apply",
        "--reason",
        "checking both events are written",
        "--by",
        "a.named.operator@quolin.example",
    )

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            events = list(
                session.scalars(
                    select(AuditEvent)
                    .where(AuditEvent.action.like("evidence.rechain%"))
                    .order_by(AuditEvent.id.desc())
                    .limit(2)
                )
            )
        finally:
            session.close()

    assert len(events) == 2, [e.action for e in events]
    actions = {e.action for e in events}
    assert actions == {"evidence.rechain.begin", "evidence.rechain.done"}, actions
    for event in events:
        assert event.this_hash, f"{event.action} was not chained"
        assert "a.named.operator@quolin.example" in event.subject, event.subject
