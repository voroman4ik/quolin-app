"""The §14 workflow, walked end to end, and what it must produce at the end of it.

The execution plan has one route from a proposal to rule content a firm may act
on: a draft is cut from the pack in force, a named specialist competent for that
regime signs it, and a second person publishes it. Every part of that mechanism
existed and had tests. Nobody had walked the whole thing and looked at what came
out the other end.

What came out was `PENDING_REVIEW`. `drafts.create` deep-copies the base body,
`content_status` and all; `drafts.publish` overwrote `signed_by` and `signed_at`
and nothing else; and `Pack.content_status` is `GENERATED ALWAYS` from
`body ->> 'content_status'`, so the column could only ever repeat what the body
said. A pack signed by a named specialist and published by a second person
landed as `PENDING_REVIEW`, `is_production_grade` false, and `packs_repo`
refused it to any firm at `limited` or `full`.

The only way to get a `REVIEWED` pack was therefore to hand-edit a file and
reseed as the owner — which bypasses signature capture, the content hash, the
jurisdiction-scoped signatory check and the second-pair-of-eyes rule. That is
the path §14 exists to forbid, and it was the only one that worked.

These tests are written through the API on purpose. A unit test on `publish`
would have passed at every point in this file's history; what was broken was the
workflow, and only a test that walks the workflow could see it.

**A note on what a valid signature is.** Publication does not stamp `REVIEWED`
merely because somebody with the `pack_signatory` role clicked sign. The
signature must name a person and carry a real qualification reference — the two
placeholder conventions this repository uses are refused, by shape. The seeded
demo signatory's qualification is `[illustrative — no engagement in place]`, so
the demo's content stays `PENDING_REVIEW` exactly as it should: stamping it
reviewed would be routing around the specialist, which is the thing migration
0025's CHECK constraint was added to make unstorable.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import adoption, identity, packs_repo, tenancy, totp
from app.db import OwnerSessionLocal, SessionLocal
from app.engine.pack import PENDING_REVIEW, REVIEWED, Pack
from app.main import app
from app.models import MfaCredential, Tenant
from app.models import Pack as PackRow
from seed.seed import SEED_PASSWORD
from tests.conftest import (
    DEMO_TENANT,
    OPERATOR_EMAIL,
    publish_through_the_api,
    sign_in,
    what_this_client_reads,
)

ACTOR = "apc_bulk_sweep"

#: A specialist who has actually been engaged, as against the seeded one who
#: has not. The qualification reference is what separates the two, and it is
#: the field the signature block prints.
ENGAGED_EMAIL = "engaged.specialist@quolin.example"
ENGAGED_QUALIFICATION = "AFSL 000000 / Legal Practising Certificate NSW 000000"

#: A signatory whose qualification is still a placeholder — the state every
#: signatory in this repository is actually in today.
UNENGAGED_EMAIL = "unengaged.specialist@quolin.example"
UNENGAGED_QUALIFICATION = "[illustrative — no engagement in place]"

#: Far enough out that nothing published here is ever the pack in force, so a
#: test that publishes cannot change what any other test evaluates against.
#: Asserted rather than assumed at the end of the first test.
FAR_FUTURE = 3650


def _specialist(email: str, qualification: str) -> str:
    """A signatory for AU with a second factor, ready to sign through the API."""
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            user = identity.find_by_email(owner, email)
            if user is None:
                user = identity.create_user(owner, email=email, display_name=email)
            identity.set_password(owner, user, SEED_PASSWORD)
            if not identity.roles_for(owner, user.id):
                identity.grant_role(
                    owner,
                    user_id=user.id,
                    role="pack_signatory",
                    jurisdiction="AU",
                    granted_by="test",
                    qualification_ref=qualification,
                )
            existing = owner.scalars(
                select(MfaCredential).where(MfaCredential.user_id == user.id)
            ).first()
            if existing is None:
                credential, _ = identity.enrol_totp(owner, user, label="test")
                owner.flush()
                identity.confirm_totp(owner, credential, totp.code_at(str(credential.secret)))
            owner.commit()
            return user.id
    finally:
        owner.close()


def _sign_in_signatory(client, email: str) -> None:
    """Sign in typing a current code, as a privileged account must."""
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            user = identity.find_by_email(owner, email)
            assert user is not None
            credential = owner.scalars(
                select(MfaCredential).where(MfaCredential.user_id == user.id)
            ).first()
            assert credential is not None
            credential.last_used_counter = 0
            owner.commit()
            code = totp.code_at(str(credential.secret))
    finally:
        owner.close()

    res = client.post(
        "/auth/login", json={"email": email, "password": SEED_PASSWORD, "code": code}
    )
    assert res.status_code == 200, res.text


def _cut_draft(title: str, *, days: int = FAR_FUTURE) -> int:
    """Cut a draft as the operator, through the API the workbench uses."""
    with TestClient(app) as operator:
        sign_in(operator, OPERATOR_EMAIL)
        res = operator.post(
            "/watch/drafts",
            json={
                "jurisdiction": "AU",
                "effective_from": (date.today() + timedelta(days=days)).isoformat(),
                "title": title,
                "rationale": "Written by tests/test_signing_produces_reviewed_content.py",
            },
        )
    assert res.status_code == 200, res.text
    return int(res.json()["id"])


def _sign(draft_id: int, email: str) -> None:
    with TestClient(app) as signatory:
        _sign_in_signatory(signatory, email)
        # Read, then sign what was read. This file is about what a signature
        # does to `content_status`, so the signature has to be an ordinary
        # honest one.
        res = signatory.post(
            f"/watch/drafts/{draft_id}/sign",
            json={
                "note": "Reviewed.",
                "signed_content_hash": what_this_client_reads(signatory, draft_id),
            },
        )
    assert res.status_code == 200, res.text


def _publish(draft_id: int) -> dict:
    # FP3-27. Publication takes two platform publishers, neither of them the
    # signatory. `PUBLISHER_EMAIL` holds `quolin_operator` and no platform
    # grant, so it can reach the endpoint and not perform the act — which is
    # the whole finding, and is asserted directly in
    # `test_publication_is_platform_scoped_with_dual_control.py`.
    def _as(email: str):
        client = TestClient(app)
        client.__enter__()
        sign_in(client, email)
        return client

    res = publish_through_the_api(_as, draft_id)
    assert res.status_code == 200, res.text
    return dict(res.json())


def _pack_row(pack_id: int) -> PackRow:
    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackRow, pack_id)
        assert row is not None
        owner.expunge(row)
        return row
    finally:
        owner.close()


#: A firm at `full` holding no permit for unreviewed content — the rung where a
#: determination reaches the world. Its own tenant rather than the demo firm,
#: which holds the permit precisely so its webhooks and referrals keep working.
ACTING_FIRM = "reviewed-probe"


def _acting_firm() -> str:
    """Create (once) a firm whose determinations have effect, and return its id."""
    from sqlalchemy import text

    from app import crypto, evidence

    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "INSERT INTO tenants (id, name, region, tier, status, stage, config, "
                "created_at) VALUES (:id, 'Reviewed Probe', 'ap-southeast-2', 'shared', "
                "'active', 'full', '{\"jurisdictions\": [\"AU\"]}'::jsonb, now()) "
                "ON CONFLICT (id) DO UPDATE SET stage = 'full'"
            ),
            {"id": ACTING_FIRM},
        )
        owner.commit()
        with tenancy.acting_as(ACTING_FIRM), tenancy.acting_as_user(ACTOR):
            crypto.ensure_key(owner, ACTING_FIRM)
            evidence.ensure_anchor(owner, ACTING_FIRM)
            owner.commit()
    finally:
        owner.close()
    return ACTING_FIRM


@pytest.fixture(scope="module")
def engaged() -> str:
    return _specialist(ENGAGED_EMAIL, ENGAGED_QUALIFICATION)


@pytest.fixture(scope="module")
def unengaged() -> str:
    return _specialist(UNENGAGED_EMAIL, UNENGAGED_QUALIFICATION)


@pytest.fixture(scope="module")
def reviewed_pack(engaged) -> PackRow:
    """One pack, cut and signed and published once for the whole module.

    Module-scoped on purpose. `packs` is append-only, so a test that publishes
    leaves a row that cannot be removed, and a per-test publish would grow the
    demo database by several pack versions on every suite run. Two published
    packs is what this file actually needs to make its point.
    """
    draft_id = _cut_draft("A pack a firm may act on", days=FAR_FUTURE)
    _sign(draft_id, ENGAGED_EMAIL)
    return _pack_row(int(_publish(draft_id)["pack_id"]))


@pytest.fixture(scope="module")
def unreviewed_pack(unengaged) -> PackRow:
    """Its twin, signed by somebody whose engagement is still a placeholder.

    Effective ten days after the reviewed one, so it is the *newest* pack on
    that date — which is what makes the gate's preference for the older,
    reviewed version a real assertion rather than an accident of ordering.
    """
    draft_id = _cut_draft("Signed by somebody not yet engaged", days=FAR_FUTURE + 10)
    _sign(draft_id, UNENGAGED_EMAIL)
    return _pack_row(int(_publish(draft_id)["pack_id"]))


def test_the_signing_workflow_produces_content_a_firm_may_act_on(
    reviewed_pack,
) -> None:
    """The finding, as a test: walk §14 and look at what comes out.

    Cut, sign as a competent and engaged specialist, publish as somebody else.
    The pack that results must be one `packs_repo` will serve to a firm that
    acts on its determinations. Before the fix it was `PENDING_REVIEW` and the
    refusal gate turned it away.
    """
    row = reviewed_pack
    assert row.content_status == REVIEWED, (
        f"the pack landed as {row.content_status}. A named specialist signed it "
        "and a second person published it — the §14 workflow ran in full — and "
        "the only route left to REVIEWED content would be hand-editing a file "
        "and reseeding as the owner, which is what §14 forbids."
    )
    pack = Pack.from_body(row.body)
    assert pack.is_production_grade, (
        f"content_status={pack.content_status!r} signed_by={pack.signed_by!r}"
    )
    assert pack.signed_by and not pack.signed_by.startswith("[")

    # Published far enough out that nothing in force moved. A test that changed
    # the pack every other test evaluates against would be a worse problem than
    # the one it was written to catch.
    assert row.effective_from > date.today() + timedelta(days=FAR_FUTURE - 1)
    in_force = packs_repo.describe(SessionLocal(), "AU", date.today())
    assert in_force.version != row.version, "publishing changed the pack in force"


def test_an_unpublished_signature_does_not_make_content_reviewed(
    unreviewed_pack,
) -> None:
    """A signature from somebody whose engagement is a placeholder is not review.

    This is the case the repository is actually in, and the reason the demo's
    packs must stay `PENDING_REVIEW`. Stamping REVIEWED on the strength of the
    role alone would let anybody holding `pack_signatory` mint production-grade
    rule content with nobody qualified behind it — the exact routing-around
    migration 0025's CHECK constraint refuses at the database.
    """
    row = unreviewed_pack
    assert row.content_status == PENDING_REVIEW, (
        "a placeholder qualification produced REVIEWED content. The signature "
        "block prints this field; a bracketed placeholder in it means nobody "
        "has been engaged."
    )
    assert not Pack.from_body(row.body).is_production_grade


def test_the_gate_serves_the_reviewed_pack_and_skips_the_unreviewed_one(
    reviewed_pack, unreviewed_pack
) -> None:
    """The other half: `packs_repo` has to act on what the flag says.

    Two versions are published far enough out to disturb nothing, the later one
    signed by somebody whose engagement is still a placeholder. A firm at `full`
    with no permit asks for the pack in force on the later date. The honest
    answer is the *earlier*, reviewed version: the newer one is real content
    awaiting a real specialist, and a firm that acts on its determinations may
    not decide on it.

    Written this way round rather than as a bare `raises`, because
    `test_unsigned_pack_refusal.py` already proves the refusal. What is new here
    is that the gate now has something to admit — before the fix there was no
    reachable REVIEWED pack for it to prefer.
    """
    reviewed, unreviewed = reviewed_pack, unreviewed_pack
    reviewed_on = reviewed.effective_from
    unreviewed_on = unreviewed.effective_from
    assert reviewed.content_status == REVIEWED
    assert unreviewed.content_status == PENDING_REVIEW

    with tenancy.acting_as(_acting_firm()), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            tenant = session.get(Tenant, _acting_firm())
            assert adoption.stage_of(tenant) in packs_repo.ACTING_STAGES
            served = packs_repo.active(session, "AU", unreviewed_on)
        finally:
            session.close()

    assert served.version != unreviewed.version, (
        f"a firm that acts on its determinations was served v{unreviewed.version}, "
        "which is PENDING_REVIEW and the newest pack on that date. The gate is "
        "meant to skip it and fall back to signed content."
    )
    assert served.content_status == REVIEWED and served.is_production_grade, (
        f"the gate served v{served.version} ({served.content_status}). Reviewed "
        f"content exists on that date — v{reviewed.version} — and is what a firm "
        "at `full` must be given."
    )
    assert reviewed_on < unreviewed_on


def test_a_draft_inherits_no_review_status_from_the_pack_it_was_cut_from(
    monkeypatch,
) -> None:
    """A draft cut from REVIEWED content is PENDING_REVIEW until somebody signs it.

    `drafts.create` deep-copies the base body. Once the workflow can produce a
    REVIEWED pack — which is the whole of the fix above — a draft cut from one
    would inherit the claim, and an unsigned draft would sit there describing
    itself as reviewed content. Two mistakes cancelling out is not a property to
    rely on.

    The base is substituted rather than published, because a REVIEWED pack
    genuinely *in force* would change what every other test evaluates against.
    What is under test is one line of `create`, and this is the smallest way to
    put a reviewed body in front of it.
    """
    from app import packs_repo as repo
    from app.watch import drafts

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            real = repo.active_rows(session, date.today())["AU"]
            reviewed_body = dict(real.body)
            reviewed_body["content_status"] = REVIEWED
            reviewed_body["signed_by"] = "A Real Specialist"

            stand_in = PackRow(
                jurisdiction=real.jurisdiction,
                version=real.version,
                effective_from=real.effective_from,
                effective_to=real.effective_to,
                body=reviewed_body,
                signed_by="A Real Specialist",
                signed_at=real.signed_at,
            )
            monkeypatch.setattr(
                drafts.packs_repo,
                "active_rows",
                lambda _session, _on: {"AU": stand_in},
            )

            draft = drafts.create(
                session,
                jurisdiction="AU",
                on=date.today(),
                effective_from=date.today() + timedelta(days=FAR_FUTURE),
                title="Cut from reviewed content",
                rationale="Written by a test.",
                author="The Signing Suite",
            )
            assert draft.body.get("content_status") == PENDING_REVIEW, (
                f"a fresh draft claims {draft.body.get('content_status')!r} because it "
                "was cut from reviewed content. A draft is unsigned by definition."
            )
            assert draft.body["signed_by"] == ""
        finally:
            session.rollback()
            session.close()


# --------------------------------------------------------------------------
# Three places decide what a real signature is. They must agree.
# --------------------------------------------------------------------------

#: Values that are not a real name or a real engagement reference. Both
#: conventions this repository actually uses, plus the two that get typed when
#: somebody is in a hurry.
PLACEHOLDERS = (
    "",
    "   ",
    "[DDO consultant — pending engagement]",
    "[illustrative — no engagement in place]",
    "ILLUSTRATIVE - NOT PROFESSIONALLY REVIEWED",
    "pending engagement",
    "TBC",
)

#: Values that are a real name or a real reference.
REAL = (
    "Aoife Brennan",
    "AFSL 000000 / Legal Practising Certificate NSW 000000",
    "Dr M. Oyelaran, SFC CE No. AAA000",
)


@pytest.mark.parametrize("value", PLACEHOLDERS)
def test_the_placeholder_rule_recognises_every_convention_in_use(value) -> None:
    from app import attestation

    assert attestation.is_placeholder(value), f"{value!r} was accepted as real"


@pytest.mark.parametrize("value", REAL)
def test_the_placeholder_rule_does_not_reject_a_real_reference(value) -> None:
    from app import attestation

    assert not attestation.is_placeholder(value), f"{value!r} was read as a placeholder"


def test_the_watch_vocabulary_is_the_engine_vocabulary() -> None:
    """`app/watch` cannot import the engine, so the strings are stated twice.

    Invariant 6 forbids the import and is right to. What it cannot do is stop
    the two copies drifting, so this is what does — a rename in `engine/pack.py`
    that is not mirrored fails here rather than producing packs the loader
    silently declines to serve.
    """
    from app import attestation
    from app.engine import pack as engine_pack

    assert attestation.REVIEWED == engine_pack.REVIEWED
    assert attestation.PENDING_REVIEW == engine_pack.PENDING_REVIEW
    assert attestation.ILLUSTRATIVE == engine_pack.ILLUSTRATIVE


@pytest.mark.parametrize("signatory", REAL)
def test_a_signature_attestation_admits_is_one_the_engine_calls_production_grade(
    signatory,
) -> None:
    """The second lock has to agree with the first.

    `publish` stamps REVIEWED using `attestation`; `packs_repo` then asks the
    engine's `is_production_grade` whether to serve it. If the two disagreed,
    publication would produce content the loader refuses — a pack that is
    reviewed according to the thing that wrote it and not according to the thing
    that reads it.
    """
    from app import attestation
    from app.engine.pack import Pack as EnginePack

    assert attestation.signature_is_qualified(signatory, "AFSL 000000")
    pack = EnginePack(
        pack_id="AU",
        version=1,
        effective_from=date.today(),
        effective_to=None,
        signed_by=signatory,
        signed_at="",
        thresholds={},
        asset_classes={},
        rules=[],
        reason_codes={},
        artefact_templates={},
        artefact_titles={},
        artefact_scopes={},
        content_status=attestation.status_for(signatory, "AFSL 000000"),
    )
    assert pack.is_production_grade


def test_the_database_still_refuses_what_attestation_would_refuse() -> None:
    """And the third lock: migration 0025's CHECK, asked directly.

    Attempted as a real INSERT rather than by re-stating the constraint's SQL
    here, which would be a fourth copy of the rule to drift. Rolled back — the
    row must never exist, and `packs` is append-only so it could not be removed
    if it did.
    """
    from sqlalchemy.exc import IntegrityError

    from app import attestation

    signatory = "[DDO consultant — pending engagement]"
    assert not attestation.signature_is_qualified(signatory, "AFSL 000000")

    owner = OwnerSessionLocal()
    try:
        owner.add(
            PackRow(
                jurisdiction="AU",
                version=999_999,
                effective_from=date.today() + timedelta(days=FAR_FUTURE * 2),
                effective_to=None,
                body={"content_status": REVIEWED, "signed_by": signatory},
                signed_by=signatory,
                signed_at="",
            )
        )
        with pytest.raises(IntegrityError):
            owner.flush()
    finally:
        owner.rollback()
        owner.close()
