"""FP3-17: a pinned firm was told about a version on the day it already applied.

`advance.notice` was reachable only from `advance.sweep`, and `sweep` selects
`Pack.effective_from <= today`. So §S5's "UAT space before advancing" described
a review window that opened *after* the thing it is a window for had happened —
the notice arrived on the day the version was already governing everybody on
auto.

Two halves, and the second is the one an auditor reads.

**Notice on publication**, so the window precedes the change.

**What an expired window does.** It stays `PENDING`. The system does not
auto-advance a pinned tenant — that is pinning in name only — and does not
refuse determinations, because halting a customer's business on our own
authority is a contractual position nobody has taken. Instead:

  * one `pack.review_overdue` webhook per day, per tenant, per overdue pack;
  * one chained audit event per day with the same key;
  * a `pack_review_overdue` field on every determination made in that period.

An auditor asking "how long did this firm operate on superseded rules, and did
they know" gets a per-day chained answer, and every determination made in the
period says so on its face.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import func, select

from app import advance, tenancy
from app.db import SessionLocal
from app.models import (
    AuditEvent,
    Decision,
    TenantAdvance,
    WebhookDelivery,
    WebhookEndpoint,
)

ACTOR = "apc_bulk_sweep"
REGIME = "AU"


@pytest.fixture
def an_overdue_window():
    """A pinned advance whose review window closed a fortnight ago.

    Manufactured rather than waited for, inside a transaction that is rolled
    back — Tier 2's rule about negative tests that vanish when the dangerous
    state is absent, applied to the state this whole finding is about.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        transaction = session.begin()
        try:
            if session.scalars(select(WebhookEndpoint)).first() is None:
                session.add(
                    WebhookEndpoint(
                        id="whe_overdue_probe",
                        url="https://example.invalid/hook",
                        secret="not a real secret",
                        events=["pack.review_overdue"],
                        status="active",
                    )
                )
                session.flush()

            row = TenantAdvance(
                id="adv_overdue_probe",
                jurisdiction=REGIME,
                pack_version=9001,
                policy=advance.PINNED,
                status=advance.PENDING,
                noticed_at=datetime.now(timezone.utc) - timedelta(days=30),
                window_closes_at=datetime.now(timezone.utc) - timedelta(days=14),
            )
            session.add(row)
            session.flush()
            yield session, row
        finally:
            transaction.rollback()
            session.close()


def test_an_expired_window_stays_pending(an_overdue_window):
    """Decided, and the alternatives were rejected rather than overlooked.

    Auto-advancing is what this module's own comment calls pinning in name only.
    Refusing determinations means halting a customer's business on our
    authority, which is a contractual and liability position that cannot be
    taken before a legal opinion exists.
    """
    _session, row = an_overdue_window
    assert row.status == advance.PENDING
    assert advance.days_overdue(row) >= 14


def test_the_firm_is_told_once_per_day_not_once_per_sweep(an_overdue_window):
    """A worker on a ten-minute cycle must not send a hundred and forty-four.

    An alert that arrives every ten minutes is one somebody filters into a
    folder, which is exactly what `source_alerts.page` says about outages.
    """
    session, _row = an_overdue_window

    first = advance.announce_overdue(session, tenant_id=DEMO_TENANT)
    second = advance.announce_overdue(session, tenant_id=DEMO_TENANT)
    third = advance.announce_overdue(session, tenant_id=DEMO_TENANT)

    assert first >= 1, "an overdue review window told nobody"
    assert second == 0, "the same firm was told twice on the same day"
    assert third == 0


def test_the_webhook_carries_what_the_firm_needs_to_act(an_overdue_window):
    session, row = an_overdue_window
    advance.announce_overdue(session, tenant_id=DEMO_TENANT)

    delivery = session.scalars(
        select(WebhookDelivery)
        .where(WebhookDelivery.event == "pack.review_overdue")
        .order_by(WebhookDelivery.id.desc())
    ).first()

    assert delivery is not None, "no pack.review_overdue webhook was enqueued"
    payload = delivery.payload
    assert payload["jurisdiction"] == REGIME
    assert payload["superseding_version"] == row.pack_version
    assert payload["days_overdue"] >= 14


def test_one_chained_audit_event_per_day(an_overdue_window):
    """The artefact that proves the firm was told.

    The webhook is how their systems learn; this is what survives somebody
    later saying they were not told. Chained, like every other audit row.
    """
    session, _row = an_overdue_window
    advance.announce_overdue(session, tenant_id=DEMO_TENANT)

    events = session.scalars(
        select(AuditEvent)
        .where(AuditEvent.action == "pack.review_overdue")
        .order_by(AuditEvent.id.desc())
    ).all()

    assert events, "nothing recorded that the firm was told"
    assert events[0].this_hash, "the notice is outside the audit hash chain"
    assert "review window closed" in events[0].subject

    advance.announce_overdue(session, tenant_id=DEMO_TENANT)
    again = session.scalar(
        select(func.count())
        .select_from(AuditEvent)
        .where(AuditEvent.action == "pack.review_overdue")
    )
    assert again == len(events), "a second run wrote a second audit event"


def test_a_determination_made_while_overdue_says_so_on_its_face(an_overdue_window):
    """The point of the whole finding.

    An auditor asking "how long did this firm operate on superseded rules"
    should not have to join a policy table against a publication date. Every
    determination made in the period carries the answer.
    """
    session, row = an_overdue_window

    carried = advance.overdue_for_snapshot(session, jurisdiction=REGIME)
    assert carried is not None, (
        "a determination made while the review window is overdue carries nothing"
    )
    assert carried["superseding_version"] == row.pack_version
    assert carried["days_overdue"] >= 14
    assert carried["pack_id"] == REGIME


def test_a_determination_in_a_regime_that_is_current_carries_nothing():
    """Absent rather than null on an ordinary determination.

    The snapshot of the overwhelming majority is unchanged in shape as well as
    in value, which is what makes this additive.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            assert (
                advance.overdue_for_snapshot(session, jurisdiction="ZZ") is None
            )


def test_no_seeded_decision_carries_the_new_field():
    """Additive by construction, asserted rather than argued.

    Every determination already on file was recorded before this field existed,
    `evaluate_snapshot` reads only the paths a pack names, and the DSL's `_walk`
    cannot see a field nothing asks for — so replay of every stored decision is
    untouched and no stored hash moves.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with SessionLocal() as session:
            rows = session.scalars(
                select(Decision).order_by(Decision.id).limit(200)
            ).all()

    assert rows, "no seeded decisions — run `make seed` first"
    carrying = [r.id for r in rows if "pack_review_overdue" in (r.snapshot or {})]
    assert not carrying, (
        f"determinations already on file grew a new snapshot field: {carrying[:5]}"
    )
