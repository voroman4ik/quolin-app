"""Signing yourself out everywhere is not the same act as signing the firm out.

`POST /auth/revoke-all` destroyed every session in the tenant and was open to
every role, including `viewer`. The reasoning written on it was sound as far as
it went: somebody whose credential has just leaked needs their sessions gone
immediately, not after they have found an administrator.

But that reasoning covers *their* sessions. Signing out every employee in the
firm to deal with one person's leaked password is a denial of service, and the
route already refused it to a machine principal for exactly that reason — "a
leaked integration secret turns into a denial of service against the customer".
The same argument applies to a viewer with a borrowed cookie, and to an
accidental double-click.

So the default scope is the caller's own sessions, which is what the
break-glass case actually needs, and the firm-wide sweep is an administrative
act. The endpoint stays; nobody loses the control they had a reason to use.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import identity, tenancy
from app.db import OwnerSessionLocal
from app.main import app
from app.models import AuthSession
from tests.conftest import (
    ADMIN_EMAIL,
    DEMO_TENANT,
    OPERATOR_EMAIL,
    VIEWER_EMAIL,
    sign_in,
)

ACTOR = "apc_bulk_sweep"


def _sessions_for(email: str) -> int:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            user = identity.find_by_email(owner, email)
            assert user is not None
            return len(
                list(
                    owner.scalars(
                        select(AuthSession).where(AuthSession.user_id == user.id)
                    )
                )
            )
    finally:
        owner.close()


@pytest.fixture
def two_people():
    """Two signed-in people in the same firm, so scope is observable at all."""
    with TestClient(app) as viewer, TestClient(app) as operator:
        sign_in(viewer, VIEWER_EMAIL)
        sign_in(operator, OPERATOR_EMAIL)
        assert _sessions_for(VIEWER_EMAIL) > 0
        assert _sessions_for(OPERATOR_EMAIL) > 0
        yield viewer, operator


def test_the_default_scope_is_the_caller_alone(two_people) -> None:
    """The finding. A viewer signing themselves out must not sign out the firm."""
    viewer, _operator = two_people
    others_before = _sessions_for(OPERATOR_EMAIL)

    res = viewer.post("/auth/revoke-all")
    assert res.status_code == 200, res.text
    assert res.json()["scope"] == "me", res.json()

    assert _sessions_for(VIEWER_EMAIL) == 0, "the caller's own sessions survived"
    assert _sessions_for(OPERATOR_EMAIL) == others_before, (
        "a viewer signed a colleague out. `revoke-all` is break-glass for the "
        "person whose credential leaked, not a firm-wide switch every role holds."
    )


def test_a_viewer_cannot_sweep_the_firm(two_people) -> None:
    """And asking for the wider scope is refused, rather than quietly narrowed.

    Silently doing the smaller thing would be worse than refusing: an
    administrator dealing with a real incident would believe they had signed
    everybody out.
    """
    viewer, _operator = two_people
    others_before = _sessions_for(OPERATOR_EMAIL)

    res = viewer.post("/auth/revoke-all", json={"scope": "tenant"})

    assert res.status_code == 403, res.text
    assert _sessions_for(OPERATOR_EMAIL) == others_before
    assert _sessions_for(VIEWER_EMAIL) > 0, (
        "a refused firm-wide sweep still revoked the caller's own sessions"
    )


def test_an_administrator_can_still_sweep_the_firm() -> None:
    """The control the endpoint exists for is unchanged for the person who has it."""
    with TestClient(app) as viewer, TestClient(app) as admin:
        sign_in(viewer, VIEWER_EMAIL)
        sign_in(admin, ADMIN_EMAIL)
        assert _sessions_for(VIEWER_EMAIL) > 0

        res = admin.post("/auth/revoke-all", json={"scope": "tenant"})

    assert res.status_code == 200, res.text
    assert res.json()["scope"] == "tenant"
    assert res.json()["revoked"] >= 2
    assert _sessions_for(VIEWER_EMAIL) == 0, "the firm-wide sweep missed somebody"
    assert _sessions_for(ADMIN_EMAIL) == 0, "the sweep spared the person who ran it"


def test_an_unknown_scope_is_refused() -> None:
    """Not treated as the default. A typo must not quietly do the smaller thing."""
    with TestClient(app) as admin:
        sign_in(admin, ADMIN_EMAIL)
        res = admin.post("/auth/revoke-all", json={"scope": "everyone"})
    assert res.status_code == 422, res.text


def test_a_machine_is_still_refused_either_way() -> None:
    """The refusal that was already there, kept.

    An integration signing a firm's people out turns a leaked secret into a
    denial of service. It has no more business revoking its own operator's
    sessions than the firm's, so both scopes are refused.
    """
    from app.rbac import ROUTE_ROLES

    assert ("POST", "/auth/revoke-all") in ROUTE_ROLES
