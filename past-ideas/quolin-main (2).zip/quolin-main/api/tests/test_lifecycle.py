"""The pack lifecycle, and the tenant advance policy that hangs off it.

Two of S5's three gate items are here. The third — the AU specialist authoring
and signing a real pack in the workbench — is a wall-clock convergence point and
is owed.

* **Unsigned content provably cannot go effective.** The existing `NotSigned`
  check refuses publication; this file adds the transition table, which refuses
  the move even if somebody reached past the handler. Two independent statements
  of the same rule, which is the pattern the append-only tables already use.
* **A pinned tenant sees the UAT flow; an auto tenant advances on the effective
  date.**

The most valuable test here is
`test_a_pinned_tenant_is_not_moved_by_a_version_becoming_effective`. Pinning is
the answer to "how do you control vendor changes?", and a pinned tenant whose
determinations quietly started using a version they had not agreed to would be
pinning in name only — the failure would look exactly like working software.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

import pytest
from conftest import DEMO_TENANT, the_bytes_on_the_row
from sqlalchemy import select

from app import advance, tenancy
from app.models import PackDraft, PackDraftTransition, Tenant, TenantAdvance
from app.watch import drafts, lifecycle

ACTOR = "usr_lifecycle_test"

#: Who signs, and it is deliberately not who writes.
#:
#: These two used to be one constant, and that is the Gate A audit's first
#: finding sitting in a fixture: the file signed content it had just authored
#: and every test below passed. `pack_drafts` now records an author and
#: `drafts.sign` refuses a signature from them, so the ordinary path through
#: this file is two people — which is what §3.2 has always said it was.
#: `test_a_signature_is_not_the_authors_own.py` is where the pairing itself is
#: tested; here it is simply how a draft gets signed.
SIGNATORY = "usr_lifecycle_signatory"


@pytest.fixture(autouse=True)
def clean_up(session):
    yield
    with tenancy.acting_as(DEMO_TENANT):
        session.rollback()
        session.query(TenantAdvance).delete(synchronize_session=False)
        tenant = session.get(Tenant, DEMO_TENANT)
        if tenant is not None:
            config = dict(tenant.config or {})
            config.pop("advance_policy", None)
            config.pop("uat_window_days", None)
            tenant.config = config
        session.commit()


def _set_policy(session, policy: str, window: int = 14) -> None:
    with tenancy.acting_as(DEMO_TENANT):
        tenant = session.get(Tenant, DEMO_TENANT)
        tenant.config = {
            **(tenant.config or {}),
            "advance_policy": policy,
            "uat_window_days": window,
        }
        session.commit()


# ------------------------------------------------------------ the state table --


def test_the_transition_table_has_no_way_back_from_a_signature():
    """Once a named person has attested to content, the way to undo it is a
    superseding version.

    An edit would leave their signature attached to bytes they never saw, which
    is worse than no signature — it is a false one.
    """
    assert lifecycle.DRAFT not in lifecycle.TRANSITIONS[lifecycle.SIGNED]
    assert lifecycle.REJECTED not in lifecycle.TRANSITIONS[lifecycle.SIGNED]
    assert lifecycle.TRANSITIONS[lifecycle.SIGNED] == (lifecycle.PUBLISHED,)


def test_rejected_and_superseded_are_terminal():
    """Both are kept rather than deleted. A rejected draft is the record that
    somebody looked and said no; a superseded one is what decisions were made
    under before the change."""
    assert lifecycle.TRANSITIONS[lifecycle.REJECTED] == ()
    assert lifecycle.TRANSITIONS[lifecycle.SUPERSEDED] == ()


def test_effective_is_reachable_only_through_published():
    """Which is what makes "unsigned content cannot go effective" structural
    rather than a check somebody remembered to write.

    Nothing reaches EFFECTIVE except PUBLISHED, nothing reaches PUBLISHED except
    SIGNED, and the only way into SIGNED is IN_REVIEW.
    """
    reaches_effective = [
        state for state, allowed in lifecycle.TRANSITIONS.items()
        if lifecycle.EFFECTIVE in allowed
    ]
    assert reaches_effective == [lifecycle.PUBLISHED]

    reaches_published = [
        state for state, allowed in lifecycle.TRANSITIONS.items()
        if lifecycle.PUBLISHED in allowed
    ]
    assert reaches_published == [lifecycle.SIGNED]


def test_every_state_appears_in_the_table():
    """A state with no entry would be one nothing can leave, silently."""
    assert set(lifecycle.TRANSITIONS) == set(lifecycle.STATUSES)


def test_an_illegal_move_says_what_was_possible_instead(session):
    """The caller is usually a screen, and the useful answer is what the buttons
    should have been."""
    with tenancy.acting_as(DEMO_TENANT):
        draft = _a_draft(session)
        with pytest.raises(lifecycle.IllegalTransition) as raised:
            lifecycle.move(session, draft, lifecycle.EFFECTIVE)
        session.rollback()

    message = str(raised.value)
    assert "cannot become 'effective'" in message
    assert "in_review" in message, "the message does not say what was possible"


def _a_draft(
    session,
    *,
    effective_in_days: int = 30,
    version: int = 99,
    author: str = "An Author",
) -> PackDraft:
    """A draft, authored by whoever is in scope — or by nobody in particular.

    `create` refuses to record a draft with no author at all, so a caller that
    has entered no user context names the watch service: a draft nothing human
    wrote, which is exactly the state that makes any later human signature an
    independent one. Where a test *is* acting as somebody, that person is the
    author and the tests below turn on what they may then do with it.
    """
    from app.watch import drafts

    acting = tenancy.current_user_or_none()
    return drafts.create(
        session,
        jurisdiction="AU",
        on=date.today(),
        effective_from=date.today() + timedelta(days=effective_in_days),
        title="Lifecycle test draft",
        rationale="Written by the lifecycle suite.",
        author=author if acting else drafts.WATCH_SERVICE_NAME,
        author_user_id=None if acting else drafts.WATCH_SERVICE,
    )


# ----------------------------------------------------------------- the log --


def test_a_draft_records_its_own_creation(session):
    """The first row, with a null `from_status`. "From nothing" is genuinely a
    different fact from "from draft"."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        rows = lifecycle.history(session, draft.id)

    assert len(rows) == 1
    assert rows[0]["from"] is None
    assert rows[0]["to"] == lifecycle.DRAFT


def test_every_move_is_recorded_with_who_made_it(session):
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        lifecycle.move(session, draft, lifecycle.IN_REVIEW, note="ready")
        session.commit()
        rows = lifecycle.history(session, draft.id)

    assert [r["to"] for r in rows] == [lifecycle.DRAFT, lifecycle.IN_REVIEW]
    assert rows[-1]["from"] == lifecycle.DRAFT
    assert rows[-1]["by"] == ACTOR
    assert rows[-1]["note"] == "ready"


def test_the_history_reads_oldest_first(session):
    """It is read as a narrative. A reader wants to start where the content did."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        lifecycle.move(session, draft, lifecycle.IN_REVIEW)
        session.commit()
        rows = lifecycle.history(session, draft.id)
    assert [r["at"] for r in rows] == sorted(r["at"] for r in rows)


def test_the_log_cannot_be_edited(session):
    """Append-only at the database, trigger and revoked grant both. A transition
    log that could be edited would be a story rather than a record."""
    from sqlalchemy.exc import ProgrammingError

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        row = session.scalars(
            select(PackDraftTransition).where(PackDraftTransition.draft_id == draft.id)
        ).first()

        with pytest.raises(ProgrammingError):
            row.note = "a different story"
            session.flush()
        session.rollback()


# --------------------------------------------------- signing and the content hash --


def test_signing_captures_what_was_signed(session):
    """"They signed version 4" is a weaker claim than "they signed these exact
    bytes" the moment somebody asks what changed between the signature and what
    went live."""
    from app.watch import drafts

    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(ACTOR):
            draft = _a_draft(session)
        with tenancy.acting_as_user(SIGNATORY):
            drafts.sign(
                session,
                draft.id,
                signatory="A Signatory",
                signed_content_hash=the_bytes_on_the_row(session, draft),
                note="Reviewed.",
            )
        session.commit()

        assert draft.content_hash == lifecycle.content_hash(draft.body)
        assert len(draft.content_hash) == 64


def test_the_content_hash_does_not_depend_on_key_order(session):
    """A hash that changed when a dictionary was rebuilt would make "is this
    what was signed" unanswerable for the wrong reason."""
    first = lifecycle.content_hash({"a": 1, "b": {"x": 1, "y": 2}})
    second = lifecycle.content_hash({"b": {"y": 2, "x": 1}, "a": 1})
    assert first == second


def test_signing_records_the_review_step_even_when_there_was_not_one(session):
    """A draft handed straight to a signatory does not have to be submitted
    first — but the log says a review step happened, rather than showing a draft
    that leapt from written to signed.

    Two people, and it used to be one. This test read *"a signatory authoring
    their own content does not have to hand it to themselves first"* and did
    exactly that: created a draft as `ACTOR` and signed it as `ACTOR`. It was
    the repository's own assertion that the separation §3.2 requires did not
    apply, sitting in the file named after the lifecycle, and it passed for
    thirteen stages. What the transition log records is unchanged; who is
    allowed to produce it is not.
    """
    from app.watch import drafts

    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(ACTOR):
            draft = _a_draft(session)
        with tenancy.acting_as_user(SIGNATORY):
            drafts.sign(
                session,
                draft.id,
                signatory="A Signatory",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
        session.commit()
        moves = [r["to"] for r in lifecycle.history(session, draft.id)]

    assert moves == [lifecycle.DRAFT, lifecycle.IN_REVIEW, lifecycle.SIGNED]


def test_the_author_cannot_sign_their_own_draft(session):
    """The forbidden path, asserted as forbidden.

    This is the inversion of what the test above used to claim. A signatory who
    writes a rule change and signs it is the only person who has read it, and
    the two signatures that follow — publication, and its second approval — are
    people agreeing with an attestation they cannot check.
    """
    from app.watch import drafts

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.flush()
        with pytest.raises(drafts.SelfAuthoredSignature):
            drafts.sign(
                session,
                draft.id,
                signatory="Their Own Author",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
        session.rollback()


# ------------------------------------------------- unsigned cannot go effective --


def test_unsigned_content_cannot_be_moved_to_effective(session):
    """S5's second gate item, at the layer beneath the handler.

    `NotSigned` refuses publication at the endpoint. This refuses the *move*, so
    that a caller reaching past the handler — a script, a future endpoint, a
    migration somebody wrote in a hurry — gets the same answer. Two independent
    statements of one rule, which is the pattern the append-only tables use.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        for target in (lifecycle.PUBLISHED, lifecycle.EFFECTIVE):
            with pytest.raises(lifecycle.IllegalTransition):
                lifecycle.move(session, draft, target)
        session.rollback()


def test_a_rejected_draft_can_never_become_content(session):
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        lifecycle.move(session, draft, lifecycle.REJECTED, note="Not this quarter.")
        session.commit()

        for target in lifecycle.STATUSES:
            if target == lifecycle.REJECTED:
                continue
            with pytest.raises(lifecycle.IllegalTransition):
                lifecycle.move(session, draft, target)
        session.rollback()


# ------------------------------------------------------------------ settling --


def test_a_published_draft_becomes_effective_when_its_date_arrives(session):
    """Recorded rather than computed. A state that changed silently at midnight
    with no row to show for it would be a hole in the middle of the log."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session, effective_in_days=3)
        lifecycle.move(session, draft, lifecycle.IN_REVIEW)
        lifecycle.move(session, draft, lifecycle.SIGNED)
        lifecycle.move(session, draft, lifecycle.PUBLISHED)
        session.commit()

        # Before the date: nothing moves.
        assert lifecycle.settle(session, today=date.today())["effective"] == 0
        assert draft.status == lifecycle.PUBLISHED

        # After it: one move, and the log says why.
        tally = lifecycle.settle(session, today=date.today() + timedelta(days=4))
        session.commit()

    assert tally["effective"] == 1
    assert draft.status == lifecycle.EFFECTIVE
    assert "effective from" in lifecycle.history(session, draft.id)[-1]["note"]


def test_settling_twice_does_not_record_the_same_move_twice(session):
    """It works out what should have happened by now rather than what changed
    since it last ran, so a missed sweep catches up rather than double-counting."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session, effective_in_days=1)
        for target in (lifecycle.IN_REVIEW, lifecycle.SIGNED, lifecycle.PUBLISHED):
            lifecycle.move(session, draft, target)
        session.commit()

        later = date.today() + timedelta(days=2)
        first = lifecycle.settle(session, today=later)
        second = lifecycle.settle(session, today=later)
        session.commit()

        moves = [r["to"] for r in lifecycle.history(session, draft.id)]

    assert first["effective"] == 1
    assert second["effective"] == 0
    assert moves.count(lifecycle.EFFECTIVE) == 1


# ------------------------------------------------------- the advance policy --


def test_an_auto_tenant_advances_on_the_effective_date(session):
    """Half of S5's third gate item. The row is not ceremony: "we moved to v4 on
    the fourteenth without review, per our standing policy" is a thing a firm may
    need to evidence."""
    _set_policy(session, advance.AUTO)

    with tenancy.acting_as(DEMO_TENANT):
        row = advance.notice(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=99
        )
        session.commit()

    assert row.status == advance.ADVANCED
    assert row.policy == advance.AUTO
    assert row.advanced_at is not None
    assert row.window_closes_at is None, "an auto tenant has no window"


def test_a_pinned_tenant_gets_a_window_rather_than_the_version(session):
    """The other half. A staged version with a deadline, not an applied one."""
    _set_policy(session, advance.PINNED, window=7)

    with tenancy.acting_as(DEMO_TENANT):
        row = advance.notice(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=99
        )
        session.commit()

        assert row.status == advance.PENDING
        assert row.window_closes_at is not None

        staged = advance.pending(session)
        assert len(staged) == 1
        assert staged[0]["pack_version"] == 99
        assert 6 <= staged[0]["days_left"] <= 7
        assert staged[0]["overdue"] is False


def test_a_pinned_tenant_is_not_moved_by_a_version_becoming_effective(session):
    """The most important test in this file.

    A pinned tenant whose determinations quietly started using a version they
    had not agreed to would be pinning in name only — and the failure would look
    exactly like working software. `effective_version_for` is what the evaluator
    asks, and it must answer with what they took rather than what is newest.
    """
    _set_policy(session, advance.PINNED)

    with tenancy.acting_as(DEMO_TENANT):
        advance.notice(session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=2)
        taken = advance.pending(session)[0]
        advance.advance(session, taken["id"], actor=ACTOR, note="Checked against our book.")

        # A newer version becomes effective. They have not taken it.
        advance.notice(session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=3)
        session.commit()

        on = advance.effective_version_for(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", on=date.today()
        )

    assert on == 2, "a pinned tenant was moved onto a version they never took"


def test_an_auto_tenant_is_not_pinned_to_anything(session):
    """`None` means the shelf decides, which is what auto means."""
    _set_policy(session, advance.AUTO)
    with tenancy.acting_as(DEMO_TENANT):
        advance.notice(session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=2)
        session.commit()
        assert (
            advance.effective_version_for(
                session, tenant_id=DEMO_TENANT, jurisdiction="AU", on=date.today()
            )
            is None
        )


def test_a_tenant_that_has_not_chosen_is_pinned(session):
    """Not choosing is not the same as agreeing to rule content changing under
    you. Auto is a decision somebody makes."""
    with tenancy.acting_as(DEMO_TENANT):
        tenant = session.get(Tenant, DEMO_TENANT)
        tenant.config = {k: v for k, v in (tenant.config or {}).items()
                         if k != "advance_policy"}
        session.commit()
        assert advance.policy_for(tenant)[0] == advance.PINNED


def test_a_typo_in_the_policy_is_treated_as_pinned(session):
    """A mistyped config value must not be the reason a firm's rules changed
    without them looking."""
    with tenancy.acting_as(DEMO_TENANT):
        tenant = session.get(Tenant, DEMO_TENANT)
        tenant.config = {**(tenant.config or {}), "advance_policy": "atuo"}
        session.commit()
        assert advance.policy_for(tenant)[0] == advance.PINNED


def test_noticing_the_same_version_twice_does_not_open_a_second_window(session):
    """A sweep that runs twice must not give a firm two windows on one change."""
    _set_policy(session, advance.PINNED)
    with tenancy.acting_as(DEMO_TENANT):
        first = advance.notice(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=99
        )
        second = advance.notice(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=99
        )
        session.commit()
    assert first.id == second.id
    assert len(advance.pending(session)) == 1


def test_declining_needs_a_reason(session):
    """The reason is the whole value — it is what gets escalated, and a decline
    with no explanation is a dead end for whoever picks it up."""
    _set_policy(session, advance.PINNED)
    with tenancy.acting_as(DEMO_TENANT):
        row = advance.notice(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=99
        )
        session.commit()

        with pytest.raises(advance.AdvanceError):
            advance.decline(session, row.id, actor=ACTOR, note="   ")

        advance.decline(
            session,
            row.id,
            actor=ACTOR,
            note="The 8% cap conflicts with our own mandate; escalating.",
        )
        session.commit()

    assert row.status == advance.DECLINED
    assert "escalating" in row.note


def test_a_version_is_taken_once(session):
    """Taking it again would put a second date on the same change."""
    _set_policy(session, advance.PINNED)
    with tenancy.acting_as(DEMO_TENANT):
        row = advance.notice(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=99
        )
        advance.advance(session, row.id, actor=ACTOR)
        session.commit()

        with pytest.raises(advance.AdvanceError) as raised:
            advance.advance(session, row.id, actor=ACTOR)
        session.rollback()
    assert "already" in str(raised.value)


def test_an_overdue_window_does_not_advance_by_itself(session):
    """The deadline is a prompt. A version that applied itself because nobody
    clicked would be pinning in name only."""
    _set_policy(session, advance.PINNED, window=1)
    with tenancy.acting_as(DEMO_TENANT):
        row = advance.notice(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=99
        )
        row.window_closes_at = datetime.now(timezone.utc) - timedelta(days=3)
        session.commit()

        staged = advance.pending(session)
        assert staged[0]["overdue"] is True
        assert row.status == advance.PENDING, "an overdue window advanced itself"


def test_the_policy_in_force_at_the_time_is_recorded_on_the_row(session):
    """A firm that switched from pinned to auto last month did not thereby change
    what happened in March."""
    _set_policy(session, advance.PINNED)
    with tenancy.acting_as(DEMO_TENANT):
        row = advance.notice(
            session, tenant_id=DEMO_TENANT, jurisdiction="AU", pack_version=99
        )
        session.commit()
    assert row.policy == advance.PINNED

    _set_policy(session, advance.AUTO)
    with tenancy.acting_as(DEMO_TENANT):
        session.expire_all()
        again = session.get(TenantAdvance, row.id)
    assert again.policy == advance.PINNED, "history was rewritten by a settings change"


# ------------------------------------------------------- the workbench path --


def test_an_edit_is_refused_once_anybody_has_signed(client, session):
    """S5's gate item, at the layer the workbench actually uses.

    `NotSigned` refuses publication and the transition table refuses the move.
    This is the third statement of the same rule, at the endpoint a specialist's
    browser calls: a signature attests to specific bytes, and an edit afterwards
    would leave a named person's name on content they never saw — which reads as
    reviewed and is not.
    """
    from app.watch import drafts

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        draft_id = draft.id

    # Editable while it is a draft.
    ok = client.patch(f"/watch/drafts/{draft_id}", json={"notes": "A working note."})
    assert ok.status_code == 200, ok.text

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(SIGNATORY):
        drafts.sign(
            session,
            draft_id,
            signatory="A Signatory",
            signed_content_hash=the_bytes_on_the_row(session, draft_id),
            note="Reviewed.",
        )
        session.commit()

    refused = client.patch(f"/watch/drafts/{draft_id}", json={"notes": "Changed after."})
    assert refused.status_code == 409
    assert "never saw" in refused.json()["detail"]


def test_an_edit_that_would_not_evaluate_is_refused_with_the_faults(client, session):
    """Refused rather than warned about. A draft that cannot evaluate must not be
    one keystroke away from being signed."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        draft_id = draft.id

    broken = client.patch(
        f"/watch/drafts/{draft_id}",
        json={"thresholds": {"max_crypto_concentration_bps": "5.5"}},
    )
    assert broken.status_code == 422
    detail = broken.json()["detail"]
    assert detail["faults"], "refused with no explanation"
    assert any("rather than a number" in f for f in detail["faults"])


def test_validating_an_edit_writes_nothing(client, session):
    """A specialist trying a threshold to see what it would break must not be
    leaving half-edited content behind them."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        draft_id, before = draft.id, dict(draft.body)

    checked = client.post(
        f"/watch/drafts/{draft_id}/validate",
        json={"thresholds": {"max_crypto_concentration_bps": "5.5"}},
    )
    assert checked.status_code == 200
    assert checked.json()["ok"] is False
    assert checked.json()["faults"]

    with tenancy.acting_as(DEMO_TENANT):
        session.expire_all()
        assert dict(session.get(PackDraft, draft_id).body) == before


def test_submitting_moves_a_draft_into_review(client, session):
    """The clock a signatory is waiting on starts here rather than when the
    draft was first written."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        draft_id = draft.id

    assert client.post(f"/watch/drafts/{draft_id}/submit").status_code == 200

    with tenancy.acting_as(DEMO_TENANT):
        session.expire_all()
        assert session.get(PackDraft, draft_id).status == lifecycle.IN_REVIEW
        assert session.get(PackDraft, draft_id).submitted_at is not None
        assert [r["to"] for r in lifecycle.history(session, draft_id)][-1] == (
            lifecycle.IN_REVIEW
        )


def test_the_history_endpoint_carries_what_was_signed(client, session):
    from app.watch import drafts

    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(ACTOR):
            draft = _a_draft(session)
        with tenancy.acting_as_user(SIGNATORY):
            drafts.sign(
                session,
                draft.id,
                signatory="A Signatory",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
        session.commit()
        draft_id = draft.id

    body = client.get(f"/watch/drafts/{draft_id}/history").json()
    assert body["status"] == lifecycle.SIGNED
    assert len(body["content_hash"]) == 64
    assert [t["to"] for t in body["transitions"]] == [
        lifecycle.DRAFT,
        lifecycle.IN_REVIEW,
        lifecycle.SIGNED,
    ]


# --------------------------------------------------- the artefact preview --


def test_a_preview_shows_what_the_drafts_own_templates_would_produce(client, session):
    """Invariant 8 is why this exists.

    Artefact titles and templates are *pack content*. A specialist changing what
    a regulator receives should see it before they sign, not after publication —
    and the preview has to render through the draft's pack rather than the
    shelf's, or it is showing the change nobody is reviewing.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        draft_id = draft.id

    got = client.get(f"/watch/drafts/{draft_id}/preview/tmd")
    assert got.status_code == 200, got.text
    assert got.headers["content-type"].startswith("text/html")
    assert "Target Market Determination" in got.text


def test_a_preview_stores_nothing(client, session):
    """A preview that left a document behind would put an unsigned pack's output
    into the evidence store, where it would be indistinguishable from one
    somebody meant to keep."""
    from app.models import Artefact

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        draft_id = draft.id
        before = session.query(Artefact).count()

    assert client.get(f"/watch/drafts/{draft_id}/preview/tmd").status_code == 200

    with tenancy.acting_as(DEMO_TENANT):
        session.expire_all()
        assert session.query(Artefact).count() == before


def test_a_kind_the_draft_has_no_template_for_says_which_it_has(client, session):
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        draft_id = draft.id

    got = client.get(f"/watch/drafts/{draft_id}/preview/no_such_kind")
    assert got.status_code == 404
    assert "Known kinds" in got.json()["detail"]


def test_a_preview_uses_the_drafts_titles_rather_than_the_shelfs(client, session):
    """The whole point of previewing a *draft*. If it rendered through the pack
    in force, a specialist changing a statutory title would see the old one and
    sign anyway."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        body = dict(draft.body)
        body["artefact_titles"] = {
            **body.get("artefact_titles", {}),
            "tmd": "Renamed By This Draft",
        }
        draft.body = body
        session.commit()
        draft_id = draft.id

    got = client.get(f"/watch/drafts/{draft_id}/preview/tmd")
    assert got.status_code == 200
    assert "Renamed By This Draft" in got.text


def test_a_period_document_previews_too(client, session):
    """A pack defines both document shapes, and the period one is what actually
    gets filed. Previewing only the per-decision half would leave the return —
    the document with a regulator's name on it — unlookable-at."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        draft_id = draft.id

    got = client.get(f"/watch/drafts/{draft_id}/preview/regulatory_return")
    assert got.status_code == 200, got.text
    assert "Periodic Distribution Return" in got.text


def test_a_draft_put_up_for_review_can_still_be_signed(session):
    """The regression the end-to-end walk found.

    `drafts.sign` refused any status but DRAFT, while the lifecycle table has
    always allowed SIGNED from IN_REVIEW — so Stage 5's submit step made a draft
    unsignable: put it up for review and the signatory got "already resolved".
    Both halves had tests and nothing walked the pair, which is the shape of
    every integration bug.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        lifecycle.move(session, draft, lifecycle.IN_REVIEW, note="submitted", actor=ACTOR)
        session.flush()
        assert draft.status == lifecycle.IN_REVIEW

        with tenancy.acting_as_user(SIGNATORY):
            signed = drafts.sign(
                session,
                draft.id,
                signatory="Aoife Brennan",
                signed_content_hash=the_bytes_on_the_row(session, draft),
                note="ok",
            )
        session.flush()

    assert signed.status == lifecycle.SIGNED
    assert signed.content_hash


def test_a_draft_put_up_for_review_can_still_be_rejected(session):
    """A signatory handed something they do not want is the *ordinary* way a
    draft gets rejected, not an edge case."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        draft = _a_draft(session)
        session.commit()
        lifecycle.move(session, draft, lifecycle.IN_REVIEW, note="submitted", actor=ACTOR)
        session.flush()

        rejected = drafts.reject(
            session, draft.id, rejected_by="Aoife Brennan", note="Wrong threshold."
        )
        session.flush()

    assert rejected.status == lifecycle.REJECTED
    assert rejected.rejected_by == "Aoife Brennan"
