"""Randomly generated packs and snapshots, for the property suite and the fuzzer.

Shared because the two need the same thing from opposite directions. The
property suite wants packs that are *valid* — so that when a property fails, the
failure is about the engine rather than about the input. The fuzzer wants packs
that are *plausible but wrong*, and the cheapest way to get those is to take a
valid one and damage it.

**Every generated number is an integer.** Not as an oversight to be fixed later:
the property that no float can enter a determination is one of the things under
test, and a generator that emitted floats would make that test pass for the wrong
reason — by never producing the case that breaks it. Floats are introduced
deliberately, in one place, by `packs_with_floats`.
"""

from __future__ import annotations

from typing import Any

from hypothesis import strategies as st

#: Small on purpose. The properties under test are structural — determinism,
#: order independence — and they fail on three rules as readily as on three
#: hundred, while a shrunk counter-example of three rules is one a person can
#: read. Scale is the benchmarks' job, not this file's.
MAX_RULES = 6

ASSET_CLASSES = ["major", "altcoin", "stablecoin", "leveraged"]
STRUCTURAL_FLAGS = ["algorithmic_peg", "synthetic", "wrapped", "yield_bearing"]
CATEGORIES = ["retail", "wholesale", "sophisticated"]

#: The comparison operators, split by what they need on the right-hand side. A
#: generator that put a list where a number belongs would produce packs that are
#: merely type-confused, which tests Python's error handling rather than ours.
SCALAR_OPS = ["eq", "neq", "lt", "lte", "gt", "gte"]
MEMBERSHIP_OPS = ["in", "not_in"]

#: Snapshot fields a generated rule may read, with the kind of value each holds.
NUMERIC_FIELDS = [
    "client.age_years",
    "client.loss_capacity_band",
    "client.assessable_portfolio_cents",
    "client.prior_crypto_purchases",
    "asset.volatility_band",
    "trade.amount_cents",
]
BOOLEAN_FIELDS = ["client.knowledge_assessed", "client.vulnerability_flag", "asset.leverage"]
CATEGORY_FIELDS = ["client.client_category", "client.residency", "client.domicile"]

CALCS = [
    "existing_crypto_cents",
    "post_trade_crypto_cents",
    "post_trade_crypto_bps",
    "trade_share_bps",
]

# Bounded well inside anything a real portfolio reaches. Hypothesis is looking
# for structural counter-examples, and an amount of 10**18 would only ever find
# that Python integers are unbounded, which is not news.
amounts = st.integers(min_value=0, max_value=5_000_000_000)
small = st.integers(min_value=0, max_value=100)


def _numeric_term() -> st.SearchStrategy[dict[str, Any]]:
    return st.one_of(
        st.builds(lambda f: {"field": f}, st.sampled_from(NUMERIC_FIELDS)),
        st.builds(lambda c: {"calc": c}, st.sampled_from(CALCS)),
        st.builds(lambda n: {"const": n}, amounts),
        st.builds(lambda t: {"threshold": t}, st.sampled_from(["limit_a", "limit_b"])),
    )


def _boolean_term() -> st.SearchStrategy[dict[str, Any]]:
    return st.one_of(
        st.builds(lambda f: {"field": f}, st.sampled_from(BOOLEAN_FIELDS)),
        st.builds(lambda b: {"const": b}, st.booleans()),
    )


def _comparison() -> st.SearchStrategy[dict[str, Any]]:
    numeric = st.builds(
        lambda op, left, right: {"op": op, "left": left, "right": right},
        st.sampled_from(SCALAR_OPS),
        _numeric_term(),
        _numeric_term(),
    )
    boolean = st.builds(
        lambda op, left, right: {"op": op, "left": left, "right": right},
        st.sampled_from(["eq", "neq"]),
        _boolean_term(),
        _boolean_term(),
    )
    membership = st.builds(
        lambda op, field, options: {
            "op": op,
            "left": {"field": field},
            "right": {"const": options},
        },
        st.sampled_from(MEMBERSHIP_OPS),
        st.sampled_from(CATEGORY_FIELDS),
        st.lists(st.sampled_from(CATEGORIES), min_size=1, max_size=3, unique=True),
    )
    return st.one_of(numeric, boolean, membership)


def conditions(depth: int = 2) -> st.SearchStrategy[dict[str, Any]]:
    """A condition, possibly nested. Depth is capped so shrinking terminates."""
    if depth <= 0:
        return _comparison()
    inner = conditions(depth - 1)
    return st.one_of(
        _comparison(),
        st.builds(lambda of: {"op": "and", "of": of}, st.lists(inner, min_size=1, max_size=3)),
        st.builds(lambda of: {"op": "or", "of": of}, st.lists(inner, min_size=1, max_size=3)),
        st.builds(lambda of: {"op": "not", "of": of}, inner),
    )


@st.composite
def rules(draw: st.DrawFn, index: int = 0) -> dict[str, Any]:
    scoped = draw(st.booleans())
    return {
        "rule_id": f"GEN-{index:03d}",
        "title": f"Generated rule {index}",
        **(
            {
                "applies_to": {
                    "asset_class": draw(
                        st.lists(
                            st.sampled_from(ASSET_CLASSES), min_size=1, max_size=4, unique=True
                        )
                    )
                }
            }
            if scoped
            else {}
        ),
        "predicate": draw(conditions()),
        "on_fail": draw(st.sampled_from(["REFER", "BLOCK"])),
        "reason_code": "GENERATED",
        "severity": draw(st.integers(min_value=1, max_value=5)),
    }


@st.composite
def packs(draw: st.DrawFn, dsl_version: int = 2) -> dict[str, Any]:
    """A pack that loads, validates and evaluates.

    Valid on purpose. A property suite generating invalid packs would spend its
    budget rediscovering that the validator works, and every failure would need
    triaging before it said anything about the engine.
    """
    count = draw(st.integers(min_value=1, max_value=MAX_RULES))
    return {
        "pack_id": "GEN",
        "version": 1,
        "dsl_version": dsl_version,
        "effective_from": "2020-01-01",
        "effective_to": None,
        "content_status": "ILLUSTRATIVE",
        "thresholds": {
            "limit_a": draw(amounts),
            "limit_b": draw(amounts),
        },
        "asset_classes": {
            "GEN-ASSET": {
                "class": draw(st.sampled_from(ASSET_CLASSES)),
                "volatility_band": draw(st.integers(min_value=1, max_value=5)),
                "leverage": draw(st.booleans()),
                "structural_flags": draw(
                    st.lists(st.sampled_from(STRUCTURAL_FLAGS), max_size=2, unique=True)
                ),
            }
        },
        "rules": [draw(rules(index=i)) for i in range(count)],
        "reason_codes": {
            "GENERATED": {"title": "Generated", "plain_english": "A generated rule failed."}
        },
    }


@st.composite
def snapshots(draw: st.DrawFn) -> dict[str, Any]:
    """A complete snapshot: every section, every field a generated rule may read.

    Complete on purpose, for the same reason packs are valid. Missing fields are
    the subject of their own tests in `test_dsl.py`, where exactly which field is
    absent is controlled rather than drawn.
    """
    existing = draw(amounts)
    amount = draw(amounts)
    portfolio = draw(amounts)
    return {
        "as_of": "2026-01-01",
        "licensee": {"jurisdiction": "GEN"},
        "client": {
            "id": "gen-client",
            "name": "Generated Client",
            "scenario": "meridian",
            "residency": draw(st.sampled_from(CATEGORIES)),
            "domicile": draw(st.sampled_from(CATEGORIES)),
            "age_years": draw(st.integers(min_value=0, max_value=120)),
            "client_category": draw(st.sampled_from(CATEGORIES)),
            "knowledge_assessed": draw(st.booleans()),
            "knowledge_assessed_days_ago": draw(st.integers(min_value=0, max_value=4000)),
            "loss_capacity_band": draw(st.integers(min_value=1, max_value=5)),
            "vulnerability_flag": draw(st.booleans()),
            "assessable_portfolio_cents": portfolio,
            "prior_crypto_purchases": draw(small),
            "structural_acks": draw(
                st.lists(st.sampled_from(STRUCTURAL_FLAGS), max_size=2, unique=True)
            ),
        },
        "asset": {
            "id": "GEN-ASSET",
            "symbol": "GEN",
            "name": "Generated Asset",
            "class": draw(st.sampled_from(ASSET_CLASSES)),
            "volatility_band": draw(st.integers(min_value=1, max_value=5)),
            "leverage": draw(st.booleans()),
            "structural_flags": draw(
                st.lists(st.sampled_from(STRUCTURAL_FLAGS), max_size=2, unique=True)
            ),
        },
        "jurisdictions": {},
        "trade": {"amount_cents": amount},
        "calc": {
            "existing_crypto_cents": existing,
            "post_trade_crypto_cents": existing + amount,
            "post_trade_crypto_bps": (
                10_000 if portfolio <= 0 and existing + amount > 0
                else 0 if portfolio <= 0
                else ((existing + amount) * 10_000) // portfolio
            ),
            "trade_share_bps": (
                10_000 if portfolio <= 0 and amount > 0
                else 0 if portfolio <= 0
                else (amount * 10_000) // portfolio
            ),
        },
    }


@st.composite
def packs_with_floats(draw: st.DrawFn) -> dict[str, Any]:
    """A pack carrying a decimal number somewhere a rule will read it.

    The adversarial half of the no-float invariant. Every other generator here
    emits integers only, so without this one the property "no float reaches a
    determination" would hold because nothing ever tried.
    """
    body = draw(packs())
    where = draw(st.sampled_from(["threshold", "const"]))
    value = draw(
        st.floats(min_value=-1e6, max_value=1e6, allow_nan=False, allow_infinity=False)
    )
    # The scope is removed so the damaged rule always runs. An earlier version
    # left it, and the property suite duly generated a pack whose float was
    # scoped out of every rule — producing a perfectly ordinary determination
    # and a test failure that was about the generator rather than the engine.
    body["rules"][0].pop("applies_to", None)
    if where == "threshold":
        body["thresholds"]["limit_a"] = value
        body["rules"][0]["predicate"] = {
            "op": "lte",
            "left": {"calc": "post_trade_crypto_bps"},
            "right": {"threshold": "limit_a"},
        }
    else:
        body["rules"][0]["predicate"] = {
            "op": "lte",
            "left": {"calc": "post_trade_crypto_bps"},
            "right": {"const": value},
        }
    return body
