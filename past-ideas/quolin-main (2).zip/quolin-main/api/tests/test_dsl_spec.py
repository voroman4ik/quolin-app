"""`docs/dsl-spec.md` describes the engine that exists.

A specification that has drifted from its implementation is worse than no
specification, because it is believed — by a diligence team reading it, by the
AU specialist signing off that a non-programmer can review a pack, and by
whoever writes the next pack from it. The document is a deliverable of this
stage and it goes to people outside the company, so the cost of it being subtly
wrong is not an internal one.

So every list in it is checked against the code rather than proofread. Add an
operator and this file fails until the table mentions it; register a calc and it
fails until the table has a row; ship a DSL version and it fails until the
version table says what changed.

What is deliberately *not* checked is the prose. Whether §8 explains the
missing-data rule *well* is a judgement, and a test that tried to assert it would
either be vacuous or would freeze the wording against improvement.
"""

from __future__ import annotations

import re
from pathlib import Path

from app.engine import DSL_VERSIONS, calcs
from app.engine.dsl import _BINARY
from app.engine.validate import OUTCOMES, SNAPSHOT_SECTIONS

SPEC = Path(__file__).resolve().parents[2] / "docs" / "dsl-spec.md"


def _text() -> str:
    return SPEC.read_text()


def _prose() -> str:
    """The document as one line, for checks about wording rather than layout.

    Markdown is hard-wrapped, so a phrase the author wrote as one sentence may
    be split across a line break. A test that failed on that would be forbidding
    anybody from reflowing a paragraph, which is not a property worth having.
    """
    return " ".join(_text().split()).lower()


def test_the_spec_exists_and_says_which_version_it_describes():
    assert "dsl **version 2**" in _prose(), "the spec does not say which version it describes"


def test_every_operator_is_documented():
    """A pack author reading this document must find every operator they may use.

    The failure this prevents is the quiet one: an operator that exists in the
    engine, is never documented, and is therefore never reviewed by the person
    signing off that packs are reviewable.
    """
    text = _text()
    undocumented = [op for op in sorted(_BINARY) if f"`{op}`" not in text]
    assert not undocumented, f"operators missing from docs/dsl-spec.md: {undocumented}"


def test_no_operator_is_documented_that_does_not_exist():
    """The other direction, which is worse.

    An author who writes a rule using an operator the document promised and the
    engine does not have gets their pack refused — after they have written it.

    Scoped to the operators table rather than to every table in the document. An
    earlier version matched any row beginning with a backticked word, which swept
    up field names, pack keys and outcomes and reported all of them as invented
    operators — a failing test that was wrong about what it was reading.
    """
    text = _text()
    table = text[text.index("### Comparisons") : text.index("### Combinations")]
    named = {
        op
        for pair in re.findall(r"^\| `(\w+)`(?: / `(\w+)`)? \|", table, re.M)
        for op in pair
        if op
    }
    assert named, "the operators table was not found where this test expected it"
    invented = sorted(named - set(_BINARY))
    assert not invented, f"documented but not implemented: {invented}"


def test_every_registered_calc_has_a_row_with_its_unit_and_description():
    """The calc table is the part a specialist checks a threshold against.

    A calc missing from it is a number nobody outside the code knows the meaning
    or the unit of — and units are how a concentration rule ends up wrong by a
    factor of ten thousand while reading perfectly sensibly.
    """
    text = _text()
    start = text.index("<!-- CALCS TABLE START -->")
    end = text.index("<!-- CALCS TABLE END -->")
    table = text[start:end]

    for name, calc in calcs.registered().items():
        assert f"`{name}`" in table, f"calc {name} is not in the spec's table"
        row = next(line for line in table.splitlines() if f"`{name}`" in line)
        assert f"| {calc.unit} |" in row, f"calc {name}: the spec states the wrong unit"
        # The description is the sentence a non-programmer checks against a
        # regulation, so it has to be the same sentence, not a paraphrase.
        assert calc.description in row, f"calc {name}: the spec's wording has drifted"
        for read in calc.reads:
            assert read in row, f"calc {name}: the spec omits that it reads {read}"


def test_no_calc_is_documented_that_is_not_registered():
    text = _text()
    start = text.index("<!-- CALCS TABLE START -->")
    end = text.index("<!-- CALCS TABLE END -->")
    documented = set(re.findall(r"^\| `(\w+)` \|", text[start:end], re.M))
    assert documented == set(calcs.names())


def test_every_snapshot_section_a_rule_may_read_is_listed():
    text = _text()
    for section in SNAPSHOT_SECTIONS:
        assert section in text, f"snapshot section {section!r} is not documented"


def test_every_dsl_version_is_described():
    """Including the old ones. A reader working out why a 2026 decision replayed
    the way it did needs the semantics that were in force then."""
    text = _text()
    for version in DSL_VERSIONS:
        assert re.search(rf"\|\s+\*\*{version}\*\*\s+\|", text), (
            f"DSL version {version} has no row in the version table"
        )


def test_the_outcomes_a_rule_may_declare_are_stated():
    text = _text()
    for outcome in OUTCOMES:
        assert f"`{outcome}`" in text
    assert "cannot be `allow`" in _prose(), "the spec does not say on_fail may not allow"


def test_the_spec_names_the_files_that_prove_its_claims():
    """The last table in the document, and the one that makes it checkable.

    A specification whose claims point at nothing is a brochure. Each of these
    files must exist, or the document is promising evidence that is not there.
    """
    tests = Path(__file__).resolve().parent
    text = _text()
    for name in (
        "test_dsl.py",
        "test_properties.py",
        "test_corpus.py",
        "test_fuzz.py",
        "test_dsl_spec.py",
    ):
        assert name in text, f"the spec does not point at {name}"
        assert (tests / name).exists(), f"the spec points at {name}, which does not exist"


def test_the_spec_states_the_no_decimals_rule_in_both_units():
    """Cents and basis points, with the conversion, because "no floats" on its
    own does not tell an author what to write instead."""
    prose = _prose()
    assert "cents" in prose and "basis points" in prose
    assert "one per cent is 100 bps" in prose


def test_the_spec_says_what_the_engine_will_not_do():
    """The section a diligence team reads first. Each line is a claim made
    elsewhere in the repo by a guard script or an invariant, and stating them
    here is what turns "trust us" into something checkable."""
    prose = _prose()
    for claim in (
        "does not weight, score or net",
        "does not consult a model",
        "does not read anything but the snapshot",
        "does not check whether the rules are right",
    ):
        assert claim in prose, f"the spec omits: {claim}"


def test_the_spec_documents_every_provenance_field():
    """The specialist authoring a pack works from this document, and provenance
    is the part they fill in per rule. A field that exists and is undocumented is
    one nobody records; a field documented and not implemented is one they record
    into nothing."""
    from app.engine.validate import PROVENANCE_FIELDS

    text = _text()
    for field in PROVENANCE_FIELDS:
        assert f"`{field}`" in text or f'"{field}"' in text, (
            f"provenance field {field!r} is not in docs/dsl-spec.md"
        )
    # And the rule that makes it trustworthy: all four or none.
    assert "complete when present" in _prose()
