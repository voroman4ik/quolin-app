"""The smoke tool's authenticator has to agree with the engine's.

F8 put `operator` into `MFA_REQUIRED_ROLES`, so the account `scripts/smoke.py`
signs in as to walk the three taps now holds an authenticator and a
password-only sign-in is refused 401. That refusal is the control working. What
was missing was any way for the tool to do what a real operator does, so
`smoke.totp_now` exists.

It is a **second implementation of RFC 6238** in this repository, and that is
deliberate: `scripts/smoke.py` is standard-library-only on purpose, because it
runs from a laptop against a stack that has just come up and whose Python
environment is none of its business. It cannot import `app.totp`.

Two implementations that must agree forever is exactly the arrangement that
drifts silently — the failure would be a smoke test refused at sign-in against a
perfectly healthy deployment, at the worst possible moment, on a stack somebody
has just stood up. So they are checked against each other here, at fixed
instants rather than at "now", so the assertion does not depend on which side of
a thirty-second boundary the suite happens to run on.

This file does not start a server. What the CI step it guards actually proves —
that a headerless operator can sign in and walk Check, Replay, Generate — is
proven by running it, and the workflow does that.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from scripts.smoke import sign_in, totp_now  # noqa: E402

from app import totp  # noqa: E402

#: The seeded operator's secret, derived the way `seed.py` derives it. Written
#: out rather than imported so that a change to the derivation shows up here as
#: a failure rather than as two functions agreeing about something new.
DEMO_OPERATOR_SECRET = "JQAWHPYSHSWOMO57RS7U342O42LXIODR"

#: Fixed instants, one per interesting case: the epoch, a round number, a moment
#: mid-step and the moment after the step boundary next to it.
INSTANTS = (0, 59, 60, 1_000_000_000, 1_756_300_000, 1_756_300_123)


@pytest.mark.parametrize("at", INSTANTS)
def test_the_smoke_tool_and_the_engine_agree(at: int) -> None:
    """The property that matters: same secret, same instant, same six digits."""
    assert totp_now(DEMO_OPERATOR_SECRET, at=at) == totp.code_at(
        DEMO_OPERATOR_SECRET, at=at
    ), (
        "scripts/smoke.py and app/totp.py have drifted. The smoke test would be "
        "refused at sign-in against a healthy deployment."
    )


def test_the_seeded_operators_secret_is_still_that_one() -> None:
    """The derivation `seed.py` uses, checked rather than assumed.

    `.github/workflows/ci.yml` passes this value to the smoke step. If the seed's
    derivation or the operator's address changes, that literal goes stale and the
    smoke step starts failing for a reason that has nothing to do with the
    deployment — so the staleness is caught here instead.
    """
    import base64
    import hashlib

    email = "dana.whitfield@quolin.example"
    digest = hashlib.sha256(f"quolin-demo-totp:{email}".encode()).digest()
    derived = base64.b32encode(digest[:20]).decode().rstrip("=")

    assert derived == DEMO_OPERATOR_SECRET, (
        "the seed's TOTP derivation has changed, so the secret in "
        "ci.yml's smoke step is stale"
    )


def test_a_code_is_six_digits() -> None:
    for at in INSTANTS:
        code = totp_now(DEMO_OPERATOR_SECRET, at=at)
        assert len(code) == 6 and code.isdigit(), code


def test_the_code_changes_across_a_step_boundary() -> None:
    """A generator that returned a constant would agree with anything."""
    assert totp_now(DEMO_OPERATOR_SECRET, at=0) != totp_now(
        DEMO_OPERATOR_SECRET, at=30
    )


def test_the_code_is_stable_inside_a_step() -> None:
    assert totp_now(DEMO_OPERATOR_SECRET, at=0) == totp_now(
        DEMO_OPERATOR_SECRET, at=29
    )


def test_a_padded_secret_is_accepted() -> None:
    """Authenticator secrets are copied around with and without `=` padding."""
    padded = DEMO_OPERATOR_SECRET + "===="
    assert totp_now(padded, at=0) == totp_now(DEMO_OPERATOR_SECRET, at=0)


def test_sign_in_asks_for_the_secret_rather_than_reporting_a_bare_401() -> None:
    """The message somebody reads when the smoke step fails.

    A deployment whose operator needs a factor and a tool that was not given one
    is an operator error, not a broken deployment, and the two have completely
    different first moves. Asserted because this is the whole reason the branch
    exists rather than letting the 401 fall through to "returned 401".
    """

    class _RefusingClient:
        def post(self, path, body=None, **kw):
            return 401, {"detail": "..."}, {"x-quolin-mfa": "required"}

    results: list = []
    assert sign_in(_RefusingClient(), "someone@example.invalid", "pw", results) is False

    name, ok, note = results[-1]
    assert ok is False
    assert "QUOLIN_SMOKE_TOTP_SECRET" in note, note
    assert "second factor" in note, note


# --- the spent-step retry -------------------------------------------------
#
# A TOTP code is one-time per time step. In CI the whole pytest suite signs in
# as this same person immediately before the smoke step, and the last of those
# sign-ins leaves the current step spent — so the code the smoke step computes
# for that same thirty-second window is refused. That looks exactly like a
# broken deployment and is not one.


class _SpendsTheFirstStep:
    """Refuses the first coded attempt, accepts the second. Records both."""

    def __init__(self) -> None:
        self.codes: list[str] = []

    def post(self, path, body=None, **kw):
        body = body or {}
        if not body.get("code"):
            return 401, {"detail": "Enter the six-digit code."}, {
                "x-quolin-mfa": "required"
            }
        self.codes.append(body["code"])
        if len(self.codes) == 1:
            return 401, {"detail": "That code has already been used."}, {}
        return 200, {"ok": True}, {}

    def get(self, path, **kw):
        return 200, {"user": {"email": "someone@example.invalid"}}, {}


def test_a_spent_code_is_retried_on_the_next_step(monkeypatch) -> None:
    """The finding CI surfaced, as a test rather than another round trip."""
    import scripts.smoke as smoke

    slept: list[float] = []
    monkeypatch.setattr(smoke.time, "sleep", lambda s: slept.append(s))

    client = _SpendsTheFirstStep()
    results: list = []
    ok = smoke.sign_in(
        client, "someone@example.invalid", "pw", results, DEMO_OPERATOR_SECRET
    )

    assert ok is True, results
    assert len(client.codes) == 2, "the refused code was not retried"
    assert slept and 0 < slept[0] <= 31, (
        f"the retry did not wait for the next step: {slept}"
    )


def test_the_retry_lands_on_a_later_step(monkeypatch) -> None:
    """Waiting is only useful if the second code is actually a different one.

    Asserted through the clock rather than by comparing the two strings: two
    adjacent steps can produce the same six digits about once in a million, and
    a test that failed then would be a test nobody trusts.
    """
    import scripts.smoke as smoke

    clock = {"now": 1_756_300_000.0}
    monkeypatch.setattr(smoke.time, "time", lambda: clock["now"])
    monkeypatch.setattr(
        smoke.time, "sleep", lambda s: clock.__setitem__("now", clock["now"] + s)
    )

    before = int(clock["now"] // 30)
    client = _SpendsTheFirstStep()
    smoke.sign_in(
        client,
        "someone@example.invalid",
        "pw",
        results=[],
        totp_secret=DEMO_OPERATOR_SECRET,
    )
    after = int(clock["now"] // 30)

    assert after > before, "the retry stayed inside the step that was refused"


def test_a_failure_reports_the_servers_own_sentence() -> None:
    """`returned 401` and nothing else cost a CI round trip to diagnose."""
    import scripts.smoke as smoke

    class _AlwaysWrong:
        def post(self, path, body=None, **kw):
            return 401, {"detail": "Those details are not correct."}, {}

    results: list = []
    assert smoke.sign_in(_AlwaysWrong(), "who@example.invalid", "pw", results) is False

    _name, ok, note = results[-1]
    assert ok is False
    assert "Those details are not correct." in note, note
