"""Changing the facts a determination rests on has to leave the old ones behind.

F9. `POST /v1/clients` is an upsert, and an update wrote one audit row:

    v1.client.upsert    client:margaret-wu (updated)

That is the word "updated" and nothing else. An operator can raise
`loss_capacity_band`, clear `vulnerability_flag` or restate
`assessable_portfolio_cents`, re-evaluate, and get the answer they wanted — and
the evidence chain then proves the determination beautifully, against facts
whose previous values are nowhere on file.

The determination is tamper-evident. The edit that enabled it was a one-word
audit row, and "what did this client's loss capacity say yesterday" had no
answer at all.

**The diff goes in the chained event, not beside it.** `audit_events` carries
its own hash chain since migration 0026, and `subject` is inside it. A diff
recorded anywhere else would be a record of the change that could be edited
without breaking anything, which is the position this finding is about.

**Only decision-relevant columns.** A corrected spelling of somebody's name is
not what this is for, and a diff that included everything would bury the three
fields that move outcomes. The set is the facts the engine reads.
"""

from __future__ import annotations

from datetime import date

import pytest
from conftest import reset_rate_limit_for_tests
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import evidence, passwords, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import ApiClient, AuditEvent
from tests.conftest import DEMO_TENANT

ACTOR = "apc_bulk_sweep"
CREDENTIAL = "apc_fact_diff_probe"
SECRET = "an integration secret, not a real one"

SUBJECT = "fact-diff-probe-client"


@pytest.fixture
def credential() -> str:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            row = owner.get(ApiClient, CREDENTIAL)
            if row is None:
                owner.add(
                    ApiClient(
                        id=CREDENTIAL,
                        label="Fact diff probe",
                        secret_hash=passwords.hash_password(SECRET, email=CREDENTIAL),
                        roles=["operator", "viewer"],
                        status="active",
                        created_by="test",
                    )
                )
            else:
                row.secret_hash = passwords.hash_password(SECRET, email=CREDENTIAL)
                row.roles = ["operator", "viewer"]
                row.status = "active"
            owner.commit()
    finally:
        owner.close()
    return CREDENTIAL


@pytest.fixture
def api(credential) -> TestClient:

    reset_rate_limit_for_tests()
    machine = TestClient(app)
    token = machine.post(
        "/v1/oauth/token",
        json={
            "grant_type": "client_credentials",
            "client_id": credential,
            "client_secret": SECRET,
        },
    ).json()["access_token"]
    machine.headers["Authorization"] = f"Bearer {token}"
    return machine


def _body(**overrides) -> dict:
    body = {
        "id": SUBJECT,
        "name": "A Client Whose Facts Move",
        "scenario": "sterling",
        "jurisdiction": "AU",
        "dob": "1990-04-04",
        "client_category": "retail",
        "knowledge_assessed": True,
        "knowledge_date": "2026-02-01",
        "loss_capacity_band": 2,
        "vulnerability_flag": True,
        "assessable_portfolio_cents": 50_000_00,
        "prior_crypto_purchases": 2,
        "structural_acks": [],
        "default_trade_amount_cents": 1_000_00,
    }
    body.update(overrides)
    return body


def _upsert_events() -> list[AuditEvent]:
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            return [
                row
                for row in session.scalars(
                    select(AuditEvent).order_by(AuditEvent.id.desc()).limit(30)
                )
                if row.action == "v1.client.upsert" and SUBJECT in (row.subject or "")
            ]
        finally:
            session.close()


def test_a_rewrite_records_what_the_values_were(api) -> None:
    """The finding, directly: the three fields that most move an outcome."""
    assert api.post("/v1/clients", json=_body()).status_code in (200, 201)

    changed = api.post(
        "/v1/clients",
        json=_body(
            loss_capacity_band=5,
            vulnerability_flag=False,
            assessable_portfolio_cents=250_000_00,
        ),
    )
    assert changed.status_code in (200, 201), changed.text

    latest = _upsert_events()[0]
    subject = latest.subject or ""

    for field, before, after in (
        ("loss_capacity_band", "2", "5"),
        ("vulnerability_flag", "True", "False"),
        ("assessable_portfolio_cents", "5000000", "25000000"),
    ):
        assert field in subject, f"{field} is not in the audit row: {subject}"
        assert before in subject, (
            f"the previous value of {field} is not recorded, so the edit that "
            f"enabled the next determination cannot be reconstructed: {subject}"
        )
        assert after in subject, f"the new value of {field} is missing: {subject}"


def test_the_diff_is_inside_the_audit_chain(api) -> None:
    """Recorded where it cannot be edited without breaking something.

    A before/after kept beside the chain rather than inside it would be a record
    of the change that is itself editable, which is the shape of the finding
    rather than a fix for it.
    """
    api.post("/v1/clients", json=_body())
    api.post("/v1/clients", json=_body(loss_capacity_band=4))

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            latest = _upsert_events()[0]
            assert latest.this_hash, "the audit row carries no hash at all"
            ok = evidence.verify_audit_chain(session)
        finally:
            session.close()

    assert ok["verified"] is True, f"the audit chain does not verify: {ok}"


def test_creating_a_client_records_no_diff(api) -> None:
    """There is nothing to compare against, and a diff of nulls is noise.

    A new id every run, because `clients` has no DELETE grant and a fixed one
    would be a creation on the first run of this suite and an update on every
    run after it.
    """
    import uuid

    fresh = f"{SUBJECT}-fresh-{uuid.uuid4().hex[:8]}"
    res = api.post("/v1/clients", json=_body(id=fresh))
    assert res.status_code in (200, 201), res.text

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            row = [
                r
                for r in session.scalars(
                    select(AuditEvent).order_by(AuditEvent.id.desc()).limit(20)
                )
                if fresh in (r.subject or "")
            ][0]
        finally:
            session.close()

    assert "created" in (row.subject or "")
    assert "->" not in (row.subject or ""), (
        f"a creation recorded a before/after diff: {row.subject}"
    )


def test_an_unchanged_resend_records_no_diff(api) -> None:
    """Re-sending a book must not fill the audit trail with empty diffs.

    An integration re-sends its whole client list nightly. If every unchanged
    row wrote a diff, the rows that matter would be invisible inside them.
    """
    api.post("/v1/clients", json=_body())
    api.post("/v1/clients", json=_body())

    latest = _upsert_events()[0]
    assert "->" not in (latest.subject or ""), (
        f"an unchanged re-send recorded a diff: {latest.subject}"
    )


def test_a_cosmetic_change_records_no_diff(api) -> None:
    """A corrected spelling is not what this is for.

    A diff that included every column would bury the three fields that move
    outcomes underneath the ones that never do.
    """
    api.post("/v1/clients", json=_body())
    api.post("/v1/clients", json=_body(name="A Client Whose Name Was Misspelt"))

    latest = _upsert_events()[0]
    assert "name" not in (latest.subject or ""), (
        f"a name correction was recorded as a decision-relevant change: "
        f"{latest.subject}"
    )


def test_the_knowledge_pair_is_covered(api) -> None:
    """Both halves of the knowledge assessment move outcomes, so both are watched."""
    api.post("/v1/clients", json=_body())
    api.post(
        "/v1/clients",
        json=_body(knowledge_date="2026-08-01", prior_crypto_purchases=9),
    )

    subject = _upsert_events()[0].subject or ""
    assert "knowledge_date" in subject, subject
    assert "prior_crypto_purchases" in subject, subject


def test_the_client_still_reads_back_correctly(api) -> None:
    """The control: recording the diff must not have changed what is stored."""
    api.post("/v1/clients", json=_body())
    api.post("/v1/clients", json=_body(loss_capacity_band=5))

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        from app.models import Client

        session = SessionLocal()
        try:
            stored = session.get(Client, SUBJECT)
            assert stored is not None
            assert stored.loss_capacity_band == 5
            assert stored.dob == date(1990, 4, 4)
        finally:
            session.close()
