"""Replay is the product. A failure here is a build-stopping event."""

from __future__ import annotations

import pytest

from app import evidence, packs_repo, service


def _replay(session, decision):
    """Replay a decision the way the application does.

    Not `packs_repo.by_version(session, "AU", ...)`: a decision made under
    another regime has to be read back under that regime's pack, and a
    cross-border one under every pack that applied to it. A test that assumed
    AU would pass by evaluating the wrong content.
    """
    pack = packs_repo.by_version(
        session, service._governing_pack_id(decision), decision.pack_version
    )
    return evidence.replay(decision, pack, service._other_packs(session, decision))


def test_every_seeded_decision_replays_exactly(session, decisions):
    failures = []
    for decision in decisions:
        result = _replay(session, decision)
        if not result["match"]:
            failures.append((decision.id, result["differences"]))

    assert not failures, f"{len(failures)} decisions failed to reproduce: {failures[:3]}"


def test_replay_covers_both_pack_versions(decisions):
    versions = {d.pack_version for d in decisions}
    assert versions >= {1, 2}, f"seeded history only covers packs {versions}"


def test_replay_covers_every_jurisdiction(session, decisions):
    """Acceptance: replay passes across all four regimes, not only the reference one."""
    replayed: set[str] = set()
    for decision in decisions:
        result = _replay(session, decision)
        assert result["match"], (decision.id, result["differences"])
        replayed.update(result["jurisdictions_replayed"])

    assert replayed >= {"AU", "HK", "SG", "EU"}, f"only replayed {sorted(replayed)}"


def test_cross_border_replay_reproduces_the_resolution(session, decisions):
    """The determination came from the resolution, so the resolution is what must reproduce."""
    cross = [d for d in decisions if (d.rule_results or {}).get("other_jurisdictions")]
    assert cross, "no cross-border decisions seeded"

    for decision in cross:
        result = _replay(session, decision)
        assert result["cross_border"] is True
        assert result["match"], (decision.id, result["differences"])
        assert len(result["jurisdictions_replayed"]) > 1


def test_cross_border_replay_notices_a_missing_regime(session, decisions):
    """Dropping one applicable pack must not quietly reproduce the same answer."""
    decision = next(d for d in decisions if (d.rule_results or {}).get("other_jurisdictions"))
    pack = packs_repo.by_version(
        session, service._governing_pack_id(decision), decision.pack_version
    )

    result = evidence.replay(decision, pack, others={})
    assert result["match"] is False
    assert any(d["field"].startswith("pack.") for d in result["differences"])


def test_replay_uses_the_pack_of_record_not_the_current_one(session, decisions):
    """A decision made under v1 must not be re-judged by v2."""
    v1_decisions = [
        d for d in decisions if d.pack_version == 1 and service._governing_pack_id(d) == "AU"
    ]
    assert v1_decisions, "no v1 decisions seeded"

    v1_pack = packs_repo.by_version(session, "AU", 1)
    v2_pack = packs_repo.by_version(session, "AU", 2)
    assert (
        v1_pack.thresholds["max_crypto_concentration_bps"]
        != v2_pack.thresholds["max_crypto_concentration_bps"]
    ), "packs must differ for this test to mean anything"

    for decision in v1_decisions:
        assert evidence.replay(decision, v1_pack)["match"]


def test_replay_detects_a_changed_stored_outcome(session, decisions):
    """Guard against replay that trivially reports success."""
    decision = decisions[0]

    original = decision.outcome
    decision.outcome = "ALLOW" if original != "ALLOW" else "BLOCK"
    try:
        result = _replay(session, decision)
        assert result["match"] is False
        assert any(d["field"] == "outcome" for d in result["differences"])
    finally:
        decision.outcome = original
        session.expunge(decision)


def test_stored_decision_is_immune_to_later_client_changes(session, decisions):
    """The snapshot is the only input: mutating the client must not move history."""
    from app.models import Client

    decision = next(d for d in decisions if d.snapshot["client"]["loss_capacity_band"] > 1)

    client = session.get(Client, decision.client_id)
    original_band = client.loss_capacity_band
    client.loss_capacity_band = 5
    session.flush()
    try:
        assert _replay(session, decision)["match"] is True
    finally:
        client.loss_capacity_band = original_band
        session.rollback()


@pytest.mark.parametrize("field", ["snapshot", "rule_results", "pack_version"])
def test_decision_records_everything_replay_needs(decisions, field):
    for decision in decisions:
        assert getattr(decision, field) is not None
