"""Encryption at rest: the claims, asserted rather than described.

The claim a diligence team actually tests is "a copy of your database is not a
copy of your customers' data". Everything here exists to make that sentence
fail loudly the day it stops being true — starting with the blunt version, that
a name read straight out of Postgres does not contain the name.

The AAD tests are the ones worth reading twice. They give the wrong tenant the
*right* key on purpose, so that what fails is the binding rather than the
cipher. A test where the key is also wrong would pass whether the additional
data were doing anything or not.
"""

from __future__ import annotations

import base64
import importlib
import json
import os

import pytest
from sqlalchemy import text

from app import crypto, tenancy
from app.artefacts.renderer import OUTPUT_DIR, SEALED_SUFFIX, _tenant_dir
from app.canonical import canonical_json
from app.models import Artefact, Base, Client
from tests.conftest import DEMO_TENANT

OTHER_TENANT = "not-this-firm"


def _pdf_ref(session, artefact_id: int) -> str:
    session.expire_all()
    return session.get(Artefact, artefact_id).pdf_ref


# ------------------------------------------------------ what is on the disk --


def test_client_names_are_ciphertext_in_the_database(session) -> None:
    """The headline claim, taken literally: read the column, look for the name."""
    row = session.execute(text("SELECT id, name FROM clients ORDER BY id LIMIT 1")).one()
    stored = bytes(row.name)
    plaintext = session.get(Client, row.id).name

    assert plaintext, "the fixture client has no name; this test proves nothing"
    assert plaintext.encode("utf-8") not in stored
    assert stored[0] == crypto.FORMAT_V1


def test_decision_snapshots_are_ciphertext_in_the_database(session, decisions) -> None:
    """The snapshot is the record replay reads back, and the one holding the detail."""
    decision = decisions[0]
    stored = bytes(
        session.execute(
            text("SELECT snapshot FROM decisions WHERE id = :id"), {"id": decision.id}
        ).scalar_one()
    )
    assert canonical_json(decision.snapshot).encode("utf-8") not in stored
    assert stored[0] == crypto.FORMAT_V1


def test_a_snapshot_survives_the_round_trip_byte_for_byte(session, decisions) -> None:
    """Invariant 5, at the layer that could quietly break it.

    Encryption sits between the engine and the disk, and a snapshot that came
    back re-ordered or re-spaced would decode to an equal dict while hashing to
    a different value — replay would fail on evidence nobody had touched. So the
    assertion is on the bytes, not on equality of the decoded object.
    """
    decision = decisions[0]
    stored = session.execute(
        text("SELECT snapshot FROM decisions WHERE id = :id"), {"id": decision.id}
    ).scalar_one()
    opened = crypto.decrypt(bytes(stored), column="decisions.snapshot")

    assert opened == canonical_json(decision.snapshot).encode("utf-8")
    assert json.loads(opened) == decision.snapshot


def test_a_generated_pdf_is_ciphertext_on_disk(client, session) -> None:
    """The document is the whole determination in one file — name, figures, reasons.

    It is also the only piece of a tenant's data that leaves Postgres, so it is
    the piece a database-only encryption story would miss.
    """
    decision = client.post("/evaluate", json={"client_id": "tom-askew", "asset_id": "SOL"}).json()
    artefact = client.post("/artefacts/tmd", json={"decision_id": decision["id"]}).json()

    served = client.get(artefact["download_url"])
    assert served.status_code == 200
    assert served.content.startswith(b"%PDF")

    stored = (
        OUTPUT_DIR / DEMO_TENANT / f"{_pdf_ref(session, artefact['id'])}{SEALED_SUFFIX}"
    ).read_bytes()

    assert not stored.startswith(b"%PDF")
    assert stored[0] == crypto.FORMAT_V1
    assert b"Askew" not in stored


def test_documents_are_filed_under_the_tenant_that_owns_them(session) -> None:
    """Encryption is what makes another tenant's document unreadable; this is
    what keeps the two from ever sitting in the same directory to begin with."""
    with tenancy.acting_as(DEMO_TENANT):
        mine = _tenant_dir()
    with tenancy.acting_as(OTHER_TENANT):
        theirs = _tenant_dir()

    assert mine != theirs
    assert mine.name == DEMO_TENANT


# ------------------------------------------------ what the binding is doing --


def test_a_ciphertext_moved_to_another_column_will_not_decrypt(session) -> None:
    sealed = crypto.encrypt(b"Tom Askew", column="clients.name")
    assert crypto.decrypt(sealed, column="clients.name") == b"Tom Askew"

    with pytest.raises(ValueError, match="failed authentication"):
        crypto.decrypt(sealed, column="clients.note")


def test_a_ciphertext_moved_to_another_tenant_will_not_decrypt(session) -> None:
    """The other tenant is handed this tenant's own key, so only the AAD can fail."""
    sealed = crypto.encrypt(b"Tom Askew", column="clients.name")
    borrowed = crypto._KEYS[DEMO_TENANT]  # noqa: SLF001 — the point of the test

    with tenancy.acting_as(OTHER_TENANT):
        crypto._KEYS[OTHER_TENANT] = borrowed  # noqa: SLF001
        try:
            with pytest.raises(ValueError, match="failed authentication"):
                crypto.decrypt(sealed, column="clients.name")
        finally:
            del crypto._KEYS[OTHER_TENANT]  # noqa: SLF001


def test_a_wrapped_key_will_not_unwrap_for_another_tenant() -> None:
    """Copying a row of `tenant_keys` onto another tenant hands over nothing."""
    key = crypto.new_key()
    wrapped = crypto.wrap(key, "acme")
    assert crypto.unwrap(wrapped, "acme") == key

    with pytest.raises(crypto.KeysNotConfigured):
        crypto.unwrap(wrapped, "beta")


def test_a_wrapped_key_will_not_unwrap_under_a_different_master_key(monkeypatch) -> None:
    """The envelope's whole purpose: the dump is inert without the other secret."""
    key = crypto.new_key()
    wrapped = crypto.wrap(key, "acme")

    monkeypatch.setenv(crypto.MASTER_KEY_ENV, base64.b64encode(os.urandom(32)).decode())
    with pytest.raises(crypto.KeysNotConfigured):
        crypto.unwrap(wrapped, "acme")


# ----------------------------------------------------- what refuses to start --


@pytest.mark.parametrize(
    "value,why",
    [
        ("", "unset"),
        ("correct horse battery staple", "a passphrase rather than a key"),
        (base64.b64encode(os.urandom(16)).decode(), "sixteen bytes"),
    ],
)
def test_the_master_key_is_checked_rather_than_assumed(monkeypatch, value, why) -> None:
    monkeypatch.setenv(crypto.MASTER_KEY_ENV, value)
    with pytest.raises(crypto.KeysNotConfigured):
        crypto.master_key()


def test_a_tenant_with_no_data_key_fails_rather_than_inventing_one(session) -> None:
    """Fail closed. The alternative is a key nobody recorded the creation of."""
    with tenancy.acting_as(OTHER_TENANT):
        with pytest.raises(crypto.NoDataKey):
            crypto.encrypt(b"anything", column="clients.name")


# ------------------------------------------------------------ what may drift --


#: Columns that were born encrypted, rather than converted from plaintext.
#:
#: 0005 and 0006 exist to move *existing* rows: add a ciphertext column beside
#: the plaintext one, fill it, drop the original. A table created after that
#: work has no plaintext twin to drop, so its sealed columns never appear in
#: 0006's list and never should — adding them there would claim a conversion
#: that did not happen, in a migration whose whole job is to record what ran.
#:
#: Listed here rather than derived, so that the next sealed column is a
#: deliberate line in this file instead of something the test quietly forgives.
BORN_ENCRYPTED = {
    "users": {"display_name"},
    "mfa_credentials": {"secret"},
    # Stage 4. A webhook signing secret is encrypted rather than hashed, which is
    # the opposite of the choice made for `api_clients.secret_hash` beside it and
    # right for a different reason: signing material has to be usable, because
    # the same bytes sign every payload. A hash would make it unforgeable and
    # also unusable.
    "webhook_endpoints": {"secret"},
}


def test_the_migration_lists_exactly_the_columns_the_models_encrypt() -> None:
    """The one duplicated list in this stage, checked.

    Migration 0006 spells the encrypted columns out longhand and says why: a
    migration is a record of what was run, and must not change meaning when the
    models do. The cost of that is a copy, and the copy is only safe if
    something notices when it stops matching. A column encrypted in the models
    but absent here would keep its plaintext twin in the schema forever.
    """
    migration = importlib.import_module("migrations.versions.0006_encrypted_columns")

    from_models: dict[str, set[str]] = {}
    for table in Base.metadata.tables.values():
        for column in table.columns:
            if isinstance(column.type, crypto._Encrypted):  # noqa: SLF001
                from_models.setdefault(table.name, set()).add(column.name)

    converted = {
        table: columns - BORN_ENCRYPTED.get(table, set())
        for table, columns in from_models.items()
    }
    converted = {table: columns for table, columns in converted.items() if columns}

    from_migration = {t: set(c) for t, c in migration.ENCRYPTED_COLUMNS.items()}
    assert converted == from_migration
