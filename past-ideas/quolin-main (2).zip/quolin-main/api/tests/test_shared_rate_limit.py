"""§S12: login rate limiting is shared between processes, and actually recorded.

Two things are asserted here, and they were one change because they were one
bug.

**The counter is shared.** It used to be a dictionary in this process, which
meant a second API task got its own copy and an attacker got twice the guesses.
`infra/variables.tf` pinned `api_desired_count` at 1 for exactly that reason,
with a note calling any increase "a security regression disguised as a scaling
decision" — and pinned at one process, a load test found the API using one core
of twelve while twenty concurrent users waited.

The sharing has to be tested across processes or not at all. A module-level
dictionary is shared between two `Session`s in one interpreter, so a
same-process test passes identically before and after the change and proves
nothing. The test below spends the cost of a subprocess to be meaningful.

**Failed sign-ins are recorded at all.** They were not. The row went to
`security_events`, which is tenant-scoped, from `/auth/login`, which is the one
request that has no tenant — so the insert failed the policy's row check every
time and `observability.record` swallowed it exactly as it was designed to.
Stage 9 built auth-anomaly alerting on that table and its game day passed,
because the game day writes its own rows with a tenant in scope.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest
from conftest import ADMIN_EMAIL, reset_rate_limit_for_tests
from fastapi.testclient import TestClient
from sqlalchemy import func, select, text
from sqlalchemy.exc import SQLAlchemyError

from app import auth
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import AuthAttempt

REPO = Path(__file__).resolve().parents[2]
PROBE_IP = "203.0.113.77"


@pytest.fixture
def clean_attempts():
    """No history for the probe address, before and after."""
    def wipe():
        owner = OwnerSessionLocal()
        try:
            owner.execute(
                text("ALTER TABLE auth_attempts DISABLE TRIGGER auth_attempts_append_only")
            )
            owner.execute(
                text("DELETE FROM auth_attempts WHERE source_ip = :ip"), {"ip": PROBE_IP}
            )
            owner.execute(
                text("ALTER TABLE auth_attempts ENABLE TRIGGER auth_attempts_append_only")
            )
            owner.commit()
        finally:
            owner.close()

    wipe()
    yield PROBE_IP
    wipe()


def test_the_counter_is_shared_between_processes(clean_attempts):
    """Failures recorded by another process count against this one.

    The load-bearing test in this file. A separate interpreter records one
    short of the limit; this one records the last and must be refused.
    """
    short_of_limit = auth.MAX_ATTEMPTS - 1
    result = subprocess.run(
        [
            sys.executable,
            "-c",
            "import sys; sys.path.insert(0, 'api');"
            "from app.db import SessionLocal;"
            "from app import auth;"
            "s = SessionLocal();"
            f"[auth.record_failure(s, {PROBE_IP!r}) for _ in range({short_of_limit})];"
            "s.commit(); s.close(); print('done')",
        ],
        cwd=REPO,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert "done" in result.stdout

    session = SessionLocal()
    try:
        # Not yet: one short of the limit is still allowed, which is what makes
        # the next assertion mean something.
        auth.check_rate_limit(session, PROBE_IP)

        auth.record_failure(session, PROBE_IP)
        session.commit()
        with pytest.raises(auth.RateLimited):
            auth.check_rate_limit(session, PROBE_IP)
    finally:
        session.close()


def test_a_correct_password_clears_the_address_without_deleting_anything(clean_attempts):
    """Success is a row, not a DELETE.

    Somebody who fumbles their password twice and then gets it right should not
    stay part-way to a lockout — but the record of the two failures is evidence,
    and an attacker eventually guessing right must not erase the attempts that
    came before.
    """
    session = SessionLocal()
    try:
        for _ in range(auth.MAX_ATTEMPTS - 1):
            auth.record_failure(session, PROBE_IP)
        session.commit()

        auth.clear_failures(session, PROBE_IP)
        session.commit()

        # Cleared: the next failures start from zero again.
        for _ in range(auth.MAX_ATTEMPTS - 1):
            auth.record_failure(session, PROBE_IP)
        session.commit()
        auth.check_rate_limit(session, PROBE_IP)

        # And nothing was thrown away.
        kept = session.scalar(
            select(func.count(AuthAttempt.id)).where(AuthAttempt.source_ip == PROBE_IP)
        )
        assert kept == (auth.MAX_ATTEMPTS - 1) * 2 + 1, (
            "a success must not delete the failures that preceded it"
        )
    finally:
        session.close()


def test_the_table_refuses_to_forget(clean_attempts):
    """Append-only, by grant and by trigger, like the rest of the evidence."""
    session = SessionLocal()
    try:
        auth.record_failure(session, PROBE_IP)
        session.commit()
        # Either grant or trigger refuses it; which one fires first is Postgres's
        # business and asserting on the message would pin an implementation
        # detail. That both exist is asserted by the migration linter.
        with pytest.raises(SQLAlchemyError):
            session.execute(
                text("DELETE FROM auth_attempts WHERE source_ip = :ip"), {"ip": PROBE_IP}
            )
            session.commit()
    finally:
        session.rollback()
        session.close()


def test_a_failed_sign_in_through_the_api_is_written_down(clean_attempts):
    """The regression that was silent.

    Three failed logins against the running system used to write zero rows.
    Asserted through the endpoint rather than against `record_failure`, because
    the bug was not in the recording — it was in where the recording went, and
    only a real request reproduces the conditions that made it fail.
    """
    session = SessionLocal()
    try:
        before = session.scalar(
            select(func.count(AuthAttempt.id)).where(AuthAttempt.outcome == auth.FAILED)
        )
    finally:
        session.close()

    reset_rate_limit_for_tests()
    with TestClient(app) as anon:
        response = anon.post(
            "/auth/login", json={"email": ADMIN_EMAIL, "password": "not the password"}
        )
    assert response.status_code == 401

    session = SessionLocal()
    try:
        after = session.scalar(
            select(func.count(AuthAttempt.id)).where(AuthAttempt.outcome == auth.FAILED)
        )
        newest = session.scalars(
            select(AuthAttempt).order_by(AuthAttempt.id.desc()).limit(1)
        ).first()
    finally:
        session.close()

    assert after == before + 1, "a failed sign-in left no trace"
    assert newest is not None and newest.outcome == auth.FAILED
    # Named by account, because this attempt resolved to a real one — and never
    # by the address that was typed.
    assert newest.user_id, "an attempt that resolved to an account should name it"
