"""Background workers must find tenants without depending on role attributes.

Every scheduled job in `scripts/` starts the same way: enumerate the active
firms, then bind each one in turn. That enumeration happens through
`OwnerSessionLocal` with no tenant bound, and `tenants` carries `FORCE ROW LEVEL
SECURITY` with a policy of `id = current_setting('app.tenant_id', true)`. With
no tenant bound the setting is the empty string, which matches no row.

In development that is invisible: the owner role is a superuser and holds
BYPASSRLS, and either attribute turns the policy into a comment. An RDS master
account — which is what `infra/` provisions — holds neither. Every worker would
then enumerate nothing, print a summary and exit 0, and `health_alerts.py`, the
§S9 paging path, would report all-clear forever.

So the enumeration must not depend on *what kind of role* is connecting. It
depends instead on an explicit grant: membership of `quolin_maintenance`, given
to the schema owner by migration 0029. These tests connect as a role that has
neither privileged attribute and assert the workers still see the firms — and,
just as importantly, that a role without the grant still sees nothing.
"""

from __future__ import annotations

import importlib
import sys
from pathlib import Path

import pytest
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker

from app import tenancy
from app.db import OWNER_DATABASE_URL, OwnerSessionLocal, _bind_tenant_to_transaction

# The workers live outside the `api` package, next to the Makefile that runs
# them. `tests/test_bluegreen.py` reaches them the same way and for the same
# reason: what is under test is the script a scheduler executes, not a copy of
# its logic moved somewhere more convenient to import.
REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

#: The role migration 0029 creates. Membership of it, not superuser-ness, is
#: what admits a connection to the whole tenant list.
MAINTENANCE_ROLE = "quolin_maintenance"

#: A stand-in for the RDS master account: it owns nothing, is not a superuser,
#: and does not hold BYPASSRLS. Created here rather than in the CI service
#: definition so that the check is identical on a laptop and in CI — a fixture
#: travels with the suite and a service definition does not.
PROBE_ROLE = "quolin_probe"
PROBE_PASSWORD = "quolin_probe"


def _probe_url(role: str = PROBE_ROLE) -> str:
    """The probe's URL, derived from the owner's so host and port stay in step."""
    tail = OWNER_DATABASE_URL.split("@", 1)[1]
    return f"postgresql+psycopg://{role}:{PROBE_PASSWORD}@{tail}"


#: The workers that discover their own work rather than being told which firm to
#: act for. `deliver_webhooks`, `batch_sweep` and `settle_packs` are deliberately
#: absent: each takes tenants as arguments and defaults to the configured one,
#: which is a different design and not the one this file is about.
DISCOVERING_WORKERS = (
    "bulk_worker",
    "artefact_worker",
    "comparison_report",
    "health_alerts",
)


@pytest.fixture(scope="module")
def owner_conn():
    engine = create_engine(OWNER_DATABASE_URL, future=True, pool_pre_ping=True)
    try:
        with engine.connect() as conn:
            conn.execution_options(isolation_level="AUTOCOMMIT")
            yield conn
    finally:
        engine.dispose()


@pytest.fixture(scope="module")
def probe_roles(owner_conn):
    """Two unprivileged login roles: one holding the maintenance grant, one not.

    The pair is the point. A single role that could read `tenants` would prove
    only that *something* let it through; the ungranted twin is what shows the
    grant is doing the work and the policy is still closed to everybody else.
    """
    granted, ungranted = PROBE_ROLE, f"{PROBE_ROLE}_ungranted"
    for role in (granted, ungranted):
        owner_conn.execute(
            text(
                f"""
                DO $$
                BEGIN
                  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{role}') THEN
                    EXECUTE 'DROP OWNED BY {role}';
                    EXECUTE 'DROP ROLE {role}';
                  END IF;
                END
                $$;
                """
            )
        )
        owner_conn.execute(
            text(
                f"CREATE ROLE {role} LOGIN PASSWORD '{PROBE_PASSWORD}' "
                f"NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE"
            )
        )
        owner_conn.execute(text(f"GRANT USAGE ON SCHEMA public TO {role}"))
        owner_conn.execute(text(f"GRANT SELECT ON ALL TABLES IN SCHEMA public TO {role}"))
    owner_conn.execute(text(f"GRANT {MAINTENANCE_ROLE} TO {granted}"))
    owner_conn.commit()

    yield {"granted": granted, "ungranted": ungranted}

    for role in (granted, ungranted):
        owner_conn.execute(text(f"REVOKE ALL ON ALL TABLES IN SCHEMA public FROM {role}"))
        owner_conn.execute(text(f"REVOKE ALL ON SCHEMA public FROM {role}"))
        owner_conn.execute(text(f"DROP OWNED BY {role}"))
        owner_conn.execute(text(f"DROP ROLE {role}"))
    owner_conn.commit()


def _sessionmaker_for(role: str):
    """A sessionmaker shaped exactly like `OwnerSessionLocal`, on another role.

    The `begin` hook matters and is easy to leave off: it is what sets
    `app.tenant_id` to the empty string on every transaction, which is the state
    a worker enumerates in. Without it the setting would be unset rather than
    empty, and this file would be testing a state no worker is ever in.
    """
    engine = create_engine(_probe_url(role), future=True, pool_pre_ping=True)
    event.listen(engine, "begin", _bind_tenant_to_transaction)
    return sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, future=True)


def test_the_probe_role_has_neither_privileged_attribute(probe_roles, owner_conn) -> None:
    """Guard against the fixture accidentally testing nothing.

    If the probe were a superuser, or held BYPASSRLS, every assertion below
    would pass whatever the policy said — which is precisely the way this defect
    stayed invisible in development for thirteen stages.
    """
    for role in probe_roles.values():
        row = owner_conn.execute(
            text("SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = :r"),
            {"r": role},
        ).one()
        assert row.rolsuper is False, f"{role} is a superuser; this test proves nothing"
        assert row.rolbypassrls is False, f"{role} holds BYPASSRLS; this test proves nothing"


@pytest.mark.parametrize("worker", DISCOVERING_WORKERS)
def test_a_worker_enumerates_tenants_without_bypassrls(worker, probe_roles, monkeypatch) -> None:
    """The finding, as a test: run the worker's own `_tenants()` as an RDS master."""
    module = importlib.import_module(f"scripts.{worker}")
    monkeypatch.setattr(module, "OwnerSessionLocal", _sessionmaker_for(probe_roles["granted"]))

    found = module._tenants()
    # `comparison_report` returns (tenant_id, stage) pairs; the rest return ids.
    ids = [row[0] if isinstance(row, tuple) else row for row in found]

    assert "demo" in ids, (
        f"scripts/{worker}.py enumerated {len(ids)} tenants as a role without "
        "BYPASSRLS. On RDS every worker would find nothing to do and exit 0."
    )


def test_a_role_without_the_grant_still_sees_no_tenants(probe_roles) -> None:
    """The other half: the maintenance grant is what admits, and nothing else.

    Run with the ambient tenant explicitly cleared. A worker enumerating is
    between tenants by definition, and the first version of this test inherited
    whatever a previously-run module had left in the context variable — so it
    passed alone and failed in a full run, having quietly measured the policy's
    *other* clause. The reset is what makes it about the grant.
    """
    token = tenancy._current.set(None)
    try:
        maker = _sessionmaker_for(probe_roles["ungranted"])
        session = maker()
        try:
            rows = list(session.execute(text("SELECT id FROM tenants")).scalars())
        finally:
            session.close()
    finally:
        tenancy._current.reset(token)

    assert rows == [], (
        "a role with no maintenance grant read the tenant list. The policy on "
        "`tenants` is meant to be closed to everybody who has not been granted "
        f"{MAINTENANCE_ROLE} by migration."
    )


def test_a_role_without_the_grant_sees_only_the_tenant_it_is_bound_to(probe_roles) -> None:
    """And when a tenant *is* bound, it sees exactly that one and no more.

    The policy gained a clause; it must not have lost one. This is the case the
    application role is always in, and widening it would mean any authenticated
    request could list the platform's customers by name.
    """
    maker = _sessionmaker_for(probe_roles["ungranted"])
    with tenancy.acting_as("demo"):
        session = maker()
        try:
            rows = list(session.execute(text("SELECT id FROM tenants")).scalars())
        finally:
            session.close()
    assert rows == ["demo"], rows


def test_the_schema_owner_holds_the_maintenance_grant(owner_conn) -> None:
    """Migration 0029 must have granted it, or an RDS master gets nothing.

    The probe above proves the mechanism works for *a* role holding the grant.
    This proves the role the workers actually connect as is one of them.
    """
    holds = owner_conn.execute(
        text(f"SELECT pg_has_role(current_user, '{MAINTENANCE_ROLE}', 'USAGE')")
    ).scalar()
    assert holds is True, (
        f"the schema owner is not a member of {MAINTENANCE_ROLE}. In development "
        "BYPASSRLS hides that; on RDS every scheduled job would enumerate zero "
        "tenants."
    )


def test_the_application_role_is_not_admitted_by_the_maintenance_grant(owner_conn) -> None:
    """The fix must not widen what a request can see.

    `quolin_app` serves HTTP. If the new policy admitted it, any authenticated
    request could list every customer of the platform by name — which is the
    disclosure the policy on `tenants` was added to prevent in the first place.
    """
    for role in ("quolin_app", "quolin_watch"):
        holds = owner_conn.execute(
            text(f"SELECT pg_has_role('{role}', '{MAINTENANCE_ROLE}', 'USAGE')")
        ).scalar()
        assert holds is False, f"{role} was granted {MAINTENANCE_ROLE}"


@pytest.mark.parametrize("worker", DISCOVERING_WORKERS)
def test_a_worker_reports_an_empty_tenant_list_as_a_fault(worker, monkeypatch) -> None:
    """Nothing to do is a finding, not a pass.

    A scheduled job that enumerates zero firms in a system with paying customers
    has not had a quiet night; it has failed to see the work. Exiting 0 is how
    that failure stays invisible — and is exactly how the defect above would
    have presented in production.
    """
    module = importlib.import_module(f"scripts.{worker}")
    monkeypatch.setattr(module, "_tenants", lambda: [])
    monkeypatch.setattr("sys.argv", [worker])
    monkeypatch.setenv("QUOLIN_PAGER_URL", "")

    assert module.main() != 0, (
        f"scripts/{worker}.py found no tenants at all and exited 0. A scheduler "
        "reading that exit code learns nothing happened and that this was fine."
    )


def test_health_alerts_records_a_heartbeat(monkeypatch) -> None:
    """§S9's paging path must leave a trace of having run.

    An alerting job that is silent because everything is well and one that is
    silent because it is dead look identical from the outside. The heartbeat is
    what tells them apart: something else can notice that the last one is old.
    """
    from app.db import OwnerSessionLocal
    from app.models import WorkerHeartbeat

    module = importlib.import_module("scripts.health_alerts")
    monkeypatch.setattr("sys.argv", ["health_alerts", "--no-page"])
    module.main()

    owner = OwnerSessionLocal()
    try:
        beat = owner.query(WorkerHeartbeat).filter_by(worker="health_alerts").one_or_none()
    finally:
        owner.close()

    assert beat is not None, "health_alerts ran and left no heartbeat"
    assert beat.tenants_seen > 0




# --- the preflight, added by F12 ------------------------------------------
#
# The grant is checked *before* the enumeration rather than diagnosed after it.
# `NoActiveTenants` already refuses to let an empty enumeration read as success,
# so the failure was never silent — but it was misdiagnosed. Migration 0029
# grants `quolin_maintenance` `TO current_user`, the account alembic runs as,
# and on a deployment where migrations run as a migrator and the workers connect
# as somebody else the grant lands on the wrong role. The worker then reports
# "no active firms were visible", and whoever is paged at 03:00 goes to look at
# a `tenants` table that is full.


def test_the_preflight_passes_for_a_role_holding_the_grant(probe_roles) -> None:
    from app import maintenance

    factory = _sessionmaker_for(probe_roles["granted"])
    session = factory()
    try:
        assert maintenance.holds_the_maintenance_grant(session) is True
        # And does not raise, which is what the workers actually call.
        maintenance.assert_can_enumerate(session)
    finally:
        session.close()


def test_the_preflight_refuses_a_role_without_the_grant(probe_roles) -> None:
    from app import maintenance

    factory = _sessionmaker_for(probe_roles["ungranted"])
    session = factory()
    try:
        assert maintenance.holds_the_maintenance_grant(session) is False
        with pytest.raises(maintenance.NoActiveTenants) as refused:
            maintenance.assert_can_enumerate(session)
    finally:
        session.close()

    message = str(refused.value)
    assert MAINTENANCE_ROLE in message, "the refusal does not name the role"
    assert "GRANT" in message, (
        "the refusal does not say how to fix it, which is the whole reason it "
        "exists rather than being left to `NoActiveTenants`"
    )


def test_the_preflight_names_the_cause_the_old_message_did_not(probe_roles) -> None:
    """The two failures are different and now read differently.

    Before this, both arrived as "no active tenants were visible to this
    connection" — one because the grant was missing, one because the table
    genuinely was empty. Same words, different first move.
    """
    from app import maintenance

    factory = _sessionmaker_for(probe_roles["ungranted"])
    session = factory()
    try:
        with pytest.raises(maintenance.NoActiveTenants) as ungranted:
            maintenance.assert_can_enumerate(session)
    finally:
        session.close()

    owner = OwnerSessionLocal()
    try:
        # The owner holds the grant, so the preflight passes and any failure
        # here would be about the data rather than the connection.
        maintenance.assert_can_enumerate(owner)
    finally:
        owner.close()

    assert "not a member" in str(ungranted.value)
