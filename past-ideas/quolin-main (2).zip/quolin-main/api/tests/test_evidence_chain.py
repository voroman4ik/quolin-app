"""Append-only is a demonstrable property here, not a claim in a slide."""

from __future__ import annotations

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from app import evidence
from app.canonical import GENESIS, canonical_json, chain_hash
from app.db import engine, owner_engine
from app.models import APPEND_ONLY_TABLES, ChainAnchor, Decision


def test_chain_verifies_across_all_seeded_decisions(session):
    result = evidence.verify_chain(session)
    assert result["verified"], result
    assert result["checked"] > 0


def test_chain_links_are_contiguous(session, decisions):
    """Contiguous from the tenant's anchor, not from a global constant.

    This used to start at GENESIS, and that is exactly what stopped being true
    when chains became per-tenant — see `test_chain_anchors.py`.
    """
    prev = session.get(ChainAnchor, DEMO_TENANT).genesis_hash
    for decision in decisions:
        assert decision.prev_hash == prev
        prev = decision.this_hash


def test_hash_changes_when_any_field_changes():
    row = {"outcome": "BLOCK", "snapshot": {"a": 1}}
    baseline = chain_hash(GENESIS, row)

    assert chain_hash(GENESIS, {**row, "outcome": "ALLOW"}) != baseline
    assert chain_hash(GENESIS, {**row, "snapshot": {"a": 2}}) != baseline
    assert chain_hash("f" * 64, row) != baseline
    assert chain_hash(GENESIS, row) == baseline


def test_canonical_json_is_key_order_independent():
    assert canonical_json({"b": 1, "a": 2}) == canonical_json({"a": 2, "b": 1})


def test_tampering_with_a_decision_breaks_verification(session, decisions):
    """The tamper demo, as a test: a value that does not match its hash.

    **Against a row in the database, which it was not.** This used to alter an
    ORM object's `outcome` without flushing — `decisions` refuses UPDATE by
    trigger and by revoked grant, so it could not be flushed — and assert that
    verification failed. It passed because `verify_chain` walked the identity
    map, which means it was reporting on an object this process had altered
    rather than on anything anybody had written.

    Comfortable in that direction and dangerous in the other: a session holding
    a cached copy of a row an attacker then altered would have verified against
    the copy and reported the chain intact. `verify_chain` reads the columns
    now, so the tamper has to be a row.

    Appended rather than edited, because appending is the attack the chain
    exists to make visible and editing is one the database refuses outright. The
    row is a well-formed determination — it decrypts, which is what separates
    this from `UNDECRYPTABLE_SNAPSHOT` — carrying hashes that are not its own.
    Rolled back, because `decisions` refuses DELETE too.
    """
    template = decisions[-1]
    forged = Decision(
        tenant_id=template.tenant_id,
        client_id=template.client_id,
        asset_id=template.asset_id,
        as_of=template.as_of,
        pack_id=template.pack_id,
        pack_version=template.pack_version,
        snapshot=template.snapshot,
        rule_results=template.rule_results,
        resolution=template.resolution,
        outcome="ALLOW" if template.outcome != "ALLOW" else "BLOCK",
        prev_hash=template.this_hash,
        this_hash="0" * 64,
        payload_schema=template.payload_schema,
        manifest=template.manifest,
    )
    session.add(forged)
    session.flush()

    try:
        result = evidence.verify_chain(session)
        assert result["verified"] is False
        assert result["broken_at_decision_id"] == forged.id
        assert result["reason"] == evidence.HASH_MISMATCH, (
            "a row that decrypts and does not hash was reported as unreadable. "
            "The two reasons ask different first questions — what changed, "
            "against who has write access — and conflating them sends whoever "
            "is paged to the wrong place."
        )
        assert result["expected_hash"] != result["stored_hash"]
    finally:
        session.rollback()

    assert evidence.verify_chain(session)["verified"] is True


def _a_disposable_row(conn, table: str) -> None:
    """Put one row in `table`, whatever its columns happen to be.

    Only ever called inside a transaction that is rolled back. It exists so the
    trigger test can assert the same thing about every append-only table rather
    than only the ones the demo seed happens to fill.

    Built from `information_schema` rather than from the ORM: the models carry
    encrypted columns, defaults bound in Python and relationships that would
    each need handling, and none of that is what is under test. What is under
    test is that the trigger refuses, and the trigger does not care what is in
    the row.

    A table that already holds rows needs nothing.
    """
    if conn.execute(text(f"SELECT 1 FROM {table} LIMIT 1")).first() is not None:
        return

    columns = conn.execute(
        text(
            "SELECT column_name, data_type, is_nullable, column_default, "
            "is_identity FROM information_schema.columns "
            "WHERE table_schema = 'public' AND table_name = :t"
        ),
        {"t": table},
    ).all()

    placeholders = {
        "text": "'x'",
        "character varying": "'x'",
        "boolean": "false",
        "integer": "0",
        "bigint": "0",
        "smallint": "0",
        "date": "current_date",
        "timestamp with time zone": "now()",
        "timestamp without time zone": "now()",
        "jsonb": "'{}'::jsonb",
        "json": "'{}'::json",
        "uuid": "gen_random_uuid()",
    }

    # Foreign keys have to be satisfied with real parents. `SET CONSTRAINTS ALL
    # DEFERRED` does nothing here — Postgres defers only constraints declared
    # DEFERRABLE, and none of these are — and disabling the FK triggers would
    # disable the append-only trigger with them, which is the thing under test.
    #
    # So each referencing column borrows a value that already exists.
    borrowed = {}
    for column, ref_table, ref_column in _foreign_keys(conn, table):
        existing = conn.execute(
            text(f"SELECT {ref_column} FROM {ref_table} LIMIT 1")
        ).scalar()
        if existing is None:
            pytest.skip(
                f"{table} references {ref_table}, which is empty, so no "
                "disposable row can be built for it"
            )
        borrowed[column] = existing

    names, values, params = [], [], {}
    for name, data_type, nullable, default, identity in columns:
        if identity == "YES":
            continue
        if name in borrowed:
            names.append(f'"{name}"')
            values.append(f":{name}")
            params[name] = borrowed[name]
            continue
        if default is not None or nullable == "YES":
            continue
        value = placeholders.get(data_type)
        if value is None:  # pragma: no cover - a column type nothing uses yet
            raise AssertionError(
                f"{table}.{name} is {data_type}, which _a_disposable_row does "
                "not know how to fill. Add it to `placeholders`."
            )
        names.append(f'"{name}"')
        values.append(value)

    conn.execute(
        text(f"INSERT INTO {table} ({', '.join(names)}) VALUES ({', '.join(values)})"),
        params,
    )


def _foreign_keys(conn, table: str) -> list[tuple[str, str, str]]:
    """(column, referenced table, referenced column) for each FK on `table`."""
    return [
        (row[0], row[1], row[2])
        for row in conn.execute(
            text(
                """
                SELECT kcu.column_name, ccu.table_name, ccu.column_name
                FROM information_schema.table_constraints tc
                JOIN information_schema.key_column_usage kcu
                  ON kcu.constraint_name = tc.constraint_name
                JOIN information_schema.constraint_column_usage ccu
                  ON ccu.constraint_name = tc.constraint_name
                WHERE tc.constraint_type = 'FOREIGN KEY'
                  AND tc.table_schema = 'public'
                  AND tc.table_name = :t
                """
            ),
            {"t": table},
        ).all()
    ]


def _a_primary_key_column(conn, table: str) -> str:
    """One column of `table`'s primary key, for a no-op self-assignment.

    `UPDATE t SET id = id` assumed every table has an `id`. `chain_anchors` is
    keyed on `tenant_id` and `pack_publications` on `pack_id`, so the statement
    failed to parse and the test reported a missing column as though it were a
    missing refusal.
    """
    column = conn.execute(
        text(
            """
            SELECT kcu.column_name
            FROM information_schema.table_constraints tc
            JOIN information_schema.key_column_usage kcu
              ON kcu.constraint_name = tc.constraint_name
            WHERE tc.constraint_type = 'PRIMARY KEY'
              AND tc.table_schema = 'public'
              AND tc.table_name = :t
            ORDER BY kcu.ordinal_position
            LIMIT 1
            """
        ),
        {"t": table},
    ).scalar()
    assert column, f"{table} has no primary key"
    return str(column)


@pytest.mark.parametrize("table", sorted(APPEND_ONLY_TABLES))
def test_the_application_role_has_no_grant_to_rewrite_evidence(table):
    """The outer of the two locks: the application cannot even attempt it.

    `quolin_app` has UPDATE and DELETE revoked on every append-only table, so
    the request never reaches the trigger. This is the lock that matters in
    practice, because it is the role every request actually runs as.

    **Parametrised over the constant, not over four names typed here.** FP3-10:
    this listed `decisions`, `packs`, `overrides` and `audit_events` while the
    database protected thirteen tables, so nine were asserted about by nothing —
    and `chain_rechains`, the record of who rewrote a firm's evidence hashes,
    genuinely did carry UPDATE and DELETE for the application role. A list of
    names in a test is a list somebody has to remember to extend, and the whole
    argument of this repository is against controls of that shape.
    """
    # No emptiness precondition, and that is not an omission. Postgres checks
    # privileges when it plans the statement, before it looks at a single row,
    # so `UPDATE t SET id = id` on an empty table raises permission denied just
    # as loudly. The trigger test below is the one that needs a row, because a
    # row-level trigger genuinely cannot fire without one.
    with owner_engine.connect() as reader:
        key = _a_primary_key_column(reader, table)

    with engine.begin() as conn:
        with pytest.raises(DBAPIError, match="permission denied"):
            conn.execute(text(f"UPDATE {table} SET {key} = {key}"))

    with engine.begin() as conn:
        with pytest.raises(DBAPIError, match="permission denied"):
            conn.execute(text(f"DELETE FROM {table}"))


@pytest.mark.parametrize("table", sorted(APPEND_ONLY_TABLES))
def test_append_only_tables_reject_update_and_delete(table):
    """The inner lock, tested as the owner — the role that holds the grant.

    Connecting as the owner is what makes this test mean anything: it is the
    only way to get past the revoked grant and reach the trigger. Without it,
    "append-only" would rest entirely on a GRANT statement, and a grant is one
    ALTER away from gone. The two mechanisms are independent on purpose, and
    each is asserted against the role that can actually reach it.
    """
    # The guard is a row-level trigger, so an empty table would pass vacuously.
    #
    # This used to `assert rows` and stop. That was honest as far as it went and
    # it is why the parametrised list could only ever be four names: five of the
    # thirteen append-only tables are empty in a freshly seeded database, so
    # widening the list turned a silent gap into five red tests.
    #
    # "The condition under test is absent" is not a reason to skip and not a
    # reason to fail — it is a reason to manufacture it. A disposable row is
    # written inside a transaction that is rolled back, so the assertion is the
    # same on every table whether or not the seed happens to populate it.
    with owner_engine.connect() as reader:
        key = _a_primary_key_column(reader, table)

    for statement in (f"UPDATE {table} SET {key} = {key}", f"DELETE FROM {table}"):
        conn = owner_engine.connect()
        transaction = conn.begin()
        try:
            _a_disposable_row(conn, table)
            with pytest.raises(DBAPIError, match="append-only"):
                conn.execute(text(statement))
        finally:
            transaction.rollback()
            conn.close()
