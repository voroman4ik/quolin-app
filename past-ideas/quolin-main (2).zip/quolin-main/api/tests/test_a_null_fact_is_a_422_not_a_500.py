"""A client fact that is present but null must not read as a broken pack.

F6. `POST /v1/clients` accepts `knowledge_assessed: true` with
`knowledge_date: null`. The CSV importer refuses exactly that combination, so
the same book loaded two ways gives two different answers about whether it is
valid.

What happens next is the finding. `build_snapshot` derives
`knowledge_assessed_days_ago` from a date that is not there, the DSL evaluates
`None <= 730`, Python raises `TypeError`, the engine turns it into `PackError` —
and DSL v2's missing-data referral does not catch it, because as far as the
engine is concerned the field is present. The caller gets a 500 whose text
blames the rule pack for a fact the API accepted.

Three things are wrong there and only one of them is a patch:

* **A 500.** An unhandled exception on the endpoint the whole product exists
  for, from a record the API itself said was fine.
* **The blame.** It names the pack, so the first move is to open the rule
  content, which is correct and has nothing wrong with it.
* **The semantics.** What *should* a present-but-null field do — refer as
  `DATA_MISSING` under DSL v2, or be refused at the door as the importer already
  refuses it? That is a question about what a determination means, not about
  exception handling, and it is recorded as decision 3 in docs/spec-changes.md.

This closes the first two. `PackError` maps to 422 on both interactive paths,
saying the determination could not be made from the facts on file. The client
row is still accepted, the importer still refuses it, and the two still
disagree — deliberately, until the decision is taken.
"""

from __future__ import annotations

from datetime import date

import pytest
from conftest import reset_rate_limit_for_tests
from fastapi.testclient import TestClient

from app import passwords, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import ApiClient, Client
from tests.conftest import DEMO_TENANT, OPERATOR_EMAIL, sign_in

ACTOR = "apc_bulk_sweep"

#: Assessed, with no date. The exact pair the importer refuses and the API takes.
HOLLOW_CLIENT = "null-knowledge-date-probe"

CREDENTIAL = "apc_null_fact_probe"
SECRET = "an integration secret, not a real one"


@pytest.fixture(scope="module")
def hollow_client() -> str:
    """A client whose knowledge assessment has no date.

    Written directly rather than through the API, so this file tests the
    determination rather than re-testing whether the endpoint accepts it —
    `test_the_api_still_accepts_what_the_importer_refuses` does that separately,
    and is the reason this row is reachable at all.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        setup = SessionLocal()
        try:
            row = setup.get(Client, HOLLOW_CLIENT)
            if row is None:
                setup.add(
                    Client(
                        id=HOLLOW_CLIENT,
                        name="Assessed On No Particular Day",
                        scenario="sterling",
                        jurisdiction="AU",
                        dob=date(1988, 7, 7),
                        client_category="retail",
                        knowledge_assessed=True,
                        knowledge_date=None,
                        loss_capacity_band=4,
                        vulnerability_flag=False,
                        assessable_portfolio_cents=200_000_00,
                        prior_crypto_purchases=3,
                        structural_acks=[],
                        default_trade_amount_cents=1_000_00,
                    )
                )
                setup.commit()
        finally:
            setup.close()
    return HOLLOW_CLIENT


@pytest.fixture
def credential() -> str:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            row = owner.get(ApiClient, CREDENTIAL)
            if row is None:
                owner.add(
                    ApiClient(
                        id=CREDENTIAL,
                        label="Null fact probe",
                        secret_hash=passwords.hash_password(SECRET, email=CREDENTIAL),
                        roles=["operator", "viewer"],
                        status="active",
                        created_by="test",
                    )
                )
            else:
                row.secret_hash = passwords.hash_password(SECRET, email=CREDENTIAL)
                row.roles = ["operator", "viewer"]
                row.status = "active"
            owner.commit()
    finally:
        owner.close()
    return CREDENTIAL


def test_the_console_path_answers_422_rather_than_500(hollow_client) -> None:
    """`POST /evaluate`, which is what the workbench calls."""
    with TestClient(app) as client:
        sign_in(client, OPERATOR_EMAIL)
        res = client.post(
            "/evaluate", json={"client_id": hollow_client, "asset_id": "BTC"}
        )

    assert res.status_code != 500, (
        f"a client record the API accepted produced a 500: {res.text}"
    )
    assert res.status_code == 422, res.text


def test_the_integration_path_answers_422_rather_than_500(
    hollow_client, credential
) -> None:
    """`POST /v1/evaluations`, which is what a customer's systems call."""

    reset_rate_limit_for_tests()
    machine = TestClient(app)
    token = machine.post(
        "/v1/oauth/token",
        json={
            "grant_type": "client_credentials",
            "client_id": credential,
            "client_secret": SECRET,
        },
    ).json()["access_token"]

    res = machine.post(
        "/v1/evaluations",
        headers={"Authorization": f"Bearer {token}"},
        json={"client_id": hollow_client, "asset_id": "BTC"},
    )

    assert res.status_code != 500, (
        f"a client record the API accepted produced a 500: {res.text}"
    )
    assert res.status_code == 422, res.text


def test_the_refusal_does_not_blame_the_rule_content(hollow_client) -> None:
    """Where somebody is sent first is most of what an error message does.

    The old message named the pack, so the first move was to open rule content
    that is correct. What is actually wrong is the client record.
    """
    with TestClient(app) as client:
        sign_in(client, OPERATOR_EMAIL)
        res = client.post(
            "/evaluate", json={"client_id": hollow_client, "asset_id": "BTC"}
        )

    body = res.text.lower()
    assert "client" in body or "facts" in body, (
        f"the refusal does not point at the client record: {res.text}"
    )


def test_no_determination_was_recorded(hollow_client) -> None:
    """A refusal is not a determination, so the chain gains nothing."""
    from sqlalchemy import select

    from app.models import Decision

    with TestClient(app) as client:
        sign_in(client, OPERATOR_EMAIL)
        client.post("/evaluate", json={"client_id": hollow_client, "asset_id": "BTC"})

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            recorded = list(
                session.scalars(
                    select(Decision).where(Decision.client_id == hollow_client)
                )
            )
        finally:
            session.close()

    assert recorded == [], "a determination was recorded for an unusable record"


def test_an_ordinary_client_still_evaluates() -> None:
    """The control: 422 must not have become the answer for everybody."""
    with TestClient(app) as client:
        sign_in(client, OPERATOR_EMAIL)
        res = client.post(
            "/evaluate", json={"client_id": "margaret-wu", "asset_id": "BTC"}
        )
    assert res.status_code == 200, res.text


def test_the_two_intake_paths_still_disagree(hollow_client) -> None:
    """The residual, asserted so it is visible rather than assumed closed.

    The importer refuses `knowledge_assessed` with no date; the API accepts it.
    This pack maps the resulting failure to 422 and does not resolve which of
    the two is right — that is decision 3, and changing either one is a
    semantics change or an API contract change rather than a patch.
    """
    header = (
        "id,scenario,name,dob,client_category,knowledge_assessed,knowledge_date,"
        "loss_capacity_band,vulnerability_flag,assessable_portfolio_cents,"
        "prior_crypto_purchases,structural_acks,default_trade_amount_cents,"
        "jurisdiction,residency,domicile"
    )
    row = (
        "null-knowledge-via-csv,sterling,Csv Hollow,1988-07-07,retail,true,,"
        "4,false,20000000,3,,100000,AU,,"
    )

    with TestClient(app) as operator:
        sign_in(operator, OPERATOR_EMAIL)
        refused = operator.post(
            "/import/clients", json={"csv_text": f"{header}\n{row}\n", "commit": False}
        )

    assert refused.status_code == 200, refused.text
    body = refused.json()
    assert not body["ok"], (
        "the importer now accepts a knowledge assessment with no date, which "
        "means decision 3 has been taken — update this test to match it"
    )
