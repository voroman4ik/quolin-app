"""One-time codes, checked against the standards that define them.

`app/totp.py` is written out rather than imported, and this is the file that
earns that decision. Everything below is a number published in RFC 4226 or RFC
6238 — not a value produced by running our own code and pasting the result,
which is the failure mode that makes a hand-written cipher look tested. If this
suite is green, the implementation agrees with the document every authenticator
app was also written from.

The two RFCs use different seeds and a different digit count from the product,
which is the reason `code_at` takes `digits` and `algorithm` at all.
"""

from __future__ import annotations

import base64

import pytest

from app import totp

#: RFC 4226 appendix D and RFC 6238 appendix B both use the ASCII string
#: "12345678901234567890" as the shared secret. The RFCs print it as hex; this
#: is the same twenty bytes, base32-encoded the way a real credential is stored.
RFC_SEED_SHA1 = base64.b32encode(b"12345678901234567890").decode().rstrip("=")

#: RFC 6238's SHA-256 and SHA-512 vectors extend the same ASCII pattern to the
#: hash function's block size rather than repeating the twenty bytes — an
#: erratum that caught several early implementations, including ones that
#: passed the SHA-1 vectors and failed in the field against apps that had not.
RFC_SEED_SHA256 = base64.b32encode(b"12345678901234567890123456789012").decode().rstrip("=")
RFC_SEED_SHA512 = (
    base64.b32encode(
        b"1234567890123456789012345678901234567890123456789012345678901234"
    )
    .decode()
    .rstrip("=")
)

#: RFC 4226 appendix D, table 1: HOTP values for counters 0 through 9.
RFC4226_VECTORS = [
    (0, "755224"),
    (1, "287082"),
    (2, "359152"),
    (3, "969429"),
    (4, "338314"),
    (5, "254676"),
    (6, "287922"),
    (7, "162583"),
    (8, "399871"),
    (9, "520489"),
]

#: RFC 6238 appendix B: eight-digit values at six moments, for three hash
#: functions. The times are seconds since the epoch, and 20000000000 is past
#: the 32-bit rollover on purpose — an implementation that packed the counter
#: into four bytes rather than eight passes every earlier row and fails this one.
RFC6238_VECTORS = [
    (59, "sha1", RFC_SEED_SHA1, "94287082"),
    (59, "sha256", RFC_SEED_SHA256, "46119246"),
    (59, "sha512", RFC_SEED_SHA512, "90693936"),
    (1111111109, "sha1", RFC_SEED_SHA1, "07081804"),
    (1111111109, "sha256", RFC_SEED_SHA256, "68084774"),
    (1111111109, "sha512", RFC_SEED_SHA512, "25091201"),
    (1111111111, "sha1", RFC_SEED_SHA1, "14050471"),
    (1111111111, "sha256", RFC_SEED_SHA256, "67062674"),
    (1111111111, "sha512", RFC_SEED_SHA512, "99943326"),
    (1234567890, "sha1", RFC_SEED_SHA1, "89005924"),
    (1234567890, "sha256", RFC_SEED_SHA256, "91819424"),
    (1234567890, "sha512", RFC_SEED_SHA512, "93441116"),
    (2000000000, "sha1", RFC_SEED_SHA1, "69279037"),
    (2000000000, "sha256", RFC_SEED_SHA256, "90698825"),
    (2000000000, "sha512", RFC_SEED_SHA512, "38618901"),
    (20000000000, "sha1", RFC_SEED_SHA1, "65353130"),
    (20000000000, "sha256", RFC_SEED_SHA256, "77737706"),
    (20000000000, "sha512", RFC_SEED_SHA512, "47863826"),
]


@pytest.mark.parametrize("counter,expected", RFC4226_VECTORS)
def test_rfc4226_counter_vectors(counter: int, expected: str) -> None:
    """The truncation rule, pinned.

    Driven through `code_at` with a period of one second, so the counter and
    the timestamp are the same number and the same code path the product uses
    is the one under test — a separate route into `_hotp` would leave the
    conversion from time to counter unchecked, which is where RFC 6238 adds
    everything it adds.
    """
    assert totp.code_at(RFC_SEED_SHA1, counter, period=1) == expected


@pytest.mark.parametrize("at,algorithm,seed,expected", RFC6238_VECTORS)
def test_rfc6238_time_vectors(at: int, algorithm: str, seed: str, expected: str) -> None:
    assert totp.code_at(seed, at, digits=8, algorithm=algorithm) == expected


def test_the_product_default_is_what_an_authenticator_app_expects() -> None:
    """Six digits, SHA-1, thirty seconds.

    Not a matter of taste. Every mainstream authenticator app assumes these and
    most ignore the parameters in the provisioning URI, so a server that quietly
    used SHA-256 would issue a QR code that scans cleanly and then never
    matches — a failure that looks like the user's fault.
    """
    assert totp.DIGITS == 6
    assert totp.PERIOD == 30
    assert len(totp.code_at(RFC_SEED_SHA1, 59)) == 6
    assert totp.code_at(RFC_SEED_SHA1, 59) == "287082"


# ------------------------------------------------------------- verification --


def test_a_code_verifies_within_the_window_and_not_outside_it(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The production window, pinned against the environment.

    `QUOLIN_TOTP_WINDOW_STEPS` can widen `SKEW_STEPS` on a laptop, and a
    developer who exported it for a demo should not then watch this file fail.
    What the standard says is one thing and what a local knob says is another;
    this asserts the first. The knob is
    `test_the_totp_window_is_a_local_knob_only.py`.
    """
    monkeypatch.setattr(totp, "SKEW_STEPS", totp.SKEW_STEPS_DEFAULT)
    now = 1_700_000_000
    code = totp.code_at(RFC_SEED_SHA1, now)

    assert totp.verify(RFC_SEED_SHA1, code, at=now) == now // totp.PERIOD
    # One step either side, which is the stated tolerance.
    assert totp.verify(RFC_SEED_SHA1, code, at=now + totp.PERIOD) is not None
    assert totp.verify(RFC_SEED_SHA1, code, at=now - totp.PERIOD) is not None
    # Two steps away is not.
    assert totp.verify(RFC_SEED_SHA1, code, at=now + 2 * totp.PERIOD) is None
    assert totp.verify(RFC_SEED_SHA1, code, at=now - 2 * totp.PERIOD) is None


def test_a_spent_code_is_refused_even_though_it_still_computes() -> None:
    """The replay guard, which is the difference between a factor and a token.

    A code is valid for its whole window, so without this a code read over a
    shoulder — or captured by anything sitting between the browser and the
    server — is usable for up to ninety seconds. The arithmetic still says yes;
    what says no is the counter the last successful verification stored.
    """
    now = 1_700_000_000
    code = totp.code_at(RFC_SEED_SHA1, now)

    step = totp.verify(RFC_SEED_SHA1, code, at=now)
    assert step is not None

    assert totp.verify(RFC_SEED_SHA1, code, at=now, after_counter=step) is None, (
        "the same code was accepted twice"
    )
    # And so is anything older, not merely the exact code that was spent.
    older = totp.code_at(RFC_SEED_SHA1, now - totp.PERIOD)
    assert totp.verify(RFC_SEED_SHA1, older, at=now, after_counter=step) is None


def test_rubbish_is_refused_rather_than_raising() -> None:
    """Every one of these is a login attempt, not a programming error.

    The handler should be able to pass whatever arrived in the request body
    straight in. A generator that raised on a non-numeric string would turn a
    typo into a 500 and a stack trace into a log line an attacker can provoke
    at will.
    """
    now = 1_700_000_000
    for presented in ["", "   ", "abcdef", "12345", "1234567", "12 34 56", None]:
        assert totp.verify(RFC_SEED_SHA1, presented or "", at=now) is None


# ------------------------------------------------------------------ secrets --


def test_a_new_secret_is_the_length_the_standard_asks_for() -> None:
    secret = totp.new_secret()
    assert "=" not in secret, "padding in a secret that goes into an otpauth URI"
    assert len(totp.decode(secret)) == totp.SECRET_BYTES
    assert totp.new_secret() != secret, "two enrolments produced the same secret"


def test_a_secret_survives_being_retyped_by_a_human() -> None:
    """Apps display the secret in spaced lowercase groups; that is the same key."""
    secret = totp.new_secret()
    spaced = " ".join(secret[i : i + 4] for i in range(0, len(secret), 4)).lower()
    assert totp.decode(spaced) == totp.decode(secret)


def test_the_provisioning_uri_names_the_parameters_it_was_generated_with() -> None:
    uri = totp.provisioning_uri("ABCDEFGHIJKLMNOP", account="alice@example.com")
    assert uri.startswith("otpauth://totp/Quolin:alice%40example.com?")
    assert "secret=ABCDEFGHIJKLMNOP" in uri
    assert f"digits={totp.DIGITS}" in uri
    assert f"period={totp.PERIOD}" in uri
    assert "algorithm=SHA1" in uri
