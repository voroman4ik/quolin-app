"""Rule B: a test asserts something, and the sweep that produced this rule.

H3 in the Gate A close. `test_an_ordinary_hash_mismatch_still_reads_as_one`
asserted that a *clean* chain verifies and carries no reason code — worth
asserting, and not what the name said. The `HASH_MISMATCH` ⁄
`UNDECRYPTABLE_SNAPSHOT` distinction its name promised was tested in a different
file, and would have gone on reading as covered here if that had ever stopped
being true.

**A misleading test name is worse than a missing test**, because a missing test
is visible in a review and a misleading one is a false confidence signal: a
reviewer reading the list of names counts it as covered and moves on. The name
is fixed and the distinction is now asserted where the name is —
`test_the_chain_verifier_fails_loudly_under_tamper.py` — and this file is what
was learned on the way.

**What this rule can and cannot do, stated rather than implied.**

It cannot read a name and a body and decide whether the one describes the other.
That is a reading exercise, and the reading was done: the sweep behind this file
walked every test in the suite for the mechanical half of the failure, and the
manual half is recorded in `docs/spec-changes.md` with what it found.

What it can do is refuse the shape that makes the failure total — **a test that
asserts nothing at all**. A test with no assertion passes for any behaviour
whatsoever, so its name is the only claim it makes and the claim is unbacked by
construction. That is enforceable, and it is enforced here.

A test may satisfy this through a helper in its own module: `_assert_refused` in
`test_oidc.py` is the assertion, written once because eight tests make the same
one about eight different malformed tokens, and inlining it would be worse. The
helper is followed one level, which is as far as this kind of indirection ever
goes in this suite and further than a rule people route around would reach.

The allow-list is for the remaining case: a test whose refusal is performed by
the code under test raising. Each entry says which call does the refusing. It is
short on purpose — a long allow-list is this rule not being enforced, which is
`test_no_test_reads_source.py`'s own note about Rule A.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

TESTS = Path(__file__).resolve().parent

#: Tests whose refusal is a call that raises, and the call that does it.
#:
#: A test of the form `check(Pack.from_body(...))` for every shipped pack is a
#: real assertion — `check` raises on a pack that does not validate — and
#: wrapping it in `assert check(...) is None` would be noise asserting less.
EXEMPT: dict[str, str] = {
    "test_dsl.py::test_the_shipped_packs_all_pass_check": (
        "`check` raises on a pack that does not validate; the loop is the "
        "assertion, once per shipped pack"
    ),
    "test_rbac.py::test_every_route_names_the_roles_that_may_call_it": (
        "`rbac.check_every_route_is_classified` raises on an unclassified "
        "route — the same call `lifespan` makes, so the API refuses to boot on "
        "what this refuses to pass"
    ),
    "test_mfa_enforcement.py::test_the_action_check_passes_once_the_factor_is_real": (
        "`mfa.assert_second_factor` raises `MfaRequired`; the positive case is "
        "the absence of that, and `assert None is None` would assert less"
    ),
    "test_webhook_targets_cannot_reach_inside.py"
    "::test_an_ordinary_customer_endpoint_is_accepted": (
        "`webhooks.validate_target` raises on a refused target; this is the "
        "half that proves the check refuses the attack and not the product"
    ),
    "test_watch_role.py::test_the_watch_role_can_record_what_it_found": (
        "the three statements are the assertion — Postgres raises on a denied "
        "INSERT, UPDATE or DELETE, which is what a privilege test can check"
    ),
    "test_artefacts_are_regenerable_and_deterministic.py"
    "::test_an_empty_hash_may_still_be_filled_in": (
        "the UPDATE is the assertion: `artefacts` is append-only by trigger and "
        "raises unless filling an empty hash is genuinely permitted"
    ),
}


def _asserts(node: ast.AST) -> bool:
    """Whether this subtree makes an assertion of any kind.

    `assert`, `pytest.raises` and `pytest.fail` all count; so does
    `with pytest.raises(...)`, which is the form every refusal in this suite is
    written in, and so does a bare `raise AssertionError(...)` — which is how a
    test asserts something about a structure it has to walk, and is an assertion
    by any reading.
    """
    for child in ast.walk(node):
        if isinstance(child, ast.Assert):
            return True
        if isinstance(child, ast.Attribute) and child.attr in ("raises", "fail"):
            return True
        if isinstance(child, ast.Raise):
            named = child.exc
            if isinstance(named, ast.Call):
                named = named.func
            if isinstance(named, ast.Name) and named.id == "AssertionError":
                return True
    return False


def _module_helpers(tree: ast.Module) -> dict[str, bool]:
    """Every module-level function, and whether it asserts."""
    return {
        node.name: _asserts(node)
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }


def _calls(node: ast.AST) -> set[str]:
    """Every plain function name this subtree calls."""
    found: set[str] = set()
    for child in ast.walk(node):
        if isinstance(child, ast.Call) and isinstance(child.func, ast.Name):
            found.add(child.func.id)
    return found


def _cases() -> list[tuple[str, bool]]:
    """Every test function in the suite, and whether it asserts anything."""
    out: list[tuple[str, bool]] = []
    for path in sorted(TESTS.glob("test_*.py")):
        tree = ast.parse(path.read_text(), filename=str(path))
        helpers = _module_helpers(tree)
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            if not node.name.startswith("test_"):
                continue
            asserts = _asserts(node) or any(
                helpers.get(name, False) for name in _calls(node)
            )
            out.append((f"{path.name}::{node.name}", asserts))
    return out


CASES = _cases()


def test_the_sweep_found_the_suite():
    """A scan of nothing is not a clean scan — `scripts/guard_lib.sh`'s rule.

    The number is a floor rather than a count: it moves every time somebody adds
    a test, and what it is here to catch is this file finding twelve when the
    suite holds eighteen hundred, which is how a meta-check reports a pass on a
    tree it never read.
    """
    assert len(CASES) > 1000, (
        f"this rule examined {len(CASES)} test functions, which is not the size "
        "of this suite. It is pointed at the wrong place."
    )


@pytest.mark.parametrize("name,asserts", CASES, ids=[name for name, _ in CASES])
def test_every_test_asserts_something(name: str, asserts: bool):
    """The mechanical half of H3, and the whole of what a rule can check.

    A test with no assertion passes whatever the code does. Its name is then the
    only claim it makes, and the name is backed by nothing — which is the
    failure H3 named, in its most complete form.
    """
    if name in EXEMPT:
        return
    assert asserts, (
        f"{name} asserts nothing. It passes for any behaviour at all, so its "
        "name is the only claim it makes and nothing holds the code to it. "
        "Assert the thing the name says, or — if the refusal is a call that "
        "raises — add it to EXEMPT with the call that does the refusing."
    )


def test_the_exemptions_still_exist():
    """The other half of every allow-list. An entry naming a test nobody has any
    more is an entry that stops being reviewed, and the next person adds theirs
    beside it."""
    names = {name for name, _ in CASES}
    missing = sorted(set(EXEMPT) - names)
    assert not missing, (
        f"EXEMPT names tests that no longer exist: {missing}. An allow-list "
        "nobody prunes is an allow-list nobody reads."
    )
