"""§3.2: the person who writes a rule change is not the person who attests to it.

The Gate A audit's first finding. `pack_drafts` recorded `signed_by`,
`signed_by_user_id` and `signed_at` and **no author field at all** — so the
separation could be neither enforced nor evidenced, and `test_lifecycle.py`
asserted the opposite in as many words: it created a draft as one account,
signed it as the same account, and called that the ordinary path.

`drafts.publish` already refused a publisher who signed, and that is a different
check. Publication is the second pair of eyes on a **signature**; this is the
second pair of eyes on the **content**. A publisher who did not sign still
cannot check rule content they never read — what they can check is that a named
specialist attested to it. When the specialist is also the author, the review
chain is one person long and the two signatures that follow are agreeing with a
claim nobody independent ever examined.

**The narrow escape hatch, and why it exists.** A firm with one specialist for a
regime would otherwise be unable to change its rules at all. The failure mode of
a rule nobody can satisfy is not compliance — it is the specialist writing the
draft and a colleague signing it having read nothing, which is the same
single-reader review with a second name on it and reads as correct. So an author
may sign their own draft provided another `pack_signatory` for **that regime**
has recorded an independent read first.

**Both layers, deliberately.** `drafts.sign` refuses, and
`pack_drafts_signature_is_independent` refuses. `drafts.py` is a file somebody
can edit; a CHECK constraint is not, and `test_the_database_refuses_it_too`
reaches past Python entirely to prove it.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from conftest import (
    DEMO_TENANT,
    reset_rate_limit_for_tests,
    the_bytes_on_the_row,
    what_this_client_reads,
)
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError

from app import identity, tenancy
from app.db import OwnerSessionLocal
from app.models import PackDraft, User
from app.watch import drafts
from app.watch.lifecycle import content_hash

#: Far enough out that nothing published here is ever the pack in force.
FAR_FUTURE = 3650

#: The three people this file needs, and the point is which grants they hold.
AUTHOR_EMAIL = "sod.author@quolin.example"
REVIEWER_EMAIL = "sod.reviewer@quolin.example"
#: A signatory, and for a regime that is not this draft's. The independence a
#: second review provides is worth nothing without the competence — somebody
#: qualified in Singapore reading an Australian rule change is a second reader
#: and not a second reviewer.
ELSEWHERE_EMAIL = "sod.elsewhere@quolin.example"
#: Somebody with no signatory grant at all.
BYSTANDER_EMAIL = "sod.bystander@quolin.example"


def _person(email: str, *roles: tuple[str, str]) -> str:
    """A user holding exactly the `(role, jurisdiction)` pairs named."""
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            user = identity.find_by_email(owner, email)
            if user is None:
                user = identity.create_user(owner, email=email, display_name=email)
            held = {(g.role, g.jurisdiction) for g in identity.roles_for(owner, user.id)}
            for role, jurisdiction in roles:
                if (role, jurisdiction) in held:
                    continue
                identity.grant_role(
                    owner,
                    user_id=user.id,
                    role=role,
                    jurisdiction=jurisdiction,
                    granted_by="test",
                    qualification_ref="[illustrative — no engagement in place]",
                )
            owner.commit()
            return str(user.id)
    finally:
        owner.close()


@pytest.fixture(scope="module")
def cast() -> dict[str, str]:
    """The people, and the point is which grants each of them holds.

    The author holds `operator` **as well as** `pack_signatory`, and that pairing
    is the finding's reachable shape over HTTP: `POST /watch/drafts` is an
    operator's act and signing is a signatory's, so a bare signatory cannot cut
    a draft through the API at all. A specialist who authors content in the
    workbench and signs it holds both — which is the S5 gate item's own
    description of the workflow, and therefore not a corner case.
    """
    return {
        "author": _person(AUTHOR_EMAIL, ("pack_signatory", "AU"), ("operator", "")),
        "reviewer": _person(REVIEWER_EMAIL, ("pack_signatory", "AU")),
        "elsewhere": _person(ELSEWHERE_EMAIL, ("pack_signatory", "SG")),
        "bystander": _person(BYSTANDER_EMAIL),
    }


def _a_draft(session, *, title: str) -> PackDraft:
    return drafts.create(
        session,
        jurisdiction="AU",
        on=date.today(),
        effective_from=date.today() + timedelta(days=FAR_FUTURE),
        title=title,
        rationale="Written by tests/test_a_signature_is_not_the_authors_own.py",
        author="The Author",
    )


# ------------------------------------------------------- authorship is recorded --


def test_a_draft_records_who_wrote_it(session, cast):
    """The fact the table did not hold, which is why nothing could enforce it.

    Recorded from the ambient scope rather than from a parameter, so a caller
    cannot record one person's authorship against another person's session —
    the rule `sign` has always applied to signatures.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(cast["author"]):
        draft = _a_draft(session, title="Authorship is recorded")
        session.flush()
        assert draft.created_by_user_id == cast["author"]
        assert draft.created_by == "The Author"
        session.rollback()


def test_a_draft_with_nobody_behind_it_is_refused(session):
    """An author is required, for the reason a signatory's name is.

    "Drafted by ''" reads as a gate that was passed. A caller with nobody in
    scope has to say what non-human thing is doing the writing.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with pytest.raises(ValueError, match="needs an author"):
            _a_draft(session, title="Nobody wrote this")
        session.rollback()


def test_nobody_can_record_somebody_elses_authorship(session, cast):
    """A person naming a colleague as the author of what they wrote.

    Refused for the same reason `SignRequest` carries no `signatory` field: the
    entire value of the record is that it names the account that acted.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(cast["author"]):
        with pytest.raises(ValueError, match="authorship against another"):
            drafts.create(
                session,
                jurisdiction="AU",
                on=date.today(),
                effective_from=date.today() + timedelta(days=FAR_FUTURE),
                title="Somebody else's work",
                rationale="Written by a test.",
                author="The Reviewer",
                author_user_id=cast["reviewer"],
            )
        session.rollback()


# ----------------------------------------------------- the signature is refused --


def test_the_author_cannot_sign_their_own_draft(session, cast):
    """The finding itself. Refused in Python, and nothing is written."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(cast["author"]):
        draft = _a_draft(session, title="Signed by its own author")
        session.flush()

        with pytest.raises(drafts.SelfAuthoredSignature) as raised:
            drafts.sign(
                session,
                draft.id,
                signatory="The Author",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )

        assert draft.signed_by_user_id is None
        assert draft.status == drafts.DRAFT
        assert "somebody other than its author" in str(raised.value)
        session.rollback()


def test_the_database_refuses_it_too(session, cast):
    """Past Python entirely, which is the half a guard in a file cannot give.

    `drafts.sign` is the rule written down and a CHECK constraint is the rule
    enforced. The two are the pattern the append-only tables use — a trigger
    *and* a revoked grant — and for the same reason: the one that can be edited
    is the one written in Python.

    Written as the schema owner, which is the strongest actor this system has.
    A CHECK constraint binds it exactly as it binds everybody else.

    **Which constraint refuses it is not this test's business, and it used to
    be.** This asserted `pack_drafts_signature_is_independent` by name, and B1
    added a second constraint over the same columns — a self-signature with no
    reviewer violates both, and Postgres reports whichever it evaluates first.
    That is an implementation detail of the server, so the assertion is against
    `drafts.LEGACY_CONSTRAINTS`: the same tuple `refusal_for_a_violating_row`
    maps to a typed 409, so a constraint renamed in a migration and not there
    fails here *and* stops being mapped, rather than only the second.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(cast["author"]):
        draft = _a_draft(session, title="Refused by the server")
        session.commit()
        draft_id = int(draft.id)

    owner = OwnerSessionLocal()
    try:
        with pytest.raises(IntegrityError) as raised:
            owner.execute(
                text(
                    "UPDATE pack_drafts SET signed_by_user_id = created_by_user_id, "
                    "signed_by = 'The Author', signed_at = now() WHERE id = :id"
                ),
                {"id": draft_id},
            )
            owner.flush()
        refused_by = [c for c in drafts.LEGACY_CONSTRAINTS if c in str(raised.value)]
        assert refused_by, (
            "the write was refused by something other than the separation-of-"
            f"duties constraints: {raised.value}"
        )
    finally:
        owner.rollback()
        owner.close()


def test_a_signature_from_anybody_else_is_the_ordinary_path(session, cast):
    """Two people, and nothing to arrange. This is what §3.2 asks for."""
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Two people")
        with tenancy.acting_as_user(cast["reviewer"]):
            signed = drafts.sign(
                session,
                draft.id,
                signatory="The Reviewer",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
        session.flush()

        assert signed.status == drafts.SIGNED
        assert signed.signed_by_user_id == cast["reviewer"]
        assert signed.created_by_user_id == cast["author"]
        # And no second review was needed, because there were already two
        # people. A column populated on every row would make the ones that
        # actually needed it invisible.
        assert signed.second_reviewer_user_id is None
        session.rollback()


# ------------------------------------------------------- the independent review --


def test_an_author_may_sign_once_somebody_independent_has_read_it(session, cast):
    """The escape hatch working, and all three identities on the record.

    A compliance officer asked who authored this rule change, who attested to
    it, and who made that attestation independent must be able to answer from
    the row — which is what the finding means by "without manual
    reconciliation".
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Reviewed by somebody independent")
            session.flush()
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
                note="Read it.",
            )
        with tenancy.acting_as_user(cast["author"]):
            signed = drafts.sign(
                session,
                draft.id,
                signatory="The Author",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
        session.flush()

        assert signed.status == drafts.SIGNED
        assert signed.created_by_user_id == cast["author"]
        assert signed.signed_by_user_id == cast["author"]
        assert signed.second_reviewer_user_id == cast["reviewer"]
        assert signed.second_reviewed_at is not None

        view = drafts.view(signed)
        assert view["created_by"] == "The Author"
        assert view["second_reviewer"] == "The Reviewer"
        assert view["signed_by_its_author"] is True
        session.rollback()


def test_the_author_cannot_be_their_own_second_reviewer(session, cast):
    """Which would make the escape hatch a checkbox the author ticks."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(cast["author"]):
        draft = _a_draft(session, title="Reviewed by its author")
        session.flush()
        with pytest.raises(drafts.NotIndependent):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Author",
                reviewed_content_hash=content_hash(draft.body),
            )
        session.rollback()


def test_a_second_reviewer_needs_the_grant_for_this_regime(session, cast):
    """Competence to attest for one regime is not competence to attest for
    another — the same bar the signature is held to, because this stands in for
    the independence a second signature would have provided."""
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Reviewed by the wrong regime")
            session.flush()
        for who in ("elsewhere", "bystander"):
            with tenancy.acting_as_user(cast[who]):
                with pytest.raises(drafts.NotQualifiedToReview):
                    drafts.record_second_review(
                        session,
                        draft.id,
                        reviewer_name="Somebody",
                        reviewed_content_hash=content_hash(draft.body),
                    )
        session.rollback()


def test_a_review_cannot_be_added_to_content_already_signed(session, cast):
    """A justification assembled after the act is not a review.

    Reachable only through this function, because the transition table already
    refuses every move out of SIGNED but PUBLISHED — this is the record of the
    same rule at the layer a caller touches.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Reviewed afterwards")
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.sign(
                session,
                draft.id,
                signatory="The Reviewer",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
            session.flush()
            with pytest.raises(drafts.AlreadyResolved):
                drafts.record_second_review(
                    session,
                    draft.id,
                    reviewer_name="The Reviewer",
                    reviewed_content_hash=content_hash(draft.body),
                )
        session.rollback()


def test_a_withdrawn_qualification_stops_the_authors_own_signature(session, cast):
    """The reviewer's grant is re-read at signature time, not trusted from the row.

    Recorded facts are kept as they were claimed — that is what
    `signed_qualification_ref` is for. But this row is not a record of what
    somebody attested to; it is a *permission* the author is leaning on, and a
    permission that has been withdrawn is withdrawn.
    """
    revoked = _person("sod.revoked@quolin.example", ("pack_signatory", "AU"))

    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Reviewer's grant withdrawn")
            session.flush()
        with tenancy.acting_as_user(revoked):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="Since Revoked",
                reviewed_content_hash=content_hash(draft.body),
            )
        session.commit()
        draft_id = int(draft.id)

    # Revocation deletes the row — see `main.revoke_role`, and `access_review`
    # and `roles_for` both read it that way. Done here rather than through the
    # endpoint because what is under test is `sign`, not the administration
    # screen, which has its own file.
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            for grant in identity.roles_for(owner, revoked):
                owner.delete(grant)
            owner.commit()
    finally:
        owner.close()

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(cast["author"]):
        session.rollback()
        with pytest.raises(drafts.NotQualifiedToReview):
            drafts.sign(
                session,
                draft_id,
                signatory="The Author",
                signed_content_hash=the_bytes_on_the_row(session, draft_id),
            )
        session.rollback()


# ------------------------------------------------------------- the watch service --


def test_a_watch_authored_draft_records_the_service_as_its_author(session):
    """Which is exactly the case where the human signature has to be independent.

    Nothing human read the gazette, assembled the change or checked it against
    the regime. Recording a person here would be the one fabrication this whole
    mechanism exists to make impossible, so it records the service — a value
    shaped like neither a person (`usr_…`) nor a machine credential (`apc_…`).
    """
    with tenancy.acting_as(DEMO_TENANT):
        draft = drafts.create(
            session,
            jurisdiction="AU",
            on=date.today(),
            effective_from=date.today() + timedelta(days=FAR_FUTURE),
            title="Cut by the sweep",
            rationale="Written by a test.",
            author=drafts.WATCH_SERVICE_NAME,
            author_user_id=drafts.WATCH_SERVICE,
        )
        session.flush()
        assert draft.created_by_user_id == drafts.WATCH_SERVICE
        assert not draft.created_by_user_id.startswith(("usr_", "apc_"))
        session.rollback()


def test_a_watch_authored_draft_still_needs_a_human_signature(session, cast):
    """The gate the watch service exists behind, unchanged by any of this.

    A human signs it — the service cannot — and publication then needs a second
    person, which is `SelfReview`. What this asserts is that recording the
    service as author does not accidentally satisfy anything: the draft is still
    inert until somebody named signs it, and a signature with nobody behind it
    is still unpublishable.
    """
    with tenancy.acting_as(DEMO_TENANT):
        draft = drafts.create(
            session,
            jurisdiction="AU",
            on=date.today(),
            effective_from=date.today() + timedelta(days=FAR_FUTURE),
            title="Cut by the sweep, signed by nobody",
            rationale="Written by a test.",
            author=drafts.WATCH_SERVICE_NAME,
            author_user_id=drafts.WATCH_SERVICE,
        )
        session.flush()

        # Signed with nobody in scope: allowed, because a null signer is not the
        # author — and refused at publication, because there is no second pair
        # of eyes for an unattributed signature to be.
        drafts.sign(
            session,
            draft.id,
            signatory="Somebody Unattributed",
            signed_content_hash=the_bytes_on_the_row(session, draft),
        )
        session.flush()
        assert draft.signed_by_user_id is None

        with tenancy.acting_as_user(cast["reviewer"]):
            with pytest.raises(drafts.SelfReview):
                drafts.publish(
                    session,
                    draft.id,
                    published_content_hash=the_bytes_on_the_row(session, draft),
                )
        session.rollback()

    # And a human signature on the same kind of content is accepted, because the
    # service is not a person any signatory could be. A second draft rather than
    # the same one: the rollback above discarded it, which is the refusal
    # working — nothing was written.
    with tenancy.acting_as(DEMO_TENANT):
        another = drafts.create(
            session,
            jurisdiction="AU",
            on=date.today(),
            effective_from=date.today() + timedelta(days=FAR_FUTURE),
            title="Cut by the sweep, signed by a person",
            rationale="Written by a test.",
            author=drafts.WATCH_SERVICE_NAME,
            author_user_id=drafts.WATCH_SERVICE,
        )
        session.flush()
        with tenancy.acting_as_user(cast["author"]):
            signed = drafts.sign(
                session,
                another.id,
                signatory="The Author",
                signed_content_hash=the_bytes_on_the_row(session, another),
            )
        session.flush()
        assert signed.signed_by_user_id == cast["author"]
        session.rollback()


# ------------------------------------------------ what a published pack carries --


def test_the_published_body_names_its_author(session, cast):
    """The artefact provenance half of the finding.

    A compliance officer reads the document, not our transition log. `signed_by`
    alone cannot show that the person attesting to a rule change is somebody
    other than the person who proposed it — so the bytes that travel with the
    content carry both, and the independent reviewer where there was one.
    """
    from app.engine import Pack

    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="What the document says")
            session.flush()
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
            )
        with tenancy.acting_as_user(cast["author"]):
            drafts.sign(
                session,
                draft.id,
                signatory="The Author",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
        session.flush()

        # The body as `publish` would write it, without publishing: publication
        # needs two platform publishers and is proved elsewhere. What is under
        # test here is which names the bytes carry.
        body = dict(draft.body)
        body["signed_by"] = draft.signed_by
        body["drafted_by"] = draft.created_by
        body["second_reviewer"] = draft.second_reviewer

        pack = Pack.from_body(body)
        assert pack.drafted_by == "The Author"
        assert pack.second_reviewer == "The Reviewer"
        assert pack.signed_by == "The Author"
        session.rollback()


def test_a_pack_published_before_any_of_this_reads_as_not_recorded(session):
    """Empty, not "nobody". Every pack on file predates migration 0049 and has
    no honest value to carry; the artefact prints the row only where there is
    one, so a document about older content does not acquire a blank line
    claiming it had no author."""
    from app.engine import Pack

    owner = OwnerSessionLocal()
    try:
        row = owner.scalars(
            select(User).where(User.email == "aoife.brennan@quolin.example")
        ).one()
        assert row is not None  # the seed is present; the pack check follows
    finally:
        owner.close()

    pack = Pack.from_body(
        {
            "pack_id": "AU",
            "version": 1,
            "effective_from": "2026-01-01",
            "thresholds": {},
            "asset_classes": {},
            "rules": [],
            "signed_by": "Somebody",
        }
    )
    assert pack.drafted_by == ""
    assert pack.second_reviewer == ""


# ------------------------------------------------------------ through the API --


def _signatory_client(email: str):
    """A signatory signed in over HTTP, with a current second-factor code.

    Signing and reviewing both demand a second factor and a fresh credential —
    an unattended screen must not be able to supply either the attestation or
    the independence that lets one through.
    """
    from conftest import SEED_PASSWORD
    from fastapi.testclient import TestClient

    from app import totp
    from app.main import app
    from app.models import MfaCredential

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            user = identity.find_by_email(owner, email)
            assert user is not None
            identity.set_password(owner, user, SEED_PASSWORD)
            credential = owner.scalars(
                select(MfaCredential).where(MfaCredential.user_id == user.id)
            ).first()
            if credential is None:
                credential, _ = identity.enrol_totp(owner, user, label="test")
                owner.flush()
                identity.confirm_totp(
                    owner, credential, totp.code_at(str(credential.secret))
                )
            credential.last_used_counter = 0
            owner.commit()
            code = totp.code_at(str(credential.secret))
    finally:
        owner.close()

    client = TestClient(app)
    client.__enter__()
    res = client.post(
        "/auth/login", json={"email": email, "password": SEED_PASSWORD, "code": code}
    )
    assert res.status_code == 200, res.text
    return client


def test_the_route_refuses_a_self_authored_signature_and_admits_a_reviewed_one(cast):
    """The whole thing over HTTP, which is the only path a workbench has.

    Cut as a signatory, refused when the same person signs it, admitted once a
    second signatory has recorded an independent read — and the draft view then
    names all three, which is what "without manual reconciliation" means.
    """

    reset_rate_limit_for_tests()
    author = _signatory_client(AUTHOR_EMAIL)
    try:
        cut = author.post(
            "/watch/drafts",
            json={
                "jurisdiction": "AU",
                "effective_from": (
                    date.today() + timedelta(days=FAR_FUTURE)
                ).isoformat(),
                "title": "Through the API",
                "rationale": "Written by a test.",
            },
        )
        assert cut.status_code == 200, cut.text
        draft = cut.json()
        draft_id = int(draft["id"])
        assert draft["created_by_user_id"] == cast["author"]

        refused = author.post(
            f"/watch/drafts/{draft_id}/sign",
            json={
                "note": "Mine.",
                "signed_content_hash": what_this_client_reads(author, draft_id),
            },
        )
        assert refused.status_code == 409, refused.text
        assert "somebody other than its author" in refused.json()["detail"]

        reviewer = _signatory_client(REVIEWER_EMAIL)
        try:
            # F1. The reviewer reads the draft, then approves the bytes that
            # read returned. Sending the hash back is what a client does; a
            # client that could omit it would be approving whatever the row
            # happens to say when its POST lands.
            read = reviewer.get(f"/watch/drafts/{draft_id}")
            assert read.status_code == 200, read.text
            reviewed = reviewer.post(
                f"/watch/drafts/{draft_id}/second-review",
                json={
                    "note": "Read it.",
                    "reviewed_content_hash": read.json()["current_content_hash"],
                },
            )
            assert reviewed.status_code == 200, reviewed.text
            assert reviewed.json()["second_reviewer_user_id"] == cast["reviewer"]
        finally:
            reviewer.__exit__(None, None, None)

        signed = author.post(
            f"/watch/drafts/{draft_id}/sign",
            json={
                "note": "Mine.",
                "signed_content_hash": what_this_client_reads(author, draft_id),
            },
        )
        assert signed.status_code == 200, signed.text

        view = signed.json()
        assert view["created_by_user_id"] == cast["author"]
        assert view["signed_by_user_id"] == cast["author"]
        assert view["second_reviewer_user_id"] == cast["reviewer"]
        assert view["signed_by_its_author"] is True
    finally:
        author.__exit__(None, None, None)


def test_a_second_review_from_the_wrong_regime_is_refused_at_the_door(cast):
    """403 rather than 409: the caller's own grant is what is wrong here, and an
    administrator can fix it. On `sign` the same condition is 409, because there
    the caller is qualified and the draft is the problem."""

    reset_rate_limit_for_tests()
    author = _signatory_client(AUTHOR_EMAIL)
    try:
        cut = author.post(
            "/watch/drafts",
            json={
                "jurisdiction": "AU",
                "effective_from": (
                    date.today() + timedelta(days=FAR_FUTURE)
                ).isoformat(),
                "title": "Reviewed from the wrong regime",
                "rationale": "Written by a test.",
            },
        )
        assert cut.status_code == 200, cut.text
        draft_id = int(cut.json()["id"])

        elsewhere = _signatory_client(ELSEWHERE_EMAIL)
        try:
            read = elsewhere.get(f"/watch/drafts/{draft_id}")
            assert read.status_code == 200, read.text
            refused = elsewhere.post(
                f"/watch/drafts/{draft_id}/second-review",
                json={
                    "note": "Looked.",
                    "reviewed_content_hash": read.json()["current_content_hash"],
                },
            )
            # 403 and not 422: the hash is right and the grant is wrong, which
            # is the distinction this test is about. F1's field must not be able
            # to change which refusal a caller meets.
            assert refused.status_code == 403, refused.text
        finally:
            elsewhere.__exit__(None, None, None)
    finally:
        author.__exit__(None, None, None)
