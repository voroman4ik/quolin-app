"""The one override on the most important refusal, out of reach of a request.

`packs_repo` refuses unreviewed rule content to a firm that acts on its
determinations. There is exactly one exception, and it exists for an honest
reason: the demonstration firm sits at `full` — it has to, or its webhooks and
referrals go quiet and the demo stops being a demo — and it runs on the shipped
illustrative content.

That exception lived in `tenants.config`, a JSONB column the application role
holds `UPDATE` on. The grant is deliberate and correct: migration 0012 gave it
so a firm can set its own advance policy through the product. What it also gave,
unintentionally, was a request path to the single flag that turns off the rule
the execution plan says cannot be waived. Any code path that rewrites `config`
— today, or the one somebody writes next quarter — carries the permit with it.

So the permit moves to a column of its own with no application grant at all. The
`config` grant stays exactly as it was, because the advance policy is genuinely
a firm's own decision, and the two things were only ever in the same place by
accident of storage.

The refusal is unchanged. What changes is who can lift it: an owner, by
migration or by a database session, and nothing that serves HTTP.
"""

from __future__ import annotations

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError

from app import packs_repo, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.models import Tenant
from tests.conftest import DEMO_TENANT

PERMIT_COLUMN = "illustrative_content_permitted"


def test_the_permit_is_a_column_of_its_own() -> None:
    """Not a key in a JSON blob somebody else may rewrite."""
    assert hasattr(Tenant, PERMIT_COLUMN), (
        "the permit is not a column on `tenants`; it cannot be protected by a "
        "grant while it lives inside `config`"
    )


def test_the_application_role_cannot_set_the_permit() -> None:
    """The finding, as a test. Refused by Postgres, not by application code."""
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            with pytest.raises(DBAPIError) as refused:
                session.execute(
                    text(
                        f"UPDATE tenants SET {PERMIT_COLUMN} = true WHERE id = :id"
                    ),
                    {"id": DEMO_TENANT},
                )
                session.commit()
            session.rollback()
        finally:
            session.close()

    message = str(refused.value).lower()
    assert "permission denied" in message or "privilege" in message, (
        f"the application role was refused for the wrong reason: {refused.value}"
    )


def test_the_application_role_can_still_set_the_advance_policy() -> None:
    """The grant that was there for a reason stays.

    A firm setting its own change-control policy is the product working, and
    revoking `UPDATE (config)` to fix the permit would have taken that with it.
    """
    # R2 §8.3. This used to commit and stop, so it asserted that the write did
    # not *raise* — which is a weaker claim than that it landed, and exactly the
    # claim that stays true if a policy silently discards the row. The value is
    # read back through a second session, because the first one's identity map
    # would answer from memory and prove nothing about what Postgres kept.
    chosen = "auto"
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            tenant = session.get(Tenant, DEMO_TENANT)
            before = dict(tenant.config or {})
            original = before.get("advance_policy", "pinned")
            chosen = "auto" if original != "auto" else "pinned"
            tenant.config = {**before, "advance_policy": chosen}
            session.commit()
        finally:
            session.close()

    try:
        with tenancy.acting_as(DEMO_TENANT):
            with SessionLocal() as fresh:
                stored = (fresh.get(Tenant, DEMO_TENANT).config or {}).get(
                    "advance_policy"
                )
        assert stored == chosen, (
            f"the application role's write did not land: advance_policy is "
            f"{stored!r}, not {chosen!r}"
        )
    finally:
        # Put it back. `tenants.config` is shared with every other test in the
        # run, and `advance_policy` decides which pack version governs the demo
        # firm — leaving it flipped would move determinations in other files.
        with tenancy.acting_as(DEMO_TENANT):
            with SessionLocal() as restore:
                row = restore.get(Tenant, DEMO_TENANT)
                row.config = {**(row.config or {}), "advance_policy": original}
                restore.commit()


def test_writing_the_old_config_key_does_not_lift_the_refusal() -> None:
    """The key must be *dead*, not merely relocated.

    A migration that added a column and left the old key readable would have
    moved the flag without closing the path — `_may_use_unreviewed` would still
    have honoured whatever a request wrote into `config`.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as("neighbour"):
            tenant = owner.get(Tenant, "neighbour")
            assert tenant is not None
            tenant.config = {**(tenant.config or {}), PERMIT_COLUMN: True}
            setattr(tenant, PERMIT_COLUMN, False)
            tenant.stage = "full"
            owner.commit()
    finally:
        owner.close()

    with tenancy.acting_as("neighbour"):
        session = SessionLocal()
        try:
            tenant = session.get(Tenant, "neighbour")
            assert tenant.config.get(PERMIT_COLUMN) is True, "the fixture did not take"
            assert packs_repo._may_use_unreviewed(session) is False, (
                "the old JSON key still lifts the refusal. Moving the flag to a "
                "column protects nothing if the key it moved from is still read."
            )
        finally:
            session.close()


def test_the_permit_still_works_when_an_owner_sets_it() -> None:
    """The exception has to keep existing, or the demo stops working."""
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as("neighbour"):
            tenant = owner.get(Tenant, "neighbour")
            setattr(tenant, PERMIT_COLUMN, True)
            tenant.stage = "full"
            owner.commit()
    finally:
        owner.close()

    try:
        with tenancy.acting_as("neighbour"):
            session = SessionLocal()
            try:
                assert packs_repo._may_use_unreviewed(session) is True
            finally:
                session.close()
    finally:
        owner = OwnerSessionLocal()
        try:
            with tenancy.acting_as("neighbour"):
                tenant = owner.get(Tenant, "neighbour")
                setattr(tenant, PERMIT_COLUMN, False)
                tenant.config = {
                    k: v for k, v in (tenant.config or {}).items() if k != PERMIT_COLUMN
                }
                owner.commit()
        finally:
            owner.close()


def test_the_demonstration_firm_keeps_its_permit() -> None:
    """Backfilled from where it used to live, not silently dropped.

    The demo firm sits at `full` and runs on illustrative content. If the
    migration had added the column without carrying the existing value across,
    every screen in the demo would have started refusing.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            tenant = owner.get(Tenant, DEMO_TENANT)
            assert getattr(tenant, PERMIT_COLUMN) is True, (
                "the demonstration firm lost its permit in the move"
            )
    finally:
        owner.close()
