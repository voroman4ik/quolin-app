"""A regime watched by hand must never roll up to a clean CURRENT.

§S13's review found that live polling needed a machine-readable feed block and
that exactly one of the nine shipped sources had one. Eight could only ever be
checked by somebody remembering to look, while the currency screen was free to
report every regime as CURRENT — a claim nothing in the system could earn.

Most of those are read as pages now (see `test_source_slas.py`). What remains is
the honest half: a publication a machine genuinely cannot read is declared
MANUAL in pack content, and MANUAL is a *worse* state than CURRENT rather than a
label beside it. Somebody remembering to check is not the same assurance as a
check that happens on its own, and the badge must not say it is.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from app.watch import fetchers, sources

WEEK = 7


def _now() -> datetime:
    return datetime.now(timezone.utc)


def test_a_manual_source_within_cadence_is_manual_not_current():
    """The whole point: the best a manual source can report is MANUAL."""
    state = sources.freshness(
        _now() - timedelta(days=1),
        WEEK,
        _now(),
        polling_status=fetchers.MANUAL,
    )
    assert state == sources.MANUAL


def test_an_automatic_source_within_cadence_is_still_current():
    """The line between enforcing the distinction and downgrading everything."""
    state = sources.freshness(_now() - timedelta(days=1), WEEK, _now())
    assert state == sources.CURRENT


def test_being_manual_does_not_excuse_being_unverified():
    """A source nobody has looked at for a month is stale either way.

    MANUAL caps how good a source can look. It must not become a place to hide:
    if the whole point is that a person checks it, a person not checking it is
    exactly the failure worth showing.
    """
    assert (
        sources.freshness(
            _now() - timedelta(days=WEEK * 3),
            WEEK,
            _now(),
            polling_status=fetchers.MANUAL,
        )
        == sources.STALE
    )
    assert (
        sources.freshness(
            _now() - timedelta(days=WEEK + 1),
            WEEK,
            _now(),
            polling_status=fetchers.MANUAL,
        )
        == sources.DUE
    )
    assert (
        sources.freshness(None, WEEK, _now(), polling_status=fetchers.MANUAL)
        == sources.STALE
    )


def test_one_manual_source_stops_a_regime_reporting_current():
    """The finding, as the rollup a compliance officer actually reads.

    Worst-wins already existed; MANUAL sitting below CURRENT in the severity
    order is what makes it apply here. A jurisdiction whose sources are all
    checked, one of them by a person, is not in the same condition as one being
    checked automatically — and this is the assertion that stops the screen
    saying it is.
    """
    assert sources.worst([sources.CURRENT, sources.CURRENT]) == sources.CURRENT
    assert sources.worst([sources.CURRENT, sources.MANUAL]) == sources.MANUAL
    assert sources.worst([sources.MANUAL, sources.MANUAL]) == sources.MANUAL


def test_manual_does_not_mask_a_real_problem():
    """It caps the good news; it must not soften the bad."""
    assert sources.worst([sources.MANUAL, sources.DUE]) == sources.DUE
    assert sources.worst([sources.MANUAL, sources.STALE]) == sources.STALE


def test_a_manual_source_is_never_polled():
    """Inventing a poll for a source that needs a login produces a source which
    reports itself checked every hour and notices nothing."""
    assert (
        fetchers.feed_of(
            {
                "id": "s1",
                "url": "https://example.invalid/secure",
                "polling_status": fetchers.MANUAL,
            }
        )
        is None
    )


def test_the_shipped_content_declares_what_cannot_be_polled(session):
    """Content, not configuration: whether a publication has a readable URL is a
    fact about the regime, so the pack says it and the row follows."""
    from datetime import date

    declared = sources.declared(session, date.today())
    assert declared, "no sources declared — run `make seed`"

    statuses = {spec["id"]: spec["polling_status"] for spec in declared}
    assert set(statuses.values()) <= {fetchers.AUTOMATIC, fetchers.MANUAL}

    manual = [source_id for source_id, status in statuses.items() if status == fetchers.MANUAL]
    assert manual, (
        "no source is declared MANUAL. If every publication really is pollable "
        "that is good news, but it should be true rather than unset — the "
        "review's finding was a claim nothing had earned."
    )

    # And every automatic source has something a fetcher could actually read.
    for spec in declared:
        if spec["polling_status"] == fetchers.AUTOMATIC:
            assert spec["feed"] is not None, (
                f"{spec['id']} is declared automatic and has no way to be read. "
                "It is either pollable or MANUAL; there is no third state that "
                "reports itself checked."
            )
