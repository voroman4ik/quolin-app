"""The widened one-time-code window is a laptop setting, and it stays one.

`QUOLIN_TOTP_WINDOW_STEPS` exists for one reason: driving a demo from a
terminal and a browser at the same time, where a thirty-second code expires
between the window you copy it in and the window you paste it in. Every step it
adds is another thirty seconds in which a code read over a shoulder is still
accepted, so it is a downgrade of the second factor and it must never be set
anywhere real.

Three things are asserted here, and the third is the one that matters.

  * The default is unchanged. Absent, mistyped or nonsensical, the module runs
    the production window of one step — `test_totp.py` proves that window is
    the RFC's, and this proves the environment cannot quietly move it.
  * The knob works, in a real subprocess with a real clock, because a knob that
    is documented and does not work is what sends somebody looking for the next
    workaround.
  * Both deployment paths refuse it. Fly by `make deploy-check`, ECS by
    `guard_task_credentials.py`'s allow-list. A comment saying "never set this
    in production" is not a control; these two are.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

from app import totp

REPO = Path(__file__).resolve().parents[2]
API = REPO / "api"

#: Two minutes. Four steps past the production window, well inside a widened
#: one — the exact gap the founder in the bug report kept falling into.
STALE_SECONDS = 120


def _skew_with(value: str | None) -> int:
    """`_skew_steps_from_env` with the variable set, unset, or set to rubbish."""
    previous = os.environ.get(totp.WINDOW_ENV)
    if value is None:
        os.environ.pop(totp.WINDOW_ENV, None)
    else:
        os.environ[totp.WINDOW_ENV] = value
    try:
        return totp._skew_steps_from_env()
    finally:
        if previous is None:
            os.environ.pop(totp.WINDOW_ENV, None)
        else:
            os.environ[totp.WINDOW_ENV] = previous


# ------------------------------------------------------------- the default --


def test_the_default_window_is_the_production_one() -> None:
    assert totp.SKEW_STEPS_DEFAULT == 1
    assert _skew_with(None) == 1
    assert _skew_with("") == 1
    assert _skew_with("   ") == 1


@pytest.mark.parametrize("rubbish", ["ten", "1.5", "-1", "-100", "0x2", "true"])
def test_a_value_that_is_not_a_window_falls_back_to_the_safe_one(rubbish: str) -> None:
    """Fail closed, and do not fail to start.

    A negative would make `range` empty and refuse every code, which is safe and
    unusable; a typo would otherwise be silently accepted as something. Both
    land on the production default, and the module logs which happened.
    """
    assert _skew_with(rubbish) == totp.SKEW_STEPS_DEFAULT


def test_the_window_is_capped_so_one_attempt_stays_one_attempt() -> None:
    """`verify` walks every step, so the window is also a work multiplier."""
    assert _skew_with(str(totp.MAX_SKEW_STEPS + 1)) == totp.MAX_SKEW_STEPS
    assert _skew_with("100000") == totp.MAX_SKEW_STEPS


def test_a_two_minute_old_code_is_refused_at_the_default(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(totp, "SKEW_STEPS", totp.SKEW_STEPS_DEFAULT)
    secret = totp.new_secret()
    now = 1_700_000_000
    stale = totp.code_at(secret, now - STALE_SECONDS)

    assert totp.verify(secret, stale, at=now) is None


# ------------------------------------------------------------- the knob ----


def test_a_two_minute_old_code_validates_with_the_window_widened() -> None:
    """In a subprocess, so the environment read itself is what is under test.

    Monkeypatching `SKEW_STEPS` would prove the arithmetic and skip the part
    that has ever been wrong — the variable being read at all, under the name
    the documentation gives. The clock is the real one for the same reason.
    """
    script = f"""
import time
from app import totp

assert totp.SKEW_STEPS == 10, totp.SKEW_STEPS

secret = totp.new_secret()
stale = totp.code_at(secret, time.time() - {STALE_SECONDS})
step = totp.verify(secret, stale)
assert step is not None, "a two-minute-old code was refused with the window widened"
print("ok")
"""
    result = subprocess.run(
        [sys.executable, "-c", script],
        cwd=API,
        capture_output=True,
        text=True,
        env={**os.environ, totp.WINDOW_ENV: "10"},
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_the_same_code_is_refused_in_the_same_subprocess_without_the_variable() -> None:
    """The other half of the pair: widening is what changed the outcome."""
    script = f"""
import time
from app import totp

assert totp.SKEW_STEPS == 1, totp.SKEW_STEPS

secret = totp.new_secret()
stale = totp.code_at(secret, time.time() - {STALE_SECONDS})
assert totp.verify(secret, stale) is None, "a two-minute-old code was accepted at the default"
print("ok")
"""
    env = {k: v for k, v in os.environ.items() if k != totp.WINDOW_ENV}
    result = subprocess.run(
        [sys.executable, "-c", script],
        cwd=API,
        capture_output=True,
        text=True,
        env=env,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


# ------------------------------------------------------------- the guards --


def test_deploy_check_refuses_to_deploy_with_the_window_set() -> None:
    """Fly. Read out of the Makefile, because that is where the control lives.

    Asserted as text rather than by running the target: `deploy-check` needs
    `flyctl` and a login. What can be checked without an account is that the
    recipe contains the refusal, that it is anchored the way the neighbouring
    `DATABASE_URL` check is, and that it is negated — a `grep -q` without the
    leading `!` would refuse every *correct* deployment instead, which is the
    mutation that would otherwise pass review.
    """
    makefile = (REPO / "Makefile").read_text()
    recipe = makefile.split("\ndeploy-check:", 1)[1].split("\ndeploy:", 1)[0]

    assert totp.WINDOW_ENV in recipe, "deploy-check does not mention the TOTP window"
    line = next(
        stripped
        for stripped in (raw.strip() for raw in recipe.splitlines())
        if totp.WINDOW_ENV in stripped and "fly secrets list" in stripped
    )
    assert line.startswith("@!"), "the check is not negated: it would refuse a correct deploy"
    assert f"'^{totp.WINDOW_ENV}[[:space:]]'" in line, "the grep is not anchored"
    assert f"fly secrets unset {totp.WINDOW_ENV}" in recipe, "no remedy is printed"


def test_no_ecs_task_may_hold_the_window_variable() -> None:
    """ECS. The allow-list guard is the control; this pins that it stays one.

    `guard_task_credentials.py` fails on any variable a task holds that is not
    listed for its command, so this needs no check of its own — it needs the
    variable to stay off the list. That is what this asserts, and it is what
    would break if somebody added it there to make a deploy go through.
    """
    sys.path.insert(0, str(REPO))
    from scripts.guard_task_credentials import ALLOWED, COMMON

    assert totp.WINDOW_ENV not in COMMON
    for command, permitted in ALLOWED.items():
        assert totp.WINDOW_ENV not in permitted, (
            f"{totp.WINDOW_ENV} is permitted on the task running {command or 'the API'}; "
            "it is a local development setting and no deployed task may hold it"
        )
