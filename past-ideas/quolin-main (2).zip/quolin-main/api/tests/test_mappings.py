"""A customer's field names becoming ours, and the money conversion that matters.

Two things are under test and the second one carries most of the weight.

**Versioning.** A mapping change can change determinations: if `risk_band` stops
meaning `loss_capacity_band` and starts meaning something else, every decision
after that is made on different facts. So a change is a new version rather than
an edit, and the version is recorded on the run that used it — otherwise
explaining a determination made last March is unanswerable.

**`dollars_to_cents`.** Firms send money in dollars because that is what their
systems hold; we store integer cents because invariant 3 says a determination
must reproduce exactly years later.

The float route fails in the worst possible pattern: `int(float("25000.50") *
100)` is correct, because a half is exactly representable — but
`int(float("19.99") * 100)` is 1998 and `int(float("0.29") * 100)` is 28. It is
right on the amounts somebody checks by hand and wrong on ordinary ones. This is
the single most likely place for invariant 3 to be broken by an integration, and
nothing would say so until a determination was replayed years later.
"""

from __future__ import annotations

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import select

from app import batch, importer, mappings, tenancy
from app.models import Client, ImportRun, IntegrationMapping

ACTOR = "apc_batch_test"


@pytest.fixture(autouse=True)
def clean_up(session):
    yield
    with tenancy.acting_as(DEMO_TENANT):
        session.rollback()
        session.query(Client).filter(Client.id.like("map-%")).delete(
            synchronize_session=False
        )
        session.query(ImportRun).delete(synchronize_session=False)
        session.query(IntegrationMapping).delete(synchronize_session=False)
        session.commit()


# ------------------------------------------------------------- money, exactly --


@pytest.mark.parametrize(
    ("given", "expected"),
    [
        ("25000.50", "2500050"),
        ("25000.5", "2500050"),
        ("25000", "2500000"),
        ("0.01", "1"),
        ("0", "0"),
        ("$25,000.50", "2500050"),
        ("", ""),
    ],
)
def test_dollars_become_cents_exactly(given, expected):
    """The conversion, across the shapes a firm's export actually contains —
    trailing zero or not, thousands separators, a currency symbol, and empty."""
    assert mappings.TRANSFORMS["dollars_to_cents"](given) == expected


@pytest.mark.parametrize(("given", "cents"), [("19.99", "1999"), ("0.29", "29")])
def test_the_float_route_really_would_have_been_wrong(given, cents):
    """The control, on amounts where float genuinely fails.

    Worth pinning precisely, because the first version of this test used
    `25000.50` — and a half is exactly representable in binary, so the float
    route converts it correctly. The values below do not: `int(float("19.99") *
    100)` is 1998 and `int(float("0.29") * 100)` is 28.

    That is the worst way for a conversion to be broken. It is right on the
    amounts somebody would check by hand and wrong on ordinary ones, so nothing
    looks amiss until a determination is replayed years later.
    """
    assert int(float(given) * 100) != int(cents), "float happens to be right here"
    assert mappings.TRANSFORMS["dollars_to_cents"](given) == cents


def test_more_precision_than_cents_is_refused_rather_than_rounded():
    """Rounding somebody's money without telling them is not ours to do — and a
    tenth of a cent means the source is not denominated the way the mapping
    claims, which is worth knowing."""
    with pytest.raises(mappings.MappingError) as raised:
        mappings.TRANSFORMS["dollars_to_cents"]("100.005")
    assert "whole cents" in str(raised.value)


def test_something_that_is_not_an_amount_is_refused():
    with pytest.raises(mappings.MappingError):
        mappings.TRANSFORMS["dollars_to_cents"]("about twenty thousand")


@pytest.mark.parametrize(
    ("given", "expected"),
    [("Y", "true"), ("yes", "true"), ("N", "false"), ("", "false")],
)
def test_yes_and_no_become_booleans(given, expected):
    assert mappings.TRANSFORMS["yes_no_to_boolean"](given) == expected


def test_a_value_that_is_neither_yes_nor_no_is_refused():
    """"maybe" in a boolean column is a data problem the firm should hear about,
    not one we resolve by picking."""
    with pytest.raises(mappings.MappingError):
        mappings.TRANSFORMS["yes_no_to_boolean"]("maybe")


# ------------------------------------------------------------------ versions --


def test_recording_a_mapping_makes_a_new_version_rather_than_editing(session):
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        first = mappings.record(
            session,
            source="clients",
            fields={"risk_band": {"canonical": "loss_capacity_band"}},
            created_by=ACTOR,
        )
        second = mappings.record(
            session,
            source="clients",
            fields={"tolerance": {"canonical": "loss_capacity_band"}},
            created_by=ACTOR,
        )
        session.commit()

    assert first.version == 1
    assert second.version == 2
    with tenancy.acting_as(DEMO_TENANT):
        assert mappings.active(session, "clients").version == 2
        # The old one is still there. A determination made under it has to stay
        # explicable, and an edited row would make that unanswerable.
        assert len(list(session.scalars(select(IntegrationMapping)))) == 2


def test_a_mapping_change_is_an_audited_event(session):
    """Because it can change determinations. A silent edit to the meaning of a
    column is indistinguishable, afterwards, from the engine changing its mind."""
    from app.models import AuditEvent

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        mappings.record(
            session,
            source="clients",
            fields={"risk_band": {"canonical": "loss_capacity_band"}},
            created_by=ACTOR,
        )
        session.commit()
        actions = set(session.scalars(select(AuditEvent.action)))
    assert "integration.mapping.recorded" in actions


def test_a_transform_that_does_not_exist_is_refused_when_the_mapping_is_written(session):
    """Caught when the mapping is authored rather than at 02:00 on the night it
    is first used."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with pytest.raises(mappings.MappingError) as raised:
            mappings.record(
                session,
                source="clients",
                fields={"amount": {"canonical": "x", "transform": "make_it_cents"}},
                created_by=ACTOR,
            )
        session.rollback()
    assert "dollars_to_cents" in str(raised.value), "no list of what is available"


def test_a_mapping_with_no_target_field_is_refused(session):
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        with pytest.raises(mappings.MappingError):
            mappings.record(
                session, source="clients", fields={"risk_band": {}}, created_by=ACTOR
            )
        session.rollback()


# ------------------------------------------------------------- through batch --


def _their_csv() -> bytes:
    """A file in the firm's own words: their column names, their money format."""
    header = [
        "client_ref",
        "scenario",
        "name",
        "dob",
        "client_category",
        "knowledge_assessed",
        "knowledge_date",
        "risk_band",
        "vulnerability_flag",
        "portfolio_dollars",
        "prior_crypto_purchases",
        "structural_acks",
        "default_trade_amount_cents",
    ]
    rows = [
        "map-1,meridian,Their Person,1985-04-02,retail,Y,2026-01-15,3,N,25000.50,2,,500000",
        "map-2,meridian,Second Person,1979-11-30,retail,Y,2026-01-15,4,N,80000.00,5,,500000",
    ]
    return ("\n".join([",".join(header), *rows]) + "\n").encode()


def _full_mapping() -> dict:
    """Every column of theirs that differs from ours, and how it converts."""
    return {
        "client_ref": {"canonical": "id"},
        "risk_band": {"canonical": "loss_capacity_band"},
        "portfolio_dollars": {
            "canonical": "assessable_portfolio_cents",
            "transform": "dollars_to_cents",
        },
        "knowledge_assessed": {
            "canonical": "knowledge_assessed",
            "transform": "yes_no_to_boolean",
        },
        "vulnerability_flag": {
            "canonical": "vulnerability_flag",
            "transform": "yes_no_to_boolean",
        },
    }


def test_a_file_in_the_firms_own_words_loads(session):
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        mappings.record(
            session,
            source="clients",
            fields=_full_mapping(),
            created_by=ACTOR,
        )
        session.commit()

        result = batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="theirs.csv",
            raw=_their_csv(),
        )
        session.commit()

    assert result.status == "completed", result.errors
    assert result.rows_written == 2

    with tenancy.acting_as(DEMO_TENANT):
        session.expire_all()
        row = session.get(Client, "map-1")
        # The conversion that matters: $25,000.50 stored as exactly 2,500,050
        # cents, not 2,500,049.
        assert row.assessable_portfolio_cents == 2_500_050
        assert row.loss_capacity_band == 3
        assert row.knowledge_assessed is True


def test_the_run_records_which_mapping_version_it_used(session):
    """Explaining a determination made last March requires knowing which mapping
    was in force when the book behind it was loaded."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        mappings.record(
            session, source="clients", fields=_full_mapping(), created_by=ACTOR
        )
        session.commit()

        batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="theirs.csv",
            raw=_their_csv(),
        )
        session.commit()
        run = session.scalars(select(ImportRun)).one()
    assert run.mapping_version == 1


def test_a_row_whose_amount_will_not_convert_is_rejected_alone(session):
    """A transform failure is a bad row, and behaves like one: the others load.

    And the error names *their* column, because that is the one in the file
    their operations team is looking at.
    """
    broken = _their_csv().replace(b"25000.50", b"twenty five thousand")

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        mappings.record(
            session,
            source="clients",
            fields=_full_mapping(),
            created_by=ACTOR,
        )
        session.commit()

        result = batch.process(
            session,
            started_by=ACTOR,
            tenant_id=DEMO_TENANT,
            filename="theirs.csv",
            raw=broken,
        )
        session.commit()

    assert result.status == "completed_with_errors"
    assert result.rows_written == 1, "the good row did not load"
    assert len(result.errors) == 1
    assert result.errors[0]["column"] == "portfolio_dollars", "named our column, not theirs"
    assert "v1" in result.errors[0]["message"], "the message does not say which mapping"


def test_a_column_the_mapping_does_not_mention_passes_through(session):
    """A firm that sends fifteen of our column names and two of theirs should
    have to map two, not seventeen."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        mapping = mappings.record(
            session,
            source="clients",
            fields={"client_ref": {"canonical": "id"}},
            created_by=ACTOR,
        )
        session.commit()

    rows, errors = mappings.apply_to_rows(
        mapping, [{"client_ref": "x", "name": "Untouched", "scenario": "meridian"}]
    )
    assert errors == []
    assert rows[0] == {"id": "x", "name": "Untouched", "scenario": "meridian"}


def test_no_mapping_at_all_is_a_supported_state(session):
    """The common one. A firm that sends our column names needs no mapping, and
    an identity mapping would be a row somebody maintains to change nothing."""
    with tenancy.acting_as(DEMO_TENANT):
        assert mappings.active(session, "clients") is None

    rows, errors = mappings.apply_to_rows(None, [{"id": "x"}])
    assert rows == [{"id": "x"}] and errors == []


def test_the_canonical_columns_the_importer_wants_are_the_ones_a_mapping_targets():
    """A mapping that targeted a field the importer has never heard of would be
    a mapping that produces a file rejected for an unrecognised column."""
    targets = {"id", "loss_capacity_band", "assessable_portfolio_cents"}
    assert targets <= set(importer.ALL_COLUMNS)
