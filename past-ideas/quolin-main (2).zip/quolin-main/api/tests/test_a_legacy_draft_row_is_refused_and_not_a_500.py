"""H1: a row written before a constraint meets it, and is refused in words.

Migrations 0049 and 0050 both add their CHECK `NOT VALID`, and both do it for the
same honest reason: this repository's own suite signed self-authored drafts for
thirteen stages, and every second review recorded between the two migrations
named a person and no hash. A validating form would have had to be bought by
rewriting the backfill until nothing violated, which is manufacturing a clean
history.

**`NOT VALID` is not "never checked", and that is the finding.** Postgres
re-checks a CHECK constraint on any UPDATE to the row it touches, and both
signing and publishing update `pack_drafts` — `published_by_user_id`,
`proposed_version`, the status transition. So an old row sitting still is fine
and an old row being *moved* raises.

The Gate A close's audit reported that the publish route does not map
`IntegrityError`. That was partially wrong and is recorded as such:
`IntegrityError` is imported in `main.py` and handled at two sites — the client
CSV import, and `POST …/approve-publication` for `uq_one_approval_each`. Neither
is the publish path and neither is the sign path, so the finding's conclusion
held even though its premise did not: a legacy row reaching publication produced
a 500 and a traceback, which tells an operator neither which draft nor which
rule, and reads as a broken deployment rather than as a refusal.

Both routes map it now, to `PredatesTheConstraint`, which names the draft and the
constraint and points at `docs/runbooks/legacy-draft-rows.md`. Anything else the
transaction can collide on — a duplicate pack version under migration 0031's
UNIQUE — is re-raised untouched, because a handler that swallowed every
`IntegrityError` would turn a genuine collision into a sentence about legacy
rows.

**The row here is manufactured as the schema owner, deliberately.** There is no
way to reach this state through the application any more, which is the point:
the state exists only in databases that predate the constraint, so a test that
produced it legitimately would be a test proving the constraint does not work.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from conftest import (
    DEMO_TENANT,
    SEED_PASSWORD,
    publish_through_the_api,
    reset_rate_limit_for_tests,
)
from fastapi.testclient import TestClient
from sqlalchemy import select, text

from app import identity, tenancy, totp
from app.db import OwnerSessionLocal
from app.main import app
from app.models import MfaCredential, PackDraft
from app.watch import drafts
from app.watch.lifecycle import content_hash

FAR_FUTURE = 3650

AUTHOR_EMAIL = "h1.author@quolin.example"
REVIEWER_EMAIL = "h1.reviewer@quolin.example"


def _person(email: str, *roles: tuple[str, str]) -> str:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            user = identity.find_by_email(owner, email)
            if user is None:
                user = identity.create_user(owner, email=email, display_name=email)
            held = {(g.role, g.jurisdiction) for g in identity.roles_for(owner, user.id)}
            for role, jurisdiction in roles:
                if (role, jurisdiction) in held:
                    continue
                identity.grant_role(
                    owner,
                    user_id=user.id,
                    role=role,
                    jurisdiction=jurisdiction,
                    granted_by="test",
                    qualification_ref="[illustrative — no engagement in place]",
                )
            owner.commit()
            return str(user.id)
    finally:
        owner.close()


@pytest.fixture(scope="module")
def cast() -> dict[str, str]:
    return {
        "author": _person(AUTHOR_EMAIL, ("pack_signatory", "AU"), ("operator", "")),
        "reviewer": _person(REVIEWER_EMAIL, ("pack_signatory", "AU")),
    }


@pytest.fixture
def a_row_from_before_the_constraint(session, cast) -> int:
    """A signed draft whose signer is its author and whose review names no hash.

    Exactly what migration 0049's escape hatch produced and 0050 now refuses: a
    review is recorded, by somebody independent and qualified, and nothing on the
    row says what they read. Written through the owner because the application
    refuses to create it, which is the property under test working.

    The constraint is `NOT VALID`, so the INSERT-time state is accepted; what
    fails is the next UPDATE, which is publication.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = drafts.create(
                session,
                jurisdiction="AU",
                on=date.today(),
                effective_from=date.today() + timedelta(days=FAR_FUTURE),
                title="Signed before the constraint existed",
                rationale="Written by tests/test_a_legacy_draft_row_is_refused_and_not_a_500.py",
                author="The Author",
            )
            session.flush()
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
            )
        session.commit()
        draft_id = int(draft.id)
        # The hash the signature would have recorded. It has to be the *real*
        # one: `publish` re-checks it against the body before anything else
        # (F4, `SignedBytesChanged`), and a row that failed that check would be
        # refused for a reason with nothing to do with this test. A row written
        # under 0049 has a correct `content_hash` and no reviewed hash at all,
        # which is exactly what is built here.
        signed_hash = drafts.content_hash(draft.body)

    owner = OwnerSessionLocal()
    try:
        # The signature, and the reviewed hash removed — which is the state every
        # row written between 0049 and 0050 is in. `ALTER TABLE … NOT VALID`
        # means this UPDATE is not checked against the new constraint only
        # because the constraint is not enforced on rows it was added over; it
        # is checked, and it passes, because the columns it reads are consistent
        # at this instant. What it will not survive is being touched again.
        owner.execute(
            text(
                "ALTER TABLE pack_drafts DROP CONSTRAINT "
                "pack_drafts_self_signature_reviewed_these_bytes"
            )
        )
        owner.execute(
            text(
                "UPDATE pack_drafts SET signed_by_user_id = created_by_user_id, "
                "signed_by = 'The Author', signed_at = now(), status = 'signed', "
                "content_hash = :hash, "
                "second_reviewed_content_hash = NULL WHERE id = :id"
            ),
            {"id": draft_id, "hash": signed_hash},
        )
        owner.execute(
            text(
                """
                ALTER TABLE pack_drafts
                  ADD CONSTRAINT pack_drafts_self_signature_reviewed_these_bytes
                  CHECK (
                    signed_by_user_id IS NULL
                    OR signed_by_user_id <> created_by_user_id
                    OR (
                      second_reviewed_content_hash IS NOT NULL
                      AND content_hash IS NOT NULL
                      AND second_reviewed_content_hash = content_hash
                    )
                  ) NOT VALID
                """
            )
        )
        owner.commit()
    finally:
        owner.close()

    yield draft_id

    # Put the row into a state nothing else trips over — **not** by deleting it.
    # `pack_draft_transitions` is append-only by trigger, so the creation and
    # review of this draft are permanent, and removing the draft while its
    # history stands would leave the history pointing at nothing. That the
    # cleanup cannot be a delete is the append-only property working.
    #
    # The UPDATE below is checked against the constraint and satisfies it — a
    # row moving *into* a legal state is exactly what Postgres permits — so this
    # also asserts, in passing, that the remediation direction is open.
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "UPDATE pack_drafts SET second_reviewed_content_hash = content_hash "
                "WHERE id = :id"
            ),
            {"id": draft_id},
        )
        owner.commit()
    finally:
        owner.close()


def _client(email: str):
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            user = identity.find_by_email(owner, email)
            assert user is not None
            identity.set_password(owner, user, SEED_PASSWORD)
            credential = owner.scalars(
                select(MfaCredential).where(MfaCredential.user_id == user.id)
            ).first()
            if credential is None:
                credential, _ = identity.enrol_totp(owner, user, label="test")
                owner.flush()
                identity.confirm_totp(
                    owner, credential, totp.code_at(str(credential.secret))
                )
            credential.last_used_counter = 0
            owner.commit()
            code = totp.code_at(str(credential.secret))
    finally:
        owner.close()

    client = TestClient(app)
    client.__enter__()
    res = client.post(
        "/auth/login", json={"email": email, "password": SEED_PASSWORD, "code": code}
    )
    assert res.status_code == 200, res.text
    return client


def test_the_row_really_does_violate_the_constraint(a_row_from_before_the_constraint):
    """The premise, asserted rather than assumed.

    If this row ever stopped violating, every assertion below would pass for a
    reason with nothing to do with the mapping under test — the same rule
    `test_the_application_role_can_append_a_row_it_cannot_read_back` applies to
    the chain verifier's forgery.
    """
    draft_id = a_row_from_before_the_constraint
    owner = OwnerSessionLocal()
    try:
        with pytest.raises(Exception) as raised:
            owner.execute(
                text("UPDATE pack_drafts SET signature_note = 'nudge' WHERE id = :id"),
                {"id": draft_id},
            )
            owner.flush()
        assert "pack_drafts_self_signature_reviewed_these_bytes" in str(raised.value)
    finally:
        owner.rollback()
        owner.close()


def test_publishing_a_legacy_row_is_a_refusal_and_not_a_traceback(
    a_row_from_before_the_constraint,
):
    """H1 itself, end to end, through the route a publisher actually uses.

    409 rather than 500, with the draft and the constraint named. The status
    matters: a 500 tells a publisher the deployment is broken and sends them to
    an engineer, and a 409 tells them this draft cannot move and sends them to
    the runbook — which is the difference between an incident and an afternoon.
    """

    reset_rate_limit_for_tests()
    draft_id = a_row_from_before_the_constraint

    clients: list = []

    def _as(email: str):
        client = _client(email)
        clients.append(client)
        return client

    try:
        response = publish_through_the_api(_as, draft_id)
    finally:
        for client in clients:
            client.__exit__(None, None, None)

    assert response.status_code == 409, (
        "publishing a row that predates the constraint answered "
        f"{response.status_code}. A 500 with a traceback names neither the "
        f"draft nor the rule.\n{response.text}"
    )
    detail = response.json()["detail"]
    assert str(draft_id) in detail, f"the refusal does not name the draft: {detail}"
    assert "pack_drafts_self_signature_reviewed_these_bytes" in detail, (
        f"the refusal does not name the constraint: {detail}"
    )
    assert "legacy-draft-rows.md" in detail, (
        f"the refusal does not name the runbook: {detail}"
    )

    # And nothing was published. The refusal happens on a flush inside
    # `drafts.publish`, so a version could have been allocated before it — the
    # rollback in the handler is what makes this true rather than the ordering.
    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row is not None
        assert row.published_pack_id is None
        assert row.status == drafts.SIGNED
    finally:
        owner.close()


def test_the_runbook_the_refusal_names_exists():
    """A refusal that points at a document nobody wrote is a refusal that wastes
    somebody's night. The file is the subject here, not a claim about code, so
    reading it is not Rule A's concern."""
    from pathlib import Path

    runbook = (
        Path(__file__).resolve().parents[2] / "docs" / "runbooks" / "legacy-draft-rows.md"
    )
    assert runbook.exists(), f"{runbook} does not exist"
    text_of = runbook.read_text()
    assert "pack_drafts_self_signature_reviewed_these_bytes" in text_of
    assert "pack_drafts_signature_is_independent" in text_of
    # The remediation, which is the only reason to open it.
    assert "raise a fresh draft" in text_of.lower()
