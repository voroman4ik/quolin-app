"""Findings from a review that contradicted the other two, checked against the code.

Report C was treated as a source of hypotheses rather than findings, because it
disagrees with the two reviews that carry transcripts. Six of its claims turned
out not to describe this codebase. That is worth a test rather than a note: a
claim that is false today can become true next quarter, and "we checked once" is
not a control.

Each test below states the claim, what was found instead, and asserts the thing
that makes the claim false — so if any of them ever becomes true, it fails here
rather than in the next external review.

The claims that *were* real are fixed in their own commits and are not here.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select, text

from app import tenancy
from app.db import SessionLocal
from app.main import app
from app.models import Artefact
from tests.conftest import DEMO_TENANT, OPERATOR_EMAIL, sign_in

REPO = Path(__file__).resolve().parents[2]
API = REPO / "api"
ACTOR = "apc_bulk_sweep"


# ---------------------------------------------------------------- claim 6 --


def test_no_evaluation_path_falls_back_to_the_wall_clock() -> None:
    """Claim: `dsl.py` falls back to `datetime.utcnow()` when `evaluated_at` is
    missing from a snapshot.

    Found: there is no `evaluated_at` field anywhere in the engine, and no call
    to `utcnow` in any of it. The snapshot carries `as_of`, which is a required
    argument to `build_snapshot` and a date rather than a clock reading.

    Asserted rather than recorded, because a wall-clock read inside the engine
    would break replay outright — invariant 2 says the frozen snapshot is the
    only input, and a determination that consulted the clock would reproduce
    differently every time it was replayed.
    """
    offenders = []
    for path in sorted((API / "app" / "engine").rglob("*.py")):
        tree = ast.parse(path.read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.Attribute) and node.attr in ("utcnow", "now", "today"):
                offenders.append(f"{path.relative_to(REPO)}:{node.lineno} .{node.attr}()")
    assert not offenders, (
        "the evaluator reads a clock: " + "; ".join(offenders) + ". A determination "
        "must be a pure function of the pack and the frozen snapshot."
    )


# ---------------------------------------------------------------- claim 7 --


def test_the_concentration_arithmetic_is_integer_throughout() -> None:
    """Claim: `calcs.py` does concentration maths in floating point.

    Found: integer floor division, in a named function whose docstring says why.
    `_no_floats` in the DSL refuses a float operand outright, so a float that
    reached a rule would raise rather than drift.
    """
    from app.engine import calcs

    source = (API / "app" / "engine" / "calcs.py").read_text()
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
            pytest.fail(
                f"calcs.py:{node.lineno} uses true division. Invariant 3: money is "
                "integer cents and proportions integer basis points."
            )

    for name, calc in calcs.registered().items():
        value = calc.fn(existing_cents=333, amount_cents=333, portfolio_cents=1000)
        assert isinstance(value, int) and not isinstance(value, bool), (
            f"{name} returned {value!r}, which is not an integer"
        )


@pytest.mark.parametrize(
    "existing,amount,portfolio,expected",
    (
        # Exactly at the cap. 700 bps of a $10,000 portfolio is $700.
        (0, 700_00, 10_000_00, 700),
        (350_00, 350_00, 10_000_00, 700),
        # One cent either side of it, which is where a float would drift.
        (0, 699_99, 10_000_00, 699),
        (0, 700_01, 10_000_00, 700),
        # A portfolio whose thirds do not divide evenly.
        (0, 1, 3, 3333),
    ),
)
def test_the_boundary_at_seven_hundred_basis_points(
    existing, amount, portfolio, expected
) -> None:
    """The exact edge a concentration cap is compared against.

    Asked for by name in the review. Floor division means the figure is never
    rounded *up* across a limit — a client one cent under the cap is under it,
    which is the direction that refuses rather than admits.
    """
    from app.engine import calcs

    computed = calcs.registered()["post_trade_crypto_bps"].fn(
        existing_cents=existing, amount_cents=amount, portfolio_cents=portfolio
    )
    assert computed == expected, f"{existing}+{amount}/{portfolio} → {computed}"
    assert isinstance(computed, int)


# ---------------------------------------------------------------- claim 8 --


def test_there_is_no_shared_passcode_or_demo_bypass_anywhere() -> None:
    """Claim: `auth.py` holds a hardcoded `_demo_mode_fallback`.

    Found: nothing of the kind. The shared passcode was removed in Stage 2 and
    `scripts/guard_no_shared_passcode.sh` fails CI on its return; this asserts
    the same thing from inside the suite, and names the specific symbol the
    review claimed to have seen.
    """
    import subprocess

    forbidden = ("_demo_mode_fallback", "demo_mode", "DEMO_PASSCODE", "SHARED_PASSCODE")
    source = (API / "app" / "auth.py").read_text()
    for name in forbidden:
        assert name not in source, f"app/auth.py contains {name!r}"

    result = subprocess.run(
        ["bash", "scripts/guard_no_shared_passcode.sh"],
        cwd=REPO,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr


# ---------------------------------------------------------------- claim 5 --


def test_the_watch_sweep_connects_as_the_watch_role() -> None:
    """Claim: the watch service shares the application's database credentials in
    `docker-compose.yml`.

    Found: there is no watch *service* in Compose at all — the sweep runs
    in-process through `make watch-tick`, and it opens `WatchSessionLocal`,
    which is `WATCH_DATABASE_URL` and therefore `quolin_watch`. The Compose API
    container carries all three URLs because it is the API container; the
    deployed topology separates them, and `guard_no_watch_in_engine.sh` check 6
    fails CI if the watch task ever holds a connection string that can write
    packs.

    What is asserted here is the thing that actually matters locally: the sweep
    runs under a role that cannot write rule content.

    **Asserted by running it, not by reading it.** This used to end with

        sweep = (REPO / "scripts" / "watch_tick.py").read_text()
        assert "WatchSessionLocal" in sweep

    which a comment satisfies. FP3-03 is the proof that it needed to: the sweep
    grew a call into `notify_tenants`, which opens the *application* engine, and
    a call into `all_tenant_ids`, which opens the *owner* engine — and this test
    stayed green throughout, because the string `WatchSessionLocal` was still in
    the file.

    The set of engines the sweep actually connects to is in
    `test_the_watch_sweep_runs_in_its_deployed_environment.py`, which runs the
    real entry point in a subprocess with the deployed environment and listens
    on `engine.connect`. Rule A: a test may not read source text to prove
    behaviour.
    """
    from app import db

    assert "quolin_watch" in db.WATCH_DATABASE_URL
    assert db.WatchSessionLocal.kw["bind"] is db.watch_engine


# ---------------------------------------------------------------- claim 4 --


def test_two_tenants_on_one_pooled_connection_never_see_each_other() -> None:
    """Claim: connection state leaks across pooled connections.

    Found: `app.tenant_id` is set with `set_config(..., true)`, which is
    transaction-scoped — Postgres discards it at commit or rollback, so a
    connection returned to the pool carries no trace of who last used it. The
    `begin` hook in `db.py` then sets it again, unconditionally, on every
    transaction; there is no path by which a transaction runs without one.

    Interleaved deliberately on a pool of one, so both sessions are guaranteed
    to be the same physical connection. That is the condition the claim needs
    and the one an ordinary test would never produce.
    """
    from sqlalchemy import create_engine, event
    from sqlalchemy.orm import sessionmaker

    from app.db import APP_DATABASE_URL, _bind_tenant_to_transaction

    engine = create_engine(APP_DATABASE_URL, future=True, pool_size=1, max_overflow=0)
    event.listen(engine, "begin", _bind_tenant_to_transaction)
    maker = sessionmaker(bind=engine, future=True)

    try:
        seen = []
        for tenant in (DEMO_TENANT, "neighbour", DEMO_TENANT, "neighbour"):
            with tenancy.acting_as(tenant):
                session = maker()
                try:
                    bound = session.execute(
                        text("SELECT current_setting('app.tenant_id', true)")
                    ).scalar()
                    seen.append((tenant, bound))
                finally:
                    session.rollback()
                    session.close()

        for wanted, bound in seen:
            assert bound == wanted, (
                f"a session acting for {wanted!r} ran bound to {bound!r}. On a pool "
                "of one, that is the previous request's tenant surviving the "
                "connection being handed back."
            )

        # And with nothing in scope it is the empty string, not the last value.
        token = tenancy._current.set(None)
        try:
            session = maker()
            try:
                assert (
                    session.execute(
                        text("SELECT current_setting('app.tenant_id', true)")
                    ).scalar()
                    == ""
                )
            finally:
                session.rollback()
                session.close()
        finally:
            tenancy._current.reset(token)
    finally:
        engine.dispose()


# ---------------------------------------------------------------- claim 9 --


def _an_artefact_of_the_demo_firm() -> int:
    """One rendered document, made if the database does not already hold one.

    Rendered rather than skipped-if-absent: a fresh `make seed` writes no
    artefacts, so a test that skipped would quietly stop proving anything the
    first time somebody reseeded — which is how the schema-1 and pre-gate tests
    in this fix-pack were caught doing the same thing.
    """
    from app.artefacts import renderer
    from app.models import Decision

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            existing = session.scalars(
                select(Artefact.id).order_by(Artefact.id.desc()).limit(1)
            ).first()
            if existing is not None:
                return int(existing)
            decision_id = session.scalars(
                select(Decision.id).order_by(Decision.id).limit(1)
            ).one()
            made = renderer.render(session, kind="tmd", decision_id=decision_id)
            session.commit()
            return int(made.id)
        finally:
            session.close()


def test_one_firm_cannot_download_another_firms_document() -> None:
    """Claim: the artefact download route serves a file path without checking
    tenant ownership.

    Found: it does check. `session.get(Artefact, id)` runs under row-level
    security and `artefacts` is tenant-scoped, so the row is invisible to
    another firm and the route answers 404 before any path is read. The file is
    only ever named by a row the caller may see.

    Asserted end to end rather than by reading the handler, because the property
    worth having is "the other firm gets 404", not "there is an if statement".
    """
    artefact_id = _an_artefact_of_the_demo_firm()

    with TestClient(app) as owner_firm:
        sign_in(owner_firm, OPERATOR_EMAIL)
        mine = owner_firm.get(f"/artefacts/{artefact_id}/pdf")
    assert mine.status_code in (200, 410), (
        f"the firm that owns this artefact cannot read it: {mine.status_code}"
    )

    with tenancy.acting_as("neighbour"), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            assert session.get(Artefact, artefact_id) is None, (
                "a neighbouring firm can read another firm's artefact row. The "
                "download route trusts row-level security to have filtered it, "
                "and it has not."
            )
            served = session.execute(
                select(Artefact.pdf_ref).where(Artefact.id == artefact_id)
            ).first()
        finally:
            session.close()
    assert served is None, (
        "the path to another firm's document is readable, which is all the "
        "download route needs to serve it"
    )


# ------------------------------------------------- Report B, claim 10 --


def test_a_snapshot_says_whether_residency_was_supplied_or_assumed() -> None:
    """Report B: a missing source fact becomes a populated derived field before
    the DSL sees it, defeating the missing-data semantics.

    The mechanism is real — `build_snapshot` fills residency and domicile from
    the licensee when the client record does not carry them. The consequence
    feared is not reachable: both columns are `NOT NULL` with a default, no
    shipped pack reads either field, and the fallback is a documented modelling
    choice with its own test in `test_import.py` ("residency and domicile
    default to the licence, not to Australia").

    So the narrow fix is the lineage, not a refusal. Making the engine treat a
    derived value as absent would hard-code a compliance judgement for a field
    no regime has asked about — invariant 1 says which facts matter is content.
    The snapshot now carries the fact and a regime that wants to refer on an
    assumed residency writes that rule.
    """
    from datetime import date as date_type

    from app.engine import build_snapshot
    from app.engine.pack import Pack as EnginePack
    from app.packs_repo import active_rows

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            body = active_rows(session, date_type.today())["AU"].body
        finally:
            session.close()
    pack = EnginePack.from_body(body)

    def snapshot_for(client_extra: dict) -> dict:
        return build_snapshot(
            pack=pack,
            client={
                "id": "c",
                "name": "C",
                "scenario": "meridian",
                "dob": date_type(1985, 6, 1),
                "client_category": "retail",
                "knowledge_assessed": True,
                "knowledge_date": date_type(2026, 1, 1),
                "loss_capacity_band": 3,
                "vulnerability_flag": False,
                "assessable_portfolio_cents": 1_000_000,
                "prior_crypto_purchases": 2,
                "structural_acks": [],
                **client_extra,
            },
            positions={"crypto_value_cents": 0, "source": "fixture"},
            asset={"id": "BTC", "symbol": "BTC", "name": "Bitcoin"},
            amount_cents=1000,
            as_of=date_type(2026, 6, 1),
            licensee_jurisdiction="AU",
        )

    supplied = snapshot_for({"residency": "SG", "domicile": "SG"})
    assert supplied["client"]["residency"] == "SG"
    assert supplied["client"]["residency_source"] == "supplied"
    assert supplied["client"]["domicile_source"] == "supplied"

    assumed = snapshot_for({})
    assert assumed["client"]["residency"] == "AU", (
        "the fallback itself is deliberate and documented; it is not being removed"
    )
    assert assumed["client"]["residency_source"] == "assumed_from_licence", (
        "a determination cannot tell 'the firm said AU' from 'the firm said "
        "nothing and we assumed the licence'"
    )
    assert assumed["client"]["domicile_source"] == "assumed_from_licence"
