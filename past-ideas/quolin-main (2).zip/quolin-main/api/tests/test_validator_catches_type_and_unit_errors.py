"""The three mistakes a non-programmer cannot see, and the validator did not.

A pack is authored by a compliance specialist and reviewed by another one. The
validator exists so the errors of *writing content* — a mistyped threshold, a
renamed reason code — are found by the person writing it rather than by a client
on the phone. It caught every error that names something which does not exist,
and none of the errors where everything named exists and the comparison is
nonsense anyway.

Three constructions loaded clean and evaluated wrongly:

  Q-07  an integer compared `eq` to a boolean threshold. `3 == True` is False
        and `1 == True` is True, in Python, silently.
  Q-08  `{"op": "in", "left": {"const": "com"}, "right": {"const": "complex"}}`
        — substring containment wearing the shape of set membership. It passes,
        for the wrong reason, and the rule reads exactly as if it did not.
  Q-09  a basis-points calc compared to a cents threshold. `calcs.py` has
        recorded a unit on every derived value since it was written, and said
        of it: "today documentation".

None of the three is visible to somebody reading the JSON who does not think in
Python. All three change what a determination says.

**Validator only.** The condition language is unchanged: no new operator, no new
term kind, no new pack field. Units are read from the names that already carry
them — `_bps`, `_cents`, `_days`, `_years` — which is the convention every pack
in this repository already follows and which nothing enforced. SG caps a first
purchase in basis points where AU caps it in cents, so the two are genuinely
different quantities and the suffix is the only thing that ever said so.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

# The function, not the module `engine/validate.py` — `engine/__init__.py`
# re-exports the callable under the same name, so `from app.engine import
# validate` gets one and reaching a constant off it fails with a confusing
# AttributeError about a function.
from app.engine import validate as validate_fn
from app.engine.pack import Pack

PACKS_DIR = Path(__file__).resolve().parents[2] / "packs"


def _pack_with(condition: dict, *, thresholds: dict | None = None) -> Pack:
    """The smallest loadable pack carrying one rule with one condition."""
    body = {
        "pack_id": "AU",
        "version": 99,
        "effective_from": "2026-01-01",
        "effective_to": None,
        "dsl_version": 2,
        "signed_by": "A Test",
        "signed_at": "",
        "content_status": "ILLUSTRATIVE",
        "thresholds": {
            "max_crypto_concentration_bps": 1000,
            "first_exposure_limit_cents": 500000,
            "adult_age_years": 18,
            "knowledge_validity_days": 730,
            "leverage_prohibited_categories": ["retail"],
            "requires_acknowledgement": True,
            **(thresholds or {}),
        },
        "asset_classes": {
            "btc": {"class": "major", "volatility_band": 4, "leverage": False}
        },
        "reason_codes": {"TEST": {"title": "Test", "plain_english": "Test."}},
        "rules": [
            {
                "rule_id": "AU-TEST-01",
                "title": "A rule written by a test",
                "applies_to": {},
                "severity": 2,
                "on_fail": "BLOCK",
                "reason_code": "TEST",
                "predicate": condition,
            }
        ],
    }
    return Pack.from_body(body)


def _faults(condition: dict, *, thresholds: dict | None = None) -> list[str]:
    return validate_fn(_pack_with(condition, thresholds=thresholds))


# ------------------------------------------------- the three that were clean --


def test_an_integer_compared_to_a_boolean_threshold_is_refused() -> None:
    """Q-07. `3 == True` is False and `1 == True` is True, silently.

    A specialist reading this JSON sees a rule saying "the loss capacity band
    equals the acknowledgement requirement", which is meaningless — and got a
    determination out of it anyway, correct for band 1 and wrong for every other
    band.
    """
    faults = _faults(
        {
            "op": "eq",
            "left": {"field": "client.loss_capacity_band"},
            "right": {"threshold": "requires_acknowledgement"},
        }
    )
    assert faults, "an integer compared to a boolean threshold loaded clean"
    assert any("boolean" in f.lower() for f in faults), faults


def test_two_booleans_compared_to_each_other_are_fine() -> None:
    """The rule is about mixing, not about booleans.

    "Has this client been assessed for knowledge" against a pack that says
    assessment is required is a perfectly ordinary rule, and refusing it would
    be refusing the product to fix the defect.
    """
    faults = _faults(
        {
            "op": "eq",
            "left": {"field": "client.knowledge_assessed"},
            "right": {"threshold": "requires_acknowledgement"},
        }
    )
    assert not faults, faults


def test_a_boolean_ordered_against_anything_is_refused() -> None:
    """`False < 1` is True in Python. It is not a thing a regulation says."""
    faults = _faults(
        {
            "op": "gt",
            "left": {"field": "client.vulnerability_flag"},
            "right": {"const": 0},
        }
    )
    assert faults, "a boolean in an ordering comparison loaded clean"
    assert any("boolean" in f.lower() for f in faults), faults


def test_membership_against_something_that_is_not_a_list_is_refused() -> None:
    """Q-08. `'com' in 'complex'` is True, and means nothing anybody intended."""
    faults = _faults(
        {"op": "in", "left": {"const": "com"}, "right": {"const": "complex"}}
    )
    assert faults, "'com' in 'complex' loaded clean"
    assert any("list" in f.lower() for f in faults), faults


def test_membership_against_a_list_threshold_is_fine() -> None:
    """Which is what every real pack does with `in`."""
    faults = _faults(
        {
            "op": "in",
            "left": {"field": "client.client_category"},
            "right": {"threshold": "leverage_prohibited_categories"},
        }
    )
    assert not faults, faults


def test_contains_against_something_that_is_not_a_list_is_refused() -> None:
    """The mirror of the above: `contains` reads its *left* side as the set."""
    faults = _faults(
        {
            "op": "contains",
            "left": {"field": "client.client_category"},
            "right": {"const": "retail"},
        }
    )
    assert faults, "`contains` against a string loaded clean"
    assert any("list" in f.lower() for f in faults), faults


def test_contains_against_a_list_field_is_fine() -> None:
    faults = _faults(
        {
            "op": "contains",
            "left": {"field": "client.structural_acks"},
            "right": {"const": "leverage_risk"},
        }
    )
    assert not faults, faults


def test_a_basis_points_calc_compared_to_a_cents_threshold_is_refused() -> None:
    """Q-09. Two integers, two different quantities, one comparison.

    1000 bps is ten per cent; 1000 cents is ten dollars. The comparison runs,
    produces a verdict, and the verdict is meaningless — and `calcs.py` has
    known the unit of every derived value since it was written.
    """
    faults = _faults(
        {
            "op": "gt",
            "left": {"calc": "post_trade_crypto_bps"},
            "right": {"threshold": "first_exposure_limit_cents"},
        }
    )
    assert faults, "a bps calc compared to a cents threshold loaded clean"
    assert any("unit" in f.lower() or "bps" in f.lower() for f in faults), faults


def test_matching_units_are_fine() -> None:
    faults = _faults(
        {
            "op": "gt",
            "left": {"calc": "post_trade_crypto_bps"},
            "right": {"threshold": "max_crypto_concentration_bps"},
        }
    )
    assert not faults, faults


def test_a_field_in_the_wrong_unit_is_refused_too() -> None:
    """The check is on quantities, not only on calcs.

    `client.age_years` against a days threshold is the same mistake made from
    the other side, and the field names already say so.
    """
    faults = _faults(
        {
            "op": "lt",
            "left": {"field": "client.age_years"},
            "right": {"threshold": "knowledge_validity_days"},
        }
    )
    assert faults, "years compared to days loaded clean"
    assert any("unit" in f.lower() for f in faults), faults


def test_a_quantity_compared_to_a_bare_constant_is_still_allowed() -> None:
    """A constant has no unit and cannot be given one.

    Refusing these would mean no rule could ever compare a calc to a literal,
    which is a real thing packs do. What is checked is a *conflict* between two
    stated units, never the absence of one.
    """
    faults = _faults(
        {"op": "gt", "left": {"calc": "post_trade_crypto_bps"}, "right": {"const": 1000}}
    )
    assert not faults, faults


# ------------------------------------- the three that were already refused --


def test_an_unknown_operator_is_still_refused() -> None:
    faults = _faults(
        {
            "op": "greater_than",
            "left": {"calc": "post_trade_crypto_bps"},
            "right": {"const": 1000},
        }
    )
    assert any("operator" in f for f in faults), faults


def test_an_unknown_threshold_is_still_refused() -> None:
    faults = _faults(
        {
            "op": "gt",
            "left": {"calc": "post_trade_crypto_bps"},
            "right": {"threshold": "max_crypto_concetration_bps"},
        }
    )
    assert any("threshold" in f for f in faults), faults


def test_a_decimal_constant_is_still_refused() -> None:
    faults = _faults(
        {"op": "gt", "left": {"calc": "post_trade_crypto_bps"}, "right": {"const": 10.5}}
    )
    assert any("decimal" in f for f in faults), faults


# ------------------------------------------------------------ the real packs --


@pytest.mark.parametrize("path", sorted(PACKS_DIR.glob("*.json")), ids=lambda p: p.name)
def test_every_shipped_pack_still_validates(path) -> None:
    """Run the corpus after tightening, and report rather than relax.

    If a shipped pack fails here it is a real defect in that pack and the answer
    is to fix the pack. The rules above were chosen so that the conventions
    these packs already follow are the ones that pass — but "chosen so" is not
    evidence, and this is.
    """
    faults = validate_fn(Pack.from_body(json.loads(path.read_text())))
    assert not faults, f"{path.name} no longer validates: {faults}"
