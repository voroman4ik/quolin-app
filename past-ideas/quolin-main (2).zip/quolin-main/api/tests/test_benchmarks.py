"""How fast the engine is, asserted rather than assumed.

The execution document names two numbers: a single evaluation at p99 under 50ms
against a 200-rule pack, and a 100,000 client-asset batch under ten minutes on
one worker. The second pairs with S8 and is measured here by extrapolation from
a real batch rather than by actually running for ten minutes, which is stated in
the test rather than hidden in it.

**Why a budget rather than a comparison against last week.** A benchmark that
compares against a stored baseline fails on somebody's laptop, on a noisy CI
runner, and on the day the runner fleet changes — and a benchmark that cries
wolf is a benchmark somebody deletes. A fixed budget with a wide margin fails
only when something has changed by an order of magnitude, which is the only
change worth failing a build over. The margin is stated in each test so nobody
has to guess how much room there is.

**p99, not the mean.** A determination happens while somebody waits, so the
number that matters is the slow one. A mean of 3ms with a p99 of 400ms is a
system that feels broken to one user in a hundred, and the mean would report it
as healthy.

These are deliberately not `pytest-benchmark`. The dependency buys statistical
machinery this does not need — the assertion is "not catastrophically slower
than it should be", and `time.perf_counter` answers that honestly.
"""

from __future__ import annotations

import copy
import json
import os
import statistics
import time
from pathlib import Path

import pytest

from app.engine import Pack, build_snapshot, evaluate_snapshot

PACKS = Path(__file__).resolve().parents[2] / "packs"

#: The execution document's numbers.
P99_BUDGET_MS = 50.0
BATCH_SIZE = 100_000
BATCH_BUDGET_SECONDS = 600.0

#: How many rules the p99 budget is quoted against.
RULES_IN_A_BIG_PACK = 200

#: Skipped by default outside CI. These take a few seconds and measure the
#: machine as much as the code, so a developer running `pytest` while a build is
#: going on should not get a red suite out of it. CI sets the variable.
BENCHMARKS_ENABLED = os.getenv("QUOLIN_BENCHMARKS", "").strip().lower() in {"1", "true", "yes"}

pytestmark = pytest.mark.skipif(
    not BENCHMARKS_ENABLED,
    reason="benchmarks measure the machine; set QUOLIN_BENCHMARKS=1 to run them",
)


def _big_pack() -> Pack:
    """A real pack grown to 200 rules by repeating its own content.

    Repeated rather than generated, so that what is being measured is the engine
    doing the work it actually does — real predicates, real lookups, real
    provenance — rather than 200 copies of `1 == 1`, which would measure the loop
    and report it as the evaluator.
    """
    body = json.loads((PACKS / "au_v2.json").read_text())
    template = body["rules"]
    grown = []
    while len(grown) < RULES_IN_A_BIG_PACK:
        for rule in template:
            clone = copy.deepcopy(rule)
            clone["rule_id"] = f"{rule['rule_id']}-{len(grown):03d}"
            grown.append(clone)
            if len(grown) >= RULES_IN_A_BIG_PACK:
                break
    body["rules"] = grown
    return Pack.from_body(body)


def _snapshot(pack: Pack) -> dict:
    from datetime import date

    return build_snapshot(
        pack=pack,
        client={
            "id": "bench",
            "name": "Benchmark Client",
            "scenario": "meridian",
            "residency": "AU",
            "domicile": "AU",
            "dob": date(1985, 3, 14),
            "client_category": "retail",
            "knowledge_assessed": True,
            "knowledge_date": date(2026, 1, 1),
            "loss_capacity_band": 3,
            "vulnerability_flag": False,
            "assessable_portfolio_cents": 25_000_000,
            "prior_crypto_purchases": 4,
            "structural_acks": [],
        },
        positions={"crypto_value_cents": 1_000_000},
        asset={"id": "BTC", "symbol": "BTC", "name": "Bitcoin"},
        amount_cents=500_000,
        as_of=date(2026, 6, 1),
        licensee_jurisdiction="AU",
    )


def _timings(pack: Pack, snapshot: dict, runs: int) -> list[float]:
    # A warm-up pass that is not measured. The first evaluation pays for import
    # caches and for the interpreter's first look at these code paths, and
    # including it would put a one-off cost into a percentile.
    evaluate_snapshot(pack, snapshot)

    timings = []
    for _ in range(runs):
        started = time.perf_counter()
        evaluate_snapshot(pack, snapshot)
        timings.append((time.perf_counter() - started) * 1000)
    return sorted(timings)


def test_a_single_evaluation_against_a_two_hundred_rule_pack_is_under_the_budget():
    """The number a screen waits on.

    p99 rather than the mean, because a determination happens while somebody is
    looking at it: a mean of 3ms with a p99 of 400ms is a system that feels
    broken to one user in a hundred and reports itself as healthy.
    """
    pack = _big_pack()
    assert len(pack.rules) == RULES_IN_A_BIG_PACK

    timings = _timings(pack, _snapshot(pack), runs=300)
    p99 = timings[int(len(timings) * 0.99) - 1]

    assert p99 < P99_BUDGET_MS, (
        f"p99 {p99:.1f}ms exceeds the {P99_BUDGET_MS:.0f}ms budget "
        f"(median {statistics.median(timings):.1f}ms, worst {timings[-1]:.1f}ms)"
    )


def test_a_hundred_thousand_evaluations_would_finish_inside_the_batch_budget():
    """Measured on a real sample and extrapolated, and saying so is the point.

    Running the full 100,000 would take minutes of every CI run to re-derive a
    number that scales linearly — the engine holds no state between evaluations,
    which is the property that makes the extrapolation sound and is asserted
    directly below.

    The pack here is the shipped 11-rule one rather than the grown 200-rule one,
    because a bulk run is over a real book against real content. The margin is
    wide on purpose: this fails when something has changed by an order of
    magnitude, not when the runner is busy.
    """
    body = json.loads((PACKS / "au_v2.json").read_text())
    pack = Pack.from_body(body)
    snapshot = _snapshot(pack)

    sample = 2_000
    timings = _timings(pack, snapshot, runs=sample)
    mean_ms = statistics.fmean(timings)
    projected = (mean_ms / 1000) * BATCH_SIZE

    assert projected < BATCH_BUDGET_SECONDS, (
        f"{BATCH_SIZE:,} evaluations project to {projected / 60:.1f} minutes, "
        f"over the {BATCH_BUDGET_SECONDS / 60:.0f}-minute budget "
        f"({mean_ms:.3f}ms each over {sample:,} runs)"
    )


def test_evaluation_time_does_not_grow_with_how_many_have_already_run():
    """The property that makes the extrapolation above honest.

    If the engine accumulated anything between evaluations — a cache that grows,
    a list appended to — a batch would slow down as it went and a projection from
    the first two thousand would be optimistic. The last decile is compared
    against the first, with generous headroom for a runner doing other work.
    """
    pack = Pack.from_body(json.loads((PACKS / "au_v2.json").read_text()))
    snapshot = _snapshot(pack)

    # Unsorted, because the order they ran in is exactly what is being examined.
    evaluate_snapshot(pack, snapshot)
    raw = []
    for _ in range(3_000):
        started = time.perf_counter()
        evaluate_snapshot(pack, snapshot)
        raw.append(time.perf_counter() - started)

    tenth = len(raw) // 10
    first = statistics.fmean(raw[:tenth])
    last = statistics.fmean(raw[-tenth:])

    assert last < first * 3, (
        f"evaluation slowed from {first * 1000:.3f}ms to {last * 1000:.3f}ms over "
        "3,000 runs, which suggests the engine is accumulating state"
    )


def test_a_pack_loads_fast_enough_to_validate_on_every_publish():
    """Validation runs when content enters, so it is on a person's critical path.

    Not a documented budget — one second is simply the point past which somebody
    publishing a draft would wonder whether the button had worked.
    """
    body = json.loads((PACKS / "au_v2.json").read_text())
    from app.engine import check

    started = time.perf_counter()
    for _ in range(100):
        check(Pack.from_body(body))
    elapsed = time.perf_counter() - started

    assert elapsed < 1.0, f"100 pack validations took {elapsed:.2f}s"
