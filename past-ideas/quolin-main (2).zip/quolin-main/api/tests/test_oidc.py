"""Signing in through the firm's identity provider, and every way that must fail.

The positive test here is short because the interesting content is the negatives.
An OIDC client that works is easy; an OIDC client that cannot be talked into
accepting somebody else's token is the entire reason to write one carefully, and
each refusal below is a bypass that has shipped in real software:

* a token signed by a key the provider never published
* `alg: none`, which is a valid JWT with no signature at all
* a `nonce` from a different login, replayed into this one
* an audience belonging to another client of the same provider
* an expired assertion
* a callback with no state cookie, or with a `state` that does not match

And two that are about this product rather than the protocol: a subject with no
account here is refused rather than provisioned, and an unverified email address
is never allowed to select an account.

`stub_idp.py` is the provider, served on a loopback port. It signs real RS256
tokens with a real key pair, so what is under test is `app/oidc.py` making the
same ordinary HTTP requests it would make against WorkOS — not a mock returning
what it was told.
"""

from __future__ import annotations

import time
from urllib.parse import parse_qs, urlparse

import httpx
import pytest
import stub_idp
from conftest import DEMO_TENANT, OPERATOR_EMAIL, reset_rate_limit_for_tests
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import auth, identity, oidc, tenancy
from app.main import app
from app.models import AuditEvent, User, UserIdentity

#: Where the provider sends the browser back to. `testserver` is the host
#: `TestClient` serves the application under, so this is the callback's real
#: address as far as anything in this suite is concerned.
CALLBACK_ORIGIN = "http://testserver"
REDIRECT_URI = f"{CALLBACK_ORIGIN}/auth/oidc/callback"

pytestmark = pytest.mark.usefixtures("stub_provider")


@pytest.fixture(scope="module")
def idp():
    """The provider, running for the length of this module.

    Module-scoped because starting a server and generating two RSA key pairs is
    the expensive part and none of it is per-test state — everything a test
    changes lives on `STUB` and is reset below.
    """
    with stub_idp.serving() as issuer:
        yield issuer


@pytest.fixture
def stub_provider(idp, monkeypatch):
    """Configure this deployment to use the stub, exactly as a real one would.

    Through the environment and nothing else. A deployment turns SSO on by
    setting these four variables, so a test that reached past them would be
    testing an arrangement no deployment can be in.
    """
    monkeypatch.setenv("QUOLIN_OIDC_ISSUER", idp)
    monkeypatch.setenv("QUOLIN_OIDC_CLIENT_ID", stub_idp.CLIENT_ID)
    monkeypatch.setenv("QUOLIN_OIDC_CLIENT_SECRET", stub_idp.CLIENT_SECRET)
    monkeypatch.setenv("QUOLIN_OIDC_REDIRECT_URI", REDIRECT_URI)
    monkeypatch.setenv("QUOLIN_OIDC_POST_LOGIN_URL", "http://localhost:3100/")

    stub_idp.STUB.reset()
    yield stub_idp.STUB


@pytest.fixture
def client():
    """A client that does not follow redirects.

    The whole flow is redirects, and a client that followed them would collapse
    three hops into one assertion about wherever it ended up. Each hop is driven
    by hand instead, which is what makes the intermediate URLs — the
    authorization request, the callback, the landing page — assertable at all.
    """
    reset_rate_limit_for_tests()
    with TestClient(app, follow_redirects=False) as c:
        yield c


@pytest.fixture(autouse=True)
def unlink_after(session):
    """Leave the seeded person exactly as found: no link, and their own name.

    This suite runs against the shared demo database, and both halves of that
    matter. A link left behind would make the next test's "this subject is
    unknown" assertion pass for the wrong reason. A name left behind would be
    worse and quieter — `accept_assertion` treats the provider as the authority
    on what somebody is called, so a test that renamed Dana would rename her for
    every other suite, and the failure would surface somewhere with no apparent
    connection to OIDC.
    """
    user_id, was_called = _seeded_operator(session)
    yield
    # Committed before entering the person's scope, and that is not tidiness.
    # `app.user_id` is bound when a transaction *begins*, so a scope entered
    # part-way through one is a scope the policies never see — the deletes below
    # would match nothing and the rename would be refused, both silently enough
    # to look like cleanup that worked. The same dance `/auth/login` performs,
    # for the same reason.
    session.commit()
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(user_id):
        for row in session.scalars(
            select(UserIdentity).where(
                UserIdentity.user_id == user_id,
                UserIdentity.provider == identity.OIDC_PROVIDER,
            )
        ):
            session.delete(row)
        person = session.get(User, user_id)
        assert person is not None
        person.display_name = was_called
        session.commit()


def _seeded_operator(session) -> tuple[str, str]:
    with tenancy.acting_as(DEMO_TENANT):
        person = identity.find_by_email(session, OPERATOR_EMAIL)
        assert person is not None, "the seeded operator is missing — run `make seed`"
        found = (person.id, person.display_name)
    session.commit()
    return found


# --------------------------------------------------------------- the happy path --


def _consent(location: str) -> str:
    """Follow the redirect to the provider and come back with its answer.

    Standing in for the part a browser does: the user arrives at the provider,
    proves who they are, and is sent back to the redirect URI with a code.
    """
    granted = httpx.get(location, timeout=10)
    assert granted.status_code == 200, granted.text
    return granted.json()["redirect_to"]


def _walk(client) -> httpx.Response:
    """Drive one full sign-in and return the callback's response.

    Three hops, each performed the way the browser would: ask us where to go, ask
    the provider for a code, come back with it. The client's cookie jar carries
    the state cookie between the first hop and the third, which is the mechanism
    under test rather than a convenience.
    """
    start = client.get("/auth/oidc/start")
    assert start.status_code == 307, start.text
    return client.get(_consent(start.headers["location"]).replace(CALLBACK_ORIGIN, ""))


def test_a_person_the_firm_already_employs_can_sign_in_through_the_provider(client, session):
    """The link is made once, and it names the account that already existed.

    The assertion that matters is the last one: the same user id, not a new
    person. A federated login that created a second row would leave every
    decision this person recorded under the password path attributed to somebody
    who no longer signs in.
    """
    with tenancy.acting_as(DEMO_TENANT):
        before = identity.find_by_email(session, OPERATOR_EMAIL)
        assert before is not None
        expected_id = before.id

    landed = _walk(client)
    assert landed.status_code == 303, landed.text
    assert landed.headers["location"] == "http://localhost:3100/"
    assert auth.COOKIE_NAME in landed.cookies

    me = client.get("/auth/session").json()
    assert me["authenticated"] is True
    assert me["user"]["email"] == OPERATOR_EMAIL
    assert "operator" in me["roles"]

    with tenancy.acting_as(DEMO_TENANT):
        linked = identity.find_by_oidc(
            session, issuer=stub_idp.ISSUER, subject=stub_idp.STUB.person.sub
        )
        assert linked is not None
        assert linked.id == expected_id


def test_the_first_federated_sign_in_is_recorded_as_a_link(client, session):
    """A person's account coming under their employer's IdP is worth a row.

    Distinguished from an ordinary federated sign-in because it happens once and
    is the moment the firm's provider takes over: an access review that could not
    tell the two apart could not say when that happened.
    """
    _walk(client)
    session.expire_all()
    with tenancy.acting_as(DEMO_TENANT):
        actions = set(session.scalars(select(AuditEvent.action)))
    assert "auth.oidc.link" in actions


def test_a_second_sign_in_reuses_the_link_rather_than_making_another(client, session):
    _walk(client)
    reset_rate_limit_for_tests()
    with TestClient(app, follow_redirects=False) as second:
        assert _walk(second).status_code == 303

    with tenancy.acting_as(DEMO_TENANT):
        person = identity.find_by_email(session, OPERATOR_EMAIL)
        assert person is not None
        with tenancy.acting_as_user(person.id):
            rows = list(
                session.scalars(
                    select(UserIdentity).where(
                        UserIdentity.user_id == person.id,
                        UserIdentity.provider == identity.OIDC_PROVIDER,
                    )
                )
            )
    assert len(rows) == 1
    assert rows[0].last_used_at is not None


def test_the_authorization_request_carries_pkce_and_a_nonce(client):
    """Proof the parameters are sent, not merely handled when they come back.

    A client that verified `nonce` on the way in but never sent one would pass
    every test that only drives the stub, because the stub echoes what it is
    given. This reads what was actually asked for.
    """
    _walk(client)
    asked = stub_idp.STUB.seen[-1]
    assert asked["code_challenge_method"] == "S256"
    assert asked["code_challenge"] and "code_verifier" not in asked
    assert asked["nonce"] and asked["state"]
    assert asked["response_type"] == "code"


def test_the_provider_is_the_authority_on_what_a_person_is_called(
    client, stub_provider, session
):
    """A name that drifts is a name that reads wrong beside next year's work.

    The firm's directory is where people get married, change their name, or were
    entered with a typo — so the assertion updates the display name. What it does
    not touch is anything already printed: a signature holds the name it was
    signed under, which is why `pack_drafts.signed_by` is a string beside the
    user id rather than a lookup through it.
    """
    stub_provider.person = stub_idp.Person(
        sub="idp|dana", email=OPERATOR_EMAIL, name="Dana Whitfield-Okoro"
    )
    assert _walk(client).status_code == 303

    session.expire_all()
    with tenancy.acting_as(DEMO_TENANT):
        person = identity.find_by_email(session, OPERATOR_EMAIL)
        assert person is not None
        assert person.display_name == "Dana Whitfield-Okoro"


# ------------------------------------------------------------------- the refusals --


def _assert_refused(landed, reason: str) -> None:
    assert landed.status_code == 303, landed.text
    assert landed.headers["location"] == f"http://localhost:3100/?sso_error={reason}"
    assert auth.COOKIE_NAME not in landed.cookies


def test_a_token_signed_by_an_unpublished_key_is_refused(client, stub_provider):
    stub_provider.sign_with_wrong_key = True
    _assert_refused(_walk(client), "invalid")


def test_a_token_with_no_signature_at_all_is_refused(client, monkeypatch):
    """`alg: none` — a valid JWT that proves nothing.

    Forged directly into the exchange rather than through the stub, because no
    library will produce one. A verifier that takes the algorithm from the token
    accepts this, and then accepts anything.
    """
    monkeypatch.setattr(
        oidc,
        "_exchange",
        lambda provider, document, code, verifier: {
            "id_token": stub_idp.unsigned_token(
                {
                    "iss": stub_idp.ISSUER,
                    "aud": stub_idp.CLIENT_ID,
                    "sub": stub_idp.STUB.person.sub,
                    "iat": int(time.time()),
                    "exp": int(time.time()) + 300,
                    "email": OPERATOR_EMAIL,
                    "email_verified": True,
                }
            )
        },
    )
    _assert_refused(_walk(client), "invalid")


def test_a_token_from_another_login_is_refused(client, stub_provider):
    """The `nonce` check, and the reason it cannot be skipped.

    Everything else about this token is correct — right key, right issuer, right
    audience, unexpired. It simply belongs to a different sign-in, which is
    exactly the shape of a replayed assertion.
    """
    stub_provider.override_nonce = "a nonce from somebody else's login"
    _assert_refused(_walk(client), "invalid")


def test_a_token_issued_for_a_different_client_is_refused(client, stub_provider):
    stub_provider.override_audience = "some-other-tenant-of-the-same-broker"
    _assert_refused(_walk(client), "invalid")


def test_an_expired_token_is_refused(client, stub_provider):
    stub_provider.lifetime_seconds = -60
    _assert_refused(_walk(client), "invalid")


def test_a_callback_with_no_state_cookie_is_refused(client):
    """The cookie is what makes a callback ours. Without it there is nothing to
    compare `state` against, and an attacker's code would be spent under whatever
    session the victim's browser holds."""
    start = client.get("/auth/oidc/start")
    back = _consent(start.headers["location"])
    client.cookies.delete(oidc.STATE_COOKIE, path="/auth/oidc")
    _assert_refused(client.get(back.replace(CALLBACK_ORIGIN, "")), "invalid")


def test_a_callback_whose_state_does_not_match_is_refused(client):
    """A code the provider really issued, presented under the wrong state.

    This is the shape of the attack `state` exists to stop: an authorization code
    that is genuine — it is the attacker's own — arriving at a victim's browser,
    which would otherwise end up holding a session for the attacker's account.
    """
    start = client.get("/auth/oidc/start")
    back = _consent(start.headers["location"])
    code = parse_qs(urlparse(back).query)["code"][0]
    landed = client.get(f"/auth/oidc/callback?code={code}&state=not-the-state-we-minted")
    _assert_refused(landed, "invalid")


def test_a_provider_that_refuses_the_exchange_produces_no_session(client, stub_provider):
    stub_provider.refuse_token = True
    _assert_refused(_walk(client), "invalid")


def test_a_user_who_declined_at_the_provider_lands_back_without_a_session(client):
    landed = client.get("/auth/oidc/callback?error=access_denied&state=x")
    _assert_refused(landed, "declined")


# ------------------------------------------------- what the provider may not decide --


def test_a_subject_with_no_account_here_is_refused_rather_than_provisioned(
    client, stub_provider, session
):
    """Authentication is not authorisation, and it is not provisioning either.

    The provider has authenticated this person perfectly well. They have no row
    here, so they do not get in — and no row is created for them. An IdP that
    could provision would make the access review report a description of whoever
    is in a directory group rather than of who the firm decided to admit.
    """
    stub_provider.person = stub_idp.Person(
        sub="idp|stranger", email="stranger@quolin.example"
    )
    _assert_refused(_walk(client), "no_account")

    with tenancy.acting_as(DEMO_TENANT):
        assert identity.find_by_email(session, "stranger@quolin.example") is None


def test_an_unverified_address_may_not_select_an_account(client, stub_provider):
    """The claim is a text field until the provider says otherwise.

    At a provider that lets a user set any address on their own profile, an
    unverified `email` claim is attacker-controlled — so honouring one would let
    anybody with an account there link themselves to any account here. The
    subject is new, so the address is the only thing that could match, and it
    must not.
    """
    stub_provider.person = stub_idp.Person(
        sub="idp|unverified", email=OPERATOR_EMAIL, email_verified=False
    )
    _assert_refused(_walk(client), "no_account")


def test_the_provider_does_not_get_to_choose_the_session_it_receives(client):
    """A federated session is not treated as freshly re-authenticated.

    Whether the provider demanded a second factor is its policy and is not
    visible here, so signing rule content still demands a step-up on this
    deployment. Assumed in the strict direction on purpose: the permissive
    assumption is the one that collects a signature from a session nobody
    re-proved.
    """
    _walk(client)
    signed = client.get("/auth/session").json()
    assert signed["authenticated"] is True
    assert signed["mfa_satisfied"] is False


# --------------------------------------------------------------- switched off --


def test_the_routes_do_not_exist_where_no_provider_is_configured(monkeypatch):
    """The demo has no IdP, and that is a supported deployment rather than a
    misconfiguration — the password fallback is what tenants without one use."""
    monkeypatch.delenv("QUOLIN_OIDC_ISSUER", raising=False)
    reset_rate_limit_for_tests()
    with TestClient(app, follow_redirects=False) as c:
        assert c.get("/auth/oidc/start").status_code == 404
        assert c.get("/auth/oidc/callback?code=x&state=y").status_code == 404


# ------------------------------------------------------------- the state cookie --


def test_a_tampered_state_cookie_is_refused():
    """Signed, not merely opaque.

    The verifier and the nonce are in there; a cookie whose contents could be
    edited would let a caller supply the `nonce` its own token happens to carry,
    which defeats the check that binds a token to a login.
    """
    sealed = oidc.seal("state-value", "nonce-value", "verifier-value")
    body, signature = sealed.split(".", 1)
    assert oidc.unseal(sealed)["state"] == "state-value"

    forged = oidc.seal("state-value", "different-nonce", "verifier-value").split(".")[0]
    with pytest.raises(oidc.OidcError):
        oidc.unseal(f"{forged}.{signature}")
    with pytest.raises(oidc.OidcError):
        oidc.unseal(f"{body}.{'A' * len(signature)}")


def test_an_expired_state_cookie_is_refused():
    sealed = oidc.seal("s", "n", "v", now=time.time() - oidc.STATE_TTL_SECONDS - 1)
    with pytest.raises(oidc.OidcError):
        oidc.unseal(sealed)
