"""With no firm in scope, the shelf that decides refuses rather than permits.

F11. `_may_use_unreviewed` answered `True` when no tenant was bound:

    tenant_id = current_tenant_or_none()
    if tenant_id is None:
        # No firm in scope means a script or a screen, not a determination.
        return True

The reasoning is sound and the direction is wrong. "No firm in scope" is not
evidence that this is a screen; it is the absence of evidence either way. Every
caller that decides does bind a tenant — which means an unbound one is a caller
that has gone wrong, and the safe answer to "may this firm act on rules nobody
has signed" is not *yes* when you cannot tell which firm is asking.

`tenancy.current_tenant()` already raises in exactly this situation, and the
whole of §S11 rests on that refusal. This was the one place that quietly
answered instead — and it answered on the single question the execution plan
says cannot be waived.

**Screens are unaffected, because they never used this path.** `describe` and
`describe_all` exist precisely so a compliance officer can read that AU is
`PENDING_REVIEW`; they apply no gate at all and are documented as never
reachable from a determination. Two names rather than a flag, as the module says
— so the gate can fail closed without taking the screens with it.
"""

from __future__ import annotations

from datetime import date

import pytest

from app import packs_repo, tenancy
from app.db import SessionLocal
from app.tenancy import NoTenantInScope
from tests.conftest import DEMO_TENANT

ACTOR = "apc_bulk_sweep"


@pytest.fixture
def no_tenant_in_scope():
    """The state a caller that has gone wrong is in, restored afterwards.

    Reaching into the context variable because there is no `acting_as(nothing)`
    and the point is precisely the absence —
    `test_v1_token_needs_no_ambient_tenant.py` does the same and says why.
    """
    token = tenancy._current.set(None)
    try:
        yield
    finally:
        tenancy._current.reset(token)


def test_the_decision_shelf_refuses_with_no_firm_in_scope(no_tenant_in_scope) -> None:
    """The finding: `active_all` is the shelf every determination reads."""
    assert tenancy.current_tenant_or_none() is None, "the fixture did not take"

    session = SessionLocal()
    try:
        with pytest.raises(NoTenantInScope):
            packs_repo.active_all(session, date.today())
    finally:
        session.close()


def test_a_single_regime_lookup_refuses_too(no_tenant_in_scope) -> None:
    """`active` is the other way onto the same shelf."""
    session = SessionLocal()
    try:
        with pytest.raises(NoTenantInScope):
            packs_repo.active(session, "AU", date.today())
    finally:
        session.close()


def test_the_screen_path_still_answers(no_tenant_in_scope) -> None:
    """`describe` applies no gate and must go on applying none.

    A fix that made the refusal universal would have taken the disclosure with
    it — the screen that tells a compliance officer their AU pack is unsigned is
    the control working, not a thing to lock down.
    """
    session = SessionLocal()
    try:
        pack = packs_repo.describe(session, "AU", date.today())
        assert pack.pack_id == "AU"

        shelf = packs_repo.describe_all(session, date.today())
        assert "AU" in shelf
    finally:
        session.close()


def test_a_firm_in_scope_is_unaffected(session) -> None:
    """The control: the ordinary path still works, and still decides."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        shelf = packs_repo.active_all(session, date.today())
    assert {"AU", "HK", "SG", "EU"} <= set(shelf)


def test_the_refusal_names_what_is_missing(no_tenant_in_scope) -> None:
    """An operator reading this needs to know what went wrong, not just that it did."""
    session = SessionLocal()
    try:
        with pytest.raises(NoTenantInScope) as refused:
            packs_repo.active_all(session, date.today())
    finally:
        session.close()

    assert "tenant" in str(refused.value).lower()
