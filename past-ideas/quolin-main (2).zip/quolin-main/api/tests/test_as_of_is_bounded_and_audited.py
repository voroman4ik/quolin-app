"""A determination's date is a claim about when, not a dial.

F7. `as_of` was caller-controlled and unbounded, and it selects the pack:

* **Backdating** picks whichever version was in force then. If a regime tightened
  a threshold in June, asking for May gets the laxer rules — a determination that
  reads as perfectly ordinary evidence and was made under content the firm is no
  longer governed by.
* **Forward-dating** changes the client rather than the rules. `age_years` and
  `knowledge_assessed_days_ago` are both derived from `as_of`, so a date far
  enough ahead makes a minor an adult and a stale assessment current.

Neither leaves a mark. The decision row records the `as_of` it was given, which
is the value that made it, so the evidence agrees with itself and the access
review has nothing to sort on.

Three changes, and they are deliberately not the same change:

* A future `as_of` is refused outright. There is no determination to make about
  facts that have not happened.
* A past `as_of` needs a stated reason. Backdating is legitimate — a
  determination reconstructed for a complaint, a period being re-filed — so it
  is not refused; it is made non-anonymous.
* Whichever way it went, if the pack selected is not the one in force today, a
  distinct audit action is written. That is what makes "list every backdated
  determination" a query the quarterly access review can actually run, rather
  than a spelunk through decision rows.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from conftest import reset_rate_limit_for_tests
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import business_time, passwords, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import ApiClient, AuditEvent
from tests.conftest import DEMO_TENANT, OPERATOR_EMAIL, sign_in

ACTOR = "apc_bulk_sweep"
CREDENTIAL = "apc_as_of_probe"
SECRET = "an integration secret, not a real one"

CLIENT = "margaret-wu"
ASSET = "BTC"


@pytest.fixture
def credential() -> str:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            row = owner.get(ApiClient, CREDENTIAL)
            if row is None:
                owner.add(
                    ApiClient(
                        id=CREDENTIAL,
                        label="as_of probe",
                        secret_hash=passwords.hash_password(SECRET, email=CREDENTIAL),
                        roles=["operator", "viewer"],
                        status="active",
                        created_by="test",
                    )
                )
            else:
                row.secret_hash = passwords.hash_password(SECRET, email=CREDENTIAL)
                row.roles = ["operator", "viewer"]
                row.status = "active"
            owner.commit()
    finally:
        owner.close()
    return CREDENTIAL


@pytest.fixture
def api(credential) -> TestClient:

    reset_rate_limit_for_tests()
    machine = TestClient(app)
    token = machine.post(
        "/v1/oauth/token",
        json={
            "grant_type": "client_credentials",
            "client_id": credential,
            "client_secret": SECRET,
        },
    ).json()["access_token"]
    machine.headers["Authorization"] = f"Bearer {token}"
    return machine


def _audit_actions() -> list[str]:
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            return [
                row.action
                for row in session.scalars(
                    select(AuditEvent).order_by(AuditEvent.id.desc()).limit(40)
                )
            ]
        finally:
            session.close()


def test_a_future_as_of_is_refused(api) -> None:
    """Forward-dating does not select a pack; it rewrites the client.

    `age_years` and `knowledge_assessed_days_ago` are both derived from `as_of`,
    so a date far enough ahead makes a minor an adult and a lapsed knowledge
    assessment current — in a determination that looks entirely ordinary.
    """
    ahead = (date.today() + timedelta(days=365 * 3)).isoformat()

    res = api.post(
        "/v1/evaluations",
        json={"client_id": CLIENT, "asset_id": ASSET, "as_of": ahead},
    )

    assert res.status_code == 422, (
        f"a determination was accepted as at a date three years away: {res.text}"
    )
    assert "future" in res.text.lower()


def firms_today() -> date:
    """Today as the firm under test counts days. FP3-05.

    These two tests used `date.today()`, which is the *container's* calendar
    day. That agreed with the application for as long as the application was
    also reading the container's clock — the suite and the code were both
    getting the same date from the same wrong place, so nothing disagreed.

    With business dates coming from the tenant's timezone, the demo firm is in
    Sydney and the runner is in UTC, and for ten hours of every day those are
    different dates. Run at 10:00 Sydney, `date.today()` here was the 27th while
    the firm's today was the 28th: "today is accepted" was refused as
    undocumented backdating, and "tomorrow is refused" was accepted because it
    was in fact the firm's today.

    Both failures are the fix working. The assertions were describing the
    defect.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with SessionLocal() as fresh:
            return business_time.business_today(fresh)


def test_tomorrow_is_far_enough_to_be_refused(api) -> None:
    """The boundary is today, not 'roughly now'."""
    res = api.post(
        "/v1/evaluations",
        json={
            "client_id": CLIENT,
            "asset_id": ASSET,
            "as_of": (firms_today() + timedelta(days=1)).isoformat(),
        },
    )
    assert res.status_code == 422, res.text


def test_today_is_accepted(api) -> None:
    """The control: the ordinary case is `as_of` today, explicitly or not."""
    res = api.post(
        "/v1/evaluations",
        json={
            "client_id": CLIENT,
            "asset_id": ASSET,
            "as_of": firms_today().isoformat(),
        },
    )
    assert res.status_code == 200, res.text


def test_omitting_as_of_is_accepted(api) -> None:
    res = api.post("/v1/evaluations", json={"client_id": CLIENT, "asset_id": ASSET})
    assert res.status_code == 200, res.text


def test_backdating_without_a_reason_is_refused(api) -> None:
    """Backdating is legitimate and anonymous backdating is not.

    A determination reconstructed for a complaint is a real need. What must not
    be available is doing it without saying why, because the resulting row is
    indistinguishable from an ordinary determination.
    """
    res = api.post(
        "/v1/evaluations",
        json={
            "client_id": CLIENT,
            "asset_id": ASSET,
            "as_of": (date.today() - timedelta(days=200)).isoformat(),
        },
    )

    assert res.status_code == 422, (
        f"a backdated determination was made with no reason given: {res.text}"
    )
    assert "reason" in res.text.lower()


def test_backdating_with_a_reason_is_allowed_and_audited(api) -> None:
    """And the reason reaches the audit trail, where a reviewer will look."""
    reason = "Reconstructed for complaint REF-8814 at the client's request."
    res = api.post(
        "/v1/evaluations",
        json={
            "client_id": CLIENT,
            "asset_id": ASSET,
            "as_of": (date.today() - timedelta(days=200)).isoformat(),
            "as_of_reason": reason,
        },
    )

    assert res.status_code == 200, res.text

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            rows = list(
                session.scalars(
                    select(AuditEvent).order_by(AuditEvent.id.desc()).limit(40)
                )
            )
        finally:
            session.close()

    backdated = [r for r in rows if r.action == "v1.evaluation.backdated"]
    assert backdated, (
        f"no distinct audit action for a backdated determination; actions seen: "
        f"{sorted({r.action for r in rows})}"
    )
    assert any(reason[:30] in (r.subject or "") for r in backdated), (
        "the stated reason is not in the audit trail, so the review cannot read it"
    )


def test_a_blank_reason_does_not_count(api) -> None:
    """Whitespace is not a reason, and a required field somebody types a space
    into is a control that has already been defeated."""
    res = api.post(
        "/v1/evaluations",
        json={
            "client_id": CLIENT,
            "asset_id": ASSET,
            "as_of": (date.today() - timedelta(days=30)).isoformat(),
            "as_of_reason": "   ",
        },
    )
    assert res.status_code == 422, res.text


def test_an_ordinary_determination_writes_no_backdated_action(api) -> None:
    """The distinct action has to stay rare, or the review cannot use it."""
    res = api.post("/v1/evaluations", json={"client_id": CLIENT, "asset_id": ASSET})
    assert res.status_code == 200, res.text

    actions = _audit_actions()
    assert actions, "no audit events at all"
    assert actions[0] != "v1.evaluation.backdated", (
        "an ordinary determination was recorded as backdated"
    )


def test_the_console_path_also_refuses_a_future_date() -> None:
    """The workbench reaches the same evaluator and takes the same field.

    The report named the `/v1` handler, and fixing only that would leave the
    firm's own staff holding the dial the integration no longer has.
    """
    with TestClient(app) as client:
        sign_in(client, OPERATOR_EMAIL)
        res = client.post(
            "/evaluate",
            json={
                "client_id": CLIENT,
                "asset_id": ASSET,
                "as_of": (date.today() + timedelta(days=90)).isoformat(),
            },
        )

    assert res.status_code == 422, res.text
    assert "future" in res.text.lower()
