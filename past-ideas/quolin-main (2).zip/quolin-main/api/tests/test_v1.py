"""The versioned API, tested as a customer's integration would use it.

Everything here is somebody else's contract. A breaking change in the web
client's API is a nuisance because both ship in the same commit; a breaking
change here is a customer whose nightly job stopped, who found out from their
compliance team, and who now does not trust the next release either.

So the tests are written from the outside: get a token, send a request, read the
response. Nothing reaches into a session or calls a service function directly,
because none of that is available to the person this API is for.

Three things carry most of the weight:

* **A machine is confined.** It authenticates, it holds roles, and it cannot
  reach the acts a regulator wants a name against. Stage 2 spent a stage making
  every action attributable to a person; a machine principal that could approve
  its own override would have undone that quietly.
* **Idempotency actually prevents a second determination.** Not "returns the same
  shape" — the same decision id, from an append-only chain that cannot be tidied
  up afterwards.
* **Pagination is stable under insertion.** An offset would skip rows while
  determinations are being made, and a customer paging through their history
  would silently miss some.
"""

from __future__ import annotations

import uuid

import pytest
from conftest import DEMO_TENANT, reset_rate_limit_for_tests
from fastapi.testclient import TestClient

from app import passwords, tenancy
from app.main import app
from app.models import ApiClient, AuthSession

SECRET = "an integration secret, not a real one"


#: One credential, reused by every test in this file rather than one per test.
#:
#: Not a shortcut. A credential that has acted cannot be deleted — the audit
#: trail names it, and Stage 2's rule is that an actor with a dangling reference
#: is worse than one that has been retired. Creating a fresh credential per test
#: and deleting it afterwards is therefore a lie about how a deployment retires
#: one; it also broke `test_attribution.py`, which resolves every audit actor
#: against the rows that exist and correctly found the orphans.
CREDENTIAL = "apc_v1_test"


@pytest.fixture
def credential(session):
    """The integration this file acts as, with `operator` and `viewer`.

    Created once and left in place, like `test_rls.py`'s probe user. Roles and
    status are reset on the way *in* rather than on the way out, so a failing
    test cannot leave the next one misconfigured.
    """
    with tenancy.acting_as(DEMO_TENANT):
        session.rollback()
        row = session.get(ApiClient, CREDENTIAL)
        if row is None:
            session.add(
                ApiClient(
                    id=CREDENTIAL,
                    label="Test integration",
                    secret_hash=passwords.hash_password(SECRET, email=CREDENTIAL),
                    roles=["operator", "viewer"],
                    status="active",
                    created_by="test",
                )
            )
        else:
            row.roles = ["operator", "viewer"]
            row.status = "active"
        session.commit()

    yield CREDENTIAL

    # Sessions are cleared so a token minted by one test cannot answer for
    # another. The credential itself stays.
    with tenancy.acting_as(DEMO_TENANT):
        session.rollback()
        session.query(AuthSession).filter_by(api_client_id=CREDENTIAL).delete(
            synchronize_session=False
        )
        session.commit()


@pytest.fixture
def api(credential):
    """A client holding a bearer token, the way an integration holds one."""
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        got = c.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": SECRET,
            },
        )
        assert got.status_code == 200, got.text
        c.headers["Authorization"] = f"Bearer {got.json()['access_token']}"
        yield c


# ------------------------------------------------------------------- tokens --


def test_client_credentials_buy_a_bearer_token(credential):
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        got = c.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": SECRET,
            },
        )
    body = got.json()
    assert got.status_code == 200
    assert body["token_type"] == "Bearer"
    assert body["access_token"]
    assert body["expires_in"] > 0
    assert "operator" in body["scope"]


def test_a_wrong_secret_and_an_unknown_client_are_the_same_refusal(credential):
    """Otherwise this endpoint is an oracle for which credentials exist.

    A customer's client ids are not secret in the way a secret is, but the set of
    them is a fact about that customer's integrations, and an endpoint that
    confirms membership of a set is one somebody will enumerate.
    """
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        wrong = c.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": "not the secret",
            },
        )
        missing = c.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": "apc_nobody",
                "client_secret": SECRET,
            },
        )
    assert wrong.status_code == missing.status_code == 401
    assert wrong.json()["detail"] == missing.json()["detail"]


def test_only_the_client_credentials_grant_is_offered(credential):
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        got = c.post(
            "/v1/oauth/token",
            json={
                "grant_type": "password",
                "client_id": credential,
                "client_secret": SECRET,
            },
        )
    assert got.status_code == 400
    assert got.json()["detail"]["code"] == "unsupported_grant_type"


def test_a_suspended_credential_buys_nothing(credential, session):
    with tenancy.acting_as(DEMO_TENANT):
        session.get(ApiClient, credential).status = "suspended"
        session.commit()

    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        got = c.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": SECRET,
            },
        )
    assert got.status_code == 401


def test_v1_refuses_a_caller_with_no_token():
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        got = c.get("/v1/decisions")
    assert got.status_code == 401


def test_the_challenge_tells_an_integration_to_send_a_token_not_find_a_cookie():
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        got = c.get("/v1/decisions", headers={"Authorization": "Bearer nonsense"})
    assert got.status_code == 401
    assert got.headers["WWW-Authenticate"] == "Bearer"


# ------------------------------------------------- what a machine may not do --


def test_a_machine_cannot_reach_the_acts_that_need_a_name_against_them(api, session):
    """Stage 2 spent a whole stage making every action attributable to a person.

    A machine principal that could approve an override or sign rule content would
    have undone that quietly — the audit row would name a credential, and nobody
    could be asked why. The route table is what stops it, and this is the test
    that says so from the outside rather than by reading the table.
    """
    for method, path in [
        ("POST", "/decisions/1/override"),
        ("POST", "/watch/drafts/1/sign"),
        ("POST", "/watch/drafts/1/publish"),
        ("POST", "/auth/revoke-all"),
    ]:
        got = api.request(method, path, json={})
        assert got.status_code == 403, f"{method} {path} returned {got.status_code}"


def test_a_machine_holding_only_viewer_cannot_write(session, credential):
    with tenancy.acting_as(DEMO_TENANT):
        session.get(ApiClient, credential).roles = ["viewer"]
        session.commit()

    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        token = c.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": SECRET,
            },
        ).json()["access_token"]
        c.headers["Authorization"] = f"Bearer {token}"

        assert c.get("/v1/decisions").status_code == 200
        assert (
            c.post(
                "/v1/evaluations",
                json={"client_id": "margaret-wu", "asset_id": "BTC"},
            ).status_code
            == 403
        )


# -------------------------------------------------------------- determinations --


def test_a_determination_comes_back_with_its_reasons_and_its_evidence(api):
    got = api.post(
        "/v1/evaluations", json={"client_id": "tom-askew", "asset_id": "SOL"}
    )
    assert got.status_code == 200, got.text
    body = got.json()

    assert body["outcome"] == "BLOCK"
    assert body["pack"]["id"] and body["pack"]["version"]
    assert len(body["reasons"]) == 3
    for reason in body["reasons"]:
        assert reason["rule_id"] and reason["reason_code"]
        # The sentence a compliance officer reads, not a rule id they cannot act
        # on. An API that returned only codes would make every consumer build
        # their own copy of our reason text, and then ours would be wrong.
        assert reason["plain_english"]
    assert body["evidence"]["this_hash"]


def test_a_determination_can_be_read_back_and_replayed(api):
    made = api.post(
        "/v1/evaluations", json={"client_id": "harold-bell", "asset_id": "BTC"}
    ).json()

    read = api.get(f"/v1/decisions/{made['id']}")
    assert read.status_code == 200
    assert read.json()["outcome"] == made["outcome"]

    replayed = api.post(f"/v1/decisions/{made['id']}/replay").json()
    assert replayed["match"] is True
    assert replayed["differences"] == []
    assert replayed["chain"]["verified"] is True


def test_an_unknown_client_is_a_404_that_says_so(api):
    got = api.post("/v1/evaluations", json={"client_id": "nobody", "asset_id": "BTC"})
    assert got.status_code == 404
    assert got.json()["detail"]["code"] == "not_found"


# ------------------------------------------------------------- idempotency --


def test_the_same_key_returns_the_same_determination_rather_than_a_second_one(api):
    """The property that matters, stated as the decision id.

    Not "returns the same shape" — the *same decision*. A determination is
    written to an append-only evidence chain, and a retry that produced a second
    one would leave two records of a decision made once, with no way to remove
    either.
    """
    key = str(uuid.uuid4())
    body = {"client_id": "margaret-wu", "asset_id": "BTC"}

    first = api.post("/v1/evaluations", json=body, headers={"Idempotency-Key": key})
    second = api.post("/v1/evaluations", json=body, headers={"Idempotency-Key": key})

    assert first.status_code == second.status_code == 200
    assert first.json()["id"] == second.json()["id"]
    assert first.json() == second.json()


def test_without_a_key_a_retry_really_does_make_a_second_determination(api):
    """The control. If this produced one determination too, the test above would
    be passing for a reason unrelated to idempotency."""
    body = {"client_id": "margaret-wu", "asset_id": "BTC"}
    first = api.post("/v1/evaluations", json=body).json()
    second = api.post("/v1/evaluations", json=body).json()
    assert first["id"] != second["id"]


def test_reusing_a_key_with_a_different_body_is_refused(api):
    """The caller believes they sent two things. Answering with the first one's
    response would tell them the second had succeeded when it never ran."""
    key = str(uuid.uuid4())
    api.post(
        "/v1/evaluations",
        json={"client_id": "margaret-wu", "asset_id": "BTC"},
        headers={"Idempotency-Key": key},
    )
    clash = api.post(
        "/v1/evaluations",
        json={"client_id": "tom-askew", "asset_id": "SOL"},
        headers={"Idempotency-Key": key},
    )
    assert clash.status_code == 409
    assert clash.json()["detail"]["code"] == "idempotency_key_reused"


def test_a_key_belongs_to_one_endpoint(api):
    key = str(uuid.uuid4())
    api.post(
        "/v1/evaluations",
        json={"client_id": "margaret-wu", "asset_id": "BTC"},
        headers={"Idempotency-Key": key},
    )
    elsewhere = api.post(
        "/v1/clients",
        json={
            "id": "v1-idem-probe",
            "name": "Probe",
            "dob": "1985-01-01",
            "loss_capacity_band": 3,
            "assessable_portfolio_cents": 100000,
        },
        headers={"Idempotency-Key": key},
    )
    assert elsewhere.status_code == 409


# --------------------------------------------------------------- pagination --


def test_a_page_says_how_to_ask_for_the_next_one(api):
    first = api.get("/v1/decisions?limit=2").json()
    assert len(first["data"]) == 2
    assert first["has_more"] is True
    assert first["next_cursor"]

    second = api.get(f"/v1/decisions?limit=2&cursor={first['next_cursor']}").json()
    assert len(second["data"]) == 2
    assert {d["id"] for d in first["data"]}.isdisjoint({d["id"] for d in second["data"]})


def test_paging_does_not_skip_or_repeat_when_rows_are_added_underneath(api):
    """The reason this is a cursor rather than an offset.

    A customer paging through their history while determinations are being made
    would, with `OFFSET`, silently miss rows as the table grew under them. The
    cursor is the last id seen, which is stable under insertion.
    """
    first = api.get("/v1/decisions?limit=3").json()
    seen = [d["id"] for d in first["data"]]

    # Three new determinations land while the caller is between pages.
    for _ in range(3):
        api.post("/v1/evaluations", json={"client_id": "margaret-wu", "asset_id": "BTC"})

    second = api.get(f"/v1/decisions?limit=3&cursor={first['next_cursor']}").json()
    seen += [d["id"] for d in second["data"]]

    assert len(seen) == len(set(seen)), "paging repeated a row"
    assert seen == sorted(seen), "paging went backwards"


def test_the_last_page_says_there_is_no_more(api):
    page = api.get("/v1/decisions?limit=200").json()
    if not page["has_more"]:
        assert page["next_cursor"] is None


def test_an_oversized_page_is_refused_with_the_limit(api):
    got = api.get("/v1/decisions?limit=10000")
    assert got.status_code == 400
    assert got.json()["detail"]["code"] == "invalid_limit"
    assert "200" in got.json()["detail"]["message"]


def test_a_cursor_we_did_not_issue_is_refused(api):
    got = api.get("/v1/decisions?cursor=not-one-of-ours!!")
    assert got.status_code == 400
    assert got.json()["detail"]["code"] == "invalid_cursor"


# --------------------------------------------------------------------- bulk --


def test_one_bad_pair_does_not_fail_the_whole_call(api):
    """Same reasoning as a malformed batch row. A caller evaluating five hundred
    pairs and getting one error back has learned nothing about the other four
    hundred and ninety-nine."""
    got = api.post(
        "/v1/bulk",
        json={
            "pairs": [
                {"client_id": "margaret-wu", "asset_id": "BTC"},
                {"client_id": "nobody-at-all", "asset_id": "BTC"},
                {"client_id": "tom-askew", "asset_id": "SOL"},
            ]
        },
    )
    assert got.status_code == 200
    body = got.json()
    assert body["requested"] == 3
    assert body["evaluated"] == 2
    assert body["failed"] == 1

    failed = next(r for r in body["results"] if r["error"])
    assert failed["client_id"] == "nobody-at-all"
    assert failed["error"]["code"] == "not_found"


# ------------------------------------------------------------------ clients --


def test_a_client_can_be_created_and_updated_through_one_endpoint(api, session):
    payload = {
        "id": "v1-upsert-probe",
        "name": "Upsert Probe",
        "dob": "1980-06-15",
        "loss_capacity_band": 3,
        "assessable_portfolio_cents": 5_000_000,
    }
    created = api.post("/v1/clients", json=payload)
    assert created.status_code == 200
    assert created.json()["created"] is True

    updated = api.post("/v1/clients", json={**payload, "name": "Renamed"})
    assert updated.json()["created"] is False

    with tenancy.acting_as(DEMO_TENANT):
        session.expire_all()
        from app.models import Client

        row = session.get(Client, "v1-upsert-probe")
        assert row.name == "Renamed"
        session.delete(row)
        session.commit()


def test_money_must_be_whole_cents(api):
    """Invariant 3 at the edge a customer touches.

    `25000.50` is the mistake an integrator makes on their first afternoon, and
    catching it at the boundary is much kinder than a determination that will not
    reproduce in 2031.
    """
    got = api.post(
        "/v1/clients",
        json={
            "id": "v1-float-probe",
            "name": "Float Probe",
            "dob": "1980-06-15",
            "loss_capacity_band": 3,
            "assessable_portfolio_cents": 25000.50,
        },
    )
    assert got.status_code == 422


# ------------------------------------------------------------ the delivery log --


def test_the_delivery_log_is_readable_through_the_api(api):
    """S4's gate says a dead endpoint dead-letters *visibly*. This is where it is
    visible to the customer rather than to us."""
    got = api.get("/v1/webhooks/deliveries")
    assert got.status_code == 200
    assert "data" in got.json()


# ---------------------------------------------------------------- the contract --


def test_every_v1_route_is_documented_in_the_openapi_surface():
    """The document a customer's engineer works from is generated from the code,
    so it cannot describe an endpoint that does not exist or omit one that
    does."""
    spec = app.openapi()
    documented = {p for p in spec["paths"] if p.startswith("/v1")}
    declared = {
        r.path
        for r in app.router.routes
        if getattr(r, "path", "").startswith("/v1")
    }
    assert documented == declared


def test_every_v1_endpoint_has_a_summary_a_reader_can_scan():
    spec = app.openapi()
    for path, operations in spec["paths"].items():
        if not path.startswith("/v1"):
            continue
        for method, operation in operations.items():
            assert operation.get("summary"), f"{method.upper()} {path} has no summary"


def test_a_generated_document_can_be_retrieved(api, session):
    """The path mypy caught as wrong before any test ran.

    `read_pdf` takes a storage reference and returns None when the file is gone;
    the first draft passed it the row and expected an exception. Both halves were
    wrong and nothing exercised it, which is what a type checker is for and why
    this test now exists beside it.
    """
    from app import artefacts
    from app import tenancy as t
    from app.models import Artefact

    made = api.post(
        "/v1/evaluations", json={"client_id": "margaret-wu", "asset_id": "BTC"}
    ).json()

    with t.acting_as(DEMO_TENANT):
        artefact = artefacts.render(session, kind="tmd", decision_id=made["id"])
        session.commit()
        artefact_id = artefact.id

    got = api.get(f"/v1/artefacts/{artefact_id}")
    assert got.status_code == 200, got.text
    assert got.headers["content-type"] == "application/pdf"
    assert got.content.startswith(b"%PDF")

    with t.acting_as(DEMO_TENANT):
        session.delete(session.get(Artefact, artefact_id))
        session.commit()


def test_an_artefact_whose_file_is_gone_says_to_generate_it_again(api, session):
    """410 rather than 404: the artefact existed and the determination behind it
    is unchanged, so "generate it again" is the whole of the caller's move."""
    from app import tenancy as t
    from app.models import Artefact

    made = api.post(
        "/v1/evaluations", json={"client_id": "margaret-wu", "asset_id": "BTC"}
    ).json()

    with t.acting_as(DEMO_TENANT):
        row = Artefact(
            kind="tmd",
            ref_id=str(made["id"]),
            title="Vanished",
            template_version="test",
            pdf_ref="a-file-that-is-not-there.pdf.enc",
        )
        session.add(row)
        session.commit()
        artefact_id = row.id

    got = api.get(f"/v1/artefacts/{artefact_id}")
    assert got.status_code == 410
    assert got.json()["detail"]["code"] == "artefact_gone"
    with t.acting_as(DEMO_TENANT):
        session.delete(session.get(Artefact, artefact_id))
        session.commit()
