"""A request handler uses the connection a request is entitled to.

The Gate A audit's seventh finding. `GET /admin/users` imported
`OwnerSessionLocal` from `app.db` inside the handler — the role that owns every
table, owns every append-only trigger, is exempt from FORCE row-level security,
and is what `scripts/rechain.py` rewrites evidence hashes with.

**Three things about it, and the second is the one nothing said.**

*It bought nothing.* The handler justified the owner read on the ground that
`users` is a platform table invisible until `app.user_id` names the row. That is
`user_self`, and it had already stopped being the whole story: migration 0047
re-pointed `user_reachable` at `tenant_members`, which is exactly the roster this
handler lists. Every person it enumerates is visible to the firm's own
connection, so the read is a plain `session.get(User, …)` and always was.

*It was broken in production.* FP3-04 removed `DATABASE_URL` from the
request-serving task, and `db.py` falls back to a hardcoded `localhost:5433`
when it is absent. So in the deployment this did not escalate — it failed to
connect, and the user-administration screen returned 500. The bypass was
reachable exactly where the owner connection happens to be lying about, which is
a developer's laptop and this suite.

*And `owner_only.py` could not stop it.* That module refuses to import without
`DATABASE_URL`, precisely so a process with no business holding the owner fails
at the import rather than three frames into a request — and its own docstring
names the hole: *"Importing this from anything a request can reach is a mistake
this cannot prevent."* Importing `app.db` directly went around it.
`scripts/guard_no_owner_in_request_path.sh` is what prevents it now, and this
file is its AST twin.

**Four rules, and the count is itself the finding.** Each round closed the
spelling that had just been used and kept the shape:

    B2 (three names) -> the door -> the door with a three-file allow-list
                     -> F2: the door, the key, and the neighbours who hold both

- *Rule 1* forbids naming the connection: `OwnerSessionLocal`, `owner_engine`,
  `OWNER_DATABASE_URL`. Three spellings, which is what B2 found was not a class.
- *Rule 2* forbids reaching `app.owner_only` at all. Both follow-up audits
  walked past rule 1 with `from app import owner_only;
  owner_only.active_tenant_ids()` — no connection named, the owner reached, both
  layers green.
- *Rule 3* forbids holding the key: `DATABASE_URL`, `create_engine`,
  `psycopg.connect`. F2. Rules 1 and 2 forbade the door and three names for what
  is behind it, and neither forbade `create_engine(os.environ["DATABASE_URL"])`,
  which needs no door at all.
- *Rule 4* forbids importing `seed` or `scripts`. F2. Both sit beside `api/app`
  on `sys.path` here and in the built image, and both re-export the owner at
  module scope, because holding it is what a worker is for.

**F3, and it is why the bottom half of this file exists.** Until it, this twin
had no mutation cases. Deleting the `Attribute`, `Name` and `Constant` branches
from `_opens_the_door` produced a clean run — and this is the only layer that
catches two of the door's spellings, so the backstop was the layer nothing
tested. `test_the_shell_guard_says_the_same_thing` used to assert that both
layers exit 0 on a clean tree, which is agreement on a *pass*: two checks that
both do nothing agree perfectly. `test_both_layers_refuse` replaces it and
asserts they agree on each *failure*, one spelling at a time.
"""

from __future__ import annotations

import ast
import os
import re
import subprocess
import sys
from pathlib import Path

import pytest
from conftest import ADMIN_EMAIL, DEMO_TENANT, reset_rate_limit_for_tests, sign_in
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import tenancy
from app.db import SessionLocal
from app.main import app
from app.models import TenantMember, User

REPO = Path(__file__).resolve().parents[2]
APP = REPO / "api" / "app"
GUARD = REPO / "scripts" / "guard_no_owner_in_request_path.sh"

#: Rule 1. The names that reach the owner connection, and the two files that may
#: hold them. `db.py` constructs the engine because something has to;
#: `owner_only.py` is the locked door.
OWNER_NAMES = ("OwnerSessionLocal", "owner_engine", "OWNER_DATABASE_URL")
MAY_NAME_IT = {"db.py", "owner_only.py"}

#: Rule 2. The door itself. B2.
#:
#: Keying on the three names above closed three spellings and not the class.
#: Both follow-up audits walked past it the same way — `from app import
#: owner_only; owner_only.active_tenant_ids()` names none of them and reaches
#: the schema owner — and one of them ran it. A runtime `ImportError` mitigates
#: it in the deployment, where the API task holds no `DATABASE_URL`; on a laptop
#: and in this suite, which is the environment the original defect was
#: reachable in, it works and CI stays green.
#:
#: **The allow-list is empty, and F2 is what emptied it.** `auth.py` was the one
#: entry: `_reset_rate_limit_for_tests` disabled an append-only trigger and
#: deleted from `auth_attempts` as the owner, and only the suite ever called it.
#: The argument for keeping it was that forty test call sites named it — a fact
#: about diffs, not about what was enforced. `auth` is imported by everything
#: that serves a request, so the exemption was holding invariant 4 and the login
#: rate limit open from any handler, for a caller that is not in the request
#: path at all. It is `conftest.reset_rate_limit_for_tests` now.
#:
#: `source_alerts.py` was an entry before that and was deleted rather than
#: allowlisted: `all_tenant_ids` was a pure delegation with no caller left in the
#: tree. Both went the same way, and the way is the answer this fix pack keeps
#: arriving at — a door nobody in the request path needs is one fewer door.
#:
#: Empty rather than `{"db.py", "owner_only.py"}`, which is where the shell
#: guard's list still stands: those two name the module in prose, and a grep
#: cannot tell prose from code. This rule reads the parse tree, where a docstring
#: is not a reference — so an entry for either would be an exemption hiding
#: nothing, which is the thing the mutation cases below exist to catch.
DOOR = "owner_only"
MAY_OPEN_IT: set[str] = set()

#: Rule 3. The key, and the two calls that turn it into a connection. F2.
#:
#: `DATABASE_URL` unqualified, so `APP_DATABASE_URL` and `WATCH_DATABASE_URL`
#: are caught too: no request-path module has business naming a connection
#: string for any role. `db.py` is the one file that may, because it is the one
#: file that builds the engines — and `owner_only.py` came off this list when it
#: stopped asking `os.getenv("DATABASE_URL")` for itself and started asking
#: `db.OWNER_URL_WAS_SUPPLIED`.
#:
#: `KEY_URL` is a shape rather than a list, and the shape is what keeps the two
#: layers saying the same thing. The shell rule greps for the substring
#: `DATABASE_URL`, so it catches every prefixed spelling for free; an exact-name
#: list here caught `DATABASE_URL` and missed `APP_DATABASE_URL`, which is a
#: divergence between the layers — the shape this defect has taken three times,
#: and `test_both_layers_refuse` is what found it. Anchored on the whole
#: identifier, so a docstring saying "the API task no longer holds
#: `DATABASE_URL`" is still not a match.
KEY_URL = re.compile(r"(?:[A-Z][A-Z0-9_]*_)?DATABASE_URL")
KEY_CALLABLES = ("create_engine",)
KEY_MODULE = "psycopg"
KEY_CALL = "connect"
MAY_HOLD_THE_KEY = {"db.py"}


def _is_the_key(text: str) -> bool:
    """Whether an identifier or string constant names the key or opens it."""
    return text in KEY_CALLABLES or KEY_URL.fullmatch(text) is not None

#: Rule 4. The packages next door. F2.
#:
#: `api/seed` and `scripts` are on `sys.path` beside `api/app` in this suite and
#: in the built image, and both re-export the owner at module scope —
#: `seed/seed.py` line 21 is `from app.db import OwnerSessionLocal,
#: owner_engine`, and every worker under `scripts/` does the same. So
#: `import seed.seed; seed.seed.OwnerSessionLocal()` reaches the owner from a
#: request-path module while naming neither the connection nor the door.
#:
#: No allow-list, and that is not an omission: nothing under `api/app` has any
#: reason to import either, so there is nothing to except.
SIBLING_PACKAGES = ("seed", "scripts")


def _tree(path: Path) -> ast.Module:
    return ast.parse(path.read_text(), filename=str(path))


def _root(dotted: str | None) -> str:
    return str(dotted or "").split(".")[0]


def _rooted_at(node: ast.expr, name: str) -> bool:
    """Whether an expression is `name` or an attribute chain starting at it."""
    while isinstance(node, ast.Attribute):
        node = node.value
    return isinstance(node, ast.Name) and node.id == name


def _named_in(path: Path) -> set[str]:
    """Rule 1, by parse tree: which owner names this module actually references.

    An AST rather than a grep, deliberately, and for the opposite reason the
    shell guard is a grep. The guard runs in CI without a Python project set up
    and has to be fast and simple; this one has the parser to hand, and reading
    the tree means a name inside a docstring or a comment — which
    `main.py` now has several of, describing what was removed — is not a match.
    A guard that refused to let its own history be written down is one people
    route around.
    """
    found: set[str] = set()
    for node in ast.walk(_tree(path)):
        if isinstance(node, ast.Name) and node.id in OWNER_NAMES:
            found.add(node.id)
        elif isinstance(node, ast.Attribute) and node.attr in OWNER_NAMES:
            found.add(node.attr)
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name in OWNER_NAMES:
                    found.add(alias.name)
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            # A string is how `os.getenv("OWNER_DATABASE_URL")` reaches it.
            if node.value in OWNER_NAMES:
                found.add(node.value)
    return found


def _opens_the_door(path: Path) -> set[str]:
    """Rule 2, by parse tree: every way this module reaches `app.owner_only`.

    B2. Six spellings, and the audit used the one a grep for the connection
    names could never have seen:

        from app import owner_only          ImportFrom, alias name
        from . import owner_only            ImportFrom, alias name
        from app.owner_only import x        ImportFrom, module
        from .owner_only import x           ImportFrom, module (level > 0)
        import app.owner_only               Import, alias name
        importlib.import_module("app.owner_only")   a string constant

    Attribute access is caught as well, so a module handed the package by any
    other route still shows up. The docstrings in this tree name the module
    constantly and none of them is a match, which is the reason this exists
    beside a grep rather than instead of it.

    **F3: three of these branches were dead weight and nothing said so.**
    Removing the `Attribute`, `Name` and `Constant` cases left the suite green —
    nothing noticed — because every mutation case in `test_guard_mutations.py`
    ran against the shell guard, which greps for the token and catches all six
    regardless. `test_both_layers_refuse` below now runs each spelling through
    *this* function too, including the three only it can catch.
    """
    found: set[str] = set()

    def _names(dotted: str | None) -> bool:
        return bool(dotted) and DOOR in str(dotted).split(".")

    for node in ast.walk(_tree(path)):
        if isinstance(node, ast.ImportFrom):
            if _names(node.module):
                found.add(f"from {'.' * node.level}{node.module} import …")
            for alias in node.names:
                if alias.name == DOOR:
                    found.add(f"from {'.' * node.level}{node.module or ''} import {DOOR}")
        elif isinstance(node, ast.Import):
            for alias in node.names:
                if _names(alias.name):
                    found.add(f"import {alias.name}")
        elif isinstance(node, ast.Attribute) and node.attr == DOOR:
            found.add(f"…{DOOR} (attribute)")
        elif isinstance(node, ast.Name) and node.id == DOOR:
            found.add(f"{DOOR} (name)")
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            if _names(node.value):
                found.add(f"{node.value!r} (string)")
    return found


def _holds_the_key(path: Path) -> set[str]:
    """Rule 3, by parse tree: the owner's connection string, and how to open it.

    F2. A module that can read `DATABASE_URL` and call `create_engine` has
    reached the schema owner without naming `OwnerSessionLocal`, without
    importing `owner_only`, and without either of the first two rules having
    anything to say about it. The door was guarded and the key was on the hook
    beside it.

    Whole-identifier matching rather than a substring test, which is what lets
    the prose stand: `pack_notices.py` says "the API task no longer holds
    `DATABASE_URL` at all" inside a docstring, and that whole string is not an
    environment variable name. The shell guard needs its backtick filter for the
    same line; this one does not.
    """
    found: set[str] = set()
    for node in ast.walk(_tree(path)):
        if isinstance(node, ast.Name) and _is_the_key(node.id):
            found.add(node.id)
        elif isinstance(node, ast.Attribute):
            if _is_the_key(node.attr):
                found.add(node.attr)
            # `psycopg.connect(...)`, which is the same reach with SQLAlchemy
            # left out of it. Matched on the pair rather than on `connect`
            # alone: `owner_engine.connect()` is a different thing entirely and
            # `db.py` is not the only file that may call something's `.connect`.
            elif node.attr == KEY_CALL and _rooted_at(node.value, KEY_MODULE):
                found.add(f"{KEY_MODULE}.{KEY_CALL}")
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if _is_the_key(alias.name):
                    found.add(alias.name)
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            if _is_the_key(node.value):
                found.add(node.value)
    return found


def _imports_a_sibling(path: Path) -> set[str]:
    """Rule 4, by parse tree: `seed` or `scripts`, in any spelling.

    F2. Absolute imports only. `from . import seed` inside `api/app` would name
    a module of that package, not the sibling — there is no `app/seed.py`, so it
    would be an error rather than a bypass, and treating it as one would make
    the rule about the word instead of about the package.

    A string constant counts only when it carries a dot, which is what makes it
    a module path rather than the word "seed" in a dictionary key. The shell
    guard draws the line in the same place, and drawing it differently in the
    two layers is the shape this defect has taken three times.
    """
    found: set[str] = set()
    for node in ast.walk(_tree(path)):
        if isinstance(node, ast.ImportFrom) and node.level == 0:
            if _root(node.module) in SIBLING_PACKAGES:
                found.add(f"from {node.module} import …")
        elif isinstance(node, ast.Import):
            for alias in node.names:
                if _root(alias.name) in SIBLING_PACKAGES:
                    found.add(f"import {alias.name}")
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            if "." in node.value and _root(node.value) in SIBLING_PACKAGES:
                found.add(f"{node.value!r} (string)")
    return found


def reaches_the_owner(path: Path) -> set[str]:
    """All four rules at once, for a mutation case that is about the boundary.

    The per-file tests below apply each rule with its own allow-list, because
    the allow-lists differ and each entry has its own reason. A probe module in
    a scratch directory is exempt from nothing, so this union is what "does this
    layer refuse it" means for a violation.
    """
    return (
        _named_in(path)
        | _opens_the_door(path)
        | _holds_the_key(path)
        | _imports_a_sibling(path)
    )


APP_MODULES = sorted(p for p in APP.rglob("*.py") if "__pycache__" not in str(p))
MODULE_IDS = [str(p.relative_to(APP)) for p in APP_MODULES]


@pytest.mark.parametrize("path", APP_MODULES, ids=MODULE_IDS)
def test_no_application_module_reaches_the_schema_owner(path: Path):
    """Rule 1. Every module under `api/app` is in the request path or one import
    from it.

    The workers live in `scripts/` and are not scanned: `artefact_worker`,
    `bulk_worker`, `health_alerts` and `comparison_report` all hold the owner
    connection deliberately, because each enumerates every firm and a query for
    "all tenants" under FORCE row-level security returns the one in scope. Rule
    4 is what stops that being a way in.
    """
    named = _named_in(path)
    if path.name in MAY_NAME_IT:
        assert named, (
            f"{path.name} is exempt from this rule and no longer names the "
            "owner connection at all, so the exemption is now hiding nothing "
            "and should be removed."
        )
        return
    assert not named, (
        f"{path.relative_to(REPO)} names {sorted(named)}. That is the schema "
        "owner, in a module a request can reach. If the operation genuinely "
        "needs owner privileges it belongs outside the request path — a script "
        "or a scheduled task — and if it is one of the two things `app/"
        "owner_only.py` holds, it belongs there."
    )


@pytest.mark.parametrize("path", APP_MODULES, ids=MODULE_IDS)
def test_no_application_module_opens_the_owner_only_door(path: Path):
    """Rule 2, B2. The class, rather than three spellings of what is behind it.

    The rule above forbids naming the owner connection. This forbids reaching
    the module that holds one, which is how both follow-up audits walked past
    it: `from app import owner_only` names no connection at all and calls
    straight through to `OwnerSessionLocal`.

    `MAY_OPEN_IT` is empty since F2, so nothing takes the exempt branch. That is
    the end state rather than a gap: no module under `api/app` opens this door
    at all now.
    """
    opened = _opens_the_door(path)
    if path.name in MAY_OPEN_IT:
        assert opened, (
            f"{path.name} is allowed to open `app.owner_only` and no longer "
            "does, so the exemption is hiding nothing and should be removed. "
            "An allow-list entry nobody needs is the next thing somebody "
            "reaches for."
        )
        return
    assert not opened, (
        f"{path.relative_to(REPO)} reaches app.owner_only: {sorted(opened)}. "
        "That module is a locked door and not a safe wrapper — behind it is the "
        "schema owner, which owns every append-only trigger and is exempt from "
        "FORCE row-level security. Importing it from something a request can "
        "reach is reaching the owner, however politely. Move the operation into "
        "a script or a scheduled task and say why in docs/spec-changes.md."
    )


@pytest.mark.parametrize("path", APP_MODULES, ids=MODULE_IDS)
def test_no_application_module_holds_the_key(path: Path):
    """Rule 3, F2. The door was guarded and the key was on the hook beside it.

    `create_engine(os.environ["DATABASE_URL"])` reaches the same role as
    `OwnerSessionLocal()` and names none of the tokens the first two rules
    forbid. One file may build an engine, and it is the file whose whole job is
    building them.
    """
    held = _holds_the_key(path)
    if path.name in MAY_HOLD_THE_KEY:
        assert held, (
            f"{path.name} is the one file that may name the owner's connection "
            "string and no longer does, so the exemption is hiding nothing."
        )
        return
    assert not held, (
        f"{path.relative_to(REPO)} names {sorted(held)}. A module that can read "
        "the connection string and build its own engine has reached the schema "
        "owner without opening anybody's door. `db.py` constructs the engines; "
        "everything else takes a session from it."
    )


@pytest.mark.parametrize("path", APP_MODULES, ids=MODULE_IDS)
def test_no_application_module_imports_a_sibling_package(path: Path):
    """Rule 4, F2. The neighbours hold the owner because that is their job.

    `seed` and `scripts` are importable from `api/app` in this suite and in the
    built image, and both re-export `OwnerSessionLocal` at module scope. There
    is no allow-list because there is nothing an application module needs from
    either.
    """
    imported = _imports_a_sibling(path)
    assert not imported, (
        f"{path.relative_to(REPO)} imports {sorted(imported)}. Those packages "
        "hold the schema owner at module scope — `seed/seed.py` and every worker "
        "under `scripts/` import `OwnerSessionLocal` directly — so importing one "
        "from the request path reaches the owner by proxy. If the operation "
        "belongs to a worker, call it as a worker."
    )


# ------------------------------------------- F3: both layers, on each failure --
#
# What was here was `test_the_shell_guard_says_the_same_thing`: run the shell
# guard on the real tree, assert exit 0, and call that agreement. It is
# agreement on a *pass*, which two checks that do nothing also reach. The AST
# twin had no mutation cases at all — deleting three branches of
# `_opens_the_door` produced a clean run — and it is the only layer that catches
# two of the door's spellings, so the backstop was the untested one.
#
# The table below is one violation per row, and each row is asserted to be
# refused by both layers. The shell guard is pointed at a scratch directory via
# `APP_DIR`, which is the parameter it already takes: no tree copy, and the
# probe module is exempt from nothing.


#: (label, module source). Every spelling both layers must refuse.
#:
#: The three door cases marked below are the F3 finding: the shell guard greps
#: for the token and catches all six regardless, so nothing was holding the
#: corresponding AST branches up.
VIOLATIONS = [
    # -- rule 1: the connection, by name -----------------------------------
    (
        "db-import-inside-a-handler",
        "def _probe():\n"
        "    from app.db import OwnerSessionLocal\n\n"
        "    return OwnerSessionLocal()\n",
    ),
    ("db-import-at-module-scope", "from app.db import OwnerSessionLocal\n"),
    (
        "the-engine-rather-than-the-sessionmaker",
        "from app.db import owner_engine\n\n\ndef _probe():\n    return owner_engine.connect()\n",
    ),
    (
        "the-variable-name-as-a-string",
        'import os\n\n\ndef _probe():\n    return os.getenv("OWNER_DATABASE_URL")\n',
    ),
    # -- rule 2: the door ---------------------------------------------------
    (
        "the-audits-own-bypass",
        "from app import owner_only\n\n\ndef _probe():\n"
        "    return owner_only.active_tenant_ids()\n",
    ),
    (
        "the-bypass-inside-a-handler",
        "def _probe():\n"
        "    from app import owner_only\n\n"
        "    return owner_only.active_tenant_ids()\n",
    ),
    (
        "the-relative-spelling",
        "def _probe():\n"
        "    from . import owner_only\n\n"
        "    return owner_only.active_tenant_ids()\n",
    ),
    (
        "straight-at-the-callable",
        "def _probe():\n"
        "    from .owner_only import active_tenant_ids\n\n"
        "    return active_tenant_ids()\n",
    ),
    ("the-other-callable", "from app.owner_only import reset_rate_limit\n"),
    (
        "the-dotted-module",
        "import app.owner_only\n\n\ndef _probe():\n    return app.owner_only.active_tenant_ids()\n",
    ),
    # An attribute chain and no import of the door at all — only this layer's
    # `Attribute` branch sees it, and deleting that branch used to be invisible.
    (
        "an-attribute-of-a-package-already-in-scope",
        "import app\n\n\ndef _probe():\n    return app.owner_only.active_tenant_ids()\n",
    ),
    # A bare name, handed in from somewhere else. Only the `Name` branch.
    (
        "a-bare-name-handed-in",
        "def _probe(owner_only=None):\n    return owner_only.active_tenant_ids()\n",
    ),
    # A dotted path as a string. Only the `Constant` branch.
    (
        "the-module-path-as-a-string",
        "import importlib\n\n\ndef _probe():\n"
        '    return importlib.import_module("app.owner_only")\n',
    ),
    # -- rule 3: the key ----------------------------------------------------
    (
        "its-own-engine-from-the-environment",
        "import os\n\nfrom sqlalchemy import create_engine\n\n"
        '_e = create_engine(os.environ["DATABASE_URL"])\n',
    ),
    (
        "create_engine-through-the-package",
        "import sqlalchemy\n\n\ndef _probe():\n"
        '    return sqlalchemy.create_engine("postgresql://")\n',
    ),
    ("the-key-alone", 'import os\n\n\ndef _probe():\n    return os.environ["DATABASE_URL"]\n'),
    (
        "the-application-role-is-a-connection-too",
        'import os\n\n\ndef _probe():\n    return os.environ["APP_DATABASE_URL"]\n',
    ),
    (
        "the-driver-without-sqlalchemy",
        'import psycopg\n\n\ndef _probe():\n    return psycopg.connect("dbname=quolin")\n',
    ),
    # -- rule 4: the neighbours --------------------------------------------
    (
        "the-seed-package",
        "import seed.seed\n\n\ndef _probe():\n    return seed.seed.OwnerSessionLocal()\n",
    ),
    ("a-name-out-of-the-seed-package", "from seed.seed import OwnerSessionLocal\n"),
    (
        "a-worker-module",
        "from scripts import health_alerts\n\n\ndef _probe():\n    return health_alerts\n",
    ),
    (
        "a-worker-module-dotted",
        "import scripts.rechain\n\n\ndef _probe():\n    return scripts.rechain\n",
    ),
    (
        "a-sibling-by-name",
        'import importlib\n\n\ndef _probe():\n    return importlib.import_module("seed.seed")\n',
    ),
    (
        "a-worker-by-name",
        "import importlib\n\n\ndef _probe():\n"
        '    return importlib.import_module("scripts.health_alerts")\n',
    ),
]


def _probe_tree(tmp_path: Path, source: str) -> Path:
    """A one-module scratch package for the guards to be pointed at.

    Not a copy of the repository: `test_guard_mutations.py` records what half a
    gigabyte per case did to a laptop, and the shell guard already takes
    `APP_DIR` from the environment — which is the parameter under test in its
    own vacuity cases. A probe module in a directory of its own is exempt from
    every allow-list, which is what a violation should be.
    """
    scan = tmp_path / "app"
    scan.mkdir()
    (scan / "probe.py").write_text(source)
    return scan


def _shell_guard(scan: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["bash", str(GUARD)],
        cwd=REPO,
        env={**os.environ, "APP_DIR": str(scan)},
        capture_output=True,
        text=True,
    )


@pytest.mark.parametrize(
    "source", [source for _, source in VIOLATIONS], ids=[name for name, _ in VIOLATIONS]
)
def test_both_layers_refuse(tmp_path, source):
    """F3. Two implementations of one rule, checked against each other on a fail.

    This replaces `test_the_shell_guard_says_the_same_thing`, which ran both on
    a clean tree and asserted both exited 0. Two checks that do nothing agree on
    that too. What is worth asserting is that they agree on each violation —
    and asserting it per spelling is what makes a deleted branch in either layer
    a failure with a name on it.
    """
    scan = _probe_tree(tmp_path, source)

    caught = reaches_the_owner(scan / "probe.py")
    assert caught, (
        "the AST layer did not see this reach the schema owner:\n\n"
        f"{source}\n"
        "Every branch of the four detectors is load-bearing for at least one "
        "row of VIOLATIONS; if you removed one, this is the row that says so."
    )

    result = _shell_guard(scan)
    assert result.returncode != 0, (
        "the shell layer passed on a module the AST layer refuses:\n\n"
        f"{source}\n{result.stdout}{result.stderr}"
    )
    assert "FAIL" in (result.stdout + result.stderr)


def test_both_layers_pass_on_a_module_that_does_none_of_it(tmp_path):
    """The other half, and it is the half that decides whether these are guards.

    A layer that refused ordinary code would be one somebody removes from CI, so
    the same probe harness runs a module that takes a tenant-scoped session and
    asserts both are quiet. It also keeps the cases above honest: if the harness
    itself tripped the guards, every row would pass for the wrong reason.
    """
    scan = _probe_tree(
        tmp_path,
        "from app.db import SessionLocal\n"
        "\n"
        "\n"
        "def _probe():\n"
        "    session = SessionLocal()\n"
        "    try:\n"
        "        return session.get(object, 1)\n"
        "    finally:\n"
        "        session.close()\n",
    )

    assert reaches_the_owner(scan / "probe.py") == set()

    result = _shell_guard(scan)
    assert result.returncode == 0, result.stdout + result.stderr


def test_the_shell_guard_passes_on_the_real_tree():
    """Both layers green on `api/app` as it stands.

    Kept, and kept small. It is not evidence that the rules work — the cases
    above are that — but a guard nobody can keep green is a guard somebody
    deletes, and this is the assertion that fails first when a legitimate change
    trips a rule.
    """
    result = subprocess.run(
        ["bash", str(GUARD)], cwd=REPO, capture_output=True, text=True
    )
    assert result.returncode == 0, result.stdout + result.stderr


# ------------------------------------------------- and the screen still works --


def test_the_roster_resolves_every_member_through_the_tenants_own_connection():
    """The reason the owner read bought nothing, asserted rather than argued.

    `user_reachable` reads `tenant_members` since migration 0047, and
    `tenant_members` is the roster this screen lists. So every person on it is
    visible to the firm's own connection — which is the whole justification for
    deleting the owner session, and would be a silent regression if a future
    migration re-pointed that policy.
    """
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            members = list(session.scalars(select(TenantMember)))
            assert members, "the demo firm has no members, so this asserts nothing"
            unresolvable = [
                m.user_id for m in members if session.get(User, m.user_id) is None
            ]
        finally:
            session.close()

    assert unresolvable == [], (
        "these members are invisible to their own firm's connection: "
        f"{unresolvable}. `user_reachable` and `tenant_members` have come "
        "apart, and the administration screen would render a shorter roster "
        "than the firm actually has."
    )


def test_the_administration_screen_still_lists_people():
    """End to end, because the fix is a deletion and a deletion can take the
    feature with it. FP3-26 built this screen; what changed is which connection
    reads it."""
    reset_rate_limit_for_tests()
    with TestClient(app) as client:
        sign_in(client, ADMIN_EMAIL)
        response = client.get("/admin/users")

    assert response.status_code == 200, response.text
    body = response.json()
    assert body["tenant_id"] == DEMO_TENANT
    assert body["users"], "the roster came back empty"

    person = body["users"][0]
    assert person["email"] and "@" in person["email"]
    assert person["display_name"], (
        "a person with no display name — the screen would print an account id, "
        "which is the FP3-26 walkthrough's own finding."
    )
    # The names are what the owner read was ostensibly for. Reading them through
    # the tenant's connection has to produce the same thing.
    assert any(p["roles"] for p in body["users"]), "nobody holds any role"


def test_the_api_is_not_given_the_owner_connection_in_the_first_place():
    """Which is why this was a 500 in production rather than an escalation.

    **And it is the only structural control this file's subject has.**
    Everything above is lexical: it refuses the spellings somebody wrote down,
    in a process that holds the owner credential and could therefore reach it
    however it liked. What actually makes the owner unreachable from the request
    path is that the request-serving task is not given `DATABASE_URL` — which is
    this assertion, and `scripts/guard_task_credentials.py`. See
    `docs/spec-changes.md` for why no Python-level mechanism replaces it inside
    one process that holds the credential.

    Read from the task definition rather than asserted about a comment, so that
    a change putting `DATABASE_URL` back in the request-serving task fails here
    as well as in `scripts/guard_task_credentials.py`.
    """
    sys.path.insert(0, str(REPO))
    from scripts.task_environment import task_definitions

    api = task_definitions()["api"]
    assert "DATABASE_URL" not in api.names, (
        "the request-serving task has been given the schema owner's connection "
        "again. FP3-04 took it out; it owns every append-only trigger and is "
        "exempt from FORCE row-level security."
    )
