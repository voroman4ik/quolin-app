"""A server-to-server client must be able to reach the token endpoint.

F2. Q-05 added `_refuse_cross_site` to the middleware, which is the right place
for it, and exempted the case it knew about: `has_bearer and not has_cookie`. A
bearer token is not attached by a browser on its own, so a request carrying one
has no cross-site exposure.

`POST /v1/oauth/token` carries no bearer. It is how a bearer comes to exist. A
server-to-server client — a cron job, a customer's middleware, `curl` — sends no
`Origin` either, because it is not a browser and has no page to name. So the
request fell past the exemption, failed the origin check, and was refused 403
before its credential was ever read.

That is Q-17's failure — "no integration could authenticate at all" —
reintroduced one tier up, in the same fix pack, and invisible for the same
reason: **the suite never sends a headerless request.** `tests/conftest.py`
patches `TestClient.__init__` so every client in this suite sends
`Origin: http://localhost:3000`. Twenty-eight tests exercise this endpoint and
all of them passed against a middleware that refused every real caller. Neither
`docs/api/openapi.json` nor the Postman collection mentions an `Origin`
requirement, so nobody building against it would have sent one.

**The fix is about cookies, not bearers.** Cross-site request forgery works
because a browser attaches an *ambient* credential by itself. A request carrying
no session cookie has none to attach, so there is nothing to forge and nothing
to refuse. The origin check belongs on cookie-carrying requests, and the bearer
special case was a narrower statement of that.

**Every client below is built outside the conftest patch and proves it.** Each
test inspects the request as it was actually sent and asserts no `Origin` went
with it — otherwise it would pass vacuously, which is exactly how F2 survived.
"""

from __future__ import annotations

import pytest
from conftest import (
    ADMIN_EMAIL,
    DEMO_TENANT,
    TEST_PASSWORD,
    reset_rate_limit_for_tests,
    second_factor_code,
)
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import auth, passwords, tenancy
from app.db import OwnerSessionLocal
from app.main import app
from app.models import ApiClient

ACTOR = "apc_bulk_sweep"
CREDENTIAL = "apc_headerless_probe"
SECRET = "an integration secret, not a real one"

#: A page that is not ours, in the sense the middleware means.
FOREIGN_ORIGIN = "https://not-our-site.example"


@pytest.fixture
def credential() -> str:
    """An active integration credential, created and left in place.

    Left rather than deleted for the reason `test_v1.py` gives: a credential
    that has acted cannot be removed without leaving the audit trail naming an
    actor that no longer exists.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            row = owner.get(ApiClient, CREDENTIAL)
            if row is None:
                owner.add(
                    ApiClient(
                        id=CREDENTIAL,
                        label="Headerless integration probe",
                        secret_hash=passwords.hash_password(SECRET, email=CREDENTIAL),
                        roles=["operator", "viewer"],
                        status="active",
                        created_by="test",
                    )
                )
            else:
                row.secret_hash = passwords.hash_password(SECRET, email=CREDENTIAL)
                row.roles = ["operator", "viewer"]
                row.status = "active"
            owner.commit()
    finally:
        owner.close()
    return CREDENTIAL


class _Sent:
    """What actually went over the wire, so a pass cannot be vacuous."""

    def __init__(self) -> None:
        self.headers: list[dict[str, str]] = []

    def record(self, request) -> None:
        self.headers.append({k.lower(): v for k, v in request.headers.items()})

    @property
    def last(self) -> dict[str, str]:
        assert self.headers, "no request was sent"
        return self.headers[-1]


def _machine_client() -> tuple[TestClient, _Sent]:
    """A client that is not a browser, built outside the conftest patch.

    The patch in `tests/conftest.py` wraps `TestClient.__init__` and does
    `headers.setdefault("origin", ...)`, so passing an explicit `origin` would
    only replace one header with another. The header is removed after
    construction instead, and every request is recorded so each test can assert
    that nothing put it back.
    """
    client = TestClient(app)
    client.headers.pop("origin", None)
    client.headers.pop("referer", None)
    sent = _Sent()
    client.event_hooks["request"] = [sent.record]
    return client, sent


def test_a_token_request_with_no_origin_and_no_cookie_succeeds(credential) -> None:
    """F2, directly: the request every integration actually makes."""
    reset_rate_limit_for_tests()

    client, sent = _machine_client()
    with client:
        res = client.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": SECRET,
            },
        )

    assert "origin" not in sent.last, (
        "this test sent an Origin, so it proves nothing — the conftest patch is "
        "back and F2 would be invisible again"
    )
    assert "referer" not in sent.last, "the fallback header was sent either"
    assert "cookie" not in sent.last, "a cookie went with it; this is not the machine case"

    assert res.status_code == 200, (
        f"a server-to-server client was refused at the token endpoint: "
        f"{res.status_code} {res.text}. This is the only request an integration "
        "can make before it has a bearer, and no integration sends Origin."
    )
    assert res.json()["access_token"]


def test_a_token_request_from_a_foreign_origin_with_no_cookie_succeeds(
    credential,
) -> None:
    """A named origin we do not know is still not a forgery without a cookie.

    A machine client that happens to set `Origin` — some HTTP libraries do — must
    not be refused for setting it to something that is not our web client. There
    is no ambient credential on this request, so there is nothing to forge.
    """
    reset_rate_limit_for_tests()

    client, sent = _machine_client()
    with client:
        res = client.post(
            "/v1/oauth/token",
            headers={"origin": FOREIGN_ORIGIN},
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": SECRET,
            },
        )

    assert sent.last.get("origin") == FOREIGN_ORIGIN, "the foreign origin was not sent"
    assert "cookie" not in sent.last, "a cookie went with it; this is not the machine case"

    assert res.status_code == 200, (
        f"a cookie-less request was refused for naming an origin we do not "
        f"recognise: {res.status_code} {res.text}"
    )
    assert res.json()["access_token"]


def test_a_cookie_from_a_foreign_origin_is_still_refused() -> None:
    """The control Q-05 exists for, unchanged.

    This is the request that terminated 24 sessions: a browser holding our
    session cookie, driven by somebody else's page. It carries an ambient
    credential, so the origin check applies to it and must still refuse it.
    """
    reset_rate_limit_for_tests()

    client, sent = _machine_client()
    with client:
        body = {"email": ADMIN_EMAIL, "password": TEST_PASSWORD}
        code = second_factor_code(ADMIN_EMAIL)
        if code:
            body["code"] = code
        # Signing in is itself an unsafe method, so it needs an origin the
        # middleware accepts — a browser would send one. What the test is about
        # is the *next* request.
        signed_in = client.post("/auth/login", json=body, headers={"origin": _ours(client)})
        assert signed_in.status_code == 200, signed_in.text
        assert auth.COOKIE_NAME in client.cookies, "no session cookie to forge with"

        res = client.post("/auth/revoke-all", headers={"origin": FOREIGN_ORIGIN})

    assert sent.last.get("origin") == FOREIGN_ORIGIN
    assert "cookie" in sent.last, "no cookie was sent, so this is not the forgery case"

    assert res.status_code == 403, (
        f"a cookie-carrying request from a foreign page was allowed: "
        f"{res.status_code} {res.text}. This is the finding Q-05 closed."
    )


def test_a_cookie_with_no_origin_at_all_is_still_refused() -> None:
    """The other half of Q-05, and the one the fix could most easily undo.

    Every current browser sends `Origin` on an unsafe method. A cookie-carrying
    POST with none is therefore not a browser doing something ordinary, and
    exempting cookie-less requests must not become exempting requests that
    simply omit the header.
    """
    reset_rate_limit_for_tests()

    client, sent = _machine_client()
    with client:
        body = {"email": ADMIN_EMAIL, "password": TEST_PASSWORD}
        code = second_factor_code(ADMIN_EMAIL)
        if code:
            body["code"] = code
        signed_in = client.post("/auth/login", json=body, headers={"origin": _ours(client)})
        assert signed_in.status_code == 200, signed_in.text

        res = client.post("/auth/revoke-all")

    assert "origin" not in sent.last, "an Origin was sent, so this proves nothing"
    assert "cookie" in sent.last, "no cookie was sent, so this is not the case under test"

    assert res.status_code == 403, (
        f"a cookie-carrying request naming no origin was allowed: "
        f"{res.status_code} {res.text}"
    )


def _ours(client: TestClient) -> str:
    """The origin the middleware treats as its own, for the sign-in step."""
    return str(client.base_url).rstrip("/")


def test_the_conftest_patch_is_still_what_makes_this_file_necessary() -> None:
    """Why these clients are built by hand, asserted rather than described.

    If the suite ever stops patching an `Origin` onto every client, the helper
    above becomes unnecessary — and, far more importantly, the rest of the suite
    starts exercising the middleware the way a real caller reaches it.
    """
    ordinary = TestClient(app)
    assert ordinary.headers.get("origin"), (
        "conftest no longer patches an Origin onto every TestClient. Check "
        "whether `_machine_client` is still doing anything."
    )


def test_the_seeded_integration_credential_is_still_usable(credential) -> None:
    """A token minted headerlessly is a real token, not merely a 200."""
    reset_rate_limit_for_tests()

    client, _ = _machine_client()
    with client:
        token = client.post(
            "/v1/oauth/token",
            json={
                "grant_type": "client_credentials",
                "client_id": credential,
                "client_secret": SECRET,
            },
        ).json()["access_token"]

        listed = client.get("/v1/clients", headers={"Authorization": f"Bearer {token}"})

    assert listed.status_code == 200, listed.text


def test_the_probe_credential_is_scoped_to_the_demo_firm() -> None:
    """The credential this file creates belongs to one firm, like any other."""
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            rows = list(
                owner.scalars(select(ApiClient).where(ApiClient.id == CREDENTIAL))
            )
    finally:
        owner.close()
    assert len(rows) <= 1
