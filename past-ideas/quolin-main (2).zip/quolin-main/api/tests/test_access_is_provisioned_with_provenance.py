"""A grant nobody can be named for is a grant the access review cannot review.

Users and role grants could only be created from a database shell. There was no
endpoint, so `identity.grant_role` defaulted `granted_by` to the string
`"bootstrap"` — and every grant in the system carried it. The quarterly access
review then reported, accurately and uselessly, on a set of permissions whose
authorisation was the word "bootstrap".

The SOC 2 control is not that access exists. It is that somebody authorised it
and somebody else can see who.

Two halves.

**A provisioning route**, so a grant can be made with a person behind it: create
the account, grant the role, revoke the grant. `quolin_operator` only, second
factor, credential presented recently, and an audit event on each. Every grant
made through it names the account that made it.

**And `granted_by` becomes required**, so the default cannot quietly reappear.
`"bootstrap"` still exists — the seed has to create the first administrator and
there is nobody to attribute that to — but it is only accepted inside an
explicit `identity.bootstrapping()` scope, which the seed enters and a request
cannot.

**Not customer self-service.** A firm's own `tenant_admin` still cannot grant
roles, and that is deliberate rather than an oversight: Q-12 rests on a customer
administrator being unable to grant themselves `quolin_operator`, and splitting
the vocabulary into "roles a customer may grant" and "roles only we may grant"
is a design decision larger than this fix. Nobody loses anything they had — the
route replaces a psql prompt, not a screen.
"""

from __future__ import annotations

import secrets

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import identity, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import AuditEvent, User, UserRole
from tests.conftest import ADMIN_EMAIL, DEMO_TENANT, PUBLISHER_EMAIL, sign_in

ACTOR = "apc_bulk_sweep"
#: A fresh address per run, because the person cannot be removed afterwards.
#:
#: This was a fixed address with a teardown that deleted the row. That teardown
#: was wrong for the reason FP3-13's `set_status` docstring gives about
#: suspension: `audit_events` names this person and is append-only, so deleting
#: them leaves the trail pointing at somebody who does not exist — which is
#: exactly what `test_attribution.py` refuses, and it started refusing it once
#: provisioning wrote a second audit row (FP3-11's invitation).
#:
#: Nothing in production deletes a person. Provisioning somebody new each run is
#: both closer to what the route does and the only option that leaves the trail
#: resolvable.
def _a_new_address() -> str:
    return f"provisioned.person.{secrets.token_hex(6)}@quolin.example"


NEW_PERSON = _a_new_address()


@pytest.fixture
def operator():
    with TestClient(app) as c:
        yield sign_in(c, PUBLISHER_EMAIL)


@pytest.fixture(autouse=True)
def clean_up():
    """A fresh address per test, and the role grants removed after it.

    **The person is not deleted, and that is the change.** This used to delete
    the `users` row so each test started from nothing, and it left
    `audit_events` — which is append-only — naming somebody who no longer
    existed. `test_attribution.py` asserts every actor in the trail resolves,
    and it began failing once provisioning wrote a second audit row for FP3-11's
    invitation.

    That is the same argument FP3-13 makes about suspension: decisions,
    overrides and audit events all name a person, and a row somebody removed is
    a name those records point at and cannot resolve. Nothing in production
    deletes a person.

    `user_roles` is not append-only and `access_review` reads it as the current
    set, so grants are still cleared — leaving them would make the next test's
    "this person has no roles yet" false.
    """
    global NEW_PERSON
    NEW_PERSON = _a_new_address()
    yield
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            person = identity.find_by_email(owner, NEW_PERSON)
            if person is not None:
                for grant in owner.scalars(
                    select(UserRole).where(UserRole.user_id == person.id)
                ):
                    owner.delete(grant)
                owner.commit()
    finally:
        owner.close()


# ------------------------------------------------------------- the mechanism --


def test_granted_by_is_required(session) -> None:
    """The default is gone. A caller that forgets is a TypeError, not a row.

    `"bootstrap"` was the default value, so every grant ever made carried it and
    the access review had nothing to report but that word.
    """
    person = identity.create_user(
        session, email="granter-probe@quolin.example", display_name="Probe"
    )
    session.flush()
    try:
        with pytest.raises(TypeError):
            identity.grant_role(session, user_id=person.id, role="viewer")
    finally:
        session.rollback()


def test_bootstrap_is_refused_outside_a_bootstrapping_scope(session) -> None:
    """It still exists, and it is no longer something a request can claim.

    The seed has to create the first administrator and there is genuinely nobody
    to attribute that to. What must not happen is a grant made while serving a
    request wearing the same word.
    """
    person = identity.create_user(
        session, email="bootstrap-probe@quolin.example", display_name="Probe"
    )
    session.flush()
    try:
        with pytest.raises(ValueError) as refused:
            identity.grant_role(
                session,
                user_id=person.id,
                role="viewer",
                granted_by=identity.BOOTSTRAP,
            )
        assert "bootstrap" in str(refused.value).lower()
    finally:
        session.rollback()


def test_bootstrap_is_permitted_inside_one(session) -> None:
    """Because the seed has to work."""
    person = identity.create_user(
        session, email="bootstrap-ok@quolin.example", display_name="Probe"
    )
    session.flush()
    try:
        with identity.bootstrapping():
            grant = identity.grant_role(
                session,
                user_id=person.id,
                role="viewer",
                granted_by=identity.BOOTSTRAP,
            )
        assert grant.granted_by == identity.BOOTSTRAP
    finally:
        session.rollback()


# --------------------------------------------------------------- the route --


def test_a_person_and_a_grant_can_be_provisioned_with_a_named_granter(operator) -> None:
    """The finding, as a test."""
    created = operator.post(
        "/admin/users",
        json={"email": NEW_PERSON, "display_name": "A Provisioned Person"},
    )
    assert created.status_code == 200, created.text
    user_id = created.json()["id"]

    granted = operator.post(
        f"/admin/users/{user_id}/roles", json={"role": "viewer"}
    )
    assert granted.status_code == 200, granted.text

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            grant = owner.scalars(
                select(UserRole).where(UserRole.user_id == user_id)
            ).one()
            granter = identity.find_by_email(owner, PUBLISHER_EMAIL)
    finally:
        owner.close()

    assert grant.granted_by == granter.id, (
        f"the grant names {grant.granted_by!r} as its authorisation. It has to "
        "name the account that made it, or the access review has nothing to "
        "review."
    )
    assert grant.granted_by != identity.BOOTSTRAP


def test_each_step_writes_a_chained_audit_event(operator) -> None:
    created = operator.post(
        "/admin/users",
        json={"email": NEW_PERSON, "display_name": "A Provisioned Person"},
    )
    user_id = created.json()["id"]
    operator.post(f"/admin/users/{user_id}/roles", json={"role": "approver"})

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            events = list(
                session.scalars(
                    select(AuditEvent)
                    .where(AuditEvent.action.in_(("identity.user.create", "identity.role.grant")))
                    .order_by(AuditEvent.id.desc())
                    .limit(2)
                )
            )
        finally:
            session.close()

    actions = {e.action for e in events}
    assert actions == {"identity.user.create", "identity.role.grant"}, actions
    for event in events:
        assert event.this_hash, f"{event.action} was not chained"
        assert user_id in event.subject or NEW_PERSON in event.subject, event.subject


def test_a_grant_can_be_revoked_and_the_revocation_is_recorded(operator) -> None:
    """Revoking takes the role away, records that it happened, and nothing else.

    **The third assertion is the one this test spent eleven stages without.** It
    had performed exactly this sequence since Stage 2 — provision, grant one
    role, revoke it — and asserted that the grant was gone and the revocation
    was chained. Both true, and both about the same half of what the act does.
    Nothing here asked whether the person was still somebody this firm could
    name, and until migration 0047 the answer was no: `user_reachable` decided
    visibility by looking for a live grant, so revoking the last one deleted the
    person from the firm's view while `audit_events`, append-only, went on
    naming them as the actor of things they did.

    It passed throughout, and the reason it could is worth keeping in front of
    whoever reads it next. The person provisioned here never acts, so no audit
    row names them and no downstream check noticed. A test can be completely
    right about its own claim and silent about the consequence that mattered.

    The defect was found by pressing Revoke on a screen and then looking at what
    the rest of the system said. This is that reading, written down where the
    act happens.
    """
    created = operator.post(
        "/admin/users",
        json={"email": NEW_PERSON, "display_name": "A Provisioned Person"},
    )
    user_id = created.json()["id"]
    grant_id = operator.post(
        f"/admin/users/{user_id}/roles", json={"role": "viewer"}
    ).json()["id"]

    revoked = operator.post(f"/admin/roles/{grant_id}/revoke")
    assert revoked.status_code == 200, revoked.text

    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            # What it takes away.
            assert identity.roles_for(session, user_id) == [], (
                "the grant is still live after being revoked"
            )
            event = session.scalars(
                select(AuditEvent)
                .where(AuditEvent.action == "identity.role.revoke")
                .order_by(AuditEvent.id.desc())
                .limit(1)
            ).first()
            # And what it must not take away. Read through the tenant's own
            # policies rather than as the owner, because the question is
            # precisely what this firm can still see.
            person = session.get(User, user_id)
        finally:
            session.close()

    assert event is not None and event.this_hash

    assert person is not None, (
        "revoking somebody's last role made them unresolvable to the firm. "
        "Every audit event naming them now points at nobody, which is the state "
        "FP3-13 built suspension to avoid."
    )
    assert person.email == NEW_PERSON
    assert person.status == "active", (
        "revoking a role changed the account's status — revocation is about "
        "what somebody may do, and suspension is how somebody leaves"
    )


def test_a_customer_administrator_cannot_provision(operator) -> None:
    """Deliberate, and the reason is Q-12.

    A `tenant_admin` who could grant roles could grant themselves
    `quolin_operator`, which is the role that publishes rule content to every
    tenant on the platform. They lose nothing they had: this route replaces a
    psql prompt, not a screen.
    """
    with TestClient(app) as admin:
        sign_in(admin, ADMIN_EMAIL)
        res = admin.post(
            "/admin/users",
            json={"email": NEW_PERSON, "display_name": "Should not exist"},
        )
    assert res.status_code == 403, res.text

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            assert identity.find_by_email(owner, NEW_PERSON) is None
    finally:
        owner.close()


def test_an_unknown_role_is_refused(operator) -> None:
    created = operator.post(
        "/admin/users",
        json={"email": NEW_PERSON, "display_name": "A Provisioned Person"},
    )
    user_id = created.json()["id"]
    res = operator.post(f"/admin/users/{user_id}/roles", json={"role": "superuser"})
    assert res.status_code == 422, res.text


def test_a_stale_credential_is_refused(operator) -> None:
    """Provisioning access is at least as weighty as signing rule content."""
    from datetime import timedelta

    from app import auth

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            row = auth.resolve(owner, operator.cookies.get(auth.COOKIE_NAME))
            assert row is not None
            row.authenticated_at = row.authenticated_at - timedelta(days=1)
            owner.commit()
    finally:
        owner.close()

    res = operator.post(
        "/admin/users", json={"email": NEW_PERSON, "display_name": "Nope"}
    )
    assert res.status_code == 401, res.text
    assert res.headers.get("X-Quolin-Reauth") == "required"


def test_the_seeded_grants_are_no_longer_all_bootstrap() -> None:
    """What the access review was looking at.

    Every grant in the system carried `bootstrap`, so the report was accurate
    and told nobody anything. The seed's own grants still do — there is nobody
    to attribute the first administrator to — but that is now a *stated*
    exception rather than the only value the column has ever held.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            granters = {
                g.granted_by
                for g in owner.scalars(
                    select(UserRole).where(UserRole.tenant_id == DEMO_TENANT)
                )
            }
    finally:
        owner.close()
    assert granters, "no grants at all"
