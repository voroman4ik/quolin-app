"""FP3-08: `pack.staged` and `pack.published` reached only the publisher's tenant.

Both events went through `service._tell_the_customers_systems`, which resolves
subscribers with `webhooks.endpoints_for` — an RLS-scoped query — inside the
signer's or publisher's own tenant transaction.

Packs are **global**: the same AU content governs every customer. Publication
requires `quolin_operator`, which is Quolin's own role and is granted *inside a
tenant*. So the only firm that could ever receive either event was whichever
tenant the publisher happened to be acting in — which is not a customer at all.

That leaves §S4's staged-pack notice and §S5's "tenants notified" gate
describing something that had never happened for anybody. Missed for the same
reason `source.stale` was: the producer exists, is called, and writes rows, so
nothing reads as unwired — the rows just go somewhere nobody is watching.

The test the finding asks for is the third one here: two subscribed firms, the
publisher in neither, both told.
"""

from __future__ import annotations

import pytest
from sqlalchemy import select, text

from app import pack_notices, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.models import PackEvent, PackEventNotice, WebhookDelivery, WebhookEndpoint

ACTOR = "apc_bulk_sweep"

#: Two customers, both licensed in AU, neither of them the publisher.
FIRM_A = "pack-event-probe-a"
FIRM_B = "pack-event-probe-b"
#: A third, licensed only in Singapore, which must hear nothing about an AU pack.
FIRM_ELSEWHERE = "pack-event-probe-sg"

#: Quolin's own tenant, where the operator who publishes actually acts.
PUBLISHER_TENANT = "_platform"


def _make_tenant(tenant_id: str, regimes: str) -> None:
    owner = OwnerSessionLocal()
    try:
        owner.execute(
            text(
                "INSERT INTO tenants (id, name, region, tier, status, stage, config, "
                "created_at) VALUES (:id, :id, 'ap-southeast-2', 'shared', 'active', "
                "'pilot', CAST(:config AS jsonb), now()) "
                "ON CONFLICT (id) DO UPDATE SET config = CAST(:config AS jsonb)"
            ),
            {"id": tenant_id, "config": regimes},
        )
        owner.commit()
        with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
            from app import crypto, evidence

            crypto.ensure_key(owner, tenant_id)
            evidence.ensure_anchor(owner, tenant_id)
            owner.commit()
    finally:
        owner.close()


def _endpoint_for(tenant_id: str) -> None:
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            if session.scalars(select(WebhookEndpoint)).first() is None:
                session.add(
                    WebhookEndpoint(
                        id=f"whe_pack_{tenant_id}",
                        url="https://example.invalid/hook",
                        secret="not a real secret",
                        events=["pack.staged", "pack.published"],
                        status="active",
                    )
                )
                session.commit()


@pytest.fixture(scope="module")
def three_firms():
    _make_tenant(FIRM_A, '{"jurisdictions": ["AU"]}')
    _make_tenant(FIRM_B, '{"jurisdictions": ["AU", "HK"]}')
    _make_tenant(FIRM_ELSEWHERE, '{"jurisdictions": ["SG"]}')
    for firm in (FIRM_A, FIRM_B, FIRM_ELSEWHERE):
        _endpoint_for(firm)
    return (FIRM_A, FIRM_B, FIRM_ELSEWHERE)


@pytest.fixture
def a_published_pack_event(three_firms):
    """A `pack.published` recorded the way the publish endpoint records it.

    Written from the publisher's own tenant, which is the whole point: that is
    where the old code's fan-out ended, and the firms below are not it.
    """
    with tenancy.acting_as(PUBLISHER_TENANT), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            row = pack_notices.record(
                session,
                event="pack.published",
                subject="AU v99",
                jurisdiction="AU",
                payload={"jurisdiction": "AU", "version": 99},
            )
            session.commit()
            return row.id


def _deliveries(tenant_id: str, event: str) -> list[WebhookDelivery]:
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            return list(
                session.scalars(
                    select(WebhookDelivery).where(WebhookDelivery.event == event)
                )
            )


def _fan_out(tenant_id: str) -> int:
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            sent = pack_notices.fan_out(session, tenant_id)
            session.commit()
            return sent


def test_two_subscribed_firms_are_told_and_the_publisher_is_in_neither(
    a_published_pack_event,
):
    """The finding, stated as the test it asks for."""
    before_a = len(_deliveries(FIRM_A, "pack.published"))
    before_b = len(_deliveries(FIRM_B, "pack.published"))

    assert _fan_out(FIRM_A) > 0
    assert _fan_out(FIRM_B) > 0

    assert len(_deliveries(FIRM_A, "pack.published")) > before_a
    assert len(_deliveries(FIRM_B, "pack.published")) > before_b


def test_a_firm_in_another_regime_is_not_told(a_published_pack_event):
    """An SG-only firm has no interest in an AU pack, and telling them anyway is
    how a customer learns to ignore our webhooks."""
    before = len(_deliveries(FIRM_ELSEWHERE, "pack.published"))
    _fan_out(FIRM_ELSEWHERE)
    assert len(_deliveries(FIRM_ELSEWHERE, "pack.published")) == before


def test_an_out_of_regime_event_is_not_reconsidered_for_ever(a_published_pack_event):
    """"Told" and "decided not to tell" are both answers, and both are recorded."""
    _fan_out(FIRM_ELSEWHERE)
    with tenancy.acting_as(FIRM_ELSEWHERE), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            assert pack_notices.pending(session, FIRM_ELSEWHERE) == []


def test_the_same_event_is_not_sent_twice(a_published_pack_event):
    """The worker runs on a schedule, so idempotence is not optional."""
    first = _fan_out(FIRM_A)
    second = _fan_out(FIRM_A)
    assert first > 0
    assert second == 0


def test_a_firm_cannot_see_another_firms_notices(a_published_pack_event):
    """`pack_event_notices` is tenant-scoped, and the policy is what says so."""
    _fan_out(FIRM_A)
    with tenancy.acting_as(FIRM_B), tenancy.acting_as_user(ACTOR):
        with SessionLocal() as session:
            visible = session.scalars(select(PackEventNotice)).all()
    assert all(n.tenant_id == FIRM_B for n in visible), (
        "one firm can read another firm's record of what it was told"
    )


def test_the_watch_role_cannot_announce_a_publication(a_published_pack_event):
    """The reason this is not one shared table with `source_breaches`.

    The watch role holds INSERT on `source_breaches` so the sweep can record
    what it saw. A single global-events table would have handed that same role
    the ability to tell every customer on the platform that the rules governing
    them had changed, which is the one thing §S6's separation exists to
    withhold.
    """
    from sqlalchemy.exc import ProgrammingError

    from app.db import WatchSessionLocal

    session = WatchSessionLocal()
    try:
        session.add(
            PackEvent(
                event="pack.published",
                subject="AU v100",
                jurisdiction="AU",
                payload={},
            )
        )
        with pytest.raises(ProgrammingError):
            session.commit()
    finally:
        session.rollback()
        session.close()
