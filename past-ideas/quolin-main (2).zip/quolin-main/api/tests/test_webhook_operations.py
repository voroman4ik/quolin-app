"""What an operator can do about a delivery that gave up.

§S9's webhook-storm runbook ends with "tell the customer their endpoint has been
failing, then replay the dead deliveries once they have fixed it". Both halves
needed a psql prompt until now — which is how an operator action at 3am ends up
performed by hand, with no record of who decided or what they replayed.

The delivery machinery itself was already real: signed, retried, dead-lettered.
What was missing was any way to see it or act on it without database access, and
a screen that claimed the compliance queue was `local` whether or not an
endpoint was configured.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from conftest import DEMO_TENANT
from sqlalchemy import select

from app import integrations, tenancy, webhooks
from app.db import SessionLocal
from app.models import AuditEvent, WebhookDelivery, WebhookEndpoint

ACTOR = "apc_bulk_sweep"


def _now() -> datetime:
    return datetime.now(timezone.utc)


@pytest.fixture
def endpoint(session):
    """A configured endpoint, removed afterwards.

    `webhook_endpoints` is not append-only — an endpoint is configuration a firm
    changes, not evidence — so this cleans up after itself.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        row = WebhookEndpoint(
            id="wep_test_operations",
            url="http://127.0.0.1:4999/hook",
            label="a test endpoint",
            secret="probe-secret-not-a-real-one",
            events=["decision.refer"],
            status="active",
        )
        session.merge(row)
        session.commit()
    yield row
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        # Deliveries first: they carry a foreign key to the endpoint, so
        # removing the endpoint underneath them is refused — which the database
        # said plainly the first time this ran. Neither table is append-only;
        # an endpoint is configuration a firm changes and a delivery attempt is
        # operational state, so both are removable, unlike the evidence tables.
        for delivery in session.scalars(
            select(WebhookDelivery).where(
                WebhookDelivery.endpoint_id == "wep_test_operations"
            )
        ):
            session.delete(delivery)
        stale = session.get(WebhookEndpoint, "wep_test_operations")
        if stale is not None:
            session.delete(stale)
        session.commit()


def _dead_delivery(session, endpoint_id: str) -> WebhookDelivery:
    delivery = WebhookDelivery(
        id=f"whd_test_{int(_now().timestamp() * 1000)}",
        endpoint_id=endpoint_id,
        event="decision.refer",
        subject="determination #1",
        payload={"event": "decision.refer"},
        status=webhooks.DEAD,
        attempts=webhooks.MAX_ATTEMPTS,
        last_status_code=500,
        last_error="HTTP 500",
        next_attempt_at=None,
    )
    session.add(delivery)
    session.flush()
    return delivery


def test_a_dead_delivery_can_be_put_back(session, endpoint):
    """The runbook's last step, as an action rather than an UPDATE."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        delivery = _dead_delivery(session, endpoint.id)
        webhooks.revive(session, delivery)

    assert delivery.status == webhooks.PENDING
    # The full backoff again: the customer says their endpoint is fixed, and a
    # revived delivery with the old count would get one more attempt and die,
    # which reads as "we tried" and is not trying.
    assert delivery.attempts == 0
    assert delivery.next_attempt_at is not None
    session.rollback()


def test_a_live_delivery_cannot_be_revived(session, endpoint):
    """Reviving something already queued would send a customer two of them.

    For an event that referred a client, a duplicate is a second case in their
    review queue — which is a real cost, not an aesthetic one.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        delivery = _dead_delivery(session, endpoint.id)
        delivery.status = webhooks.PENDING
        session.flush()

        with pytest.raises(ValueError) as refused:
            webhooks.revive(session, delivery)

    assert "not dead" in str(refused.value)
    session.rollback()


def test_redelivery_is_audited(client, session, endpoint):
    """Somebody decided to send it again, and the trail says who."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        delivery = _dead_delivery(session, endpoint.id)
        session.commit()
        delivery_id = delivery.id

    response = client.post(f"/webhooks/deliveries/{delivery_id}/redeliver")
    assert response.status_code == 200, response.text
    assert response.json()["status"] == webhooks.PENDING

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        probe = SessionLocal()
        try:
            recorded = probe.scalars(
                select(AuditEvent)
                .where(AuditEvent.action == "webhook.redeliver")
                .order_by(AuditEvent.id.desc())
                .limit(1)
            ).first()
        finally:
            probe.close()

    assert recorded is not None
    assert delivery_id in recorded.subject
    assert recorded.actor, "a redelivery with no name against it"


def test_reviving_a_delivered_one_is_refused_through_the_api(client, session, endpoint):
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        delivery = _dead_delivery(session, endpoint.id)
        delivery.status = webhooks.DELIVERED
        delivery.delivered_at = _now() - timedelta(hours=1)
        session.commit()
        delivery_id = delivery.id

    refused = client.post(f"/webhooks/deliveries/{delivery_id}/redeliver")
    # 409: the request is well formed and the delivery is real — what is wrong
    # is its state, and the caller's move is to look rather than to retry.
    assert refused.status_code == 409, refused.text


def test_the_console_can_see_what_was_sent(client, session, endpoint):
    """Without this, the runbook's first step needs database access."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        _dead_delivery(session, endpoint.id)
        session.commit()

    listed = client.get("/webhooks/deliveries?status=dead")
    assert listed.status_code == 200, listed.text
    body = listed.json()
    assert body["deliveries"], "a dead delivery was invisible to the console"
    assert body["dead"] >= 1

    # The payload is not in the list. It carries whatever the event carried —
    # for a determination, a client and an outcome — and a delivery list is a
    # screen an operator scans, not a place to read a customer's book.
    assert "payload" not in body["deliveries"][0]


def test_an_unknown_status_is_refused_rather_than_matching_nothing(client):
    """A typo'd filter that returned an empty list reads as "nothing is wrong"."""
    refused = client.get("/webhooks/deliveries?status=ded")
    assert refused.status_code == 422


def test_the_queue_is_reported_local_when_nothing_is_configured(session):
    """The honest state, and the one the screen used to assert unconditionally."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        edges = {row["id"]: row for row in integrations.describe(session)}

    queue = edges["compliance_queue"]
    assert queue["status"] == "local"
    assert "No endpoint is configured" in queue["detail"]


def test_the_queue_reads_live_once_an_endpoint_exists(session, endpoint):
    """The finding: this said `local` whether or not anything was configured.

    A deployment delivering webhooks perfectly well would have told its operator
    that nothing was posted outside it — wrong in the direction that matters,
    because the screen exists to say which edges are real.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        edges = {row["id"]: row for row in integrations.describe(session)}

    queue = edges["compliance_queue"]
    assert queue["status"] == "live"
    assert "posted to" in queue["detail"]
