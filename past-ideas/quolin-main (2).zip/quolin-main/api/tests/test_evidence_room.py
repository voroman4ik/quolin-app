"""A generator is not evidence that the control operated.

That was the sharpest line in the external review, and it was right. Every
drill, access review, game day and scan printed to stdout and vanished — proving
something to whoever was watching the terminal and nothing to anybody else. A
SOC 2 observation window is wall-clock, so the room has to start filling before
it is needed; there is no way to produce six months of history in the month
somebody asks for it.

What is asserted here is what the room can and cannot do. It can show that an
artefact was altered after it was filed, and it can show where the holes are
against a stated cadence. It cannot show that a run happened — somebody with
write access could author a convincing artefact — and the index says so in its
own output rather than leaving a reader to assume otherwise.
"""

from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from scripts import evidence_index, evidence_io  # noqa: E402


@pytest.fixture
def room(tmp_path) -> Path:
    out = tmp_path / "evidence"
    for category in evidence_io.CATEGORIES:
        (out / category).mkdir(parents=True)
    return out


def test_an_artefact_records_what_an_auditor_needs_to_place_it(room):
    """Not just the result: when, where, at which commit, and who ran it."""
    path = evidence_io.write(
        "drills",
        "restore-drill",
        {"seconds": 6.5, "chains": "verified"},
        passed=True,
        summary="Restored into a clean database and verified every chain.",
        out=room,
    )
    body = json.loads(path.read_text())

    for field in (
        "control",
        "ran_at",
        "environment",
        "git_sha",
        "invoked_by",
        "passed",
        "content_sha256",
    ):
        assert body.get(field) not in (None, ""), f"{field} is missing"

    # And a version a person can read without a parser. The reader of an
    # evidence room is often an auditor with no tooling and an afternoon.
    readable = path.with_suffix(".md")
    assert readable.exists()
    assert "restore-drill" in readable.read_text()


def test_the_environment_is_never_silently_omitted(room, monkeypatch):
    """A drill against a laptop and one against staging are different facts.

    The failure this prevents is the weaker one being read as the stronger,
    which is how a folder of local runs becomes a claim about production.
    """
    monkeypatch.delenv("QUOLIN_ENVIRONMENT", raising=False)
    local = json.loads(
        evidence_io.write("drills", "smoke-test", {}, out=room).read_text()
    )
    assert local["environment"] == "local"

    monkeypatch.setenv("QUOLIN_ENVIRONMENT", "staging")
    staged = json.loads(
        evidence_io.write("drills", "smoke-test", {}, out=room).read_text()
    )
    assert staged["environment"] == "staging"


def test_a_tampered_artefact_is_reported_rather_than_read(room):
    """The one thing the digest genuinely proves."""
    path = evidence_io.write(
        "drills", "restore-drill", {"chains": "verified"}, passed=True, out=room
    )
    body = json.loads(path.read_text())
    body["summary"] = "everything was fine, honestly"
    path.write_text(json.dumps(body, indent=2))

    ok, why = evidence_io.verify(path)
    assert not ok and "digest" in why

    index = evidence_index.build(room)
    assert index["damaged"], "an edited artefact was read as evidence"


def test_an_artefact_with_no_digest_cannot_be_checked_and_says_so(room):
    """A file dropped into the folder by hand is not silently accepted."""
    path = room / "drills" / "2026-01-01T00-00-00Z-restore-drill.json"
    path.write_text(json.dumps({"control": "restore-drill", "passed": True}))

    ok, why = evidence_io.verify(path)
    assert not ok
    assert "no digest" in why


def test_a_control_that_never_ran_is_a_named_gap(room):
    """An empty room is honest, and the index has to say what is missing from it.

    Reported rather than failed: a control that has not run is a fact about the
    programme and the person reading needs to see it, not have the report refuse
    to render.
    """
    index = evidence_index.build(room)
    never = {gap["control"] for gap in index["gaps"] if gap["why"] == "never run"}
    assert "restore-drill" in never
    assert "access-review" in never
    assert not index["damaged"]


def test_an_overdue_control_is_a_gap_even_though_it_has_history(room):
    """The failure a naive index misses: a control that quietly stopped.

    Cadence is checked against a stated expectation rather than inferred from
    the files, because a control's own history cannot be the standard it is
    measured against — one that stopped a year ago would look perfectly regular.
    """
    long_ago = datetime.now(timezone.utc) - timedelta(days=400)
    evidence_io.write(
        "drills", "restore-drill", {}, passed=True, out=room, now=long_ago
    )

    index = evidence_index.build(room)
    overdue = {
        gap["control"]: gap["days_overdue"]
        for gap in index["gaps"]
        if gap["why"] == "overdue"
    }
    assert "restore-drill" in overdue
    assert overdue["restore-drill"] > 300


def test_a_control_with_no_cadence_is_not_a_gap(room):
    """An empty incidents folder is good news, not a hole."""
    index = evidence_index.build(room)
    named = {gap["control"] for gap in index["gaps"]}
    assert "incident" not in named
    assert "pack-signature" not in named
    assert "rollback" not in named


def test_a_failed_run_is_named_rather_than_counted(room):
    """"Ran nine times" and "ran nine times and failed twice" are different rooms."""
    evidence_io.write("drills", "restore-drill", {}, passed=True, out=room)
    evidence_io.write("drills", "restore-drill", {}, passed=False, out=room)

    index = evidence_index.build(room)
    state = index["controls"]["restore-drill"]
    assert state["runs"] == 2
    assert len(state["failed_runs"]) == 1


def test_the_index_refuses_to_imply_more_than_it_can_show(room):
    """The overstatement this room exists to avoid, asserted as output."""
    index = evidence_index.build(room)
    assert "cannot show that a run happened" in index["statement"]


def test_an_unknown_category_is_refused(room):
    """A misspelled folder is evidence filed where nobody will look for it."""
    with pytest.raises(evidence_io.UnknownCategory):
        evidence_io.write("drils", "restore-drill", {}, out=room)


def test_the_index_exits_non_zero_on_a_damaged_room(room):
    """Run as the command line, because that is what a scheduler watches."""
    path = evidence_io.write("drills", "restore-drill", {}, passed=True, out=room)
    body = json.loads(path.read_text())
    body["passed"] = False
    path.write_text(json.dumps(body, indent=2))

    result = subprocess.run(
        [sys.executable, "-m", "scripts.evidence_index", "--room", str(room)],
        cwd=REPO,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 2, result.stdout + result.stderr
    assert "digest" in (result.stdout + result.stderr)


def test_gaps_alone_do_not_fail_the_index(room):
    """A room that has never been used still renders, and lists everything owed."""
    result = subprocess.run(
        [sys.executable, "-m", "scripts.evidence_index", "--room", str(room)],
        cwd=REPO,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert "never run" in result.stdout
