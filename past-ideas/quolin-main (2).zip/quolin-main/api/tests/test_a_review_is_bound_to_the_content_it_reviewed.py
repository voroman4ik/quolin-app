"""B1: an independent review attests to bytes, not to a moment.

Both Gate A follow-up audits found this independently, and one of them built the
sequence and ran it against a live database:

    author cuts a draft
      → an independent, qualified signatory records their read
      → the author edits the body
      → the author signs their own draft

    SIGNED_BY_AUTHOR: True · REVIEWER_STILL_SET · BODY_HAS_ATTACK: True

Migration 0049 persisted *who* performed the second review and *when*, and
`drafts.sign` asked only whether `second_reviewer_user_id` was populated — which
it still was. `pack_drafts_signature_is_independent` asked the same question of
the same three columns and was satisfied for the same reason. So the one act
that turns a proposal into rule content attested to content nobody but its
author had ever seen, and the row read as independently reviewed.

The principal it needs holds `operator` and `pack_signatory`: an operator may
edit a draft, a signatory may sign one. That pairing is the S5 workbench
workflow as the gate item itself describes it, not a corner case.

**The pattern already existed one function away.** `sign` records
`content_hash(draft.body)` and `publish` re-checks it, so an edit landing
between the signature and the publication is refused — F4,
`test_publish_verifies_the_signed_bytes.py`. Nothing mirrored it onto the window
before the signature, which is the same window with an earlier pair of eyes in
it. Migration 0050 adds `second_reviewed_content_hash` and applies the pattern.

**Three layers, and each of them is asserted here.**

`main.edit_draft` clears the review on any change to the body, so a stale one
never sits on the row looking valid. `drafts.sign` refuses when an author's own
signature leans on a review of different bytes, so a body moved by something
other than that route still cannot be signed. And
`pack_drafts_self_signature_reviewed_these_bytes` refuses the row, so a writer
that never went through Python is refused by Postgres — which is the half a
check in an editable file cannot give.

The sequence at the top of this docstring is what
`test_review_then_edit_then_the_author_signs_is_refused` runs, and it is the
test this file exists for.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from conftest import (
    DEMO_TENANT,
    SEED_PASSWORD,
    reset_rate_limit_for_tests,
    the_bytes_on_the_row,
    what_this_client_reads,
)
from fastapi.testclient import TestClient
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError

from app import identity, tenancy, totp
from app.db import OwnerSessionLocal
from app.main import app
from app.models import MfaCredential, PackDraft
from app.watch import drafts
from app.watch.lifecycle import content_hash

#: Far enough out that nothing signed here is ever the pack in force.
FAR_FUTURE = 3650

#: Their own accounts rather than the ones
#: `test_a_signature_is_not_the_authors_own.py` uses, so that a change to that
#: file's cast cannot quietly change what this one is testing.
AUTHOR_EMAIL = "b1.author@quolin.example"
REVIEWER_EMAIL = "b1.reviewer@quolin.example"
OTHER_SIGNATORY_EMAIL = "b1.other@quolin.example"

#: What the author adds to the body after the review. A threshold rather than a
#: note, because a note is metadata and a threshold is the number the engine
#: decides on — the difference between "the reviewer did not see this word" and
#: "the reviewer did not see this rule".
ATTACK_THRESHOLD = "max_crypto_concentration_bps"
ATTACK_VALUE = 9999


def _person(email: str, *roles: tuple[str, str]) -> str:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            user = identity.find_by_email(owner, email)
            if user is None:
                user = identity.create_user(owner, email=email, display_name=email)
            held = {(g.role, g.jurisdiction) for g in identity.roles_for(owner, user.id)}
            for role, jurisdiction in roles:
                if (role, jurisdiction) in held:
                    continue
                identity.grant_role(
                    owner,
                    user_id=user.id,
                    role=role,
                    jurisdiction=jurisdiction,
                    granted_by="test",
                    qualification_ref="[illustrative — no engagement in place]",
                )
            owner.commit()
            return str(user.id)
    finally:
        owner.close()


@pytest.fixture(scope="module")
def cast() -> dict[str, str]:
    """The author holds `operator` as well as `pack_signatory`, and that is the finding.

    `PATCH /watch/drafts/{id}` is an operator's act and `POST …/sign` is a
    signatory's, so the attack needs one principal holding both. The S5 gate
    item describes exactly that principal — "the AU specialist authoring and
    signing a real pack in the workbench" — which is why this is a workflow
    rather than a corner case.
    """
    return {
        "author": _person(AUTHOR_EMAIL, ("pack_signatory", "AU"), ("operator", "")),
        "reviewer": _person(REVIEWER_EMAIL, ("pack_signatory", "AU")),
        "other": _person(
            OTHER_SIGNATORY_EMAIL, ("pack_signatory", "AU"), ("operator", "")
        ),
    }


def _a_draft(session, *, title: str) -> PackDraft:
    return drafts.create(
        session,
        jurisdiction="AU",
        on=date.today(),
        effective_from=date.today() + timedelta(days=FAR_FUTURE),
        title=title,
        rationale="Written by tests/test_a_review_is_bound_to_the_content_it_reviewed.py",
        author="The Author",
    )


def _edit_the_body(draft: PackDraft) -> None:
    """Change the content, as the workbench's PATCH does.

    Assigned rather than mutated in place, because `PackDraft.body` is a JSON
    column and SQLAlchemy does not see a mutation of the dictionary it handed
    out. A test that mutated would flush nothing and pass while asserting the
    opposite of what it says.
    """
    body = dict(draft.body)
    body["thresholds"] = dict(body["thresholds"]) | {ATTACK_THRESHOLD: ATTACK_VALUE}
    draft.body = body


# ------------------------------------------------------------- the attack itself --


def test_review_then_edit_then_the_author_signs_is_refused(session, cast):
    """The sequence both audits found, and the regression test that matters.

    Nothing about this was tested before: `review → sign` had a test and
    `edit → sign` had a test, and the pair walked in that order did not. It is
    the same shape as the Stage 6 defect recorded in `drafts.sign`'s own comment
    — signing and submitting each had tests and nothing walked the pair.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Reviewed, then edited, then signed")
            session.flush()
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
                note="Read it.",
            )
            session.flush()

        reviewed_hash = draft.second_reviewed_content_hash
        assert reviewed_hash, "the review recorded no hash, so it binds to nothing"

        with tenancy.acting_as_user(cast["author"]):
            _edit_the_body(draft)
            session.flush()

            with pytest.raises(drafts.ReviewedBytesChanged) as raised:
                drafts.sign(
                    session,
                    draft.id,
                    signatory="The Author",
                    signed_content_hash=the_bytes_on_the_row(session, draft),
                )

        # Refused, and nothing written: not a signature that is later found to
        # be wrong, but a draft that was never signed.
        assert draft.signed_by_user_id is None
        assert draft.signed_at is None
        assert draft.status == drafts.DRAFT
        assert "has changed since" in str(raised.value)
        session.rollback()


def test_the_workbench_route_forgets_a_review_of_content_it_has_changed(session, cast):
    """The other half, and it is not an alternative to the check above.

    The hash is what makes the *signature* refuse. This is what stops a stale
    reviewer's name sitting on the row — on the draft view, in the workbench and
    in the table — reading as a review that covers what is there now.
    """
    from app.schemas import DraftEdit

    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Edited after review")
            session.flush()
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
            )
            session.flush()
        draft_id = int(draft.id)
        session.commit()

    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        edited = author.patch(
            f"/watch/drafts/{draft_id}",
            json=DraftEdit(
                thresholds=dict(draft.body["thresholds"])
                | {ATTACK_THRESHOLD: ATTACK_VALUE}
            ).model_dump(),
        )
    assert edited.status_code == 200, edited.text

    view = edited.json()
    assert view["second_reviewer_user_id"] is None, (
        "the review survived an edit to the content it was of. A review of "
        "superseded content is not a review."
    )
    assert view["second_reviewer"] == ""
    assert view["second_reviewed_at"] is None
    assert view["second_review_covers_this_body"] is False

    # Read on a fresh connection rather than through `session`, whose identity
    # map still holds the object this test created — the edit happened in the
    # route's own session, so asking the old one would answer from before it.
    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row is not None
        assert row.second_reviewed_content_hash is None
        assert row.second_reviewer_user_id is None
    finally:
        owner.close()
    session.rollback()


def test_the_database_refuses_a_self_signature_over_unreviewed_bytes(session, cast):
    """Past Python entirely, which is the half an editable file cannot give.

    `drafts.sign` is the rule written down;
    `pack_drafts_self_signature_reviewed_these_bytes` is the rule enforced.
    Written as the schema owner — the strongest actor this system has — because
    a CHECK constraint binds it exactly as it binds everybody else.

    The row is built to satisfy 0049's constraint in full: a reviewer who is
    neither the author nor the signer is recorded, which is precisely the state
    that used to be enough.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Refused by the server")
            session.flush()
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
            )
        session.commit()
        draft_id = int(draft.id)

    owner = OwnerSessionLocal()
    try:
        with pytest.raises(IntegrityError) as raised:
            owner.execute(
                text(
                    "UPDATE pack_drafts SET signed_by_user_id = created_by_user_id, "
                    "signed_by = 'The Author', signed_at = now(), "
                    "content_hash = 'a-different-body-entirely' WHERE id = :id"
                ),
                {"id": draft_id},
            )
            owner.flush()
        assert "pack_drafts_self_signature_reviewed_these_bytes" in str(raised.value)
    finally:
        owner.rollback()
        owner.close()


# --------------------------------------------------- and everything else still works --


def test_review_then_sign_with_nothing_touched_still_succeeds(session, cast):
    """The escape hatch, unchanged. A fix that closed it would close the regime
    with one specialist out of being able to change its own rules — which is not
    compliance, it is the specialist writing the draft and a colleague signing
    it having read nothing."""
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Reviewed and signed, untouched")
            session.flush()
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
            )
            session.flush()
        with tenancy.acting_as_user(cast["author"]):
            signed = drafts.sign(
                session,
                draft.id,
                signatory="The Author",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
        session.flush()

        assert signed.status == drafts.SIGNED
        assert signed.second_reviewer_user_id == cast["reviewer"]
        # The two hashes agree, which is what the constraint checks and what
        # makes the row's claim of independence true.
        assert signed.second_reviewed_content_hash == signed.content_hash
        assert drafts.view(signed)["second_review_covers_this_body"] is True
        session.rollback()


def test_an_edit_followed_by_a_fresh_review_signs_normally(session, cast):
    """The recovery path, and the reason this is an invalidation rather than a lock.

    A draft that could never be edited again after one review would push the
    work into a new draft each time somebody found a typo, and a mechanism that
    expensive is one people route around — which is the failure mode every
    refusal in this module is written to avoid.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Reviewed, edited, reviewed again")
            session.flush()
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
            )
            session.flush()
        with tenancy.acting_as_user(cast["author"]):
            _edit_the_body(draft)
            drafts.invalidate_second_review(draft)
            session.flush()
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
                note="Read it again.",
            )
            session.flush()
        with tenancy.acting_as_user(cast["author"]):
            signed = drafts.sign(
                session,
                draft.id,
                signatory="The Author",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
        session.flush()

        assert signed.status == drafts.SIGNED
        assert signed.second_reviewed_content_hash == content_hash(signed.body)
        assert signed.body["thresholds"][ATTACK_THRESHOLD] == ATTACK_VALUE
        session.rollback()


def test_a_signer_who_is_not_the_author_is_untouched_by_any_of_this(session, cast):
    """Two people is already two people, and needs no review to lean on.

    The ordinary §3.2 path: a draft signed by somebody other than its author
    involves two pairs of eyes without an escape hatch, so neither the hash nor
    its absence has anything to say about it. Asserted rather than assumed,
    because a check written into `sign` unconditionally would have made every
    ordinary signature depend on a column that is null on almost every row.
    """
    with tenancy.acting_as(DEMO_TENANT):
        with tenancy.acting_as_user(cast["author"]):
            draft = _a_draft(session, title="Signed by somebody else entirely")
            session.flush()
        with tenancy.acting_as_user(cast["reviewer"]):
            drafts.record_second_review(
                session,
                draft.id,
                reviewer_name="The Reviewer",
                reviewed_content_hash=content_hash(draft.body),
            )
            session.flush()
        # The body moves after the review, which is the state that refuses an
        # author's own signature and says nothing about anybody else's.
        with tenancy.acting_as_user(cast["author"]):
            _edit_the_body(draft)
            session.flush()
        with tenancy.acting_as_user(cast["other"]):
            signed = drafts.sign(
                session,
                draft.id,
                signatory="Another Signatory",
                signed_content_hash=the_bytes_on_the_row(session, draft),
            )
        session.flush()

        assert signed.status == drafts.SIGNED
        assert signed.signed_by_user_id == cast["other"]
        assert signed.content_hash == content_hash(signed.body)
        session.rollback()


# ------------------------------------------------------------------ over HTTP --


def _sign_in(client, email: str) -> None:
    """A signatory signed in, with a current second-factor code.

    Signing, reviewing and editing each demand a second factor and a credential
    presented in the last few minutes — an unattended screen must not be able to
    supply the independence that lets an author's own signature through.
    """
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user("apc_bulk_sweep"):
            user = identity.find_by_email(owner, email)
            assert user is not None
            identity.set_password(owner, user, SEED_PASSWORD)
            credential = owner.scalars(
                select(MfaCredential).where(MfaCredential.user_id == user.id)
            ).first()
            if credential is None:
                credential, _ = identity.enrol_totp(owner, user, label="test")
                owner.flush()
                identity.confirm_totp(
                    owner, credential, totp.code_at(str(credential.secret))
                )
            credential.last_used_counter = 0
            owner.commit()
            code = totp.code_at(str(credential.secret))
    finally:
        owner.close()

    res = client.post(
        "/auth/login", json={"email": email, "password": SEED_PASSWORD, "code": code}
    )
    assert res.status_code == 200, res.text


def test_the_attack_over_http_is_a_409_and_not_a_signature(cast):
    """The audit's executed sequence, through the only path a workbench has.

    One principal, holding `operator` and `pack_signatory`, doing four ordinary
    things in an order nobody had walked. The response is 409 rather than 403:
    the caller's grants are right and the door was the right door, and what is
    wrong is that this draft's bytes have moved since the review the signature
    would depend on.
    """

    reset_rate_limit_for_tests()
    with TestClient(app) as author:
        _sign_in(author, AUTHOR_EMAIL)
        cut = author.post(
            "/watch/drafts",
            json={
                "jurisdiction": "AU",
                "effective_from": (
                    date.today() + timedelta(days=FAR_FUTURE)
                ).isoformat(),
                "title": "The audit's sequence",
                "rationale": "Written by a test.",
            },
        )
        assert cut.status_code == 200, cut.text
        draft_id = int(cut.json()["id"])

        with TestClient(app) as reviewer:
            _sign_in(reviewer, REVIEWER_EMAIL)
            # F1. Read, then approve what was read.
            read = reviewer.get(f"/watch/drafts/{draft_id}")
            assert read.status_code == 200, read.text
            reviewed = reviewer.post(
                f"/watch/drafts/{draft_id}/second-review",
                json={
                    "note": "Read it.",
                    "reviewed_content_hash": read.json()["current_content_hash"],
                },
            )
        assert reviewed.status_code == 200, reviewed.text
        assert reviewed.json()["second_review_covers_this_body"] is True

        current = author.get(f"/watch/drafts/{draft_id}")
        assert current.status_code == 200, current.text
        thresholds = dict(current.json()["body"]["thresholds"])

        edited = author.patch(
            f"/watch/drafts/{draft_id}",
            json={"thresholds": thresholds | {ATTACK_THRESHOLD: ATTACK_VALUE}},
        )
        assert edited.status_code == 200, edited.text

        # The author reads the draft *as they edited it* and signs that, so the
        # refusal under test is about the review rather than about their screen.
        refused = author.post(
            f"/watch/drafts/{draft_id}/sign",
            json={
                "note": "Mine.",
                "signed_content_hash": what_this_client_reads(author, draft_id),
            },
        )

    assert refused.status_code == 409, refused.text
    # And the *reason* is the one the outer layer gives, which is worth being
    # precise about. Over HTTP the edit has already cleared the review, so what
    # the author meets is `SelfAuthoredSignature` — "there is no independent
    # read on this at all" — rather than `ReviewedBytesChanged`. Both are 409
    # and both refuse; the second is the layer that answers when a body moves
    # without going through this route, which is what
    # `test_review_then_edit_then_the_author_signs_is_refused` exercises
    # directly. Asserting the outer message here is what would catch the
    # invalidation being removed and the hash check being relied on alone.
    assert "somebody other than its author" in refused.json()["detail"]

    # And the row says so: no signature, and no reviewer left standing beside
    # content they did not read.
    owner = OwnerSessionLocal()
    try:
        row = owner.get(PackDraft, draft_id)
        assert row is not None
        assert row.signed_by_user_id is None
        assert row.second_reviewer_user_id is None
        assert row.status == drafts.DRAFT
    finally:
        owner.close()
