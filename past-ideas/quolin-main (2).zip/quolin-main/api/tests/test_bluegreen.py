"""A cutover that reports what it asked for is confidently wrong.

§S9 wants blue-green with instant rollback; §16 wants the rollback proven under
two minutes. The proof needs a deployed environment and is Part B. What is
testable here is the mechanism, and specifically the two places it lied while
being built — both times printing a success line over a system that had not
moved. `docs/runbooks/rollback.md` records both.

Nothing here needs Docker. The router and the containers are stubbed, because
what is under test is the ordering and the refusals, not nginx.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from scripts import deploy, evidence_io, rollback  # noqa: E402


@pytest.fixture
def active(tmp_path, monkeypatch) -> Path:
    """The one line the router reads, somewhere disposable."""
    path = tmp_path / "active.conf"
    path.write_text("upstream active { server api-blue:8000; }\n")
    monkeypatch.setattr(deploy, "ACTIVE", path)
    return path


@pytest.fixture
def room(tmp_path, monkeypatch) -> Path:
    out = tmp_path / "evidence"
    for category in evidence_io.CATEGORIES:
        (out / category).mkdir(parents=True)
    monkeypatch.setattr(evidence_io, "ROOM", out)
    return out


@pytest.fixture
def no_waiting(monkeypatch):
    """The gate and the confirmation both poll; nothing here should sleep."""
    monkeypatch.setattr(deploy.time, "sleep", lambda _s: None)


@pytest.fixture
def reloads(monkeypatch) -> list:
    """Record reload attempts instead of running docker."""
    calls: list[tuple] = []
    monkeypatch.setattr(deploy, "_compose", lambda *a, **k: calls.append(a))
    return calls


def _router(monkeypatch, answers) -> list[str]:
    """Stand in for every HTTP probe, and record what was asked.

    `answers` is a callable taking the URL and returning `(status, body)`.
    """
    asked: list[str] = []

    def fake(url: str, timeout: float = 3.0):
        asked.append(url)
        return answers(url)

    monkeypatch.setattr(deploy, "_ask", fake)
    return asked


def _artefacts(room: Path, control: str) -> list[dict]:
    return [
        json.loads(p.read_text())
        for p in sorted((room / "deployments").glob(f"*-{control}.json"))
    ]


# --- the health gate ----------------------------------------------------


def test_a_failing_health_check_blocks_the_cutover(
    active, room, no_waiting, reloads, monkeypatch, capsys
):
    """The whole reason to check before moving rather than after."""
    _router(monkeypatch, lambda url: (503, {}))
    monkeypatch.setattr(sys, "argv", ["deploy", "--to", "green", "--timeout", "1"])

    assert deploy.main() == 2
    assert not reloads, "the router was reloaded towards a revision that never answered"
    assert "api-blue" in active.read_text(), "traffic moved despite a failed gate"
    assert "still serving" in capsys.readouterr().err


def test_a_revision_answering_as_the_wrong_colour_is_refused(
    active, room, no_waiting, reloads, monkeypatch
):
    """A container still on the previous image answers like a healthy new one.

    Which is how a deploy silently does nothing: everything is green, and the
    code somebody thinks they shipped is not running anywhere.
    """
    _router(monkeypatch, lambda url: (200, {"status": "ok", "revision": "blue"}))
    monkeypatch.setattr(sys, "argv", ["deploy", "--to", "green", "--timeout", "1"])

    assert deploy.main() == 2
    assert not reloads
    assert "api-blue" in active.read_text()


def test_the_refusal_says_which_kind_of_failure_it_was(monkeypatch, no_waiting):
    """"Never answered" and "answered as the wrong revision" have different fixes."""
    _router(monkeypatch, lambda url: (200, {"revision": "blue"}))
    wrong = deploy.health_gate("green", port=8082, timeout=1)

    _router(monkeypatch, lambda url: (0, {}))
    silent = deploy.health_gate("green", port=8082, timeout=1)

    assert not wrong["healthy"] and "expected 'green'" in wrong["reason"]
    assert not silent["healthy"] and "answer" in silent["reason"]


def test_a_gate_failure_is_filed_as_a_run_that_did_not_pass(
    active, room, no_waiting, reloads, monkeypatch
):
    """A refusal is the control working, and an unrecorded refusal is not evidence."""
    _router(monkeypatch, lambda url: (503, {}))
    monkeypatch.setattr(
        sys, "argv", ["deploy", "--to", "green", "--timeout", "1", "--evidence-out"]
    )
    deploy.main()

    filed = _artefacts(room, "deploy")
    assert len(filed) == 1
    assert filed[0]["passed"] is False
    assert "never moved" in filed[0]["summary"]


# --- confirming that traffic actually moved ------------------------------


def test_a_cutover_is_not_reported_until_the_router_agrees(
    active, room, no_waiting, reloads, monkeypatch, capsys
):
    """The first defect: `nginx -s reload` returns before the reload happens.

    The script reported a completed cutover in 0.1s while the router was
    demonstrably still serving the old colour. A green deploy log over an
    unchanged system is worse than a failure, because nobody looks twice.
    """

    def answers(url: str):
        # The new colour is healthy on its own port; the router never comes
        # round, which is exactly the window that produced the false success.
        if "8082" in url:
            return 200, {"revision": "green"}
        return 200, {"revision": "blue"}

    _router(monkeypatch, answers)
    monkeypatch.setattr(
        sys, "argv", ["deploy", "--to", "green", "--timeout", "1", "--evidence-out"]
    )

    assert deploy.main() == 2, "reported a cutover the router had not performed"
    assert reloads, "the reload itself should still have been attempted"
    assert "still answering" in capsys.readouterr().err
    assert _artefacts(room, "deploy")[0]["passed"] is False


def test_one_good_answer_is_not_a_confirmation(monkeypatch, no_waiting):
    """The second defect, and the subtler one.

    A graceful reload runs new workers alongside old ones for a window, and both
    accept from the shared socket. Confirming on the first matching answer
    reported a 0.2s rollback whose very next request returned 504 from an old
    worker still trying the container that had just been stopped.
    """
    sequence = iter(
        [
            (200, {"revision": "green"}),  # a new worker
            (504, {}),  # an old one, still there
            (200, {"revision": "blue"}),  # and again
            (200, {"revision": "green"}),
            (200, {"revision": "green"}),
        ]
    )
    _router(monkeypatch, lambda url: next(sequence, (200, {"revision": "green"})))

    moved, serving = deploy.confirm("green", timeout=5, streak=3)
    assert moved and serving == "green"

    # The point: it kept asking past the first match. Two answers would have
    # been enough for the version that was wrong.
    short = iter([(200, {"revision": "green"}), (504, {})])
    _router(monkeypatch, lambda url: next(short, (504, {})))
    assert deploy.confirm("green", timeout=0.5, streak=3) == (False, "HTTP 504")


def test_a_deployment_that_reports_no_revision_is_still_usable(monkeypatch, no_waiting):
    """Refusing there would make the script unusable, not more careful."""
    _router(monkeypatch, lambda url: (200, {"status": "ok"}))
    assert deploy.confirm("green", timeout=2, streak=2) == (True, "unreported")


# --- rolling back --------------------------------------------------------


def test_a_rollback_restores_the_previous_revision(
    active, room, no_waiting, reloads, monkeypatch
):
    active.write_text("upstream active { server api-green:8000; }\n")
    _router(monkeypatch, lambda url: (200, {"revision": "blue"}))
    monkeypatch.setattr(sys, "argv", ["rollback"])

    assert rollback.main() == 0
    assert "api-blue" in active.read_text()
    assert reloads


def test_a_rollback_does_not_wait_on_a_health_check(
    active, room, no_waiting, reloads, monkeypatch
):
    """Deliberate, and the difference between this and a deploy.

    Only the router is asked, and only after the switch. Probing the target
    first would add the one thing a rollback cannot afford — and if the previous
    colour has also died, the answer is not to wait for it.
    """
    active.write_text("upstream active { server api-green:8000; }\n")
    asked = _router(monkeypatch, lambda url: (200, {"revision": "blue"}))
    monkeypatch.setattr(sys, "argv", ["rollback"])
    rollback.main()

    assert asked, "nothing was confirmed at all"
    assert all(deploy.ROUTER in url for url in asked), (
        "a rollback probed a container directly, which is a health gate by "
        "another name"
    )


def test_a_router_that_never_comes_back_is_reported_as_an_outage(
    active, room, no_waiting, reloads, monkeypatch, capsys
):
    active.write_text("upstream active { server api-green:8000; }\n")
    _router(monkeypatch, lambda url: (504, {}))
    monkeypatch.setattr(sys, "argv", ["rollback", "--evidence-out"])

    assert rollback.main() == 2
    assert "outage, not a bad deploy" in capsys.readouterr().err
    assert _artefacts(room, "rollback")[0]["passed"] is False


# --- what the artefact has to carry --------------------------------------


def test_the_elapsed_time_is_recorded(active, room, no_waiting, reloads, monkeypatch):
    """A rollback nobody measured is a claim."""
    active.write_text("upstream active { server api-green:8000; }\n")
    _router(monkeypatch, lambda url: (200, {"revision": "blue"}))
    monkeypatch.setattr(sys, "argv", ["rollback", "--evidence-out"])
    rollback.main()

    filed = _artefacts(room, "rollback")[0]["result"]
    assert isinstance(filed["seconds"], float)
    assert filed["target_seconds"] == rollback.TARGET_SECONDS
    assert filed["within_target"] is True


def test_the_artefact_says_which_environment_the_number_is_about(
    active, room, no_waiting, reloads, monkeypatch
):
    """The claim §16 cares about is not the one a laptop can support.

    A timing filed without an environment is a number somebody will quote at an
    assessor as though it came from production. `evidence_io` stamps it and
    `evidence_index.py` prints it beside every control for the same reason.
    """
    active.write_text("upstream active { server api-green:8000; }\n")
    _router(monkeypatch, lambda url: (200, {"revision": "blue"}))
    monkeypatch.setenv("QUOLIN_ENVIRONMENT", "compose")
    monkeypatch.setattr(sys, "argv", ["rollback", "--evidence-out"])
    rollback.main()

    filed = _artefacts(room, "rollback")[0]
    assert filed["environment"] == "compose"
    assert "not a rollback on production" in filed["summary"]


# --- refusals that stop a confusing outcome ------------------------------


def test_cutting_over_to_the_colour_already_serving_is_refused(
    active, room, no_waiting, reloads, monkeypatch
):
    """It would be a reload with a misleading name, and would file a deploy record."""
    monkeypatch.setattr(sys, "argv", ["deploy", "--to", "blue"])
    assert deploy.main() == 1
    assert not reloads
    assert not _artefacts(room, "deploy")


def test_an_unreadable_active_conf_is_an_error_rather_than_a_guess(active, monkeypatch):
    """Defaulting to a colour here would move traffic somewhere nobody chose."""
    active.write_text("upstream active { server api-teal:8000; }\n")
    with pytest.raises(RuntimeError) as refused:
        deploy.live_colour()
    assert "by hand" in str(refused.value)


def test_a_dry_run_changes_nothing(active, room, no_waiting, reloads, monkeypatch):
    _router(monkeypatch, lambda url: (200, {"revision": "green"}))
    monkeypatch.setattr(sys, "argv", ["deploy", "--to", "green", "--dry-run"])

    assert deploy.main() == 0
    assert not reloads
    assert "api-blue" in active.read_text()


# --- the compose stack the drill runs against ----------------------------


def test_each_colour_publishes_its_own_port():
    """A merge key nearly gave green blue's port, and two cannot bind one.

    The gate has to reach a container directly while the router still serves the
    other; sharing a port would mean it could only ever reach whichever came up.
    """
    compose = (REPO / "docker-compose.yml").read_text()
    assert '"8081:8000"' in compose and '"8082:8000"' in compose


def test_a_cutover_leaves_the_router_config_explaining_itself(
    active, monkeypatch, no_waiting, reloads
):
    """The first version wrote one bare line and deleted the committed comment.

    That file is committed so the router has something to start from, and a
    drill silently reduced it to `upstream active { ... }` — leaving whoever
    read the repository next with a line and no account of what maintains it.
    """
    _router(monkeypatch, lambda url: (200, {"revision": "green"}))
    monkeypatch.setattr(sys, "argv", ["deploy", "--to", "green"])
    deploy.main()

    written = active.read_text()
    assert "api-green:8000" in written
    assert "rollback.md" in written, "the cutover stripped the file's explanation"


def test_the_committed_router_config_is_what_a_cutover_would_write():
    """Otherwise the repository and the drill disagree from the first run."""
    committed = (REPO / "infra" / "compose" / "active.conf").read_text()
    assert committed == deploy.active_conf("blue")
