"""Rule content is global. Its change control was not.

`packs` is global by design and the design is right: every customer under a
licence should see the same AU rules, and copying content per tenant is how two
customers end up on different rules by accident.

But the publication path wrote to that global table and required `tenant_admin`
— a role held by a *customer's* administrator. So one firm's staff could put
rule content in front of every other firm on the platform. And
`pack_draft_transitions`, which records who moved that content through review,
is tenant-scoped: the customers who inherited the change could not see who made
it, or that it had been reviewed at all.

Two halves, and the fix is narrow on purpose.

**Publication becomes a Quolin act.** Drafting, editing, submitting, signing and
rejecting all stay inside the customer's tenant, because proposing and reviewing
a change is exactly what a firm's specialists should do. Only the last step —
putting content into a table every tenant reads — requires `quolin_operator`.

**And the history follows the content.** `pack_publications` is global and
append-only: one row per published pack, naming the firm the draft came from,
who signed it, who published it, and the content hash. A customer reading a rule
they did not write can now ask who did.

`packs` stays global. Making it tenant-scoped would break the property that
every customer under a licence sees the same rules, which is the right property
and the more important one.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest
from conftest import publish_through_the_api, the_bytes_on_the_row
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import rbac, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import ROLES, PackDraft, PackPublication
from tests.conftest import ADMIN_EMAIL, DEMO_TENANT, PUBLISHER_EMAIL, sign_in

ACTOR = "apc_bulk_sweep"
PUBLISH_ROUTE = ("POST", "/watch/drafts/{draft_id}/publish")

#: Far enough out that nothing published here is ever the pack in force.
FAR_FUTURE = 3650


@pytest.fixture(scope="module")
def quolin_operator() -> str:
    """The seeded account that may publish. Quolin's own, not the firm's.

    Seeded rather than created here, because the demo has to be walkable: if
    nobody in the seed could publish, the §14 workflow would end one step short
    of live content and the finding would have been traded for a different one.
    """
    from sqlalchemy import select as _select

    from app import identity
    from app.models import UserRole

    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            user = identity.find_by_email(owner, PUBLISHER_EMAIL)
            assert user is not None, (
                "the seed no longer creates a Quolin operator; nobody can publish"
            )
            held = {
                g.role
                for g in owner.scalars(
                    _select(UserRole).where(UserRole.user_id == user.id)
                )
            }
            assert "quolin_operator" in held, held
    finally:
        owner.close()
    return PUBLISHER_EMAIL


def _signed_draft() -> int:
    from app.watch import drafts

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            draft = drafts.create(
                session,
                jurisdiction="AU",
                on=date.today(),
                effective_from=date.today() + timedelta(days=FAR_FUTURE),
                title="For the publication-role tests",
                rationale="Written by a test.",
                author="The Publication Suite",
            )
            with tenancy.acting_as_user("user-some-signatory"):
                drafts.sign(
                    session,
                    draft.id,
                    signatory="A. Signatory",
                    signed_content_hash=the_bytes_on_the_row(session, draft),
                )
            session.commit()
            return int(draft.id)
        finally:
            session.close()


# ------------------------------------------------------------------- the role --


def test_the_role_exists_and_is_not_the_customer_side_operator() -> None:
    """Two roles, similar names, entirely different people.

    `operator` is a compliance officer inside a customer's firm who runs checks.
    `quolin_operator` is Quolin staff. Naming them apart matters because the
    whole of this finding is that one was standing in for the other.
    """
    assert "quolin_operator" in ROLES
    assert "operator" in ROLES


def test_publication_requires_a_quolin_operator() -> None:
    """The route table, read directly.

    Asserted here as well as through the API below, because the table is the
    thing a reviewer reads to answer "who may publish rule content" and a test
    that only exercised the endpoint would leave that answer implicit.
    """
    allowed = rbac.ROUTE_ROLES[PUBLISH_ROUTE]
    assert allowed == frozenset({"quolin_operator"}), allowed
    assert "tenant_admin" not in allowed, (
        "a customer's administrator may still publish to the global pack table"
    )


def test_a_customer_admin_cannot_publish() -> None:
    """The finding, through the API. `packs` is global; this person is not."""
    draft_id = _signed_draft()
    with TestClient(app) as admin:
        sign_in(admin, ADMIN_EMAIL)
        res = admin.post(f"/watch/drafts/{draft_id}/publish")

    assert res.status_code == 403, (
        f"a customer's tenant_admin published to the global pack table: "
        f"{res.status_code} {res.text}"
    )
    with tenancy.acting_as(DEMO_TENANT):
        session = SessionLocal()
        try:
            assert session.get(PackDraft, draft_id).published_pack_id is None
        finally:
            session.close()


def test_the_customer_still_owns_drafting_and_review() -> None:
    """The narrow part. Everything before publication stays inside the firm.

    A fix that moved the whole workflow to Quolin would have taken a customer's
    specialists out of reviewing their own regime's rules, which is worse than
    the problem.
    """
    for route, roles in (
        (("POST", "/watch/drafts"), {"operator", "approver"}),
        (("POST", "/watch/drafts/{draft_id}/sign"), {"pack_signatory"}),
    ):
        allowed = rbac.ROUTE_ROLES[route]
        assert set(allowed) >= roles, (route, allowed)
        assert "quolin_operator" not in allowed, (
            f"{route} now needs Quolin. Drafting and review belong to the firm."
        )


def _publish_it(draft_id: int):
    """Publish over HTTP with the second approval FP3-27 requires.

    The `quolin_operator` fixture below is still what these tests are about —
    Q-12's claim that publication is Quolin's act rather than a customer
    administrator's. FP3-27 adds that holding the role is not the same as
    holding the capability: the role is a tenant-scoped row and `packs` is
    global, so the act is gated on `platform_publishers` as well.
    """

    def _as(email: str):
        client = TestClient(app)
        client.__enter__()
        sign_in(client, email)
        return client

    return publish_through_the_api(_as, draft_id)


def test_a_quolin_operator_can_publish(quolin_operator) -> None:
    """And the workflow still completes, which is the point of the exercise."""
    draft_id = _signed_draft()
    res = _publish_it(draft_id)
    assert res.status_code == 200, res.text
    assert res.json()["pack_id"]


# ------------------------------------------------------ the history that follows --


def test_a_published_pack_records_who_moved_it_through_review(quolin_operator) -> None:
    draft_id = _signed_draft()
    published = _publish_it(draft_id).json()

    owner = OwnerSessionLocal()
    try:
        record = owner.get(PackPublication, int(published["pack_id"]))
    finally:
        owner.close()

    assert record is not None, "a pack was published with no global record of it"
    assert record.jurisdiction == "AU"
    assert record.signed_by == "A. Signatory"
    assert record.signed_by_user_id and record.published_by_user_id
    assert record.signed_by_user_id != record.published_by_user_id
    assert record.origin_tenant == DEMO_TENANT, (
        "the record does not name the firm whose staff moved this content"
    )
    assert record.content_hash


def test_a_second_tenant_can_read_that_history(quolin_operator) -> None:
    """The half a customer actually needs.

    `pack_draft_transitions` is tenant-scoped, correctly — one firm's workflow
    is not another's. But the *content* is shared, so the answer to "who put
    this rule in front of me" has to be shared too.
    """
    draft_id = _signed_draft()
    published = _publish_it(draft_id).json()
    pack_id = int(published["pack_id"])

    with tenancy.acting_as("neighbour"), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            seen = session.get(PackPublication, pack_id)
            transitions = session.scalars(
                select(PackDraft).where(PackDraft.id == draft_id)
            ).first()
        finally:
            session.close()

    assert seen is not None, (
        "a firm cannot see who published the rules it is being governed by"
    )
    assert seen.origin_tenant == DEMO_TENANT
    assert transitions is None, (
        "the neighbouring firm can read the demo firm's draft. One firm's "
        "workflow is still not another's — only the publication is shared."
    )


def test_the_record_is_append_only(quolin_operator) -> None:
    """It is evidence of a change to rules other people are governed by."""
    from sqlalchemy import text
    from sqlalchemy.exc import DBAPIError

    draft_id = _signed_draft()
    pack_id = int(_publish_it(draft_id).json()["pack_id"])

    owner = OwnerSessionLocal()
    try:
        with pytest.raises(DBAPIError):
            owner.execute(
                text("UPDATE pack_publications SET signed_by = 'somebody else' WHERE pack_id = :p"),
                {"p": pack_id},
            )
            owner.commit()
        owner.rollback()
    finally:
        owner.close()
