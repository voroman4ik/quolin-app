"""A client whose decision-relevant facts change gets re-checked.

§S8 names three things that re-check a book: a new pack version becoming
effective, a **client profile change**, and the scheduled periodic review. Two
of them are wired into `scripts/settle_packs.py`. The third was not wired to
anything.

`bulk.on_profile_change` existed, was documented, was unit-tested, and had zero
callers in `api/app` or `scripts` — the same shape as F1, where the advance
policy's read path was written and never connected. A function with no callers
does not re-check anybody's book.

**The trigger is a decision-relevant change, not any write.** An integration
re-sends its whole client list nightly; almost none of those rows have moved,
and planning a run for each would bury the handful that matter under thousands
that do not. F9 already computes exactly the right predicate for this — the
before/after diff over the columns the engine reads — so the run fires on the
same condition that writes the audit diff, and on nothing else.

A corrected spelling of somebody's name changes no determination and plans no
run. A `loss_capacity_band` moving from 2 to 5 changes several and plans one.
"""

from __future__ import annotations

import importlib
import uuid
from datetime import date

import pytest
from conftest import reset_rate_limit_for_tests
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import passwords, tenancy
from app.bulk import PROFILE_CHANGE
from app.db import OwnerSessionLocal, SessionLocal
from app.main import app
from app.models import ApiClient, EvalRun
from tests.conftest import DEMO_TENANT

ACTOR = "apc_bulk_sweep"
CREDENTIAL = "apc_profile_change_probe"
SECRET = "an integration secret, not a real one"


@pytest.fixture
def credential() -> str:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            row = owner.get(ApiClient, CREDENTIAL)
            if row is None:
                owner.add(
                    ApiClient(
                        id=CREDENTIAL,
                        label="Profile change probe",
                        secret_hash=passwords.hash_password(SECRET, email=CREDENTIAL),
                        roles=["operator", "viewer"],
                        status="active",
                        created_by="test",
                    )
                )
            else:
                row.secret_hash = passwords.hash_password(SECRET, email=CREDENTIAL)
                row.roles = ["operator", "viewer"]
                row.status = "active"
            owner.commit()
    finally:
        owner.close()
    return CREDENTIAL


@pytest.fixture
def api(credential) -> TestClient:

    reset_rate_limit_for_tests()
    machine = TestClient(app)
    token = machine.post(
        "/v1/oauth/token",
        json={
            "grant_type": "client_credentials",
            "client_id": credential,
            "client_secret": SECRET,
        },
    ).json()["access_token"]
    machine.headers["Authorization"] = f"Bearer {token}"
    return machine


@pytest.fixture
def client_id() -> str:
    """A new id per test. `clients` has no DELETE grant, so ids accumulate."""
    return f"profile-change-{uuid.uuid4().hex[:8]}"


def _body(client_id: str, **overrides) -> dict:
    body = {
        "id": client_id,
        "name": "A Client Whose Facts May Move",
        "scenario": "sterling",
        "jurisdiction": "AU",
        "dob": "1990-04-04",
        "client_category": "retail",
        "knowledge_assessed": True,
        "knowledge_date": "2026-02-01",
        "loss_capacity_band": 2,
        "vulnerability_flag": True,
        "assessable_portfolio_cents": 50_000_00,
        "prior_crypto_purchases": 2,
        "structural_acks": [],
        "default_trade_amount_cents": 1_000_00,
    }
    body.update(overrides)
    return body


def _runs_for(client_id: str) -> list[EvalRun]:
    """Profile-change runs naming this client, newest first.

    The note is matched **in SQL, before the limit**, and that ordering is the
    whole point. This used to take the newest forty profile-change runs of any
    kind and filter them in Python, so once the database held more than forty of
    them the ones this test cares about fell out of the window — and the
    symptom was `before + 1` failing because the run just created had pushed an
    older matching run out of the forty rather than added to them.

    The limit is gone rather than raised, because a raised limit is the same
    defect with a larger number in front of it — the matched set is bounded by
    the match, and every caller here counts rather than paginates.

    It passed for eleven stages and failed the first time the suite ran against
    a database with enough history, which is the same class of defect as every
    other one this fix-pack found: green because nothing had accumulated yet.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            return list(
                session.scalars(
                    select(EvalRun)
                    .where(
                        EvalRun.trigger == PROFILE_CHANGE,
                        EvalRun.note.contains(client_id),
                    )
                    .order_by(EvalRun.id.desc())
                )
            )
        finally:
            session.close()


def test_a_decision_relevant_change_plans_a_run(api, client_id) -> None:
    """The finding: §S8's third trigger, connected."""
    assert api.post("/v1/clients", json=_body(client_id)).status_code in (200, 201)
    assert _runs_for(client_id) == [], "creating a client planned a re-check"

    changed = api.post(
        "/v1/clients",
        json=_body(client_id, loss_capacity_band=5, vulnerability_flag=False),
    )
    assert changed.status_code in (200, 201), changed.text

    runs = _runs_for(client_id)
    assert runs, (
        "a client's loss capacity and vulnerability flag changed and nothing "
        "re-checked them. §S8 names a profile change as one of three triggers."
    )
    assert runs[0].pairs_total > 0, "the run covers no pairs"


def test_creating_a_client_plans_nothing(api, client_id) -> None:
    """There is no previous answer to re-check.

    A client's first determination is made when somebody asks for one, not by
    a sweep planned at the moment they were loaded.
    """
    assert api.post("/v1/clients", json=_body(client_id)).status_code in (200, 201)
    assert _runs_for(client_id) == []


def test_an_unchanged_resend_plans_nothing(api, client_id) -> None:
    """The property that keeps this usable.

    An integration re-sends its whole book nightly. If every unchanged row
    planned a run, the handful that matter would be buried under thousands that
    do not — and the queue would be doing thousands of re-checks a night to
    reach the same answers.
    """
    api.post("/v1/clients", json=_body(client_id))
    api.post("/v1/clients", json=_body(client_id))
    api.post("/v1/clients", json=_body(client_id))

    assert _runs_for(client_id) == [], "an unchanged re-send planned a re-check"


def test_a_cosmetic_change_plans_nothing(api, client_id) -> None:
    """A corrected spelling changes no determination, so it re-checks nothing."""
    api.post("/v1/clients", json=_body(client_id))
    api.post("/v1/clients", json=_body(client_id, name="A Corrected Spelling"))

    assert _runs_for(client_id) == [], "a name correction planned a re-check"


def test_the_run_is_scoped_to_that_client(api, client_id) -> None:
    """A profile change is not a reason to re-check nine thousand other people.

    The demo firm has a couple of hundred clients; a run planned for one of them
    must cover that one, and the pair count is how that is visible.
    """
    api.post("/v1/clients", json=_body(client_id))
    api.post("/v1/clients", json=_body(client_id, assessable_portfolio_cents=900_000_00))

    runs = _runs_for(client_id)
    assert runs, "no run was planned"

    from app.models import Asset

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            assets = len(list(session.scalars(select(Asset.id))))
        finally:
            session.close()

    assert runs[0].pairs_total <= assets, (
        f"a single client's profile change planned {runs[0].pairs_total} pairs "
        f"against {assets} assets — the run is not scoped to that client"
    )


def test_the_upsert_still_answers_normally(api, client_id) -> None:
    """Planning a run must not change what the endpoint returns.

    An integration that started seeing a different status code because we added
    a re-check would be a breaking change to a published contract.
    """
    created = api.post("/v1/clients", json=_body(client_id))
    assert created.status_code in (200, 201)
    assert created.json() == {"id": client_id, "created": True}

    updated = api.post("/v1/clients", json=_body(client_id, loss_capacity_band=4))
    assert updated.status_code in (200, 201)
    assert updated.json() == {"id": client_id, "created": False}


def test_the_other_two_triggers_are_still_wired(monkeypatch) -> None:
    """The reason this file exists, generalised.

    Two of §S8's three triggers were connected and one was not. A test that
    asserted only the third would not notice if one of the other two later
    became disconnected the same way.

    **Rewritten under Rule A.** This used to be

        settle = Path(".../settle_packs.py").read_text()
        assert "on_pack_effective" in settle

    and `settle_packs.py` contains the comment "See `bulk.on_pack_effective`."
    four lines above the call — so deleting the call and keeping the comment
    passed. That is the exact shape of test FP3-03 shipped behind.

    So the two targets are replaced with recorders and the module's real `main`
    is run. A name that appears only in a comment records nothing.

    `advance.sweep` is given one synthetic noticed row, because
    `on_pack_effective` fires only when a version actually becomes effective
    during a sweep and no ordinary test run makes one. Standing in for the
    input, not for the wiring: everything between that row and the trigger is
    the real code path.
    """
    import sys
    from dataclasses import dataclass
    from datetime import datetime, timedelta, timezone
    from pathlib import Path

    from app import advance, bulk

    # The repository root, so `scripts` is importable. The suite runs with
    # `api/` on the path; `scripts/` lives beside it.
    root = str(Path(__file__).resolve().parents[2])
    if root not in sys.path:
        sys.path.insert(0, root)

    settle = importlib.import_module("scripts.settle_packs")

    called: list[str] = []

    @dataclass
    class _Noticed:
        jurisdiction: str = "AU"
        pack_version: int = 1
        noticed_at: datetime = datetime.now(timezone.utc) + timedelta(seconds=5)

    monkeypatch.setattr(advance, "sweep", lambda *a, **k: [_Noticed()])
    monkeypatch.setattr(advance, "pending", lambda *a, **k: [])
    monkeypatch.setattr(
        bulk,
        "on_pack_effective",
        lambda *a, **k: called.append("on_pack_effective") or None,
    )
    monkeypatch.setattr(
        bulk, "periodic_due", lambda *a, **k: called.append("periodic_due") or []
    )
    monkeypatch.setattr(sys, "argv", ["settle_packs", DEMO_TENANT, "--json"])

    settle.main()

    assert "on_pack_effective" in called, "the pack-effective trigger lost its caller"
    assert "periodic_due" in called, "the periodic trigger lost its caller"


def test_the_seeded_book_is_unaffected(session) -> None:
    """The control: this fires on writes, not on reading what is already there."""
    assert date.today() is not None
    with tenancy.acting_as(DEMO_TENANT):
        assert session is not None


# --- the importer -----------------------------------------------------------
#
# The CSV importer is the other path that rewrites client facts, and it rewrites
# many at once. So it plans **one run over the changed subset** rather than one
# run per row: a firm re-loading a book of nine thousand where forty moved wants
# one re-check of forty, not forty runs, and certainly not nine thousand.
#
# The trigger condition is the same one the API path uses — the columns the
# engine actually reads — so a re-upload of an unchanged book plans nothing.

CSV_HEADER = (
    "id,scenario,name,dob,client_category,knowledge_assessed,knowledge_date,"
    "loss_capacity_band,vulnerability_flag,assessable_portfolio_cents,"
    "prior_crypto_purchases,structural_acks,default_trade_amount_cents,"
    "jurisdiction,residency,domicile"
)


def _csv_row(client_id: str, *, band: int = 3, portfolio: int = 5_000_000) -> str:
    return (
        f"{client_id},sterling,Imported Client,1990-01-01,retail,true,2026-01-15,"
        f"{band},false,{portfolio},2,,100000,AU,,"
    )


def _import(csv_text: str, *, commit: bool = True) -> dict:
    from tests.conftest import OPERATOR_EMAIL, sign_in

    with TestClient(app) as operator:
        sign_in(operator, OPERATOR_EMAIL)
        res = operator.post(
            "/import/clients", json={"csv_text": csv_text, "commit": commit}
        )
    assert res.status_code == 200, res.text
    return res.json()


def _import_runs() -> list[EvalRun]:
    """Profile-change runs planned by an import, newest first.

    Filtered in SQL before the limit, for the reason `_runs_for` above spells
    out at length: this is the helper the defect actually bit.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            return list(
                session.scalars(
                    select(EvalRun)
                    .where(
                        EvalRun.trigger == PROFILE_CHANGE,
                        EvalRun.note.contains("import"),
                    )
                    .order_by(EvalRun.id.desc())
                )
            )
        finally:
            session.close()


def _clients_covered(run: EvalRun) -> set[str]:
    from app.models import EvalChunk

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            covered: set[str] = set()
            for chunk in session.scalars(
                select(EvalChunk).where(EvalChunk.run_id == run.id)
            ):
                for client_id, _asset_id in chunk.pairs or []:
                    covered.add(client_id)
            return covered
        finally:
            session.close()


def test_an_import_that_changes_facts_plans_one_run_for_the_changed_rows() -> None:
    """The finding: the second write path did not fire the trigger at all."""
    first = f"import-change-a-{uuid.uuid4().hex[:8]}"
    second = f"import-change-b-{uuid.uuid4().hex[:8]}"
    untouched = f"import-change-c-{uuid.uuid4().hex[:8]}"

    _import(
        "\n".join(
            [CSV_HEADER, _csv_row(first), _csv_row(second), _csv_row(untouched)]
        )
        + "\n"
    )
    before = len(_import_runs())

    # Two rows move, one is re-sent exactly as it was.
    _import(
        "\n".join(
            [
                CSV_HEADER,
                _csv_row(first, band=5),
                _csv_row(second, portfolio=90_000_000),
                _csv_row(untouched),
            ]
        )
        + "\n"
    )

    runs = _import_runs()
    assert len(runs) == before + 1, (
        f"expected exactly one run for the changed subset, got "
        f"{len(runs) - before}. One run per changed row would give two."
    )

    covered = _clients_covered(runs[0])
    assert first in covered and second in covered, (
        f"the run does not cover both changed clients: {sorted(covered)}"
    )
    assert untouched not in covered, (
        "a row re-sent unchanged was re-checked anyway"
    )


def test_an_unchanged_reimport_plans_nothing() -> None:
    """Re-loading a book that has not moved is the common case."""
    client_id = f"import-same-{uuid.uuid4().hex[:8]}"
    csv = "\n".join([CSV_HEADER, _csv_row(client_id)]) + "\n"

    _import(csv)
    before = len(_import_runs())
    _import(csv)
    _import(csv)

    assert len(_import_runs()) == before, "an unchanged re-import planned a run"


def test_a_first_import_plans_nothing() -> None:
    """Creating clients is not a profile change; there is no previous answer."""
    csv = (
        "\n".join(
            [CSV_HEADER, _csv_row(f"import-new-{uuid.uuid4().hex[:8]}")]
        )
        + "\n"
    )
    before = len(_import_runs())
    _import(csv)
    assert len(_import_runs()) == before, "loading new clients planned a re-check"


def test_a_preview_plans_nothing() -> None:
    """`commit=false` is the preview. It must not have side effects."""
    client_id = f"import-preview-{uuid.uuid4().hex[:8]}"
    csv = "\n".join([CSV_HEADER, _csv_row(client_id)]) + "\n"

    _import(csv)
    before = len(_import_runs())
    _import("\n".join([CSV_HEADER, _csv_row(client_id, band=5)]) + "\n", commit=False)

    assert len(_import_runs()) == before, "a preview planned a run"


def test_a_refused_import_plans_nothing() -> None:
    """All-or-nothing: a file with a bad row writes nothing and re-checks nothing.

    The endpoint's own promise is that either the file is good and all of it
    lands, or none of it does. A run planned for rows that were never written
    would be a re-check of a state that does not exist.
    """
    client_id = f"import-bad-{uuid.uuid4().hex[:8]}"
    _import("\n".join([CSV_HEADER, _csv_row(client_id)]) + "\n")
    before = len(_import_runs())

    bad = _csv_row(client_id, band=5).replace(",retail,", ",not-a-category,")
    body = _import("\n".join([CSV_HEADER, bad]) + "\n")

    assert body["ok"] is False, "the bad row was accepted"
    assert len(_import_runs()) == before, "a refused import planned a run"
