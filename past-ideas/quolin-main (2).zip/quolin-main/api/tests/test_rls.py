"""Tenant isolation: the merge gate for this stage.

This is the file a diligence reader opens first, so it is written to be read.
The question it answers is "can one customer of yours reach another's data",
and it answers it four ways, in increasing order of how much has to be true:

1. The schema is shaped for isolation — every scoped table carries a tenant,
   has row-level security enabled *and forced*, and no table has quietly
   avoided being classified as one thing or the other.
2. A connection that has not said who it is sees nothing. Fail-closed, so the
   bug that leaks is a bug that returns zero rows rather than all of them.
3. With two customers actually in the database, neither can read the other's
   rows and neither can write a row stamped with the other's name — the second
   refused by Postgres rather than by application code.
4. Through the API, end to end, with a real session.

Stage 0 shipped this file with the assertions dormant, activated by the
appearance of a `tenants` table in the model metadata rather than by a flag
someone had to remember to flip. That trigger has fired; the skip conditions
stay because they cost nothing and they document how the gate was armed.
"""

from __future__ import annotations

from datetime import date, datetime, timezone

import pytest
from sqlalchemy import select, text

from app import crypto, evidence, identity, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.models import (
    PLATFORM_TABLES,
    TENANT_SCOPED_TABLES,
    Asset,
    Base,
    Client,
    Decision,
    MfaCredential,
    Tenant,
    User,
    UserRole,
)
from tests.conftest import DEMO_TENANT

#: Read off the models rather than copied. The list in `app/models.py` is the
#: one the migrations, the policies and the `tenant_id` columns are all written
#: from, and a second copy here would only ever be a second copy to go stale —
#: as it had, within one stage, by the time `chain_anchors` and `tenant_keys`
#: existed and this file had not heard of either.
TENANT_SCOPED = list(TENANT_SCOPED_TABLES)

#: The product's content and the tenant register itself, which are deliberately
#: not any one customer's. Packs are the clearest case: the same AU rules govern
#: every customer, and copying them per tenant is how two customers end up on
#: different rules by accident.
GLOBAL_TABLES = [
    "packs",
    "assets",
    "watch_sources",
    "watch_events",
    # Stage 6. What a model was asked about a publication and what it answered.
    # Global for the same reason `watch_events` is: the publication is the same
    # publication for every customer, and so is the reading of it. Scoping it per
    # tenant would mean asking the same question four times and keeping four
    # answers that must agree.
    "watch_assist_calls",
    "tenants",
    # §S12. Sign-in attempts: an address, a timestamp, and an account id when
    # the attempt resolved to one. Global rather than tenant-scoped because the
    # login endpoint is shared by every tenant on a shared deployment, and
    # because being tenant-scoped is precisely what stopped these rows being
    # written at all — the policy required a tenant, and `/auth/login` is the
    # one request that cannot have one. See migration 0022.
    #
    # Listed here rather than in PLATFORM_TABLES, and the distinction is real:
    # a platform table is invisible until a person is in scope, and this one is
    # not. It is checked by name below rather than by the blanket fail-closed
    # assertion, because a blanket claim it does not satisfy is worse than an
    # explicit statement of what it does.
    "auth_attempts",
    # FP3-03. A regulator's feed being dark, and which firms have been told.
    # Global because a source outage is a fact about a publisher, not about any
    # customer: one row is the observation, and every tenant's notification is
    # derived from it. Scoping them per tenant would mean one row per firm per
    # outage, all saying the same thing about the same website.
    #
    # Only the breach. `source_breach_notices` is tenant-scoped and lives in
    # TENANT_SCOPED_TABLES: it carries `tenant_id`, and the first draft of this
    # change listed it here — which this file refused, correctly. A table with a
    # tenant column and no policy is the shape every cross-tenant read has.
    "source_breaches",
    # FP3-08. A pack being staged or published is a fact about global rule
    # content, not about any customer: one row, and every firm's notification
    # derived from it. `pack_event_notices` — which firms were told — is
    # tenant-scoped and lives with the rest of their evidence.
    "pack_events",
    # FP3-27. Who at Quolin may put rule content in front of every customer, and
    # who agreed to each publication.
    #
    # `platform_publishers` is here for a reason that is the opposite of an
    # oversight: it has **no `tenant_id` column at all**, and that absence is
    # the control. A capability whose target is every tenant must not be
    # conferrable by a row belonging to one, so there is nothing for a
    # tenant-scoped policy to filter on and nothing a compromised firm's role
    # set can write. Only the schema owner may insert.
    "platform_publishers",
    "publication_approvals",
    # The pulse of a scheduled job: which worker, when it last ran, how many
    # firms it saw. Global because it is a fact about a process on the platform
    # rather than about a customer — and because the worker writing it is
    # deliberately between tenants at that moment, which is the whole reason
    # migration 0029 exists. Holds no customer data: a worker name, a
    # timestamp, a count and a one-word outcome.
    "worker_heartbeats",
    # Q-12. Who put a piece of global rule content in front of every customer:
    # regime, version, the firm the draft came from, the named signatory, and
    # the two accounts that signed and published it. Global because the content
    # it describes is global — a firm being governed by a rule it did not write
    # has to be able to ask who did. Holds no customer data.
    "pack_publications",
]

#: The third category, added in Stage 2. These hold people rather than customers
#: or content: no `tenant_id`, because one person may serve several firms, but
#: emphatically not global either, because a staff list is not shared content.
#: They are policed by reachability — visible where the acting firm has granted
#: that person a role — which means "enabled and forced" has to be true here for
#: exactly the reason it does on the tenant-scoped tables.
PLATFORM = list(PLATFORM_TABLES)

#: Every table the policies have to cover, which is what the schema-shape
#: assertions below iterate. `tenants` is in GLOBAL_TABLES but is policed by its
#: own primary key, and is checked separately in the isolation section.
POLICED = TENANT_SCOPED + PLATFORM

NEIGHBOUR = "neighbour"

TENANCY_LANDED = "tenants" in Base.metadata.tables

reason = "Stage 1 has not landed the tenant model yet; this suite activates with it"


def test_this_suite_is_actually_running() -> None:
    """Twenty-odd tests below are gated on `TENANCY_LANDED`, so it is asserted.

    Written during the Tier 2 skip audit. The gate was correct when Stage 1 was
    being built and has been true for thirteen stages, but its failure mode is
    that **the entire row-level-security suite disappears silently** — a run
    reporting "20 skipped" among sixteen hundred passes is not something anybody
    reads.

    So the condition has one test of its own that fails rather than skips. If
    `tenants` ever leaves the metadata, this says so in one line instead of the
    isolation suite quietly ceasing to exist.
    """
    assert TENANCY_LANDED, (
        "`tenants` is not in Base.metadata, so every row-level-security test in "
        "this file is being skipped. That is not a pass."
    )


@pytest.fixture
def neighbour():
    """A second customer with a client and a decision of its own.

    Committed rather than rolled back, because half of what follows reads it
    through a different session — and one of those sessions is the API's.
    `chain_anchors` and `decisions` both refuse DELETE, so this tenant stays in
    the dev and CI databases until `make seed` next rebuilds from empty. That is
    the isolation this stage exists to provide, demonstrating itself: nothing
    the demo shows can see it.
    """
    with tenancy.acting_as(NEIGHBOUR):
        session = OwnerSessionLocal()
        try:
            if session.get(Tenant, NEIGHBOUR) is None:
                session.add(
                    Tenant(
                        id=NEIGHBOUR,
                        name="Neighbour Wealth",
                        region="ap-southeast-2",
                    )
                )
                session.flush()
            evidence.ensure_anchor(session, NEIGHBOUR)
            crypto.ensure_key(session, NEIGHBOUR)
            if session.get(Client, "neighbour-client") is None:
                session.add(
                    Client(
                        id="neighbour-client",
                        scenario="probe",
                        name="Neighbour Client",
                        dob=date(1980, 1, 1),
                        client_category="RETAIL",
                        knowledge_assessed=False,
                        loss_capacity_band=1,
                        vulnerability_flag=False,
                        assessable_portfolio_cents=100_000,
                        default_trade_amount_cents=10_000,
                    )
                )
                session.flush()
            if not session.scalars(
                select(Decision).where(Decision.client_id == "neighbour-client")
            ).first():
                evidence.record(
                    session,
                    client_id="neighbour-client",
                    asset_id=session.scalars(select(Asset.id).order_by(Asset.id)).first(),
                    as_of=date(2026, 1, 1),
                    pack_id="AU",
                    pack_version=1,
                    snapshot={"neighbour": True},
                    evaluation={"rule_results": [], "rules_not_applicable": []},
                    outcome="BLOCK",
                    created_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
                )
            session.commit()
        finally:
            session.close()
    return NEIGHBOUR


# ------------------------------------------------------- 1. the schema shape --


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_every_tenant_scoped_table_carries_a_tenant_id() -> None:
    missing = [t for t in TENANT_SCOPED if "tenant_id" not in Base.metadata.tables[t].columns]
    assert not missing, f"tenant-scoped tables without tenant_id: {missing}"


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_every_table_is_classified_one_way_or_the_other() -> None:
    """The guard that catches the *next* table rather than the ones here now.

    A table added without a decision about whose data it holds is the way a
    leak gets introduced, and it does not announce itself: the new table simply
    has no policy and is readable by everyone. Adding one now fails this until
    somebody writes it down as one thing or the other.
    """
    unclassified = (
        set(Base.metadata.tables)
        - set(TENANT_SCOPED)
        - set(GLOBAL_TABLES)
        - set(PLATFORM)
    )
    assert not unclassified, (
        f"tables classified as none of the three: {sorted(unclassified)}. Add to "
        "TENANT_SCOPED_TABLES or PLATFORM_TABLES in app/models.py, or to "
        "GLOBAL_TABLES here with a reason."
    )


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_every_policed_table_has_row_level_security_enabled(session) -> None:
    """Enabled *and* forced, so the table owner is not silently exempt.

    Covers the platform tables as well as the tenant-scoped ones. They are
    protected by a different predicate — reachability rather than a `tenant_id`
    match — but the switch that makes any predicate apply is the same switch,
    and a platform table with row-level security merely enabled would be one an
    owning connection walked straight past.
    """
    rows = session.execute(
        text(
            "select relname, relrowsecurity, relforcerowsecurity "
            "from pg_class where relname = any(:names)"
        ),
        {"names": POLICED},
    ).all()
    state = {name: (enabled, forced) for name, enabled, forced in rows}

    unprotected = [t for t in POLICED if state.get(t) != (True, True)]
    assert not unprotected, f"row-level security not enabled and forced on: {unprotected}"


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_platform_tables_have_no_tenant_id() -> None:
    """The distinction that makes the third category a category.

    A `tenant_id` appearing here would mean somebody had quietly decided a
    person belongs to one firm — which reintroduces one login per firm, and with
    it the shared-credential problem Stage 2 exists to end.
    """
    scoped = [t for t in PLATFORM if "tenant_id" in Base.metadata.tables[t].columns]
    assert not scoped, f"platform tables that grew a tenant_id: {scoped}"


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_packs_stay_global() -> None:
    """A regression here would mean the content library had been cut up per customer."""
    leaked = [
        t
        for t in GLOBAL_TABLES
        if t != "tenants" and "tenant_id" in Base.metadata.tables[t].columns
    ]
    assert not leaked, f"global tables that grew a tenant_id: {leaked}"


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_sign_in_attempts_are_deployment_wide_and_say_so(session) -> None:
    """The one table here that is deliberately not isolated, asserted as such.

    §S12 moved login rate limiting out of process memory and into this table, so
    that the API could run more than one process — and found, doing it, that
    failed sign-ins had never been recorded anywhere: the row was going to
    `security_events`, which requires a tenant, from the one endpoint that
    cannot have one.

    Row-level security is still enabled and forced, and the policy still exists.
    What the policy says is `true`, and this test is here so that says so out
    loud: a table with security enabled and no policy denies everything, a table
    with neither can be widened by any later migration without anyone noticing,
    and this one is neither of those. It is a deliberate deployment-wide table
    with the decision written down in a policy.
    """
    enabled, forced = session.execute(
        text(
            "select relrowsecurity, relforcerowsecurity from pg_class "
            "where relname = 'auth_attempts'"
        )
    ).one()
    assert (enabled, forced) == (True, True), "security not enabled and forced"

    policies = session.execute(
        text("select count(*) from pg_policies where tablename = 'auth_attempts'")
    ).scalar_one()
    assert policies >= 1, "enabled and forced with no policy denies everything"

    # No email addresses, for the reason `security_events` gives: a table of
    # addresses people typed at a login form is a list of who might have an
    # account here.
    columns = set(Base.metadata.tables["auth_attempts"].columns.keys())
    assert "email" not in columns, "an address would make this a list of accounts"
    assert "tenant_id" not in columns, (
        "a tenant_id here would recreate the bug this table was made to fix"
    )


# ------------------------------------------------------------ 2. fail-closed --


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_a_request_without_a_tenant_setting_sees_nothing(session) -> None:
    """Fail-closed is the whole property: absent setting means zero rows, not all rows.

    Both settings are cleared, because the platform tables read the second one.
    A connection that has named neither a firm nor a person is the state a
    pooled connection is in between requests, and it must see an empty database.
    """
    session.execute(text("reset app.tenant_id"))
    session.execute(text("reset app.user_id"))
    try:
        for table in POLICED:
            count = session.execute(text(f"select count(*) from {table}")).scalar_one()
            assert count == 0, f"{table} served {count} rows with no tenant or user set"
    finally:
        # The reset above lasts for the rest of this transaction, and the
        # session fixture is shared. Ending the transaction is what puts the
        # tenant back — `app.tenant_id` is bound on `begin`, so the next
        # statement re-binds it. Without this, every later test in the run sees
        # an empty database and fails for a reason that has nothing to do with
        # what it was written to check.
        session.rollback()


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_the_application_role_cannot_bypass_any_of_this(session) -> None:
    """The single property everything above rests on, and the one you cannot see.

    `FORCE ROW LEVEL SECURITY` does not apply to a superuser, or to a role
    granted `BYPASSRLS`. Give the application either and every policy in the
    schema silently stops applying — no error, no warning, and a suite that
    reads through the owning connection would still be green.

    The owning role in development *is* a superuser, because it is the account
    docker-compose creates. That is exactly why the application connects as
    `quolin_app` instead, and why this asserts against the role the API
    actually holds rather than whichever one a test happened to open.
    """
    role, superuser, bypass = session.execute(
        text(
            "select current_user, rolsuper, rolbypassrls "
            "from pg_roles where rolname = current_user"
        )
    ).one()
    assert role == "quolin_app", f"the application is connecting as {role!r}"
    assert not superuser, "the application role is a superuser; every policy is inert"
    assert not bypass, "the application role has BYPASSRLS; every policy is inert"


# -------------------------------------------------- 3. two customers, at once --


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_neither_customer_can_read_the_other(neighbour, session) -> None:
    session.expire_all()
    assert session.get(Client, "neighbour-client") is None, (
        "the demo firm read a neighbour's client"
    )

    mine = set(session.scalars(select(Client.id)))
    assert mine, "the demo book is empty; this test would pass for the wrong reason"
    assert "neighbour-client" not in mine

    # As the application role, not the owning one. The owner in development is
    # the superuser docker-compose creates, and `FORCE ROW LEVEL SECURITY` does
    # not apply to a superuser — reading through it would show every tenant's
    # rows and prove nothing.
    with tenancy.acting_as(neighbour):
        theirs = SessionLocal()
        try:
            assert {c.id for c in theirs.scalars(select(Client))} == {"neighbour-client"}
        finally:
            theirs.close()


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_a_row_stamped_with_another_tenant_is_refused_by_the_database(neighbour, session) -> None:
    """Refused by Postgres, not by a check in the application.

    This is the assertion that distinguishes isolation from a convention. The
    insert names the neighbour explicitly and would satisfy every constraint the
    schema has apart from the policy's WITH CHECK — so what stops it is the
    database, in a session that has already authenticated as somebody else.
    """
    session.add(
        Client(
            id="smuggled",
            tenant_id=neighbour,
            scenario="probe",
            name="Smuggled",
            dob=date(1980, 1, 1),
            client_category="RETAIL",
            knowledge_assessed=False,
            loss_capacity_band=1,
            vulnerability_flag=False,
            assessable_portfolio_cents=1,
            default_trade_amount_cents=1,
        )
    )
    with pytest.raises(Exception, match="row-level security"):
        session.flush()
    session.rollback()


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_each_customer_has_a_chain_of_its_own(neighbour, session) -> None:
    """Two chains, each verifying, neither containing the other's records."""
    session.expire_all()
    mine = evidence.verify_chain(session)
    assert mine["verified"], mine

    with tenancy.acting_as(neighbour):
        theirs_session = SessionLocal()
        try:
            theirs = evidence.verify_chain(theirs_session)
        finally:
            theirs_session.close()

    assert theirs["verified"], theirs
    assert theirs["checked"] >= 1
    assert theirs["tip_hash"] != mine["tip_hash"]
    assert mine["checked"] > theirs["checked"], "the demo chain absorbed the neighbour's records"


# --------------------------------------------------------- 4. through the API --


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_the_api_serves_only_the_signed_in_tenant(neighbour, client) -> None:
    """Everything above, as a caller experiences it.

    The deployment serves one tenant, so a signed-in session is the demo firm
    and there is no header that could make it anybody else. That is the point:
    the neighbour's client is not merely filtered out of the list, it is not
    addressable.
    """
    ids = {c["id"] for c in client.get("/clients").json()}
    assert ids, "the API returned no clients; this test would pass for the wrong reason"
    assert "neighbour-client" not in ids

    assert client.get("/clients/neighbour-client").status_code == 404


# -------------------------------------------------------------- 5. the people --

#: A member of the demo firm's staff, created once and left in place.
STAFF_ID = "rls-probe-user"
STAFF_EMAIL = "rls-probe@example.invalid"


@pytest.fixture
def staff(neighbour):
    """One person, holding one role, at the demo firm.

    Written through the owner because provisioning a user is administration
    rather than a request — but still inside both scopes, because the owner is
    forced by the policies too and an insert that named no acting user would be
    refused. Depends on `neighbour` so that the firm this person is *not* a
    member of exists to be tested against.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(STAFF_ID):
        session = OwnerSessionLocal()
        try:
            if session.get(User, STAFF_ID) is None:
                session.add(
                    User(id=STAFF_ID, email=STAFF_EMAIL, display_name="Probe Officer")
                )
                session.flush()
                session.add(
                    UserRole(
                        id=f"{STAFF_ID}-operator",
                        tenant_id=DEMO_TENANT,
                        user_id=STAFF_ID,
                        role="operator",
                        # Named, not "bootstrap". That word is reserved for the
                        # seed creating a firm's first administrator, where there
                        # is genuinely nobody to attribute the grant to — see
                        # `identity.BOOTSTRAP`.
                        granted_by="test",
                    )
                )
                session.add(
                    MfaCredential(
                        id=f"{STAFF_ID}-totp",
                        user_id=STAFF_ID,
                        secret="JBSWY3DPEHPK3PXP",
                    )
                )
            session.commit()
        finally:
            session.close()
    return STAFF_ID


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_a_firm_sees_the_people_it_has_granted_a_role_to(staff, session) -> None:
    """Reachability, which is what stands in for a `tenant_id` on `users`."""
    session.expire_all()
    person = session.get(User, staff)
    assert person is not None, "the demo firm cannot see its own staff"
    assert person.display_name == "Probe Officer", "the sealed name did not round-trip"


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_another_firm_cannot_see_them(staff) -> None:
    """The disclosure the third category exists to prevent.

    A staff list is not shared content. The neighbour has granted this person
    nothing, so as far as its connection is concerned they do not exist — not
    filtered from a list, absent from the table.
    """
    with tenancy.acting_as(NEIGHBOUR):
        theirs = SessionLocal()
        try:
            assert theirs.get(User, staff) is None, "a firm read another firm's staff"
            assert theirs.get(MfaCredential, f"{staff}-totp") is None
            assert theirs.scalars(select(UserRole).where(UserRole.user_id == staff)).all() == []
        finally:
            theirs.close()


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_sign_in_can_find_a_user_before_it_knows_the_tenant(staff, session) -> None:
    """The bootstrap, and the fact that it is exactly one row wide.

    Resolving an address to a person is the step that *decides* both the user
    and the tenant, so it cannot be filtered by either. What makes that safe is
    that the setting names one address: with it in force, the table holds one
    visible row, and it is the row the caller already named.
    """
    session.execute(text("reset app.tenant_id"))
    session.execute(text("reset app.user_id"))
    try:
        assert session.scalars(select(User.id)).all() == [], (
            "users were visible with neither setting in force"
        )

        session.execute(
            text("select set_config('app.login_email', :email, true)"),
            {"email": STAFF_EMAIL},
        )
        assert session.scalars(select(User.id)).all() == [staff]
    finally:
        session.rollback()


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_the_sign_in_bootstrap_cannot_write(staff, session) -> None:
    """Read-only, so knowing an address is not a way to mint an account."""
    session.execute(text("reset app.tenant_id"))
    session.execute(text("reset app.user_id"))
    try:
        session.execute(
            text("select set_config('app.login_email', :email, true)"),
            {"email": STAFF_EMAIL},
        )
        with pytest.raises(Exception, match="row-level security"):
            session.execute(
                text(
                    "insert into users (id, email, display_name, status, created_at) "
                    "values ('planted', :email, '\\x00'::bytea, 'active', now())"
                ),
                {"email": STAFF_EMAIL},
            )
    finally:
        session.rollback()


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_a_firm_cannot_grant_a_role_inside_another_firm(staff, session) -> None:
    """Refused by Postgres, in a connection that is already authenticated.

    `user_roles` carries the widening this schema makes on purpose — a person
    reads their own grants across every tenant — and this is the assertion that
    the widening is read-only. If it were not, knowing your own user id would be
    a way to grant yourself a role at somebody else's firm.
    """
    session.add(
        UserRole(
            id="smuggled-grant",
            tenant_id=NEIGHBOUR,
            user_id=staff,
            role="tenant_admin",
            granted_by="probe",
        )
    )
    with pytest.raises(Exception, match="row-level security"):
        session.flush()
    session.rollback()


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_a_second_factor_is_never_stored_in_the_clear(staff, session) -> None:
    """What a firm can see is that a factor exists, not what it is.

    Read through the application role and off the raw column, not through the
    model, because the model would decrypt it and prove nothing.
    """
    session.expire_all()
    raw = session.execute(
        text("select secret from mfa_credentials where id = :id"),
        {"id": f"{staff}-totp"},
    ).scalar_one()
    assert isinstance(raw, (bytes, memoryview)), "the second factor is not stored as bytes"
    assert b"JBSWY3DPEHPK3PXP" not in bytes(raw), "the second factor is stored in the clear"


# ------------------------------------------------------------- the guard rail --


def test_the_placeholder_cannot_sleep_through_stage_one() -> None:
    """The guard on the guard.

    If `tenants` exists, the tests above must be running rather than skipping.
    If it does not, this test records that the suite is deliberately dormant so
    that a green CI run is not mistaken for isolation having been proven.
    """
    if TENANCY_LANDED:
        assert TENANT_SCOPED, "tenant model landed but no tables are declared tenant-scoped"
    else:
        assert "clients" in Base.metadata.tables, "schema moved; this suite needs rewriting"


@pytest.mark.skipif(not TENANCY_LANDED, reason=reason)
def test_a_grant_in_another_firm_does_not_open_this_one(session) -> None:
    """§S12's find, and the worst bug this repository has had.

    A person whose only role grant was in another firm signed in to this
    deployment, was handed that role, and every screen then showed them this
    firm's book. Found by the load model, which was the first thing to create a
    person who belongs to one tenant and point them at a deployment serving
    another — the demo has only ever had one firm's staff.

    The mechanism is the one this repository has now been taught five times.
    `app.tenant_id` binds when a transaction *begins*. By the time sign-in asks
    "does this person hold a grant here", a transaction is already open —
    `authenticate` opened it to read the user — so entering the tenancy context
    afterwards does not rebind the setting, the policy was evaluated against
    whatever the pooled connection last held, and it returned somebody else's
    grant.

    `identity.roles_for` now filters by tenant explicitly as well. Row-level
    security is still on and still forced; this is the second lock, on the one
    query whose answer decides who may act.
    """
    # Created through the real path rather than by raw SQL. The first version
    # inserted the row by hand and wrote a plaintext address into an encrypted
    # column, which the access review then failed to decrypt two test files
    # later — "ciphertext does not begin with a known format byte". A fixture
    # that writes rows the application could not have written tests a database
    # this application does not have.
    email = "grant.elsewhere@example.invalid"
    with tenancy.acting_as(NEIGHBOUR), tenancy.acting_as_user(STAFF_ID):
        owner = OwnerSessionLocal()
        try:
            existing = identity.find_by_email(owner, email)
            outsider = (
                existing
                or identity.create_user(owner, email=email, display_name="Grant Elsewhere")
            ).id
            if not identity.roles_for(owner, outsider):
                identity.grant_role(
                    owner, user_id=outsider, role="operator", granted_by="test"
                )
            owner.commit()
        finally:
            owner.close()

    # The condition the bug actually needs, reproduced deliberately.
    #
    # The first version of this test rolled back first and then asked under
    # `demo`, so the next statement began a fresh transaction bound to demo and
    # row-level security hid the grant on its own — it passed with the fix
    # removed, which makes it a test of nothing. What sign-in does is open a
    # transaction (to read the user) and *then* enter the tenancy context, and
    # `app.tenant_id` binds on begin, so the policy is still evaluated against
    # whatever the connection last held.
    #
    # So: open a transaction under the neighbour, and without ending it, ask the
    # question as `demo` would.
    session.rollback()
    with tenancy.acting_as(NEIGHBOUR):
        session.execute(text("select 1"))  # binds app.tenant_id to the neighbour

    with tenancy.acting_as(DEMO_TENANT):
        held = identity.roles_for(session, outsider)

    assert held == [], (
        "a grant in another firm was accepted here — this is the check that "
        "stops one customer's staff signing in to another customer's "
        "deployment, and the transaction was deliberately left bound to the "
        "other firm because that is the state sign-in is in when it asks"
    )

    # And the grant is still real where it was actually made, so the assertion
    # above is about scoping rather than about the row having failed to exist.
    session.rollback()
    with tenancy.acting_as(NEIGHBOUR):
        held_there = identity.roles_for(session, outsider)

    # Ends the transaction this test left bound to the neighbour. The session
    # fixture is shared, `app.tenant_id` binds on `begin`, and a test that walks
    # away with another firm in scope makes the next twenty tests fail for a
    # reason that has nothing to do with what they check. The fail-closed test
    # above this one carries the same note for the same reason.
    session.rollback()
    assert held_there, "the grant itself was not written"
