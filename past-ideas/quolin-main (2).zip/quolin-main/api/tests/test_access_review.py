"""The quarterly access review, and the questions it has to be able to ask.

The execution document is specific that the SOC 2 control is *the report being
generated and signed off*. That makes two different things worth testing, and
they are separated below.

`examine` is the judgement — given a roster, which grants should somebody be
asked about. It is a pure function over plain objects, so every case it is meant
to catch is constructible in three lines, including the ones no seeded database
happens to contain: a suspended account that still holds access, support access
with no expiry, a grant naming a user nobody can resolve.

`collect` is the reading — and the only thing worth testing there is that it
reads through the tenant's own policies rather than around them, because a
report assembled by a connection that bypassed row-level security would prove
nothing about row-level security. So that half runs against the real seeded
database, as the application role, with a tenant in scope.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from conftest import APPROVER_EMAIL, DEMO_TENANT, OPERATOR_EMAIL, SIGNATORY_EMAIL
from sqlalchemy import select

from app import access_review, identity, tenancy
from app.access_review import Credential, Grant, Person
from app.models import UserRole

NOW = datetime(2026, 8, 24, 12, 0, tzinfo=timezone.utc)


def _grant(role: str, **kw) -> Grant:
    return Grant(
        role=role,
        jurisdiction=kw.get("jurisdiction", ""),
        qualification_ref=kw.get("qualification_ref", "ASIC RG 146"),
        granted_at=kw.get("granted_at", NOW - timedelta(days=400)),
        granted_by=kw.get("granted_by", "usr_admin"),
        expires_at=kw.get("expires_at"),
    )


def _person(*roles: Grant, **kw) -> Person:
    return Person(
        user_id=kw.get("user_id", "usr_test"),
        email=kw.get("email", "someone@quolin.example"),
        display_name=kw.get("display_name", "Someone"),
        status=kw.get("status", "active"),
        grants=list(roles),
        methods=kw.get("methods", ["password"]),
        second_factors=kw.get("second_factors", 1),
        last_sign_in=kw.get("last_sign_in"),
        last_action_at=kw.get("last_action_at", NOW - timedelta(days=1)),
        actions=kw.get("actions", 12),
    )


def _kinds(people: list[Person], **kw) -> set[str]:
    found = access_review.examine(
        people, when=NOW, inactive_days=kw.get("inactive_days", 90)
    )
    return {f.kind for f in found}


# ------------------------------------------------------------- the judgement --


def test_an_ordinary_active_person_produces_no_findings():
    """The negative that makes every other test in this file mean something.

    A report that flagged everybody would satisfy each assertion below and be
    worthless: a reviewer who has learned that every line is noise reads none of
    them.
    """
    assert _kinds([_person(_grant("operator"))]) == set()


def test_a_suspended_account_that_still_holds_access_is_raised():
    """Not an open door, and still the thing a review exists to find.

    Sign-in checks status, so this person cannot get in today. The grant matters
    because the account is not deleted — deleting it would orphan the audit rows
    naming it — so it sits there waiting for whoever reactivates it.
    """
    assert "inactive_account_with_access" in _kinds(
        [_person(_grant("approver"), status="suspended")]
    )


def test_holding_both_halves_of_a_two_person_rule_is_raised_without_being_called_a_breach():
    """The engine refuses the act; the review asks about the arrangement.

    Two different jobs, and conflating them would be wrong in both directions —
    reporting nothing would hide how much weight the runtime check is carrying,
    and reporting a breach would be false, because there is not one.
    """
    found = access_review.examine(
        [_person(_grant("operator"), _grant("approver"))], when=NOW, inactive_days=90
    )
    conflict = next(f for f in found if f.kind == "separation_of_duties")
    assert conflict.severity == "review"
    assert "still refuses" in conflict.detail


def test_the_conflict_is_not_raised_when_one_of_the_two_roles_has_lapsed():
    """An expired grant is not access, and a review that said otherwise would
    send somebody to remove a role that is already gone."""
    kinds = _kinds(
        [
            _person(
                _grant("operator"),
                _grant("approver", expires_at=NOW - timedelta(days=1)),
            )
        ]
    )
    assert "separation_of_duties" not in kinds
    assert "lapsed_grants" in kinds


def test_support_access_without_an_expiry_is_the_loudest_finding():
    """The execution document requires `quolin_support` to be time-boxed.

    Nothing enforces that at grant time, so the review is where it is checked —
    and an unbounded grant of our own staff's access into a customer's tenant is
    the single finding most worth a reviewer's attention.
    """
    unbounded = access_review.examine(
        [_person(_grant("quolin_support"))], when=NOW, inactive_days=90
    )
    bounded = access_review.examine(
        [_person(_grant("quolin_support", expires_at=NOW + timedelta(days=3)))],
        when=NOW,
        inactive_days=90,
    )
    assert next(f for f in unbounded if f.kind == "support_access").severity == "attention"
    # Still reported when it is bounded. The point is that a person outside the
    # firm can read their records, which is worth a sentence either way.
    assert next(f for f in bounded if f.kind == "support_access").severity == "review"


def test_a_signatory_with_no_recorded_qualification_is_raised():
    """The signature prints this field, so an empty one is a signature that says
    nothing about why it can be relied on."""
    assert "signatory_without_qualification" in _kinds(
        [_person(_grant("pack_signatory", jurisdiction="AU", qualification_ref=""))]
    )


def test_access_nobody_has_ever_used_is_distinguished_from_access_gone_quiet():
    """Two different conversations. "They never started" and "they have moved on"
    lead a reviewer to ask different people."""
    never = _kinds([_person(_grant("viewer"), last_action_at=None, actions=0)])
    quiet = _kinds([_person(_grant("viewer"), last_action_at=NOW - timedelta(days=200))])
    assert never == {"never_used"}
    assert quiet == {"inactive"}


def test_the_inactivity_window_is_the_one_the_caller_asked_for():
    person = _person(_grant("viewer"), last_action_at=NOW - timedelta(days=45))
    assert "inactive" not in _kinds([person], inactive_days=90)
    assert "inactive" in _kinds([person], inactive_days=30)


def test_a_grant_naming_somebody_this_tenant_cannot_resolve_is_raised_alone():
    """The worst row in the table, and it stops the rest of the checks.

    A grant pointing at a user this tenant cannot see is either a removed
    account — which should not happen — or a grant that belongs to a different
    firm. Either way, running the remaining checks against a person with no
    attributes would produce a page of findings about nothing.
    """
    orphan = _person(_grant("approver"), status="unresolvable", email="", methods=[])
    assert _kinds([orphan]) == {"grant_names_nobody"}


def test_a_missing_second_factor_is_raised_only_where_a_password_is_in_play():
    """Where the firm's provider authenticates, its second-factor policy is not
    visible here — and reporting our own ignorance as somebody's failing is
    exactly the kind of finding that teaches a reviewer to skim."""
    assert "no_second_factor" in _kinds(
        [_person(_grant("approver"), second_factors=0, methods=["password"])]
    )
    assert "no_second_factor" not in _kinds(
        [
            _person(
                _grant("approver"),
                second_factors=0,
                methods=["oidc via https://idp.example"],
            )
        ]
    )


def test_a_missing_second_factor_is_not_raised_for_roles_that_do_not_demand_one():
    assert "no_second_factor" not in _kinds(
        [_person(_grant("viewer"), second_factors=0, methods=["password"])]
    )


def test_findings_are_ordered_by_how_much_they_want_attention():
    found = access_review.examine(
        [
            _person(_grant("viewer"), email="quiet@x.example", last_action_at=None),
            _person(
                _grant("approver"),
                email="suspended@x.example",
                status="suspended",
                second_factors=0,
            ),
        ],
        when=NOW,
        inactive_days=90,
    )
    assert [f.severity for f in found] == sorted(
        (f.severity for f in found), key=access_review.SEVERITIES.index
    )
    assert found[0].severity == "attention"


# ---------------------------------------------------------------- the reading --


#: A second firm on the same deployment. `test_rls.py` creates one too and
#: leaves it in place, but this file does not depend on that suite having run —
#: a cross-tenant isolation test whose second tenant exists only when another
#: file ran first is a test that silently passes by having nothing to compare.
NEIGHBOUR_TENANT = "neighbour"


@pytest.fixture(autouse=True, scope="module")
def neighbour():
    """The second firm, created once if it is not already there.

    Written through the owner because provisioning a tenant is administration
    rather than a request, and inside the tenant's own scope because the policy
    on `tenants` admits the row naming the setting and no other.
    """
    from app.db import OwnerSessionLocal
    from app.models import Tenant

    with tenancy.acting_as(NEIGHBOUR_TENANT):
        session = OwnerSessionLocal()
        try:
            if session.get(Tenant, NEIGHBOUR_TENANT) is None:
                session.add(
                    Tenant(
                        id=NEIGHBOUR_TENANT,
                        name="Neighbour Wealth",
                        # Required since FP3-02: a tenant's region is where its
                        # data lives, and it defaulted to Sydney for everybody.
                        region="ap-southeast-2",
                    )
                )
                session.commit()
        finally:
            session.close()


@pytest.fixture
def review(session):
    with tenancy.acting_as(DEMO_TENANT):
        yield access_review.collect(session, tenant_id=DEMO_TENANT)


def test_the_report_names_every_person_the_firm_has_granted_a_role_to(review):
    """Read as the application role, through `user_reachable`.

    That policy exists for this caller — migration 0007 says so — and this is
    what proves the report is assembled within the same rules the product
    enforces rather than around them.
    """
    seen = {p.email for p in review.people}
    assert {OPERATOR_EMAIL, APPROVER_EMAIL, SIGNATORY_EMAIL} <= seen
    assert review.tenant_name


def test_each_person_carries_the_grants_they_actually_hold(review):
    by_email = {p.email: p for p in review.people}
    assert by_email[OPERATOR_EMAIL].roles_held(review.as_of) == {"operator"}
    # Two rows, not one — a signatory grant carries the regime it covers, and
    # the review has to show both or it is describing a competence nobody holds.
    signatory = by_email[SIGNATORY_EMAIL]
    assert {g.jurisdiction for g in signatory.grants if g.role == "pack_signatory"} == {
        "AU",
        "HK",
    }


def test_activity_is_read_from_the_audit_trail_and_not_from_live_sessions(client, review):
    """A person who signed in daily for a year and stopped last month looks, to
    `auth_sessions`, exactly like somebody who has never signed in — because
    lapsed session rows are deleted. The audit trail is what remembers."""
    operator = next(p for p in review.people if p.email == OPERATOR_EMAIL)
    assert operator.actions > 0
    assert operator.last_action_at is not None


def test_the_review_changes_nothing(session, review):
    """Reads only, and this is the assertion that keeps it that way.

    A tool that could revoke would be a tool somebody runs on a schedule, and
    removing a person's access is a decision that needs a name against it.
    """
    with tenancy.acting_as(DEMO_TENANT):
        before = set(session.scalars(select(UserRole.id)))
        assert before, "no grants at all — the comparison would hold vacuously"
        access_review.collect(session, tenant_id=DEMO_TENANT)
        session.expire_all()
        assert set(session.scalars(select(UserRole.id))) == before


def test_a_planted_conflict_is_found_against_the_real_database(session, review):
    """The unit tests above construct a conflict; this one creates a real grant.

    Written because everything between a `user_roles` row and a `Finding` — the
    query, the tenant scope, the live/expired split — is untested by a table of
    dataclasses, and that is where a report quietly stops seeing things.
    """
    with tenancy.acting_as(DEMO_TENANT):
        person = identity.find_by_email(session, OPERATOR_EMAIL)
        assert person is not None
        grant = identity.grant_role(
            session, user_id=person.id, role="approver", granted_by="test"
        )
        session.commit()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            found = access_review.collect(session, tenant_id=DEMO_TENANT)
        conflicts = [
            f
            for f in found.findings
            if f.kind == "separation_of_duties" and f.subject == OPERATOR_EMAIL
        ]
        assert len(conflicts) == 1
    finally:
        with tenancy.acting_as(DEMO_TENANT):
            session.delete(grant)
            session.commit()

    # And it is gone once the grant is. A finding that outlived its cause would
    # send a reviewer to remove access that no longer exists.
    with tenancy.acting_as(DEMO_TENANT):
        after = access_review.collect(session, tenant_id=DEMO_TENANT)
    assert not [f for f in after.findings if f.kind == "separation_of_duties"]


def test_reviewing_two_tenants_does_not_print_one_firms_staff_under_the_other():
    """The regression this file exists for as much as any finding above.

    `collect_all` originally reused one session across the loop, and
    `app.tenant_id` binds when a transaction *begins* — so the second tenant's
    section was assembled inside the first tenant's still-open transaction and
    listed the first firm's employees under the second firm's heading. In the
    one document whose purpose is to show that two customers cannot see each
    other.

    It passed every single-tenant test. So this one drives the multi-tenant path
    end to end and asserts the isolation directly, against the real database and
    the real policies.
    """
    reviews = access_review.collect_all([DEMO_TENANT, NEIGHBOUR_TENANT])
    demo, neighbour = reviews

    assert demo.tenant_id == DEMO_TENANT
    assert neighbour.tenant_id == NEIGHBOUR_TENANT
    assert {p.email for p in demo.people}, "the demo firm has no staff — reseed"

    overlap = {p.user_id for p in demo.people} & {p.user_id for p in neighbour.people}
    assert not overlap, f"a person appears in both firms' reviews: {sorted(overlap)}"
    assert OPERATOR_EMAIL not in {p.email for p in neighbour.people}


def test_the_order_of_the_tenants_does_not_change_what_each_one_says():
    """The leak was direction-dependent: whichever tenant came first won.

    Asserting on one ordering would have passed against the broken version half
    the time, which is the kind of test that makes a bug take two people and a
    week to find.
    """
    forwards = access_review.collect_all([DEMO_TENANT, NEIGHBOUR_TENANT])
    backwards = access_review.collect_all([NEIGHBOUR_TENANT, DEMO_TENANT])

    by_id = {r.tenant_id: r for r in forwards} | {}
    reversed_by_id = {r.tenant_id: r for r in backwards}
    for tenant_id in (DEMO_TENANT, NEIGHBOUR_TENANT):
        assert {p.user_id for p in by_id[tenant_id].people} == {
            p.user_id for p in reversed_by_id[tenant_id].people
        }


# ---------------------------------------------------------------- the document --


def test_the_report_renders_the_findings_above_the_roster(review):
    """Order is the whole design. The roster is evidence for the findings, and a
    document that opened with a table of everybody is one where the five lines
    that need a decision are below the fold."""
    body = access_review.render([review])
    assert body.index("### Findings") < body.index("### People")
    assert "## Sign-off" in body
    assert "Reviewed by" in body


def test_the_report_carries_a_digest_of_itself(review):
    """So that "the report that was signed" is a specific document.

    The digest covers everything above it and nothing below, which is why it is
    the last line — a digest that included itself could not be computed.
    """
    body = access_review.render([review])
    printed = body.strip().rsplit("`", 2)[1]
    assert printed == access_review.digest(body[: body.index("\nReport digest")])
    assert len(printed) == 64


def test_a_tenant_with_nobody_in_it_says_so_rather_than_printing_an_empty_table():
    empty = access_review.TenantReview(
        tenant_id="unprovisioned",
        tenant_name="",
        as_of=NOW,
        inactive_days=90,
        people=[],
        findings=[],
    )
    body = access_review.render([empty])
    assert "No role grants" in body
    assert "### People" not in body


def test_the_machine_readable_form_carries_the_same_findings(review):
    payload = access_review.to_dict(review)
    assert {f["kind"] for f in payload["findings"]} == {f.kind for f in review.findings}
    assert payload["tenant_id"] == DEMO_TENANT
    # Expiry is stated per grant rather than left for a reader to work out from
    # a date, because "is this live" is the only question the archive is for.
    for person in payload["people"]:
        for grant in person["grants"]:
            assert isinstance(grant["live"], bool)


def test_findings_name_a_person_and_say_what_to_do_about_them(review):
    """A finding whose text is a category name is a finding somebody has to come
    back and investigate, which is the cost this report exists to remove."""
    for finding in review.findings:
        assert finding.subject
        assert len(finding.detail) > 40, finding
        assert finding.severity in access_review.SEVERITIES


# ------------------------------------------------------- machines that act --


def _credential(**kw) -> Credential:
    return Credential(
        client_id=kw.get("client_id", "apc_test"),
        label=kw.get("label", "Nightly sync"),
        status=kw.get("status", "active"),
        roles=kw.get("roles", ["operator"]),
        created_at=kw.get("created_at", NOW - timedelta(days=200)),
        created_by=kw.get("created_by", "usr_admin"),
        last_used_at=kw.get("last_used_at", NOW - timedelta(days=1)),
        expires_at=kw.get("expires_at", NOW + timedelta(days=90)),
        actions=kw.get("actions", 40),
        last_action_at=kw.get("last_action_at", NOW - timedelta(days=1)),
    )


def _credential_kinds(credentials, **kw) -> set[str]:
    found = access_review.examine_credentials(
        credentials, when=NOW, inactive_days=kw.get("inactive_days", 90)
    )
    return {f.kind for f in found}


def test_a_well_kept_credential_produces_no_findings():
    """The negative that makes the rest of this section mean something."""
    assert _credential_kinds([_credential()]) == set()


def test_a_machine_holding_a_role_only_a_person_should_hold_is_the_loudest_finding():
    """The finding this whole section exists for.

    Approving an override, signing rule content and granting a role are acts a
    regulator would want a name against. A machine cannot be asked why it did
    any of them — so a credential holding one is either a misconfiguration or an
    integration that has been handed a person's job, and separation of duties is
    the thing quietly defeated either way.
    """
    for role in access_review.ROLES_A_MACHINE_SHOULD_NOT_HOLD:
        found = access_review.examine_credentials(
            [_credential(roles=["operator", role])], when=NOW, inactive_days=90
        )
        flagged = next(f for f in found if f.kind == "machine_holds_a_human_role")
        assert flagged.severity == "attention", role
        assert role in flagged.detail


def test_an_operator_credential_is_not_flagged_for_its_role():
    """Running determinations is exactly what an integration is for. A review
    that flagged every credential would be one nobody reads."""
    assert "machine_holds_a_human_role" not in _credential_kinds(
        [_credential(roles=["operator", "viewer"])]
    )


def test_a_credential_that_never_expires_is_raised():
    """The secret was shown once at creation and there is nothing to recover it
    from, so the only way to rotate is to issue a new one deliberately — which
    nobody does unless something asks."""
    assert "credential_without_expiry" in _credential_kinds(
        [_credential(expires_at=None)]
    )


def test_a_credential_nobody_owns_is_raised():
    """This review ends in somebody deciding whether each credential is still
    needed, and that question has to be put to a person."""
    assert "credential_without_an_owner" in _credential_kinds(
        [_credential(created_by="")]
    )


def test_a_credential_that_has_never_acted_is_distinguished_from_one_gone_quiet():
    never = _credential_kinds([_credential(last_action_at=None, actions=0)])
    quiet = _credential_kinds([_credential(last_action_at=NOW - timedelta(days=200))])
    assert "credential_never_used" in never
    assert "credential_inactive" in quiet
    assert "credential_never_used" not in quiet


def test_an_expired_credential_is_tidying_rather_than_exposure():
    """It cannot authenticate, so the roles it still carries are not access.

    Reported as a note rather than passed over: a reviewer tidying a list wants
    to see it, and a reviewer looking for exposure should not have their
    attention spent on it.
    """
    found = access_review.examine_credentials(
        [_credential(expires_at=NOW - timedelta(days=1))], when=NOW, inactive_days=90
    )
    kinds = {f.kind: f.severity for f in found}
    assert kinds == {"expired_credential_still_granted": "note"}


def test_an_expired_credential_is_not_also_flagged_for_everything_else():
    """A credential that cannot authenticate must not generate the same four
    findings as a live one. A reviewer who has to skip half the list stops
    reading it."""
    kinds = _credential_kinds(
        [
            _credential(
                expires_at=NOW - timedelta(days=1),
                created_by="",
                last_action_at=None,
                roles=["approver"],
            )
        ]
    )
    assert "machine_holds_a_human_role" not in kinds
    assert "credential_without_expiry" not in kinds


def test_a_suspended_credential_is_not_treated_as_live():
    assert _credential_kinds([_credential(status="suspended", created_by="")]) <= {
        "expired_credential_still_granted"
    }


def test_the_review_reads_machine_credentials_from_the_database(session):
    """The regression this whole change exists for.

    Stage 2 built this review to answer "who can do what". Stage 4 introduced a
    second kind of actor that holds roles and appears in the audit trail, and for
    three commits the review could not see them — a document claiming to list
    everyone with access while silently omitting some of the things that had it.
    """
    from app.models import ApiClient

    with tenancy.acting_as(DEMO_TENANT):
        session.add(
            ApiClient(
                id="apc_review_probe",
                label="Review probe",
                secret_hash="not-a-real-hash",
                roles=["operator", "approver"],
                status="active",
            )
        )
        session.commit()
    try:
        with tenancy.acting_as(DEMO_TENANT):
            review = access_review.collect(session, tenant_id=DEMO_TENANT)

        seen = {c.client_id for c in review.credentials}
        assert "apc_review_probe" in seen, "the review cannot see machine credentials"

        flagged = [
            f
            for f in review.findings
            if f.kind == "machine_holds_a_human_role" and "apc_review_probe" in f.subject
        ]
        assert flagged, "a machine holding `approver` was not raised"
    finally:
        with tenancy.acting_as(DEMO_TENANT):
            session.delete(session.get(ApiClient, "apc_review_probe"))
            session.commit()


def test_the_report_lists_integrations_beside_the_people(review):
    """Two tables rather than one. A reviewer asks different questions of a
    machine — nobody asks whether a credential enrolled a second factor, and
    everybody should ask when it was last rotated."""
    body = access_review.render([review])
    assert "### Integrations" in body
    assert body.index("### People") < body.index("### Integrations")


def test_the_machine_readable_form_carries_the_credentials_too(review):
    payload = access_review.to_dict(review)
    assert "credentials" in payload
    for credential in payload["credentials"]:
        assert credential["client_id"]
        assert isinstance(credential["live"], bool)
        assert isinstance(credential["roles"], list)
