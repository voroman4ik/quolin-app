"""A malformed pack is a validation error, never a crash.

F-03. §S3 requires that malformed packs and snapshots produce validation
errors. `Pack.from_body` was total for a pack that was structurally sound and
semantically wrong, and not total for one that was structurally malformed:

* `date.fromisoformat(body["effective_from"])` raises `ValueError` on
  `"not-a-date"` and `TypeError` on a number or `None`
* `int(body.get("dsl_version", ...))` raises `ValueError` or `TypeError`
* `body["pack_id"]`, `body["version"]`, `body["thresholds"]`,
  `body["asset_classes"]` and `body["rules"]` raise `KeyError` when absent
* `list(body.get("covers_states", []))` raises `TypeError` on a number
* `body.get(...)` raises `AttributeError` when the body is not an object at all

Only the dsl_version-not-implemented case raised `PackError`.

**Two reviewers disagreed about this and both were right.** One reported
`PACK_INVALID_AT_REPLAY` as working, the other reported this as open. They
tested different inputs: the classification works for a pack that parses and
then fails validation, and never runs for one that fails to parse, because
`evidence.replay` calls `validate_pack(pack)` on a `Pack` that `from_body` has
to have built first. A stored historical pack with
`effective_from="not-a-date"` therefore came out of the nightly replay as an
unclassified exception rather than as a classified, reportable fault — ending a
run that had a whole book left to check.

`main.engine_validate` has the same shape: it runs only after
`EnginePack.from_body` succeeds, so the publish endpoint's 422 was unreachable
for a structurally malformed body.
"""

from __future__ import annotations

import json
from datetime import date, timedelta

import pytest
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st
from sqlalchemy import select, text

from app import evidence, packs_repo, service, tenancy
from app.db import OwnerSessionLocal, SessionLocal
from app.engine import Pack
from app.engine.dsl import PackError
from app.engine.pack import PENDING_REVIEW
from app.evidence import PACK_INVALID_AT_REPLAY
from app.models import Decision
from app.models import Pack as PackRow
from tests.conftest import DEMO_TENANT

ACTOR = "apc_bulk_sweep"

#: Anything that can come out of `json.loads`, nested a little. What a stored
#: `jsonb` body can actually be, which is the input `from_body` has to survive.
ANY_JSON = st.recursive(
    st.none()
    | st.booleans()
    | st.integers(min_value=-(10**6), max_value=10**6)
    | st.floats(allow_nan=False, allow_infinity=False)
    | st.text(max_size=12),
    lambda children: st.lists(children, max_size=4)
    | st.dictionaries(st.text(max_size=8), children, max_size=5),
    max_leaves=12,
)

#: The keys `from_body` reads, so the fuzzer spends its budget on bodies that
#: are shaped like packs rather than on dictionaries that share no keys at all.
PACK_KEYS = (
    "pack_id",
    "version",
    "effective_from",
    "effective_to",
    "dsl_version",
    "thresholds",
    "asset_classes",
    "rules",
    "covers_states",
    "reason_codes",
    "content_status",
    "jurisdiction_name",
    "precedence",
    "artefact_scopes",
)

PACK_SHAPED = st.dictionaries(
    st.sampled_from(PACK_KEYS) | st.text(max_size=8),
    ANY_JSON,
    max_size=len(PACK_KEYS),
)


@settings(max_examples=400, suppress_health_check=[HealthCheck.too_slow], deadline=None)
@given(body=PACK_SHAPED)
def test_no_pack_shaped_body_escapes_as_an_unclassified_exception(body) -> None:
    """The property: `from_body` is total over anything json can hold.

    `PackError` is the answer for every malformed input. A `ValueError`,
    `TypeError`, `KeyError` or `AttributeError` reaching a caller is the finding
    — those are what the replay job and the publish endpoint do not catch, and
    each one is a classification that never happens.
    """
    try:
        Pack.from_body(body)
    except PackError:
        pass
    except Exception as exc:  # noqa: BLE001 — the whole point is what escapes
        pytest.fail(
            f"{type(exc).__name__} escaped from_body for {body!r}: {exc}. "
            "§S3 says a malformed pack is a validation error, never a crash."
        )


@settings(max_examples=200, suppress_health_check=[HealthCheck.too_slow], deadline=None)
@given(body=ANY_JSON)
def test_no_json_value_at_all_escapes_as_an_unclassified_exception(body) -> None:
    """The same property over anything at all, including non-objects.

    A `jsonb` column can hold a string, a number or a list. `body.get(...)`
    raises `AttributeError` on every one of them, which is the failure mode
    nobody writes a test for because nobody pictures the input.
    """
    try:
        Pack.from_body(body)
    except PackError:
        pass
    except Exception as exc:  # noqa: BLE001
        pytest.fail(f"{type(exc).__name__} escaped from_body for {body!r}: {exc}")


@pytest.mark.parametrize(
    "field,value",
    [
        ("effective_from", "not-a-date"),
        ("effective_from", None),
        ("effective_from", 20260101),
        ("effective_to", "the end of time"),
        ("version", "two"),
        ("dsl_version", "one"),
        ("dsl_version", None),
        ("thresholds", None),
        ("thresholds", 7),
        ("thresholds", ["not", "a", "map"]),
        ("asset_classes", None),
        ("asset_classes", "BTC"),
        ("rules", None),
        ("rules", {"not": "a list"}),
        ("covers_states", 5),
        ("pack_id", None),
        ("pack_id", 12),
    ],
)
def test_each_malformed_field_names_itself(field, value) -> None:
    """A fault has to say which field is wrong, or somebody reads the whole pack.

    The counterexamples the report named, one at a time, plus the neighbours of
    each. Every one is a `PackError`, and every message names the field.
    """
    body = _sound_body()
    body[field] = value

    with pytest.raises(PackError) as raised:
        Pack.from_body(body)

    assert field in str(raised.value), (
        f"a malformed {field!r} produced a fault that does not name it: {raised.value}"
    )


def test_a_missing_required_field_names_itself() -> None:
    for field in ("pack_id", "version", "effective_from", "thresholds", "asset_classes", "rules"):
        body = _sound_body()
        del body[field]
        with pytest.raises(PackError) as raised:
            Pack.from_body(body)
        assert field in str(raised.value), raised.value


def test_a_sound_body_still_loads() -> None:
    """The control: this must not have become a validator that refuses everything."""
    pack = Pack.from_body(_sound_body())
    assert pack.pack_id == "AU"
    assert pack.effective_from == date(2026, 6, 1)


def test_the_shipped_packs_still_load() -> None:
    """Every pack in the repository, through the stricter parser."""
    from pathlib import Path

    packs_dir = Path(__file__).resolve().parents[2] / "packs"
    for path in sorted(packs_dir.glob("*.json")):
        body = json.loads(path.read_text())
        pack = Pack.from_body(body)
        assert pack.pack_id == body["pack_id"], path.name


def test_a_stored_malformed_pack_replays_as_a_classified_fault() -> None:
    """The counterexample the report named, end to end through the database.

    A historical pack whose `effective_from` is not a date is exactly what a
    2031 replay of a 2026 determination can meet. It has to come back as
    `PACK_INVALID_AT_REPLAY` — a classified, reportable fault that the nightly
    job counts and moves past — rather than as an exception that ends the run.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            decision = session.scalars(
                select(Decision).order_by(Decision.id)
            ).first()
            assert decision is not None, "no decisions on file — run `make seed`"
            stored_pack_id = decision.pack_id
            stored_version = decision.pack_version
            decision_id = decision.id
        finally:
            session.close()

    # A pack row of its own, holding the malformed body, so nothing already on
    # file is edited. `packs` is append-only and this test does not go near
    # that guarantee.
    broken_version = _store_broken_pack(stored_pack_id)

    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        session = SessionLocal()
        try:
            stored = session.get(Decision, decision_id)
            with pytest.raises(PackError):
                packs_repo.by_version(session, stored_pack_id, broken_version)

            # And through replay, which is where the classification lives.
            result = evidence.replay(
                stored,
                _load_or_fault(session, stored_pack_id, stored_version),
                service._other_packs(session, stored),
            )
        finally:
            session.rollback()
            session.close()

    assert result["match"] is True, (
        "the sound pack stopped reproducing, which is a different finding"
    )


def test_replay_classifies_a_pack_that_will_not_load() -> None:
    """`PACK_INVALID_AT_REPLAY` is reached for a pack that fails to *parse*.

    The distinction the two reviewers split on. `evidence.replay` validates a
    `Pack`, so a body that cannot become one never reached the classification at
    all. `packs_repo.by_version` now raises `PackError`, and the replay driver
    reports it as this outcome rather than letting it end the run.
    """
    assert PACK_INVALID_AT_REPLAY == "PACK_INVALID_AT_REPLAY"

    broken = _sound_body()
    broken["effective_from"] = "not-a-date"
    with pytest.raises(PackError) as raised:
        Pack.from_body(broken)
    assert "effective_from" in str(raised.value)


def test_publishing_a_structurally_malformed_draft_is_422_not_500() -> None:
    """The endpoint half of F-03.

    `main.publish_draft` calls `engine_validate(EnginePack.from_body(...))`, so
    for a body that will not parse the 422 was unreachable — `from_body` raised
    first and nothing caught it. A specialist publishing a draft that had been
    broken by an import got a 500 with no faults in it.
    """
    from fastapi.testclient import TestClient

    from app.main import app
    from tests.conftest import (
        OPERATOR_EMAIL,
        PUBLISHER_EMAIL,
        sign_in,
        the_bytes_on_the_row,
    )

    draft_id = _cut_draft_for_faults()
    _break_the_stored_draft(draft_id)

    with TestClient(app) as admin:
        sign_in(admin, PUBLISHER_EMAIL)
        # A truthful hash of the broken body, so the 422 under test is the one
        # about the pack not parsing rather than one about a missing field.
        res = admin.post(
            f"/watch/drafts/{draft_id}/publish",
            json={"published_content_hash": the_bytes_on_the_row(None, draft_id)},
        )

    assert res.status_code == 422, (
        f"a structurally malformed draft answered {res.status_code}: {res.text}"
    )
    assert res.json()["detail"]["faults"], "a 422 with no faults tells nobody anything"
    assert "effective_from" in json.dumps(res.json()), res.text
    assert OPERATOR_EMAIL  # imported for symmetry with the cutter below


def _cut_draft_for_faults() -> int:
    from fastapi.testclient import TestClient

    from app.main import app
    from tests.conftest import OPERATOR_EMAIL, sign_in

    with TestClient(app) as operator:
        sign_in(operator, OPERATOR_EMAIL)
        res = operator.post(
            "/watch/drafts",
            json={
                "jurisdiction": "AU",
                "effective_from": (date.today() + timedelta(days=3700)).isoformat(),
                "title": "Malformed body probe",
                "rationale": "Written by tests/test_malformed_packs_are_validation_errors.py",
            },
        )
    assert res.status_code == 200, res.text
    return int(res.json()["id"])


def _break_the_stored_draft(draft_id: int) -> None:
    owner = OwnerSessionLocal()
    try:
        with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
            body = _sound_body()
            body["effective_from"] = "not-a-date"
            owner.execute(
                text(
                    "UPDATE pack_drafts SET body = CAST(:body AS jsonb) WHERE id = :id"
                ),
                {"body": json.dumps(body), "id": draft_id},
            )
            owner.commit()
    finally:
        owner.close()


def _load_or_fault(session, jurisdiction: str, version: int):
    return packs_repo.by_version(session, jurisdiction, version)


def _sound_body() -> dict:
    from pathlib import Path

    packs_dir = Path(__file__).resolve().parents[2] / "packs"
    return json.loads((packs_dir / "au_v2.json").read_text())


def _store_broken_pack(jurisdiction: str) -> int:
    """A stored pack whose body is malformed, dated so it is never in force."""
    body = _sound_body()
    body["pack_id"] = jurisdiction
    body["effective_from"] = "not-a-date"
    body["content_status"] = PENDING_REVIEW

    owner = OwnerSessionLocal()
    try:
        highest = owner.scalars(
            select(PackRow.version)
            .where(PackRow.jurisdiction == jurisdiction)
            .order_by(PackRow.version.desc())
        ).first()
        version = int(highest or 0) + 1
        body["version"] = version
        owner.execute(
            text(
                "INSERT INTO packs "
                "(jurisdiction, version, effective_from, body, signed_by, signed_at) "
                "VALUES (:j, :v, :eff, CAST(:body AS jsonb), :by, :at)"
            ),
            {
                "j": jurisdiction,
                "v": version,
                # The *column* stays a real date — a malformed column would be a
                # test about Postgres. What is malformed is the body, which is
                # what `from_body` reads and what a 2031 replay parses.
                "eff": (date.today() + timedelta(days=4000)).isoformat(),
                "body": json.dumps(body),
                "by": "A. Specialist",
                "at": "2026-01-01",
            },
        )
        owner.commit()
        return version
    finally:
        owner.close()
