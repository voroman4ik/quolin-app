"""The hard determinism constraints from the spec, tested rather than assumed."""

from __future__ import annotations

import copy
import random

import pytest

from app import packs_repo
from app.engine import Pack, evaluate_snapshot, worst_of
from app.engine.dsl import PackError, resolve


def _walk(value, path="snapshot"):
    if isinstance(value, dict):
        for key, item in value.items():
            yield from _walk(item, f"{path}.{key}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from _walk(item, f"{path}[{index}]")
    else:
        yield path, value


def test_no_floats_anywhere_in_stored_snapshots(decisions):
    offenders = [
        (d.id, path, value)
        for d in decisions
        for path, value in _walk(d.snapshot)
        if isinstance(value, float)
    ]
    assert not offenders, f"floats break replay equality: {offenders[:5]}"


def test_no_floats_in_pack_thresholds(pack_bodies):
    offenders = [
        (pack_id, version, path, value)
        for (pack_id, version), body in pack_bodies.items()
        for path, value in _walk(body["thresholds"])
        if isinstance(value, float)
    ]
    assert not offenders, offenders


def test_rule_order_does_not_change_the_result(session, decisions):
    rng = random.Random(7)
    for decision in decisions[:25]:
        pack = packs_repo.by_version(session, "AU", decision.pack_version)
        baseline = evaluate_snapshot(pack, decision.snapshot)

        for _ in range(5):
            shuffled_rules = list(pack.rules)
            rng.shuffle(shuffled_rules)
            shuffled = Pack(**{**pack.__dict__, "rules": shuffled_rules})
            result = evaluate_snapshot(shuffled, decision.snapshot)

            assert result["outcome"] == baseline["outcome"]
            assert result["rule_results"] == baseline["rule_results"]


def test_worst_of_is_commutative():
    rng = random.Random(11)
    for _ in range(200):
        outcomes = [rng.choice(["ALLOW", "REFER", "BLOCK"]) for _ in range(rng.randint(1, 8))]
        shuffled = list(outcomes)
        rng.shuffle(shuffled)
        assert worst_of(outcomes) == worst_of(shuffled)


def test_worst_of_ordering():
    assert worst_of(["ALLOW", "REFER"]) == "REFER"
    assert worst_of(["REFER", "BLOCK"]) == "BLOCK"
    assert worst_of(["ALLOW", "BLOCK", "REFER"]) == "BLOCK"
    assert worst_of([]) == "ALLOW"


def test_evaluation_is_a_pure_function_of_the_snapshot(session, decisions):
    for decision in decisions[:25]:
        pack = packs_repo.by_version(session, "AU", decision.pack_version)
        first = evaluate_snapshot(pack, copy.deepcopy(decision.snapshot))
        second = evaluate_snapshot(pack, copy.deepcopy(decision.snapshot))
        assert first == second


def test_evaluation_does_not_mutate_the_snapshot(session, decisions):
    for decision in decisions[:25]:
        pack = packs_repo.by_version(session, "AU", decision.pack_version)
        before = copy.deepcopy(decision.snapshot)
        evaluate_snapshot(pack, decision.snapshot)
        assert decision.snapshot == before


def test_every_result_carries_provenance(session, decisions):
    for decision in decisions:
        for result in decision.rule_results["results"]:
            assert result["rule_id"]
            assert "passed" in result
            assert isinstance(result["inputs_read"], list)
            assert isinstance(result["thresholds_used"], list)
            if not result["passed"]:
                assert result["reason_code"], result
            # A rule that compares nothing cannot be explained on screen.
            assert result["inputs_read"] or result["thresholds_used"], result


def test_dsl_rejects_floats():
    with pytest.raises(PackError, match="float"):
        resolve({"const": 1.5}, {}, {}, [])


def test_dsl_rejects_unknown_terms_and_missing_fields():
    with pytest.raises(PackError):
        resolve({"mystery": "x"}, {}, {}, [])
    with pytest.raises(PackError, match="no field"):
        resolve({"field": "client.nope"}, {"client": {}}, {}, [])
    with pytest.raises(PackError, match="no threshold"):
        resolve({"threshold": "nope"}, {}, {}, [])
