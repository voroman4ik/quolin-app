"""Why a rule was in or out of a determination, not merely which ones were.

F10's engine half. `evaluate_snapshot` returned `rules_not_applicable` — a list
of rule ids and nothing more — so a screen could say *which* rules said nothing
and never *why*.

That matters more than it sounds, because of what it sits next to.
`evaluate.worst_of(..., default=ALLOW)` means a determination in which no rule
applied is an ALLOW: an asset class no rule names passes silently. Whether that
is right is a content question for the specialists and is **not changed here** —
it is recorded as a decision. What is fixed is that the first question anybody
asks about a silent ALLOW ("which rules were even considered, and on what?")
now has an answer on the screen.

**Additive, and that is the whole design.** `rules_not_applicable` is stored on
every decision and compared field-by-field by `evidence.replay`. Widening it
would make every determination on file fail to reproduce — which
`docs/runbooks/chain-mismatch.md` says to treat as a security incident. So the
answer arrives as a separate key that `evidence.record` does not read, and the
view recomputes it from the frozen snapshot rather than storing it.
"""

from __future__ import annotations

from datetime import date

from fastapi.testclient import TestClient
from sqlalchemy import select

from app import evidence, packs_repo, service, tenancy
from app.engine import Pack, evaluate_snapshot
from app.engine.evaluate import APPLICABILITY
from app.main import app
from app.models import Decision
from tests.conftest import DEMO_TENANT, OPERATOR_EMAIL, sign_in

ACTOR = "apc_bulk_sweep"


def _a_decision() -> int:
    with TestClient(app) as client:
        sign_in(client, OPERATOR_EMAIL)
        res = client.post(
            "/evaluate", json={"client_id": "margaret-wu", "asset_id": "BTC"}
        )
    assert res.status_code == 200, res.text
    return int(res.json()["id"])


def test_the_engine_says_why_each_rule_was_in_or_out(session) -> None:
    """Every rule in the pack is accounted for, applied or not."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        decision = session.scalars(select(Decision).order_by(Decision.id)).first()
        assert decision is not None, "no decisions — run `make seed`"
        pack = packs_repo.by_version(
            session, decision.pack_id or "AU", decision.pack_version
        )
        result = evaluate_snapshot(pack, decision.snapshot)

    applicability = result["applicability"]
    assert applicability, "the engine reported no applicability at all"

    covered = {entry["rule_id"] for entry in applicability}
    assert covered == {rule["rule_id"] for rule in pack.rules}, (
        "some rules are missing from the applicability report, so a reason card "
        "would silently omit them"
    )

    # And it agrees with the list that was already there.
    excluded = {e["rule_id"] for e in applicability if not e["applied"]}
    assert excluded == set(result["rules_not_applicable"])


def test_an_excluded_rule_carries_what_excluded_it(session) -> None:
    """A rule scoped to an asset class says which class it saw."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        decision = session.scalars(select(Decision).order_by(Decision.id)).first()
        pack = packs_repo.by_version(
            session, decision.pack_id or "AU", decision.pack_version
        )
        result = evaluate_snapshot(pack, decision.snapshot)

    excluded = [e for e in result["applicability"] if not e["applied"]]
    assert excluded, "no rule was excluded, so this decision cannot show the finding"

    with_reads = [e for e in excluded if e["reads"]]
    assert with_reads, (
        "every excluded rule was excluded with nothing recorded about why"
    )
    for entry in with_reads:
        for read in entry["reads"]:
            assert read["kind"] == APPLICABILITY, (
                f"an applicability read is filed under {read['kind']!r}, which "
                "would make a reason card claim the rule tested it"
            )
            assert read["ref"], "a read with no field reference explains nothing"


def test_the_decision_view_carries_it() -> None:
    """The production consumer: a decision page can render the card."""
    decision_id = _a_decision()

    with TestClient(app) as client:
        sign_in(client, OPERATOR_EMAIL)
        body = client.get(f"/decisions/{decision_id}").json()

    assert "applicability" in body, "the decision view does not carry applicability"
    assert body["applicability"], "the decision view carries an empty applicability"
    assert {e["rule_id"] for e in body["applicability"]} >= set(
        body["rules_not_applicable"]
    ), "a rule reported as not applicable is missing from the explanation"


def test_nothing_stored_about_a_decision_changed(session) -> None:
    """The property that makes this safe to add at all.

    `evidence.record` reads exactly two keys out of the evaluation, so a third
    is invisible to storage and to the hash chain.
    """
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        decision = session.scalars(select(Decision).order_by(Decision.id)).first()
        stored = decision.rule_results

    assert set(stored) <= {"results", "not_applicable", "other_jurisdictions"}, (
        f"a decision row now carries {sorted(stored)} — applicability leaked "
        "into stored evidence, and every determination on file has to be "
        "rehashed"
    )
    assert "applicability" not in stored


def test_every_seeded_decision_still_replays(session) -> None:
    """The regression guard: adding the key must not touch reproduction."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        rows = list(session.scalars(select(Decision).order_by(Decision.id).limit(40)))
        assert rows, "no decisions on file — run `make seed`"
        for row in rows:
            pack = packs_repo.by_version(
                session, row.pack_id or "AU", row.pack_version
            )
            result = evidence.replay(
                pack=pack,
                decision=row,
                others=service._other_packs(session, row),
            )
            assert result["match"] is True, (
                f"decision {row.id} stopped reproducing: {result['differences']}"
            )


def test_a_rule_that_applies_is_reported_as_applied(session) -> None:
    """The control: this is not a report that everything was excluded."""
    with tenancy.acting_as(DEMO_TENANT), tenancy.acting_as_user(ACTOR):
        decision = session.scalars(select(Decision).order_by(Decision.id)).first()
        pack = packs_repo.by_version(
            session, decision.pack_id or "AU", decision.pack_version
        )
        result = evaluate_snapshot(pack, decision.snapshot)

    applied = [e for e in result["applicability"] if e["applied"]]
    assert applied, "no rule applied at all"
    assert {e["rule_id"] for e in applied} == {
        r["rule_id"] for r in result["rule_results"]
    }


def test_the_default_outcome_is_deliberately_unchanged() -> None:
    """F10's content half is a decision, not a patch — asserted so it stays visible.

    An asset class no rule names still produces ALLOW. Whether zero applicable
    rules should REFER instead is a question for the specialists, recorded under
    "Decisions requested" in docs/spec-changes.md. If this test ever fails, that
    decision has been taken and this file should say so rather than being
    quietly updated.
    """
    from app.engine.evaluate import worst_of

    assert worst_of([]) == "ALLOW"

    empty = Pack.from_body(
        {
            "pack_id": "ZZ",
            "version": 1,
            "effective_from": "2020-01-01",
            "thresholds": {},
            "asset_classes": {"BTC": {"class": "major", "volatility_band": 1,
                                      "leverage": False, "structural_flags": []}},
            "rules": [],
        }
    )
    assert empty.rules == []
    assert date(2020, 1, 1) == empty.effective_from
