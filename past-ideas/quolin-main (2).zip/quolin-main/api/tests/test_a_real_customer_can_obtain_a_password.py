"""FP3-11: the first customer's first user could never sign in.

`identity.set_password` had exactly two callers — `api/seed/seed.py` and
`scripts/load_model.py`. `POST /admin/users` creates, in its own docstring, "a
person, created with no way to sign in yet", and there was no invite route, no
set-password route and no reset route. OIDC does not provision either.

So every account that works today works because the seed gave it a password.
That is a demo, not a product: a real firm's first administrator could create
their compliance officer and had no way to hand them a credential short of
somebody at Quolin running an UPDATE.

The test the finding asks for is `test_the_whole_journey_...` at the bottom:
`POST /admin/users` through to a successful sign-in with a second factor,
through the API only.
"""

from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone

import pytest
from conftest import (
    DEMO_TENANT,
    PUBLISHER_EMAIL,
    reset_rate_limit_for_tests,
    second_factor_code,
    sign_in,
)
from fastapi.testclient import TestClient
from sqlalchemy import select

from app import tenancy
from app.db import OwnerSessionLocal
from app.main import app
from app.models import AuditEvent, Invitation

STRONG = "a-password-nobody-else-typed"


def _a_new_address(label: str) -> str:
    """An address nobody has used before, per test.

    Not a fixed address with teardown. A `users` row cannot be deleted once it
    has been provisioned — audit events, role grants and identities all point at
    it, and `audit_events` is append-only — so a fixture that tried to clean up
    after itself hit a foreign key on the second run. Provisioning somebody new
    is also closer to what the route is for.
    """
    return f"fp3-11-{label}-{secrets.token_hex(6)}@quolin.example"


@pytest.fixture
def publisher():
    with TestClient(app) as c:
        yield sign_in(c, PUBLISHER_EMAIL)


@pytest.fixture
def anonymous():
    reset_rate_limit_for_tests()
    with TestClient(app) as c:
        yield c
    reset_rate_limit_for_tests()


@pytest.fixture
def a_fresh_invitation(publisher):
    """Somebody provisioned from scratch, with the token that came back."""
    email = _a_new_address("newcomer")
    made = publisher.post(
        "/admin/users", json={"email": email, "display_name": "FP3-11 newcomer"}
    )
    assert made.status_code in (200, 201), made.text
    body = made.json()
    assert body["created"] is True, "the probe address was not new"

    # A role, in the fixture rather than in the tests that happen to need one.
    #
    # Two reasons, and the second is not about convenience. `/auth/login`
    # refuses an account with no business in this firm before it looks at
    # anything else, so a probe with no grant could never complete the journey.
    # And `users` is visible to a tenant-scoped read through the grants held in
    # it — so an invited person with no role is invisible there while the audit
    # row naming them as having set their own password is not, which is what
    # `test_attribution.py` reports as "audit rows naming nobody".
    #
    # Inviting somebody to nothing is not a state a firm provisions on purpose:
    # you invite a person *to* a role.
    granted = publisher.post(
        f"/admin/users/{body['id']}/roles", json={"role": "viewer"}
    )
    assert granted.status_code in (200, 201), granted.text
    return body


def test_provisioning_returns_a_token_the_person_can_use(a_fresh_invitation):
    """The finding: there was nothing here at all."""
    invitation = a_fresh_invitation.get("invitation")
    assert invitation, (
        "creating a person returned no invitation, so they have no way to sign in"
    )
    assert invitation["token"]
    assert invitation["expires_at"]


def test_the_token_is_not_stored(a_fresh_invitation):
    """Hashed at rest, like a session token.

    `invitations` is readable by the application role, and a table of live
    credentials in plaintext is a worse problem than the one it solves.
    """
    token = a_fresh_invitation["invitation"]["token"]
    with OwnerSessionLocal() as s:
        rows = s.scalars(
            select(Invitation).where(Invitation.user_id == a_fresh_invitation["id"])
        ).all()
    assert rows, "no invitation row was written"
    assert all(row.token_hash != token for row in rows), (
        "the invitation token is stored in plaintext"
    )


def test_the_person_can_set_a_password_and_sign_in(a_fresh_invitation, anonymous):
    """The whole point, end to end and through the API only."""
    token = a_fresh_invitation["invitation"]["token"]

    chosen = anonymous.post(
        "/auth/set-password", json={"token": token, "password": STRONG}
    )
    assert chosen.status_code == 200, chosen.text

    signed_in = anonymous.post(
        "/auth/login",
        json={"email": a_fresh_invitation["email"], "password": STRONG},
    )
    assert signed_in.status_code == 200, signed_in.text


def test_a_token_is_single_use(a_fresh_invitation, anonymous):
    """An invite link sits in an inbox for ever, and a mailbox is not a vault."""
    token = a_fresh_invitation["invitation"]["token"]

    first = anonymous.post(
        "/auth/set-password", json={"token": token, "password": STRONG}
    )
    assert first.status_code == 200, first.text

    again = anonymous.post(
        "/auth/set-password", json={"token": token, "password": "another-one-entirely"}
    )
    assert again.status_code == 400, "a spent invitation was accepted a second time"


def test_an_expired_token_is_refused(a_fresh_invitation, anonymous):
    """A credential-granting link that never dies is a credential."""
    user_id = a_fresh_invitation["id"]
    with OwnerSessionLocal() as s:
        row = s.scalars(
            select(Invitation).where(Invitation.user_id == user_id)
        ).one()
        row.expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        s.commit()

    refused = anonymous.post(
        "/auth/set-password",
        json={"token": a_fresh_invitation["invitation"]["token"], "password": STRONG},
    )
    assert refused.status_code == 400, refused.text


def test_a_weak_password_does_not_spend_the_link(a_fresh_invitation, anonymous):
    """The failure mode of a password rule is people locking themselves out.

    The policy is checked before the invitation is consumed, so a first attempt
    that is too short leaves the link live.
    """
    token = a_fresh_invitation["invitation"]["token"]

    refused = anonymous.post("/auth/set-password", json={"token": token, "password": "short"})
    assert refused.status_code == 422, refused.text

    accepted = anonymous.post(
        "/auth/set-password", json={"token": token, "password": STRONG}
    )
    assert accepted.status_code == 200, (
        "a rejected password spent the invitation, so the person is locked out "
        "for having tried to obey the rule"
    )


def test_an_unknown_token_says_the_same_thing_as_a_spent_one(anonymous):
    """Expired, used, and never ours are three facts about our records.

    Telling somebody holding a bad token which one applies tells them something
    about an account they may not hold.
    """
    made_up = anonymous.post(
        "/auth/set-password",
        json={"token": "x" * 40, "password": STRONG},
    )
    assert made_up.status_code == 400
    assert "not valid" in made_up.json()["detail"]


def test_a_reset_says_the_same_thing_for_an_address_that_does_not_exist(anonymous):
    """The one endpoint reachable by somebody who cannot sign in.

    A response that distinguished "no such user" from "sent" would be an
    enumeration oracle on exactly the surface with none of the other defences.
    """
    known = anonymous.post("/auth/reset", json={"email": PUBLISHER_EMAIL})
    unknown = anonymous.post("/auth/reset", json={"email": "nobody@example.invalid"})

    assert known.status_code == unknown.status_code == 200
    assert known.json() == unknown.json(), (
        "the reset route answers differently for an address that has an account"
    )


def test_the_invitation_is_recorded_in_the_trail(a_fresh_invitation, anonymous):
    """"How did this person come to hold a credential" is an access-review
    question, and it now has an answer."""
    token = a_fresh_invitation["invitation"]["token"]
    anonymous.post("/auth/set-password", json={"token": token, "password": STRONG})

    with tenancy.acting_as(DEMO_TENANT):
        with OwnerSessionLocal() as s:
            actions = {
                row.action
                for row in s.scalars(
                    select(AuditEvent).order_by(AuditEvent.id.desc()).limit(40)
                )
            }

    assert "identity.invitation.issued" in actions, "nothing recorded the invitation"
    assert "identity.invitation.consumed" in actions, (
        "nothing recorded that a password was chosen"
    )


def test_the_whole_journey_from_provisioning_to_a_second_factor(publisher, anonymous):
    """The test the finding asks for, through the API and nothing else.

    `POST /admin/users` -> invitation -> set a password -> a role -> sign in ->
    enrol an authenticator -> sign in again with a code.

    Signing in with MFA is the part that matters: `MFA_REQUIRED_ROLES` means a
    privileged account is refused a password-only sign-in, so an invite flow
    that stopped at "has a password" would hand somebody a credential that still
    cannot reach the work they were hired to do.
    """
    email = _a_new_address("journey")
    made = publisher.post(
        "/admin/users", json={"email": email, "display_name": "FP3-11 journey"}
    )
    assert made.status_code in (200, 201), made.text
    person = made.json()
    token = person["invitation"]["token"]

    # `approver` requires a second factor — which is the point of choosing it.
    granted = publisher.post(
        f"/admin/users/{person['id']}/roles", json={"role": "approver"}
    )
    assert granted.status_code in (200, 201), granted.text

    chosen = anonymous.post(
        "/auth/set-password", json={"token": token, "password": STRONG}
    )
    assert chosen.status_code == 200, chosen.text

    first = anonymous.post("/auth/login", json={"email": email, "password": STRONG})
    assert first.status_code == 200, (
        f"a newly invited approver could not sign in at all: {first.text}"
    )

    enrolled = anonymous.post("/auth/mfa/enrol")
    assert enrolled.status_code == 200, (
        f"an invited person cannot enrol an authenticator: {enrolled.text}"
    )
    secret = enrolled.json()["secret"]

    from app import totp

    confirmed = anonymous.post(
        "/auth/mfa/verify", json={"code": totp.code_at(secret)}
    )
    assert confirmed.status_code == 200, confirmed.text

    # And from here they are a privileged account: password alone is refused,
    # password with a code is not.
    reset_rate_limit_for_tests()
    with TestClient(app) as fresh:
        without = fresh.post("/auth/login", json={"email": email, "password": STRONG})
        assert without.status_code == 401
        assert without.headers.get("X-Quolin-MFA") == "required"

        code = second_factor_code(email)
        assert code, "the enrolled authenticator produced no code"
        with_code = fresh.post(
            "/auth/login", json={"email": email, "password": STRONG, "code": code}
        )
    assert with_code.status_code == 200, (
        f"an invited approver with an enrolled authenticator cannot sign in: "
        f"{with_code.text}"
    )
