"""Known inputs, known results, checked on every commit and never deleted.

The execution document asks for versioned (snapshot, pack, expected result)
triples in the repository, and for every bug ever found to become a permanent
entry. `corpus/` holds them, one JSON file per case, each carrying a `why` that
says what it is for.

**Why a corpus as well as a property suite.** They fail differently and that is
the point. A property says "this must hold for everything" and catches classes of
defect; a corpus says "this exact input gave this exact answer" and catches the
one regression a property was never written for. The property suite is how you
find out you were wrong about the engine. The corpus is how you find out somebody
changed an answer.

**Why the expected results are stored rather than recomputed.** A test that
computed the expected result from the engine and then compared it to the engine
would pass whatever the engine did. These files were written by running the
engine once, at a commit where the answer was checked by hand, and are now
frozen. When one of them changes, either a bug has been introduced or a
deliberate change has been made — and the second requires updating the file,
which is a diff a reviewer sees.

**How to add a case.** Any bug, the moment it is understood. Write the snapshot
that triggers it, the pack it happened under, the answer it should give, and a
`why` that a stranger can read. Cases are never removed: a corpus that shrinks is
one that has forgotten something.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from app.engine import Pack, evaluate_snapshot

ROOT = Path(__file__).resolve().parents[2]
CORPUS = ROOT / "corpus"
PACKS = ROOT / "packs"

CASES = sorted(CORPUS.glob("*.json"))


def _pack(name: str) -> Pack:
    return Pack.from_body(json.loads((PACKS / f"{name}.json").read_text()))


def test_the_corpus_is_not_empty():
    """A corpus that has been emptied passes every test below.

    `pytest.mark.parametrize` over an empty list is zero tests and a green run,
    so the collection itself has to be asserted or deleting the directory would
    look like success.
    """
    assert len(CASES) >= 10, f"only {len(CASES)} corpus cases — has the directory been pruned?"


@pytest.mark.parametrize("path", CASES, ids=lambda p: p.stem)
def test_a_known_case_still_produces_its_known_result(path):
    """The whole corpus, one test per case so a failure names the case.

    Compared field by field rather than as one blob, because "the determination
    changed" is not a useful failure message and "the failing rules changed from
    X to Y" is.
    """
    case = json.loads(path.read_text())
    result = evaluate_snapshot(_pack(case["pack"]), case["snapshot"])
    expected = case["expect"]

    assert result["outcome"] == expected["outcome"], case["why"]

    failing = sorted(r["rule_id"] for r in result["rule_results"] if not r["passed"])
    assert failing == expected["failing_rules"], case["why"]

    codes = sorted({r["reason_code"] for r in result["rule_results"] if not r["passed"]})
    assert codes == expected["reason_codes"], case["why"]

    assert result["rules_not_applicable"] == expected["rules_not_applicable"], case["why"]


@pytest.mark.parametrize("path", CASES, ids=lambda p: p.stem)
def test_every_case_says_what_it_is_for(path):
    """A case with no explanation is one nobody dares change and nobody
    understands. In a year, `why` is the only thing that will say whether a
    changed answer is a regression or an intended correction."""
    case = json.loads(path.read_text())
    assert case["id"] == path.stem
    assert len(case["why"]) > 60, f"{path.name}: 'why' is too short to be useful"
    assert (PACKS / f"{case['pack']}.json").exists(), f"{path.name} names a pack that is gone"


def test_the_corpus_covers_every_outcome():
    """A corpus of nothing but ALLOWs would pass while the engine had forgotten
    how to block."""
    outcomes = {json.loads(p.read_text())["expect"]["outcome"] for p in CASES}
    assert outcomes == {"ALLOW", "REFER", "BLOCK"}, outcomes


def test_the_corpus_covers_every_shipped_pack_and_both_dsl_versions():
    """Coverage of the *content*, not only of the engine.

    Both DSL versions specifically: `au_v1` is a version-1 pack, and a corpus
    that only exercised version 2 would not notice the day version-1 evaluation
    quietly stopped working — which is the one thing invariant 5 promises will
    never happen.
    """
    used = {json.loads(p.read_text())["pack"] for p in CASES}
    shipped = {p.stem for p in PACKS.glob("*.json")}
    assert used >= {"au_v1", "au_v2"}, used

    versions = {_pack(name).dsl_version for name in used}
    assert versions == {1, 2}, f"the corpus exercises only DSL {versions}"

    # Not every pack needs a case, but a pack with none is worth knowing about.
    uncovered = sorted(shipped - used)
    assert len(uncovered) <= 1, f"packs with no corpus case at all: {uncovered}"


def test_every_bug_case_is_named_as_one():
    """The naming convention that makes the corpus readable at a glance.

    `bug-` cases are regressions that must never come back; `edge-` cases are
    boundaries somebody reasoned about; `seed-` cases are the demo cast. A case
    with none of those prefixes is one nobody classified.
    """
    for path in CASES:
        assert path.stem.split("-")[0] in {"bug", "edge", "seed"}, (
            f"{path.name}: name it bug-, edge- or seed- so a reader knows what it is"
        )

    bugs = [p for p in CASES if p.stem.startswith("bug-")]
    assert bugs, "no regression cases at all — every bug found should leave one"
