"""Malformed packs and snapshots produce errors, never wrong answers.

The execution document asks for this in one line and it is worth expanding,
because "never crashes" is the weaker half of the requirement and the easier one
to satisfy accidentally. The failure that matters is not a stack trace — it is a
malformed pack that *evaluates anyway* and returns a determination. A crash is
loud and gets fixed. A pack with a typo that silently allows everything is a
compliance system reporting that everything is fine.

So each test below asserts a specific refusal, not merely the absence of a
crash. Damaged content must be caught by the validator; damaged data must refer;
and the outcome must never be ALLOW on input nobody wrote deliberately.

**The corpus is persisted.** Hypothesis writes failing examples to
`.hypothesis/examples`, which CI caches, so an input that broke the fuzzer once
is retried first on every subsequent run. The weekly job runs the same tests with
a far larger budget — see `.github/workflows/fuzz.yml`.
"""

from __future__ import annotations

import copy
import json
import os
from pathlib import Path

import pytest
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st
from strategies import packs, snapshots

from app.engine import ALLOW, DATA_MISSING, Pack, PackError, evaluate_snapshot, validate

PACKS = Path(__file__).resolve().parents[2] / "packs"

#: Raised by the weekly job. Kept modest per-commit for the reason the property
#: suite gives: a slow suite is a suite somebody stops running.
EXAMPLES = int(os.getenv("QUOLIN_FUZZ_EXAMPLES", "50"))

settings.register_profile(
    "fuzz",
    max_examples=EXAMPLES,
    deadline=None,
    suppress_health_check=[HealthCheck.too_slow, HealthCheck.data_too_large],
)
settings.load_profile("fuzz")


#: Every way of damaging a pack that a person could plausibly produce: a renamed
#: threshold, a deleted table, a retyped operator. Deliberately not random bytes
#: — a pack is JSON authored by a specialist, and garbage that could never be
#: written tests the JSON parser rather than the engine.
def _damage(body: dict, kind: str, seed: int) -> dict:
    body = copy.deepcopy(body)
    rules = body["rules"]
    rule = rules[seed % len(rules)]
    # The scope goes, so the damaged rule always runs. Without this the fuzzer
    # spends its budget generating packs whose broken rule is scoped out of the
    # snapshot — which produces a clean ALLOW and a failure that is about the
    # generator rather than about the engine.
    rule.pop("applies_to", None)

    if kind == "unknown_op":
        rule["predicate"] = {"op": "approximately", "left": {"const": 1}, "right": {"const": 2}}
    elif kind == "unknown_threshold":
        rule["predicate"] = {
            "op": "lte",
            "left": {"const": 1},
            "right": {"threshold": "a_threshold_nobody_defined"},
        }
    elif kind == "unknown_calc":
        rule["predicate"] = {
            "op": "lte",
            "left": {"calc": "post_trade_crypto_percentage"},
            "right": {"const": 1},
        }
    elif kind == "unknown_field":
        rule["predicate"] = {
            "op": "lte",
            "left": {"field": "client.net_worth_in_guineas"},
            "right": {"const": 1},
        }
    elif kind == "missing_operand":
        rule["predicate"] = {"op": "lte", "left": {"const": 1}}
    elif kind == "empty_term":
        rule["predicate"] = {"op": "lte", "left": {}, "right": {"const": 1}}
    elif kind == "float_threshold":
        # The rule is pointed at the threshold as well as the value being
        # damaged. Setting the value alone is not reliably damage: a pack whose
        # rules never read `limit_a` evaluates perfectly well with a decimal
        # sitting unread in the table, which is a fact about that pack rather
        # than about the engine.
        body["thresholds"]["limit_a"] = 0.5
        rule["predicate"] = {
            "op": "lte",
            "left": {"calc": "post_trade_crypto_bps"},
            "right": {"threshold": "limit_a"},
        }
    elif kind == "orphan_reason":
        rule["reason_code"] = "A_CODE_THE_PACK_NEVER_DEFINED"
    elif kind == "allow_on_fail":
        rule["on_fail"] = "ALLOW"
    elif kind == "duplicate_id":
        rules.append(copy.deepcopy(rule))
    elif kind == "no_rules":
        body["rules"] = []
    elif kind == "deleted_thresholds":
        # Same reasoning: the rule is made to need a threshold first, or
        # deleting the table damages nothing.
        rule["predicate"] = {
            "op": "lte",
            "left": {"const": 1},
            "right": {"threshold": "limit_a"},
        }
        body["thresholds"] = {}
    return body


DAMAGE = [
    "unknown_op",
    "unknown_threshold",
    "unknown_calc",
    "unknown_field",
    "missing_operand",
    "empty_term",
    "float_threshold",
    "orphan_reason",
    "allow_on_fail",
    "duplicate_id",
    "no_rules",
    "deleted_thresholds",
]


# ------------------------------------------------------------ damaged packs --


@given(body=packs(), kind=st.sampled_from(DAMAGE), seed=st.integers(0, 1000))
def test_a_damaged_pack_is_refused_by_the_validator(body, kind, seed):
    """The load-time gate, over every kind of damage a person could write.

    The assertion is that the validator *names* a fault — not that something
    somewhere went wrong. A pack that loads clean and then explodes at evaluation
    has passed the check that was supposed to catch it.
    """
    damaged = _damage(body, kind, seed)
    faults = validate(Pack.from_body(damaged))
    assert faults, f"{kind} was not caught by the validator"
    assert all(isinstance(f, str) and f for f in faults)


#: Damage that makes a rule impossible to evaluate. These must never produce a
#: determination at all — the engine has to refuse rather than answer.
#:
#: The other kinds are damage to the *explanation* rather than to the logic: an
#: orphaned reason code matters only when the rule fails, and a rule that would
#: allow on failure still allows when it passes. Both are caught by the validator
#: above; asserting they change an outcome would be asserting something untrue,
#: and a test that demands the wrong thing is worse than no test.
UNEVALUATABLE = [
    "unknown_op",
    "unknown_threshold",
    "unknown_calc",
    "missing_operand",
    "empty_term",
    "float_threshold",
    "deleted_thresholds",
]


@given(body=packs(), kind=st.sampled_from(UNEVALUATABLE), seed=st.integers(0, 1000))
def test_a_pack_that_cannot_be_evaluated_refuses_rather_than_answering(body, kind, seed):
    """The failure that matters more than a crash.

    A damaged pack that returns ALLOW is a compliance system reporting that
    everything is fine because its rules are broken. The engine must refuse — and
    refuse as `PackError`, which is what the callers above know how to turn into
    a 4xx. A `KeyError` from a bare subscript reads to everything upstream as a
    bug in the engine rather than a fault in the pack, which is how a malformed
    condition used to escape.
    """
    damaged = _damage(body, kind, seed)
    snapshot = _plain_snapshot(damaged)

    try:
        result = evaluate_snapshot(Pack.from_body(damaged), snapshot)
    except PackError:
        return  # refused, which is the correct answer
    except Exception as exc:
        pytest.fail(f"{kind} raised {type(exc).__name__} rather than PackError: {exc}")

    assert result["outcome"] != ALLOW, f"{kind} produced a clean ALLOW"


@given(body=packs(), seed=st.integers(0, 1000))
def test_a_failing_rule_always_has_something_to_say(body, seed):
    """A refusal with no explanation is a refusal nobody can act on.

    The counterpart to the test above, for the damage that harms the explanation
    rather than the logic. An orphaned reason code is caught by the validator —
    but if one ever reached evaluation, the reason card must not come out blank.
    """
    from app.engine import failing_reasons

    damaged = _damage(body, "orphan_reason", seed)
    pack = Pack.from_body(damaged)
    try:
        result = evaluate_snapshot(pack, _plain_snapshot(damaged))
    except PackError:
        return

    for reason in failing_reasons(result, pack):
        assert reason["reason_code"], "a failing rule with no reason code"
        assert reason["reason_title"], f"{reason['rule_id']} prints no title"


def _plain_snapshot(body: dict) -> dict:
    known = next(iter(body["asset_classes"].values()), {"class": "major", "volatility_band": 2})
    return {
        "as_of": "2026-01-01",
        "licensee": {"jurisdiction": "GEN"},
        "client": {
            "id": "fuzz",
            "age_years": 40,
            "client_category": "retail",
            "residency": "retail",
            "domicile": "retail",
            "knowledge_assessed": True,
            "knowledge_assessed_days_ago": 10,
            "loss_capacity_band": 3,
            "vulnerability_flag": False,
            "assessable_portfolio_cents": 1_000_000,
            "prior_crypto_purchases": 1,
            "structural_acks": [],
        },
        "asset": {
            "id": "GEN-ASSET",
            "class": known["class"],
            "volatility_band": known.get("volatility_band", 2),
            "leverage": False,
            "structural_flags": [],
        },
        "jurisdictions": {},
        "trade": {"amount_cents": 1000},
        "calc": {
            "existing_crypto_cents": 0,
            "post_trade_crypto_cents": 1000,
            "post_trade_crypto_bps": 10,
            "trade_share_bps": 10,
        },
    }


# -------------------------------------------------------- damaged snapshots --


@given(snapshot=snapshots(), drop=st.integers(min_value=0, max_value=20))
def test_a_snapshot_with_a_field_removed_refers_rather_than_crashing(snapshot, drop):
    """Every removable field, against a real pack.

    DSL v2's whole promise, fuzzed: whichever field is gone, the answer is a
    determination that refers — never an exception reaching the caller, and never
    an ALLOW that was reached without reading the missing fact.
    """
    body = json.loads((PACKS / "au_v2.json").read_text())
    pack = Pack.from_body(body)

    snapshot = copy.deepcopy(snapshot)
    snapshot["asset"]["class"] = next(iter(pack.asset_classes.values()))["class"]

    fields = [(s, f) for s in ("client", "asset", "trade") for f in snapshot[s]]
    section, field = fields[drop % len(fields)]
    del snapshot[section][field]

    result = evaluate_snapshot(pack, snapshot)

    # Not every field is read by a rule — removing `asset.symbol` changes
    # nothing, and asserting otherwise would be demanding that the engine care
    # about a fact no rule consults. What must hold is that it answered at all,
    # and that wherever it *did* notice the absence it referred rather than
    # deciding.
    assert result["outcome"] in ("ALLOW", "REFER", "BLOCK")
    missing = [r for r in result["rule_results"] if r["reason_code"] == DATA_MISSING]
    if missing:
        assert result["outcome"] in ("REFER", "BLOCK")
        assert all(r["outcome"] == "REFER" for r in missing)
        assert all(r["inputs_read"][0]["ref"] for r in missing), "the field is not named"


@given(snapshot=snapshots())
def test_an_entirely_empty_snapshot_refers_and_does_not_crash(snapshot):
    """The degenerate case, which is what an integration bug actually produces."""
    body = json.loads((PACKS / "au_v2.json").read_text())
    result = evaluate_snapshot(Pack.from_body(body), {"asset": {"class": "major"}})
    assert result["outcome"] == "REFER"
    assert all(
        r["reason_code"] == DATA_MISSING
        for r in result["rule_results"]
        if not r["passed"]
    )


# ------------------------------------------------------------ malformed JSON --


@pytest.mark.parametrize(
    "body",
    [
        {},
        {"pack_id": "X"},
        {"pack_id": "X", "version": 1},
        {"pack_id": "X", "version": 1, "effective_from": "not-a-date"},
        {"pack_id": "X", "version": 1, "effective_from": "2020-01-01", "thresholds": {}},
    ],
    ids=["empty", "id-only", "no-dates", "bad-date", "no-rules"],
)
def test_a_structurally_incomplete_pack_is_refused_when_it_is_loaded(body):
    """Loading is allowed to raise. What it may not do is succeed."""
    with pytest.raises((PackError, KeyError, ValueError, TypeError)):
        check_loads(body)


def check_loads(body: dict) -> None:
    from app.engine import check

    check(Pack.from_body(body))
