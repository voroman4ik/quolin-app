"""The sweep, run with exactly what `infra/compute.tf` gives the watch task.

FP3-03, and FP3-09's replacement for three tests that read source text.

The 27 August sweep wired `source.stale` by having `scripts/watch_tick.py` call
`source_alerts.notify_tenants(source_alerts.all_tenant_ids(), breaches)`. Both
halves of that line open an engine the watch task has no connection string for —
`all_tenant_ids` uses `OwnerSessionLocal` (`DATABASE_URL`) and `notify_tenants`
uses `SessionLocal` (`APP_DATABASE_URL`) — and
`scripts/guard_no_watch_in_engine.sh` check 6 *fails the build* if the task is
given either. In production both fall back to `db.py`'s hardcoded
`localhost:5433`, so the sweep raised on every run with a source in breach.

**Three things stopped anyone seeing it**, and all three are addressed here
rather than argued about:

* The test asserting the wiring was `assert "notify_tenants" in
  Path("scripts/watch_tick.py").read_text()`. The explanatory comment ten lines
  above the call contains that string, so deleting the call and keeping the
  comment passed.
* The subprocess test that did run the sweep passed `{**os.environ, ...}`, which
  on a laptop and in CI holds all three connection strings. It proved the sweep
  works in an environment production does not provide.
* Nothing asserted which engines the sweep opens.

So: the environment comes from the task definition itself (one place, parsed —
see `scripts/task_environment.py`), and the claim is checked by instrumenting
`engine.connect` and reading back the set of DSNs actually opened.

**And the Gate A audit found what this file still could not see.** Every
subprocess below runs under `sys.executable` — the suite's own virtualenv, where
every dependency is present. The deployed task ran
`["python", "-m", "scripts.watch_tick"]` against an image whose dependencies
live in `/app/.venv` and whose bare `python` was the base image's, so it died on
its first third-party import. Nothing here could tell: the assertions are
faithful about the environment and silent about the interpreter, and no amount
of care with the first can reach the second.

The claim this file makes is therefore narrowed to the one it can support — *the
sweep opens only the watch engine, and reads no connection string it is not
given* — which is a real property and is FP3-03's. The claim it cannot support
is `scripts/image_smoke.py`, which builds the image and runs each task's exact
command inside it, and `make image-smoke` in CI.

What is added here is the half of that which needs no docker: the task
definitions and the Dockerfile have to agree about which interpreter runs a
scheduled task. They had drifted, in three places, and nothing compared them.

**H2, and it is about where the real catch lives.** The Gate A close's audit
observed that the interpreter test here would not have caught the original bug
on its own — the deployed command *is* a bare `python`, and it is correct
because the image puts the virtualenv on PATH. That makes the real catch
`scripts/image_smoke.py`, which needs docker, which means the guarantee rests on
a CI job actually running. Nothing asserted that it does.

Two things follow, and both are below.
`test_every_task_command_runs_the_interpreter_the_image_provides` now asserts
the PATH guarantee in the same test that permits the bare name, so the pair
cannot be separated. And `test_the_image_smoke_actually_runs_in_ci` reads
`.github/workflows/ci.yml` and fails if the smoke step is absent, conditional,
or allowed to fail — because a check that can be skipped silently is a check
whose absence looks exactly like a pass, which is §S13's rule and the reason
`scripts/guard_lib.sh` exists.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from scripts.task_environment import task_definitions  # noqa: E402

WATCH_TASK = "watch"

#: The watch role's connection, which is the one credential the task holds.
#: Taken from the suite's own environment because a DSN is a deployment fact,
#: not a repository one — but it is the *only* value carried across, and the
#: names of everything else come from the task definition.
WATCH_DSN = os.environ.get(
    "WATCH_DATABASE_URL",
    "postgresql+psycopg://quolin_watch:quolin_watch@localhost:5433/quolin",
)


def deployed_environment() -> dict[str, str]:
    """Exactly the variables `infra/compute.tf` gives the watch container.

    Not `{**os.environ, ...}`. That is the whole point: inheriting the parent
    environment is what made the previous version of this test green about a
    deployment it was not describing.
    """
    task = task_definitions()[WATCH_TASK]
    env = {name: "" for name in sorted(task.names)}

    # PATH and HOME are not in the task definition because ECS does not put them
    # there — the container image provides them. Everything else must not be.
    env["PATH"] = os.environ.get("PATH", "/usr/bin:/bin")
    env["HOME"] = os.environ.get("HOME", "/tmp")

    env["WATCH_DATABASE_URL"] = WATCH_DSN
    env["WATCH_MODE"] = "replay"
    env["QUOLIN_ENVIRONMENT"] = "test"
    env["AWS_REGION"] = "ap-southeast-2"
    return env


DOCKERFILE = REPO / "api" / "Dockerfile"

#: Where the image's dependencies live, and therefore what `python` has to be.
#: Spelled here, in the Dockerfile and in `scripts/image_smoke.py`, and the
#: first test below is what stops the three drifting.
VENV_BIN = "/app/.venv/bin"


def test_the_image_puts_its_virtualenv_on_the_path():
    """The convention every task command depends on, asserted about the image.

    `uv sync` installs into `/app/.venv`. Unless that is on PATH, `python`
    is `/usr/local/bin/python` — the base image's interpreter, with none of this
    project's dependencies — and every command that does not wrap itself in
    `uv run` fails on its first third-party import.

    The API's CMD *did* wrap itself, which is why this went unnoticed for as
    long as it did: the API worked and the three scheduled tasks did not.
    """
    dockerfile = DOCKERFILE.read_text()
    assert f'PATH="{VENV_BIN}:' in dockerfile, (
        f"api/Dockerfile does not put {VENV_BIN} on PATH. Every task definition "
        "in infra/ runs a bare `python`, and without this that is the base "
        "image's interpreter."
    )


def test_the_dependency_install_has_no_fallback_that_could_swallow_a_failure():
    """A build that cannot resolve the lock must fail, not install a subset.

    This read `uv sync … 2>/dev/null || uv pip install --system <eight
    packages>`. The redirect threw away the only description of what went wrong
    and the alternative installed a reduced set — no `alembic`, no
    `cryptography`, no `argon2-cffi`, no `pyjwt` — into a different interpreter.
    A lock resolution failure therefore built green and crashed at runtime, on
    whichever path first reached a package nobody had listed.
    """
    dockerfile = DOCKERFILE.read_text()
    # Instructions, not the comment above them that quotes what was removed.
    # A guard that refused to let its own history be written down is one people
    # route around — the same rule `guard_no_shared_passcode.sh` applies to
    # `docs/`.
    sync_lines = [
        line
        for line in dockerfile.splitlines()
        if "uv sync" in line and not line.lstrip().startswith("#")
    ]
    assert sync_lines, "api/Dockerfile no longer installs anything with uv sync"
    for line in sync_lines:
        assert "2>/dev/null" not in line, (
            f"a uv sync is silenced: {line.strip()!r}. A build failure nobody "
            "can see is worse than one that stops the build."
        )
        assert "||" not in line, (
            f"a uv sync has a fallback: {line.strip()!r}. The fallback installed "
            "a reduced package set, so the failure moved from build time to "
            "runtime and changed shape on the way."
        )


#: The bare entrypoints a task may use, and the guarantee each one rests on.
#:
#: One name, because one is what the image establishes. `sh` and `uv` were on
#: this list and nothing used either — permission nobody needs, which is the
#: same finding `scripts/deployed_workers.py` makes about the scheduler policy.
#: A task that genuinely needs a shell is a deliberate change and adds itself
#: here with its reason.
BARE_ENTRYPOINTS = {"python"}


@pytest.mark.parametrize("resource", sorted(task_definitions()))
def test_every_task_command_runs_the_interpreter_the_image_provides(resource):
    """The comparison nothing made, across every task rather than the one.

    `infra/compute.tf` and `api/Dockerfile` are two files that have to agree
    about what `python` means, and they did not.

    **H2: the two halves of that agreement are asserted here together.** This
    read `entrypoint in ("python", "sh", "uv")` and stopped, which the Gate A
    close's audit correctly called a check that would not have caught the
    original bug on its own — a bare `python` was exactly what the three
    scheduled tasks ran, and it resolved to the base image's interpreter.

    What makes a bare `python` correct is a property of the *image*, so a test
    that permits one has to assert that property in the same breath. Two tests,
    each true and neither mentioning the other, is how the pair came apart the
    first time: `test_the_image_puts_its_virtualenv_on_the_path` below can be
    deleted, skipped or made vacuous without this one noticing.

    **Deviation, recorded here because a reader will otherwise wonder.** The
    finding's own suggestion is to reject a bare interpreter outright — which
    means spelling `/app/.venv/bin/python` in every task definition. That is the
    weaker of the two available fixes and `api/Dockerfile` argues against it at
    length: a prefix has to be remembered at every call site (an ECS override, a
    `docker run`, a shell in a running container, a healthcheck), and putting
    the virtualenv on PATH makes the *default* correct instead. It also puts an
    image's internal layout into Terraform, which is a second pair of files that
    must agree about what `python` means — the class of defect this whole test
    exists for. So the interpreter stays bare and the guarantee is asserted.

    Whether the module then *imports* is `scripts/image_smoke.py`, which needs
    docker, runs in CI, and is asserted to run in CI by
    `test_the_image_smoke_actually_runs_in_ci` below.
    """
    task = task_definitions()[resource]
    if not task.command:
        return  # the image's own CMD, which the Dockerfile owns

    entrypoint = task.command[0]

    if entrypoint.startswith("/"):
        # An absolute path answers for itself and needs no PATH guarantee.
        assert entrypoint.startswith(f"{VENV_BIN}/"), (
            f"{resource} runs {entrypoint!r}, an absolute path outside "
            f"{VENV_BIN}. That is the base image's interpreter, which has none "
            "of this project's dependencies."
        )
        return

    assert entrypoint in BARE_ENTRYPOINTS, (
        f"{resource} runs {entrypoint!r}, which is not one of the entrypoints "
        "api/Dockerfile establishes. See the entrypoint convention in "
        "docs/deployment.md — a task that invents its own is a task that will "
        "resolve to something nobody chose."
    )

    # And the guarantee that makes the bare name correct, in this test, about
    # this task. Without it the assertion above says only that somebody typed a
    # word from a list of one.
    dockerfile = DOCKERFILE.read_text()
    assert f'PATH="{VENV_BIN}:' in dockerfile, (
        f"{resource} runs a bare {entrypoint!r} and api/Dockerfile no longer "
        f"puts {VENV_BIN} on PATH. That pairing is the original defect exactly: "
        "the command resolves to /usr/local/bin/python, the base image's "
        "interpreter, and the task dies on its first third-party import with "
        "nothing in EventBridge distinguishing it from a task that ran."
    )


def test_the_task_definition_still_withholds_the_other_two_connections():
    """If this ever stops being true, the rest of this file is testing nothing.

    Read from the task definition rather than asserted about a string, so that
    renaming the resource or moving the block does not silently make it vacuous.
    """
    task = task_definitions()[WATCH_TASK]
    assert "WATCH_DATABASE_URL" in task.secrets
    assert "DATABASE_URL" not in task.names, (
        "the watch task has been given the schema-owner connection"
    )
    assert "APP_DATABASE_URL" not in task.names, (
        "the watch task has been given the application connection"
    )
    assert task.command == ("python", "-m", "scripts.watch_tick")


def test_the_sweep_completes_with_only_the_credential_it_is_deployed_with():
    """The reproduction, inverted.

    Before FP3-03 this raised: `all_tenant_ids()` is an argument to
    `notify_tenants(...)`, so it was evaluated on *every* sweep whether or not
    anything was in breach, and it opens the owner engine.

    **Under `sys.executable`, and that is a limit rather than an oversight.**
    This proves the sweep needs no credential it is not given. It says nothing
    about whether the deployed image can start it — that is a fact about an
    interpreter, and `scripts/image_smoke.py` is where it is asserted.
    """
    result = subprocess.run(
        [sys.executable, "-m", "scripts.watch_tick"],
        cwd=REPO,
        env=deployed_environment(),
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, (
        "the watch sweep failed in the environment its own task definition "
        f"gives it.\nstdout:\n{result.stdout}\nstderr:\n{result.stderr}"
    )
    assert "connected as     quolin_watch" in result.stdout


def test_the_sweep_opens_no_engine_but_the_watch_one():
    """Which connections were opened, asked of SQLAlchemy rather than of a file.

    The test this replaces was `assert "WatchSessionLocal" in sweep`, reading
    `scripts/watch_tick.py` as text. That assertion is satisfied by a comment,
    and it says nothing about the two engines `app.db` constructs at import time
    and hands to whatever asks.

    This runs the real entry point in a subprocess with the deployed environment
    and a `sitecustomize` that listens on `engine.connect` for every engine in
    `app.db`, then reads back the set of DSNs that were actually opened.
    """
    probe = REPO / "api" / "tests" / "_watch_dsn_probe.py"
    env = deployed_environment()
    env["PYTHONPATH"] = str(REPO / "api")

    result = subprocess.run(
        [sys.executable, str(probe)],
        cwd=REPO,
        env=env,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr

    opened = json.loads(result.stdout.strip().splitlines()[-1])
    assert opened == ["watch_engine"], (
        "the watch sweep opened an engine other than the watch one. In "
        "production those connection strings are absent and fall back to "
        f"localhost:5433, where nothing is listening. Opened: {opened}"
    )


@pytest.mark.parametrize("forbidden", ["DATABASE_URL", "APP_DATABASE_URL"])
def test_the_sweep_does_not_read_a_connection_string_it_is_not_given(forbidden):
    """Belt and braces, and it catches the case the DSN probe cannot.

    A future change that reads `os.environ["DATABASE_URL"]` directly rather than
    through `app.db` would open no engine and still be broken in production.
    Here the variable is present and points at a database that does not exist,
    so anything that reaches for it fails loudly instead of silently succeeding
    against the developer's own server.
    """
    env = deployed_environment()
    env[forbidden] = "postgresql+psycopg://nobody:nobody@127.0.0.1:1/nothing"

    result = subprocess.run(
        [sys.executable, "-m", "scripts.watch_tick"],
        cwd=REPO,
        env=env,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, (
        f"the sweep used {forbidden}, which its task definition does not give "
        f"it.\nstdout:\n{result.stdout}\nstderr:\n{result.stderr}"
    )


# ------------------------------------------------- the check that needs docker --

#: The workflow the smoke job lives in, and the command it has to run.
CI_WORKFLOW = REPO / ".github" / "workflows" / "ci.yml"
SMOKE_COMMAND = "make image-smoke"


def _steps(workflow: dict) -> list[tuple[str, dict]]:
    """Every step in every job, as `(job name, step)`."""
    out: list[tuple[str, dict]] = []
    for name, job in (workflow.get("jobs") or {}).items():
        for step in job.get("steps") or []:
            out.append((name, step))
    return out


def test_the_image_smoke_actually_runs_in_ci():
    """H2. The behavioural guarantee of Fix 4 rests on a job, so the job is asserted.

    `scripts/image_smoke.py` is the only thing in this repository that runs a
    deployed command against the image that will run it. It needs docker, so it
    cannot live in `pytest` — which means the guarantee is only as good as a
    step in a YAML file that nothing was reading.

    Three ways that step can stop being a check without stopping being present,
    and all three fail here:

      * it is deleted, or the command is renamed;
      * `continue-on-error: true` is added, which makes a failure a green run;
      * an `if:` is added, which makes "did not run" indistinguishable from
        "ran and passed" in the job summary.

    The script's own answer to a missing docker is already exit 2 rather than a
    skip — see its `main()` — so what is left to assert is that CI still calls
    it and still believes the answer.

    Read from the workflow rather than asserted about a comment, for the reason
    every check in this file is: a string in a document is satisfied by the
    sentence explaining it.
    """
    import yaml

    assert CI_WORKFLOW.exists(), f"{CI_WORKFLOW} is missing; there is no CI to check"
    workflow = yaml.safe_load(CI_WORKFLOW.read_text())

    smoke = [
        (job, step)
        for job, step in _steps(workflow)
        if SMOKE_COMMAND in str(step.get("run", ""))
    ]
    assert smoke, (
        f"no step in {CI_WORKFLOW.name} runs {SMOKE_COMMAND!r}. That is the only "
        "check in this repository that runs a deployed command against the "
        "image that will run it — every scheduled task died on its first "
        "third-party import and no unit test could see it, because the suite's "
        "own interpreter has every dependency."
    )

    for job, step in smoke:
        assert not step.get("continue-on-error"), (
            f"the {SMOKE_COMMAND!r} step in job {job!r} is marked "
            "continue-on-error, so a failure is a green build. A smoke test "
            "that cannot fail the pipeline is a smoke test that reports a pass "
            "nothing earned."
        )
        assert "if" not in step, (
            f"the {SMOKE_COMMAND!r} step in job {job!r} is conditional "
            f"({step.get('if')!r}). A skipped step and a passing step look the "
            "same from outside, which is precisely the failure §S13 names: "
            "silence is never a pass."
        )
