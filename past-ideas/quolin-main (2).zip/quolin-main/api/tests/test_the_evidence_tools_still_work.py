"""The scripts that demonstrate the evidence guarantees, actually run.

`make tamper-demo` is the step of the demo script that makes the tamper-evidence
claim checkable in the room, and `make nightly-replay` is invariant 5 as a
scheduled job. Both recompute a determination's hash from its stored columns,
and neither had a test.

That gap shipped a defect. Q-04 added a payload schema so the execution manifest
could be introduced without rehashing history, and every caller of
`evidence._hashable` had to start passing the row's own schema.
`scripts/rechain.py` was updated; `scripts/tamper_demo.py` was missed. Its only
symptom was a script telling an audience, in a meeting, that the chain was
already broken.

So `_hashable` now requires `schema` and `execution_manifest` rather than
defaulting them — a missed call site should be a TypeError — and these tests run
the tools rather than trusting that they were remembered.

Run as subprocesses on purpose. What broke was the script, not a function it
calls, and importing its internals would test the half that was already fine.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]

#: The tools that recompute an evidence hash from stored columns. Each one is a
#: place the payload shape has to be got right, and each is a place it can
#: silently be got wrong.
TOOLS = (
    ("tamper_demo", ()),
    ("nightly_replay", ()),
    ("rechain", ()),  # dry run by default; writes nothing without --apply
)


@pytest.mark.parametrize("tool,args", TOOLS, ids=lambda v: v if isinstance(v, str) else "")
def test_the_tool_runs_against_the_seeded_database(tool, args) -> None:
    result = subprocess.run(
        [sys.executable, "-m", f"scripts.{tool}", *args],
        cwd=REPO,
        capture_output=True,
        text=True,
        timeout=300,
    )
    assert result.returncode == 0, (
        f"`python -m scripts.{tool}` exited {result.returncode}.\n"
        f"--- stdout ---\n{result.stdout[-3000:]}\n"
        f"--- stderr ---\n{result.stderr[-3000:]}"
    )


def test_the_tamper_demo_shows_the_forged_hash_differing() -> None:
    """Not merely exits 0 — says the thing it exists to say.

    A script that printed nothing and returned 0 would pass the test above and
    demonstrate nothing, which is the failure mode this whole file is about.
    """
    result = subprocess.run(
        [sys.executable, "-m", "scripts.tamper_demo"],
        cwd=REPO,
        capture_output=True,
        text=True,
        timeout=300,
    )
    assert result.returncode == 0, result.stderr[-2000:]
    assert "Chain verifies" in result.stdout, result.stdout[-2000:]
    assert "append-only" in result.stdout.lower(), result.stdout[-2000:]
    assert "already broken" not in result.stdout, (
        "the demo reports the chain as broken before any tampering. That is what "
        "a payload recomputed under the wrong schema looks like."
    )
