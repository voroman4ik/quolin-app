"""§S11's network register, and whether its checker can actually say no.

`make new-stack ARGS=--check` runs on every CI push against the real register,
which is valid — and would stay green whether the overlap detection worked or
had been commented out. A checker that has only ever been run against a correct
input is indistinguishable from one that always says yes, and this file is the
difference.

So every test here points the script at a fixture directory containing a
register that is wrong in one specific way, and asserts it says so. The failure
these guard against is not hypothetical: two stacks with overlapping CIDRs apply
cleanly, run fine, and collide the day somebody routes between them, when both
hold a customer's evidence and neither can be renumbered without downtime.

Run as a subprocess rather than by importing `check`, for the reason
`test_nightly_replay.py` gives: what runs in CI is the command line, including
its exit code, and that is what a build watches.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[2]

HEADER = "| Slug | CIDR | Tenancy | Status | Note |\n|---|---|---|---|---|\n"


def register(tmp_path: Path, rows: str, files: dict[str, str] | None = None) -> Path:
    """An envs directory holding one register and whatever tfvars are named."""
    envs = tmp_path / "envs"
    envs.mkdir(exist_ok=True)
    (envs / "allocations.md").write_text(HEADER + rows)
    for name, body in (files or {}).items():
        (envs / name).write_text(body)
    return envs


def run(envs: Path, *args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "-m", "scripts.new_stack", "--envs", str(envs), *args],
        cwd=REPO,
        capture_output=True,
        text=True,
    )


def test_a_clean_register_passes(tmp_path):
    envs = register(
        tmp_path,
        "| alpha | 10.32.0.0/16 | dedicated | live | x |\n",
        {"alpha.tfvars": 'vpc_cidr = "10.32.0.0/16"\n'},
    )
    result = run(envs, "--check")
    assert result.returncode == 0, result.stderr
    assert "no overlapping ranges" in result.stdout


def test_overlapping_ranges_are_caught(tmp_path):
    """A /17 inside a /16 — the shape a person allocating by hand produces."""
    envs = register(
        tmp_path,
        "| alpha | 10.32.0.0/16 | dedicated | live | x |\n"
        "| beta  | 10.32.0.0/17 | dedicated | live | x |\n",
        {
            "alpha.tfvars": 'vpc_cidr = "10.32.0.0/16"\n',
            "beta.tfvars": 'vpc_cidr = "10.32.0.0/17"\n',
        },
    )
    result = run(envs, "--check")
    assert result.returncode == 2
    assert "overlaps" in result.stderr


def test_a_stack_missing_from_the_register_is_caught(tmp_path):
    """The whole point: a range allocated from memory rather than from the file."""
    envs = register(
        tmp_path,
        "| alpha | 10.32.0.0/16 | dedicated | live | x |\n",
        {
            "alpha.tfvars": 'vpc_cidr = "10.32.0.0/16"\n',
            "rogue.tfvars": 'vpc_cidr = "10.99.0.0/16"\n',
        },
    )
    result = run(envs, "--check")
    assert result.returncode == 2
    assert "allocated from memory" in result.stderr


def test_a_tfvars_edited_by_hand_is_caught(tmp_path):
    """The register becomes fiction the first time somebody edits around it."""
    envs = register(
        tmp_path,
        "| alpha | 10.32.0.0/16 | dedicated | live | x |\n",
        {"alpha.tfvars": 'vpc_cidr = "10.44.0.0/16"\n'},
    )
    result = run(envs, "--check")
    assert result.returncode == 2
    assert "10.44.0.0/16" in result.stderr and "10.32.0.0/16" in result.stderr


def test_a_registered_stack_with_no_tfvars_is_caught(tmp_path):
    envs = register(tmp_path, "| alpha | 10.32.0.0/16 | dedicated | live | x |\n")
    result = run(envs, "--check")
    assert result.returncode == 2
    assert "has no" in result.stderr


def test_a_retired_stack_needs_no_tfvars(tmp_path):
    """Retirement is the one case where a row outlives its files.

    A range is never returned to the pool, so a torn-down stack keeps its row —
    and the check has to tolerate that or every tear-down breaks the build.
    """
    envs = register(tmp_path, "| alpha | 10.32.0.0/16 | dedicated | retired | x |\n")
    assert run(envs, "--check").returncode == 0


def test_allocation_skips_what_is_taken(tmp_path):
    envs = register(tmp_path, "| alpha | 10.32.0.0/16 | dedicated | live | x |\n",
                    {"alpha.tfvars": 'vpc_cidr = "10.32.0.0/16"\n'})
    result = run(envs, "--slug", "beta")
    assert result.returncode == 0, result.stderr
    assert "10.33.0.0/16" in result.stdout, result.stdout
    # And what it wrote passes its own check, which is the property that makes
    # the two halves of this script trustworthy together.
    assert run(envs, "--check").returncode == 0


def test_allocation_never_hands_out_our_own_ranges(tmp_path):
    """Staging is 10.10 and production is 10.20. The pool starts above both.

    Written because the obvious implementation — "first free /16 in 10.0.0.0/8" —
    hands the first customer 10.0.0.0/16 and the second 10.1.0.0/16, and works
    perfectly until somebody peers a customer stack with production.
    """
    import importlib
    import ipaddress

    if str(REPO) not in sys.path:
        sys.path.insert(0, str(REPO))
    new_stack = importlib.import_module("scripts.new_stack")

    ours = [ipaddress.ip_network(c) for c in ("10.10.0.0/16", "10.20.0.0/16")]

    # Asserted against the pool itself, not against a handful of allocations.
    # The first version of this test allocated three stacks and checked those:
    # with the pool widened to 10.0.0.0/8 it hands out 10.0, 10.1 and 10.2, none
    # of which collide, and the test passed while the property it names was
    # gone. A test that only fails on the eleventh iteration is a test that does
    # not fail.
    for mine in ours:
        assert not new_stack.POOL.overlaps(mine), (
            f"the allocation pool {new_stack.POOL} contains {mine}, which is one "
            "of our own environments — a customer stack will eventually be "
            "handed it"
        )

    envs = register(tmp_path, "")
    for slug in ("one", "two", "three"):
        result = run(envs, "--slug", slug)
        assert result.returncode == 0, result.stderr

    allocated = [
        ipaddress.ip_network(line.split("|")[2].strip())
        for line in (envs / "allocations.md").read_text().splitlines()
        if line.startswith("| ") and "dedicated" in line
    ]
    assert allocated, "nothing was allocated"
    for network in allocated:
        assert not any(network.overlaps(mine) for mine in ours), (
            f"{network} collides with one of our own environments"
        )


def test_a_slug_that_would_not_survive_being_a_hostname_is_refused(tmp_path):
    """It becomes the subdomain, the database identifier and the log prefix."""
    envs = register(tmp_path, "")
    # `--slug=x` rather than `--slug x`, so a value beginning with a hyphen
    # reaches the validator instead of being read by argparse as a flag.
    for bad in ("Acme", "acme_corp", "a", "-acme", "acme.corp", "a" * 22):
        result = run(envs, f"--slug={bad}")
        assert result.returncode == 1, f"{bad!r} was accepted"
        assert not (envs / f"{bad}.tfvars").exists()


@pytest.mark.parametrize("slug", ["alpha"])
def test_the_same_customer_cannot_be_allocated_twice(tmp_path, slug):
    envs = register(tmp_path, f"| {slug} | 10.32.0.0/16 | dedicated | retired | x |\n")
    result = run(envs, "--slug", slug)
    assert result.returncode == 1
    assert "never reused" in result.stderr
