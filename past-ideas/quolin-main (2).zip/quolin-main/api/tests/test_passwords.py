"""The password fallback, and the properties that are worth a test.

A hash function cannot be checked against published vectors the way `totp.py`
can — Argon2 is salted, so the same password hashes differently every time and
there is nothing to pin. What can be asserted is everything around it: that the
parameters are the ones claimed and are not quietly weak, that the encoding
carries them, that a parameter change is detected, that malformed input is
refused rather than raised on, and that a missing account costs the same time as
a wrong password.

That last one is a timing assertion, which is usually a bad idea. It survives
here because both sides do the identical computation, so the ratio is stable
even on a loaded machine; the band is wide enough to never flake and narrow
enough to catch the only regression that matters, which is `waste_time` becoming
a no-op.
"""

from __future__ import annotations

import time

import pytest
from argon2 import PasswordHasher

from app import passwords

GOOD = "correct horse battery staple"


# --------------------------------------------------------------- parameters --


def test_the_parameters_are_the_ones_rfc_9106_recommends() -> None:
    """A floor, not a preference.

    Argon2's whole argument is the memory. An implementation that kept the name
    and dropped the cost — because a test suite was slow, most often — would
    still produce `$argon2id$` encodings that verify correctly and would have
    given up the property the dependency exists for.
    """
    assert passwords.MEMORY_KIB == 64 * 1024
    assert passwords.TIME_COST == 3
    assert passwords.PARALLELISM == 4


def test_the_encoding_names_the_variant_and_the_cost() -> None:
    encoded = passwords.hash_password(GOOD)
    assert encoded.startswith("$argon2id$"), "not the side-channel-resistant variant"
    assert f"m={passwords.MEMORY_KIB},t={passwords.TIME_COST},p={passwords.PARALLELISM}" in encoded


def test_the_same_password_hashes_differently_every_time() -> None:
    """Salting, observed rather than assumed.

    Without it, identical stored values would tell anyone who reached the table
    which accounts share a password, and one cracked hash would open all of them.
    """
    assert passwords.hash_password(GOOD) != passwords.hash_password(GOOD)


# ------------------------------------------------------------- verification --


def test_the_right_password_verifies_and_the_wrong_one_does_not() -> None:
    encoded = passwords.hash_password(GOOD)

    matched, rehash = passwords.verify(encoded, GOOD)
    assert matched
    assert not rehash, "a hash made with the current parameters wants rehashing"

    assert passwords.verify(encoded, GOOD + " ")[0] is False
    assert passwords.verify(encoded, GOOD.upper())[0] is False
    assert passwords.verify(encoded, "")[0] is False


def test_a_corrupted_row_is_a_refused_sign_in_rather_than_a_stack_trace() -> None:
    """Each of these is a value that could be in the column, and none is a bug.

    An empty secret is what an OIDC-only identity stores. The rest are what a
    truncated write or a bad migration leaves behind. All of them are reached
    through a login endpoint, so raising would hand an attacker a 500 they can
    provoke at will and an error log they can fill.
    """
    for stored in ["", "not a hash", "$argon2id$", "$argon2id$v=19$m=65536,t=3,p=4$"]:
        assert passwords.verify(stored, GOOD) == (False, False)


def test_a_hash_made_under_weaker_parameters_asks_to_be_rehashed() -> None:
    """The upgrade path, which only ever runs while the plaintext is in hand.

    Raising the cost is worthless if existing rows stay at the old one forever.
    This is how a stored hash finds out it is behind, and the only moment it can
    act on that is a successful sign-in — hence the flag riding back on `verify`
    rather than a background job that would need the passwords it cannot have.
    """
    weaker = PasswordHasher(time_cost=1, memory_cost=8 * 1024, parallelism=1)
    old = weaker.hash(GOOD)

    matched, rehash = passwords.verify(old, GOOD)
    assert matched, "raising the parameters invalidated an existing password"
    assert rehash, "an out-of-date hash was not flagged for upgrade"

    # And what the caller is expected to do about it settles the matter.
    assert passwords.verify(passwords.hash_password(GOOD), GOOD) == (True, False)


# -------------------------------------------------------------- enumeration --


def test_a_missing_account_costs_what_a_wrong_password_costs() -> None:
    """Otherwise the login route is a user directory.

    The gap being closed is not marginal: an Argon2 verification is around a
    tenth of a second and returning early is microseconds, which is visible over
    a network without any statistics at all.
    """
    encoded = passwords.hash_password(GOOD)

    def elapsed(fn) -> float:
        runs = []
        for _ in range(3):
            started = time.perf_counter()
            fn()
            runs.append(time.perf_counter() - started)
        return sorted(runs)[1]

    real = elapsed(lambda: passwords.verify(encoded, "wrong password entirely"))
    decoy = elapsed(passwords.waste_time)

    assert 0.4 < decoy / real < 2.5, (
        f"an absent account took {decoy:.3f}s against {real:.3f}s for a wrong "
        "password, which tells an attacker which emails have accounts"
    )


# ---------------------------------------------------------------- strength --


def test_short_passwords_are_refused_before_they_are_hashed() -> None:
    with pytest.raises(passwords.WeakPassword) as refused:
        passwords.hash_password("hunter2")
    assert str(passwords.MIN_LENGTH) in str(refused.value)

    # Exactly at the boundary is accepted; the rule is a minimum, not a target.
    assert passwords.hash_password("a" * passwords.MIN_LENGTH)


def test_a_password_that_is_the_email_address_is_refused() -> None:
    address = "compliance@harbourpoint.example"
    with pytest.raises(passwords.WeakPassword):
        passwords.hash_password(address, email=address)
    with pytest.raises(passwords.WeakPassword):
        passwords.hash_password("  " + address.upper() + " ", email=address)

    # The check is only against that account's own address.
    assert passwords.hash_password(address, email="someone.else@example.invalid")


def test_length_is_the_only_composition_rule() -> None:
    """Deliberate, and the sort of thing a reviewer should see asserted.

    Rules demanding a capital and a symbol are what produce `Passw0rd!` across a
    whole firm. A long passphrase of ordinary lowercase words is stronger and is
    accepted here, and if someone later adds a character-class rule this fails.
    """
    assert passwords.hash_password("the quiet gardener waters everything")
    assert passwords.hash_password("aaaaaaaaaaaaaaaaaaaaaaaa")
