"""A rule id or reason code of the wrong type is a fault, never a `TypeError`.

The Gate A audit's second finding, and it is two defects in one line.

    elif rule_id in seen_ids:          # the raw value
        ...
    else:
        seen_ids.add(str(rule_id))     # the normalised one

**A crash where §S3 requires a fault.** `rule_id` is whatever the JSON held.
`["a"] in set()` raises `TypeError: unhashable type: 'list'` out of `validate`,
which is not `PackError` — so `evidence.replay` could not classify it as
`PACK_INVALID_AT_REPLAY`, and the nightly job ended with a whole book left to
check. `main.engine_validate`'s 422 was equally unreachable.

**And a duplicate check that did not check.** `1 in {"1"}` is False. Two rules
both numbered `1` therefore never collided, the pack loaded, and one of the two
was invisible in every determination's evidence — which is the exact outcome the
message on that branch describes and the check exists to prevent.

`reason_code` had the same shape and the same two consequences: it is tested
with `not in pack.reason_codes`, which is a mapping, so an unhashable value
raised there too, while `_suggest(str(reason_code), …)` normalised for the
message only.

**Fixed by type-checking, not by normalising both sides.** Normalising would
have removed the crash and kept the second defect wearing a different hat: `1`
and `"1"` would become one rule id, so a pack could name a rule two ways and the
evidence would key on whichever spelling the author happened to use. A rule id
is a string, and anything else is a fault that names the index and the type.

**What the audit turned up that was not a defect.** `on_fail not in OUTCOMES`
looks identical and is safe: `OUTCOMES` is a tuple, so `in` compares with `==`
and never hashes. `_check_term` and `_shape_of` normalise with `str(...)` once
and then use the normalised value for both the lookup and the message, which is
the correct form of the same pattern. `_lookup_tables_cover_every_class` reaches
`entry.get("class")` on values `Pack.from_body` has already established are
mappings. Recorded here so the next reader auditing this class does not have to
re-derive which of the four are real.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st

from app.engine import Pack
from app.engine.dsl import PackError
from app.engine.validate import validate

PACKS = Path(__file__).resolve().parents[2] / "packs"


def _sound_body() -> dict:
    return json.loads((PACKS / "au_v2.json").read_text())


def _pack_with(**rule_overrides) -> Pack:
    """The shipped AU pack with its first rule's fields replaced."""
    body = _sound_body()
    rule = dict(body["rules"][0])
    for key, value in rule_overrides.items():
        if value is _ABSENT:
            rule.pop(key, None)
        else:
            rule[key] = value
    body["rules"] = [rule] + body["rules"][1:]
    return Pack.from_body(body)


class _Absent:
    pass


_ABSENT = _Absent()


#: Every JSON type a `rule_id` can be that is not a usable one. `json.loads` can
#: produce all of them, and `pack_drafts.body` and `packs.body` are `jsonb`.
MALFORMED_IDS = [
    pytest.param(["r-1"], id="list"),
    pytest.param({"id": "r-1"}, id="dict"),
    pytest.param(1, id="int"),
    pytest.param(1.5, id="float"),
    pytest.param(True, id="bool"),
    pytest.param(None, id="null"),
    pytest.param("", id="empty-string"),
]


@pytest.mark.parametrize("value", MALFORMED_IDS)
def test_a_malformed_rule_id_is_a_readable_fault(value) -> None:
    """A fault naming the index and — where there is one — the offending type.

    The index rather than the id, because there is no usable id: `rule ['r-1']`
    would be a message printed in Python's repr of a list to a compliance
    specialist reading their own pack.
    """
    faults = validate(_pack_with(rule_id=value))
    assert faults, f"a rule_id of {value!r} produced no fault at all"
    about_the_id = [f for f in faults if f.startswith("rule[0]:")]
    assert about_the_id, f"no fault names rule[0]: {faults}"

    if value is None or value == "":
        assert any("has no 'rule_id'" in f for f in about_the_id), about_the_id
    else:
        assert any("must be a string" in f for f in about_the_id), about_the_id
        assert any(type(value).__name__ in f for f in about_the_id), about_the_id


def test_a_list_valued_rule_id_does_not_raise() -> None:
    """The reproduction. `["a"] in seen_ids` is `TypeError: unhashable type`.

    Asserted as "does not raise" rather than as "returns faults", because the
    finding is about the *kind* of exit: a `TypeError` leaving `validate` is
    what stopped `evidence.replay` classifying the pack and ended a nightly run.
    """
    try:
        faults = validate(_pack_with(rule_id=["a"]))
    except TypeError as exc:  # pragma: no cover - this is the regression
        pytest.fail(f"TypeError escaped validate: {exc}")
    assert faults


def test_two_numeric_rule_ids_do_not_evade_the_duplicate_check() -> None:
    """The half of the finding that produced a wrong answer rather than a crash.

    `1 in {"1"}` is False, so a pack with two rules numbered `1` loaded and one
    of them was invisible in the evidence — which is what the duplicate message
    says would happen and what the check exists to prevent. Both rules are
    refused now, on the ground that a rule id is a string, and neither loads.
    """
    body = _sound_body()
    first, second = dict(body["rules"][0]), dict(body["rules"][1])
    first["rule_id"] = 1
    second["rule_id"] = 1
    body["rules"] = [first, second]

    faults = validate(Pack.from_body(body))
    assert [f for f in faults if f.startswith("rule[0]:") and "must be a string" in f]
    assert [f for f in faults if f.startswith("rule[1]:") and "must be a string" in f]


def test_two_identical_string_rule_ids_are_still_caught() -> None:
    """The check the line was always supposed to perform, unbroken by the fix."""
    body = _sound_body()
    first, second = dict(body["rules"][0]), dict(body["rules"][1])
    second["rule_id"] = first["rule_id"]
    body["rules"] = [first, second]

    faults = validate(Pack.from_body(body))
    assert any("two rules share this id" in f for f in faults), faults


@pytest.mark.parametrize("value", MALFORMED_IDS)
def test_a_malformed_reason_code_is_a_readable_fault(value) -> None:
    """The same class of defect, at the second place in this file that had it.

    `pack.reason_codes` is a mapping, so the membership test hashed the raw
    value here exactly as it did for `rule_id`.
    """
    try:
        faults = validate(_pack_with(reason_code=value))
    except TypeError as exc:  # pragma: no cover - this is the regression
        pytest.fail(f"TypeError escaped validate for reason_code={value!r}: {exc}")

    assert faults
    if value is None or value == "":
        assert any("has no 'reason_code'" in f for f in faults), faults
    else:
        assert any("reason code must be a string" in f for f in faults), faults


def test_the_shipped_packs_still_validate() -> None:
    """The type checks refuse nothing that was already correct."""
    for path in sorted(PACKS.glob("*.json")):
        pack = Pack.from_body(json.loads(path.read_text()))
        assert validate(pack) == [], f"{path.name} stopped validating"


# ---------------------------------------------------------------- the property --

#: Anything `json.loads` can produce, nested a little — which is what a `jsonb`
#: pack body can actually hold. Copied in shape from
#: `test_malformed_packs_are_validation_errors.py`, which asserts the same
#: property one layer up, at `from_body`.
ANY_JSON = st.recursive(
    st.none()
    | st.booleans()
    | st.integers(min_value=-(10**6), max_value=10**6)
    | st.floats(allow_nan=False, allow_infinity=False)
    | st.text(max_size=12),
    lambda children: st.lists(children, max_size=3)
    | st.dictionaries(st.text(max_size=8), children, max_size=4),
    max_leaves=8,
)

#: The keys `validate` reads off a rule, so the fuzzer spends its budget on
#: rules rather than on dictionaries that share no keys with one.
RULE_KEYS = (
    "rule_id",
    "on_fail",
    "severity",
    "reason_code",
    "predicate",
    "applies_to",
    "provenance",
)

RULE_SHAPED = st.dictionaries(
    st.sampled_from(RULE_KEYS) | st.text(max_size=8),
    ANY_JSON,
    max_size=len(RULE_KEYS),
)


@settings(max_examples=400, suppress_health_check=[HealthCheck.too_slow], deadline=None)
@given(rule=RULE_SHAPED)
def test_no_rule_shaped_object_escapes_validate_as_an_exception(rule) -> None:
    """The property the two fixes above are two instances of.

    `validate` returns faults. Anything else leaving it — `TypeError`,
    `KeyError`, `AttributeError` — is a pack that cannot be classified, and an
    unclassifiable pack is what ends a nightly replay and turns a 422 into a
    500.
    """
    body = _sound_body()
    body["rules"] = [rule]
    try:
        pack = Pack.from_body(body)
    except PackError:
        return  # refused one layer earlier, which is also a controlled fault
    try:
        validate(pack)
    except Exception as exc:  # noqa: BLE001 — the whole point is what escapes
        pytest.fail(
            f"{type(exc).__name__} escaped validate for rule {rule!r}: {exc}. "
            "§S3 says a malformed pack is a validation error, never a crash."
        )
