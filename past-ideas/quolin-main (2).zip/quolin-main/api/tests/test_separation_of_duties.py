"""The two acts this system will not let one person complete alone.

Separation of duties is two claims, and only the second is interesting. The
first is that the roles are different — an operator may not approve, a signatory
may not publish — and `test_rbac.py` proves that against the route table. The
second is that the *people* are different, which no route table can express: it
depends on who signed this draft and who ran this check, and both of those are
rows rather than roles.

So each pair here is written twice. Once with two people, asserting the act goes
through; once with one person doing both halves, asserting it does not. A test
that only showed the refusal would pass against a system that refused everybody,
and a test that only showed the success would pass against one that never
checked at all.
"""

from __future__ import annotations

import pytest
from conftest import (
    APPROVER_EMAIL,
    OPERATOR_EMAIL,
    SIGNATORY_EMAIL,
    publish_through_the_api,
    reset_rate_limit_for_tests,
    sign_in,
    the_bytes_on_the_row,
    what_this_client_reads,
)
from fastapi.testclient import TestClient

from app.main import app

# Publishing here is not a simulation: it writes a real row to `packs`, which is
# the point, since the gate under test is the one guarding live rule content.
# Those rows are not cleaned up afterwards and cannot be — `packs` carries no
# DELETE grant, because rule content that could be removed is rule content a
# 2031 replay might not find. So the versions this file publishes accumulate
# across runs against a database that is not re-seeded, and any test elsewhere
# that counts pack versions has to say what it means rather than pinning a
# total. `test_api.py` does.
#
# The drafts are all future-dated, so nothing published here is ever in force
# and no determination is affected — which is the property that makes leaving
# them behind acceptable rather than merely unavoidable.


def _give_second_factor(session, user_id: str) -> bool:
    """A confirmed authenticator, so a privileged role can actually be used.

    Returns whether one was actually added, which the teardown needs.

    F8 made this matter. `operator` is in `MFA_REQUIRED_ROLES` now, so the
    seeded operator arrives already enrolled and this is a no-op for them —
    while `_remove_second_factor` went on deleting unconditionally. The pair
    was asymmetric, so the teardown stripped a factor this file never granted
    and every later sign-in as that person in the same run landed in a locked
    session. Exactly the cross-test residue the comment below warns about,
    with the sign flipped.
    """
    import base64
    import hashlib
    from datetime import datetime, timezone

    from sqlalchemy import select

    from app.identity import new_id
    from app.models import MfaCredential

    existing = session.scalars(
        select(MfaCredential).where(MfaCredential.user_id == user_id)
    ).first()
    if existing is not None:
        return False
    # `mfa_credentials` is policed by reachability: a person's second factor is
    # visible and writable only while that person is the acting user. Scoped
    # here the same way `identity.enrol_totp` does, rather than writing as the
    # owner — a test that reached around the policy would be testing a database
    # this application does not have.
    from app.identity import _scope_to_user

    _scope_to_user(session, user_id)
    digest = hashlib.sha256(f"quolin-demo-totp:{user_id}".encode()).digest()
    session.add(
        MfaCredential(
            id=new_id("mfa"),
            user_id=user_id,
            kind="totp",
            label="authenticator",
            secret=base64.b32encode(digest[:20]).decode().rstrip("="),
            confirmed_at=datetime.now(timezone.utc),
            last_used_counter=0,
            created_at=datetime.now(timezone.utc),
        )
    )
    session.flush()
    return True


def _remove_second_factor(session, user_id: str, *, added: bool = True) -> None:
    """Undo `_give_second_factor`, so the person leaves as they arrived.

    `added` is what `_give_second_factor` returned. A factor this file did not
    grant is not this file's to remove — see the note there.
    """
    if not added:
        return

    from sqlalchemy import select

    from app.identity import _scope_to_user
    from app.models import MfaCredential

    _scope_to_user(session, user_id)
    for row in session.scalars(
        select(MfaCredential).where(MfaCredential.user_id == user_id)
    ):
        session.delete(row)
    session.flush()


@pytest.fixture
def as_person():
    """Sign in as whoever a test needs, one client per person.

    Separate clients rather than one client re-authenticating, because the thing
    under test is two people acting, and a single cookie swapped between
    identities is one person with two hats — the arrangement these rules exist
    to make impossible.
    """
    clients = []

    def _make(email: str) -> TestClient:
        reset_rate_limit_for_tests()
        c = TestClient(app)
        c.__enter__()
        clients.append(c)
        return sign_in(c, email)

    yield _make
    for c in clients:
        c.__exit__(None, None, None)


# --- pair one: the decision and the override ------------------------------


def test_an_override_is_recorded_against_the_approver_who_is_signed_in(as_person):
    """The name on an override is the account, not a field in the request.

    The request body carries no approver at all — the schema has no such field —
    so there is nothing for a caller to put somebody else's name into.
    """
    operator = as_person(OPERATOR_EMAIL)
    approver = as_person(APPROVER_EMAIL)

    decision = operator.post(
        "/evaluate", json={"client_id": "priya-nair", "asset_id": "ETH"}
    ).json()

    recorded = approver.post(
        f"/decisions/{decision['id']}/override",
        json={"justification": "Suitability re-tested against the supplementary file."},
    )
    assert recorded.status_code == 200
    assert recorded.json()["override"]["approver"] == "Marcus Oyelaran"


def test_nobody_overrides_the_determination_they_ran_themselves(as_person, session):
    """The pair the stage gate names first.

    Constructed by granting the operator an approver role for the length of the
    test rather than by finding somebody who holds both — because nobody in the
    seed does, and a rule that is only ever exercised against people who cannot
    reach it is a rule nobody has tested. The point is that holding both roles
    is still not enough: the refusal is about the person, not the permission.
    """
    from app import identity, tenancy
    from app.models import User

    operator = as_person(OPERATOR_EMAIL)
    decision = operator.post(
        "/evaluate", json={"client_id": "priya-nair", "asset_id": "ETH"}
    ).json()

    with tenancy.acting_as("demo"):
        person = identity.find_by_email(session, OPERATOR_EMAIL)
        assert person is not None
        grant = identity.grant_role(
            session, user_id=person.id, role="approver", granted_by="test"
        )
        # `approver` is in MFA_REQUIRED_ROLES, and §S13 enforces it. A person
        # who has just been granted a privileged role needs a second factor
        # before they can exercise it — otherwise the refusal below would be
        # about the missing factor rather than about self-approval, which is
        # what this test is for.
        granted_factor = _give_second_factor(session, person.id)
        session.commit()

    # And a fresh session, because the flag is set when a session is
    # established. A role granted mid-session does not let an existing session
    # perform a privileged action until the person authenticates again with the
    # factor — which is a property worth having and worth asserting here.
    operator = as_person(OPERATOR_EMAIL)

    try:
        refused = operator.post(
            f"/decisions/{decision['id']}/override",
            json={"justification": "Overruling my own determination, which is the point."},
        )
        assert refused.status_code == 409
        assert "somebody else" in refused.json()["detail"]
    finally:
        with tenancy.acting_as("demo"):
            session.delete(grant)
            # The factor goes with the role. Leaving it behind gives the
            # operator a second factor for the rest of the run, which changes
            # how every later sign-in as that person behaves — the kind of
            # cross-test residue that makes a file pass alone and fail in the
            # suite.
            _remove_second_factor(session, person.id, added=granted_factor)
            session.commit()

    # And the row is not there. A refusal that still wrote the override would be
    # the worst outcome available: an audit trail that records the violation as
    # though it had been permitted.
    after = operator.get(f"/decisions/{decision['id']}").json()
    assert after["override"] is None
    assert isinstance(session.get(User, person.id), User)


# --- pair two: the signature and the publication --------------------------


def _draft(client, *, jurisdiction: str = "AU", title: str = "Test draft") -> dict:
    from datetime import date, timedelta

    res = client.post(
        "/watch/drafts",
        json={
            "jurisdiction": jurisdiction,
            "effective_from": (date.today() + timedelta(days=90)).isoformat(),
            "title": title,
            "rationale": "Written by the separation-of-duties suite.",
        },
    )
    assert res.status_code == 200, res.text
    return res.json()


def test_a_signature_names_the_account_that_signed_and_not_a_typed_name(as_person):
    operator = as_person(OPERATOR_EMAIL)
    signatory = as_person(SIGNATORY_EMAIL)

    draft = _draft(operator, title="Signature attribution")
    signed = signatory.post(
        f"/watch/drafts/{draft['id']}/sign",
        json={
            "note": "Reviewed.",
            "signed_content_hash": what_this_client_reads(signatory, draft["id"]),
        },
    )
    assert signed.status_code == 200, signed.text
    assert signed.json()["signed_by"] == "Aoife Brennan"
    # Signing alone puts nothing in force. The flag that used to let it is gone.
    assert signed.json()["published_pack_id"] is None
    assert signed.json()["status"] == "signed"


def test_a_signatory_may_not_sign_for_a_regime_they_are_not_competent_in(as_person):
    """A grant carries a jurisdiction, and the handler is where that is read.

    RBAC can say this person is a signatory. Only the handler can say whether
    they are a signatory *for this draft*, because the table cannot see drafts.
    The seed's signatory holds AU and HK, so SG is the honest negative.
    """
    operator = as_person(OPERATOR_EMAIL)
    signatory = as_person(SIGNATORY_EMAIL)

    draft = _draft(operator, jurisdiction="SG", title="Wrong regime")
    refused = signatory.post(
        f"/watch/drafts/{draft['id']}/sign",
        json={
            "note": "",
            # A truthful hash, so that the refusal under test is the one about
            # the regime rather than a 422 about a missing field.
            "signed_content_hash": what_this_client_reads(signatory, draft["id"]),
        },
    )
    assert refused.status_code == 403
    assert "not a signatory for SG" in refused.json()["detail"]


def test_signed_content_is_put_in_force_by_somebody_other_than_its_signatory(as_person):
    """Publication is Quolin's, since Q-12: `packs` is global, so a customer's
    administrator no longer writes to it. The second-pair-of-eyes rule this test
    is about is unchanged — it is the same rule, one role along."""
    operator = as_person(OPERATOR_EMAIL)
    signatory = as_person(SIGNATORY_EMAIL)

    draft = _draft(operator, title="Second pair of eyes")
    assert signatory.post(
        f"/watch/drafts/{draft['id']}/sign",
        json={
            "note": "Reviewed.",
            "signed_content_hash": what_this_client_reads(signatory, draft["id"]),
        },
    ).status_code == 200

    # FP3-27. Three distinct people now: the signatory attests, and two platform
    # publishers each decide it should govern every customer. The rule this test
    # is about — signer ≠ publisher — is unchanged and is joined by a second.
    published = publish_through_the_api(as_person, draft["id"])
    assert published.status_code == 200, published.text
    assert published.json()["signed_by"] == "Aoife Brennan"


def test_a_signatory_cannot_publish_their_own_signature(as_person, session):
    """The second pair the stage gate names, and the reason `SelfReview` exists.

    Granted `quolin_operator` for the length of the test for the same reason the
    override pair grants `approver`: the rule has to be exercised by somebody who
    could otherwise get through, or it proves only that the route table works.
    Before Q-12 the role to borrow was `tenant_admin`; publication moved, and
    the point of the test did not.
    """
    from app import identity, tenancy

    operator = as_person(OPERATOR_EMAIL)
    signatory = as_person(SIGNATORY_EMAIL)

    draft = _draft(operator, title="Self review")
    assert signatory.post(
        f"/watch/drafts/{draft['id']}/sign",
        json={
            "note": "Reviewed.",
            "signed_content_hash": what_this_client_reads(signatory, draft["id"]),
        },
    ).status_code == 200

    with tenancy.acting_as("demo"):
        person = identity.find_by_email(session, SIGNATORY_EMAIL)
        assert person is not None
        grant = identity.grant_role(
            session, user_id=person.id, role="quolin_operator", granted_by="test"
        )
        session.commit()

    try:
        refused = signatory.post(
            f"/watch/drafts/{draft['id']}/publish",
            json={
                "published_content_hash": what_this_client_reads(
                    signatory, draft["id"]
                )
            },
        )
        assert refused.status_code == 409
        assert "somebody else" in refused.json()["detail"]
    finally:
        with tenancy.acting_as("demo"):
            session.delete(grant)
            session.commit()

    # Still signed, still not content. The refusal must leave the draft exactly
    # where it was, so that the right person can still publish it afterwards.
    state = signatory.get(f"/watch/drafts/{draft['id']}").json()
    assert state["status"] == "signed"
    assert state["published_pack_id"] is None


def test_an_unattributed_signature_cannot_be_published_by_anyone(as_person, session):
    """A draft signed by nobody has no second pair of eyes available.

    Rows like this exist: the seed and the offline scripts sign with no person in
    scope. Treating a null signer as "not the publisher" would let exactly the
    unattributed signature through the gate that exists to catch it, so `publish`
    refuses instead.
    """
    from datetime import date, timedelta

    from app import tenancy
    from app.watch import drafts

    with tenancy.acting_as("demo"):
        draft = drafts.create(
            session,
            jurisdiction="AU",
            on=date.today(),
            effective_from=date.today() + timedelta(days=120),
            title="Unattributed signature",
            rationale="Written by the separation-of-duties suite.",
            author=drafts.WATCH_SERVICE_NAME,
            author_user_id=drafts.WATCH_SERVICE,
        )
        drafts.sign(
            session,
            draft.id,
            signatory="Nobody In Particular",
            signed_content_hash=the_bytes_on_the_row(session, draft),
        )
        assert draft.signed_by_user_id is None

        with pytest.raises(drafts.SelfReview):
            with tenancy.acting_as_user("some-real-person"):
                drafts.publish(
                    session,
                    draft.id,
                    published_content_hash=the_bytes_on_the_row(session, draft),
                )
        session.rollback()
