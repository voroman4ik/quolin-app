"""Smoke tests for the §7.1 API surface, exercised through the app itself."""

from __future__ import annotations


def test_health(client):
    body = client.get("/health").json()
    assert body["status"] == "ok"
    # Packs, not decisions. `/health` is public, so no tenant is in scope and a
    # decision count there would correctly be zero — see the endpoint's own note.
    assert body["packs"] > 0


def test_scenarios_cover_both_buyer_types(client):
    scenarios = client.get("/scenarios").json()
    assert {s["id"] for s in scenarios} == {"meridian", "sterling"}
    assert {s["artefact_kind"] for s in scenarios} == {"tmd", "evidence_pack"}


def test_cast_clients_are_reachable(client):
    cast = client.get("/clients", params={"cast_only": True}).json()
    assert {c["id"] for c in cast} == {
        "margaret-wu",
        "tom-askew",
        "priya-nair",
        "harold-bell",
        "dana-cole",
        "alex-reyes",
        "wei-lin-chow",
        "ingrid-halvorsen",
        "marcus-tan",
        "chen-yu-hsuan",
    }
    assert all(c["note"] for c in cast)


def test_cast_covers_single_and_multi_jurisdiction_clients(client):
    cast = {c["id"]: c for c in client.get("/clients", params={"cast_only": True}).json()}

    # The original cast must stay single-jurisdiction: their determinations are
    # the ones the demo walks, and a second regime would change them.
    assert cast["tom-askew"]["cross_border"] is False
    assert cast["harold-bell"]["cross_border"] is False

    assert cast["wei-lin-chow"]["cross_border"] is True
    assert (cast["wei-lin-chow"]["residency"], cast["wei-lin-chow"]["domicile"]) == ("HK", "SG")
    # Governed elsewhere, but only by one regime — cross-border is about how many
    # regimes reach a client, not about whether the regime is the reference one.
    assert cast["chen-yu-hsuan"]["jurisdiction"] == "HK"
    assert cast["chen-yu-hsuan"]["cross_border"] is False


def test_client_detail_exposes_exposure_against_cap(client):
    body = client.get("/clients/margaret-wu").json()
    assert body["concentration_cap_bps"] == 1000
    assert 0 <= body["exposure_bps"] <= 10_000
    assert body["decisions"]


def test_evaluate_returns_a_blocking_decision_with_three_reasons(client):
    body = client.post(
        "/evaluate", json={"client_id": "tom-askew", "asset_id": "SOL"}
    ).json()

    assert body["outcome"] == "BLOCK"
    assert len(body["reasons"]) == 3
    for reason in body["reasons"]:
        assert reason["reason_plain_english"]
        assert reason["rule_id"]
        assert reason["inputs_read"] or reason["thresholds_used"]
    assert body["pack_version"] == 2


def test_evaluate_rejects_unknown_client(client):
    response = client.post("/evaluate", json={"client_id": "nobody", "asset_id": "BTC"})
    assert response.status_code == 404


def test_replay_of_the_demo_decision_reproduces_exactly(client):
    history = client.get("/decisions", params={"client_id": "harold-bell"}).json()
    oldest = min(history, key=lambda d: d["as_of"])
    assert oldest["pack_version"] == 1

    result = client.post(f"/decisions/{oldest['id']}/replay").json()
    assert result["match"] is True
    assert result["stored_outcome"] == result["replayed_outcome"]
    assert result["differences"] == []
    assert result["chain"]["verified"] is True


def test_override_requires_a_real_justification(client, approver):
    """Two clients, because an override takes two roles.

    The operator runs the check; the approver overrides it. Written this way
    even though only the justification is under test, so that the test is not
    quietly describing one person doing both.

    No approver name is sent. It is read from the session, which is why the
    assertion names the seeded approver rather than whatever the test asked for
    — a name the caller could choose would be an approval by nobody.
    """
    decision = client.post(
        "/evaluate", json={"client_id": "priya-nair", "asset_id": "ETH"}
    ).json()
    assert decision["outcome"] == "REFER"

    too_short = approver.post(
        f"/decisions/{decision['id']}/override", json={"justification": "fine"}
    )
    assert too_short.status_code == 422

    accepted = approver.post(
        f"/decisions/{decision['id']}/override",
        json={
            "justification": "Supplementary suitability questionnaire re-tested band 2.",
        },
    ).json()
    assert accepted["override"]["approver"] == "Marcus Oyelaran"


def test_pack_endpoint_exposes_versions_and_the_diff(client):
    """The shelf shows every version, and what changed between the first two.

    Deliberately not asserting how many versions exist. The separation-of-duties
    suite publishes future-dated AU versions and cannot remove them — `packs`
    carries no DELETE grant, because rule content that could be deleted is rule
    content a 2031 replay might not find. Pinning a total would make this test a
    report on what else has run, so it states what it actually cares about: the
    two seeded versions are there, in order, and v2 is the one in force.
    """
    body = client.get("/packs/AU").json()
    assert body["current_version"] == 2
    assert [v["version"] for v in body["versions"]][:2] == [1, 2]

    delta = body["diffs"][0]
    assert delta["from_version"] == 1 and delta["to_version"] == 2
    assert any(c["name"] == "max_crypto_concentration_bps" for c in delta["thresholds_changed"])
    assert [r["rule_id"] for r in delta["rules_added"]] == ["AU-KNOW-02"]


def test_queue_lists_refers_and_marks_resolved_ones(client):
    queue = client.get("/queue").json()
    assert queue
    assert all("reason_codes" in item for item in queue)
    assert any(item["resolved"] for item in queue)


def test_dashboard_counts_are_scenario_scoped(client):
    sterling = client.get("/dashboard", params={"scenario": "sterling"}).json()
    meridian = client.get("/dashboard", params={"scenario": "meridian"}).json()

    assert sterling["decisions_total"] + meridian["decisions_total"] == (
        client.get("/dashboard").json()["decisions_total"]
    )
    assert sterling["chain"]["verified"] is True


def test_artefact_generates_a_pdf_and_serves_it(client):
    decision = client.post(
        "/evaluate", json={"client_id": "margaret-wu", "asset_id": "BTC"}
    ).json()

    artefact = client.post("/artefacts/tmd", json={"decision_id": decision["id"]}).json()
    assert artefact["title"] == "Target Market Determination"

    pdf = client.get(artefact["download_url"])
    assert pdf.status_code == 200
    assert pdf.headers["content-type"] == "application/pdf"
    assert pdf.content.startswith(b"%PDF")


def test_unknown_artefact_kind_is_rejected(client):
    assert client.post("/artefacts/nonsense", json={"decision_id": 1}).status_code == 404


def test_artefact_magnitudes_print_in_the_unit_the_pack_declared():
    """A document and the screen it was generated from must not disagree on units.

    `200000 cents` and `$2,000.00` are the same number, and only one of them can
    be checked against a statement by whoever reads the evidence pack. An
    unrecognised scale is never coerced into a unit no pack declared, and a
    qualitative constraint with no magnitude prints the dash rather than a
    number it does not have.
    """
    from app.artefacts.renderer import _magnitude

    assert _magnitude(200000, "cents") == "$2,000.00"
    assert _magnitude(200, "bps") == "2.00%"
    assert _magnitude(4, "band") == "Band 4"
    assert _magnitude(365, "days") == "365 days"
    assert _magnitude(1, "day") == "1 day"
    assert _magnitude(18, "years") == "18 years"
    assert _magnitude(None, "qualitative") == "—"
    # A scale the renderer has never seen keeps its own name beside the value.
    assert _magnitude(7, "sleeps") == "7 sleeps"
