"""The hash of what was signed, recorded where it cannot be edited.

F4. `drafts.sign` records `content_hash(draft.body)` on the draft row, and
`drafts.publish` computes a second hash over the body it has just mutated —
version, signature block, attested content status — and stores that beside the
pack. Nothing compared them. `publish` treated `status == SIGNED` as proof that
the body in front of it was the body that had been signed.

`pack_drafts` is mutable working state by design, so an edit between signature
and publication — a race against `main.edit_draft`, which refuses on status and
takes no row lock, or any `UPDATE` from a shell — put bytes the signatory never
saw into `packs` under their name, their user id and their qualification
reference. Content that reads as reviewed is worse than content that reads as
unsigned: unsigned content is refused to any acting firm, and this was not.

The comparison itself lives in `publish`. What was missing underneath it is a
place for the claim to live: the signed hash sat on the mutable row it was
supposed to protect, so after the fact there was nothing to check it against.
This column is that place — `pack_publications` is append-only, and the
attestation now sits in it beside the hash of what was actually published.

**Nullable, and not backfilled.** Every publication already on file was made
before anything recorded which bytes were signed, and the honest value for those
rows is "nobody recorded one". A backfill would have to invent it — and
`pack_publications` carries an append-only trigger, so writing to those rows
means going around the guarantee this column exists to strengthen. The trigger
is untouched here.

**What this does not do.** The signed hash still cannot be *rebuilt* from the
published pack: `publish` overwrites four fields the signed body carried as
inherited placeholders, so the two hashes can be compared but never recomputed
from the pack alone by a third party. Changing that changes what a signature
covers and invalidates every `content_hash` on file — a decision for the
project, recorded under "Decisions requested" in docs/spec-changes.md.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0035_signed_content_hash"
down_revision = "0034_rechain_record"
branch_labels = None
depends_on = None

COLUMN = "signed_content_hash"


def upgrade() -> None:
    op.add_column(
        "pack_publications",
        sa.Column(COLUMN, sa.String(64), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("pack_publications", COLUMN)
