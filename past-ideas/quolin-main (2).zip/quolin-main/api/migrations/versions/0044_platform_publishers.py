"""Publishing rule content stops being something a tenant can grant.

FP3-27, and R2 Finding 2. `quolin_operator` is the role that may publish, and it
is granted through `user_roles` — which is **tenant-scoped**. `POST
/watch/drafts/{draft_id}/publish` writes to `packs`, which is **global**: the
same AU content governs every customer on the platform.

So a capability whose target is every tenant was authorised by a row belonging
to one. Compromise of a single firm's role set — or of anybody able to write one
— reaches every other firm's regulatory content. Q-12 spotted that publishing is
Quolin's act rather than a customer's and expressed it as "a role only we grant";
the storage never caught up with the reasoning.

**A separate table, not a `tenant_id IS NULL` row in `user_roles`.** The
brief offers either. A nullable tenant on a table whose entire policy is
`tenant_id = current_setting(...)` would be a row invisible to that policy and
therefore governed by whatever the next `WHERE` clause happened to say — the
shape of every cross-tenant read there has ever been. A table with no
`tenant_id` column at all cannot be written by a tenant-scoped grant, cannot be
reached by the `/admin/users/{id}/roles` route, and needs no policy to say so.

Only the schema owner may write it. There is no API route that grants platform
publication and there is deliberately not going to be one: it is a
`make platform-publisher` operation against the database, performed by somebody
with the owner credential, which is the same bar as running a migration.

**Dual control lives on the draft, not here.** Who may publish is this table;
that publication needs two of them, neither being the signer, is state on
`pack_drafts` — see 0045.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0044_platform_publishers"
down_revision = "0043_invitations"
branch_labels = None
depends_on = None

TABLE = "platform_publishers"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("user_id", sa.String(), nullable=False),
        #: What qualifies this person, printed nowhere and read by the access
        #: review. Free text on purpose: the answer is a name and a role at
        #: Quolin, not a code.
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
        sa.Column("granted_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("granted_by", sa.String(), nullable=False, server_default=""),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("user_id"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
    )

    # **No `tenant_id`, and no policy.** That is the control. A table with no
    # tenant column cannot be reached by a tenant-scoped write, and there is
    # nothing for a compromised firm's role set to say.
    #
    # Readable by the application, because the publish route has to ask. Not
    # writable by it at all: minting a platform publisher is an owner
    # operation, at the same bar as running a migration.
    op.execute(f"REVOKE ALL ON {TABLE} FROM quolin_app;")
    op.execute(f"GRANT SELECT ON {TABLE} TO quolin_app;")
    op.execute(f"REVOKE ALL ON {TABLE} FROM quolin_watch;")


def downgrade() -> None:
    raise NotImplementedError(
        "Reversing this returns publication of global rule content to a "
        "tenant-scoped role grant, so compromise of one firm's role set reaches "
        "every firm's regulatory content. If the boundary genuinely has to move, "
        "that is a forward migration somebody signs."
    )
