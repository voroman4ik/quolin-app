"""A priority on the artefact queue, so a batch cannot bury a person.

§S12: "bulk runs not starving interactive traffic (queue priorities)."

The queue claims `ORDER BY id` — strict first-in, first-out, which is the right
default and the wrong answer the first time somebody asks for a quarter's
returns. Ten thousand documents go in, and the officer who then asks for one
determination's Target Market Determination is behind all ten thousand of them.
Nothing is broken; the render is simply scheduled for tomorrow. FIFO is fair to
jobs and this queue serves people.

**The priority is derived, not passed in.** It comes from the artefact's scope,
which the pack already declares: a decision-scoped document is somebody looking
at one determination on a screen, and a run- or period-scoped one is a batch
nobody is watching in real time. A `priority` parameter on the enqueue call
would be set to "urgent" by every caller within a year — each for a good local
reason, and collectively turning the column into a constant.

**Existing rows get the batch priority.** Everything queued before this
migration was queued under FIFO, and promoting a backlog on deploy would be a
surprise rather than a fix.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0023_queue_priority"
down_revision = "0022_auth_attempts"
branch_labels = None
depends_on = None

TABLE = "artefact_jobs"


def upgrade() -> None:
    # Lower is sooner, like `nice`. A default of 10 means a row written by code
    # that has not heard of this column is treated as batch work, which is the
    # safe direction to be wrong in: a batch job served early is a delay, an
    # interactive job served late is a person waiting.
    op.add_column(
        TABLE,
        sa.Column("priority", sa.Integer(), nullable=False, server_default="10"),
    )

    # The claim's index, widened rather than duplicated. Migration 0017 created
    # `ix_artefact_jobs_claim` on (status, id) for the claim as it was; the
    # claim now filters on status and orders by (priority, id), so the same
    # index with the new column in the middle serves it and the old one becomes
    # dead weight. Two overlapping indexes on a queue table is write cost for
    # nothing.
    op.drop_index(f"ix_{TABLE}_claim", table_name=TABLE)
    op.create_index(f"ix_{TABLE}_claim", TABLE, ["status", "priority", "id"])


def downgrade() -> None:
    op.drop_index(f"ix_{TABLE}_claim", table_name=TABLE)
    # Back to what migration 0017 created, not to nothing.
    op.create_index(f"ix_{TABLE}_claim", TABLE, ["status", "id"])
    op.drop_column(TABLE, "priority")
