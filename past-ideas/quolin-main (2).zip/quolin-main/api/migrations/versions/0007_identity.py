"""People, the roles they hold, and how they prove who they are

Revision ID: 0007_identity
Revises: 0006_encrypted_columns
Created: 2026-08-23

Up to here, "who did this" was a string. `audit_events.actor` said `officer`,
every session named the same shared passcode, and the only honest thing the
product could tell a regulator was that somebody with the password did it. This
migration is where a person becomes a row.

**Three categories of table, not two.** Stage 1 split the schema into
tenant-scoped (has `tenant_id`, filtered by row-level security) and global (pack
content, the same for every customer). A user fits neither. They cannot be
tenant-scoped, because the execution document requires that one person hold
different roles in different firms — a consultant compliance officer serving
three clients — and a `tenant_id` column would force three user rows, three
passwords, and back to shared credentials by another name. They cannot be
global either: pack content is global because every customer *should* see the
same AU rules, whereas one customer reading another's staff list is precisely
the disclosure Stage 1 exists to prevent.

So `users`, `user_identities` and `mfa_credentials` carry no `tenant_id` and are
policed by reachability instead: a firm sees a person exactly when it has
granted that person a role. The grant itself — `user_roles` — *is* tenant-scoped
and ordinary, because it is the firm's own decision about its own staff.

**Two settings that are not the tenant.** `app.user_id` names the person this
transaction acts for. It is what lets somebody read their own profile, enrol
their own second factor and burn their own one-time code, none of which the
tenant setting can express, because at the moment of enrolment the interesting
question is which human this is and not which firm they are looking at.

`app.login_email` is narrower still and is set for one statement only: the
lookup that turns a submitted address into a user id. That step has to happen
before either of the other settings can hold anything, because it is what
determines them — the same bootstrap problem `app.session_token` solved for
cookies in 0003, solved the same way rather than by exempting a table.

**One deliberate widening, stated rather than hidden.** With `app.user_id` set,
a person can read their own `user_roles` rows in every tenant, not only the
current one. That is what a tenant switcher needs, and the rows are their own.
It does mean a query against `user_roles` that forgets to filter by tenant can
return a row from another one, so the API filters explicitly instead of leaning
on the policy, and `tests/test_rls.py` asserts the widening exists on purpose.

**What is deliberately absent.** No password column on `users`. Credentials live
in `user_identities`, one row per way of proving identity, so that a firm moving
from the email fallback to its own identity provider adds a row rather than
becoming a new person — and every decision they recorded last year still carries
their name.

**The reserved tenant.** `_platform` is inserted here. It is not a customer; it
owns the data key that personal secrets are sealed under, for the reason set out
in `app/crypto.py`: a second factor authenticates a human, and a human may serve
several firms, so no one firm's key is the right one. It carries
`status = 'platform'` so that anything listing customers excludes it by asking a
question about the row rather than by matching a magic string. Its key is *not*
created here — key material never comes from a migration, for the reason given
in 0005 — it comes from `crypto.ensure_key`, which the seed and `make
platform-key` call.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0007_identity"
down_revision = "0006_encrypted_columns"
branch_labels = None
depends_on = None

TENANT_SETTING = "app.tenant_id"
USER_SETTING = "app.user_id"
LOGIN_EMAIL_SETTING = "app.login_email"

POLICY = "tenant_isolation"

PLATFORM_TENANT = "_platform"

#: Tables holding people. Enabled *and* forced, like every other policed table:
#: `ENABLE` alone exempts the owner, and the owner is the role a well-meaning
#: maintenance script connects as.
PLATFORM_TABLES = ("users", "user_identities", "mfa_credentials")


def upgrade() -> None:
    op.create_table(
        "users",
        # An opaque string, not a serial, for the same reason tenants are slugs:
        # this identifier is written into `audit_events.actor` and into every
        # signature row, where it is read by humans reconstructing what
        # happened, and "user 7" is a value somebody eventually reads as 1.
        sa.Column("id", sa.String(), nullable=False),
        # Lowercased at write time, unique across the product, and the one piece
        # of personal data in this schema that is not sealed. Sign-in has to find
        # a row by address before it knows who the user is, and an authenticated
        # cipher column cannot be searched — the same plaintext produces
        # different bytes on every write, by design. The alternatives were a
        # keyed hash beside the ciphertext, which leaks equality anyway and adds
        # a second thing to rotate, or decrypting every row on every attempt,
        # which invites an unauthenticated party to make the server do work. The
        # exposure is bounded and worth saying plainly: a stolen dump reveals who
        # holds an account, not what any of them did.
        sa.Column("email", sa.String(), nullable=False),
        sa.Column("display_name", sa.LargeBinary(), nullable=False),
        sa.Column("status", sa.String(), nullable=False, server_default="active"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("email", name="users_email_key"),
    )
    op.create_index("ix_users_status", "users", ["status"])

    op.create_table(
        "user_identities",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("user_id", sa.String(), nullable=False),
        sa.Column("provider", sa.String(), nullable=False),
        sa.Column("issuer", sa.String(), nullable=False, server_default=""),
        # For a password identity this is the lowercased address; for an OIDC one
        # it is the `sub` claim and never the address, because an employer may
        # reassign a mailbox to a new joiner and `sub` is the claim that promises
        # not to be reassigned.
        sa.Column("subject", sa.String(), nullable=False),
        # The Argon2id encoding for a password identity, empty for OIDC. Not
        # additionally sealed: the encoding carries its own salt and parameters
        # and is not reversible, so encrypting it would protect nothing it does
        # not already protect, while making a rehash on parameter changes depend
        # on the key being present.
        sa.Column("secret", sa.Text(), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("last_used_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.UniqueConstraint(
            "provider", "issuer", "subject", name="user_identities_provider_key"
        ),
    )
    op.create_index("ix_user_identities_user_id", "user_identities", ["user_id"])
    op.create_index("ix_user_identities_provider", "user_identities", ["provider"])

    op.create_table(
        "user_roles",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("tenant_id", sa.String(), nullable=False),
        sa.Column("user_id", sa.String(), nullable=False),
        sa.Column("role", sa.String(), nullable=False),
        # Set only for `pack_signatory`. Signing AU content and signing EU
        # content are different competencies attested by different people, and a
        # signatory role with no regime on it would let one sign for the other.
        sa.Column("jurisdiction", sa.String(), nullable=False, server_default=""),
        sa.Column("qualification_ref", sa.String(), nullable=False, server_default=""),
        sa.Column("granted_at", sa.DateTime(timezone=True), nullable=False),
        # Not a foreign key on purpose: a grant has to survive the granter
        # leaving, and the access review cares what the record says rather than
        # whether that person is still employed.
        sa.Column("granted_by", sa.String(), nullable=False, server_default=""),
        # Null for staff, always set for `quolin_support`, whose access the
        # execution document requires to be time-boxed. Expiry is applied when
        # the role is read, not by a sweep job — an expiry that depends on a cron
        # having run is not an expiry.
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.UniqueConstraint(
            "tenant_id", "user_id", "role", "jurisdiction", name="user_roles_grant_key"
        ),
    )
    op.create_index("ix_user_roles_tenant_id", "user_roles", ["tenant_id"])
    op.create_index("ix_user_roles_user_id", "user_roles", ["user_id"])
    op.create_index("ix_user_roles_role", "user_roles", ["role"])

    op.create_table(
        "mfa_credentials",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("user_id", sa.String(), nullable=False),
        sa.Column("kind", sa.String(), nullable=False, server_default="totp"),
        sa.Column("label", sa.String(), nullable=False, server_default=""),
        # Sealed under the platform key, not a customer's.
        sa.Column("secret", sa.LargeBinary(), nullable=False),
        # Null until the user has generated a code from it. An enrolment that
        # stopped halfway must not lock anyone out or, worse, wave them through.
        sa.Column("confirmed_at", sa.DateTime(timezone=True), nullable=True),
        # The highest time step already accepted. A one-time code stays valid for
        # its whole window, so without this a code read over a shoulder can be
        # replayed inside the same thirty seconds. Recording the step makes every
        # code single-use.
        sa.Column("last_used_counter", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
    )
    op.create_index("ix_mfa_credentials_user_id", "mfa_credentials", ["user_id"])

    # -- the session becomes a person's session ------------------------------

    # Nullable because the table already holds rows, and a column added NOT NULL
    # to a populated table needs a default that would have to be a fabricated
    # user id. `auth.resolve` rejects a session with no user instead, so the old
    # rows are inert rather than privileged — and 0007 is the migration after
    # which the passcode path no longer exists to create more of them.
    op.add_column("auth_sessions", sa.Column("user_id", sa.String(), nullable=True))
    op.create_foreign_key(
        "auth_sessions_user_id_fkey", "auth_sessions", "users", ["user_id"], ["id"]
    )
    op.create_index("ix_auth_sessions_user_id", "auth_sessions", ["user_id"])
    # When the credential was last presented in full. Distinct from `created_at`
    # because stepping up moves this forward without minting a new session: the
    # browser stays signed in, but the clock that governs signing restarts.
    op.add_column(
        "auth_sessions",
        sa.Column(
            "authenticated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )
    # Whether a second factor was presented *on this session*. Stored rather than
    # derived from the user's enrolment, because "this person has a factor" and
    # "this browser proved it" are different claims and only the second may open
    # a signing screen.
    op.add_column(
        "auth_sessions",
        sa.Column(
            "mfa_satisfied",
            sa.Boolean(),
            nullable=False,
            server_default=sa.text("false"),
        ),
    )

    # -- the reserved tenant -------------------------------------------------

    op.execute(
        f"""
        INSERT INTO tenants (id, name, region, tier, status, config, created_at)
        VALUES (
          '{PLATFORM_TENANT}', 'Quolin platform', 'ap-southeast-2',
          'shared', 'platform', '{{}}'::jsonb, now()
        )
        ON CONFLICT (id) DO NOTHING;
        """
    )

    # -- policies ------------------------------------------------------------

    op.execute("ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;")
    op.execute("ALTER TABLE user_roles FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY {POLICY} ON user_roles
        USING (tenant_id = current_setting('{TENANT_SETTING}', true))
        WITH CHECK (tenant_id = current_setting('{TENANT_SETTING}', true));
        """
    )
    # The widening described at the top of this file. Read-only: `WITH CHECK
    # (false)` contributes nothing to writes, so granting a role still goes
    # through the tenant policy above and is still pinned to the acting firm. A
    # person cannot grant themselves anything by knowing their own id.
    op.execute(
        f"""
        CREATE POLICY role_of_self ON user_roles
        USING (user_id = current_setting('{USER_SETTING}', true))
        WITH CHECK (false);
        """
    )

    for table in PLATFORM_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;")

    # A person may read and write their own row. This is also how a user is
    # created: provisioning names the new id in `app.user_id` and inserts it, so
    # the rule stays "you may write exactly the row you have declared yourself
    # to be" rather than opening an unconstrained INSERT.
    op.execute(
        f"""
        CREATE POLICY user_self ON users
        USING (id = current_setting('{USER_SETTING}', true))
        WITH CHECK (id = current_setting('{USER_SETTING}', true));
        """
    )
    # The sign-in bootstrap. In force for exactly one statement, and read-only.
    op.execute(
        f"""
        CREATE POLICY user_login ON users
        USING (email = current_setting('{LOGIN_EMAIL_SETTING}', true))
        WITH CHECK (false);
        """
    )
    # Reachability: a firm sees the people it has granted a role to, and nobody
    # else. This is the policy that makes a staff list tenant-private without a
    # `tenant_id` column. The subquery is itself subject to the policies on
    # `user_roles`, which is belt and braces rather than redundancy — the
    # explicit tenant predicate is what the reader should be able to check.
    op.execute(
        f"""
        CREATE POLICY user_reachable ON users
        USING (
          EXISTS (
            SELECT 1 FROM user_roles ur
            WHERE ur.user_id = users.id
              AND ur.tenant_id = current_setting('{TENANT_SETTING}', true)
          )
        )
        WITH CHECK (false);
        """
    )

    for table in ("user_identities", "mfa_credentials"):
        op.execute(
            f"""
            CREATE POLICY {table}_self ON {table}
            USING (user_id = current_setting('{USER_SETTING}', true))
            WITH CHECK (user_id = current_setting('{USER_SETTING}', true));
            """
        )
        # Read-only reachability, and it exists for one caller: the quarterly
        # access review has to say how each person authenticates and whether
        # they have enrolled a second factor. The secret itself travels as
        # ciphertext under a key no customer holds, so what a firm can see here
        # is that a factor exists, not what it is.
        op.execute(
            f"""
            CREATE POLICY {table}_reachable ON {table}
            USING (
              EXISTS (
                SELECT 1 FROM user_roles ur
                WHERE ur.user_id = {table}.user_id
                  AND ur.tenant_id = current_setting('{TENANT_SETTING}', true)
              )
            )
            WITH CHECK (false);
            """
        )


def downgrade() -> None:
    for table in ("user_identities", "mfa_credentials"):
        op.execute(f"DROP POLICY {table}_reachable ON {table};")
        op.execute(f"DROP POLICY {table}_self ON {table};")
    op.execute("DROP POLICY user_reachable ON users;")
    op.execute("DROP POLICY user_login ON users;")
    op.execute("DROP POLICY user_self ON users;")
    for table in PLATFORM_TABLES:
        op.execute(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY;")
        op.execute(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY;")
    op.execute("DROP POLICY role_of_self ON user_roles;")
    op.execute(f"DROP POLICY {POLICY} ON user_roles;")
    op.execute("ALTER TABLE user_roles NO FORCE ROW LEVEL SECURITY;")
    op.execute("ALTER TABLE user_roles DISABLE ROW LEVEL SECURITY;")

    op.drop_column("auth_sessions", "mfa_satisfied")
    op.drop_column("auth_sessions", "authenticated_at")
    op.drop_index("ix_auth_sessions_user_id", table_name="auth_sessions")
    op.drop_constraint("auth_sessions_user_id_fkey", "auth_sessions", type_="foreignkey")
    op.drop_column("auth_sessions", "user_id")

    op.drop_table("mfa_credentials")
    op.drop_table("user_roles")
    op.drop_table("user_identities")
    op.drop_table("users")

    # The platform tenant stays. Its `tenant_keys` row holds the only copy of the
    # key every enrolled second factor is sealed under, and 0005 refuses to drop
    # that table for the same reason. Removing the tenant would orphan the key
    # behind a foreign key, or cascade it away — and a downgrade that destroys
    # key material is not a downgrade.
