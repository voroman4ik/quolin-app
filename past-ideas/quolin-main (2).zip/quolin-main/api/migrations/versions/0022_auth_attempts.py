"""Sign-in attempts: a table with no tenant, because an attempt has no tenant.

§S12 went looking for why the API could not use more than one of twelve cores
and found the answer in `infra/variables.tf`: `api_desired_count` is 1, and the
note beside it says it stays there because login rate limiting is per-process,
so a second task would silently halve the effective lockout. Raising it first
would have been a security regression disguised as a scaling decision.

Making that state shared turned up a second thing, and it is the worse of the
two. **Failed sign-ins were never being recorded at all.** `security_events` is
tenant-scoped, its policy requires `tenant_id = current_setting('app.tenant_id')`,
and at `/auth/login` there is no tenant — the caller has not proved who they are
yet, which is the entire point of the endpoint. So the INSERT failed the row
check, `observability.record` swallowed it exactly as designed, and the request
carried on. Three failed logins against the running system wrote zero rows.

Stage 9 built alerting on auth anomalies on top of that table. Its game day
passed because the game day writes its own rows with a tenant in scope. The
alert could not have fired on a real brute-force attempt against the login page,
which is the one thing it exists for — the failure mode Stage 9's own runbook
warns about, in the mechanism meant to catch it.

The fix for both is the same table, and the reason it is one table is that both
problems are the same sentence: **a sign-in attempt does not belong to a
tenant.** Stage 9 created `security_events` rather than weaken Stage 2's rule
that an audit row names a person; this is that argument one level further down.

Three properties worth stating:

**Append-only, like every other record here.** Rate limiting wants "a correct
password clears the address", which sounds like a DELETE. It is not: a success
is recorded as a success, and the limiter counts failures *since the last
success*. Nothing is removed, the record of the attack survives the moment the
attacker guesses right, and the table needs no UPDATE grant.

**Deliberately not tenant-scoped, and readable across the deployment.** The
login endpoint is shared by every tenant on a shared stack, so the picture of
who is hammering it is a property of the deployment rather than of a customer.
It holds an address, a timestamp, and an account id when the attempt resolved to
one — never the address that was typed, for the reason `security_events` gives.

**Indexed for the query the limiter runs.** `(source_ip, at)`, because that
lookup is on the login path and a sequential scan there is a denial-of-service
primitive rather than a slow query.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0022_auth_attempts"
down_revision = "0021_adoption_ladder"
branch_labels = None
depends_on = None

TABLE = "auth_attempts"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        # No tenant_id. See the note above: that column is what stopped the
        # rows being written in the first place.
        sa.Column("source_ip", sa.String(), nullable=False, server_default=""),
        #: The account, when the attempt resolved to one. Never an address.
        sa.Column("user_id", sa.String(), nullable=True),
        #: `failed`, `succeeded`, or `rate_limited`.
        sa.Column("outcome", sa.String(), nullable=False),
        sa.Column("detail", sa.Text(), nullable=False, server_default=""),
        sa.Column(
            "at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )

    # The limiter's query, and the only one on the login path.
    op.create_index(f"ix_{TABLE}_ip_at", TABLE, ["source_ip", "at"])

    op.execute(
        f"""
        CREATE TRIGGER {TABLE}_append_only
        BEFORE UPDATE OR DELETE ON {TABLE}
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )
    op.execute(f"REVOKE UPDATE, DELETE ON {TABLE} FROM quolin_app;")

    op.execute(f"ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY;")
    op.execute(f"ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY;")
    # Enabled and forced with a policy that admits everything, which looks
    # pointless and is not. Enabling row-level security on a table with no
    # policy denies all access; a table with neither is one a future `ALTER`
    # can quietly widen. This states the intent — the rows are deployment-wide —
    # in the same place every other table states its own, so the RLS probe's
    # "enabled, forced, and carries a policy" check covers this table too rather
    # than reporting it as an exception somebody has to remember.
    op.execute(
        f"""
        CREATE POLICY {TABLE}_deployment ON {TABLE}
        USING (true) WITH CHECK (true);
        """
    )


def downgrade() -> None:
    raise NotImplementedError(
        "This is the record of who tried to sign in and failed — the evidence "
        "an incident is reconstructed from, and the state the login rate "
        "limiter reads. Migration 0001 takes the same position on dropping "
        "append-only tables."
    )
