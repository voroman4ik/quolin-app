"""A second review is bound to the bytes it reviewed.

Migration 0049 made "who reviewed this, and when" a fact the database holds and
a CHECK constraint enforces. It did not make *what* they reviewed a fact at all,
and both external audits found the same hole through it — one of them by
constructing the sequence and running it against a live database:

    author cuts a draft
      → an independent, qualified reviewer records their read
      → the author edits the body
      → the author signs their own draft

`sign` asked only whether `second_reviewer_user_id` was populated, and it still
was. `pack_drafts_signature_is_independent` asked the same question of the same
three columns, and they still satisfied it. So the signature — the one act in
this system that turns a proposal into rule content — attested to bytes nobody
but their author had ever seen, and the row said it had been independently
reviewed.

The principal who can do this holds `operator` and `pack_signatory`, which is
the S5 workbench workflow rather than a corner case: an operator may edit a
draft, and a signatory may sign one.

**The pattern already existed one function away.** `drafts.sign` records
`content_hash(draft.body)` and `drafts.publish` re-checks it, so an edit landing
between the signature and the publication is refused (`SignedBytesChanged`, F4).
Nothing mirrored that onto the window between the *review* and the signature,
which is the same window with an earlier pair of eyes in it.

**One column, and two halves of the fix in the application.**

`second_reviewed_content_hash` is the body's canonical hash as it stood when the
review was recorded, captured the way `content_hash` is captured at signing —
at the moment of the act, never computed on read, because computing it later
hashes whatever is there now and that is precisely the question.

`drafts.sign` refuses when an author's own signature leans on a review of
different bytes (`ReviewedBytesChanged`), and `main.edit_draft` clears the whole
review — reviewer, name, timestamp and hash — on any change to the body. Both,
because they answer different questions: the first is what stops a signature
from being wrong, and the second is what stops a stale review from sitting on a
row looking valid to every other reader of it.

**The constraint, and why it is `NOT VALID` for the same reason 0049's was.**

`pack_drafts_self_signature_reviewed_these_bytes` says that a row whose signer
is its author must carry a reviewed hash equal to the signed hash. It is SQL
comparing two columns rather than hashing anything, so it holds against a writer
that never went through Python — which is the half a check in `drafts.py` cannot
give, `drafts.py` being a file somebody can edit.

`NOT VALID` because rows written between 0049 and this migration recorded a
reviewer and no hash: every one of them violates, and every one of them was
written by the mechanism working as specified at the time. Validating would
require inventing a hash for content that may since have changed — asserting
about the past exactly the thing this migration exists to stop asserting. The
rows stand, and what they are is a query:

    SELECT id FROM pack_drafts
     WHERE signed_by_user_id = created_by_user_id
       AND (second_reviewed_content_hash IS NULL
            OR second_reviewed_content_hash <> content_hash);

**A legacy row is a refusal and not a 500.** A pre-existing violating row that
is updated — publication writes to it — makes Postgres raise, and `main.py` maps
that to a typed 409 naming the draft and the constraint rather than letting an
`IntegrityError` reach a traceback. See `docs/runbooks/legacy-draft-rows.md` for
what to do with one.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0050_review_binds_to_content"
down_revision = "0049_draft_authorship"
branch_labels = None
depends_on = None

TABLE = "pack_drafts"

CONSTRAINT = "pack_drafts_self_signature_reviewed_these_bytes"


def upgrade() -> None:
    # Nullable and not backfilled. A row reviewed before this column existed has
    # no honest value to put here — the body may have moved since — and writing
    # today's hash would manufacture the evidence the column exists to hold.
    op.add_column(
        TABLE,
        sa.Column("second_reviewed_content_hash", sa.String(), nullable=True),
    )

    op.execute(
        f"""
        ALTER TABLE {TABLE}
          ADD CONSTRAINT {CONSTRAINT} CHECK (
            signed_by_user_id IS NULL
            OR signed_by_user_id <> created_by_user_id
            OR (
              second_reviewed_content_hash IS NOT NULL
              AND content_hash IS NOT NULL
              AND second_reviewed_content_hash = content_hash
            )
          ) NOT VALID;
        """
    )


def downgrade() -> None:
    raise NotImplementedError(
        "Dropping this column restores a schema in which a second review names "
        "a person and a time and not the content they read — so an edit between "
        "the review and the signature is invisible, which is the attack this "
        "migration exists to refuse. The constraint alone can be dropped by "
        "hand, deliberately; there is no reversal of the binding itself that "
        "does not lose it."
    )
