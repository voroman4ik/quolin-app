"""Make a plain URL pollable, and let a source say it cannot be.

§S13's review: live polling needed a machine-readable `feed` block, and in the
shipped content exactly one source of nine has one. The other eight are a name
and a URL — which is what a human opens, and is not a feed. So "freshness
CURRENT across all four regimes" was a claim the system could not have earned:
eight sources could only ever be checked by somebody remembering to look.

Two columns, for the two halves of the answer.

`content_hash` makes a plain URL pollable. Fetch the page, normalise it, hash
it, and compare with last time. That is weaker than a feed — it says *something
changed* rather than *what was published* — and it is exactly the signal the
triage tiers already work on, so a changed page raises an item in the human
queue the same way a feed entry does.

`polling_status` is the honest half. Some sources genuinely cannot be polled:
they need a login, or the URL is a search form with no stable result. Those are
`MANUAL`, they carry the date a person last verified them, and the currency
screen renders that as manual verification — distinct from CURRENT, and unable
to roll a jurisdiction up to a clean CURRENT it has not earned.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0027_watch_polling"
down_revision = "0026_audit_chain"
branch_labels = None
depends_on = None

TABLE = "watch_sources"


def upgrade() -> None:
    # The last content we saw at this URL, as a digest. Never the page itself:
    # this table is monitoring state, not an archive, and storing regulator
    # pages would make it one without anybody deciding to.
    op.add_column(
        TABLE, sa.Column("content_hash", sa.Text(), nullable=False, server_default="")
    )

    # `AUTOMATIC` or `MANUAL`. Defaulted to automatic because that is what a
    # source with a readable URL is, and a pack that says otherwise says so.
    op.add_column(
        TABLE,
        sa.Column(
            "polling_status",
            sa.Text(),
            nullable=False,
            server_default="AUTOMATIC",
        ),
    )
    op.create_check_constraint(
        "watch_sources_polling_status_is_known",
        TABLE,
        "polling_status IN ('AUTOMATIC', 'MANUAL')",
    )

    # Which adapter last read it — `rss`, `atom`, `html`, or empty for a source
    # nothing has read yet. Recorded per source because "this regime is current"
    # means something different when it rests on a page digest than when it
    # rests on a publisher's own feed, and a reader is entitled to know which.
    op.add_column(
        TABLE, sa.Column("fetcher", sa.Text(), nullable=False, server_default="")
    )


def downgrade() -> None:
    op.drop_constraint("watch_sources_polling_status_is_known", TABLE, type_="check")
    op.drop_column(TABLE, "fetcher")
    op.drop_column(TABLE, "polling_status")
    op.drop_column(TABLE, "content_hash")
