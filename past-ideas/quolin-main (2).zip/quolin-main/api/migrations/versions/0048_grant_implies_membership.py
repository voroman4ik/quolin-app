"""A grant implies a membership, and the database is what says so.

Migration 0047 put `ensure_member` inside `identity.grant_role` and this file's
author wrote, in that migration and in the commit message, that a grant
therefore could not exist without the membership it implies. CI disproved it
within the hour: two fixtures in `test_rls.py` construct `UserRole` directly,
because they predate the split and there was no reason not to. On a database
built from zero — which is what CI has and a developer machine stops having
after the first run — those grants had no membership, and the person holding
them was invisible to the firm that had granted them.

That is the worst shape this can fail in. The grant authorises, `rbac` reads it
and lets the request through, and the policies then refuse to resolve the person
it authorised. The access review reports a role held by somebody it cannot name.

**So the rule moves into the database.** An `AFTER INSERT` trigger on
`user_roles` writes the membership, which no ORM insert, raw statement, fixture
or future call site can go around. `ensure_member` stays in `grant_role`: two
independent statements of the same rule, exactly as append-only is stated twice
by a trigger and by revoked grants, and for the same reason — the one that can
be forgotten is the one written in Python.

**AFTER rather than BEFORE, and the ordering is load-bearing.** Row-level
security's `WITH CHECK` on `user_roles` is evaluated after `BEFORE` triggers and
before `AFTER` ones. A `BEFORE` trigger would therefore fire on a grant that RLS
is about to refuse — `test_a_firm_cannot_grant_a_role_inside_another_firm`
deliberately attempts one — and the refusal would name `tenant_members` instead
of the table the caller actually tried to write. Same outcome, worse diagnosis.

The insert is `ON CONFLICT DO NOTHING` because granting a second role to
somebody already here is the common case and must be a no-op rather than an
error, and because two grants arriving together must not turn into an integrity
failure on a path that adds nothing.

`NEW.tenant_id` rather than the ambient setting, because it is the tenant the
row itself declares — and RLS on `user_roles` has already refused any row whose
tenant is not the one in scope, so by the time this runs the two agree and the
column is the more direct statement of the two.
"""

from __future__ import annotations

from alembic import op

revision = "0048_grant_implies_membership"
down_revision = "0047_tenant_members"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        CREATE OR REPLACE FUNCTION quolin_grant_implies_membership()
        RETURNS trigger AS $$
        BEGIN
          INSERT INTO tenant_members (tenant_id, user_id, joined_at, reason)
          VALUES (NEW.tenant_id, NEW.user_id, now(), 'granted ' || NEW.role)
          ON CONFLICT (tenant_id, user_id) DO NOTHING;
          RETURN NULL;
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    op.execute(
        """
        CREATE TRIGGER user_roles_imply_membership
        AFTER INSERT ON user_roles
        FOR EACH ROW EXECUTE FUNCTION quolin_grant_implies_membership();
        """
    )

    # And repair anything already in this state. 0047's backfill read
    # `user_roles` as it stood at that moment; a grant written between the two
    # migrations by a path that does not call `ensure_member` would have been
    # missed, and on a database restored from a backup taken in between there
    # would be no other trace of it.
    op.execute(
        """
        INSERT INTO tenant_members (tenant_id, user_id, joined_at, reason)
        SELECT ur.tenant_id, ur.user_id, MIN(ur.granted_at), 'backfill: holds a grant'
        FROM user_roles ur
        GROUP BY ur.tenant_id, ur.user_id
        ON CONFLICT (tenant_id, user_id) DO NOTHING;
        """
    )


def downgrade() -> None:
    raise NotImplementedError(
        "Dropping this trigger restores the state CI found: a grant can be "
        "written by any path that does not call `identity.grant_role`, and the "
        "person holding it is then authorised by `rbac` and unresolvable by the "
        "policies. Nothing about that announces itself — the request succeeds "
        "and the access review reports a role held by nobody nameable."
    )
