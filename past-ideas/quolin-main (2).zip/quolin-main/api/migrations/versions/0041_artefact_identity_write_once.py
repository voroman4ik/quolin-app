"""§S7's determinism gate gets its second lock, and `artefacts` stays mutable.

FP3-10, the reconciliation half. Three lists disagreed about `artefacts` and no
two matched:

  * `scripts/lint_migrations.sh` guarded five names, `artefacts` among them.
  * `models.APPEND_ONLY_TABLES` named eleven, `artefacts` **not** among them.
  * The database enforced thirteen triggers, `artefacts` **not** among them.

**The first draft of this migration made it append-only, and that was wrong.**
Sixteen tests went red and said why: `artefacts/renderer.py` re-renders an
existing document — same `kind`, same `ref_id` — and updates the row in place.
That is not an oversight, it is §S7's design. Regenerating a return for the same
period under the same pack version is expected to be possible, and expected to
produce byte-identical output; `_refuse_a_different_document` compares the
hashes and raises if the bytes have moved.

So the model list and the schema were right and the linter's regex was wrong,
and the reconciliation is to say so rather than to make the schema match a
five-name list somebody typed in Stage 0. The rewritten linter derives its table
list from `models.APPEND_ONLY_TABLES` and the triggers actually present, so the
stale entry is gone by construction.

**What this migration does instead** is enforce the invariant that is genuinely
true and was resting on one application-level `if`.

The second draft made `content_hash` unconditionally write-once, and the suite
refused that too: a return regenerated after more determinations have landed in
its window legitimately has different bytes. Reading `renderer.py` rather than
guessing a third time, the actual rule is

    same_inputs and existing.content_hash and existing.content_hash != content_hash
        -> NotDeterministic

— the hash may not change **when the inputs did not**. That is §S7's
determinism gate stated exactly: "regenerating a return for the same period
under the same pack version produces byte-identical output". Different inputs,
different document, and the row is refreshed.

So that is what the trigger enforces, and it is the second, independent
statement of the same rule, which is the pattern 0001 gives for every other
piece of evidence here:

    a trigger can be dropped by whoever can drop it, and the grant is a second,
    independent statement of the same rule

Filling in an empty hash is permitted: rows written before provenance existed
carry none, and the bytes in front of us are what they describe.
"""

from __future__ import annotations

from alembic import op

revision = "0041_artefacts_append_only"
down_revision = "0040_pack_events"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        CREATE OR REPLACE FUNCTION quolin_artefact_identity_is_write_once()
        RETURNS trigger AS $$
        BEGIN
          IF OLD.content_hash IS NOT NULL
             AND OLD.content_hash <> ''
             AND OLD.inputs_hash IS NOT DISTINCT FROM NEW.inputs_hash
             AND NEW.content_hash IS DISTINCT FROM OLD.content_hash THEN
            RAISE EXCEPTION
              'artefact % was produced from inputs % as content %, and the same '
              'inputs have now produced %. §S7 requires that to be impossible.',
              OLD.id, OLD.inputs_hash, OLD.content_hash, NEW.content_hash;
          END IF;
          RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    op.execute(
        """
        CREATE TRIGGER artefacts_identity_write_once
        BEFORE UPDATE ON artefacts
        FOR EACH ROW EXECUTE FUNCTION quolin_artefact_identity_is_write_once();
        """
    )


def downgrade() -> None:
    raise NotImplementedError(
        "Reversing this removes the database's half of §S7's determinism gate: "
        "that the same inputs under the same pack version produce the same "
        "bytes. The application still checks. Two independent statements of a "
        "rule is the pattern every other piece of evidence here follows."
    )
