"""Baseline: the schema as Stage 0 left it, plus the application role

Revision ID: 0001_baseline
Revises:
Created: 2026-08-23

Everything here already existed, created by `Base.metadata.create_all` in the
seed. It is transcribed explicitly rather than left as a `create_all` call for
one reason: a baseline that reads the live models is not a baseline. It would
describe whatever the models say today, so the first migration that changes a
model would find its column already present and every later migration would be
applying to a schema nobody can reconstruct. A baseline is a frozen fact.

The one genuinely new thing is `quolin_app`, the role the API connects as. It
is created here with no password — passwords are environment-specific and
belong in Secrets Manager or a dev bootstrap, never in a file that is committed.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0001_baseline"
down_revision = None
branch_labels = None
depends_on = None

APPEND_ONLY_TABLES = ("packs", "decisions", "overrides", "audit_events")


def upgrade() -> None:
    op.create_table(
        "clients",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("scenario", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("dob", sa.Date(), nullable=False),
        sa.Column("client_category", sa.String(), nullable=False),
        sa.Column("knowledge_assessed", sa.Boolean(), nullable=False),
        sa.Column("knowledge_date", sa.Date(), nullable=True),
        sa.Column("loss_capacity_band", sa.Integer(), nullable=False),
        sa.Column("vulnerability_flag", sa.Boolean(), nullable=False),
        sa.Column("assessable_portfolio_cents", sa.BigInteger(), nullable=False),
        sa.Column("prior_crypto_purchases", sa.Integer(), nullable=False),
        sa.Column("structural_acks", postgresql.JSONB(), nullable=False),
        sa.Column("default_trade_amount_cents", sa.BigInteger(), nullable=False),
        sa.Column("jurisdiction", sa.String(), nullable=False),
        sa.Column("residency", sa.String(), server_default=sa.text("'AU'"), nullable=False),
        sa.Column("domicile", sa.String(), server_default=sa.text("'AU'"), nullable=False),
        sa.Column("note", sa.Text(), nullable=False),
        sa.Column("is_cast", sa.Boolean(), server_default=sa.text("false"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_clients_scenario", "clients", ["scenario"])

    op.create_table(
        "assets",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("symbol", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "packs",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("jurisdiction", sa.String(), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("effective_from", sa.Date(), nullable=False),
        sa.Column("effective_to", sa.Date(), nullable=True),
        sa.Column("body", postgresql.JSONB(), nullable=False),
        sa.Column("signed_by", sa.String(), nullable=False),
        sa.Column("signed_at", sa.String(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_packs_jurisdiction", "packs", ["jurisdiction"])

    op.create_table(
        "decisions",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("client_id", sa.String(), nullable=False),
        sa.Column("asset_id", sa.String(), nullable=False),
        sa.Column("as_of", sa.Date(), nullable=False),
        sa.Column("pack_id", sa.String(), nullable=True),
        sa.Column("pack_version", sa.Integer(), nullable=False),
        sa.Column("snapshot", postgresql.JSONB(), nullable=False),
        sa.Column("rule_results", postgresql.JSONB(), nullable=False),
        sa.Column("resolution", postgresql.JSONB(), nullable=True),
        sa.Column("outcome", sa.String(), nullable=False),
        sa.Column("prev_hash", sa.String(), nullable=False),
        sa.Column("this_hash", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["client_id"], ["clients.id"]),
        sa.ForeignKeyConstraint(["asset_id"], ["assets.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_decisions_client_id", "decisions", ["client_id"])
    op.create_index("ix_decisions_pack_id", "decisions", ["pack_id"])
    op.create_index("ix_decisions_outcome", "decisions", ["outcome"])

    op.create_table(
        "overrides",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("decision_id", sa.BigInteger(), nullable=False),
        sa.Column("justification", sa.Text(), nullable=False),
        sa.Column("approver", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["decision_id"], ["decisions.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_overrides_decision_id", "overrides", ["decision_id"])

    op.create_table(
        "artefacts",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("kind", sa.String(), nullable=False),
        sa.Column("ref_id", sa.String(), nullable=False),
        sa.Column("title", sa.String(), nullable=False),
        sa.Column("template_version", sa.String(), nullable=False),
        sa.Column("pdf_ref", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_artefacts_ref_id", "artefacts", ["ref_id"])

    op.create_table(
        "audit_events",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("actor", sa.String(), nullable=False),
        sa.Column("action", sa.String(), nullable=False),
        sa.Column("subject", sa.String(), nullable=False),
        sa.Column("at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "watch_sources",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("jurisdiction", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("url", sa.String(), nullable=False),
        sa.Column("cadence_days", sa.Integer(), nullable=False),
        sa.Column("last_checked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_mode", sa.String(), nullable=False),
        sa.Column("enabled", sa.Boolean(), server_default=sa.text("true"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_watch_sources_jurisdiction", "watch_sources", ["jurisdiction"])

    op.create_table(
        "watch_events",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("source_id", sa.String(), nullable=False),
        sa.Column("jurisdiction", sa.String(), nullable=False),
        sa.Column("digest", sa.String(), nullable=False),
        sa.Column("title", sa.Text(), nullable=False),
        sa.Column("summary", sa.Text(), nullable=False),
        sa.Column("url", sa.String(), nullable=False),
        sa.Column("published_at", sa.Date(), nullable=False),
        sa.Column("observed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tier", sa.String(), nullable=False),
        sa.Column("matched", postgresql.JSONB(), nullable=False),
        sa.Column("status", sa.String(), nullable=False),
        sa.Column("note", sa.Text(), nullable=False),
        sa.ForeignKeyConstraint(["source_id"], ["watch_sources.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_watch_events_source_id", "watch_events", ["source_id"])
    op.create_index("ix_watch_events_jurisdiction", "watch_events", ["jurisdiction"])
    op.create_index("ix_watch_events_digest", "watch_events", ["digest"], unique=True)
    op.create_index("ix_watch_events_tier", "watch_events", ["tier"])
    op.create_index("ix_watch_events_status", "watch_events", ["status"])

    op.create_table(
        "pack_drafts",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("jurisdiction", sa.String(), nullable=False),
        sa.Column("base_version", sa.Integer(), nullable=False),
        sa.Column("proposed_version", sa.Integer(), nullable=False),
        sa.Column("effective_from", sa.Date(), nullable=False),
        sa.Column("title", sa.String(), nullable=False),
        sa.Column("rationale", sa.Text(), nullable=False),
        sa.Column("body", postgresql.JSONB(), nullable=False),
        sa.Column("event_ids", postgresql.JSONB(), nullable=False),
        sa.Column("status", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("signed_by", sa.String(), nullable=False),
        sa.Column("signed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("signature_note", sa.Text(), nullable=False),
        sa.Column("published_pack_id", sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(["published_pack_id"], ["packs.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_pack_drafts_jurisdiction", "pack_drafts", ["jurisdiction"])
    op.create_index("ix_pack_drafts_status", "pack_drafts", ["status"])

    op.create_table(
        "auth_sessions",
        sa.Column("token_hash", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("last_seen_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("user_agent", sa.String(), nullable=False),
        sa.Column("created_ip", sa.String(), nullable=False),
        sa.PrimaryKeyConstraint("token_hash"),
    )
    op.create_index("ix_auth_sessions_expires_at", "auth_sessions", ["expires_at"])

    # Append-only, enforced by the database rather than by everyone remembering.
    # `packs`, `decisions`, `overrides` and `audit_events` carry evidence;
    # `clients` legitimately changes and `auth_sessions` must be deletable or
    # logging out is theatre.
    op.execute(
        """
        CREATE OR REPLACE FUNCTION quolin_append_only() RETURNS trigger AS $$
        BEGIN
          RAISE EXCEPTION 'table % is append-only', TG_TABLE_NAME;
        END;
        $$ LANGUAGE plpgsql;
        """
    )
    for table in APPEND_ONLY_TABLES:
        op.execute(
            f"""
            CREATE TRIGGER {table}_append_only
            BEFORE UPDATE OR DELETE ON {table}
            FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
            """
        )

    _create_app_role()


def _create_app_role() -> None:
    """The role the API connects as.

    No password: passwords differ per environment and belong in Secrets Manager
    or a dev bootstrap script, not in version control. No LOGIN either until a
    password is set — a login-capable role with a null password is a role whose
    authentication depends on what pg_hba happens to say.

    What matters more than any of that is what this role is *not*: not a
    superuser, not the owner of these tables, and without BYPASSRLS. Each of
    those three attributes turns every row-level security policy into a comment.
    """
    op.execute(
        """
        DO $$
        BEGIN
          IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'quolin_app') THEN
            CREATE ROLE quolin_app NOLOGIN;
          END IF;
        END
        $$;
        """
    )
    op.execute("REVOKE ALL ON SCHEMA public FROM quolin_app;")
    op.execute("GRANT USAGE ON SCHEMA public TO quolin_app;")
    op.execute(
        "GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO quolin_app;"
    )
    op.execute("GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO quolin_app;")
    # Tables created by later migrations get the same grants without anyone
    # remembering to add them. Scoped to the owner's default privileges, so this
    # cannot grant anything on a table some other role creates.
    op.execute(
        "ALTER DEFAULT PRIVILEGES IN SCHEMA public "
        "GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO quolin_app;"
    )
    op.execute(
        "ALTER DEFAULT PRIVILEGES IN SCHEMA public "
        "GRANT USAGE, SELECT ON SEQUENCES TO quolin_app;"
    )
    # UPDATE and DELETE are granted above and then revoked on exactly the tables
    # the append-only trigger protects. The trigger already refuses, so this is
    # belt and braces on purpose: a trigger can be dropped by whoever can drop
    # it, and the grant is a second, independent statement of the same rule.
    for table in APPEND_ONLY_TABLES:
        op.execute(f"REVOKE UPDATE, DELETE ON {table} FROM quolin_app;")


def downgrade() -> None:
    raise NotImplementedError(
        "The baseline is not reversible. Downgrading it means dropping every "
        "table holding evidence, which is not a thing a migration should offer "
        "to do on the strength of one mistyped command."
    )
