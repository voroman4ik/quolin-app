"""A session may belong to a machine as well as to a person

Revision ID: 0011_machine_sessions
Revises: 0010_integrations
Created: 2026-08-24

The v1 API authenticates with OAuth2 client credentials, which means something
that is not a person needs a session. There were three ways to do that and only
one of them keeps the guarantees Stage 2 built.

**A JWT was the obvious wrong answer.** A self-describing token cannot be
revoked without building the server-side list `auth_sessions` already is — so a
customer whose integration credential leaks would have to wait for expiry. The
whole design of that table is that revocation is real, and a second token format
that could not be revoked would quietly become the weakest way in.

**A separate `api_sessions` table was the tempting wrong answer.** It would have
duplicated expiry-on-read, the idle timeout, the token hashing, `revoke-all` and
`/auth/sessions` — and every one of those is a place where the two copies drift
and the machine half is the one nobody notices is stale.

So: one column. A session names a person or a machine, never both, and every
mechanism that already exists applies unchanged. `revoke-all` now revokes
integrations too, which is the correct behaviour when a credential has reached
the wrong hands and is exactly what a customer would assume that button did.

**`user_id` stays nullable and the constraint is "not both" rather than
"exactly one".** Rows written before Stage 2 have neither, and the middleware
already refuses them — a stricter constraint would fail the migration on any
database that predates people rather than describing what is true now.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0011_machine_sessions"
down_revision = "0010_integrations"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("auth_sessions", sa.Column("api_client_id", sa.String(), nullable=True))
    op.create_foreign_key(
        "auth_sessions_api_client_id_fkey",
        "auth_sessions",
        "api_clients",
        ["api_client_id"],
        ["id"],
    )
    op.create_index(
        "ix_auth_sessions_api_client_id", "auth_sessions", ["api_client_id"]
    )
    # A session that named both would be one whose audit actor depends on which
    # column the reader looked at first.
    op.create_check_constraint(
        "auth_sessions_one_principal",
        "auth_sessions",
        "NOT (user_id IS NOT NULL AND api_client_id IS NOT NULL)",
    )


def downgrade() -> None:
    op.drop_constraint("auth_sessions_one_principal", "auth_sessions", type_="check")
    op.drop_index("ix_auth_sessions_api_client_id", "auth_sessions")
    op.drop_constraint(
        "auth_sessions_api_client_id_fkey", "auth_sessions", type_="foreignkey"
    )
    op.drop_column("auth_sessions", "api_client_id")
