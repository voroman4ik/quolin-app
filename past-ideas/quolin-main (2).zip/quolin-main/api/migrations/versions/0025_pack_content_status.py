"""`content_status` as a column, so the database can refuse unreviewed rules.

The execution plan's rule that cannot be waived: no jurisdiction ships to a
production tenant on in-house content, however good the in-house content looks.
The flag existed and nothing enforced it. Every pack body already carries
`content_status` — the AU packs say `PENDING_REVIEW`, with the signatory
recorded as `[DDO consultant — pending engagement]` — and `packs_repo.active`
selected on jurisdiction and effective date alone. A live customer would have
been served those rules and told nothing.

**Why a column when the value is already in the body.** A rule the database can
check is a rule no code path can skip. `body` is JSONB, so a CHECK on a value
inside it is possible and unreadable; lifting it to a column makes the
constraint below legible to somebody reading the schema, and makes the loader's
filter an index-able predicate rather than a JSON extraction.

**The second constraint is the one that matters.** A row may only claim
`REVIEWED` if it names somebody. The two placeholder conventions this repository
uses — a bracketed `[specialist — pending engagement]` and the shouted
`ILLUSTRATIVE - NOT PROFESSIONALLY REVIEWED` — are both refused. A pack marked
reviewed with nobody's name against it is either a mistake or somebody routing
around the specialist, and neither should be storable.

**Vocabulary unchanged.** `REVIEWED / PENDING_REVIEW / ILLUSTRATIVE` is what
`app/engine/pack.py` has always used and what every pack file says. The external
review proposed `SIGNED` plus a `DRAFT`/`IN_REVIEW` pair; `SIGNED` is a second
name for `REVIEWED`, and the draft states belong to `watch_drafts`, which is a
different table with a different lifecycle. Renaming would have touched every
pack file and both currency screens to change nothing.

**Generated from the body, not backfilled into it.** The first version of this
migration added a plain column and ran an `UPDATE` to populate it. Postgres
refused: `table packs is append-only`, which is the trigger doing exactly its
job — packs are content of record and a migration is not a licence to edit them.

A `GENERATED ALWAYS AS ... STORED` column needs no `UPDATE`. Postgres computes
it for every existing row as part of the DDL and for every future row on insert,
which means the column and the body cannot disagree — there is no write path
that could set one without the other. The first design had that drift as a
latent bug; this one cannot have it.

A body that declares no status reads as `ILLUSTRATIVE`, which is the direction
that refuses rather than admits.
"""

from __future__ import annotations

from alembic import op

revision = "0025_pack_content_status"
down_revision = "0024_chain_no_forks"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        ALTER TABLE packs
        ADD COLUMN content_status TEXT
        GENERATED ALWAYS AS (
            COALESCE(NULLIF(body ->> 'content_status', ''), 'ILLUSTRATIVE')
        ) STORED;
        """
    )

    op.create_check_constraint(
        "packs_content_status_is_known",
        "packs",
        "content_status IN ('REVIEWED', 'PENDING_REVIEW', 'ILLUSTRATIVE')",
    )

    # Reviewed content names a person. Both placeholder conventions are refused
    # by shape rather than by an exact string, because the next placeholder will
    # be spelled differently and will still be a placeholder.
    op.create_check_constraint(
        "packs_reviewed_needs_a_signatory",
        "packs",
        """
        content_status <> 'REVIEWED'
        OR (
            signed_by IS NOT NULL
            AND btrim(signed_by) <> ''
            AND signed_by NOT LIKE '[%'
            AND signed_by NOT LIKE '%ILLUSTRATIVE%'
            AND signed_by NOT LIKE '%pending engagement%'
        )
        """,
    )

    # The loader's predicate: jurisdiction, date, and now status.
    op.create_index(
        "ix_packs_status_lookup", "packs", ["jurisdiction", "content_status"]
    )


def downgrade() -> None:
    op.drop_index("ix_packs_status_lookup", table_name="packs")
    op.drop_constraint("packs_reviewed_needs_a_signatory", "packs", type_="check")
    op.drop_constraint("packs_content_status_is_known", "packs", type_="check")
    op.drop_column("packs", "content_status")
