"""A queue between the sweep, which sees breaches, and the worker that can tell anyone.

FP3-03. The 27 August sweep produced `source.stale` by having
`scripts/watch_tick.py` call `source_alerts.notify_tenants(all_tenant_ids(),
breaches)`. Read as a call graph that is correct. Read as a deployment it cannot
run:

  * `all_tenant_ids` opens `OwnerSessionLocal` — `DATABASE_URL`.
  * `notify_tenants` opens `SessionLocal` — `APP_DATABASE_URL`.
  * The watch ECS task holds `WATCH_DATABASE_URL` and nothing else, and
    `guard_no_watch_in_engine.sh` check 6 *fails the build* if it holds either
    of the others.

So in production both engines fall back to `db.py`'s hardcoded
`localhost:5433`, where nothing is listening, and the sweep raises after paging
the specialist and before printing its summary — every run, for as long as any
source is in breach. It is green on a developer's laptop and in CI because both
have all three connection strings and a database at that address.

**Why a table rather than widening the watch task's credentials.** The
separation is the point of Stage 6: the watch service reads publications and
writes drafts, and the one thing it must never hold is a credential that can
write a pack or read a customer's data. Handing it `APP_DATABASE_URL` to send a
webhook would trade a real security property for a notification.

So the sweep writes what it saw, with the only credential it has, and a worker
that already holds the application role picks it up and fans it out.

**The breach itself is global.** A source being down is a fact about a
regulator's feed, not about any customer, so `source_breaches` carries no
`tenant_id` and no policy — every tenant's notification is derived from the same
row, rather than one row per firm per outage all saying the same thing about the
same website.

Both tables are append-only, for the ordinary reason: this is the evidence that
we knew a feed was dark and when each firm was told, and the answer to "when did
you know" must not be editable afterwards.

`source_breach_notices` is the other half. Whether a breach has been fanned out
to a given tenant cannot be a column on the breach — that would be an UPDATE to
an append-only row — so it is a second appended row per (breach, tenant), which
also makes the worker idempotent by construction: it selects breaches with no
notice for a tenant, so running it twice sends nothing twice.

**And that half *is* tenant-scoped**, unlike the breach it points at. The first
draft made both global and `test_packs_stay_global` refused it: a table carrying
`tenant_id` and no policy is the shape every cross-tenant read has, and the
suite is right to treat the pair as a contradiction rather than a style
question. What a given firm has been told is that firm's record. The fan-out
already runs inside `tenancy.acting_as(tenant_id)` — it has to, because
enqueueing the webhook does — so there is a bound tenant at the moment the row
is written and the policy costs nothing.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0038_source_breaches"
down_revision = "0037_untrusted_xff"
branch_labels = None
depends_on = None

WATCH = "quolin_watch"
APP = "quolin_app"


def upgrade() -> None:
    op.create_table(
        "source_breaches",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("source_id", sa.String(), nullable=False),
        sa.Column("jurisdiction", sa.String(), nullable=False),
        # The whole breach as the sweep saw it, so the notification a tenant
        # receives is built from what was recorded rather than from a second
        # read of a source row that may have changed since.
        sa.Column("detail", postgresql.JSONB(), nullable=False),
        sa.Column("observed_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_source_breaches_source_id", "source_breaches", ["source_id"])
    op.create_index("ix_source_breaches_observed_at", "source_breaches", ["observed_at"])

    op.create_table(
        "source_breach_notices",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("breach_id", sa.BigInteger(), nullable=False),
        sa.Column("tenant_id", sa.String(), nullable=False),
        sa.Column("notified_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["breach_id"], ["source_breaches.id"]),
        sa.PrimaryKeyConstraint("id"),
        # The idempotency, in the schema rather than in the worker's care. Two
        # workers racing produce one notification and one integrity error, not
        # two notifications.
        sa.UniqueConstraint("breach_id", "tenant_id", name="uq_breach_notice"),
    )

    op.execute("ALTER TABLE source_breach_notices ENABLE ROW LEVEL SECURITY;")
    op.execute("ALTER TABLE source_breach_notices FORCE ROW LEVEL SECURITY;")
    op.execute(
        """
        CREATE POLICY tenant_isolation ON source_breach_notices
        USING (tenant_id = current_setting('app.tenant_id', true))
        WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
        """
    )

    for table in ("source_breaches", "source_breach_notices"):
        op.execute(
            f"""
            CREATE TRIGGER {table}_append_only
            BEFORE UPDATE OR DELETE ON {table}
            FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
            """
        )
        # 0001's ALTER DEFAULT PRIVILEGES already granted all four to the
        # application role on any new table, and FP3-10 is what happens when a
        # migration adds an append-only table and forgets this line.
        op.execute(f"REVOKE UPDATE, DELETE, TRUNCATE ON {table} FROM {APP};")

    # The sweep writes breaches and reads nothing else here. It must not be able
    # to write a notice: that would let a compromised watch task mark every
    # breach as already told and silence the fan-out without deleting anything.
    op.execute(f"GRANT INSERT ON source_breaches TO {WATCH};")
    op.execute(f"REVOKE UPDATE, DELETE, TRUNCATE ON source_breaches FROM {WATCH};")
    op.execute(f"REVOKE ALL ON source_breach_notices FROM {WATCH};")
    op.execute(f"GRANT SELECT ON source_breach_notices TO {WATCH};")

    op.execute(f"GRANT INSERT ON source_breach_notices TO {APP};")


def downgrade() -> None:
    raise NotImplementedError(
        "This is the record of when a regulator's feed was known to be dark and "
        "when each firm was told. Dropping it removes the answer to 'when did "
        "you know', which is the question it exists to answer."
    )
