"""Source SLAs: who owns a source, and when it has stopped answering.

§S6 asks for per-source check frequency and alert thresholds, and for a source
unreachable for three consecutive checks to page its specialist owner. The
cadence half already existed — `cadence_days` has been on the table since the
watch service was built, and freshness is derived from it on read. What was
missing was the failure half: nothing recorded that a check had been *attempted
and failed*, so a source that went dark looked exactly like one nobody had got
to yet.

Five columns, and each is a fact somebody acts on:

  owner                  who gets paged. Declared in pack content beside the
                         source, because an alert with nobody's name on it is
                         one everybody assumes somebody else is handling.
  consecutive_failures   reset by any success, so a source that flaps does not
                         accumulate its way to an alert over a good month.
  alert_after_failures   per source, because a daily feed and a monthly one earn
                         an alert at different speeds.
  last_error             why, in the words the person paged reads.
  alerted_at             when they were last told. Stored, unlike freshness,
                         because it is a delivery fact rather than a derivation
                         — and without it every sweep re-pages.

`last_failed_at` sits beside `last_checked_at` rather than replacing it. They
answer different questions: "when did we last look" and "when did looking last
not work", and a screen that collapsed them would show a source as freshly
checked on the strength of a timeout.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0013_source_slas"
down_revision = "0012_pack_lifecycle"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "watch_sources",
        sa.Column("owner", sa.String(), nullable=False, server_default=""),
    )
    op.add_column(
        "watch_sources",
        sa.Column(
            "consecutive_failures", sa.Integer(), nullable=False, server_default="0"
        ),
    )
    op.add_column(
        "watch_sources",
        sa.Column(
            "alert_after_failures", sa.Integer(), nullable=False, server_default="3"
        ),
    )
    op.add_column(
        "watch_sources",
        sa.Column("last_error", sa.Text(), nullable=False, server_default=""),
    )
    op.add_column(
        "watch_sources",
        sa.Column("last_failed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.add_column(
        "watch_sources",
        sa.Column("alerted_at", sa.DateTime(timezone=True), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("watch_sources", "alerted_at")
    op.drop_column("watch_sources", "last_failed_at")
    op.drop_column("watch_sources", "last_error")
    op.drop_column("watch_sources", "alert_after_failures")
    op.drop_column("watch_sources", "consecutive_failures")
    op.drop_column("watch_sources", "owner")
