"""What a model was asked, and what it said. Retained, and append-only.

§S6 asks that the LLM boundary be productionised: summarisation and
classification inside the watch service only, no credentials for core-api,
prompts and outputs retained for audit, confidence recorded, and below-threshold
classifications escalating conservatively. This is the retention half.

The reason it is append-only rather than a log table is narrower than "we keep
logs". The product's central claim is that no model decides anything — rules
decide, and a model may raise a hand. A reader is entitled to check that claim
against what the model was actually asked and what it actually answered, rather
than against our description of it. A retention record that can be edited after
the fact answers a different question: what do you *say* it said.

So it gets the same treatment as `decisions` and `audit_events`: the trigger
refuses UPDATE and DELETE, and the grant is revoked as a second, independent
statement of the same rule. A trigger can be dropped by whoever can drop it.

Not tenant-scoped, because `watch_events` is not either: the publication is the
same publication for every customer, and so is the reading of it.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0015_watch_assist_calls"
down_revision = "0014_watch_role"
branch_labels = None
depends_on = None

TABLE = "watch_assist_calls"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column(
            "event_id",
            sa.BigInteger(),
            sa.ForeignKey("watch_events.id"),
            nullable=False,
            index=True,
        ),
        # The exact model, not a family name: "we use Claude" does not survive
        # the question of which one, and behaviour differs between them.
        sa.Column("model", sa.String(), nullable=False),
        sa.Column("prompt", sa.Text(), nullable=False),
        sa.Column("output", sa.Text(), nullable=False),
        # Whole percent, deliberately an integer. The exact value the model
        # returned is in `output` verbatim, which is the copy that matters.
        sa.Column("confidence_pct", sa.Integer(), nullable=False),
        # The tier pack vocabulary produced, stored beside the suggestion so the
        # two can be compared later without re-deriving either.
        sa.Column("deterministic_tier", sa.String(), nullable=False),
        sa.Column(
            "escalated", sa.Boolean(), nullable=False, server_default=sa.text("false")
        ),
        sa.Column("escalation_reason", sa.Text(), nullable=False, server_default=""),
        sa.Column(
            "at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )

    op.execute(
        f"""
        CREATE TRIGGER {TABLE}_append_only
        BEFORE UPDATE OR DELETE ON {TABLE}
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )
    op.execute(f"REVOKE UPDATE, DELETE ON {TABLE} FROM quolin_app;")
    # The watch service writes these and must not be able to rewrite them. It is
    # the only process that writes them at all.
    op.execute(f"GRANT INSERT ON {TABLE} TO quolin_watch;")
    op.execute(f"REVOKE UPDATE, DELETE ON {TABLE} FROM quolin_watch;")


def downgrade() -> None:
    raise NotImplementedError(
        "This table is append-only evidence: what a model was asked and what it "
        "answered, kept so the claim that no model decides anything can be "
        "checked rather than believed. Dropping it means dropping that record, "
        "which is not a thing a migration should offer to do on the strength of "
        "one mistyped command. Migration 0001 takes the same position."
    )
