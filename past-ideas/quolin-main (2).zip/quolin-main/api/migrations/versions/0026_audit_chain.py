"""Hash-chain the audit trail, so a fabricated history cannot hide either.

`docs/threat-model.md` T3, recorded as **not closed** since §S9 and named in
§S13's review as the largest unmitigated item in the document. Determinations
are chained; audit events were append-only and nothing more. Append-only stops
a row being edited or removed *by the application role* — it does nothing about
a privileged actor inserting rows that never happened, and the CSV export
carried no arithmetic proof that the sequence was intact. An auditor reading it
had our word.

**The same mechanism as decisions, deliberately.** Canonical JSON, the same
`chain_hash`, a `prev_hash` and a `this_hash` per row, and one chain per tenant.
A second scheme would have been a second thing to verify, a second thing to get
wrong, and a second set of tooling.

**The genesis is derived from the tenant's existing anchor** rather than stored
in a second row: `chain_hash(anchor.genesis_hash, {"chain": "audit_events"})`.
That inherits the property the anchor was built for — a tenant deleted and
recreated under the same slug gets a different anchor, so nothing from the old
chain verifies against the new one — without a second table or a wider primary
key on an append-only one.

**Existing rows are outside the chain until backfilled, and say so.** Both
columns default to the empty string, which is not a hash and cannot be mistaken
for one. `make rechain ARGS="--table audit_events --apply"` links them, as the
owner, with the trigger dropped for the duration — the same pattern
`scripts/rechain.py` has always used for decisions, and the only pattern in this
repository that is allowed to write to an append-only table.

The unique index is partial for that reason: unlinked rows all share an empty
`prev_hash`, and they are not forks.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0026_audit_chain"
down_revision = "0025_pack_content_status"
branch_labels = None
depends_on = None

TABLE = "audit_events"


def upgrade() -> None:
    op.add_column(
        TABLE, sa.Column("prev_hash", sa.Text(), nullable=False, server_default="")
    )
    op.add_column(
        TABLE, sa.Column("this_hash", sa.Text(), nullable=False, server_default="")
    )

    # One child per parent, the same guarantee migration 0024 gives decisions
    # after §S13's restore drill found a chain forked by concurrent writes.
    # Partial, because every row written before the backfill shares an empty
    # `prev_hash` and those are absences rather than forks.
    op.execute(
        """
        CREATE UNIQUE INDEX ix_audit_events_one_child_per_parent
        ON audit_events (tenant_id, prev_hash)
        WHERE prev_hash <> '';
        """
    )

    # The verifier walks a tenant's rows in order.
    op.create_index("ix_audit_events_chain_walk", TABLE, ["tenant_id", "id"])


def downgrade() -> None:
    """Refused. FP3-01.

    This used to drop both chain columns, which is what alembic's own idiom
    suggests: the migration added them, so the reverse removes them. Read as a
    schema change that is correct, and it is. Read as an operation somebody can
    run on a deployment, it is the destruction of the audit chain — the rows
    survive, the arithmetic proving nobody inserted or removed one does not, and
    what is left is a history that reads exactly like a real one and cannot be
    checked. That is the T3 threat this migration was written to close, reopened
    by the migration itself.

    It was not caught for the ordinary reason: the linter that was supposed to
    catch it was a regex for the SQL spelling `drop column`, and alembic writes
    `op.drop_column`. The guard reported the tree clean for as long as this
    existed. `scripts/migration_lint.py` now applies each downgrade to a scratch
    database and reads the catalog back, and this migration is the case it was
    rewritten around.

    Twelve migrations in this tree already decline to reverse for the same class
    of reason, 0001 among them. This is the thirteenth. If the columns genuinely
    have to go, that is a migration somebody writes and signs, with the chain
    exported first — not a reversal that happens because a deploy was rolled
    back.
    """
    raise NotImplementedError(
        "0026 is not reversible. Dropping prev_hash and this_hash leaves every "
        "audit row readable and unverifiable, which is worse than either — and "
        "is the exact tampering this migration exists to make detectable. "
        "Export the chain and write a forward migration instead."
    )
