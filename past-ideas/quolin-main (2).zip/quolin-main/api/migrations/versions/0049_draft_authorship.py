"""A draft has an author, and a signature that is not the author's own.

`pack_drafts` recorded `signed_by`, `signed_by_user_id`, `signed_at` and no
author field at all. Draft authorship was never persisted anywhere the row could
be asked about, so the one separation §3.2 requires — the person who wrote a
rule change is not the person who attests to it — could neither be enforced nor
evidenced. `api/tests/test_lifecycle.py` asserted the opposite in as many words:
a signatory authored content and signed it in the same breath and the suite
called that correct.

`drafts.publish` already refuses a publisher who signed, and that check is a
different one. Publication is the second pair of eyes on a *signature*; this is
the second pair of eyes on the *content*. One person writing a rule and signing
it is not made a review by a third person pressing publish afterwards — the
publisher reviews an attestation they cannot check, because the only person who
read the content is the one who wrote it.

**Four columns.**

`created_by_user_id` is NOT NULL because a draft with no author is the state
this migration exists to end. `created_by` is the display name, kept beside the
id for the reason `signed_by` is kept beside `signed_by_user_id`: an id answers
"who did this" only for somebody who can query the database, and the FP3-26
walkthrough found exactly that printed on a screen.

`second_reviewer_user_id` and `second_reviewed_at` are the escape hatch, and it
is deliberately narrow. A specialist who authors content may sign it *provided
somebody else, qualified for that regime, has read it and said so on the record*
— which is a review, performed by a second person, rather than a rule that
cannot be satisfied by a firm with one specialist and would therefore be routed
around.

**The backfill is honest and is two different answers.**

`pack_draft_transitions` records the creation of every draft with `by_actor`
defaulted from the ambient scope, and `drafts.publish` has always read that row
to fill `pack_publications.drafted_by`. Where it names somebody, that *is* the
author and this migration uses it. Where it is null — the seed, the offline
scripts, anything that ran with no user in scope — nothing in this database
knows who wrote the draft, so the row is stamped `UNKNOWN_PRE_MIGRATION`: a
value that is obviously not a person, cannot collide with a `usr_` id, and
cannot be mistaken for an attribution.

The display name is `UNKNOWN_PRE_MIGRATION` on **every** pre-migration row, even
where the account is known. No display name was ever recorded against a draft's
creation, and writing the account id into a column that is printed as a name
would be the FP3-26 defect committed on purpose.

**The constraint, and why it is NOT VALID.**

The CHECK makes the forbidden state unrepresentable rather than merely refused
in Python: `drafts.sign` can be edited, and a row inserted from a shell cannot
be. It says the signer is not the author, unless an independent second reviewer
is recorded who is neither of them.

It is added `NOT VALID`, which enforces it on every row written from now on and
does not assert it about rows written before it existed. That is the honest
position: this repository's own suite has been signing self-authored drafts for
thirteen stages, so there are databases holding rows that violate this rule.
Validating would either fail the migration on those databases or — worse —
require rewriting the backfill until nothing violated, which is manufacturing a
clean history. The rows are left as they are, and what they are is now visible:
`created_by_user_id = signed_by_user_id` with no second reviewer is a query.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0049_draft_authorship"
down_revision = "0048_grant_implies_membership"
branch_labels = None
depends_on = None

TABLE = "pack_drafts"

#: What a row says when nothing in this database knows who wrote it.
#:
#: Obviously not a person and obviously not an account: every real identity in
#: this system is `usr_…` or `apc_…`, so this cannot be confused for one, and it
#: cannot silently satisfy the independence constraint against a real signer
#: either — which is the point of choosing a value no signer can ever equal.
UNKNOWN = "UNKNOWN_PRE_MIGRATION"

CONSTRAINT = "pack_drafts_signature_is_independent"


def upgrade() -> None:
    op.add_column(TABLE, sa.Column("created_by_user_id", sa.String(), nullable=True))
    op.add_column(
        TABLE, sa.Column("created_by", sa.String(), nullable=False, server_default="")
    )
    op.add_column(
        TABLE, sa.Column("second_reviewer_user_id", sa.String(), nullable=True)
    )
    # The name beside the account, captured when the review happens rather than
    # resolved at publication — the argument `signed_qualification_ref` makes.
    # A name looked up later is whatever the directory says today, and what a
    # published pack should record is the claim as it was made.
    op.add_column(
        TABLE, sa.Column("second_reviewer", sa.String(), nullable=False, server_default="")
    )
    op.add_column(
        TABLE,
        sa.Column("second_reviewed_at", sa.DateTime(timezone=True), nullable=True),
    )

    # The account, from the row this system has always written when a draft came
    # into existence. `lifecycle.record_creation` inserts it with `from_status`
    # null, which is what identifies it — a draft has exactly one such row.
    op.execute(
        f"""
        UPDATE {TABLE} d
           SET created_by_user_id = t.by_actor
          FROM (
            SELECT DISTINCT ON (draft_id) draft_id, by_actor
              FROM pack_draft_transitions
             WHERE from_status IS NULL
             ORDER BY draft_id, at, id
          ) t
         WHERE t.draft_id = d.id
           AND t.by_actor IS NOT NULL
           AND t.by_actor <> '';
        """
    )
    # Everything the transition log could not name.
    op.execute(
        f"UPDATE {TABLE} SET created_by_user_id = '{UNKNOWN}' "
        "WHERE created_by_user_id IS NULL;"
    )
    # And the display name, which was never recorded for any of them.
    op.execute(f"UPDATE {TABLE} SET created_by = '{UNKNOWN}' WHERE created_by = '';")

    op.alter_column(TABLE, "created_by_user_id", nullable=False)

    # `NOT VALID`: enforced on every write from here, not asserted about the
    # rows that predate it. See the module docstring — a validating form would
    # have to be bought with a dishonest backfill.
    op.execute(
        f"""
        ALTER TABLE {TABLE}
          ADD CONSTRAINT {CONSTRAINT} CHECK (
            signed_by_user_id IS NULL
            OR signed_by_user_id <> created_by_user_id
            OR (
              second_reviewer_user_id IS NOT NULL
              AND second_reviewer_user_id <> created_by_user_id
              AND second_reviewer_user_id <> signed_by_user_id
            )
          ) NOT VALID;
        """
    )

    # And the record that follows the content out to every firm governed by it.
    #
    # `pack_publications.drafted_by` has carried the creation transition's
    # `by_actor` since migration 0033 — an account id, in a column read as a
    # name. A compliance officer at a firm inheriting these rules could see
    # `usr_3FT6FW8AcS5hIT-m` drafted them, which answers "who authored this rule
    # change" only for somebody who can query our database. The name and the
    # account are separated here for the reason they are separated everywhere
    # else, and the second reviewer travels with them: an attestation whose
    # independence rests on a third person is not evidenced by naming two.
    #
    # Nullable, and not backfilled. Rows written before this migration recorded
    # neither, and `pack_publications` is append-only precisely so that a later
    # writer cannot decide what an earlier one meant.
    op.add_column(
        "pack_publications", sa.Column("drafted_by_user_id", sa.String(), nullable=True)
    )
    op.add_column(
        "pack_publications",
        sa.Column("second_reviewer_user_id", sa.String(), nullable=True),
    )


def downgrade() -> None:
    raise NotImplementedError(
        "Dropping these columns destroys the only record of who authored each "
        "rule change, which is the fact this migration exists to persist — and "
        "it restores a schema in which a signatory can attest to their own "
        "content with nothing able to tell. The constraint alone can be dropped "
        "if it has to be, deliberately and by hand; there is no reversal of the "
        "authorship itself that does not lose it."
    )
