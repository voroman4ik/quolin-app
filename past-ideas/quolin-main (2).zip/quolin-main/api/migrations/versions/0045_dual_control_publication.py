"""Publication takes two publishers, and neither of them is the signer.

FP3-27's second half. `SelfReview` already enforces signer ≠ publisher, which is
one pair of eyes on signed content. What it does not give is a second pair on
the *publication itself* — the act that puts content in front of every customer
on the platform.

Three distinct people: the signer attests that the content is right, and two
platform publishers each independently decide that it should go live. One
compromised or careless account cannot do it, and neither can one compromised
account plus the signature it also holds.

**Approvals are their own table rather than two columns on the draft**, because
"who approved, when, and were they the same person" is three questions and a
pair of nullable columns answers the first two badly and the third by
comparison. It is append-only for the ordinary reason: an approval somebody
could withdraw quietly is not an approval.

The count is deliberately not configurable. A number in a settings table is a
number somebody sets to one during an incident, and the whole value of dual
control is that it cannot be relaxed by whoever is in a hurry.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0045_dual_control"
down_revision = "0044_platform_publishers"
branch_labels = None
depends_on = None

TABLE = "publication_approvals"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("draft_id", sa.Integer(), nullable=False),
        sa.Column("approved_by", sa.String(), nullable=False),
        #: The content hash the approver saw. An approval of bytes that have
        #: since moved is not an approval of what is being published — the same
        #: argument F4 makes about the signature.
        sa.Column("content_hash", sa.String(), nullable=False, server_default=""),
        sa.Column("approved_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["draft_id"], ["pack_drafts.id"]),
        sa.ForeignKeyConstraint(["approved_by"], ["users.id"]),
        # One approval per person per draft. Two clicks from one publisher is
        # one pair of eyes, and without this it would count as two.
        sa.UniqueConstraint("draft_id", "approved_by", name="uq_one_approval_each"),
    )
    op.create_index("ix_publication_approvals_draft", TABLE, ["draft_id"])

    op.execute(
        f"""
        CREATE TRIGGER {TABLE}_append_only
        BEFORE UPDATE OR DELETE ON {TABLE}
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )
    op.execute(f"REVOKE UPDATE, DELETE, TRUNCATE ON {TABLE} FROM quolin_app;")
    op.execute(f"REVOKE ALL ON {TABLE} FROM quolin_watch;")


def downgrade() -> None:
    raise NotImplementedError(
        "This is the record of who agreed that a piece of rule content should "
        "govern every customer on the platform. Dropping it removes the "
        "evidence that two people did."
    )
