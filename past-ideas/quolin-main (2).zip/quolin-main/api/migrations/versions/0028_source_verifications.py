"""A person recording that they checked a source a machine cannot read.

§S13 added `polling_status: MANUAL` for publications nothing can poll — a
search portal whose front page moves without anything being published, a feed
behind a login. Those carry the date somebody last looked, and the fix-pack left
one thing unbuilt and said so: there was no way to *record* that somebody had
looked. The seed asserted a date so the state was visible, and a real deployment
would have watched its manual sources drift to STALE with no way to say
otherwise.

This is the record. It is deliberately a table rather than a column on
`watch_sources`, and the reason is the same one behind every other evidence
table here: `watch_sources.last_checked_at` is *derived state* that gets
overwritten on every check, and an attestation that somebody personally
verified a regulator's page is not something to overwrite. A firm asked why
their AU sources were current in March needs the March attestation, not the one
from last week.

**Append-only, like the rest of the evidence.** Trigger and revoked grant, both.
A verification is somebody putting their name to a claim about what a regulator
had published, which is the same kind of statement as a pack signature and gets
the same treatment.

**One row per person per source per day is not enforced.** Two people checking
the same source on the same day is a real thing that happens at a handover, and
refusing the second would lose the more recent one.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0028_source_verifications"
down_revision = "0027_watch_polling"
branch_labels = None
depends_on = None

TABLE = "source_verifications"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column(
            "tenant_id",
            sa.String(),
            sa.ForeignKey("tenants.id"),
            nullable=False,
            index=True,
        ),
        sa.Column(
            "source_id",
            sa.String(),
            sa.ForeignKey("watch_sources.id"),
            nullable=False,
            index=True,
        ),
        #: The date the person says they looked, which is not always today —
        #: somebody recording Friday's check on Monday is the normal case, and
        #: forcing it to now would make the record wrong to keep it tidy.
        sa.Column("verified_on", sa.Date(), nullable=False),
        #: The account that recorded it. A provisioned row, never a typed name:
        #: the whole point is that somebody can be asked about it.
        sa.Column("verified_by", sa.String(), nullable=False, index=True),
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
        #: Where the proof lives, if there is any — a ticket, a document store
        #: reference, a screenshot's filename. Free text on purpose: it points
        #: at somebody else's system and we should not pretend to validate it.
        sa.Column("attachment_ref", sa.Text(), nullable=False, server_default=""),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )

    op.create_index(
        f"ix_{TABLE}_newest", TABLE, ["tenant_id", "source_id", "verified_on"]
    )

    op.execute(
        f"""
        CREATE TRIGGER {TABLE}_append_only
        BEFORE UPDATE OR DELETE ON {TABLE}
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )
    op.execute(f"REVOKE UPDATE, DELETE ON {TABLE} FROM quolin_app;")

    op.execute(f"ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY;")
    op.execute(f"ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY {TABLE}_tenant ON {TABLE}
        USING (tenant_id = current_setting('app.tenant_id', true))
        WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
        """
    )


def downgrade() -> None:
    raise NotImplementedError(
        "These are attestations: named people saying they checked a regulator's "
        "publication on a date. Dropping the table drops the record of who said "
        "what, which is not a thing a migration should offer to do on the "
        "strength of one mistyped command. Migration 0001 takes the same "
        "position."
    )
