"""The application role could edit the record of who rewrote a firm's evidence.

FP3-10, found by the FP3-01 linter on the first run of its standing-state check.

`chain_rechains` records that somebody rebuilt a tenant's hash chain, and it is
the only thing distinguishing that operation from a tamper. It is in
`models.APPEND_ONLY_TABLES`, it carries the append-only trigger, and
`quolin_app` held UPDATE and DELETE on it.

**Nothing in migration 0034 did that.** 0034 wrote `GRANT SELECT ON
chain_rechains TO quolin_app`, and reading it in review the intent is
unmistakable and correct: the application may look, the owner writes. What it
missed is that migration 0001 sets

    ALTER DEFAULT PRIVILEGES IN SCHEMA public
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO quolin_app;

so every table created after it arrives with all four already granted, and 0001
revokes UPDATE and DELETE on the append-only ones *by name*. A table added to
the append-only set later has to be added to that revoke list too, and 0034 was
not. The `GRANT SELECT` was a no-op on top of a wider grant, which is why it
read as narrowing and was not.

So the trigger was the only control standing. That is one mechanism where the
design calls for two, and 0001's own comment says why it calls for two: "a
trigger can be dropped by whoever can drop it, and the grant is a second,
independent statement of the same rule."

**Why no guard caught it for two migrations.** The old linter was a regex over
migration source text looking for a `GRANT` statement. There was no `GRANT`
statement to find — the privilege arrived by default privilege, from a migration
thirty-three revisions earlier, and no line of SQL anywhere in the tree says so.
Only the catalog does. The rewritten linter reads the catalog, and asks the
question about the end state rather than about each diff, because a weakness
that arrives with a table appears in no diff at all.
"""

from __future__ import annotations

from alembic import op

revision = "0036_rechain_grants"
down_revision = "0035_signed_content_hash"
branch_labels = None
depends_on = None

TABLE = "chain_rechains"


def upgrade() -> None:
    op.execute(f"REVOKE UPDATE, DELETE, TRUNCATE ON {TABLE} FROM quolin_app;")
    op.execute(f"REVOKE UPDATE, DELETE, TRUNCATE ON {TABLE} FROM quolin_watch;")


def downgrade() -> None:
    raise NotImplementedError(
        "Reversing this re-grants UPDATE and DELETE on the record of who "
        "rewrote a firm's evidence hashes, which is the finding rather than the "
        "fix. If the application genuinely needs to write here, that is a "
        "forward migration somebody signs."
    )
