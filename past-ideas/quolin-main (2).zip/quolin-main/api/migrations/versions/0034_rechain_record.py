"""A rewrite of a firm's evidence, recorded as an event rather than performed silently.

`scripts/rechain.py` is a legitimate maintenance tool and it is also the only
thing in this system that rewrites hashes on rows already written. Its own module
note has said so since it was written: it looks exactly like a tamper, and the
only difference is that somebody meant it.

That difference was not written down anywhere. The tool wrote one audit event
after the fact naming the *new* tip, which leaves an auditor holding an export
from before and one from after with every hash different and nothing to
reconcile them against — the exact position the tool's own docstring says it
puts them in.

`chain_rechains` is one row per rewrite: which table, who asked for it, why,
the tip before, the tip after, and how many rows moved. Tenant-scoped, because a
rewrite of one firm's chain is that firm's business, and append-only, because a
rechain that could be un-recorded is a rechain that was never recorded.

The tip before is the field that matters most and is the one that was missing.
It is the only thing that lets somebody take an old export and say "yes, this is
where that chain ended, and this row is why the numbers changed".
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0034_rechain_record"
down_revision = "0033_global_publication_record"
branch_labels = None
depends_on = None

TABLE = "chain_rechains"
SETTING = "app.tenant_id"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column(
            "tenant_id",
            sa.String(),
            sa.ForeignKey("tenants.id"),
            nullable=False,
            index=True,
        ),
        sa.Column("at", sa.DateTime(timezone=True), nullable=False),
        #: `decisions` or `audit_events`. The tool rebuilds either.
        sa.Column("table_name", sa.String(32), nullable=False),
        #: A person, named by whoever ran it. "The system did it" is not an
        #: answer to "who rewrote this".
        sa.Column("by_operator", sa.String(), nullable=False),
        sa.Column("reason", sa.Text(), nullable=False),
        #: Where the chain ended before. The field that lets an auditor
        #: reconcile an export taken before this against one taken after.
        sa.Column("tip_before", sa.String(64), nullable=False, server_default=""),
        sa.Column("tip_after", sa.String(64), nullable=False, server_default=""),
        sa.Column("rows_changed", sa.Integer(), nullable=False, server_default="0"),
    )

    op.execute(
        f"""
        CREATE TRIGGER {TABLE}_append_only
        BEFORE UPDATE OR DELETE ON {TABLE}
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )

    op.execute(f"ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY;")
    op.execute(f"ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY {TABLE}_tenant ON {TABLE}
        USING (tenant_id = current_setting('{SETTING}', true))
        WITH CHECK (tenant_id = current_setting('{SETTING}', true));
        """
    )

    # Readable by the application, so a firm can see that its own evidence was
    # rebuilt and why. Written only by the owner, which is the role the tool
    # already connects as — it has to be, since rebuilding requires disabling
    # the append-only trigger and only the table's owner can do that.
    op.execute(f"GRANT SELECT ON {TABLE} TO quolin_app;")
    op.execute(f"GRANT SELECT ON {TABLE} TO quolin_watch;")


def downgrade() -> None:
    raise NotImplementedError(
        "This is the record of somebody rewriting a firm's evidence hashes. "
        "Dropping the table removes the only thing distinguishing that from a "
        "tamper, which is not something a migration should offer to do on the "
        "strength of one mistyped command. Migrations 0001, 0028 and 0033 take "
        "the same position."
    )
