"""A sweep that reports what would change and records nothing.

Stage 5 gives a pinned tenant a window to check a new pack version against their
own book before it applies to them. §S8 says the delta report "powers the
pinned-tenant UAT flow" — and that only works if the report can be produced
*before* the tenant takes the version.

An ordinary sweep cannot do it. Recording determinations under a pack the tenant
has not adopted would put evidence in their chain that contradicts the version
they are actually on, which is the opposite of what pinning is for. So a dry run
evaluates exactly as a real sweep does — the same code path, so the two cannot
drift — and discards the determination, keeping only the outcome and the delta.

`against_version` records which version the question was about, because "what
would change" is meaningless without saying "compared to what".
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0019_dry_run_sweeps"
down_revision = "0018_bulk_evaluation"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "eval_runs",
        sa.Column("dry_run", sa.Boolean(), nullable=False, server_default=sa.text("false")),
    )
    op.add_column("eval_runs", sa.Column("against_version", sa.Integer(), nullable=True))


def downgrade() -> None:
    op.drop_column("eval_runs", "against_version")
    op.drop_column("eval_runs", "dry_run")
