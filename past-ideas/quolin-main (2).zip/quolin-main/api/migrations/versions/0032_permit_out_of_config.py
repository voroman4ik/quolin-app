"""The unreviewed-content permit, out of reach of anything serving a request.

`packs_repo` refuses unreviewed rule content to a firm that acts on its
determinations — the execution plan's rule that cannot be waived. There is one
exception, and it exists for an honest reason: the demonstration firm sits at
`full`, because otherwise its webhooks and referrals go quiet and the demo stops
being a demo, and it runs on the shipped illustrative content.

Q-11: that exception lived in `tenants.config`, and migration 0012 granted
`UPDATE (config)` to `quolin_app` so a firm could set its own advance policy
through the product. The grant is right and stays. What it also gave, and nobody
intended, was a request path to the single flag that lifts the one refusal that
matters most — reachable by any code path that rewrites `config`, today or the
one somebody writes next quarter.

So the permit gets a column of its own. Column-level grants are additive: a
column nobody has been granted `UPDATE` on cannot be written by `quolin_app`,
and no revoke is needed because no grant is made. The advance policy stays in
`config` where it belongs; the two were only ever in the same place by accident
of storage.

**Backfilled, then removed from `config`.** Carrying the value across matters —
the demonstration firm would otherwise start refusing on every screen. Removing
the key matters more: a migration that added a column and left the old key
readable would have moved the flag without closing the path, and
`_may_use_unreviewed` would still have honoured whatever a request wrote.
`tenants` is not append-only, so unlike migration 0025 this UPDATE is permitted.

The refusal itself is unchanged. What changes is who can lift it: an owner, by
migration or by a database session, and nothing that answers HTTP.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0032_permit_out_of_config"
down_revision = "0031_pack_identity_and_manifest"
branch_labels = None
depends_on = None

COLUMN = "illustrative_content_permitted"


def upgrade() -> None:
    op.add_column(
        "tenants",
        sa.Column(COLUMN, sa.Boolean(), nullable=False, server_default=sa.false()),
    )

    # Carried across rather than reset. A firm holding the permit today holds it
    # tomorrow; deciding otherwise is somebody's decision to make, not a
    # migration's.
    op.execute(
        f"""
        UPDATE tenants
        SET {COLUMN} = true
        WHERE COALESCE((config ->> '{COLUMN}')::boolean, false)
        """
    )

    # And the old key removed, so there is one answer to "may this firm decide
    # on unreviewed content" rather than two that can disagree.
    op.execute(f"UPDATE tenants SET config = config - '{COLUMN}'")

    # Said out loud, after the fact, so that the property this migration exists
    # for is a line a reviewer can point at rather than an absence to infer.
    # Column grants are additive: `quolin_app` holds UPDATE on `config` and
    # `stage` and on nothing else, so this column is already unwritable by it.
    op.execute(f"REVOKE UPDATE ({COLUMN}) ON tenants FROM quolin_app;")
    op.execute(f"GRANT SELECT ({COLUMN}) ON tenants TO quolin_app;")
    op.execute(f"GRANT SELECT ({COLUMN}) ON tenants TO quolin_watch;")


def downgrade() -> None:
    op.execute(
        f"""
        UPDATE tenants
        SET config = jsonb_set(COALESCE(config, '{{}}'::jsonb), '{{{COLUMN}}}', 'true')
        WHERE {COLUMN}
        """
    )
    op.drop_column("tenants", COLUMN)
