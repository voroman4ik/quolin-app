"""A firm's business day is measured on the firm's clock, not the container's.

FP3-05. Every business date in the application was `date.today()` — the
process's local calendar date, which on ECS is UTC. Timestamps were already
correct (`datetime.now(timezone.utc)`, fixed by Q-03); the business date was
never looked at.

For a Sydney firm the two disagree for ten hours of every day, which is most of
their working morning. Reproduced at 2026-08-27T23:30:00Z, 09:30 on the 28th in
Sydney: a determination asked for `as_of` 2026-08-28 was refused
`as_of_in_the_future`, the console's default recorded the 27th, and a pack
effective on the 28th did not begin governing that firm until 10:00 local.

Backfilled to `Australia/Sydney` for every existing row, confirmed against the
data rather than assumed: all fifteen tenants in the seeded database are
`ap-southeast-2`, which is the primary region and the reason the tenancy stage
chose it.

A column rather than a key in `config`. `config` is a firm's own settings —
`quolin_app` holds `UPDATE (config)` so a customer can change them — and which
clock their regulatory day is measured on is not something the customer's own
console should be able to move. Changing it retrospectively would shift which
pack version was in force for a day's determinations, so it is provisioning,
set by whoever sets the region.

Nullable, and empty means "derive it from the region". A firm whose hosting
region and business clock agree — which is all of them today — needs no value
here, and a column that had to be filled in correctly for every new tenant
would be a column that is eventually filled in wrongly.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0039_business_timezone"
down_revision = "0038_source_breaches"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "tenants", sa.Column("business_timezone", sa.String(), nullable=True)
    )
    # Every existing row, explicitly. Leaving them null would work — the region
    # fallback answers Australia/Sydney for all of them — but a value that was
    # true when this ran should be recorded as a value, so that changing the
    # region default later does not silently move the business day of a firm
    # that has been operating for a year.
    op.execute(
        "UPDATE tenants SET business_timezone = 'Australia/Sydney' "
        "WHERE business_timezone IS NULL AND region = 'ap-southeast-2';"
    )


def downgrade() -> None:
    op.drop_column("tenants", "business_timezone")
