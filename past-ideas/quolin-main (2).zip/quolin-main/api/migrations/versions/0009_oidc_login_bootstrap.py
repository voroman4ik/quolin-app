"""The read that lets an identity provider's assertion find its account

Revision ID: 0009_oidc_login_bootstrap
Revises: 0008_separation_of_duties
Created: 2026-08-24

0007 left `user_identities` readable only by the person it belongs to
(`user_id = app.user_id`) or by a firm that has granted that person a role. Both
are correct and both are useless to federated sign-in, which arrives holding an
issuer and a `sub` and knows neither the user nor the tenant — the row it cannot
see is the row that would tell it.

This is the same bootstrap `users` already has for the password path, where
`app.login_email` makes exactly one row readable for exactly one statement. The
policy here is the federated twin, and it is deliberately the narrowest thing
that works:

* **Read-only.** `WITH CHECK (false)` — the bootstrap can never write. Linking a
  provider subject to a person happens afterwards, under `app.user_id`, through
  the `user_identities_self` policy that already exists.
* **One provider.** Restricted to `provider = 'oidc'`, so the same settings can
  never be used to fish out a password hash. A password identity's `secret`
  column holds an Argon2 hash; there is no reason for this path to be able to
  read one, so it cannot.
* **Both halves required.** The predicate ANDs issuer and subject, and an unset
  setting is the empty string — which matches no row, rather than matching every
  row the way a NULL comparison would silently do.

**What this does not defend against, stated plainly.** As with the rest of the
identity tables, row-level security here is containment rather than the
authentication boundary: it means a SQL injection elsewhere cannot enumerate a
firm's federated accounts. The thing that stops an attacker asserting an
arbitrary `sub` is that `app.login_subject` is set in exactly one place, from a
JWT whose signature, issuer, audience, expiry and `nonce` were all checked
first — never from anything that arrived in a request.

No table is created for the login attempt itself. `state`, `nonce` and the PKCE
verifier live in a signed, short-lived cookie; `app/oidc.py` says why, and the
short version is that a login attempt grants nothing and expires in minutes, so
a table would buy revocability of something there is no reason to revoke.
"""

from __future__ import annotations

from alembic import op

revision = "0009_oidc_login_bootstrap"
down_revision = "0008_separation_of_duties"
branch_labels = None
depends_on = None

LOGIN_ISSUER_SETTING = "app.login_issuer"
LOGIN_SUBJECT_SETTING = "app.login_subject"


def upgrade() -> None:
    op.execute(
        f"""
        CREATE POLICY user_identity_login ON user_identities
        USING (
          provider = 'oidc'
          AND issuer = current_setting('{LOGIN_ISSUER_SETTING}', true)
          AND subject = current_setting('{LOGIN_SUBJECT_SETTING}', true)
        )
        WITH CHECK (false);
        """
    )


def downgrade() -> None:
    op.execute("DROP POLICY IF EXISTS user_identity_login ON user_identities;")
