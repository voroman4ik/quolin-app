"""The tables a customer's engineer connects to

Revision ID: 0010_integrations
Revises: 0009_oidc_login_bootstrap
Created: 2026-08-24

Stage 4 replaces the mocked edges with implementations a real integration can
use. Six tables, all tenant-scoped, all under the same fail-closed row-level
security as everything else — because every one of them holds a fact about one
customer, and several of them hold facts a competitor would pay for.

**`api_clients` is not `users`.** An OAuth2 client-credentials grant has no
person behind it: nobody typed a password and nobody can be asked what they
meant. Putting machines in the staff table would have put rows in the quarterly
access review that no reviewer could sensibly answer questions about, and would
have made "every action is attributable to a person" quietly false. Machine
actors get their own table, their own audit prefix, and a narrower set of roles.

**`idempotency_keys` protects an append-only chain from a retrying client.**
Integrations retry — a dropped response, a redelivered queue message, an
engineer running a script twice. Without a key, each of those writes a second
determination into evidence that cannot be tidied up afterwards. The stored
response is returned verbatim rather than the request re-executed, because
re-executing produces a different decision id and a different hash, which is
precisely what the caller sent the key to avoid.

**`webhook_deliveries` is deliberately not append-only**, unlike the evidence
tables. A delivery is retried, and its attempt count and status change as it is
— which is the one thing an append-only table cannot express. It is operational
rather than evidential: what it says about a decision is not what makes that
decision true. `scripts/lint_migrations.sh` guards the append-only set and this
table is correctly outside it.

**`integr_mappings` is versioned because a mapping change can change
determinations.** If a customer's `risk_band` stops meaning `loss_capacity_band`
and starts meaning something else, every decision after that is made on
different facts. Explaining a determination made last March requires knowing
which mapping was in force when it was made, so the version is recorded on the
run that used it rather than inferred from dates.

**Secrets.** `api_clients.secret_hash` is Argon2id — the secret is shown once at
creation and there is nothing to recover it from. `webhook_endpoints.secret` is
encrypted rather than hashed, because it is signing material that has to be
usable: the same bytes sign every payload. Both choices are the opposite of each
other and both are right for what they hold.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0010_integrations"
down_revision = "0009_oidc_login_bootstrap"
branch_labels = None
depends_on = None

TENANT_FK = "tenants.id"
POLICY = "tenant_isolation"
SETTING = "app.tenant_id"

NEW_TABLES = (
    "api_clients",
    "idempotency_keys",
    "webhook_endpoints",
    "webhook_deliveries",
    "integr_mappings",
    "import_runs",
)


def _tenant_column() -> sa.Column:
    return sa.Column("tenant_id", sa.String(), sa.ForeignKey(TENANT_FK), nullable=False)


def upgrade() -> None:
    op.create_table(
        "api_clients",
        sa.Column("id", sa.String(), primary_key=True),
        _tenant_column(),
        sa.Column("label", sa.String(), nullable=False),
        sa.Column("secret_hash", sa.Text(), nullable=False),
        sa.Column("roles", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("status", sa.String(), nullable=False, server_default="active"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_by", sa.String(), nullable=True),
        sa.Column("last_used_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_api_clients_tenant_id", "api_clients", ["tenant_id"])
    op.create_index("ix_api_clients_status", "api_clients", ["status"])

    op.create_table(
        "idempotency_keys",
        sa.Column("key", sa.String(), primary_key=True),
        _tenant_column(),
        sa.Column("endpoint", sa.String(), nullable=False),
        sa.Column("request_hash", sa.String(), nullable=False),
        sa.Column("status_code", sa.Integer(), nullable=False),
        sa.Column("response", postgresql.JSONB(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_idempotency_keys_tenant_id", "idempotency_keys", ["tenant_id"])
    # Swept by age rather than kept forever: a key is only useful for as long as
    # a client might retry, and an unbounded table of every write ever made is a
    # second copy of the decision history with none of its guarantees.
    op.create_index("ix_idempotency_keys_created_at", "idempotency_keys", ["created_at"])

    op.create_table(
        "webhook_endpoints",
        sa.Column("id", sa.String(), primary_key=True),
        _tenant_column(),
        sa.Column("url", sa.String(), nullable=False),
        sa.Column("label", sa.String(), nullable=False, server_default=""),
        sa.Column("secret", sa.LargeBinary(), nullable=False),
        sa.Column("events", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("status", sa.String(), nullable=False, server_default="active"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_webhook_endpoints_tenant_id", "webhook_endpoints", ["tenant_id"])
    op.create_index("ix_webhook_endpoints_status", "webhook_endpoints", ["status"])

    op.create_table(
        "webhook_deliveries",
        sa.Column("id", sa.String(), primary_key=True),
        _tenant_column(),
        sa.Column(
            "endpoint_id",
            sa.String(),
            sa.ForeignKey("webhook_endpoints.id"),
            nullable=False,
        ),
        sa.Column("event", sa.String(), nullable=False),
        sa.Column("subject", sa.String(), nullable=False),
        sa.Column("payload", postgresql.JSONB(), nullable=False),
        sa.Column("status", sa.String(), nullable=False, server_default="pending"),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("last_status_code", sa.Integer(), nullable=True),
        sa.Column("last_error", sa.Text(), nullable=False, server_default=""),
        sa.Column("next_attempt_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("delivered_at", sa.DateTime(timezone=True), nullable=True),
    )
    for column in ("tenant_id", "endpoint_id", "event", "status", "next_attempt_at"):
        op.create_index(
            f"ix_webhook_deliveries_{column}", "webhook_deliveries", [column]
        )

    op.create_table(
        "integr_mappings",
        sa.Column("id", sa.String(), primary_key=True),
        _tenant_column(),
        sa.Column("source", sa.String(), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("fields", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("effective_from", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_by", sa.String(), nullable=True),
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
        # One version of one source per tenant. A second row claiming version 3
        # of the client mapping would make "which mapping was in force" a
        # question with two answers, which is the one thing this table exists to
        # prevent.
        sa.UniqueConstraint(
            "tenant_id", "source", "version", name="integr_mappings_version_key"
        ),
    )
    op.create_index("ix_integr_mappings_tenant_id", "integr_mappings", ["tenant_id"])
    op.create_index("ix_integr_mappings_source", "integr_mappings", ["source"])

    op.create_table(
        "import_runs",
        sa.Column("id", sa.String(), primary_key=True),
        _tenant_column(),
        sa.Column("channel", sa.String(), nullable=False),
        sa.Column("source", sa.String(), nullable=False, server_default="clients"),
        sa.Column("filename", sa.String(), nullable=False, server_default=""),
        sa.Column("content_hash", sa.String(), nullable=False),
        sa.Column("status", sa.String(), nullable=False, server_default="pending"),
        sa.Column("rows_total", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("rows_written", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("errors", postgresql.JSONB(), nullable=False, server_default="[]"),
        sa.Column("mapping_version", sa.Integer(), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("started_by", sa.String(), nullable=True),
    )
    for column in ("tenant_id", "channel", "content_hash", "status"):
        op.create_index(f"ix_import_runs_{column}", "import_runs", [column])

    # Fail-closed row-level security, exactly as migration 0003 applied it to
    # the tables that existed then. FORCE as well as ENABLE, so that even the
    # owning role is filtered: a policy the owner bypasses is a policy that is
    # off in every environment where anybody runs a script.
    for table in NEW_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;")
        op.execute(
            f"""
            CREATE POLICY {POLICY} ON {table}
            USING (tenant_id = current_setting('{SETTING}', true))
            WITH CHECK (tenant_id = current_setting('{SETTING}', true));
            """
        )

    # The application role's grants come from the default privileges migration
    # 0001 set, which cover tables created later. Stated rather than assumed
    # because a table the app cannot read fails at the first request rather than
    # at deploy, and the next person should not have to rediscover why.
    op.execute(
        "GRANT SELECT, INSERT, UPDATE, DELETE ON "
        + ", ".join(NEW_TABLES)
        + " TO quolin_app;"
    )


def downgrade() -> None:
    for table in NEW_TABLES:
        op.execute(f"DROP POLICY IF EXISTS {POLICY} ON {table};")
        op.execute(f"ALTER TABLE {table} NO FORCE ROW LEVEL SECURITY;")
        op.execute(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY;")
    for table in reversed(NEW_TABLES):
        op.drop_table(table)
