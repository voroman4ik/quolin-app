"""The number a sale closes on becomes evidence rather than a running total.

FP3-23, reproduced. `comparison.ingest` did

    existing.outcome = mapped
    existing.outcome_raw = raw
    existing.source = source

when a (client, asset, as_of) triplet already had a row, and `incumbent_outcomes`
carried no append-only trigger and no revoked grants. So the customer's recorded
answer for a given pair on a given day could be overwritten in place, by the
application role, with nothing anywhere recording that it had changed.

**Why that is worth a migration rather than a note.** §S10's whole value is the
sentence "we agree with you 97% of the time, and here are the 3%". That number
is what a shadow-mode engagement converts on. An operator who could edit the
incumbent's side of the comparison could move the agreement rate in either
direction — up to close a sale, or down to argue a divergence was theirs — and
every other number in this system is chained specifically so that this cannot be
done to it. This one was not.

Invariant 4 does not say "evidence of determinations is append-only", it says
evidence is. What the customer's own system said about a client is a fact about
the world on a date, and re-stating it is a new observation rather than a
correction to the old one.

**Supersession rather than refusal.** A firm genuinely does re-send a corrected
file, and refusing the second one would mean the comparison silently reports
last week's answer. So a new row is written and the old one is kept, and every
reader takes the newest row per (client, asset, as_of) — which is the same shape
`packs` uses for rule content and `source_breaches` for outages.

The existing rows are left exactly as they are. They were written under the old
rule and rewriting them to fit the new one would be the finding.
"""

from __future__ import annotations

from alembic import op

revision = "0042_incumbent_append_only"
down_revision = "0041_artefacts_append_only"
branch_labels = None
depends_on = None

TABLE = "incumbent_outcomes"


def upgrade() -> None:
    # 0021's unique index has to go, and it is worth saying what it was for.
    #
    #   One answer per pair per date. A re-sent extract corrects the row it
    #   replaces rather than adding a second opinion nobody can choose between.
    #
    # That reasoning is sound about the *reader's* problem and it solved it by
    # making the writer destructive. "Nobody can choose between them" is
    # answered by choosing — the newest row wins, which is the same rule
    # `packs_repo` applies to rule content — and the price of solving it with a
    # unique index was that the customer's earlier answer had to be destroyed to
    # record their later one.
    op.drop_index("ix_incumbent_one_per_pair", table_name=TABLE)

    # The newest row per pair, which is the query every reader now makes.
    op.create_index(
        "ix_incumbent_outcomes_supersession",
        TABLE,
        ["tenant_id", "client_id", "asset_id", "as_of", "id"],
    )

    op.execute(
        f"""
        CREATE TRIGGER {TABLE}_append_only
        BEFORE UPDATE OR DELETE ON {TABLE}
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )
    # Both locks. 0001's default privileges granted all four on this table when
    # it was created, and nothing revoked them — which is FP3-10's shape again,
    # in the one place where the consequence is a metric somebody sells on.
    op.execute(f"REVOKE UPDATE, DELETE, TRUNCATE ON {TABLE} FROM quolin_app;")
    op.execute(f"REVOKE UPDATE, DELETE, TRUNCATE ON {TABLE} FROM quolin_watch;")


def downgrade() -> None:
    raise NotImplementedError(
        "Reversing this makes the incumbent's side of the shadow-mode "
        "comparison editable in place again — the agreement rate a firm signs "
        "on the strength of, movable by whoever holds the application role, "
        "with no chain alarm. If it genuinely has to be mutable, that is a "
        "forward migration somebody signs."
    )
