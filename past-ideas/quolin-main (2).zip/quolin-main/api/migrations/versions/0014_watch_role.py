"""The watch service's own database role, with no way to write a pack.

§S6: "watch runs as its own service with a DB role that has no write grant on
`packs` — the only publish path is the signature endpoint in core-api. The
existing guard script becomes a deployment fact."

Until now that separation was structural but not enforced by anything outside
the code: `scripts/guard_no_watch_in_engine.sh` fails CI if a watch module
constructs a pack row, and `watch/drafts.py::publish` refuses an unsigned draft.
Both are good. Neither survives somebody with a shell and a reason to hurry.

This migration makes the claim a property of the database. `quolin_watch` can
read packs and cannot write them — not "does not", *cannot*: the INSERT, UPDATE
and DELETE privileges are not granted, so the statement is refused by Postgres
before any application code is consulted. A watch process compromised end to end
still cannot put rule content in front of a client.

What it *can* do is exactly the job:

  watch_sources, watch_events   full read and write — this is its own workflow
  pack_drafts                   read and write, because proposing a change is
                                the whole point. A draft is inert: nothing in
                                the evaluator reads this table.
  pack_draft_transitions        INSERT and SELECT only, matching the append-only
                                trigger that governs it for everybody else
  audit_events                  INSERT and SELECT, so a sweep can say what it did
  packs, tenants, users, …      SELECT only

**Not BYPASSRLS, not a superuser, not the table owner.** Each of those three
attributes turns every row-level security policy into a comment, which is the
note migration 0001 makes about `quolin_app` and it is no less true here.

**Created NOLOGIN and without a password**, like `quolin_app`. A password in a
committed migration is a password in every clone of the repository; the seed
grants a dev one, and production's comes from Secrets Manager.
"""

from __future__ import annotations

from alembic import op

revision = "0014_watch_role"
down_revision = "0013_source_slas"
branch_labels = None
depends_on = None

ROLE = "quolin_watch"

#: Tables the watch service owns outright.
OWN_TABLES = ("watch_sources", "watch_events", "pack_drafts")

#: Append-only for everybody. INSERT and SELECT, never UPDATE or DELETE — the
#: same shape the trigger enforces, stated a second time as a grant so that
#: dropping one does not silently remove the other.
APPEND_ONLY = ("pack_draft_transitions", "audit_events")


def upgrade() -> None:
    op.execute(
        f"""
        DO $$
        BEGIN
          IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{ROLE}') THEN
            CREATE ROLE {ROLE} NOLOGIN;
          END IF;
        END
        $$;
        """
    )

    # Start from nothing. Additive grants on a role that might already exist in
    # a long-lived environment would leave whatever it had before.
    op.execute(f"REVOKE ALL ON SCHEMA public FROM {ROLE};")
    op.execute(f"REVOKE ALL ON ALL TABLES IN SCHEMA public FROM {ROLE};")
    op.execute(f"REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM {ROLE};")

    op.execute(f"GRANT USAGE ON SCHEMA public TO {ROLE};")
    # Read everything: triage compares publications against pack content, and
    # the currency screen reads tenants and packs. Reading is not the risk.
    op.execute(f"GRANT SELECT ON ALL TABLES IN SCHEMA public TO {ROLE};")

    for table in OWN_TABLES:
        op.execute(f"GRANT INSERT, UPDATE, DELETE ON {table} TO {ROLE};")
    for table in APPEND_ONLY:
        op.execute(f"GRANT INSERT ON {table} TO {ROLE};")

    op.execute(f"GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO {ROLE};")
    # A table added by a later migration must not silently become writable by
    # this role. SELECT only, by default; anything more is a deliberate grant in
    # the migration that adds the table, which is a line a reviewer will see.
    op.execute(
        f"ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO {ROLE};"
    )
    op.execute(
        f"ALTER DEFAULT PRIVILEGES IN SCHEMA public "
        f"GRANT USAGE, SELECT ON SEQUENCES TO {ROLE};"
    )

    # Said explicitly, after everything else, so that the one privilege this
    # whole migration exists to withhold is a line somebody can point at in a
    # diligence review rather than an absence they have to infer.
    op.execute(f"REVOKE INSERT, UPDATE, DELETE ON packs FROM {ROLE};")
    op.execute(f"REVOKE INSERT, UPDATE, DELETE ON tenants FROM {ROLE};")
    op.execute(f"REVOKE INSERT, UPDATE, DELETE ON users FROM {ROLE};")
    op.execute(f"REVOKE INSERT, UPDATE, DELETE ON user_roles FROM {ROLE};")
    op.execute(f"REVOKE INSERT, UPDATE, DELETE ON decisions FROM {ROLE};")


def downgrade() -> None:
    op.execute(f"REVOKE ALL ON SCHEMA public FROM {ROLE};")
    op.execute(f"REVOKE ALL ON ALL TABLES IN SCHEMA public FROM {ROLE};")
    op.execute(f"REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM {ROLE};")
    op.execute(f"ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE SELECT ON TABLES FROM {ROLE};")
    op.execute(
        f"ALTER DEFAULT PRIVILEGES IN SCHEMA public "
        f"REVOKE USAGE, SELECT ON SEQUENCES FROM {ROLE};"
    )
    # The role itself is left in place. Dropping a role that owns nothing is
    # harmless, but it is also the kind of statement that fails on one
    # environment and not another depending on what has been granted to it
    # elsewhere, and a downgrade that half-runs is worse than one that leaves a
    # role with no privileges behind.
