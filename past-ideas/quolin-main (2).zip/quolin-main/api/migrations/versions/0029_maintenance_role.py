"""Tenant enumeration that does not depend on what kind of role is connecting.

Every scheduled job in `scripts/` begins by listing the active firms and then
binds each one in turn. That first step runs through `OwnerSessionLocal` with no
tenant bound, and migration 0003 put `FORCE ROW LEVEL SECURITY` on `tenants`
with a policy of `id = current_setting('app.tenant_id', true)`. With no tenant
bound the setting is the empty string, which matches no row.

In development nothing goes wrong, because the owner is a superuser and holds
BYPASSRLS, and either attribute makes the policy inert. Migration 0003 says so
itself: *"What it cannot cover is a superuser or a role with BYPASSRLS."* An RDS
master account — which is what `infra/` provisions — holds neither. On that
database every worker would enumerate nothing, do nothing, print a summary and
exit 0. `scripts/health_alerts.py`, the §S9 paging path, would report all-clear
for as long as the deployment lived.

The fix is to stop the enumeration resting on a role *attribute* and rest it on
a role *grant* instead.

`quolin_maintenance` is a NOLOGIN role that owns nothing and holds no privilege
of its own. Its only purpose is to be a thing a connection can be a member of,
and the policy on `tenants` gains one additional clause admitting members. The
schema owner is granted it here, by migration, so that the account which runs
migrations — the same account the workers connect as — is admitted on any
database this has been applied to, RDS included.

Two things this deliberately is not.

**Not a setting.** An `app.maintenance` GUC would have been fewer lines, and any
connection that can call `set_config` could then have set it — including
`quolin_app`, which serves HTTP. The whole point of the policy on `tenants` is
that a request cannot list the platform's customers by name. Role membership
cannot be assumed at runtime by a role that was not granted it.

**Not a widening of the application role.** `quolin_app` and `quolin_watch` are
not members and are not granted membership here. `tests/test_worker_tenant_
enumeration.py` asserts both, by asking Postgres rather than by reading this.

`worker_heartbeats` arrives in the same migration because it is the same
finding. A monitor that is silent because all is well and one that is silent
because it never ran look identical from outside, and that is exactly the state
this migration exists to end. Each run writes the row for its worker, so the
absence or staleness of a heartbeat is itself an observable fact.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0029_maintenance_role"
down_revision = "0028_source_verifications"
branch_labels = None
depends_on = None

ROLE = "quolin_maintenance"
POLICY = "tenant_isolation"
SETTING = "app.tenant_id"

#: The roles that must *not* gain the grant, said out loud so that a future
#: migration adding a role has to decide rather than default.
EXCLUDED = ("quolin_app", "quolin_watch")


def upgrade() -> None:
    op.execute(
        f"""
        DO $$
        BEGIN
          IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{ROLE}') THEN
            CREATE ROLE {ROLE} NOLOGIN;
          END IF;
        END
        $$;
        """
    )

    # The account applying this migration is the account the workers connect
    # as: both come from DATABASE_URL. Granting to `current_user` rather than to
    # a name written here means this works on a database whose master account is
    # called something other than `quolin`, which every hosted one will be.
    op.execute(f"GRANT {ROLE} TO current_user;")

    # Explicit, and after the grant, so that the one thing this must not do is
    # a line a reviewer can point at rather than an absence to be inferred.
    for role in EXCLUDED:
        op.execute(
            f"""
            DO $$
            BEGIN
              IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{role}') THEN
                EXECUTE 'REVOKE {ROLE} FROM {role}';
              END IF;
            END
            $$;
            """
        )

    # The policy gains a second way in and loses none of the first. A firm's own
    # connection still sees exactly its own row; a member of the maintenance
    # role sees the list. `USING` only — `WITH CHECK` is left as it was, because
    # enumerating firms is a read and nothing here needs to write one.
    op.execute(f"DROP POLICY {POLICY} ON tenants;")
    op.execute(
        f"""
        CREATE POLICY {POLICY} ON tenants
        USING (
          id = current_setting('{SETTING}', true)
          OR pg_has_role(current_user, '{ROLE}', 'USAGE')
        );
        """
    )

    # A scheduled job's own pulse. Not tenant-scoped: it is a fact about a
    # process on the platform, not about a customer, and the worker that writes
    # it is between tenants when it does.
    op.create_table(
        "worker_heartbeats",
        sa.Column("worker", sa.String(64), primary_key=True),
        sa.Column("ran_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("tenants_seen", sa.Integer(), nullable=False),
        sa.Column("outcome", sa.String(32), nullable=False),
        sa.Column("detail", sa.Text(), nullable=False, server_default=""),
    )
    # Readable by everything, writable by the roles that run jobs. `quolin_app`
    # gets SELECT so the status page can report a stale monitor; it has no
    # reason to write one.
    op.execute("GRANT SELECT ON worker_heartbeats TO quolin_app;")
    op.execute("GRANT SELECT ON worker_heartbeats TO quolin_watch;")


def downgrade() -> None:
    op.drop_table("worker_heartbeats")
    op.execute(f"DROP POLICY {POLICY} ON tenants;")
    op.execute(
        f"""
        CREATE POLICY {POLICY} ON tenants
        USING (id = current_setting('{SETTING}', true));
        """
    )
    # The role is left in place, for the reason migration 0014 gives: dropping a
    # role that may have been granted elsewhere fails on one environment and not
    # another, and a downgrade that half-runs is worse than one that leaves an
    # unprivileged role behind.
