"""One evidence chain per tenant, each with its own recorded start

Revision ID: 0004_chain_anchors
Revises: 0003_rls
Created: 2026-08-23

Migration 0003 made every query tenant-filtered, and in doing so it broke the
evidence chain — not by damaging a row, but by making the old shape incoherent.

The chain was global: decision N's hash covers decision N-1's hash, in id
order, across the whole table. That was correct when there was one customer.
With two, customer B's chain threads through rows belonging to customer A, and
customer B cannot see those rows. `verify_chain` would walk B's decisions, find
a `prev_hash` naming a record it has no row for, and report the chain broken.
It would be right to. A guarantee that reports itself broken under normal
operation is not a guarantee; it is an alarm nobody will keep answering.

So the chain becomes per tenant, which needs a per-tenant start. `chain_anchors`
holds it: one row per customer, recording the hash their chain begins at and
the moment it began. The reasoning for storing it rather than deriving it from
the tenant id is on the model (`app/models.py::ChainAnchor`) — briefly, a
derived start has no moment in it, and a tenant deleted and recreated under the
same slug would silently inherit the closed account's chain identity.

**This migration does not rewrite existing hashes, and on a database with
decisions already in it that leaves the chain reporting broken until
`make rechain` has run.** That is deliberate and it is the smaller of two
evils. Recomputing a decision hash means reproducing the exact payload the
engine hashes — ten fields, canonical JSON, the resolution block — and a
migration is a frozen snapshot that must never be edited again, so the copy it
made would drift from the live calculation the first time a field was added,
and would then be silently wrong for every database restored after that. The
recomputation belongs in one place, calling the live code:
`scripts/rechain.py`. `docs/deployment.md` lists it as the step after this
migration; dev does not need it because `make seed` starts from an empty table
with the anchors already in place.
"""

from __future__ import annotations

import hashlib
import json

import sqlalchemy as sa
from alembic import op

revision = "0004_chain_anchors"
down_revision = "0003_rls"
branch_labels = None
depends_on = None

#: Sixty-four zeroes — what every chain used to start at, and what an anchor's
#: own hash is computed against. Duplicated from `app.canonical` rather than
#: imported, like every other constant in these files: a migration is a record
#: of what was done, and importing from a package that keeps changing turns it
#: into a record of what the package says today.
GENESIS = "0" * 64

SETTING = "app.tenant_id"
POLICY = "tenant_isolation"


def _genesis_hash(tenant_id: str, created_at: str) -> str:
    """`chain_hash(GENESIS, {"created_at": ..., "tenant_id": ...})`, inlined.

    Two keys and a sha256, which is small enough to reproduce here safely — and
    unlike the decision payload it is fixed forever, because an anchor has no
    fields to grow. `app.evidence.genesis_hash` is the live copy;
    `tests/test_chain_anchors.py` asserts the two agree, so the duplication is
    checked rather than trusted.
    """
    row = json.dumps(
        {"created_at": created_at, "tenant_id": tenant_id},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256((GENESIS + row).encode("utf-8")).hexdigest()


def upgrade() -> None:
    op.create_table(
        "chain_anchors",
        sa.Column("tenant_id", sa.String(), nullable=False),
        sa.Column("genesis_hash", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("tenant_id"),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
    )

    # An anchor for every tenant that already exists. Anchors for tenants
    # created later are written when the tenant is — see
    # `app.evidence.ensure_anchor`, which the seed calls and which a future
    # provisioning path will call too. There is no lazy creation on read: a
    # chain whose start appears the first time somebody verifies it is a chain
    # whose start is whatever was convenient at that moment.
    bind = op.get_bind()
    tenants = bind.execute(sa.text("SELECT id, created_at FROM tenants")).fetchall()
    for tenant_id, created_at in tenants:
        stamp = created_at.isoformat()
        bind.execute(
            sa.text(
                "INSERT INTO chain_anchors (tenant_id, genesis_hash, created_at) "
                "VALUES (:id, :hash, :created_at) ON CONFLICT (tenant_id) DO NOTHING"
            ),
            {"id": tenant_id, "hash": _genesis_hash(tenant_id, stamp), "created_at": created_at},
        )

    # An anchor is evidence in the strictest sense: rewriting one rewrites the
    # meaning of every hash beneath it. So it gets both locks the decisions
    # themselves get — the trigger from the baseline, and the revoked grants.
    op.execute(
        """
        CREATE TRIGGER chain_anchors_append_only
        BEFORE UPDATE OR DELETE ON chain_anchors
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )
    op.execute("REVOKE UPDATE, DELETE ON chain_anchors FROM quolin_app;")

    op.execute("ALTER TABLE chain_anchors ENABLE ROW LEVEL SECURITY;")
    op.execute("ALTER TABLE chain_anchors FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY {POLICY} ON chain_anchors
        USING (tenant_id = current_setting('{SETTING}', true))
        WITH CHECK (tenant_id = current_setting('{SETTING}', true));
        """
    )


def downgrade() -> None:
    raise NotImplementedError(
        "Anchors are the roots of every tenant's evidence chain. Dropping this "
        "table would leave every stored hash computed against a start that no "
        "longer exists, and no chain could ever verify again — the records "
        "would still be there and would be permanently unprovable. Recovering "
        "from that means re-chaining from a new anchor, which is a decision an "
        "operator makes with `scripts/rechain.py`, not something a mistyped "
        "`alembic downgrade` does on their behalf."
    )
