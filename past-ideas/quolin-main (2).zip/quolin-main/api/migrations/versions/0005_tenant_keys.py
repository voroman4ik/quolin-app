"""Per-tenant data keys, and somewhere to put the ciphertext

Revision ID: 0005_tenant_keys
Revises: 0004_chain_anchors
Created: 2026-08-23

Row-level security answers "can customer A read customer B's rows". It says
nothing about anyone holding the whole database — a restored backup, a copied
volume, a support session with a psql prompt. Encryption at rest answers that
second question, and it is asked before the first one in every diligence pack a
bank sends.

This migration is pure schema. It creates `tenant_keys`, and it adds the
columns the ciphertext will live in. It generates no keys and moves no data,
and that is deliberate: both of those need the master key and the live
envelope in `app/crypto.py`, and a migration is a frozen snapshot that must
never be edited again. A copy of the encryption made here would drift from the
one the application uses the first time the envelope changed, and would then be
silently wrong for every database restored after that. Key creation lives in
`crypto.ensure_key`, which the seed calls; the move of existing rows lives in
`scripts/encrypt_existing.py`, which `0006` refuses to run ahead of.

**Why the plaintext columns are still here afterwards.** `decisions` is
append-only, enforced by a trigger and by revoked grants, so nothing can
rewrite a stored snapshot in place — including this. Turning existing rows into
ciphertext means suspending that guarantee deliberately, as an operator, with
the act recorded; that is what `scripts/rechain.py` already established for the
one other operation of this kind, and this follows it rather than inventing a
second way. So: this migration adds columns beside the old ones, the script
fills them, and `0006` drops what is left.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0005_tenant_keys"
down_revision = "0004_chain_anchors"
branch_labels = None
depends_on = None

SETTING = "app.tenant_id"
POLICY = "tenant_isolation"

#: table -> the columns that become ciphertext. Read by `0006` and by
#: `scripts/encrypt_existing.py`, which is why it is a declaration rather than
#: four repeated statements: three copies of this list is three chances for one
#: of them to be missing a column, and the column it is missing is the one that
#: stays in plaintext.
ENCRYPTED_COLUMNS = {
    "clients": ("name", "dob", "note"),
    "decisions": ("snapshot",),
}

#: The suffix the ciphertext column carries until `0006` renames it into place.
CIPHER = "_cipher"


def upgrade() -> None:
    op.create_table(
        "tenant_keys",
        sa.Column("tenant_id", sa.String(), nullable=False),
        sa.Column("wrapped_key", sa.LargeBinary(), nullable=False),
        sa.Column("rewraps", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("rewrapped_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("tenant_id"),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
    )

    # The outer lock only, and no trigger. `tenant_keys` is the one tenant-scoped
    # table that is not append-only, because rotation rewraps this row in place
    # and a table that refused UPDATE would make the only key operation the
    # system has impossible to perform. The rewrap is an owner operation
    # (`scripts/rotate_keys.py`), so the application keeps no way to reach it.
    #
    # INSERT stays. The primary key means an insert can only ever create a key
    # for a tenant that has none, which is provisioning; there is no insert that
    # replaces a key, and therefore none that destroys data.
    op.execute("REVOKE UPDATE, DELETE ON tenant_keys FROM quolin_app;")

    op.execute("ALTER TABLE tenant_keys ENABLE ROW LEVEL SECURITY;")
    op.execute("ALTER TABLE tenant_keys FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY {POLICY} ON tenant_keys
        USING (tenant_id = current_setting('{SETTING}', true))
        WITH CHECK (tenant_id = current_setting('{SETTING}', true));
        """
    )

    # Nullable, because on a database that already holds rows there is nothing
    # to put in them yet. `0006` makes them NOT NULL once there is.
    for table, columns in ENCRYPTED_COLUMNS.items():
        for column in columns:
            op.add_column(
                table, sa.Column(f"{column}{CIPHER}", sa.LargeBinary(), nullable=True)
            )


def downgrade() -> None:
    raise NotImplementedError(
        "`tenant_keys` holds the only copy of every customer's wrapped data "
        "key. Dropping the table destroys the ability to read every snapshot "
        "and every client name ever encrypted under it, in the live database "
        "and in every backup already taken — the rows would still be there and "
        "would be permanently undecryptable. There is no automated way back "
        "from that, and there should not be one behind a mistyped `alembic "
        "downgrade`. Reversing encryption means decrypting to plaintext columns "
        "first, deliberately, with the keys still present."
    )
