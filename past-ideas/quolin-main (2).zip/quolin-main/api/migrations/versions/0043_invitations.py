"""A real customer can obtain a password.

FP3-11. `identity.set_password` was called by two things: `api/seed/seed.py` and
`scripts/load_model.py`. `POST /admin/users` creates, in its own docstring, "a
person, created with no way to sign in yet" — and there was no invite route, no
set-password route and no reset route. OIDC does not provision either.

So the first customer's first user could be created and could never sign in. The
only way anybody has a password today is that the seed gave them one, which
works for a demo and is not a product.

**A single-use, expiring, hashed token.** Hashed for the reason session tokens
are: this table is readable by the application role, and a table of live
credentials in plaintext is a worse problem than the one it solves. Single-use
because an invite link sits in an inbox for ever and a mailbox is not a vault.

`consumed_at` rather than a delete, so "this invitation was used, on this date"
survives the account existing — an access review asking how somebody came to
have a credential gets an answer, which is the same question `granted_by`
answers for roles.

The same mechanism serves password resets. A reset is an invitation to choose a
credential, issued to somebody who already has an account; making it a second
table would mean two implementations of one security-sensitive thing, and the
second one is always the one nobody looks at.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0043_invitations"
down_revision = "0042_incumbent_append_only"
branch_labels = None
depends_on = None

TABLE = "invitations"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("tenant_id", sa.String(), nullable=False),
        sa.Column("user_id", sa.String(), nullable=False),
        #: SHA-256 of the token. The token itself is returned once, to the
        #: administrator who created it, and is never stored.
        sa.Column("token_hash", sa.String(), nullable=False),
        #: `invite` or `reset`. The mechanism is identical; the word is what the
        #: audit trail and the screen say.
        sa.Column("kind", sa.String(), nullable=False, server_default="invite"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("created_by", sa.String(), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("consumed_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.UniqueConstraint("token_hash", name="uq_invitation_token"),
    )
    op.create_index("ix_invitations_user_id", TABLE, ["user_id"])
    op.create_index("ix_invitations_expires_at", TABLE, ["expires_at"])

    # Tenant-scoped like every other per-firm record. An invitation names a
    # person at a firm, and which firm is issuing credentials to whom is that
    # firm's business.
    op.execute(f"ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY;")
    op.execute(f"ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY tenant_isolation ON {TABLE}
        USING (tenant_id = current_setting('app.tenant_id', true))
        WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
        """
    )

    # **Not append-only**, and the reason is worth stating rather than leaving
    # to be noticed. Consuming an invitation sets `consumed_at` on the row that
    # was issued, and that update is the whole single-use property — a design
    # where it were a second appended row would mean the check for "already
    # used" is a query somebody has to remember to write, instead of a column
    # the consuming statement itself sets.
    #
    # What is protected is that the *record* cannot be erased: DELETE is
    # revoked, so an invitation that was used cannot be made to look as though
    # it never existed.
    op.execute(f"REVOKE DELETE, TRUNCATE ON {TABLE} FROM quolin_app;")
    op.execute(f"REVOKE ALL ON {TABLE} FROM quolin_watch;")


def downgrade() -> None:
    raise NotImplementedError(
        "This is the record of how every person came to hold a credential. An "
        "access review asking 'who authorised this account, and when did they "
        "choose their password' reads it. Dropping the table removes the answer."
    )
