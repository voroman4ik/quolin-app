"""What happened *to* the system: failed sign-ins, and denials.

§S9 asks for alerting on auth anomalies and row-level-security denials. Neither
had anywhere to be recorded. A failed sign-in calls the rate limiter and returns
401; nothing durable remembers it, so "alert on auth anomalies" had nothing to
read.

`audit_events` is the wrong home. An audit row names the person who acted, and
the whole point of a failed sign-in is that nobody proved who they were — Stage
2 refuses an unattributed audit row and should keep refusing. So this is a
separate table rather than a weakening of that rule.

Append-only, like the rest of the evidence: this is what somebody reads after an
incident, and a record that can be edited afterwards answers a different
question.

**No email addresses.** A failed attempt names the account when it resolves to
one and says `unknown account` when it does not. A table of addresses people
typed at a login form is a list of who might have an account here — precisely
what an attacker would like and what the rest of this schema takes trouble to
encrypt.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0020_security_events"
down_revision = "0019_dry_run_sweeps"
branch_labels = None
depends_on = None

TABLE = "security_events"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column(
            "tenant_id",
            sa.String(),
            sa.ForeignKey("tenants.id"),
            nullable=False,
            index=True,
        ),
        sa.Column("kind", sa.String(), nullable=False, index=True),
        sa.Column("user_id", sa.String(), nullable=True, index=True),
        sa.Column("source_ip", sa.String(), nullable=False, server_default=""),
        sa.Column("detail", sa.Text(), nullable=False, server_default=""),
        sa.Column(
            "at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
            index=True,
        ),
    )

    op.execute(
        f"""
        CREATE TRIGGER {TABLE}_append_only
        BEFORE UPDATE OR DELETE ON {TABLE}
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )
    op.execute(f"REVOKE UPDATE, DELETE ON {TABLE} FROM quolin_app;")

    op.execute(f"ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY;")
    op.execute(f"ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY {TABLE}_tenant ON {TABLE}
        USING (tenant_id = current_setting('app.tenant_id', true))
        WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
        """
    )


def downgrade() -> None:
    raise NotImplementedError(
        "This table is append-only security evidence: failed sign-ins and "
        "denials, which is what somebody reads after an incident. Dropping it "
        "means dropping that record, which is not a thing a migration should "
        "offer to do on the strength of one mistyped command. Migration 0001 "
        "takes the same position."
    )
