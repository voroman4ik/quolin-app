"""The artefact queue: a table, because Postgres is already a queue.

§S7: "artefact rendering moves to the async worker (Postgres-backed queue; no
Redis/Kafka until measured need)". The parenthesis is the design decision, and
it is worth saying why it is not a compromise.

`SELECT … FOR UPDATE SKIP LOCKED` is precisely the primitive a work queue needs:
concurrent workers claim disjoint rows without coordinating, and a worker that
dies holds nothing once its transaction ends. Row-level security already
protects these rows, so a job cannot be claimed on another tenant's behalf — a
property an external broker would need a second, parallel implementation of. And
the job and the artefact it produced commit in the same transaction, which no
broker offers, and without which "the document rendered but the queue still says
pending" is a state somebody reconciles by hand.

The measured need that would justify a broker is throughput this cannot meet.
One row per document, a handful of workers, documents that take hundreds of
milliseconds each: the database is not the bottleneck and would not be at a
hundred times this volume.

Not append-only. A job is workflow — queued, running, done, retried — which is
the argument `watch_events` makes for itself. What happened is in
`audit_events`; what is *left to do* is here.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0017_artefact_jobs"
down_revision = "0016_artefact_provenance"
branch_labels = None
depends_on = None

TABLE = "artefact_jobs"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column(
            "tenant_id",
            sa.String(),
            sa.ForeignKey("tenants.id"),
            nullable=False,
            index=True,
        ),
        sa.Column("kind", sa.String(), nullable=False, index=True),
        sa.Column(
            "params",
            postgresql.JSONB(),
            nullable=False,
            server_default=sa.text("'{}'::jsonb"),
        ),
        sa.Column("fingerprint", sa.String(), nullable=False, index=True),
        sa.Column("subject", sa.String(), nullable=False, server_default=""),
        sa.Column(
            "status", sa.String(), nullable=False, server_default="queued", index=True
        ),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("last_error", sa.Text(), nullable=False, server_default=""),
        sa.Column("requested_by", sa.String(), nullable=False, server_default=""),
        sa.Column(
            "requested_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "artefact_id", sa.Integer(), sa.ForeignKey("artefacts.id"), nullable=True
        ),
    )

    # The claim query's index: a worker asks for the oldest queued job and
    # nothing else. Without it, a queue gets slower the longer it has been
    # working, which is the failure that arrives after the demo.
    op.create_index("ix_artefact_jobs_claim", TABLE, ["status", "id"])

    # Row-level security, like every other tenant-scoped table. FORCE, because
    # a policy is worth nothing against the role that owns the table.
    op.execute(f"ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY;")
    op.execute(f"ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY {TABLE}_tenant ON {TABLE}
        USING (tenant_id = current_setting('app.tenant_id', true))
        WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
        """
    )


def downgrade() -> None:
    op.execute(f"DROP POLICY IF EXISTS {TABLE}_tenant ON {TABLE};")
    op.drop_index("ix_artefact_jobs_claim", table_name=TABLE)
    op.drop_table(TABLE)
