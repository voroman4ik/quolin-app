"""The qualification a signatory held when they signed, recorded on the draft.

Q-02: the §14 workflow could not produce a `REVIEWED` pack. Every part of the
mechanism worked and nothing set the flag, so a pack signed by a named
specialist and published by a second person landed as `PENDING_REVIEW` and the
refusal gate turned it away. The only route to reviewed content was hand-editing
a file and reseeding as the owner, which bypasses signature capture, the content
hash, the jurisdiction-scoped signatory check and the second-pair-of-eyes rule —
the path §14 exists to forbid.

Fixing it means publication has to decide whether a signature is a review. Being
in the `pack_signatory` role is not enough: it is a permission, and competence
to attest for a regime is a fact about an engagement. That fact is already
recorded, on the role grant, as `qualification_ref`. Every signatory in this
repository carries a placeholder there today, which is honest and must keep
producing `PENDING_REVIEW`.

This column copies the qualification onto the draft **at signature time**
rather than leaving publication to look it up. Two reasons, and the second is
the one that matters in two years:

  * A grant can be revoked, re-issued, or corrected. What the pack should record
    is the qualification the signatory held *when they signed*, not whatever
    their grant says on the day somebody asks.
  * It sits beside `content_hash`, which was added for exactly the same reason:
    an attestation is a claim made at a moment, and the moment is part of it.

Nullable with an empty default, so every draft signed before this migration
reads as a signature with no qualification recorded — which is the truthful
answer for them, and produces `PENDING_REVIEW`, which is what they already are.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0030_signature_qualification"
down_revision = "0029_maintenance_role"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "pack_drafts",
        sa.Column(
            "signed_qualification_ref",
            sa.String(),
            nullable=False,
            server_default="",
        ),
    )


def downgrade() -> None:
    op.drop_column("pack_drafts", "signed_qualification_ref")
