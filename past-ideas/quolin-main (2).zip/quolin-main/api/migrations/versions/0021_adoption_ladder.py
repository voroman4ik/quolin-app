"""The adoption ladder, and the customer's own answers to compare against.

§S10: `pilot → shadow → limited → full`, with transitions logged as signed-off
events, and a comparison ingest so shadow mode can produce the sentence the
whole stage exists for — "we agree with you 97% of the time, and here are the
3%".

**The grant is one column wide.** Migration 0002 revoked UPDATE on `tenants`
because a request able to update that table could change its own `id`. Stage 5
granted `config` alone; this grants `stage` alone. The guarantee caught this
stage the first time it tried to move a firm, which is the guard working.

**`tenants.stage` is denormalised, and the transition log is the record.** Every
determination asks which stage a firm is at, because whether an outcome may have
an effect in the world depends on it. Answering that with a join on every write,
for a value that changes four times in a customer's life, is the wrong trade.
`tenant_stages` remains the answer to "when did they go live, and who said so".

**Transitions are append-only.** Moving a firm from shadow to limited means
their determinations start reaching their case system and their clients. The
question afterwards is always who decided they were ready, and a ladder whose
history could be edited answers it with whatever is convenient.

**Incumbent outcomes keep the customer's own vocabulary.** `outcome_raw` is
whatever their file said; `outcome` is our mapping onto ALLOW/REFER/BLOCK. A
divergence report that silently translated `TIER_3` into `REFER` would be
arguing with a strawman — and the mapping is exactly the kind of thing that
turns out to be wrong in week one.

Not append-only, that one: a customer re-sends a corrected extract, and the
correction is the point. What was compared and when is recorded on the
comparison, not on the row.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0021_adoption_ladder"
down_revision = "0020_security_events"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "tenants",
        sa.Column("stage", sa.String(), nullable=False, server_default="pilot"),
    )
    op.create_index("ix_tenants_stage", "tenants", ["stage"])
    # Column-scoped, like Stage 5's grant on `config`. Migration 0002 revoked
    # UPDATE on `tenants` deliberately — a request that could update that table
    # could change its own `id` — so each column the application legitimately
    # writes is granted one at a time, and nothing else becomes writable.
    op.execute("GRANT UPDATE (stage) ON tenants TO quolin_app;")

    op.create_table(
        "tenant_stages",
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column(
            "tenant_id",
            sa.String(),
            sa.ForeignKey("tenants.id"),
            nullable=False,
            index=True,
        ),
        sa.Column("from_stage", sa.String(), nullable=True),
        sa.Column("to_stage", sa.String(), nullable=False, index=True),
        sa.Column(
            "at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("signed_by", sa.String(), nullable=False, server_default=""),
        sa.Column("signed_by_user_id", sa.String(), nullable=True),
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
    )

    op.execute(
        """
        CREATE TRIGGER tenant_stages_append_only
        BEFORE UPDATE OR DELETE ON tenant_stages
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )
    op.execute("REVOKE UPDATE, DELETE ON tenant_stages FROM quolin_app;")

    op.create_table(
        "incumbent_outcomes",
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column(
            "tenant_id",
            sa.String(),
            sa.ForeignKey("tenants.id"),
            nullable=False,
            index=True,
        ),
        sa.Column("client_id", sa.String(), nullable=False, index=True),
        sa.Column("asset_id", sa.String(), nullable=False, index=True),
        sa.Column("as_of", sa.Date(), nullable=False, index=True),
        sa.Column("outcome", sa.String(), nullable=False, server_default=""),
        sa.Column("outcome_raw", sa.String(), nullable=False, server_default=""),
        sa.Column("source", sa.String(), nullable=False, server_default=""),
        sa.Column(
            "received_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
    )
    # One answer per pair per date. A re-sent extract corrects the row it
    # replaces rather than adding a second opinion nobody can choose between.
    op.create_index(
        "ix_incumbent_one_per_pair",
        "incumbent_outcomes",
        ["tenant_id", "client_id", "asset_id", "as_of"],
        unique=True,
    )

    for table in ("tenant_stages", "incumbent_outcomes"):
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;")
        op.execute(
            f"""
            CREATE POLICY {table}_tenant ON {table}
            USING (tenant_id = current_setting('app.tenant_id', true))
            WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
            """
        )


def downgrade() -> None:
    raise NotImplementedError(
        "`tenant_stages` is append-only evidence: who signed for a firm going "
        "live, and when. Dropping it means dropping that record, which is not a "
        "thing a migration should offer to do on the strength of one mistyped "
        "command. Migration 0001 takes the same position."
    )
