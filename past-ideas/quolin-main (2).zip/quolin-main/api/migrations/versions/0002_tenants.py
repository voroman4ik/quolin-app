"""Tenants, and tenant_id on every tenant-scoped table

Revision ID: 0002_tenants
Revises: 0001_baseline
Created: 2026-08-23

The column this migration adds is the one every row-level security policy in
0003 will filter on. Nothing here enables isolation — a `tenant_id` column with
no policy over it is just a label — but the policies cannot be written until
every protected row can answer the question the policy asks.

Two details are worth reading rather than skimming.

**The backfill is a column default, not an UPDATE.** `decisions`, `overrides`,
`packs` and `audit_events` carry a trigger that raises on any UPDATE, so
`UPDATE decisions SET tenant_id = 'demo'` would be refused — correctly, and by
the guarantee this product sells. Adding the column with a `DEFAULT` instead
fills existing rows without rewriting them, because Postgres 11 and later store
the default in the catalogue rather than touching the heap. No row is edited, so
there is nothing for the trigger to object to, and the append-only guarantee is
not suspended for the convenience of a migration.

**The default is then dropped.** Leaving `DEFAULT 'demo'` in place would mean
that any INSERT which forgot to name a tenant would quietly land in somebody
else's data. A missing tenant should be an error at write time, loudly, which is
what a NOT NULL column with no default gives.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0002_tenants"
down_revision = "0001_baseline"
branch_labels = None
depends_on = None

# Kept as a literal list rather than imported from `app.models`. A migration
# describes the schema at one moment; importing today's models would make this
# file mean something different next month, which is the one thing a migration
# must never do.
TENANT_SCOPED_TABLES = (
    "clients",
    "decisions",
    "overrides",
    "artefacts",
    "audit_events",
    "pack_drafts",
    "auth_sessions",
)

# Every row that exists before this migration belongs to the demo firm, because
# before this migration there was only one firm. The id is a slug on purpose:
# it appears in `current_setting('app.tenant_id')`, in logs, and in support
# conversations, where "tenant 7" is a value somebody eventually mistypes.
DEFAULT_TENANT = "demo"


def upgrade() -> None:
    op.create_table(
        "tenants",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("region", sa.String(), nullable=False),
        sa.Column("tier", sa.String(), nullable=False),
        sa.Column("status", sa.String(), nullable=False),
        sa.Column("config", postgresql.JSONB(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_tenants_status", "tenants", ["status"])

    # Reference data, not seed data. The NOT NULL foreign keys below have
    # nothing to point at until this row exists, so it is part of the schema
    # change rather than something a later script supplies.
    op.execute(
        sa.text(
            """
            INSERT INTO tenants (id, name, region, tier, status, config, created_at)
            VALUES (:id, 'Demo Advisory', 'ap-southeast-2', 'shared', 'active',
                    '{}'::jsonb, now())
            ON CONFLICT (id) DO NOTHING
            """
        ).bindparams(id=DEFAULT_TENANT)
    )

    for table in TENANT_SCOPED_TABLES:
        op.add_column(
            table,
            sa.Column(
                "tenant_id",
                sa.String(),
                nullable=False,
                server_default=sa.text(f"'{DEFAULT_TENANT}'"),
            ),
        )
        # Indexed on every table without exception. The policy adds
        # `tenant_id = current_setting(...)` to every plan touching this table,
        # including the queries that already had a perfectly good index — an
        # unindexed predicate present in literally every query is the kind of
        # thing that looks fine on demo data and falls over on a production book.
        op.create_index(f"ix_{table}_tenant_id", table, ["tenant_id"])
        op.create_foreign_key(
            f"fk_{table}_tenant_id", table, "tenants", ["tenant_id"], ["id"]
        )
        # See the module docstring: the default exists only to fill the rows
        # that were already there. Keeping it would turn a forgotten tenant on
        # an INSERT into a silent write into the demo firm's data.
        op.alter_column(table, "tenant_id", server_default=None)

    # `tenants` is readable by the application and writable only by the owner.
    # Creating or suspending a customer is an administrative act; no request
    # performs one, and a request that could would be a request that can grant
    # itself a tenant to read. The baseline's ALTER DEFAULT PRIVILEGES granted
    # full DML on every future table, so this takes three of the four back.
    op.execute("REVOKE INSERT, UPDATE, DELETE ON tenants FROM quolin_app;")


def downgrade() -> None:
    op.execute("GRANT INSERT, UPDATE, DELETE ON tenants TO quolin_app;")
    for table in TENANT_SCOPED_TABLES:
        op.drop_constraint(f"fk_{table}_tenant_id", table, type_="foreignkey")
        op.drop_index(f"ix_{table}_tenant_id", table_name=table)
        op.drop_column(table, "tenant_id")
    op.drop_index("ix_tenants_status", table_name="tenants")
    op.drop_table("tenants")
