"""Who put this rule in front of me, answerable by the firm being governed by it.

Q-12. `packs` is global by design, and the design is right: every customer under
a licence should see the same AU rules, and copying content per tenant is how
two firms end up on different rules by accident.

But `pack_draft_transitions` — the record of who moved that content through
review — is tenant-scoped, correctly, because one firm's workflow is not
another's. The two together left a customer inheriting rule content with no way
to see who wrote it, who signed it, or that it had been reviewed at all.

`pack_publications` is the narrow bridge: global, append-only, one row per
published pack. It carries what a firm being governed by the content is entitled
to know — the regime and version, the firm the draft came from, the named
signatory, the two distinct accounts that signed and published, and the content
hash — and nothing about the drafting workflow that produced it. The transition
log stays where it is and stays tenant-scoped.

Append-only for the same reason `packs` is. A record of a change to rules other
people are governed by is evidence, and an editable one is a story.

Keyed by `pack_id` rather than by an id of its own: there is exactly one
publication per pack row, and a separate key would allow two.

`quolin_operator` arrives in the same change and needs no schema — roles are
strings in `user_roles`. It is the role the publication route now requires, and
it is Quolin staff rather than a customer's administrator. Nothing here grants
it; the seed does, and `access_review.py` reports it like any other.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0033_global_publication_record"
down_revision = "0032_permit_out_of_config"
branch_labels = None
depends_on = None

TABLE = "pack_publications"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column(
            "pack_id",
            sa.Integer(),
            sa.ForeignKey("packs.id"),
            primary_key=True,
        ),
        sa.Column("jurisdiction", sa.String(), nullable=False, index=True),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("effective_from", sa.Date(), nullable=False),
        #: The firm whose staff drafted, reviewed and signed this content. Not a
        #: tenant scope — every tenant reads every row — but the answer to
        #: "whose specialists proposed the rules I am being governed by".
        sa.Column("origin_tenant", sa.String(), nullable=False),
        sa.Column("drafted_by", sa.String(), nullable=False, server_default=""),
        sa.Column("drafted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("signed_by", sa.String(), nullable=False, server_default=""),
        sa.Column("signed_by_user_id", sa.String(), nullable=True),
        sa.Column("signed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("published_by_user_id", sa.String(), nullable=True),
        sa.Column("published_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("content_hash", sa.String(64), nullable=False, server_default=""),
    )

    op.execute(
        f"""
        CREATE TRIGGER {TABLE}_append_only
        BEFORE UPDATE OR DELETE ON {TABLE}
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )

    # Readable by everybody, writable by the role that publishes. The trigger
    # above is the second lock: even the owner cannot edit a row once written.
    op.execute(f"GRANT SELECT ON {TABLE} TO quolin_app;")
    op.execute(f"GRANT INSERT ON {TABLE} TO quolin_app;")
    op.execute(f"GRANT SELECT ON {TABLE} TO quolin_watch;")
    op.execute(f"REVOKE UPDATE, DELETE ON {TABLE} FROM quolin_app;")
    op.execute(f"REVOKE INSERT, UPDATE, DELETE ON {TABLE} FROM quolin_watch;")


def downgrade() -> None:
    raise NotImplementedError(
        "This is the record of who put a piece of rule content in front of every "
        "customer on the platform. Dropping the table drops the answer to the "
        "question the finding was about, which is not a thing a migration should "
        "offer to do on the strength of one mistyped command. Migrations 0001 "
        "and 0028 take the same position."
    )
