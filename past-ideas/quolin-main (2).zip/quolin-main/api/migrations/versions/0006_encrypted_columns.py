"""Drop the plaintext columns, once there is ciphertext to replace them

Revision ID: 0006_encrypted_columns
Revises: 0005_tenant_keys
Created: 2026-08-23

The second half of the pair `0005` opened. It refuses to run while any row is
still missing its ciphertext, then drops the plaintext columns and renames the
ciphertext ones into their place, so that `clients.name` and
`decisions.snapshot` keep the names every query and every reader already uses
and simply stop being readable without a key.

Two migrations rather than one because the fill between them cannot happen
here. `decisions` is append-only, and turning its stored snapshots into
ciphertext means suspending that guarantee on purpose, as an operator, with the
act recorded — `scripts/encrypt_existing.py`, following the pattern
`scripts/rechain.py` set. A migration that quietly disabled the trigger to do
it would be the exact move the migration linter exists to catch.

On a database created from scratch this is uneventful: `make seed` rebuilds the
schema by running every migration against empty tables, so the guard below
passes with nothing to count and the seed then writes ciphertext from the
first row onward.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0006_encrypted_columns"
down_revision = "0005_tenant_keys"
branch_labels = None
depends_on = None

#: Repeated from `0005` rather than imported from it. Migrations are records of
#: what was run, and one reaching into another makes the older file's contents
#: load-bearing for the newer one forever.
ENCRYPTED_COLUMNS = {
    "clients": ("name", "dob", "note"),
    "decisions": ("snapshot",),
}

CIPHER = "_cipher"


def upgrade() -> None:
    bind = op.get_bind()

    # Every row must already carry its ciphertext. Counted as the owner, which
    # is the role migrations run as and the only one that sees past row-level
    # security — a count taken under a tenant filter would report zero
    # outstanding rows for every customer except the one being counted, and
    # would then drop the plaintext other customers still depended on.
    outstanding = []
    for table, columns in ENCRYPTED_COLUMNS.items():
        for column in columns:
            missing = bind.execute(
                sa.text(f"SELECT count(*) FROM {table} WHERE {column}{CIPHER} IS NULL")
            ).scalar_one()
            if missing:
                outstanding.append(f"{table}.{column}: {missing} rows")

    if outstanding:
        raise RuntimeError(
            "Refusing to drop plaintext columns that have not been encrypted "
            "yet:\n  " + "\n  ".join(outstanding) + "\n\n"
            "Run `make encrypt-existing` (dry run), then "
            "`make encrypt-existing ARGS=--apply`, then this migration again. "
            "The database is left at 0005, which is a working state: the "
            "application reads the plaintext columns until this migration "
            "completes."
        )

    for table, columns in ENCRYPTED_COLUMNS.items():
        for column in columns:
            op.drop_column(table, column)
            op.alter_column(
                table,
                f"{column}{CIPHER}",
                new_column_name=column,
                nullable=False,
            )


def downgrade() -> None:
    raise NotImplementedError(
        "Going back means decrypting every snapshot and every client name into "
        "plaintext columns, which needs the master key and the live envelope in "
        "`app/crypto.py` — neither of which a frozen migration may hold, for "
        "the reason `0005` gives. Dropping the ciphertext columns instead would "
        "destroy the data outright. If this genuinely has to be reversed, it is "
        "a script written against the code of the day, not a downgrade."
    )
