"""Pack events reach every firm the content governs, not just the publisher's.

FP3-08. `pack.staged` and `pack.published` were emitted through
`service._tell_the_customers_systems`, which calls `webhooks.endpoints_for` —
an RLS-scoped query — inside the signer's or publisher's own tenant
transaction.

Packs are **global**: the same AU rules govern every customer. Publication
requires `quolin_operator`, which is Quolin's own role, held inside one tenant.
So the only firm that could ever receive `pack.staged` or `pack.published` was
whichever tenant the publisher happened to be acting in — which is not a
customer at all.

That leaves §S4's staged-pack notice and §S5's "tenants notified" gate
describing something that has never happened. It is the same class as
`source.stale` and was missed for the same reason: a producer exists, is called,
and writes rows, so nothing looks unwired.

**A separate table from `source_breaches`, and the reason is not tidiness.**
Both are global events fanned out per tenant, and one table with an `event`
column would serve both — but the watch role holds INSERT on `source_breaches`,
and a single shared table would let a compromised watch task announce a
`pack.published` that never happened to every customer on the platform. Two
tables means two grants, and the watch role has no reach into this one.

`pack_event_notices` is tenant-scoped for the same reason `source_breach_notices`
is: what a given firm has been told is that firm's record, and the fan-out
already runs inside `acting_as(tenant_id)` because enqueueing the webhook does.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0040_pack_events"
down_revision = "0039_business_timezone"
branch_labels = None
depends_on = None

APP = "quolin_app"
WATCH = "quolin_watch"


def upgrade() -> None:
    op.create_table(
        "pack_events",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("event", sa.String(), nullable=False),
        sa.Column("subject", sa.String(), nullable=False),
        #: Which regime this concerns, so the fan-out can skip firms that are
        #: not licensed in it. A firm operating only in Australia has no
        #: interest in an EU pack being staged, and telling them anyway is how a
        #: customer learns to ignore our webhooks.
        sa.Column("jurisdiction", sa.String(), nullable=False),
        sa.Column("payload", postgresql.JSONB(), nullable=False),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_pack_events_event", "pack_events", ["event"])

    op.create_table(
        "pack_event_notices",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("pack_event_id", sa.BigInteger(), nullable=False),
        sa.Column("tenant_id", sa.String(), nullable=False),
        sa.Column("notified_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["pack_event_id"], ["pack_events.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("pack_event_id", "tenant_id", name="uq_pack_event_notice"),
    )

    op.execute("ALTER TABLE pack_event_notices ENABLE ROW LEVEL SECURITY;")
    op.execute("ALTER TABLE pack_event_notices FORCE ROW LEVEL SECURITY;")
    op.execute(
        """
        CREATE POLICY tenant_isolation ON pack_event_notices
        USING (tenant_id = current_setting('app.tenant_id', true))
        WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
        """
    )

    for table in ("pack_events", "pack_event_notices"):
        op.execute(
            f"""
            CREATE TRIGGER {table}_append_only
            BEFORE UPDATE OR DELETE ON {table}
            FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
            """
        )
        # 0001's default privileges grant all four on every new table and revoke
        # them on the append-only ones by name. FP3-10 is what happens when a
        # migration adds one and forgets this line.
        op.execute(f"REVOKE UPDATE, DELETE, TRUNCATE ON {table} FROM {APP};")

    # The watch service has no business here at all. It reads publications and
    # writes drafts; announcing that a pack is in force is the publish
    # endpoint's, and a compromised sweep must not be able to tell every
    # customer that rule content changed when it did not.
    op.execute(f"REVOKE ALL ON pack_events FROM {WATCH};")
    op.execute(f"REVOKE ALL ON pack_event_notices FROM {WATCH};")


def downgrade() -> None:
    raise NotImplementedError(
        "This is the record of which firms were told that the rules governing "
        "them had changed, and when. §S5's advance window is measured from it. "
        "Dropping it removes the evidence that a firm was given notice."
    )
