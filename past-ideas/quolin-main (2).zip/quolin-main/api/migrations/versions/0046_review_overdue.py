"""A firm operating on superseded rules is told every day, and it is on file.

FP3-17. `advance.notice` was called only from `advance.sweep`, and `sweep`
selects `Pack.effective_from <= today` — so a pinned tenant learned that a new
version existed **on the day it was already governing everybody on auto**. §S5's
"UAT space before advancing" describes a review window that starts after the
thing it is a window for has happened.

Two changes, and the second is the one an auditor reads.

**Part one: notice on publication.** `notice` is called when a future-dated pack
is published, so the window precedes the change rather than trailing it.

**Part two: what an expired window does.** Decided, and recorded here because
the alternatives were considered and rejected rather than overlooked.

An expired window **stays PENDING**. The system does not auto-advance a pinned
tenant — that is pinning in name only, as the code's own comment says — and it
does not refuse determinations, because halting a customer's business on our own
authority is a contractual and liability position nobody has taken and nobody
should take before a legal opinion exists.

Instead the state is made impossible to miss and impossible to deny later:

  * a `pack.review_overdue` webhook, **once per day, per tenant, per overdue
    pack**, from the day after the window closes until the firm advances;
  * one chained audit event per day with the same key, which is the artefact
    proving the firm was told;
  * a `pack_review_overdue` field on every determination made while a window is
    open past its close, naming the pack, the superseding version and the days
    overdue.

That last one is the point. An auditor asking "how long did this firm operate on
superseded rules, and did they know" gets a per-day chained answer from the
evidence itself, **and every single determination made in that period says so on
its face** — rather than the answer having to be reconstructed by joining a
policy table against a publication date.

This table is the once-per-day key. `(tenant_id, jurisdiction, pack_version,
on_day)` is unique, so a worker that runs every ten minutes sends one
notification a day rather than a hundred and forty-four — the same reasoning
`source_alerts.page` uses about an alert that arrives every ten minutes being an
alert nobody reads.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0046_review_overdue"
down_revision = "0045_dual_control"
branch_labels = None
depends_on = None

TABLE = "review_overdue_notices"


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("tenant_id", sa.String(), nullable=False),
        sa.Column("jurisdiction", sa.String(), nullable=False),
        sa.Column("pack_version", sa.Integer(), nullable=False),
        #: The firm's own business date, not the container's. FP3-05.
        sa.Column("on_day", sa.Date(), nullable=False),
        sa.Column("days_overdue", sa.Integer(), nullable=False),
        sa.Column("sent_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        # Once per day, per tenant, per overdue pack. The constraint is the
        # control: a worker on a ten-minute cycle would otherwise send a hundred
        # and forty-four notifications a day, and an alert that arrives every
        # ten minutes is one somebody filters into a folder.
        sa.UniqueConstraint(
            "tenant_id",
            "jurisdiction",
            "pack_version",
            "on_day",
            name="uq_one_overdue_notice_per_day",
        ),
    )
    op.create_index(
        "ix_review_overdue_notices_tenant", TABLE, ["tenant_id", "on_day"]
    )

    op.execute(f"ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY;")
    op.execute(f"ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY tenant_isolation ON {TABLE}
        USING (tenant_id = current_setting('app.tenant_id', true))
        WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
        """
    )

    op.execute(
        f"""
        CREATE TRIGGER {TABLE}_append_only
        BEFORE UPDATE OR DELETE ON {TABLE}
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )
    op.execute(f"REVOKE UPDATE, DELETE, TRUNCATE ON {TABLE} FROM quolin_app;")
    op.execute(f"REVOKE ALL ON {TABLE} FROM quolin_watch;")


def downgrade() -> None:
    raise NotImplementedError(
        "This is the per-day record that a firm was told it was operating on "
        "superseded rules. It is the answer to 'did they know', and the whole "
        "reason the alternative to auto-advancing was acceptable. Dropping it "
        "removes the evidence and leaves the decision."
    )
