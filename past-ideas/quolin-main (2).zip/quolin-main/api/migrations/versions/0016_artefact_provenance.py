"""What produced a document, from what, and who asked.

§S7: "every artefact records template version, pack version, data window,
generator identity". The template version has been on the row since Stage 0. The
other three were reconstructible only by inference — the pack version from the
decision, the window from the filename, the requester not at all — and inference
is not provenance.

The question this exists to answer is the one a regulator asks about a document
in front of them. "Which rules produced these figures" is not answered by the
template name: two pack versions can share a layout, and the numbers come from
the rules. "What period does this cover" is answered by the body of a return and
by nothing at all on a per-determination document. "Who asked for it" was
nowhere.

`content_hash` is the fifth, and it is only worth storing because of the work in
this same stage that made rendering deterministic: no wall-clock in the
document, so the bytes are a function of the pack version and the data. That
turns "this is the document we filed" into a checkable claim.

`inputs_hash` is the sixth, and it exists because the fifth needs something to
be compared *against*. A document's bytes depend on more than its subject: the
firm's own letterhead is in them, and a firm that changes its trading name
legitimately produces a different document from the same determination. Without
this column the two cases — "the renderer has started reading the clock" and
"the customer renamed themselves" — are the same observation. With it, the first
raises and the second is recorded.

Nullable rather than backfilled with guesses. Rows written before this migration
genuinely do not carry these facts, and a plausible value invented now would be
indistinguishable from one that was recorded at the time — which is the failure
mode the whole column exists to prevent.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0016_artefact_provenance"
down_revision = "0015_watch_assist_calls"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "artefacts", sa.Column("pack_id", sa.String(), nullable=False, server_default="")
    )
    op.add_column("artefacts", sa.Column("pack_version", sa.Integer(), nullable=True))
    op.add_column("artefacts", sa.Column("window_start", sa.Date(), nullable=True))
    op.add_column("artefacts", sa.Column("window_end", sa.Date(), nullable=True))
    op.add_column(
        "artefacts",
        sa.Column("generated_by", sa.String(), nullable=False, server_default=""),
    )
    op.add_column(
        "artefacts",
        sa.Column("content_hash", sa.String(), nullable=False, server_default=""),
    )
    op.add_column(
        "artefacts",
        sa.Column("inputs_hash", sa.String(), nullable=False, server_default=""),
    )
    # Regenerating a return for the same period under the same pack version must
    # find the existing row rather than write a second one. The index is what
    # makes that lookup a lookup rather than a scan.
    op.create_index(
        "ix_artefacts_regeneration",
        "artefacts",
        ["tenant_id", "kind", "ref_id", "pack_version"],
    )


def downgrade() -> None:
    op.drop_index("ix_artefacts_regeneration", table_name="artefacts")
    for column in (
        "inputs_hash",
        "content_hash",
        "generated_by",
        "window_end",
        "window_start",
        "pack_version",
        "pack_id",
    ):
        op.drop_column("artefacts", column)
