"""How a piece of rule content came to be in force, and who each step was

Revision ID: 0012_pack_lifecycle
Revises: 0011_machine_sessions
Created: 2026-08-24

Stage 5 makes the pack lifecycle first-class. Two tables, and the reasoning for
each is different.

**`pack_draft_transitions` is append-only, alongside the evidence tables.** A
`status` column says where a draft is now and destroys the record of how it got
there every time it changes. That record is what an auditor is actually asking
for: "this pack became effective on the fourteenth" is a fact, and "it was
drafted by an operator on the second, put up for review on the ninth, signed by
a named signatory on the eleventh and put in force by an administrator on the
twelfth" is the answer to the question behind it.

It is append-only for the same reason `audit_events` is, and the trigger and the
revoked grant say so twice on purpose — a trigger can be dropped by whoever can
drop it, and the grant is a second, independent statement of the same rule.
`scripts/lint_migrations.sh` forbids a later migration from re-granting either.

**`tenant_advances` is not append-only, and that is deliberate.** A pinned
tenant's row moves from `pending` to `advanced` or `declined` as they work
through their window, which is exactly the kind of state change an append-only
table cannot express. It is a workflow record rather than evidence: what it says
about a pack version is not what makes that version true, and the transitions
that matter — the signature, the publication — are in the append-only table
above.

**`policy` is copied onto each advance rather than read from the tenant.** A
firm that switched from pinned to auto last month did not thereby change what
happened in March, and a report that derived the policy from the tenant row
would rewrite its own history every time somebody changed a setting.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0012_pack_lifecycle"
down_revision = "0011_machine_sessions"
branch_labels = None
depends_on = None

TENANT_FK = "tenants.id"
POLICY = "tenant_isolation"
SETTING = "app.tenant_id"

NEW_TABLES = ("pack_draft_transitions", "tenant_advances")
APPEND_ONLY = ("pack_draft_transitions",)


def upgrade() -> None:
    op.create_table(
        "pack_draft_transitions",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("tenant_id", sa.String(), sa.ForeignKey(TENANT_FK), nullable=False),
        sa.Column(
            "draft_id", sa.Integer(), sa.ForeignKey("pack_drafts.id"), nullable=False
        ),
        # Nullable on the first row, which records the draft coming into
        # existence. A sentinel string would sort among the real states in every
        # query that groups by this column.
        sa.Column("from_status", sa.String(), nullable=True),
        sa.Column("to_status", sa.String(), nullable=False),
        sa.Column("at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("by_actor", sa.String(), nullable=True),
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
    )
    for column in ("tenant_id", "draft_id", "to_status", "at"):
        op.create_index(
            f"ix_pack_draft_transitions_{column}", "pack_draft_transitions", [column]
        )

    op.create_table(
        "tenant_advances",
        sa.Column("id", sa.String(), primary_key=True),
        sa.Column("tenant_id", sa.String(), sa.ForeignKey(TENANT_FK), nullable=False),
        sa.Column("jurisdiction", sa.String(), nullable=False),
        sa.Column("pack_version", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(), nullable=False, server_default="pending"),
        sa.Column("policy", sa.String(), nullable=False),
        sa.Column("window_closes_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("noticed_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("advanced_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("advanced_by", sa.String(), nullable=True),
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
        # One row per tenant per version. A second would make "have they
        # advanced" a question with two answers.
        sa.UniqueConstraint(
            "tenant_id", "jurisdiction", "pack_version", name="tenant_advances_version_key"
        ),
    )
    for column in ("tenant_id", "jurisdiction", "status"):
        op.create_index(f"ix_tenant_advances_{column}", "tenant_advances", [column])

    # Row-level security, fail-closed, exactly as every tenant-scoped table
    # since migration 0003 has it.
    for table in NEW_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;")
        op.execute(
            f"""
            CREATE POLICY {POLICY} ON {table}
            USING (tenant_id = current_setting('{SETTING}', true))
            WITH CHECK (tenant_id = current_setting('{SETTING}', true));
            """
        )

    op.execute(
        "GRANT SELECT, INSERT, UPDATE, DELETE ON "
        + ", ".join(NEW_TABLES)
        + " TO quolin_app;"
    )
    op.execute(
        "GRANT USAGE, SELECT ON SEQUENCE pack_draft_transitions_id_seq TO quolin_app;"
    )

    # Append-only, stated twice. The trigger refuses the write; the revoked
    # grant means the role could not have attempted it. Either alone is a rule
    # somebody can remove in one line without the other noticing.
    for table in APPEND_ONLY:
        op.execute(
            f"""
            CREATE TRIGGER {table}_append_only
            BEFORE UPDATE OR DELETE ON {table}
            FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
            """
        )
        op.execute(f"REVOKE UPDATE, DELETE ON {table} FROM quolin_app;")

    # `pack_drafts` gains the two things a signature has to capture. The hash is
    # of the body as it stood when it was signed: a signatory attests to
    # specific content, and "they signed version 4" is a weaker claim than
    # "they signed these exact bytes" when somebody later asks what changed.
    op.add_column("pack_drafts", sa.Column("content_hash", sa.String(), nullable=True))
    op.add_column(
        "pack_drafts", sa.Column("submitted_at", sa.DateTime(timezone=True), nullable=True)
    )
    op.add_column("pack_drafts", sa.Column("submitted_by", sa.String(), nullable=True))

    # A tenant may set its own advance policy, and nothing else about itself.
    #
    # Migration 0002 revoked INSERT, UPDATE and DELETE on `tenants` from the
    # application role, with good reasoning: creating or suspending a customer is
    # administrative, and a request that could update `tenants` could change its
    # own `id` — which is a request that can move itself into another customer's
    # data. That reasoning is untouched.
    #
    # But §S5 frames the advance policy as the *customer's* control over vendor
    # changes, and a control they cannot set is a weaker answer to the question
    # it exists to answer. So the grant is column-scoped: `config` and nothing
    # else. Combined with the existing policy on `tenants` — which admits only
    # the row named by `app.tenant_id` — a firm can change its own settings and
    # cannot reach its identity or anybody else's row.
    op.execute("GRANT UPDATE (config) ON tenants TO quolin_app;")

    # Every tenant gets an advance policy, defaulting to pinned.
    #
    # Pinned rather than auto, and that is the safe default rather than the
    # convenient one: a firm that has not chosen has not agreed to rule content
    # changing under them without a look. Auto is a decision somebody makes.
    op.execute(
        """
        UPDATE tenants
        SET config = COALESCE(config, '{}'::jsonb) || '{"advance_policy": "pinned",
                                                        "uat_window_days": 14}'::jsonb
        WHERE NOT (COALESCE(config, '{}'::jsonb) ? 'advance_policy');
        """
    )


def downgrade() -> None:
    """Refused, for the reason the baseline migration gives.

    `pack_draft_transitions` is append-only evidence: it is how a piece of rule
    content came to be in force, and who each step was. A downgrade that dropped
    it would destroy that record — and it would have to drop the append-only
    trigger first, which is precisely the move `scripts/lint_migrations.sh`
    exists to refuse.

    The guard caught this migration's first downgrade doing exactly that, and it
    was right to. A teardown that removes an append-only guarantee is
    indistinguishable, in a diff, from a migration that quietly weakens one; the
    linter cannot tell them apart and should not have to.

    Reversing this on a database that matters means deciding, by hand, what to
    do with the transition history. That is a conversation, not a command.
    """
    raise NotImplementedError(
        "0012 is not reversible. It creates `pack_draft_transitions`, which is "
        "append-only evidence of how rule content came to be in force. Dropping "
        "it means dropping its trigger first, which invariant 4 forbids — see "
        "scripts/lint_migrations.sh. Decide what to do with the history by hand."
    )


# Referenced so the migration linter's append-only check has something to read
# in this file, and so a reader grepping for the guarded set finds this table.
_APPEND_ONLY_TABLES_ADDED = APPEND_ONLY
