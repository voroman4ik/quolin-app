"""One parent, one child: a unique index that makes a forked chain impossible.

§S13's restore drill — drill number two, and the first one to find anything —
reported the evidence chain broken in exactly one tenant: the one §S12's load
test had driven with twenty concurrent sessions. Ten determinations shared a
single `prev_hash`, written within twenty milliseconds of each other. Every one
of them was a valid link from the same parent, and a chain with ten children is
a tree. `verify_chain` walks by id, so it broke at the second sibling and
reported the tenant's evidence as unverifiable.

Nothing before this had ever appended to one tenant's chain from two connections
at once. A determination is made by a person; the demo firm has one firm's
staff; the bulk sweep is one worker per tenant by construction. So every chain
test in the suite passed, `make tamper-demo` demonstrated exactly what it
claims, and the guarantee this product is sold on would have failed the first
afternoon two compliance officers worked at the same time.

`evidence._lock_chain` is the fix: `FOR UPDATE` on the tenant's anchor row, so
appends serialise within a firm and not between firms. This index is the second
lock, and the reason for having both is the reason there is both a trigger and a
revoked grant on every append-only table — a guarantee that rests on one
mechanism rests on somebody remembering that mechanism exists. A path that
appends without taking the lock now *fails*, rather than forking a chain that
verifies today and does not next quarter.

**This migration will refuse to apply to a database that already holds a fork**,
and that is deliberate. Creating the index is the check. A database that cannot
take it has an evidence chain that does not verify, which is a thing to find out
during a deploy rather than during an audit; `scripts/rechain.py` is the repair,
and it needs a person to run it and say why.
"""

from __future__ import annotations

from alembic import op

revision = "0024_chain_no_forks"
down_revision = "0023_queue_priority"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Partial: the first determination in a tenant's chain has the anchor as its
    # parent, and that is legitimately shared by nothing — but a tenant with no
    # determinations has no row here at all, so there is nothing to exclude.
    # Every row is covered.
    op.execute(
        """
        CREATE UNIQUE INDEX ix_decisions_one_child_per_parent
        ON decisions (tenant_id, prev_hash);
        """
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_decisions_one_child_per_parent;")
