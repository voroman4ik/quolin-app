"""What the caller *claimed* their address was, kept apart from what it was.

FP3-02. `auth_attempts.source_ip` was written from the first entry of
`X-Forwarded-For`, which is whatever the client typed. So the table Stage 9
describes as the record of an attack that survives the attacker recorded the
attacker's chosen fiction, and thirty guesses from one address appeared as
thirty addresses that each guessed once.

`source_ip` now holds the address the ASGI server resolved from the trusted
proxy count and nothing else. The header is still worth having — a spoofed
`X-Forwarded-For` is itself a signal, and the chain a real proxy writes is how
you tell a CDN from a botnet — so it is kept, in its own column, named so that
nobody reads it as an address.

Deliberately not backfilled. Every existing row's `source_ip` was written from
the header, and there is no way to tell from the row which ones were honest.
Copying the old values across would manufacture the appearance of provenance
this migration exists to remove. They stay as they are, and the column is null
for every attempt recorded before the fix — which is the truthful answer to
"where did this come from" for those rows.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0037_untrusted_xff"
down_revision = "0036_rechain_grants"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "auth_attempts",
        sa.Column("forwarded_for_untrusted", sa.Text(), nullable=True),
    )


def downgrade() -> None:
    raise NotImplementedError(
        "auth_attempts is append-only and holds the record of failed sign-ins. "
        "Dropping a column from it rewrites that record. If the forensic value "
        "of the raw header is no longer wanted, stop writing it — do not remove "
        "what was already written."
    )
