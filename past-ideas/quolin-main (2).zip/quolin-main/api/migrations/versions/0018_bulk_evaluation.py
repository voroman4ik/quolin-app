"""Bulk re-evaluation: runs, the chunks they are done in, and what changed.

§S8 asks for the whole book to be re-checked when a pack version becomes
effective, when a client's profile changes, or on a schedule — in chunked
batches, resumable, with per-run stats — and for a delta report as a first-class
artefact.

Four things here, and one of them is a constraint rather than a table.

**`eval_runs`** is the unit people talk about. "Pack v4 took effect and 212
clients moved to REFER" is a sentence about a run, and `trigger` records why it
happened because "why was my whole book re-checked on a Tuesday" is the first
question a customer asks about one.

**`eval_chunks`** lists the pairs it owns rather than an offset into an
ordering. An offset is only stable if the underlying set is, and one client
added mid-run would shift every later chunk — silently re-doing some pairs and
skipping others. A list cannot drift.

**`eval_deltas`** is stored, not derived. The comparison is against the
determination in force *before* the run, which stops being findable the moment
another run happens; and a pinned tenant's Stage 5 UAT decision is made against
this list, so it has to be the same list tomorrow.

**The unique constraint on `decisions (run_id, client_id, asset_id)`** is what
§S8's gate means by "resumes without double-recording". One transaction per
chunk already means a worker killed mid-chunk leaves nothing behind; this is the
second, independent statement of the same rule, for the case where a chunk
committed and the process died before it could be marked done. Partial, so that
the determinations an officer makes by hand — which carry no run — are not
forced to be unique per client and asset, which they must not be.

Runs are serialised within a tenant, and that is the evidence chain's doing
rather than a limitation of this schema: `prev_hash` is the previous
determination's hash, so two workers appending to one tenant's chain would
splice it. Chunks are for resumability and progress. Parallelism is across
tenants, where the chains are separate.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0018_bulk_evaluation"
down_revision = "0017_artefact_jobs"
branch_labels = None
depends_on = None

TABLES = ("eval_runs", "eval_chunks", "eval_deltas")


def _tenant_policy(table: str) -> None:
    """Row-level security, forced, like every other tenant-scoped table."""
    op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;")
    op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY {table}_tenant ON {table}
        USING (tenant_id = current_setting('app.tenant_id', true))
        WITH CHECK (tenant_id = current_setting('app.tenant_id', true));
        """
    )


def upgrade() -> None:
    op.create_table(
        "eval_runs",
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column(
            "tenant_id", sa.String(), sa.ForeignKey("tenants.id"), nullable=False, index=True
        ),
        sa.Column("trigger", sa.String(), nullable=False, index=True),
        sa.Column("jurisdiction", sa.String(), nullable=False, server_default=""),
        sa.Column("as_of", sa.Date(), nullable=False),
        sa.Column("status", sa.String(), nullable=False, server_default="planned", index=True),
        sa.Column("requested_by", sa.String(), nullable=False, server_default=""),
        sa.Column(
            "requested_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.text("now()"),
        ),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("pairs_total", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("pairs_done", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("changed", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("failures", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
    )

    op.create_table(
        "eval_chunks",
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column(
            "tenant_id", sa.String(), sa.ForeignKey("tenants.id"), nullable=False, index=True
        ),
        sa.Column(
            "run_id", sa.BigInteger(), sa.ForeignKey("eval_runs.id"), nullable=False, index=True
        ),
        sa.Column("seq", sa.Integer(), nullable=False),
        sa.Column(
            "pairs", postgresql.JSONB(), nullable=False, server_default=sa.text("'[]'::jsonb")
        ),
        sa.Column("status", sa.String(), nullable=False, server_default="queued", index=True),
        sa.Column("attempts", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_error", sa.Text(), nullable=False, server_default=""),
    )
    # The claim query: the run's lowest-numbered chunk that nobody holds.
    op.create_index("ix_eval_chunks_claim", "eval_chunks", ["status", "run_id", "seq"])

    op.create_table(
        "eval_deltas",
        sa.Column("id", sa.BigInteger(), primary_key=True, autoincrement=True),
        sa.Column(
            "tenant_id", sa.String(), sa.ForeignKey("tenants.id"), nullable=False, index=True
        ),
        sa.Column(
            "run_id", sa.BigInteger(), sa.ForeignKey("eval_runs.id"), nullable=False, index=True
        ),
        sa.Column("client_id", sa.String(), nullable=False, index=True),
        sa.Column("asset_id", sa.String(), nullable=False),
        sa.Column("from_outcome", sa.String(), nullable=False),
        sa.Column("to_outcome", sa.String(), nullable=False),
        sa.Column("from_pack_version", sa.Integer(), nullable=True),
        sa.Column("to_pack_version", sa.Integer(), nullable=True),
        sa.Column("rule_id", sa.String(), nullable=False, server_default=""),
        sa.Column("reason_code", sa.String(), nullable=False, server_default=""),
        sa.Column("decision_id", sa.Integer(), sa.ForeignKey("decisions.id"), nullable=True),
    )

    for table in TABLES:
        _tenant_policy(table)

    op.add_column(
        "decisions",
        sa.Column(
            "run_id",
            sa.BigInteger(),
            sa.ForeignKey("eval_runs.id"),
            nullable=True,
        ),
    )
    op.create_index("ix_decisions_run", "decisions", ["run_id"])
    # Partial, and deliberately so. A determination an officer makes at a screen
    # carries no run, and those must *not* be unique per client and asset — a
    # client can be assessed for the same asset many times, which is most of
    # what the history screen shows.
    op.execute(
        """
        CREATE UNIQUE INDEX ix_decisions_one_per_run
        ON decisions (run_id, client_id, asset_id)
        WHERE run_id IS NOT NULL;
        """
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_decisions_one_per_run;")
    op.drop_index("ix_decisions_run", table_name="decisions")
    op.drop_column("decisions", "run_id")
    for table in reversed(TABLES):
        op.execute(f"DROP POLICY IF EXISTS {table}_tenant ON {table};")
    op.drop_index("ix_eval_chunks_claim", table_name="eval_chunks")
    for table in reversed(TABLES):
        op.drop_table(table)
