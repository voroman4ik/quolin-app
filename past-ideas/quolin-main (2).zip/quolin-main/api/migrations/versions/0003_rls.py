"""Row-level security: fail-closed tenant isolation in the database

Revision ID: 0003_rls
Revises: 0002_tenants
Created: 2026-08-23

The point of this migration is that isolation stops being something the
application does. Up to here, "customer A cannot see customer B" was a claim
about every WHERE clause in the codebase — true only for as long as nobody
writes a query that forgets. From here it is a property of the tables, and a
query that forgets returns nothing rather than everything.

Three details carry the guarantee, and each is a way it is usually got wrong.

**FORCE, not just ENABLE.** `ENABLE ROW LEVEL SECURITY` exempts the table's
owner. Migrations and the seed run as the owner, so a policy that is merely
enabled is one an owning connection walks straight past — and the owning
connection is the one a well-meaning maintenance script uses. `FORCE` applies
the policy to the owner as well. What it cannot cover is a superuser or a role
with BYPASSRLS: for those there is no policy, only the discipline of not
connecting as one, which `tests/test_rls.py` asserts about the application role
rather than leaving to a comment.

**Fail closed on an absent setting.** `current_setting('app.tenant_id', true)`
returns NULL when nothing has been set, and `tenant_id = NULL` is NULL, which is
not true, so the row is not visible. A connection that has not said who it is
sees an empty database. The alternative — a policy that permits everything when
unset — reads as convenience and behaves as a full disclosure the first time a
code path forgets to set it.

**WITH CHECK as well as USING.** `USING` filters what a statement can see;
`WITH CHECK` constrains what it can write. Without the second, a request could
read only its own rows and still INSERT a row belonging to somebody else — which
is not a data leak but is a data *plant*, and in an evidence system that is
worse. The two clauses are identical here on purpose: you may write exactly the
rows you may read.
"""

from __future__ import annotations

from alembic import op

revision = "0003_rls"
down_revision = "0002_tenants"
branch_labels = None
depends_on = None

TENANT_SCOPED_TABLES = (
    "clients",
    "decisions",
    "overrides",
    "artefacts",
    "audit_events",
    "pack_drafts",
    "auth_sessions",
)

#: The Postgres setting every policy reads, set per transaction from the
#: authenticated session. Bare `set_config` rather than a custom GUC class
#: registered in postgresql.conf, because the latter needs a server restart to
#: introduce and a managed Postgres will not always give you one.
SETTING = "app.tenant_id"

#: The second setting, and it exists to solve one problem: authentication has to
#: happen before the tenant is known. Resolving a cookie to a session row is the
#: step that *decides* the tenant, so it cannot itself be filtered by tenant —
#: and a table whose rows are invisible until you know which tenant they belong
#: to cannot tell you which tenant they belong to.
#:
#: The answer is not to exempt `auth_sessions` from isolation. It is to give it a
#: second, narrower policy: while this setting holds the hash of a presented
#: cookie, exactly one row is visible — the one that cookie names. That is
#: tighter than tenant scoping, not looser.
#:
#: The two settings are never both in force. `app.session_token` is set only
#: inside the token lookup, `app.tenant_id` only once a tenant is known.
TOKEN_SETTING = "app.session_token"

POLICY = "tenant_isolation"


def upgrade() -> None:
    for table in TENANT_SCOPED_TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY;")
        op.execute(f"ALTER TABLE {table} FORCE ROW LEVEL SECURITY;")
        op.execute(
            f"""
            CREATE POLICY {POLICY} ON {table}
            USING (tenant_id = current_setting('{SETTING}', true))
            WITH CHECK (tenant_id = current_setting('{SETTING}', true));
            """
        )

    # See TOKEN_SETTING. Permissive policies are OR'd, so during a request the
    # tenant policy applies and during the cookie lookup this one does; neither
    # widens the other, because the setting the other reads is unset.
    op.execute(
        f"""
        CREATE POLICY session_self ON auth_sessions
        USING (token_hash = current_setting('{TOKEN_SETTING}', true))
        WITH CHECK (token_hash = current_setting('{TOKEN_SETTING}', true));
        """
    )

    # `tenants` is policed too, and by its own primary key rather than by a
    # `tenant_id` column. Without this, any authenticated request could list
    # every customer of the platform by name — not their data, but the client
    # list is itself commercially sensitive and is the first thing anyone would
    # ask about in diligence.
    op.execute("ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;")
    op.execute("ALTER TABLE tenants FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY {POLICY} ON tenants
        USING (id = current_setting('{SETTING}', true));
        """
    )


def downgrade() -> None:
    """Refused. FP3-01, and not a finding anybody reported.

    This dropped every tenant-isolation policy, un-forced row-level security on
    every tenant-scoped table, and disabled it — which is to say it removed the
    entire mechanism separating one customer's rows from another's, leaving a
    schema that looks identical in every column and answers every query with
    everybody's data.

    Nobody named this one. It was found by the new linter on the run that was
    written to catch 0026, which is the argument for the linter rather than for
    the finding: a guard that asserts the deployed fact finds the instances
    nobody thought to list, and a guard that greps for spellings finds the ones
    somebody already knew about.

    The same reasoning as 0026 applies and applies harder. A rollback is a thing
    that happens under pressure, at speed, by somebody who has been paged — and
    the failure mode here is silent. Nothing errors. The next request simply
    returns another firm's clients.
    """
    raise NotImplementedError(
        "0003 is not reversible. Reversing it drops every tenant-isolation "
        "policy and un-forces row-level security, which does not fail loudly — "
        "it serves one customer another customer's rows. If row-level security "
        "genuinely has to be rebuilt, it is a forward migration somebody signs."
    )
