"""Who did each half of a two-person act

Revision ID: 0008_separation_of_duties
Revises: 0007_identity
Created: 2026-08-23

0007 made a person a row. This migration is what lets the application refuse to
let one row do both halves of an act that is supposed to take two.

Every column here is a user id beside an existing free-text name, not a
replacement for it. `overrides.approver` and `pack_drafts.signed_by` stay: they
hold what was typed at the time, they appear on generated documents, and a
signature that changed retroactively because somebody edited their profile would
be a worse record than one that is merely old. The new columns answer a
different question — *which account* acted — and that is the question separation
of duties turns on, because two people may share a name and one person may
change theirs.

**Nullable, and staying nullable.** Rows written before this point have nobody
attached, and no backfill can invent one. A placeholder id would make those rows
indistinguishable from attributed ones, which is the whole failure mode
`service.Unattributed` exists to prevent. The application refuses to *write* an
unattributed row; the schema tolerates the ones already on file, and the reports
print them as unattributed rather than as anybody.

**Not foreign keys.** Same reasoning as `user_roles.granted_by` in 0007: the
record of who acted must outlive the account, and a person leaving the firm must
not be undeletable because a determination points at them, nor take the
attribution with them if they are.

**`decisions.decided_by` is outside the hash, deliberately.** Invariant 2 says
the frozen snapshot is the only input to a determination, so who ran the check
cannot be part of what the chain protects — hashing it would tie the evidence to
something the engine never read, and replay would have to be handed an operator
to reproduce a result the operator did not influence. It is safe outside the
hash because `decisions` is append-only at the database level: there is no
UPDATE grant with which to change it.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0008_separation_of_duties"
down_revision = "0007_identity"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("decisions", sa.Column("decided_by", sa.String(), nullable=True))
    op.add_column("overrides", sa.Column("approved_by", sa.String(), nullable=True))
    op.add_column("pack_drafts", sa.Column("signed_by_user_id", sa.String(), nullable=True))
    op.add_column(
        "pack_drafts", sa.Column("published_by_user_id", sa.String(), nullable=True)
    )
    # A rejected draft used to write the rejecting person into `signed_by`,
    # which read back as a signature on content nobody signed. Its own column,
    # so the two acts cannot be confused by anything reading the row.
    op.add_column(
        "pack_drafts",
        sa.Column("rejected_by", sa.String(), nullable=False, server_default=""),
    )
    op.add_column(
        "pack_drafts", sa.Column("rejected_by_user_id", sa.String(), nullable=True)
    )
    op.add_column(
        "pack_drafts",
        sa.Column("rejected_at", sa.DateTime(timezone=True), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("pack_drafts", "rejected_at")
    op.drop_column("pack_drafts", "rejected_by_user_id")
    op.drop_column("pack_drafts", "rejected_by")
    op.drop_column("pack_drafts", "published_by_user_id")
    op.drop_column("pack_drafts", "signed_by_user_id")
    op.drop_column("overrides", "approved_by")
    op.drop_column("decisions", "decided_by")
