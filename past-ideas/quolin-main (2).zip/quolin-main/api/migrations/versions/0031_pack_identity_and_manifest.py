"""A pack version that identifies one pack, and a decision that says what ran.

Q-04, in four columns and one constraint.

**`UNIQUE (jurisdiction, version)`.** `packs` had no such constraint. Versions
were allocated at *draft* creation as `highest + 1`, and the §14 rolling track
keeps several drafts open against one base at a time — so two drafts cut on the
same afternoon both proposed the same number and both could publish it. Every
determination made afterwards records a version that names two different pieces
of rule content, and `packs_repo.by_version` picked between them with `.first()`
and no `ORDER BY`.

This migration will fail on a database that already holds a collision, and that
is deliberate. Resolving one means deciding which determinations were made under
which content, which is not a thing a migration should do quietly at 3am.
`tests/test_pack_provenance_and_manifest.py` checks the seed holds none.

**`packs.content_hash`.** So "what are the bytes of this pack" is answerable
without evaluating anything. Written at publication and by the seed. Left empty
on rows that predate this migration, rather than backfilled — `packs` is
append-only and enforced by trigger, exactly as migration 0025 found when it
tried an UPDATE. An empty hash is the honest record of a pack published before
hashes were kept, and nothing depends on it: the authoritative copy for replay
is the one inside each decision's manifest, computed from the body at the moment
of the determination.

**`decisions.manifest`.** What actually ran: the pack content, the snapshot, the
language version, the evaluator build, and the snapshot-construction inputs.
Replay compares it against the environment doing the replaying and reports drift
as drift, rather than as a rule-outcome difference that looks exactly like a
regression in the engine.

**`decisions.payload_schema`.** The reason this could be done at all. The chain
hash is recomputed from stored columns, so adding a field to the hashed payload
would change the recomputed hash of every determination already on file and
break the chain on rows nobody had touched. That is invariant 5 broken to
improve provenance, which is not a trade worth making. Instead each row records
which payload shape it was hashed under: 1 for everything written before this,
2 for everything after. Both are supported forever, for the same reason
`engine/evaluate.py` keeps DSL v1 forever.

`server_default='1'` is what classifies the existing rows, so no UPDATE is
needed on an append-only table and no row is guessed at on read.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import JSONB

revision = "0031_pack_identity_and_manifest"
down_revision = "0030_signature_qualification"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_unique_constraint(
        "packs_one_row_per_jurisdiction_version", "packs", ["jurisdiction", "version"]
    )

    op.add_column(
        "packs",
        sa.Column("content_hash", sa.String(64), nullable=False, server_default=""),
    )

    op.add_column("decisions", sa.Column("manifest", JSONB(), nullable=True))
    op.add_column(
        "decisions",
        sa.Column("payload_schema", sa.Integer(), nullable=False, server_default="1"),
    )

    # Every determination is one of the shapes this engine can still recompute.
    # A row claiming a schema nothing implements would be a record that cannot
    # be verified, which is worse than one that fails verification.
    op.create_check_constraint(
        "decisions_payload_schema_is_known",
        "decisions",
        "payload_schema IN (1, 2)",
    )


def downgrade() -> None:
    op.drop_constraint("decisions_payload_schema_is_known", "decisions", type_="check")
    op.drop_column("decisions", "payload_schema")
    op.drop_column("decisions", "manifest")
    op.drop_column("packs", "content_hash")
    op.drop_constraint(
        "packs_one_row_per_jurisdiction_version", "packs", type_="unique"
    )
