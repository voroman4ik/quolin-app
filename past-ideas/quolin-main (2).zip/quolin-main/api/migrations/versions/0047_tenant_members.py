"""Belonging to a firm is not the same fact as holding a role in it.

A firm could revoke somebody's last grant and, in doing so, make every audit
event naming that person unresolvable to itself. `users` has no `tenant_id` — it
cannot have one, because a consultant compliance officer serves three firms and
is one human — so migration 0007 answered "which people may this firm see?" with
`user_reachable`: the ones it has granted a role to. That is the right shape and
the wrong predicate.

`user_roles` was carrying two facts at once:

  * **this person belongs to this firm**, which is about identity, and
  * **this person may do X here**, which is about authorisation.

Revoking authorisation is an ordinary act somebody performs on a Tuesday.
Revoking *identity* is not, and it is what actually happened: the row was
deleted, the person stopped resolving for that tenant, and `audit_events` —
append-only — went on naming them as the actor of things they did. FP3-13 had
already established the principle ("nothing in production deletes a person,
because decisions, overrides and audit events all name one") and built
suspension so that off-boarding did not have that effect. Revoking the last
grant went around it.

A second sequence reached the same state and no screen could have prevented it:
`identity.invitation.consumed` names the invited person as its actor, correctly,
at a moment when they hold no grant at all. Between choosing a password and
being given a role, the trail named somebody the firm could not look up.

**So membership becomes its own table, and it is create-only.** A row appears
when a firm provisions a person or grants them anything, and nothing removes it.
`user_reachable` reads it instead of `user_roles`.

Three things this deliberately does not do.

**It does not weaken tenant isolation.** The policy is the same fail-closed
`EXISTS` against a tenant-scoped table; only the table changed. A firm still
cannot see somebody it has never had. What it can now see is somebody it *did*
have, which is the difference between a staff list and an audit trail.

**It does not touch the authorisation path.** `roles_for`, `rbac` and
`access_review` read `user_roles` exactly as before. The alternative considered
— keeping revoked grants as soft-deleted rows and matching those — would have
put "is this grant live?" into every query that reads the table, and the failure
mode of missing one is a revoked role that still authorises. That is the worst
possible way to get this wrong, and this way cannot get it wrong at all.

**It does not let a firm remove somebody.** There is no un-join, because an
un-join is the bug. A person who has left is a person with no live grants, which
is what suspension and revocation already express.

The backfill reads `user_roles` for everybody currently granted, **and
`audit_events` for everybody who ever acted** — the second is what repairs the
firms where this has already happened, and without it the migration would fix
the future and leave the existing orphans exactly where they are.
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0047_tenant_members"
down_revision = "0046_review_overdue"
branch_labels = None
depends_on = None

TABLE = "tenant_members"
TENANT_SETTING = "app.tenant_id"

#: The three policies that answered "may this firm see this person?" by asking
#: `user_roles`. All three move together: a person's login methods and second
#: factor are reachable on exactly the same basis as the person, and the
#: quarterly access review reads all three.
REACHABLE = (
    ("users", "user_reachable", "users.id"),
    ("user_identities", "user_identities_reachable", "user_identities.user_id"),
    ("mfa_credentials", "mfa_credentials_reachable", "mfa_credentials.user_id"),
)


def upgrade() -> None:
    op.create_table(
        TABLE,
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("tenant_id", sa.String(), nullable=False),
        sa.Column("user_id", sa.String(), nullable=False),
        sa.Column("joined_at", sa.DateTime(timezone=True), nullable=False),
        #: Why this person became one of this firm's people — provisioned into
        #: it, granted something in it, or recovered by this migration's
        #: backfill. Free text and not a constraint: it is here so that a row
        #: nobody remembers creating can be accounted for.
        sa.Column("reason", sa.String(), nullable=False, server_default=""),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"]),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        # One membership per person per firm. `ensure_member` inserts with ON
        # CONFLICT DO NOTHING against this, so the common case — granting a
        # second role to somebody who is already here — is a no-op rather than
        # an error the caller has to know to catch.
        sa.UniqueConstraint("tenant_id", "user_id", name="uq_one_membership_each"),
    )
    op.create_index("ix_tenant_members_user", TABLE, ["user_id"])

    # ---------------------------------------------------------------- backfill
    #
    # Before RLS and before the append-only trigger, deliberately: the policy
    # would refuse rows for every tenant but whichever one happened to be in
    # scope, and there is no tenant in scope during a migration.
    #
    # Everybody who currently holds a grant.
    op.execute(
        f"""
        INSERT INTO {TABLE} (tenant_id, user_id, joined_at, reason)
        SELECT ur.tenant_id, ur.user_id, MIN(ur.granted_at), 'backfill: holds a grant'
        FROM user_roles ur
        GROUP BY ur.tenant_id, ur.user_id
        ON CONFLICT (tenant_id, user_id) DO NOTHING;
        """
    )
    # And everybody who ever acted, which is the half that repairs the damage.
    # A person whose last grant was revoked has no `user_roles` row left and is
    # exactly the case this migration exists for.
    #
    # `audit_events.actor` also names machine credentials, which are not people
    # and have no `users` row; the EXISTS filters them out rather than the join
    # silently dropping them, so the intent is on the page.
    op.execute(
        f"""
        INSERT INTO {TABLE} (tenant_id, user_id, joined_at, reason)
        SELECT ae.tenant_id, ae.actor, MIN(ae.at), 'backfill: named in the audit trail'
        FROM audit_events ae
        WHERE EXISTS (SELECT 1 FROM users u WHERE u.id = ae.actor)
        GROUP BY ae.tenant_id, ae.actor
        ON CONFLICT (tenant_id, user_id) DO NOTHING;
        """
    )

    # ------------------------------------------------------------- the fences
    op.execute(f"ALTER TABLE {TABLE} ENABLE ROW LEVEL SECURITY;")
    op.execute(f"ALTER TABLE {TABLE} FORCE ROW LEVEL SECURITY;")
    op.execute(
        f"""
        CREATE POLICY tenant_isolation ON {TABLE}
        USING (tenant_id = current_setting('{TENANT_SETTING}', true))
        WITH CHECK (tenant_id = current_setting('{TENANT_SETTING}', true));
        """
    )

    # Append-only, and this is the load-bearing part rather than housekeeping.
    # A membership somebody could delete is a membership somebody could delete
    # to make an actor stop resolving, which is the whole defect with an extra
    # step. Two independent statements of the same rule, as everywhere else: the
    # trigger and the revoked grants.
    op.execute(
        f"""
        CREATE TRIGGER {TABLE}_append_only
        BEFORE UPDATE OR DELETE ON {TABLE}
        FOR EACH ROW EXECUTE FUNCTION quolin_append_only();
        """
    )
    op.execute(f"REVOKE UPDATE, DELETE, TRUNCATE ON {TABLE} FROM quolin_app;")
    op.execute(f"REVOKE ALL ON {TABLE} FROM quolin_watch;")

    # ------------------------------------------------------- the policy change
    for table, policy, column in REACHABLE:
        op.execute(f"DROP POLICY {policy} ON {table};")
        op.execute(
            f"""
            CREATE POLICY {policy} ON {table}
            USING (
              EXISTS (
                SELECT 1 FROM {TABLE} tm
                WHERE tm.user_id = {column}
                  AND tm.tenant_id = current_setting('{TENANT_SETTING}', true)
              )
            )
            WITH CHECK (false);
            """
        )


def downgrade() -> None:
    raise NotImplementedError(
        "Going back re-points the reachability policies at `user_roles`, which "
        "makes every person whose grants have been revoked invisible to the "
        "firm again while `audit_events` goes on naming them. The table could "
        "be dropped; the consequence is that determinations, overrides and "
        "audit rows start pointing at people nobody can resolve, silently, and "
        "the only visible symptom is an access review reporting 'unresolvable'. "
        "That is the defect this migration exists to remove."
    )
