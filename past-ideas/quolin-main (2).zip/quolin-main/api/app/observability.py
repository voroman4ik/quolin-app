"""Structured logs, and the record of what happened *to* the system.

§S9 asks for structured logging with central aggregation, and for alerting on
auth anomalies and row-level-security denials. Two different needs with one
thing in common: both are useless unless the thing being observed is written
down in a shape a machine can read.

**Logs are JSON, one object per line.** Not because JSON is pleasant to read —
it is not — but because the alternative is a regular expression written a year
later by somebody who was not there, run against a format that has drifted. A
log aggregator wants fields; giving it a sentence and asking it to parse one out
is how "alert on RLS denials" becomes "alert on RLS denials that still match the
pattern".

**Every line carries the tenant and the actor when they are known.** An
incident's first question is whose data was involved, and a log line that cannot
answer it sends somebody to the database to find out — during the incident.

**Security events are a table, not a log line.** A log is for reading; a table
is for querying, alerting and keeping. `security_events` is append-only for the
same reason the audit trail is: it is what somebody reads afterwards, and a
record that can be rewritten answers a different question.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
import uuid
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any

from sqlalchemy.orm import Session

from .models import SecurityEvent
from .tenancy import current_tenant_or_none, current_user_or_none

#: The request being served, so that every line emitted while handling it can be
#: joined back together. Set by the middleware and never by hand.
_REQUEST_ID: ContextVar[str | None] = ContextVar("quolin_request_id", default=None)

#: Kinds of security event. A closed list, because an alert rule that matches a
#: string somebody typed is one that stops matching when they type it
#: differently.
AUTH_FAILED = "auth.failed"
AUTH_RATE_LIMITED = "auth.rate_limited"
AUTH_REAUTH_FAILED = "auth.reauth_failed"
RLS_DENIED = "rls.denied"
#: A stored determination that no longer reproduces. Not an *auth* event, but it
#: belongs in the same table for the same reason: it is something that happened
#: to the system, it has no acting person, and it is what somebody reads after
#: an incident. The nightly replay writes it; `alerts.replay_mismatches` reads
#: it. The alert existed before this kind did, which the first game day found
#: within a minute — an alert whose condition cannot be written is an alert that
#: does not work.
REPLAY_MISMATCH = "replay.mismatch"
KINDS = (
    AUTH_FAILED,
    AUTH_RATE_LIMITED,
    AUTH_REAUTH_FAILED,
    RLS_DENIED,
    REPLAY_MISMATCH,
)

#: What a failed sign-in is allowed to say when it did not resolve to an
#: account. Never the address that was typed — see the module note.
UNKNOWN_ACCOUNT = "unknown account"


class JsonFormatter(logging.Formatter):
    """One JSON object per line, with the context that makes a line useful.

    Extra fields are read off the record rather than formatted into the message,
    so that `logger.info("evaluated", extra={"decision_id": 4})` produces a
    field an aggregator can filter on rather than a sentence it has to parse.
    """

    #: Attributes `logging` puts on every record. Anything else was put there by
    #: a caller and belongs in the output.
    _STANDARD = frozenset(
        vars(logging.LogRecord("", 0, "", 0, "", None, None)).keys()
    ) | {"message", "asctime", "taskName"}

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "at": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname.lower(),
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key, value in vars(record).items():
            if key not in self._STANDARD and not key.startswith("_"):
                payload[key] = value
        for key, value in (
            ("tenant_id", current_tenant_or_none()),
            ("actor", current_user_or_none()),
            ("request_id", _REQUEST_ID.get()),
        ):
            if value:
                payload.setdefault(key, value)
        if record.exc_info:
            payload["error"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure(level: str | None = None) -> None:
    """Point the root logger at stdout, as JSON.

    stdout rather than a file: every deployment target this system has — ECS,
    a container on a laptop — collects stdout, and a log file inside a container
    is a log file nobody reads and nobody rotates.

    Idempotent, because the API and every script call it and a second handler
    means every line twice.
    """
    root = logging.getLogger()
    chosen = level or os.getenv("QUOLIN_LOG_LEVEL") or "INFO"
    root.setLevel(chosen.upper())
    for existing in list(root.handlers):
        if getattr(existing, "_quolin", False):
            return
        root.removeHandler(existing)

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    handler._quolin = True  # type: ignore[attr-defined]
    root.addHandler(handler)


def new_request_id() -> str:
    request_id = uuid.uuid4().hex[:16]
    _REQUEST_ID.set(request_id)
    return request_id


def request_id() -> str | None:
    return _REQUEST_ID.get()


def record(
    session: Session,
    *,
    kind: str,
    user_id: str | None = None,
    source_ip: str = "",
    detail: str = "",
) -> SecurityEvent | None:
    """Write a security event, and never let doing so break the request.

    The same reasoning `service.notify` uses for webhooks, and it applies more
    strongly here: this is called on the failure path of sign-in, and a system
    that refused to log somebody out because it could not write a log line would
    have turned an observability feature into an outage.

    Returns None when it could not be written. The caller carries on either way;
    the log line below is what survives.
    """
    if kind not in KINDS:
        raise ValueError(f"unknown security event {kind!r}. Known: {', '.join(KINDS)}")

    logging.getLogger("quolin.security").warning(
        kind,
        extra={
            "event": kind,
            "subject": user_id or UNKNOWN_ACCOUNT,
            "source_ip": source_ip,
            "detail": detail,
        },
    )
    try:
        event = SecurityEvent(
            kind=kind, user_id=user_id, source_ip=source_ip, detail=detail
        )
        session.add(event)
        session.flush()
        return event
    except Exception:  # noqa: BLE001 — see the docstring
        session.rollback()
        return None


def timed(logger_name: str, message: str, **fields: Any):
    """A context manager that logs how long something took.

    Used for the things §S9 wants alerting on when they get slow — a sweep, a
    render, a restore drill — because "it is slow" is not actionable and "the
    p99 of this operation moved from 200ms to 9s on Tuesday" is.
    """

    class _Timer:
        def __enter__(self):
            self.started = time.monotonic()
            return self

        def __exit__(self, exc_type, exc, tb):
            elapsed_ms = int((time.monotonic() - self.started) * 1000)
            logging.getLogger(logger_name).info(
                message,
                extra={**fields, "elapsed_ms": elapsed_ms, "ok": exc is None},
            )
            return False

    return _Timer()
