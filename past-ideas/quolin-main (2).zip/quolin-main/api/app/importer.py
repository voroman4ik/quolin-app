"""CSV client import: parse, validate, report, and only then write.

A client book arriving as a CSV is reference data, not evidence. `clients` is
deliberately absent from `APPEND_ONLY_TABLES`, because a CRM record legitimately
changes — someone's loss-capacity band is reassessed, a vulnerability flag is
added. What must never change is a determination that was already made, and that
is safe here for a structural reason rather than a careful one: every decision
freezes its inputs into a snapshot, and replay reads the snapshot. Re-importing a
client cannot reach backwards into a determination.

Three rules shape this module:

  Validate everything before writing anything. A half-imported book leaves the
  institution in a state nobody chose and nobody can describe. Either the file
  is good and all of it lands, or none of it does and every bad row is named.

  Reject decimals in money columns outright. Cents are integers (invariant 3).
  A CSV is exactly where a float gets in — `1234.56` in a cents column means the
  author thought in dollars, and silently rounding it would put a number in the
  evidence chain that nobody typed.

  Say what the import does not bring. A client row carries no custody data. The
  positions provider is a fixture, so an imported client has no holdings on
  file, and every path that reports on the import has to say so rather than let
  a reader assume the concentration figures mean something.
"""

from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from datetime import date

from . import business_time

# Every column the importer understands. Order is the order of the sample file,
# which is the order a reader will most likely produce by hand.
REQUIRED_COLUMNS = (
    "id",
    "scenario",
    "name",
    "dob",
    "client_category",
    "knowledge_assessed",
    "knowledge_date",
    "loss_capacity_band",
    "vulnerability_flag",
    "assessable_portfolio_cents",
    "prior_crypto_purchases",
    "structural_acks",
    "default_trade_amount_cents",
)
OPTIONAL_COLUMNS = ("jurisdiction", "residency", "domicile", "note")
ALL_COLUMNS = REQUIRED_COLUMNS + OPTIONAL_COLUMNS

MONEY_COLUMNS = ("assessable_portfolio_cents", "default_trade_amount_cents")

ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,63}$")

# `structural_acks` is a list in one CSV cell, so it needs a separator that
# cannot appear in an acknowledgement name. A comma cannot be used inside a CSV
# field without quoting, and quoting is where hand-edited files go wrong.
ACK_SEPARATOR = "|"

TRUE_WORDS = {"true", "yes", "y", "1"}
FALSE_WORDS = {"false", "no", "n", "0", ""}

# Bands are 1-5 in every pack threshold table that maps them. A band outside
# that range would not match any row of `hard_floor_loss_band_by_volatility`,
# so it is rejected at import rather than producing an unexplainable decision.
MIN_BAND, MAX_BAND = 1, 5

# An import that creates a client in a scenario no screen knows about produces a
# book that exists in the database and nowhere in the product.
KNOWN_SCENARIOS = ("meridian", "sterling")
KNOWN_CATEGORIES = ("retail", "wholesale")

#: The regime assumed when a file predates the jurisdiction columns. Kept in
#: step with `service.DEFAULT_JURISDICTION` and stated by value here, because an
#: importer that imported from the service layer would drag half the
#: application into a module whose whole job is to read text.
DEFAULT_JURISDICTION = "AU"

# Two letters, which is the whole of the code space packs are named in: ISO
# 3166-1 alpha-2 for a country, and the same two-letter space for a bloc that
# regulates as one (EU). Deliberately a shape check and not a list of the codes
# we happen to ship — an importer that rejected a regime the moment before its
# pack landed would make adding a jurisdiction a two-place change, which is the
# thing this architecture exists to avoid.
JURISDICTION_RE = re.compile(r"^[A-Z]{2}$")


class ImportError_(ValueError):
    """The file as a whole cannot be read — not a per-row problem."""


@dataclass
class RowError:
    """One reason one row was rejected.

    Carries the column as well as the message, because "row 14 is invalid" sends
    someone hunting through thirteen fields.
    """

    row: int
    column: str
    message: str

    def as_dict(self) -> dict:
        return {"row": self.row, "column": self.column, "message": self.message}


@dataclass
class ParsedRow:
    row: int
    values: dict
    # True when a client with this id is already in the database. Decided by the
    # caller, which is the only party that can see the database.
    exists: bool = False


@dataclass
class ImportReport:
    """What the file contains and what importing it would do."""

    total_rows: int = 0
    valid: list[ParsedRow] = field(default_factory=list)
    errors: list[RowError] = field(default_factory=list)
    duplicate_ids: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    def as_dict(self, *, committed: bool) -> dict:
        new = [r for r in self.valid if not r.exists]
        updated = [r for r in self.valid if r.exists]
        return {
            "ok": self.ok,
            "committed": committed,
            "total_rows": self.total_rows,
            "valid_rows": len(self.valid),
            "rejected_rows": len({e.row for e in self.errors}),
            "new_clients": len(new),
            "updated_clients": len(updated),
            "errors": [e.as_dict() for e in self.errors],
            "new_ids": [r.values["id"] for r in new],
            "updated_ids": [r.values["id"] for r in updated],
            # Stated on every import result, successful or not. An imported
            # client has no custody record, and the concentration rule will
            # therefore assess them as holding nothing.
            "custody_warning": (
                "Imported clients have no custody positions. Custody is a fixture in "
                "this prototype, so concentration is assessed as if an imported client "
                "holds nothing. Figures for these clients are not a view of a real "
                "portfolio."
            ),
        }


def _boolean(raw: str, column: str, row: int, errors: list[RowError]) -> bool | None:
    value = raw.strip().lower()
    if value in TRUE_WORDS:
        return True
    if value in FALSE_WORDS:
        return False
    errors.append(
        RowError(row, column, f"{raw!r} is not a yes/no value (use true or false)")
    )
    return None


def _integer(
    raw: str, column: str, row: int, errors: list[RowError], *, minimum: int | None = None
) -> int | None:
    value = raw.strip()
    if not value:
        errors.append(RowError(row, column, "required"))
        return None

    # Checked before int() so the message can name the real mistake. int("12.5")
    # raises the same ValueError as int("abc"), and they are not the same error.
    if column in MONEY_COLUMNS and ("." in value or "," in value):
        errors.append(
            RowError(
                row,
                column,
                f"{raw!r} looks like a decimal amount. This column is whole cents — "
                "$1,234.56 is 123456.",
            )
        )
        return None

    try:
        number = int(value)
    except ValueError:
        errors.append(RowError(row, column, f"{raw!r} is not a whole number"))
        return None

    if minimum is not None and number < minimum:
        errors.append(RowError(row, column, f"must be {minimum} or more, got {number}"))
        return None
    return number


def _date(raw: str, column: str, row: int, errors: list[RowError]) -> date | None:
    value = raw.strip()
    if not value:
        errors.append(RowError(row, column, "required"))
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        errors.append(RowError(row, column, f"{raw!r} is not a date in YYYY-MM-DD form"))
        return None


def _jurisdiction(
    raw: str | None, fallback: str, column: str, row: int, errors: list[RowError]
) -> str:
    """A jurisdiction code, or the fallback when the cell is blank.

    A blank cell is not an error: the fallback is what the row means when it
    says nothing. A cell with something unusable in it is, because a client
    silently filed under the wrong regulator is a decision made under the wrong
    rules.
    """
    value = (raw or "").strip().upper()
    if not value:
        return fallback
    if not JURISDICTION_RE.match(value):
        errors.append(
            RowError(row, column, f"{value!r} is not a two-letter jurisdiction code")
        )
    return value


def _validate_row(
    row_number: int, raw: dict, errors: list[RowError], today: date
) -> dict | None:
    """Validate one row. Appends every problem it finds rather than the first.

    Returning after the first bad column would make fixing a spreadsheet an
    iterative game against the importer.
    """
    before = len(errors)
    values: dict = {}

    client_id = (raw.get("id") or "").strip()
    if not ID_RE.match(client_id):
        errors.append(
            RowError(
                row_number,
                "id",
                f"{client_id!r} is not a valid id (lowercase letters, digits and "
                "hyphens, 2-64 characters)",
            )
        )
    values["id"] = client_id

    scenario = (raw.get("scenario") or "").strip().lower()
    if scenario not in KNOWN_SCENARIOS:
        errors.append(
            RowError(
                row_number,
                "scenario",
                f"{scenario!r} is not a known book ({', '.join(KNOWN_SCENARIOS)})",
            )
        )
    values["scenario"] = scenario

    name = (raw.get("name") or "").strip()
    if not name:
        errors.append(RowError(row_number, "name", "required"))
    values["name"] = name

    dob = _date(raw.get("dob", ""), "dob", row_number, errors)
    if dob is not None and dob >= today:
        errors.append(RowError(row_number, "dob", "date of birth is in the future"))
    values["dob"] = dob

    category = (raw.get("client_category") or "").strip().lower()
    if category not in KNOWN_CATEGORIES:
        errors.append(
            RowError(
                row_number,
                "client_category",
                f"{category!r} is not one of {', '.join(KNOWN_CATEGORIES)}",
            )
        )
    values["client_category"] = category

    assessed = _boolean(
        raw.get("knowledge_assessed", ""), "knowledge_assessed", row_number, errors
    )
    values["knowledge_assessed"] = assessed

    knowledge_raw = (raw.get("knowledge_date") or "").strip()
    knowledge_date = None
    if knowledge_raw:
        knowledge_date = _date(knowledge_raw, "knowledge_date", row_number, errors)
        if knowledge_date is not None and knowledge_date > today:
            errors.append(
                RowError(row_number, "knowledge_date", "assessment date is in the future")
            )
    elif assessed:
        # AU v2 refers when the assessment is over 24 months old, which it cannot
        # compute without a date. Importing "assessed, but we won't say when"
        # would produce a client the currency rule cannot evaluate.
        errors.append(
            RowError(
                row_number,
                "knowledge_date",
                "required when knowledge_assessed is true — the assessment's age is "
                "what the rule tests",
            )
        )
    values["knowledge_date"] = knowledge_date

    values["loss_capacity_band"] = _integer(
        raw.get("loss_capacity_band", ""), "loss_capacity_band", row_number, errors
    )
    band = values["loss_capacity_band"]
    if band is not None and not (MIN_BAND <= band <= MAX_BAND):
        errors.append(
            RowError(
                row_number,
                "loss_capacity_band",
                f"must be between {MIN_BAND} and {MAX_BAND}, got {band}",
            )
        )

    values["vulnerability_flag"] = _boolean(
        raw.get("vulnerability_flag", ""), "vulnerability_flag", row_number, errors
    )
    values["assessable_portfolio_cents"] = _integer(
        raw.get("assessable_portfolio_cents", ""),
        "assessable_portfolio_cents",
        row_number,
        errors,
        minimum=0,
    )
    values["prior_crypto_purchases"] = _integer(
        raw.get("prior_crypto_purchases", ""),
        "prior_crypto_purchases",
        row_number,
        errors,
        minimum=0,
    )
    values["default_trade_amount_cents"] = _integer(
        raw.get("default_trade_amount_cents", ""),
        "default_trade_amount_cents",
        row_number,
        errors,
        minimum=1,
    )

    acks_raw = (raw.get("structural_acks") or "").strip()
    values["structural_acks"] = (
        [a.strip() for a in acks_raw.split(ACK_SEPARATOR) if a.strip()] if acks_raw else []
    )

    # Three separate facts, and only the first is about the firm. A row that
    # names one of them names all three, because a client advised from where
    # they live and where they are domiciled is the ordinary case and every row
    # written before this column existed was exactly that.
    licensee = _jurisdiction(
        raw.get("jurisdiction"), DEFAULT_JURISDICTION, "jurisdiction", row_number, errors
    )
    values["jurisdiction"] = licensee
    values["residency"] = _jurisdiction(
        raw.get("residency"), licensee, "residency", row_number, errors
    )
    values["domicile"] = _jurisdiction(
        raw.get("domicile"), licensee, "domicile", row_number, errors
    )

    values["note"] = (raw.get("note") or "").strip()

    return values if len(errors) == before else None


def parse(text: str, *, today: date | None = None) -> ImportReport:
    """Read a client-book CSV and report what it contains.

    Writes nothing and touches no database. The same function backs both the
    preview and the commit, so what a caller was shown is what a caller gets.

    `today` is the importing firm's business date, and it is a parameter rather
    than something looked up here precisely to keep the sentence above true.
    FP3-05: "is this date of birth in the future" and "is this assessment dated
    ahead of today" are questions about the firm's calendar, not the container's,
    and for a Sydney firm those differ for ten hours of every working morning —
    long enough to refuse a row recorded this morning as being dated tomorrow.

    Defaulting to the platform date rather than requiring the argument: both
    production callers pass one, and a test that only cares about column parsing
    should not have to invent a firm.
    """
    today = today or business_time.platform_today()
    if not text.strip():
        raise ImportError_("the file is empty")

    reader = csv.DictReader(io.StringIO(text))
    if reader.fieldnames is None:
        raise ImportError_("the file has no header row")

    header = [(f or "").strip() for f in reader.fieldnames]
    missing = [c for c in REQUIRED_COLUMNS if c not in header]
    if missing:
        raise ImportError_(
            f"missing required column{'s' if len(missing) > 1 else ''}: "
            f"{', '.join(missing)}"
        )
    unknown = [c for c in header if c and c not in ALL_COLUMNS]
    if unknown:
        # Refused rather than ignored: a column the importer silently drops is a
        # field the author believed they had supplied.
        raise ImportError_(
            f"unrecognised column{'s' if len(unknown) > 1 else ''}: "
            f"{', '.join(unknown)}. Remove it or correct the spelling."
        )

    report = ImportReport()
    seen: dict[str, int] = {}

    for offset, raw in enumerate(reader):
        # Row 1 is the header, so the first data row is row 2 — the number the
        # author will see in their spreadsheet.
        row_number = offset + 2
        if not any((v or "").strip() for v in raw.values()):
            continue
        report.total_rows += 1

        values = _validate_row(
            row_number, {k: (v or "") for k, v in raw.items()}, report.errors, today
        )
        if values is None:
            continue

        client_id = values["id"]
        if client_id in seen:
            report.duplicate_ids.append(client_id)
            report.errors.append(
                RowError(
                    row_number,
                    "id",
                    f"{client_id!r} already appears on row {seen[client_id]} of this file",
                )
            )
            continue
        seen[client_id] = row_number
        report.valid.append(ParsedRow(row=row_number, values=values))

    if report.total_rows == 0:
        raise ImportError_("the file has a header but no rows")
    return report
