"""Period aggregation for returns, override reporting and audit export.

Everything in this module *reads* recorded evidence. Nothing here decides
anything, and nothing here is on the decision path — a report can be wrong
without a determination being wrong. That is deliberate: aggregation is
allowed to change shape between versions, determinations are not.

Two date fields are in play and they are not interchangeable:

  Decision.as_of      the business date the determination applies to, and the
                      date frozen into the snapshot. Returns scope on this,
                      because it is the date a reader would recognise as "when
                      this client was assessed".
  Decision.created_at when the row was written. Only used for the audit trail.

Overrides and audit events have no business date, so they scope on their own
`created_at` / `at`.
"""

from __future__ import annotations

import re
from collections import Counter
from datetime import date, datetime, time, timedelta, timezone

from sqlalchemy import Row, select
from sqlalchemy.orm import Session

from . import evidence, packs_repo
from .engine.dsl import DATA_MISSING
from .engine.evaluate import DATA_MISSING_TEXT
from .models import Asset, AuditEvent, Client, Decision, Override

#: Kept in step with `service.DEFAULT_JURISDICTION`; imported by value rather
#: than from `service` because `service` imports the renderer which imports this.
DEFAULT_JURISDICTION = "AU"

MONTH_RE = re.compile(r"^(\d{4})-(0[1-9]|1[0-2])$")
QUARTER_RE = re.compile(r"^(\d{4})-Q([1-4])$")


class PeriodError(ValueError):
    """The period string is not one this system knows how to bound."""


def period_bounds(period: str) -> tuple[date, date]:
    """Inclusive start and end dates for `YYYY-MM` or `YYYY-Qn`.

    Only two shapes are accepted. A free-text date range would let a caller
    quietly produce a return covering an arbitrary window and label it a
    period; named periods are checkable by a reader.
    """
    month = MONTH_RE.match(period)
    if month:
        year, mon = int(month.group(1)), int(month.group(2))
        start = date(year, mon, 1)
        end = date(year + (mon == 12), (mon % 12) + 1, 1) - timedelta(days=1)
        return start, end

    quarter = QUARTER_RE.match(period)
    if quarter:
        year, q = int(quarter.group(1)), int(quarter.group(2))
        start = date(year, 3 * (q - 1) + 1, 1)
        end_month = 3 * q
        end = date(year + (end_month == 12), (end_month % 12) + 1, 1) - timedelta(days=1)
        return start, end

    raise PeriodError(f"period {period!r} is not YYYY-MM or YYYY-Qn")


def period_label(period: str) -> str:
    start, end = period_bounds(period)
    if MONTH_RE.match(period):
        return start.strftime("%B %Y")
    return f"{period[5:]} {start.year} ({start:%d %b} – {end:%d %b %Y})"


def available_periods(
    session: Session,
    scenario: str | None = None,
    jurisdiction: str = DEFAULT_JURISDICTION,
) -> list[dict]:
    """Months that actually contain determinations, newest first.

    Derived from the data rather than from the calendar, so the reporting
    screen cannot offer a period that would render an empty document.

    Scoped by scenario and jurisdiction for the same reason the reports are: an
    unscoped count next to a scoped preview reads as a contradiction, and a
    reader who spots one stops believing the other figures on the screen.
    """
    stmt = (
        select(Decision.as_of)
        .where(_in_jurisdiction(jurisdiction))
        .order_by(Decision.as_of.desc())
    )
    if scenario:
        stmt = stmt.join(Client, Client.id == Decision.client_id).where(
            Client.scenario == scenario
        )
    counts = Counter(d.strftime("%Y-%m") for d in session.execute(stmt).scalars())
    return [
        {"period": key, "label": period_label(key), "decisions": count}
        for key, count in sorted(counts.items(), reverse=True)
    ]


def _in_jurisdiction(jurisdiction: str):
    """Decisions governed by one pack.

    A return is filed with one regulator, so it must count the determinations
    that regulator's pack governed and no others. Rows written before decisions
    recorded their jurisdiction are all from the single-jurisdiction era, which
    is why a null falls to the default rather than being excluded.
    """
    if jurisdiction == DEFAULT_JURISDICTION:
        return (Decision.pack_id.is_(None)) | (Decision.pack_id == jurisdiction)
    return Decision.pack_id == jurisdiction


def _decisions(
    session: Session, start: date, end: date, scenario: str | None, jurisdiction: str
) -> list[Decision]:
    stmt = (
        select(Decision)
        .where(Decision.as_of >= start, Decision.as_of <= end)
        .where(_in_jurisdiction(jurisdiction))
        .order_by(Decision.id)
    )
    if scenario:
        stmt = stmt.join(Client, Client.id == Decision.client_id).where(
            Client.scenario == scenario
        )
    return list(session.scalars(stmt))


def _reason_titles(session: Session, jurisdiction: str, versions: set[int]) -> dict[str, str]:
    """Reason-code titles drawn from every pack version present in the period.

    A period can straddle a pack change, so a single lookup against the current
    pack would silently drop the title of a code that only v1 defined.
    """
    # `DATA_MISSING` is raised by the evaluator on behalf of no regulator, so no
    # pack defines it and `pack.reason_codes` cannot supply its title. Seeded
    # first so a regime that *does* choose to word it itself still wins below —
    # the same precedence `engine.failing_reasons` applies on a reason card.
    titles: dict[str, str] = {DATA_MISSING: DATA_MISSING_TEXT["title"]}
    for version in sorted(versions):
        pack = packs_repo.by_version(session, jurisdiction, version)
        for code, body in pack.reason_codes.items():
            titles.setdefault(code, body.get("title", code))
    return titles


def _overrides(
    session: Session, start: date, end: date, scenario: str | None, jurisdiction: str
) -> list[Row[tuple[Override, Decision, Client, Asset]]]:
    """Overrides recorded in the window, with the decision they attach to."""
    start_at = datetime.combine(start, time.min, tzinfo=timezone.utc)
    end_at = datetime.combine(end, time.max, tzinfo=timezone.utc)
    stmt = (
        select(Override, Decision, Client, Asset)
        .join(Decision, Decision.id == Override.decision_id)
        .join(Client, Client.id == Decision.client_id)
        .join(Asset, Asset.id == Decision.asset_id)
        .where(Override.created_at >= start_at, Override.created_at <= end_at)
        .where(_in_jurisdiction(jurisdiction))
        .order_by(Override.created_at)
    )
    if scenario:
        stmt = stmt.where(Client.scenario == scenario)
    return list(session.execute(stmt))


def distribution_return(
    session: Session,
    *,
    period: str,
    jurisdiction: str = DEFAULT_JURISDICTION,
    scenario: str | None = None,
) -> dict:
    """Everything the periodic return states, as plain data.

    Returned as a dict rather than rendered directly so the same figures can be
    shown on screen before anyone commits them to a PDF. A document whose
    numbers cannot be inspected beforehand is a document nobody checks.
    """
    start, end = period_bounds(period)
    decisions = _decisions(session, start, end, scenario, jurisdiction)

    outcomes = Counter(d.outcome for d in decisions)
    pack_versions = Counter(d.pack_version for d in decisions)

    findings: Counter[tuple[str, str]] = Counter()
    for decision in decisions:
        for result in decision.rule_results["results"]:
            if not result["passed"] and result.get("reason_code"):
                findings[(result["rule_id"], result["reason_code"])] += 1

    titles = _reason_titles(session, jurisdiction, set(pack_versions) or {1})
    overrides = _overrides(session, start, end, scenario, jurisdiction)

    by_asset = Counter(d.snapshot["asset"]["symbol"] for d in decisions)
    clients_assessed = {d.client_id for d in decisions}

    return {
        "kind": "regulatory_return",
        "jurisdiction": jurisdiction,
        "period": period,
        "period_label": period_label(period),
        "period_start": start.isoformat(),
        "period_end": end.isoformat(),
        "scope_basis": "assessment date",
        "scenario": scenario,
        "decisions_total": len(decisions),
        "clients_assessed": len(clients_assessed),
        "outcomes": [
            {"outcome": key, "count": outcomes.get(key, 0)}
            for key in ("ALLOW", "REFER", "BLOCK")
        ],
        "by_asset": [
            {"symbol": symbol, "count": count} for symbol, count in by_asset.most_common()
        ],
        "findings": [
            {
                "rule_id": rule_id,
                "reason_code": code,
                "title": titles.get(code, code),
                "count": count,
            }
            for (rule_id, code), count in sorted(
                findings.items(), key=lambda kv: (-kv[1], kv[0][0])
            )
        ],
        "packs_in_force": [
            _pack_summary(session, jurisdiction, version, count)
            for version, count in sorted(pack_versions.items())
        ],
        "overrides_total": len(overrides),
        "chain": evidence.verify_chain(session),
    }


def _pack_summary(session: Session, jurisdiction: str, version: int, decisions: int) -> dict:
    pack = packs_repo.by_version(session, jurisdiction, version)
    return {
        "pack_id": pack.pack_id,
        "version": version,
        "effective_from": pack.effective_from.isoformat(),
        "effective_to": pack.effective_to.isoformat() if pack.effective_to else None,
        "signed_by": pack.signed_by,
        "decisions": decisions,
    }


def override_register(
    session: Session,
    *,
    period: str,
    jurisdiction: str = DEFAULT_JURISDICTION,
    scenario: str | None = None,
) -> dict:
    """Every override recorded in the period, with what it overrode.

    An override register that lists only the justification is a list of
    opinions. Each row carries the determination it displaced and the findings
    that determination rested on, so the justification can be read against it.
    """
    start, end = period_bounds(period)
    rows = _overrides(session, start, end, scenario, jurisdiction)

    versions = {decision.pack_version for _, decision, _, _ in rows}
    titles = _reason_titles(session, jurisdiction, versions or {1})

    entries = []
    for override, decision, client, asset in rows:
        findings = [
            {
                "rule_id": r["rule_id"],
                "reason_code": r["reason_code"],
                "title": titles.get(r["reason_code"], r["reason_code"]),
            }
            for r in decision.rule_results["results"]
            if not r["passed"] and r.get("reason_code")
        ]
        entries.append(
            {
                "override_id": override.id,
                "decision_id": decision.id,
                "client_id": client.id,
                "client_name": client.name,
                "asset_symbol": asset.symbol,
                "as_of": decision.as_of.isoformat(),
                "outcome": decision.outcome,
                "pack_version": decision.pack_version,
                "approver": override.approver,
                "justification": override.justification,
                "recorded_at": override.created_at.isoformat(),
                "findings": findings,
            }
        )

    approvers = Counter(e["approver"] for e in entries)
    pack_versions = Counter(e["pack_version"] for e in entries)
    return {
        "kind": "override_report",
        "packs_in_force": [
            _pack_summary(session, jurisdiction, version, count)
            for version, count in sorted(pack_versions.items())
        ],
        "jurisdiction": jurisdiction,
        "period": period,
        "period_label": period_label(period),
        "period_start": start.isoformat(),
        "period_end": end.isoformat(),
        # Not assessment date: an override can be recorded in a later period
        # than the determination it displaces, and each row prints both.
        "scope_basis": "date the override was recorded",
        "scenario": scenario,
        "overrides_total": len(entries),
        "by_outcome": [
            {"outcome": key, "count": sum(1 for e in entries if e["outcome"] == key)}
            for key in ("REFER", "BLOCK")
        ],
        "by_approver": [
            {"approver": name, "count": count} for name, count in approvers.most_common()
        ],
        "entries": entries,
        "chain": evidence.verify_chain(session),
    }


AUDIT_COLUMNS = ("id", "at", "actor", "action", "subject")


def audit_rows(
    session: Session, *, start: date | None = None, end: date | None = None
) -> list[dict]:
    """Audit events in id order, optionally bounded by date.

    `audit_events` is append-only — the database refuses UPDATE and DELETE on
    it — but unlike `decisions` it is *not* hash-chained. Deleting the whole
    table and starting again would leave no arithmetic trace. Callers must say
    so rather than let a reader assume the export carries the same guarantee
    the decision chain does.
    """
    stmt = select(AuditEvent).order_by(AuditEvent.id)
    if start:
        stmt = stmt.where(AuditEvent.at >= datetime.combine(start, time.min, tzinfo=timezone.utc))
    if end:
        stmt = stmt.where(AuditEvent.at <= datetime.combine(end, time.max, tzinfo=timezone.utc))

    return [
        {
            "id": row.id,
            "at": row.at.isoformat(),
            "actor": row.actor,
            "action": row.action,
            "subject": row.subject,
        }
        for row in session.scalars(stmt)
    ]
