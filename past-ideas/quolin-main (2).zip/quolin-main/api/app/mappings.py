"""How one customer's field names become ours, and when that changed.

Every firm calls things something different. One sends `risk_band`, another
`loss_tolerance`, a third `CapacityForLossBand`. Renaming them by hand in a
spreadsheet before each drop is what integrations do when nobody gives them
anywhere to put the mapping, and it is where a nightly job silently starts
loading the wrong column.

**Versioned, because a mapping change can change determinations.** If
`risk_band` stops meaning `loss_capacity_band` and starts meaning something
else, every decision after that is made on different facts — and explaining a
determination made last March requires knowing which mapping was in force when
it was made. So the version is recorded on the run that used it rather than
inferred from dates, and a change is an audited event rather than an edit.

**Transforms are a closed list, and a short one.** A mapping is content authored
by an integrations engineer, and the moment it can express arbitrary computation
it is code that nobody reviews and no test covers. The whole list is below.

**`dollars_to_cents` is the one that earns its place.** Firms send money in
dollars because that is what their systems hold, and we need integer cents
because invariant 3 says a determination must reproduce exactly years later.

Getting that conversion wrong is not a rounding annoyance, and it is worth being
exact about how it fails, because the obvious example does not:
`int(float("25000.50") * 100)` is `2500050`, correctly — a half is exactly
representable in binary. `int(float("19.99") * 100)` is **1998**, and
`int(float("0.29") * 100)` is **28**. So the float route is right on the amounts
somebody would test with by hand and wrong on ordinary ones, which is the worst
way for a conversion to be broken: nothing looks wrong until somebody replays a
determination years later and it does not reproduce.

`Decimal` is used here for that reason, and a value with more precision than
cents is refused rather than rounded — rounding somebody's money without telling
them is not ours to do.
"""

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .identity import new_id
from .models import IntegrationMapping

#: The feeds a mapping may govern. A firm's CRM and its custodian do not agree
#: on field names either, so the mapping is per source rather than per tenant.
SOURCES = ("clients", "positions")


class MappingError(ValueError):
    """A mapping cannot be applied, or would produce a value we will not store."""


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ----------------------------------------------------------------- transforms --


def _identity(raw: str) -> str:
    return raw


def _dollars_to_cents(raw: str) -> str:
    """`"25000.50"` becomes `"2500050"`, exactly.

    `Decimal` rather than `float`, and the difference is the whole point.
    `int(float("19.99") * 100)` is 1998 and `int(float("0.29") * 100)` is 28 —
    while `25000.50`, the amount anybody would test with, converts correctly
    either way. A book loaded through the float route is therefore a book of
    determinations that will not reproduce, with nothing to suggest it
    (invariant 3).

    More precision than cents is refused rather than rounded. A tenth of a cent
    is not a rounding error we may silently absorb on somebody's behalf — it
    means the source is not denominated the way the mapping claims.
    """
    text = (raw or "").strip().replace(",", "").replace("$", "")
    if not text:
        return ""
    try:
        amount = Decimal(text)
    except InvalidOperation as exc:
        raise MappingError(f"{raw!r} is not an amount") from exc

    cents = amount * 100
    if cents != cents.to_integral_value():
        raise MappingError(
            f"{raw!r} is more precise than whole cents. Quolin stores money as an "
            "integer number of cents, so rounding this is a decision about "
            "somebody's money that we will not take on your behalf."
        )
    return str(int(cents))


def _boolean_from_yes_no(raw: str) -> str:
    text = (raw or "").strip().lower()
    if text in {"y", "yes", "true", "1", "t"}:
        return "true"
    if text in {"n", "no", "false", "0", "f", ""}:
        return "false"
    raise MappingError(f"{raw!r} is not a yes/no value")


def _upper(raw: str) -> str:
    return (raw or "").strip().upper()


def _lower(raw: str) -> str:
    return (raw or "").strip().lower()


#: Every transform a mapping may name. Closed on purpose: a mapping that could
#: express arbitrary computation would be code nobody reviews and no test covers,
#: sitting between a customer's book and a regulated determination.
TRANSFORMS = {
    "none": _identity,
    "dollars_to_cents": _dollars_to_cents,
    "yes_no_to_boolean": _boolean_from_yes_no,
    "uppercase": _upper,
    "lowercase": _lower,
}


# ------------------------------------------------------------------- reading --


def active(session: Session, source: str) -> IntegrationMapping | None:
    """The mapping in force for this tenant and feed, or None.

    None is a supported state and the common one: a firm that sends our column
    names needs no mapping, and inventing an identity mapping for them would be
    a row somebody has to maintain to change nothing.
    """
    return session.scalars(
        select(IntegrationMapping)
        .where(IntegrationMapping.source == source)
        .order_by(IntegrationMapping.version.desc())
    ).first()


def record(
    session: Session,
    *,
    source: str,
    fields: dict[str, Any],
    created_by: str,
    note: str = "",
) -> IntegrationMapping:
    """Write a new version. Never edits the one in force.

    A mapping change is a new version rather than an update, for the same reason
    a pack change is: a determination made last March was made under the mapping
    that was in force then, and an edited row would make that unanswerable. The
    old version stays, and every import run names the version it used.
    """
    if source not in SOURCES:
        raise MappingError(f"unknown source {source!r}. Known: {', '.join(SOURCES)}")

    for their_field, rule in fields.items():
        transform = (rule or {}).get("transform", "none")
        if transform not in TRANSFORMS:
            raise MappingError(
                f"{their_field!r} names the transform {transform!r}, which does not "
                f"exist. Available: {', '.join(sorted(TRANSFORMS))}."
            )
        if not (rule or {}).get("canonical"):
            raise MappingError(f"{their_field!r} does not say which field it maps to")

    current = active(session, source)
    row = IntegrationMapping(
        id=new_id("map"),
        source=source,
        version=(current.version + 1) if current else 1,
        fields=fields,
        effective_from=_now(),
        created_at=_now(),
        created_by=created_by,
        note=note,
    )
    session.add(row)
    session.flush()

    from . import service

    service.audit(
        session,
        "integration.mapping.recorded",
        f"{source} mapping v{row.version}: {len(fields)} field(s) mapped",
    )
    return row


# ------------------------------------------------------------------ applying --


def apply_to_rows(
    mapping: IntegrationMapping | None, rows: list[dict[str, str]]
) -> tuple[list[dict[str, str]], list[dict[str, Any]]]:
    """Rename and transform a firm's rows into ours. Returns rows and per-row errors.

    Errors are per row rather than raised, for the same reason the batch gateway
    reports them that way: eleven bad amounts must not take four thousand good
    rows down with them, and a transform failure is exactly a bad row.

    A column the mapping does not mention passes through untouched. That is
    deliberate — a firm that sends fifteen of our column names and two of theirs
    should have to map two, not seventeen.
    """
    if mapping is None:
        return rows, []

    rules = mapping.fields or {}
    out: list[dict[str, str]] = []
    errors: list[dict[str, Any]] = []

    for index, raw in enumerate(rows):
        # Row 1 is the header, so the first data row is row 2 — the number the
        # author sees in their spreadsheet.
        row_number = index + 2
        translated: dict[str, str] = {}
        failed = False

        for column, value in raw.items():
            rule = rules.get(column)
            if rule is None:
                translated[column] = value
                continue
            transform = TRANSFORMS[rule.get("transform", "none")]
            try:
                translated[rule["canonical"]] = transform(value)
            except MappingError as exc:
                errors.append(
                    {
                        "row": row_number,
                        "column": column,
                        "message": (
                            f"{exc} (mapped to {rule['canonical']!r} by "
                            f"{mapping.source} mapping v{mapping.version})"
                        ),
                    }
                )
                failed = True

        if not failed:
            out.append(translated)

    return out, errors


def describe(mapping: IntegrationMapping | None) -> dict[str, Any]:
    """A mapping as a screen or an API shows it."""
    if mapping is None:
        return {"version": None, "fields": {}, "note": "No mapping — send our column names."}
    return {
        "version": mapping.version,
        "source": mapping.source,
        "effective_from": mapping.effective_from.isoformat(),
        "created_by": mapping.created_by or "unrecorded",
        "note": mapping.note,
        "fields": mapping.fields,
    }
