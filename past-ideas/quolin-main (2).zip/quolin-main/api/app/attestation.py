"""What makes a signature a review, rather than a click by somebody with a role.

Three places already decide whether a name counts as a real signatory: the CHECK
constraint in migration 0025, `engine.pack.is_production_grade`, and — from
Q-02 — the moment a draft is published. They must agree, and they cannot share a
module: `app/watch` may not import the engine (invariant 6, enforced by
`test_watch.py` and `scripts/guard_no_watch_in_engine.sh`), and the engine is a
pure evaluator that imports nothing from the application around it.

So this module holds the rule in the one form the watch service can reach, and
`test_signing_produces_reviewed_content.py` asserts it agrees with both of the
others. Drift becomes a failing test rather than a pack that one layer thinks is
reviewed and another does not.

**The rule has two halves and the second is the one that was missing.** A
signature names a person, and it carries the qualification that makes their name
worth having. `pack_signatory` is a role; being competent to attest for a regime
is a fact about an engagement, and it is recorded on the grant as
`qualification_ref`. Every signatory in this repository today has a placeholder
there — `[illustrative — no engagement in place]` — which is the honest state
and must not produce reviewed content. A signature stamped REVIEWED on the
strength of the role alone would let anybody holding it mint production-grade
rule content with nobody qualified behind it, which is exactly what migration
0025's constraint exists to make unstorable.

Placeholders are recognised by shape rather than by exact string, because the
next placeholder will be spelled differently and will still be a placeholder.
"""

from __future__ import annotations

#: The three values a pack body may declare. Restated rather than imported from
#: `engine.pack` because of the import boundary above; the test named in the
#: docstring asserts they are the same three strings.
REVIEWED = "REVIEWED"
PENDING_REVIEW = "PENDING_REVIEW"
ILLUSTRATIVE = "ILLUSTRATIVE"

#: Substrings that mark a value as a stand-in, matched case-insensitively.
#: A leading `[` is handled separately: the bracketed convention is a whole
#: shape rather than a word.
PLACEHOLDER_MARKERS = ("ILLUSTRATIVE", "PENDING ENGAGEMENT", "TBC", "TBD")


def is_placeholder(value: str | None) -> bool:
    """Whether this reads as a stand-in rather than as a real name or reference.

    Empty counts. A blank in the place a signatory's name should go is worse
    than an absent one, because it looks like the gate was passed — which is the
    reasoning `drafts.sign` already applies to an empty signatory.
    """
    text = (value or "").strip()
    if not text:
        return True
    if text.startswith("["):
        return True
    upper = text.upper()
    return any(marker in upper for marker in PLACEHOLDER_MARKERS)


def signature_is_qualified(signatory: str | None, qualification_ref: str | None) -> bool:
    """Whether this signature can carry content to `REVIEWED`.

    Both halves, and both by the same rule. A real name with a placeholder
    qualification is somebody who has not been engaged; a real qualification with
    a bracketed name is a record nobody can be asked about.
    """
    return not is_placeholder(signatory) and not is_placeholder(qualification_ref)


def status_for(signatory: str | None, qualification_ref: str | None) -> str:
    """The `content_status` a pack published from this signature should carry.

    `PENDING_REVIEW` rather than `ILLUSTRATIVE` when the signature does not
    qualify: the content is honest work awaiting a specialist, which is a
    different and truer claim than "written to exercise the architecture".
    """
    return REVIEWED if signature_is_qualified(signatory, qualification_ref) else PENDING_REVIEW
