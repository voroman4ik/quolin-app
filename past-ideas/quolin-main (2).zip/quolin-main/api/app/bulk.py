"""Re-checking a whole book, and saying exactly what changed.

§S8. Three things a firm needs and one constraint that shapes all of them.

**The three things.** A book gets re-checked when a new pack version becomes
effective, when a client's profile changes, and on a schedule the pack
configures. Each is a `trigger` on the run, recorded rather than inferred:
"why was my whole book re-checked on a Tuesday" is the first question a customer
asks about one of these, and an answer assembled afterwards from timestamps is a
reconstruction.

**The constraint.** Determinations are hash-chained per tenant — each one's
`prev_hash` is the last one's hash — so appends within a tenant are serial. Two
workers sweeping one tenant would splice its chain, and append-only would
prevent the repair. Chunks therefore exist for *resumability and progress*, not
for parallelism inside a tenant. Parallelism is across tenants, where the chains
are separate. This is a real limit on throughput and it is the price of the
guarantee that makes the evidence worth having.

**Idempotency, twice over.** One transaction per chunk, so a worker killed
mid-chunk leaves nothing half-written and the chunk is simply claimed again. And
a unique index on `decisions (run_id, client_id, asset_id)` for the case the
transaction cannot cover: a chunk that committed and a process that died before
it could say so. §S8's gate asks for a mid-run kill to resume without
double-recording; these are the two independent reasons it does.

**What a delta is.** A pair whose *outcome* changed — ALLOW to REFER, REFER to
BLOCK. Not a pair whose reasons were reworded or whose rule ids moved: a
compliance officer acts on outcomes, and a delta report that listed cosmetic
changes would train them to skim it. The rule that made the difference is
recorded beside the change, because "212 clients moved to REFER" is a headline
and "under AU-CONC-01" is what a regulator asks next.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from typing import Any, Iterable

from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from . import advance, business_time, observability, packs_repo, service
from .models import Asset, Client, Decision, EvalChunk, EvalDelta, EvalRun

#: Why a run happened. Recorded on the run, not worked out later.
PACK_EFFECTIVE = "pack_effective"
PROFILE_CHANGE = "profile_change"
PERIODIC = "periodic"
MANUAL = "manual"
TRIGGERS = (PACK_EFFECTIVE, PROFILE_CHANGE, PERIODIC, MANUAL)

PLANNED = "planned"
RUNNING = "running"
DONE = "done"
FAILED = "failed"

QUEUED = "queued"

#: Pairs per chunk. Small enough that a killed worker loses little and that one
#: transaction stays modest; large enough that the bookkeeping is a rounding
#: error against the evaluation. Five hundred determinations is a few seconds.
CHUNK_SIZE = 500

#: How many times a chunk is retried before the run is left failed with the
#: error on the row. Same reasoning as the artefact queue: what fails here fails
#: transiently or fails identically forever.
MAX_ATTEMPTS = 3

#: How long a worker's claim on a chunk holds. Longer than the artefact queue's
#: because a chunk is five hundred determinations rather than one document.
LEASE = timedelta(minutes=30)


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ----------------------------------------------------------------- planning --


def pairs_for(
    session: Session, *, jurisdiction: str = "", client_ids: Iterable[str] | None = None
) -> list[list[str]]:
    """Every client-and-asset pair a run should cover, in a stable order.

    Ordered by client then asset so that a run's chunks are the same chunks on
    a re-plan, and so a half-finished run's progress means something to a reader
    watching it.

    Assets come from the shelf rather than from what each client has been
    assessed for before. A client who has never been assessed for an asset is
    exactly the case a periodic review exists to catch.
    """
    clients = select(Client.id).order_by(Client.id)
    if jurisdiction:
        clients = clients.where(Client.jurisdiction == jurisdiction.upper())
    if client_ids is not None:
        wanted = list(client_ids)
        if not wanted:
            return []
        clients = clients.where(Client.id.in_(wanted))

    assets = list(session.scalars(select(Asset.id).order_by(Asset.id)))
    return [
        [client_id, asset_id]
        for client_id in session.scalars(clients)
        for asset_id in assets
    ]


def plan(
    session: Session,
    *,
    trigger: str,
    jurisdiction: str = "",
    as_of: date | None = None,
    client_ids: Iterable[str] | None = None,
    requested_by: str = "",
    note: str = "",
    dry_run: bool = False,
    against_version: int | None = None,
) -> EvalRun:
    """Work out what a run will cover and write its chunks. Evaluates nothing.

    Planned up front rather than streamed, so that `pairs_total` is a real
    number from the moment the run exists. A progress bar that discovers its own
    denominator is one nobody can act on: "1,400 done" answers nothing without
    "of 9,600".
    """
    if trigger not in TRIGGERS:
        raise ValueError(f"unknown trigger {trigger!r}. Known: {', '.join(TRIGGERS)}")

    pairs = pairs_for(session, jurisdiction=jurisdiction, client_ids=client_ids)
    run = EvalRun(
        trigger=trigger,
        jurisdiction=jurisdiction.upper(),
        as_of=as_of or business_time.business_today(session),
        status=PLANNED,
        requested_by=requested_by,
        pairs_total=len(pairs),
        note=note,
        dry_run=dry_run,
        against_version=against_version,
    )
    session.add(run)
    session.flush()

    for seq, start in enumerate(range(0, len(pairs), CHUNK_SIZE)):
        session.add(
            EvalChunk(
                run_id=run.id,
                seq=seq,
                pairs=pairs[start : start + CHUNK_SIZE],
                status=QUEUED,
            )
        )
    session.flush()
    return run


# ---------------------------------------------------------------- executing --


def claim(session: Session, *, run_id: int | None = None, now: datetime | None = None):
    """Take the lowest-numbered chunk nobody holds, or return None.

    `FOR UPDATE SKIP LOCKED`, as with the artefact queue — and here the point is
    not parallelism within a tenant, which the chain forbids, but that a second
    worker started by an over-eager scheduler takes nothing rather than
    duplicating work.

    A chunk whose lease has expired is claimable again. That is what turns a
    killed worker into a delay.
    """
    now = now or _now()
    stale = now - LEASE

    stmt = (
        select(EvalChunk)
        .where(
            (EvalChunk.status == QUEUED)
            | (
                (EvalChunk.status == RUNNING)
                & (EvalChunk.started_at.is_not(None))
                & (EvalChunk.started_at < stale)
            )
        )
        .where(EvalChunk.attempts < MAX_ATTEMPTS)
        .order_by(EvalChunk.run_id, EvalChunk.seq)
        .limit(1)
        .with_for_update(skip_locked=True)
    )
    if run_id is not None:
        stmt = stmt.where(EvalChunk.run_id == run_id)

    chunk = session.scalars(stmt).first()
    if chunk is None:
        return None

    chunk.status = RUNNING
    chunk.started_at = now
    chunk.attempts += 1
    session.flush()
    return chunk


def baseline_for(
    session: Session, run: EvalRun, pairs: list[list[str]]
) -> dict[tuple[str, str], Decision]:
    """The determination in force for each pair before the run touched it.

    One query for the whole chunk rather than one per pair. Five hundred
    round-trips to answer five hundred questions of the same shape is the kind
    of thing that reads fine and turns a twelve-minute sweep into an hour.

    Excludes this run's own output, so a chunk retried after a partial commit
    compares against the same baseline it did the first time rather than against
    itself — which would report every pair as unchanged and quietly empty the
    delta report.
    """
    if not pairs:
        return {}

    clients = {client_id for client_id, _ in pairs}
    assets = {asset_id for _, asset_id in pairs}
    wanted = {(client_id, asset_id) for client_id, asset_id in pairs}

    # `DISTINCT ON` returns one row per pair — the newest — rather than the
    # whole history for every client in the chunk.
    #
    # The first version read everything and reduced in Python, which was correct
    # and quietly unbounded: a client assessed daily for two years brings back
    # seven hundred rows to answer one question, and the sweep gets slower every
    # month the firm operates. It showed up as a benchmark that drifted downward
    # as the test database filled, which is exactly how this would have been
    # noticed in production a year late.
    rows = session.scalars(
        select(Decision)
        .where(
            Decision.client_id.in_(clients),
            Decision.asset_id.in_(assets),
            (Decision.run_id.is_(None)) | (Decision.run_id != run.id),
        )
        .distinct(Decision.client_id, Decision.asset_id)
        .order_by(Decision.client_id, Decision.asset_id, Decision.id.desc())
    )
    return {
        (row.client_id, row.asset_id): row
        for row in rows
        if (row.client_id, row.asset_id) in wanted
    }


#: Which outcome a rule result asserts, from most severe. A determination's
#: outcome is the worst any rule reached, so the rule that decided it is the
#: first one that reached that outcome.
_SEVERITY = {"BLOCK": 0, "REFER": 1, "ALLOW": 2}


def _deciding_rule(decision: Decision) -> tuple[str, str]:
    """The rule that produced the outcome, and its reason code.

    A rule result records `passed` and the `outcome` it asserts — not a `fired`
    flag, which is what this looked for first. Every delta came back with a
    blank rule, and the test that was supposed to catch that passed, because a
    sweep of an unchanged book has no deltas to be blank. Both are fixed; this
    is the half that was actually wrong.

    The rule that decided is the first *failing* one that reached the
    determination's own outcome. First, because that is the one a reason card
    leads with and the one an officer will be asked about. A determination where
    nothing failed is an ALLOW and has no deciding rule, which is the honest
    answer rather than a blank that looks like missing data.

    **Every regime, not only the governing one.** A cross-border determination
    is BLOCK because *some* applicable pack said so, and it is routinely not the
    licensee's own. The first version of this read the governing pack's results
    alone and returned nothing for exactly those cases — a delta report saying a
    client moved to BLOCK with no rule beside it, which is the question a
    regulator asks and the answer we would not have had.
    """
    results = list((decision.rule_results or {}).get("results", []))
    for block in ((decision.rule_results or {}).get("other_jurisdictions") or {}).values():
        results.extend(block.get("results", []))

    for result in results:
        if result.get("passed"):
            continue
        if str(result.get("outcome") or "") == decision.outcome:
            return (
                str(result.get("rule_id") or ""),
                str(result.get("reason_code") or ""),
            )
    return "", ""


def _ask_only(
    session: Session,
    run: EvalRun,
    *,
    client_id: str,
    asset_id: str,
    shelf: dict[str, Any],
    tenant: Any | None = None,
    review_overdue: dict[str, Any] | None = None,
) -> tuple[str, int | None, str, str, None]:
    """What the answer *would* be, without recording that it was asked.

    The evaluation is the real one — same function, same snapshot, same rules —
    performed inside a savepoint that is then rolled back. Writing a second,
    compute-only evaluation path would be the more obvious design and the worse
    one: two paths that must agree forever, where the one nobody runs in anger
    is the one that drifts.

    So the determination is genuinely made and genuinely discarded. What
    survives is the outcome, which is all a "what would change" report needs.
    """
    savepoint = session.begin_nested()
    try:
        decision = service.evaluate(
            session,
            client_id=client_id,
            asset_id=asset_id,
            as_of=run.as_of,
            run_id=run.id,
            shelf=shelf,
            tenant=tenant,
            review_overdue_by_regime=review_overdue,
        )
        session.flush()
        outcome = decision.outcome
        pack_version = decision.pack_version
        rule_id, reason_code = _deciding_rule(decision)
    finally:
        # Rolled back whether or not the evaluation succeeded. A dry run that
        # left a determination behind would be the exact thing it exists not to
        # do, and the failure would be silent.
        savepoint.rollback()
    return outcome, pack_version, rule_id, reason_code, None


def run_chunk(session: Session, chunk: EvalChunk) -> dict[str, int]:
    """Timed, per FP3-16 — a sweep getting slower is §S9's alerting signal."""
    with observability.timed(
        "bulk.chunk", "evaluated a chunk", run_id=chunk.run_id, chunk_id=chunk.id
    ):
        return _run_chunk(session, chunk)


def _run_chunk(session: Session, chunk: EvalChunk) -> dict[str, int]:
    """Evaluate every pair in one chunk, recording what changed.

    Deliberately not clever about the failure of a single pair: a client whose
    positions file has gone missing should not cost the other four hundred and
    ninety-nine. The pair is counted as a failure, the run carries the count,
    and the chunk still finishes.
    """
    run = session.get(EvalRun, chunk.run_id)
    if run is None:
        raise LookupError(f"chunk {chunk.id} belongs to no run")

    # Resolved once for the whole chunk, and passed to every evaluation. This is
    # a consistency decision before it is a speed one: a pack version published
    # halfway through a sweep would otherwise leave part of the book assessed
    # under v4 and the rest under v5, and the delta report would be describing
    # two changes at once with no way to tell them apart.
    shelf = packs_repo.active_all(session, run.as_of)
    # Resolved once per chunk beside the shelf, and for the same reason: a
    # lookup per pair is five hundred reads to answer a question whose answer
    # cannot change mid-chunk.
    from .models import Tenant

    tenant = session.get(Tenant, run.tenant_id)

    # FP3-17, resolved here for the third time and the same reason. A pinned
    # firm whose review window has closed carries a field on every
    # determination; the answer is per (tenant, regime) and cannot change
    # mid-chunk, so a lookup per pair is five hundred reads for one answer.
    review_overdue = {
        code: advance.overdue_for_snapshot(session, jurisdiction=code)
        for code in shelf
    }

    pairs = [list(pair) for pair in (chunk.pairs or [])]
    baseline = baseline_for(session, run, pairs)

    tally = {"done": 0, "changed": 0, "failed": 0}
    for client_id, asset_id in pairs:
        before = baseline.get((client_id, asset_id))
        try:
            if run.dry_run:
                outcome, pack_version, rule_id, reason_code, decision_id = _ask_only(
                    session,
                    run,
                    client_id=client_id,
                    asset_id=asset_id,
                    shelf=shelf,
                    tenant=tenant,
                    review_overdue=review_overdue,
                )
            else:
                decision = service.evaluate(
                    session,
                    client_id=client_id,
                    asset_id=asset_id,
                    as_of=run.as_of,
                    run_id=run.id,
                    shelf=shelf,
                    tenant=tenant,
                    # Keyed per regime, because the governing pack is not known
                    # until the snapshot is built. A dict lookup rather than a
                    # query per pair is the whole point.
                    review_overdue_by_regime=review_overdue,
                )
                outcome = decision.outcome
                pack_version = decision.pack_version
                rule_id, reason_code = _deciding_rule(decision)
                decision_id = decision.id
        except IntegrityError:
            # The unique index refused a second determination for this pair in
            # this run: the chunk ran before and committed. Not an error — it is
            # the guarantee working — but the transaction is poisoned and the
            # caller has to start it again.
            raise
        except Exception as exc:  # noqa: BLE001 — see the docstring
            tally["failed"] += 1
            run.note = f"{client_id}/{asset_id}: {type(exc).__name__}: {exc}"[:2000]
            continue

        tally["done"] += 1

        if before is not None and before.outcome != outcome:
            session.add(
                EvalDelta(
                    run_id=run.id,
                    client_id=client_id,
                    asset_id=asset_id,
                    from_outcome=before.outcome,
                    to_outcome=outcome,
                    from_pack_version=before.pack_version,
                    to_pack_version=pack_version,
                    rule_id=rule_id,
                    reason_code=reason_code,
                    decision_id=decision_id,
                )
            )
            tally["changed"] += 1

    chunk.status = DONE
    chunk.finished_at = _now()
    chunk.last_error = ""

    run.status = RUNNING
    run.started_at = run.started_at or _now()
    run.pairs_done += tally["done"]
    run.changed += tally["changed"]
    run.failures += tally["failed"]
    session.flush()
    return tally


def settle(session: Session, run_id: int) -> EvalRun | None:
    """Mark a run finished once no chunk is outstanding.

    Separate from `run_chunk` because the last chunk does not know it is the
    last one — another worker may still hold one — and a run that declared
    itself done while work was outstanding would be worse than one that took a
    moment to notice.
    """
    run = session.get(EvalRun, run_id)
    if run is None:
        return None

    outstanding = session.scalar(
        select(func.count())
        .select_from(EvalChunk)
        .where(EvalChunk.run_id == run_id, EvalChunk.status.in_((QUEUED, RUNNING)))
    )
    if outstanding:
        return run

    exhausted = session.scalar(
        select(func.count())
        .select_from(EvalChunk)
        .where(EvalChunk.run_id == run_id, EvalChunk.attempts >= MAX_ATTEMPTS)
        .where(EvalChunk.status != DONE)
    )
    run.status = FAILED if exhausted else DONE
    run.finished_at = _now()
    session.flush()

    # One event for the whole sweep. Failure is announced too: a re-check that
    # was asked for and did not happen is exactly what a customer must not have
    # to notice for themselves.
    service._tell_the_customers_systems(
        session,
        "bulk.completed",
        f"run:{run.id}",
        {
            "run_id": run.id,
            "trigger": run.trigger,
            "jurisdiction": run.jurisdiction or "all",
            "status": run.status,
            "as_of": run.as_of.isoformat(),
            "pairs_total": run.pairs_total,
            "pairs_done": run.pairs_done,
            "changed": run.changed,
            "failures": run.failures,
            "moves": stats(session, run.id)["moves"],
        },
    )
    return run


def drain(session: Session, *, run_id: int | None = None, limit: int = 1000) -> dict[str, int]:
    """Work chunks until there are none, committing each on its own.

    One transaction per chunk: a worker killed on the ninth keeps the eight that
    finished, and its claim on the ninth expires for somebody else to take. A
    single transaction over a whole run would lose everything and hold a claim
    on all of it while it ran.
    """
    totals = {"chunks": 0, "done": 0, "changed": 0, "failed": 0}
    touched: set[int] = set()

    for _ in range(limit):
        chunk = claim(session, run_id=run_id)
        if chunk is None:
            break
        # Committed before the work, so the attempt survives a rollback. Without
        # it a chunk that fails identically every time is retried forever — the
        # artefact queue learned this the same way.
        chunk_id, this_run = chunk.id, chunk.run_id
        session.commit()

        claimed = session.get(EvalChunk, chunk_id)
        if claimed is None:  # pragma: no cover — the row was just committed
            continue
        try:
            tally = run_chunk(session, claimed)
        except Exception as exc:  # noqa: BLE001 — a worker survives one bad chunk
            session.rollback()
            failed = session.get(EvalChunk, chunk_id)
            if failed is not None:
                failed.status = FAILED if failed.attempts >= MAX_ATTEMPTS else QUEUED
                failed.last_error = f"{type(exc).__name__}: {exc}"[:2000]
                failed.started_at = None if failed.status == QUEUED else failed.started_at
                session.commit()
            continue

        session.commit()
        totals["chunks"] += 1
        for key in ("done", "changed", "failed"):
            totals[key] += tally[key]
        touched.add(this_run)

    for finished in touched:
        settle(session, finished)
        session.commit()
    return totals


# ------------------------------------------------------------------ reading --


def stats(session: Session, run_id: int) -> dict[str, Any]:
    """Per-run stats, which §S8 asks for by name."""
    run = session.get(EvalRun, run_id)
    if run is None:
        raise LookupError(f"no run {run_id}")

    by_status: dict[str, int] = {
        str(status): int(count)
        for status, count in session.execute(
            select(EvalChunk.status, func.count())
            .where(EvalChunk.run_id == run_id)
            .group_by(EvalChunk.status)
        ).all()
    }
    moves = session.execute(
        select(EvalDelta.from_outcome, EvalDelta.to_outcome, func.count())
        .where(EvalDelta.run_id == run_id)
        .group_by(EvalDelta.from_outcome, EvalDelta.to_outcome)
        .order_by(func.count().desc())
    ).all()

    return {
        "id": run.id,
        "trigger": run.trigger,
        "jurisdiction": run.jurisdiction or "all",
        "as_of": run.as_of.isoformat(),
        "status": run.status,
        "requested_by": run.requested_by,
        "requested_at": run.requested_at.isoformat(),
        "started_at": run.started_at.isoformat() if run.started_at else None,
        "finished_at": run.finished_at.isoformat() if run.finished_at else None,
        "dry_run": run.dry_run,
        "against_version": run.against_version,
        "pairs_total": run.pairs_total,
        "pairs_done": run.pairs_done,
        "changed": run.changed,
        "failures": run.failures,
        "chunks": by_status,
        # The headline a compliance officer repeats: "212 clients moved to
        # REFER". Grouped by the move rather than by the destination, because
        # ALLOW→REFER and BLOCK→REFER are not the same news.
        "moves": [
            {"from": frm, "to": to, "count": count} for frm, to, count in moves
        ],
        "note": run.note,
    }


def deltas(session: Session, run_id: int, *, limit: int = 500) -> list[dict[str, Any]]:
    """What changed, worst move first.

    A move *to* BLOCK is read before a move to ALLOW: one of them is a client
    who can no longer do something they could yesterday, and the other is good
    news that can wait.
    """
    severity = {"BLOCK": 0, "REFER": 1, "ALLOW": 2}
    rows = sorted(
        session.scalars(select(EvalDelta).where(EvalDelta.run_id == run_id).limit(limit)),
        key=lambda d: (severity.get(d.to_outcome, 3), d.client_id, d.asset_id),
    )
    return [
        {
            "client_id": row.client_id,
            "asset_id": row.asset_id,
            "from": row.from_outcome,
            "to": row.to_outcome,
            "from_pack_version": row.from_pack_version,
            "to_pack_version": row.to_pack_version,
            "rule_id": row.rule_id,
            "reason_code": row.reason_code,
            "decision_id": row.decision_id,
        }
        for row in rows
    ]


# ----------------------------------------------------------------- triggers --
#
# §S8 names three things that should re-check a book. They are functions rather
# than a scheduler's business because each has a different shape, and the
# differences matter more than the similarity.


def on_pack_effective(
    session: Session,
    *,
    tenant_id: str,
    jurisdiction: str,
    version: int,
    requested_by: str = "",
) -> EvalRun | None:
    """A new pack version became effective. Re-check the book — or preview it.

    Which of those depends on the tenant's advance policy, and getting it the
    wrong way round would be a serious error in both directions.

    An **auto** tenant's book genuinely moves the moment the version is
    effective, so their determinations are re-made and recorded: their evidence
    should say what their rules now say.

    A **pinned** tenant has not adopted the version. Recording determinations
    under it would put evidence in their chain contradicting the version they
    are actually on. What they need is the *preview* — a dry run against the new
    version, which is the delta report their Stage 5 review window is for.
    """
    from . import advance
    from .models import Tenant

    # Only the version actually in force. `advance.sweep` notices every
    # effective version a tenant has not been told about, which on a fresh
    # deployment includes superseded ones — and re-checking a book against rules
    # that were replaced two years ago produces a delta report about history.
    in_force = packs_repo.active_rows(
        session, business_time.business_today(session)
    ).get(jurisdiction.upper())
    if in_force is None or in_force.version != version:
        return None

    policy, _window = advance.policy_for(session.get(Tenant, tenant_id))
    pinned = policy == advance.PINNED

    run = plan(
        session,
        trigger=PACK_EFFECTIVE,
        jurisdiction=jurisdiction,
        requested_by=requested_by,
        dry_run=pinned,
        against_version=version if pinned else None,
        note=(
            f"{jurisdiction} v{version} became effective; "
            + ("preview for review before taking it" if pinned else "book re-checked")
        ),
    )
    return _discard_if_empty(session, run)


def _discard_if_empty(session: Session, run: EvalRun) -> EvalRun | None:
    """Throw away a run with nothing to do.

    A tenant who advises in three regimes gets a fourth regime's pack becoming
    effective too, and a run over zero pairs is a row somebody has to open to
    discover it means nothing. Silence is the right answer.
    """
    if run.pairs_total:
        return run
    session.delete(run)
    session.flush()
    return None


def on_profile_change(
    session: Session, *, client_id: str, requested_by: str = ""
) -> EvalRun | None:
    """A client's own facts changed, so their answers may have.

    Scoped to that client rather than the book. A profile change is not a reason
    to re-check nine thousand other people, and a sweep that did would bury the
    one client whose answer moved in a run that took four minutes.

    Returns None when the client has no pairs to check — a client with no
    assessable assets is not an error, and a run over nothing would be a row
    somebody has to explain.
    """
    return on_profiles_changed(
        session,
        client_ids=[client_id],
        requested_by=requested_by,
        note=f"{client_id}'s profile changed",
    )


def on_profiles_changed(
    session: Session,
    *,
    client_ids: Iterable[str],
    requested_by: str = "",
    note: str = "",
) -> EvalRun | None:
    """The same trigger for several clients at once, as **one** run.

    The CSV importer rewrites a whole book in a single request, so it needs the
    plural. One run over the changed subset rather than one run per changed row:
    a firm re-loading nine thousand clients where forty moved wants a single
    re-check of forty, and forty runs would be forty rows somebody has to open
    to discover they are all the same import.

    Which is also why this is not simply `plan` at the call site. "These
    clients' facts changed" is one event with one meaning, and both callers
    should be saying the same thing — `on_profile_change` above is this function
    with a list of one.

    Returns None when nothing has any pairs to check, by the same reasoning
    `_discard_if_empty` gives: a run over zero pairs is a row that means
    nothing.
    """
    ids = list(client_ids)
    if not ids:
        return None

    run = plan(
        session,
        trigger=PROFILE_CHANGE,
        client_ids=ids,
        requested_by=requested_by,
        note=note or f"{len(ids)} client(s) changed",
    )
    return _discard_if_empty(session, run)


def periodic_review(
    session: Session, *, jurisdiction: str, requested_by: str = ""
) -> EvalRun | None:
    """Plan a regime's periodic review, or nothing if this tenant has no book
    in it. See `_discard_if_empty`."""
    run = plan(
        session,
        trigger=PERIODIC,
        jurisdiction=jurisdiction,
        requested_by=requested_by,
        note=f"{jurisdiction} periodic review",
    )
    return _discard_if_empty(session, run)


def periodic_due(
    session: Session, *, today: date | None = None, jurisdiction: str = ""
) -> list[str]:
    """Regimes whose pack says a review is due, and which have not had one.

    The cadence is pack content — `periodic_review_days` — because how often a
    book should be re-examined is a fact about a regime rather than about our
    scheduler. A pack that declares none is not reviewed periodically, which is
    a legitimate answer and not a default we should invent.
    """
    from . import packs_repo

    when = today or business_time.business_today(session)
    due = []
    for code, row in sorted(packs_repo.active_rows(session, when).items()):
        if jurisdiction and code != jurisdiction.upper():
            continue
        every = (row.body or {}).get("periodic_review_days")
        if not every:
            continue

        # Outstanding as well as finished. A review that has been planned and
        # not yet worked is still a review — without this, a scheduler running
        # daily queues a fresh sweep of the whole book every morning until
        # somebody drains the first one.
        last = session.scalars(
            select(EvalRun)
            .where(
                EvalRun.trigger == PERIODIC,
                EvalRun.jurisdiction == code,
                EvalRun.status.in_((PLANNED, RUNNING, DONE)),
                EvalRun.dry_run.is_(False),
            )
            .order_by(EvalRun.id.desc())
        ).first()
        if last is None or (
            last.status == DONE and (when - last.as_of).days >= int(every)
        ):
            due.append(code)
    return due
