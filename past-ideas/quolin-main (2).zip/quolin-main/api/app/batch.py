"""The file drop: a firm that can only send files, served properly.

The execution document is explicit that this is not legacy accommodation — a
real segment of institutions can only do files, and doing files gracefully is a
selling point. So this is built as a gateway rather than as an upload form with
a cron entry.

**Partial success, and this is the one place it is right.** `/import/clients`
is all-or-nothing on purpose: a person previewing their own file wants to fix it
and re-send, and a half-applied book is a state nobody can describe afterwards.
A nightly drop is the opposite situation. Nobody is watching at 02:00, the file
holds four thousand rows, and rejecting all of them because eleven are malformed
means a firm's entire book goes stale over one bad date. S4's gate says so
directly: *a malformed batch file produces row-level errors, not a failed run.*

So a batch run writes every valid row, and returns the rejects as a file beside
the input — the same shape the firm sent, plus the reason. Their operations team
fixes eleven rows and drops those, rather than re-cutting four thousand.

**The drop directory is the interface; SFTP is deployment.** What is here is
everything that happens to a file once it has landed: schema validation,
row-level errors, the error file, the run history, replay. The transport — an
SFTP server, per-tenant chroots, PGP at rest — is server configuration described
in `docs/integrations.md` rather than Python. A gateway that shelled out to an
SFTP daemon would be a gateway nobody could test.

**Every run is recorded and every run is replayable.** `import_runs` holds the
content hash, so the same file dropped twice is detectable — the most common
batch accident there is — and holds the errors, so "what did you reject on the
14th" is answerable a year later rather than only in the moment.
"""

from __future__ import annotations

import hashlib
import io
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import business_time, importer, mappings, service
from .identity import new_id
from .models import Client, ImportRun

#: Where a tenant's files land, relative to the drop root. One directory per
#: tenant, which is what an SFTP chroot maps onto — a shared directory would be
#: one customer able to read another's book, and no application check can undo
#: that once the transport has allowed it.
INCOMING = "incoming"
PROCESSED = "processed"
ERRORS = "errors"

#: Bigger than any real client book we have seen and small enough that a
#: mis-cut file cannot exhaust a worker's memory. A firm with more clients than
#: this is a conversation rather than a bigger constant.
MAX_BYTES = 32 * 1024 * 1024


class BatchError(ValueError):
    """The file as a whole cannot be processed — not a per-row problem."""


class MappingHeaderError(BatchError):
    """The mapping and the file disagree about what columns exist."""


def _translate(text: str, mapping) -> tuple[str, list[dict[str, Any]]]:
    """Rewrite a firm's CSV into ours, and report the rows that would not convert.

    Round-tripped through CSV rather than handed to the importer as dicts,
    because `importer.parse` is the one place that knows what a valid client row
    is and giving it a second entry point is how the two drift.
    """
    import csv as _csv

    reader = _csv.DictReader(io.StringIO(text))
    if reader.fieldnames is None:
        raise MappingHeaderError("the file has no header row")

    rows = [{k: (v or "") for k, v in row.items()} for row in reader]
    translated, errors = mappings.apply_to_rows(mapping, rows)
    if not translated:
        # Every row failed to convert. Reporting four thousand identical errors
        # is a worse answer than saying the mapping does not fit the file.
        if errors:
            raise MappingHeaderError(
                f"no row survived the {mapping.source} mapping v{mapping.version}. "
                f"First problem: {errors[0]['message']}"
            )
        return text, []

    out = io.StringIO()
    writer = _csv.DictWriter(out, fieldnames=list(translated[0].keys()))
    writer.writeheader()
    writer.writerows(translated)
    return out.getvalue(), errors


@dataclass
class BatchResult:
    """What one run did, in the terms the firm's operations team thinks in."""

    run_id: str
    filename: str
    status: str
    rows_total: int
    rows_written: int
    errors: list[dict[str, Any]]
    error_file: str | None
    #: The run that already loaded these exact bytes, if there was one. FP3-15.
    duplicate_of: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "filename": self.filename,
            "status": self.status,
            "rows_total": self.rows_total,
            "rows_written": self.rows_written,
            "rows_rejected": len({e["row"] for e in self.errors}),
            "errors": self.errors,
            "error_file": self.error_file,
            # Present and null on every run, not omitted when absent: a
            # scheduler reading the manifest should be able to test one key
            # rather than know which shape means what.
            "duplicate_of": self.duplicate_of,
        }


def _now() -> datetime:
    return datetime.now(timezone.utc)


def content_hash(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def drop_root(base: Path, tenant_id: str) -> Path:
    return Path(base) / tenant_id


def ensure_drop(base: Path, tenant_id: str) -> Path:
    root = drop_root(base, tenant_id)
    for part in (INCOMING, PROCESSED, ERRORS):
        (root / part).mkdir(parents=True, exist_ok=True)
    return root


def error_file_for(report_errors: list[dict[str, Any]], original: str) -> str:
    """The rejects, as a CSV the firm can read in the tool they already use.

    Their row number, their column, and the reason in a sentence. Deliberately
    not JSON: the person who fixes this opens it in a spreadsheet beside the
    file they sent, and a nested structure would be a worse answer delivered
    more precisely.
    """
    import csv

    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["source_file", "row", "column", "problem"])
    for error in report_errors:
        writer.writerow([original, error["row"], error["column"], error["message"]])
    return out.getvalue()


def process(
    session: Session,
    *,
    tenant_id: str,
    filename: str,
    raw: bytes,
    channel: str = "batch",
    started_by: str,
) -> BatchResult:
    """One file: validate every row, write the good ones, report the rest.

    The caller has already entered the *tenant's* scope. This does not enter it
    itself, for the reason `access_review.collect` gives — a function that
    silently changed the ambient tenant is one whose writes are hard to reason
    about from the call site.

    The *actor* is different, and `started_by` is required rather than optional
    because of it. A nightly drop at 02:00 has no person behind it, which under
    Stage 2's rule means `service.audit` refuses to write — correctly, since an
    unattributed row is the thing that rule exists to prevent. The answer is not
    to exempt batch: it is that a batch run acts as the machine credential that
    owns the drop, which is what `api_clients` is for. Whoever calls this says
    which credential, and the audit trail names it.
    """
    if len(raw) > MAX_BYTES:
        raise BatchError(
            f"{filename} is {len(raw):,} bytes, over the {MAX_BYTES:,}-byte limit. "
            "Split it, or talk to us about raising the limit for this tenant."
        )

    digest = content_hash(raw)

    # FP3-15. `already_seen` was written for this and had no callers, so the
    # most common batch accident there is — the same file dropped twice, usually
    # because a firm is re-sending after a failed night and doing exactly the
    # right thing — was silently re-imported as though it were new work.
    #
    # It reports rather than refuses, which is its own docstring's design and is
    # right: the second load is idempotent by construction (an upsert of the
    # same rows) and a firm that meant it should not be blocked. What was
    # missing is that it was *invisible*. The prior run's id travels back in the
    # result, into the manifest their scheduler reads, and onto the run row.
    prior = already_seen(session, digest)

    run = ImportRun(
        id=new_id("imp"),
        channel=channel,
        source="clients",
        filename=filename,
        content_hash=digest,
        status="running",
        started_at=_now(),
        started_by=started_by,
    )
    session.add(run)
    session.flush()

    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        # A file in the wrong encoding is a whole-file problem: there are no
        # rows to report on because we cannot read any of them.
        run.status = "failed"
        run.errors = [{"row": 0, "column": "", "message": f"not valid UTF-8: {exc}"}]
        run.finished_at = _now()
        session.flush()
        raise BatchError(f"{filename} is not valid UTF-8") from exc

    # A firm's own column names become ours before anything is validated, so
    # that the row-level errors an operations team reads name *their* columns
    # rather than the canonical ones they have never seen. The version is
    # recorded on the run: a mapping change can change determinations, and
    # explaining one made last March needs to know which mapping was in force.
    mapping = mappings.active(session, "clients")
    run.mapping_version = mapping.version if mapping else None
    mapping_errors: list[dict[str, Any]] = []
    if mapping is not None:
        try:
            text, mapping_errors = _translate(text, mapping)
        except MappingHeaderError as exc:
            run.status = "failed"
            run.errors = [{"row": 0, "column": "", "message": str(exc)}]
            run.finished_at = _now()
            session.flush()
            raise BatchError(str(exc)) from exc

    try:
        report = importer.parse(text, today=business_time.business_today(session))
    except importer.ImportError_ as exc:
        # A missing header, an unknown column, an empty file. Also whole-file:
        # every row would fail for the same reason, and four thousand identical
        # error lines is a worse answer than one.
        run.status = "failed"
        run.errors = [{"row": 0, "column": "", "message": str(exc)}]
        run.finished_at = _now()
        session.flush()
        raise BatchError(str(exc)) from exc

    for row in report.valid:
        row.exists = session.get(Client, row.values["id"]) is not None

    written = 0
    for row in report.valid:
        values = row.values
        existing = session.get(Client, values["id"])
        if existing is None:
            session.add(Client(**values))
        else:
            for column, value in values.items():
                setattr(existing, column, value)
        written += 1

    # Mapping failures and validation failures are the same kind of thing to the
    # person fixing them — a row that could not be loaded, and why — so they are
    # one list sorted by row rather than two the reader has to merge.
    errors = sorted(
        mapping_errors + [e.as_dict() for e in report.errors],
        key=lambda e: (e["row"], e["column"]),
    )
    run.rows_total = report.total_rows + len({e["row"] for e in mapping_errors})
    run.rows_written = written
    run.errors = errors
    # `completed` even with rejects, and the word is chosen. The run did what a
    # batch run is for: it loaded what it could and said precisely what it could
    # not. `partial` would suggest something is still owed.
    run.status = "completed" if not errors else "completed_with_errors"
    run.finished_at = _now()

    from . import tenancy

    duplicate_note = f", duplicate of run {prior.id}" if prior is not None else ""

    with tenancy.acting_as_user(started_by):
        service.audit(
            session,
            action="batch.clients",
            subject=(
                f"{filename}: {written} of {report.total_rows} rows written, "
                f"{len({e['row'] for e in errors})} rejected (run {run.id})"
                f"{duplicate_note}"
            ),
        )
    session.flush()

    return BatchResult(
        run_id=run.id,
        filename=filename,
        status=run.status,
        rows_total=report.total_rows,
        rows_written=written,
        errors=errors,
        error_file=f"{Path(filename).stem}.errors.csv" if errors else None,
        duplicate_of=prior.id if prior is not None else None,
    )


def sweep(
    session: Session,
    *,
    tenant_id: str,
    base: Path,
    started_by: str,
) -> list[BatchResult]:
    """Everything waiting in one tenant's incoming directory.

    Files are moved rather than deleted: `processed/` keeps what was loaded and
    `errors/` holds the rejects beside it. A drop directory that empties itself
    is one where "what did you send us on the 14th" has no answer.

    Sorted by name so a firm dropping `book-001.csv` through `book-012.csv` gets
    them applied in the order they numbered them, rather than in whatever order
    the filesystem returns.
    """
    root = ensure_drop(base, tenant_id)
    results = []

    for path in sorted((root / INCOMING).glob("*.csv")):
        raw = path.read_bytes()
        try:
            result = process(
                session,
                tenant_id=tenant_id,
                filename=path.name,
                raw=raw,
                started_by=started_by,
            )
        except BatchError as exc:
            session.commit()
            # The file stays where it is. A whole-file failure is something a
            # person has to look at, and moving it out of `incoming` would hide
            # the one file that needs attention.
            (root / ERRORS / f"{path.stem}.errors.csv").write_text(
                error_file_for([{"row": 0, "column": "", "message": str(exc)}], path.name)
            )
            results.append(
                BatchResult(
                    run_id="",
                    filename=path.name,
                    status="failed",
                    rows_total=0,
                    rows_written=0,
                    errors=[{"row": 0, "column": "", "message": str(exc)}],
                    error_file=f"{path.stem}.errors.csv",
                )
            )
            continue

        session.commit()
        if result.error_file is not None:
            (root / ERRORS / result.error_file).write_text(
                error_file_for(result.errors, path.name)
            )
        path.rename(root / PROCESSED / path.name)
        results.append(result)

    return results


def history(session: Session, *, limit: int = 50) -> list[dict[str, Any]]:
    """This tenant's runs, newest first. What `/v1/imports` serves."""
    rows = session.scalars(
        select(ImportRun).order_by(ImportRun.started_at.desc()).limit(limit)
    ).all()
    return [
        {
            "run_id": r.id,
            "channel": r.channel,
            "source": r.source,
            "filename": r.filename,
            "content_hash": r.content_hash,
            "status": r.status,
            "rows_total": r.rows_total,
            "rows_written": r.rows_written,
            "rows_rejected": len({e["row"] for e in (r.errors or [])}),
            "started_at": r.started_at.isoformat() if r.started_at else None,
            "finished_at": r.finished_at.isoformat() if r.finished_at else None,
        }
        for r in rows
    ]


def already_seen(session: Session, digest: str) -> ImportRun | None:
    """A previous run of the identical bytes, if there is one.

    The same file dropped twice is the most common batch accident there is, and
    it is not obviously an error — a firm re-sending after a failed night is
    doing the right thing. So this reports rather than refuses, and the caller
    decides. What matters is that it is *visible*.
    """
    return session.scalars(
        select(ImportRun)
        .where(ImportRun.content_hash == digest, ImportRun.status != "failed")
        .order_by(ImportRun.started_at.desc())
    ).first()


def manifest(results: list[BatchResult]) -> str:
    """A run summary written back into the drop, so the firm's job can read it.

    Their scheduler ran a job and needs to know what happened without calling an
    API — which is the whole reason they are on files rather than on HTTP.
    """
    return json.dumps(
        {
            "ran_at": _now().isoformat(),
            "files": [r.as_dict() for r in results],
            "totals": {
                "files": len(results),
                "rows_written": sum(r.rows_written for r in results),
                "rows_rejected": sum(len({e["row"] for e in r.errors}) for r in results),
            },
        },
        indent=2,
    )
