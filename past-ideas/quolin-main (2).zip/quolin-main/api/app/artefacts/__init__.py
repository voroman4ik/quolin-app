"""Documents: rendering them, sealing them, and accounting for them.

The renderer lives in `renderer.py` rather than `render.py`, and that is not
arbitrary. This package exports a function called `render`, which would shadow a
module of the same name — `artefacts.render` would then mean the module or the
function depending on how you reached it, which is the kind of ambiguity that
costs somebody an afternoon exactly once.
"""

from . import queue as queue
from .renderer import (
    OUTPUT_DIR,
    PERIOD_KINDS,
    RUN_KINDS,
    RUN_SCOPE,
    preview,
    read_pdf,
    render,
    render_period,
    render_run,
    scope_of,
)

__all__ = [
    "queue",
    "OUTPUT_DIR",
    "PERIOD_KINDS",
    "RUN_KINDS",
    "RUN_SCOPE",
    "scope_of",
    "preview",
    "read_pdf",
    "render",
    "render_period",
    "render_run",
]
