"""Claiming, running and retrying artefact jobs.

The queue is a Postgres table and the claim is `FOR UPDATE SKIP LOCKED` — see
the migration for why that is the right answer rather than the cheap one. This
module is the part that has to be got right regardless of the storage:

**A job is claimed by exactly one worker.** `SKIP LOCKED` makes that a property
of the database rather than of our locking discipline. Two workers started by a
scheduler that fired twice do not produce two documents.

**A worker that dies mid-render loses nothing.** The claim is a row update, so a
process killed between claiming and finishing leaves a `running` row with an old
`started_at`. That row is reclaimed once the lease expires. §S8's gate asks for
a mid-run kill to resume without double-recording; this is the same property one
stage early, and rendering is idempotent anyway — the same inputs produce the
same bytes and the same artefact row.

**Failure is bounded and legible.** A job that fails is retried up to a limit
and then left `failed` with the error on the row, not deleted. A document a
customer asked for and never received is a thing somebody must be able to find.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import ArtefactJob

QUEUED = "queued"
RUNNING = "running"
DONE = "done"
FAILED = "failed"

#: Where a job sits in the queue. Lower is sooner.
#:
#: §S12 asks for queue priorities so that bulk work cannot starve interactive
#: traffic, and the failure it prevents is specific: ten thousand documents go
#: in for a quarter's returns, and the officer who then asks for one
#: determination's Target Market Determination is behind all ten thousand of
#: them. Nothing is broken — the render is simply scheduled for tomorrow.
#:
#: Two levels, not five. A priority scheme with five levels is one where the
#: interesting question becomes which level something is, and the answer drifts
#: upward. The only distinction that matters here is whether somebody is
#: waiting for this document right now.
INTERACTIVE = 0
BATCH = 10

#: Which scope means somebody is waiting. A decision-scoped document is one
#: determination on somebody's screen; run- and period-scoped documents are
#: batches produced by a sweep or a month end, and nobody watches those arrive.
#:
#: Derived from the pack's declared scope rather than passed in by the caller,
#: for the reason on `ArtefactJob.priority`.
INTERACTIVE_SCOPES = ("decision",)


def priority_for(scope: str) -> int:
    """Where a job of this scope belongs in the queue."""
    return INTERACTIVE if scope in INTERACTIVE_SCOPES else BATCH

#: How many times a job is attempted before it is left alone. Three, because the
#: failures worth retrying here are transient (a database hiccup, a worker
#: killed mid-render) and the ones that are not — a decision that does not
#: exist, a pack with no template for this kind — fail identically every time.
MAX_ATTEMPTS = 3

#: How long a worker's claim holds before another may take the job. Generous
#: relative to a render: a document takes hundreds of milliseconds and this is
#: fifteen minutes, so a reclaim means the worker is genuinely gone rather than
#: slow. Reclaiming a job that is merely slow would produce the document twice —
#: harmless, because rendering is idempotent, but wasteful and confusing.
LEASE = timedelta(minutes=15)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def fingerprint(kind: str, params: dict[str, Any]) -> str:
    """A stable digest of what a job will render.

    Canonical JSON for the reason every other hash in this repository is: key
    order is not meaningful, and a digest that changed when a dictionary was
    rebuilt would make "is this already queued" answer no whenever it mattered.
    """
    return hashlib.sha256(
        json.dumps(
            {"kind": kind, "params": params}, sort_keys=True, separators=(",", ":")
        ).encode()
    ).hexdigest()


def enqueue(
    session: Session,
    *,
    kind: str,
    params: dict[str, Any],
    subject: str = "",
    requested_by: str = "",
    scope: str = "",
) -> tuple[ArtefactJob, bool]:
    """Ask for a document. Returns the job and whether it is new.

    Asking twice for the same document while one is outstanding returns the
    first job. Not an optimisation: a screen with an eager button, a retrying
    client and a scheduled job all asking for the same return would otherwise
    render it three times and leave three rows claiming to be the document that
    was filed.

    A *finished* job does not suppress a new one. Regenerating deliberately is a
    thing people do — the figures changed, the pack was corrected — and
    deterministic rendering means an unnecessary regeneration costs a render and
    changes nothing.
    """
    digest = fingerprint(kind, params)
    outstanding = session.scalars(
        select(ArtefactJob)
        .where(
            ArtefactJob.fingerprint == digest,
            ArtefactJob.status.in_((QUEUED, RUNNING)),
        )
        .order_by(ArtefactJob.id)
    ).first()
    if outstanding is not None:
        return outstanding, False

    job = ArtefactJob(
        kind=kind,
        params=params,
        fingerprint=digest,
        subject=subject,
        status=QUEUED,
        requested_by=requested_by,
        priority=priority_for(scope),
    )
    session.add(job)
    session.flush()
    return job, True


def claim(session: Session, *, now: datetime | None = None) -> ArtefactJob | None:
    """Take the most urgent job nobody else holds, then the oldest of those.

    `FOR UPDATE SKIP LOCKED` is the whole of the concurrency control: two
    workers running this at the same instant get different rows, and neither
    waits for the other. The alternative — read, then update, then hope — is the
    bug that produces two documents under load and never in testing.

    Jobs whose lease has expired are claimable again. That is what makes a
    worker killed mid-render a delay rather than a stuck job.
    """
    now = now or _now()
    stale = now - LEASE

    job = session.scalars(
        select(ArtefactJob)
        .where(
            (ArtefactJob.status == QUEUED)
            | (
                (ArtefactJob.status == RUNNING)
                & (ArtefactJob.started_at.is_not(None))
                & (ArtefactJob.started_at < stale)
            )
        )
        .where(ArtefactJob.attempts < MAX_ATTEMPTS)
        # Priority first, then age. Age alone is what buries a person behind a
        # batch; priority alone would let a steady trickle of interactive work
        # starve a batch forever, which is why the second term is still `id`
        # rather than anything cleverer. Within a priority this is exactly the
        # first-in-first-out it always was.
        .order_by(ArtefactJob.priority, ArtefactJob.id)
        .limit(1)
        .with_for_update(skip_locked=True)
    ).first()
    if job is None:
        return None

    job.status = RUNNING
    job.started_at = now
    job.attempts += 1
    session.flush()
    return job


def succeeded(session: Session, job: ArtefactJob, *, artefact_id: int) -> ArtefactJob:
    job.status = DONE
    job.artefact_id = artefact_id
    job.finished_at = _now()
    job.last_error = ""
    session.flush()
    return job


def failed(session: Session, job: ArtefactJob, *, error: str) -> ArtefactJob:
    """Record a failure, and put the job back only if it is worth retrying.

    Left `failed` with the reason on the row rather than deleted. A document
    somebody asked for and never received has to be findable — by them, and by
    whoever is asked why it never arrived.
    """
    job.last_error = error[:2000]
    if job.attempts >= MAX_ATTEMPTS:
        job.status = FAILED
        job.finished_at = _now()
    else:
        job.status = QUEUED
        job.started_at = None
    session.flush()
    return job


def depth(session: Session) -> dict[str, int]:
    """How much is outstanding, by status. What an alert watches."""
    counts = {QUEUED: 0, RUNNING: 0, DONE: 0, FAILED: 0}
    for status, count in session.execute(
        select(ArtefactJob.status, func.count()).group_by(ArtefactJob.status)
    ).all():
        counts[status] = count
    return counts


def view(job: ArtefactJob) -> dict[str, Any]:
    """One job, as a caller polling for their document sees it."""
    return {
        "id": job.id,
        "kind": job.kind,
        "subject": job.subject,
        # What the job was asked for, so a failure can be asked for again.
        #
        # FP3-26. `subject` is a sentence for a person to read — "determination
        # #4021" — and reconstructing a request from it would be parsing English
        # to decide what to re-enqueue. These are the same keys `/artefacts/batch`
        # takes, so the queue screen's retry is the original request repeated
        # rather than a second guess at what it was.
        "params": dict(job.params or {}),
        "status": job.status,
        # Shown, because "why is my document still pending" has a real answer
        # now and it should be visible on the queue screen rather than only in
        # the table.
        "priority": job.priority,
        "attempts": job.attempts,
        "requested_at": job.requested_at.isoformat(),
        "started_at": job.started_at.isoformat() if job.started_at else None,
        "finished_at": job.finished_at.isoformat() if job.finished_at else None,
        "artefact_id": job.artefact_id,
        "error": job.last_error,
        "download_url": (
            f"/artefacts/{job.artefact_id}/pdf" if job.artefact_id else None
        ),
    }
