"""Turning a claimed job into a document.

Deliberately separate from `queue.py`, which knows nothing about what a job
renders, and from `renderer.py`, which knows nothing about queues. This is the
only place the two meet, and keeping it small is what lets each be read on its
own.

It lives outside `main.py` because a worker process must be able to do this
without FastAPI, a request, or a cookie — and because the endpoint and the
worker have to run *the same* code. A queue whose jobs are executed by a
reimplementation of the synchronous path is a queue that renders subtly
different documents.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from .. import business_time, tenancy
from ..models import Artefact, ArtefactJob
from . import queue, renderer

#: Who a document is attributed to when the job carries no requester — a
#: scheduled month-end run rather than a person pressing a button. A machine
#: principal, provisioned by the seed, for the reason Stage 6 learned: an audit
#: actor that is a bare string names nobody, and "not blank" is not the bar.
SCHEDULE_ACTOR = "apc_artefact_worker"

#: Which shape a job is decides which parameters it carries. The distinction is
#: not ours — a Target Market Determination is about one client and a
#: distribution return is about a month — and since Stage 7 it is declared in
#: pack content rather than listed here. A job renders under the pack in force
#: for its regime, so the scope is read from that pack.


def _scope(session: Session, job: ArtefactJob) -> str:
    """Which shape this job renders, per the pack that governs it.

    Falls back to the renderer's defaults when the job names no regime — which
    a per-decision job does not, because the decision carries its own, and a
    sweep's report does not, because the run does.
    """
    from .. import packs_repo

    params = job.params or {}
    regime = params.get("jurisdiction")
    if not regime:
        return renderer.scope_of(job.kind)
    try:
        pack = packs_repo.active(
            session, str(regime).upper(), business_time.business_today(session)
        )
    except packs_repo.NoReviewedPackAvailable:
        # Deliberately not caught by the LookupError below, which it subclasses.
        # "No pack is effective on this date" is a scope question with a
        # sensible default; "this firm may not decide on unsigned content" is a
        # refusal, and a document produced by falling back past it would carry
        # the authority of rules nobody signed.
        raise
    except LookupError:
        return renderer.scope_of(job.kind)
    return renderer.scope_of(job.kind, pack)


class UnknownJob(ValueError):
    """A job whose parameters do not describe anything renderable.

    Raised rather than skipped: a job that cannot be run is a document somebody
    is waiting for, and silently marking it done would be the worst outcome.
    """


def run(session: Session, job: ArtefactJob, *, aggregate=None) -> Artefact:
    """Render one job's document, in the tenant the job belongs to.

    `aggregate` is injected because computing a period's figures lives in
    `app.reports`, and importing that here would tie the worker to the API's
    module graph for one function. The endpoint and the worker pass the same
    callable, which is what keeps the two paths identical.
    """
    params: dict[str, Any] = dict(job.params or {})
    scope = _scope(session, job)

    if scope == renderer.RUN_SCOPE:
        # A document about one sweep of the book — §S8's delta report. The run
        # carries its own regime and its own as-at date, so the job needs
        # nothing but its id.
        run_id = params.get("run_id")
        if not run_id:
            raise UnknownJob(f"job {job.id} reports on a sweep and names no run")
        return renderer.render_run(session, kind=job.kind, run_id=int(run_id))

    if scope == renderer.PERIOD_SCOPE:
        if aggregate is None:
            raise UnknownJob(
                f"job {job.id} renders a period document and no aggregator was given"
            )
        for required in ("period", "jurisdiction"):
            if not params.get(required):
                raise UnknownJob(f"job {job.id} has no {required}")
        report = aggregate(
            session,
            job.kind,
            params["period"],
            params["jurisdiction"],
            params.get("scenario"),
        )
        return renderer.render_period(
            session,
            kind=job.kind,
            report=report,
            jurisdiction=params["jurisdiction"],
        )

    decision_id = params.get("decision_id")
    if not decision_id:
        raise UnknownJob(f"job {job.id} has no decision_id")
    return renderer.render(session, kind=job.kind, decision_id=int(decision_id))


def drain(
    session: Session, *, aggregate=None, limit: int = 100, now=None
) -> dict[str, int]:
    """Work the queue until it is empty or `limit` jobs have been done.

    One transaction per job, committed as it finishes. A single transaction over
    a hundred documents would mean a worker killed on the ninety-ninth loses all
    ninety-eight that worked — and would hold a claim on every one of them for
    as long as it ran.

    `limit` bounds a single pass so a scheduled worker cannot run forever on a
    queue somebody keeps filling.
    """
    tally = {"done": 0, "failed": 0}
    for _ in range(limit):
        job = queue.claim(session, now=now)
        if job is None:
            break
        # Committed before the work starts, and this is not tidiness. The claim
        # increments `attempts`; a failed render rolls back, and a rollback that
        # took the increment with it would leave a job that fails identically
        # every time being retried forever — the exact thing MAX_ATTEMPTS
        # exists to prevent. Committing here also ends the row lock, so a worker
        # that then hangs is governed by the lease rather than by a transaction
        # nobody can see.
        session.commit()
        try:
            # Rendered as the person who asked for it, not as the worker. The
            # worker is machinery; "who generated this document" means who
            # wanted it, and that is the identity a regulator's question is
            # about. The job has carried it since it was enqueued.
            with tenancy.acting_as_user(job.requested_by or SCHEDULE_ACTOR):
                artefact = run(session, job, aggregate=aggregate)
        except Exception as exc:  # noqa: BLE001 — a worker survives one bad job
            session.rollback()
            # Re-claimed rather than re-used: the rollback above discarded the
            # object's state along with the failed render.
            fresh = session.get(ArtefactJob, job.id)
            if fresh is not None:
                queue.failed(session, fresh, error=f"{type(exc).__name__}: {exc}")
                # Only once it has stopped retrying. Telling a customer their
                # document failed and then producing it on the next attempt is
                # how an integration learns to ignore us.
                if fresh.status == queue.FAILED:
                    _tell_them(session, fresh)
                session.commit()
            tally["failed"] += 1
            continue
        queue.succeeded(session, job, artefact_id=artefact.id)
        _tell_them(session, job, artefact=artefact)
        session.commit()
        tally["done"] += 1
    return tally


def _tell_them(
    session: Session, job: ArtefactJob, *, artefact: Artefact | None = None
) -> None:
    """Notify the customer's systems that a document is ready, or is not.

    §S7 asks for returns "delivered to console + webhook". The console half is
    the queue screen; this is the other. A customer who queued a month-end
    return should not have to poll for it, and — the half that matters more — a
    document that was asked for and never produced is exactly what they must not
    discover for themselves at the end of a reporting period.

    Imported here rather than at module scope for the reason `service.notify`
    gives: the notification layer knows nothing about documents, and this is the
    only place that knows about both. Failure to notify never fails the render —
    the document exists, and telling somebody is a separate obligation.
    """
    from .. import service

    if artefact is not None:
        service._tell_the_customers_systems(
            session,
            "artefact.ready",
            f"artefact:{artefact.id}",
            {
                "job_id": job.id,
                "artefact_id": artefact.id,
                "kind": artefact.kind,
                "title": artefact.title,
                "subject": job.subject,
                "pack_id": artefact.pack_id,
                "pack_version": artefact.pack_version,
                "window_start": (
                    artefact.window_start.isoformat() if artefact.window_start else None
                ),
                "window_end": (
                    artefact.window_end.isoformat() if artefact.window_end else None
                ),
                "content_hash": artefact.content_hash,
                "download_url": f"/artefacts/{artefact.id}/pdf",
            },
        )
        return

    service._tell_the_customers_systems(
        session,
        "artefact.failed",
        f"job:{job.id}",
        {
            "job_id": job.id,
            "kind": job.kind,
            "subject": job.subject,
            "attempts": job.attempts,
            "error": job.last_error,
        },
    )
