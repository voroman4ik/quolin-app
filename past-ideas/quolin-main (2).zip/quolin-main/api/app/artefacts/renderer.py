from __future__ import annotations

import hashlib
import json
import os
from datetime import date
from pathlib import Path
from typing import Any

from jinja2 import FileSystemLoader, Undefined, select_autoescape
from jinja2.sandbox import SandboxedEnvironment
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import crypto, observability, packs_repo
from .. import service as service_module
from ..models import Artefact, Decision, Tenant
from ..service import decision_view
from ..tenancy import current_tenant, current_user_or_none

#: What a document is about, when its pack does not say.
#:
#: Content decides this now — a pack's `artefact_scopes` maps a kind to
#: `period` or `decision`, per §S7's "return formats are pack content,
#: engineering is the pipeline". These two are the fallback for packs written
#: before the map existed, and they are the honest default rather than a
#: shortcut: every other document this system has ever produced was about one
#: determination, so silence means `decision` and these two are the exceptions
#: that were already true.
DEFAULT_PERIOD_KINDS = ("regulatory_return", "override_report")

#: Documents about one bulk sweep rather than about one determination or one
#: month. §S8's delta report is the first: "pack v4 took effect and 212 clients
#: moved to REFER" is a statement about an *act*, and the questions asked of it —
#: what caused it, what changed, had the tenant taken the version yet — are not
#: the questions a period return answers.
#:
#: A default, like `DEFAULT_PERIOD_KINDS`. Which scope a document has is pack
#: content — see `scope_of` — and this is only what to assume when no pack is in
#: hand.
DEFAULT_RUN_KINDS = ("delta_report",)
RUN_KINDS = DEFAULT_RUN_KINDS

#: Kept as a name because callers import it, and because "which kinds are period
#: documents *in general*" is still a sensible question for a screen that has no
#: pack in hand. Anything deciding what to *do* with a kind asks the pack.
PERIOD_KINDS = DEFAULT_PERIOD_KINDS

PERIOD_SCOPE = "period"
DECISION_SCOPE = "decision"
#: Stage 8. A document about one sweep of the book.
RUN_SCOPE = "run"


def scope_of(kind: str, pack: Any | None = None) -> str:
    """Whether this document is about a period or about one determination.

    Read from pack content when a pack is in hand, because that is where §S7
    puts it: a regime that needs a document nobody has thought of declares it,
    and the pipeline renders it without a deploy. Falls back to the two kinds
    that were period documents before the map existed.
    """
    declared = getattr(pack, "artefact_scopes", None) or {}
    scope = str(declared.get(kind, "")).strip().lower()
    if scope in (PERIOD_SCOPE, DECISION_SCOPE, RUN_SCOPE):
        return scope
    if kind in DEFAULT_PERIOD_KINDS:
        return PERIOD_SCOPE
    if kind in DEFAULT_RUN_KINDS:
        return RUN_SCOPE
    return DECISION_SCOPE


def kinds_for(pack: Any, scope: str | None = None) -> list[str]:
    """Every document this pack declares, optionally of one scope.

    The list a screen offers and the list an API validates against are both
    this: a kind exists because a pack declares a template for it, and for no
    other reason.
    """
    kinds = sorted(getattr(pack, "artefact_templates", None) or {})
    if scope is None:
        return kinds
    return [k for k in kinds if scope_of(k, pack) == scope]

TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"
OUTPUT_DIR = Path(os.getenv("ARTEFACT_DIR", Path(__file__).resolve().parents[3] / "artefacts_out"))

#: The column name the PDF is sealed under. Artefacts are not a database column,
#: but they are the same tenant's data under the same key, and giving them a
#: name in the same namespace means a sealed PDF cannot be fed to the code that
#: reads snapshots, or the reverse.
PDF_AAD = "artefacts.pdf"

#: Pinned so that a subset font is the same font every time.
#:
#: WeasyPrint subsets embedded fonts through HarfBuzz, and a TrueType `head`
#: table carries `created` and `modified` timestamps. HarfBuzz stamps the
#: current time into the subset it produces — so two renders of *identical*
#: markup a second apart differ, by exactly one, in the `head` table's checksum.
#: That is the whole of the nondeterminism §S7's gate ran into, and it took four
#: wrong explanations to find: the difference is a single byte, inside a
#: compressed stream, in a font nobody wrote.
#:
#: `SOURCE_DATE_EPOCH` is the reproducible-builds convention both HarfBuzz and
#: fontTools honour for exactly this. Set to zero rather than to a plausible
#: date: a synthetic timestamp that looks like a real one invites somebody to
#: read meaning into it, and the epoch is obviously not when this font was made.
#:
#: Set at import, before anything renders, because the libraries read it when
#: they subset rather than when they are asked to.
FONT_TIMESTAMP_EPOCH = "0"
os.environ.setdefault("SOURCE_DATE_EPOCH", FONT_TIMESTAMP_EPOCH)


class NotDeterministic(RuntimeError):
    """The same inputs produced different bytes.

    §S7's gate is that regenerating a return for the same period and pack
    version is byte-identical. If that stops being true the useful failure is
    loud and immediate: silently replacing the stored hash would destroy the
    evidence that the two ever differed, which is the only interesting thing
    about the event.

    Raised only when the *inputs* were identical. A firm that changes its
    trading name legitimately produces a different document from the same
    determination — that is a new document, not a broken renderer, and telling
    the two apart is what `inputs_hash` is for.
    """

    def __init__(
        self,
        kind: str,
        ref_id: str,
        was: str,
        now: str,
        *,
        stored: bytes | None = None,
        produced: bytes | None = None,
    ):
        message = (
            f"regenerating {kind} for {ref_id} produced different bytes from "
            f"identical inputs: the document on file hashes to {was[:12]} and "
            f"this render to {now[:12]}. Something in the rendering path is "
            "reading the clock, the environment, or an unordered collection."
        )
        # The whole point of a loud failure is that it hands somebody a lead.
        # "Different bytes" is not one; "they diverge at byte 41,208, and the
        # surrounding bytes are a page-content stream" is. The stored document
        # is on disk and readable, so there is no reason to make the next person
        # go and diff it themselves.
        if stored is not None and produced is not None:
            shortest = min(len(stored), len(produced))
            at = next(
                (i for i in range(shortest) if stored[i] != produced[i]), shortest
            )
            window = slice(max(0, at - 60), at + 60)
            message += (
                f"\n  sizes: {len(stored)} on file, {len(produced)} now"
                f"\n  first difference at byte {at}"
                f"\n  on file: {stored[window]!r}"
                f"\n  now:     {produced[window]!r}"
            )
        super().__init__(message)

#: What is actually on disk is not a PDF and must not be named as though it
#: were. `pdf_ref` keeps the readable name — it is what the browser saves the
#: download as — and this is appended to reach the file.
SEALED_SUFFIX = ".enc"


def _tenant_dir() -> Path:
    """Where this tenant's documents live, created on demand.

    A directory per customer rather than one flat pile. The encryption is what
    makes another tenant's document unreadable; the directory is what stops the
    two ever being confused for one another by a human, a backup script, or a
    filename collision.
    """
    directory = OUTPUT_DIR / current_tenant()
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def branding(session: Session) -> dict[str, str]:
    """This customer's name and marks, for the document's letterhead.

    §S7 asks for tenant branding from config, and the boundary matters: branding
    is *presentation*, and it is the only thing about a document a customer may
    choose. Statutory titles are pack content and stay pack content (invariant
    8) — a firm that could retitle its own Target Market Determination would be
    a firm filing a document whose name it invented.

    So: a display name, a line of contact detail, and nothing that could change
    what the document asserts. Missing keys fall back to the tenant's own name
    rather than to a placeholder, because a letterhead reading "Your Firm Here"
    on a filed return is worse than one reading nothing at all.
    """
    tenant = session.get(Tenant, current_tenant())
    config = (tenant.config if tenant is not None else None) or {}
    marks = config.get("branding") or {}
    return {
        "name": str(marks.get("name") or (tenant.name if tenant is not None else "")),
        "contact": str(marks.get("contact") or ""),
        "reference": str(marks.get("reference") or ""),
    }


def _seal(filename: str, pdf: bytes) -> None:
    (_tenant_dir() / f"{filename}{SEALED_SUFFIX}").write_bytes(
        crypto.encrypt(pdf, column=PDF_AAD)
    )


def read_pdf(pdf_ref: str) -> bytes | None:
    """A stored document, decrypted, or None if the file is not there.

    Absent is a normal state rather than an error: the hosted API writes to the
    container's `/tmp`, so every document predates the current machine at most
    by one deploy. The caller turns None into "regenerate", which is the honest
    answer and the one that was there before any of this was encrypted.

    `Path(...).name` because a stored reference is joined onto a tenant's
    directory. Nothing writes a separator into `pdf_ref` today, and this is what
    makes that still true after the next thing that writes one.
    """
    path = _tenant_dir() / f"{Path(pdf_ref).name}{SEALED_SUFFIX}"
    if not path.exists():
        return None
    return crypto.decrypt(path.read_bytes(), column=PDF_AAD)

#: Sandboxed rather than plain, and the reason is what artefact templates are
#: about to become rather than what they are.
#:
#: A plain `Environment` lets a template reach an object's attributes and call
#: what it finds — `{{ decision.__class__.__init__.__globals__ }}` is the
#: standard walk from any passed object to the interpreter. Today every template
#: under `TEMPLATE_DIR` ships in this repository and goes through code review,
#: so nothing hostile is being rendered and exploitability is low.
#:
#: But §S7's stated design is that return formats are pack content: a regime
#: that needs a document nobody has thought of yet declares it with a template.
#: `artefact_templates` already lives in the pack body. The day a template
#: arrives from content rather than from this repository, a plain environment
#: turns rule content into code execution — and that day will not look like a
#: security change.
#:
#: `select_autoescape(["html"])` is unchanged: the sandbox governs what a
#: template may reach, escaping governs what it may emit, and both are wanted.
_env = SandboxedEnvironment(
    loader=FileSystemLoader(TEMPLATE_DIR),
    autoescape=select_autoescape(["html"]),
)


#: What a document prints where a custody figure should be, when there is no
#: custody record. Q-06 withholds the calcs that read `positions.` from a
#: snapshot built for a client nobody holds positions for, so these fields are
#: genuinely absent rather than zero — and a Target Market Determination that
#: printed `$0.00` there would be the same fabrication as the ALLOW that finding
#: was about, in a document somebody files.
NOT_ON_FILE = "Not on file"


def _missing(value: Any) -> str | None:
    """Distinguish "absent from the snapshot" from "present and null".

    An `Undefined` reaches a filter when the template asked for a key the
    snapshot does not carry, which since Q-06 means exactly one thing: the
    figure depends on custody and custody has no record of this client. `None`
    is a different fact — the value exists and is empty — and keeps the em dash
    it has always had.
    """
    if isinstance(value, Undefined):
        return NOT_ON_FILE
    if value is None:
        return "—"
    return None


def _cents(value: int | None) -> str:
    absent = _missing(value)
    if absent is not None or value is None:
        return absent or "—"
    return f"${value / 100:,.2f}"


def _bps(value: int | None) -> str:
    absent = _missing(value)
    if absent is not None or value is None:
        return absent or "—"
    whole, frac = divmod(value, 100)
    return f"{whole}.{frac:02d}%"


def _magnitude(value: int | str | None, scale: str) -> str:
    """A cross-border constraint's magnitude, in the unit its own pack declared.

    The same rendering the screen uses, for the same reason: `200000 cents` and
    `$2,000.00` are the same number, and only one of them can be checked against
    a statement by someone reading the document. The unit is never guessed — an
    unrecognised scale prints the raw value beside the scale's own name rather
    than being coerced into a unit no pack declared, and a constraint with no
    magnitude at all prints the dash a table of numbers uses for absence.
    """
    if value is None:
        return "—"
    if isinstance(value, int) and not isinstance(value, bool):
        if scale == "cents":
            return _cents(value)
        if scale == "bps":
            return _bps(value)
        if scale == "band":
            return f"Band {value}"
        if scale in ("days", "years"):
            return f"{value} {scale[:-1] if value == 1 else scale}"
    return f"{value} {scale}"


_env.filters["cents"] = _cents
_env.filters["bps"] = _bps
_env.filters["magnitude"] = _magnitude


def render(session: Session, *, kind: str, decision_id: int) -> Artefact:
    """The document for one determination, and the record of having made it.

    Deterministic: the same determination under the same pack version produces
    byte-identical output, every time. Nothing in the document is read from the
    clock — see `_document_footer` in the templates and the note on
    `Artefact.content_hash`. That is §S7's gate for returns, and there is no
    reason a per-decision document should be weaker.
    """
    # FP3-16. `observability.timed` was written for "the things §S9 wants
    # alerting on when they get slow — a sweep, a render, a restore drill" and
    # had no callers, so §S9's slow-operation alerting had no signal to alert
    # on. Three of the operations it names are wrapped now; this is the render.
    with observability.timed(
        "artefacts.render", "rendered an artefact", kind=kind, decision_id=decision_id
    ):
        return _render(session, kind=kind, decision_id=decision_id)


def _render(session: Session, *, kind: str, decision_id: int) -> Artefact:
    """The body of `render`, so the timing wrapper is one line rather than an
    indent over two hundred."""
    decision = session.get(Decision, decision_id)
    if decision is None:
        raise KeyError(f"unknown decision {decision_id}")

    # The governing pack, at the version the decision was made under. Templates
    # and titles are pack config (invariant 8), so a document produced for a
    # decision made in one regime must never be titled by another's.
    pack = packs_repo.by_version(
        session, service_module._governing_pack_id(decision), decision.pack_version
    )
    template_name = pack.artefact_templates.get(kind)
    if template_name is None:
        raise KeyError(f"pack v{pack.version} defines no template for {kind!r}")

    view = decision_view(session, decision, pack)
    title = pack.artefact_titles.get(kind, kind.replace("_", " ").title())

    html = _env.get_template(template_name).render(
        title=title,
        kind=kind,
        decision=view,
        pack=pack,
        branding=branding(session),
    )
    pdf = _to_pdf(html)

    return _record(
        session,
        kind=kind,
        ref_id=str(decision.id),
        title=title,
        template_name=template_name,
        pack_id=pack.pack_id,
        pack_version=pack.version,
        # A determination's window is the day it was assessed *as at*, not the
        # day it was recorded. Same question as a return's period, answered from
        # the same field the rules were selected by.
        window_start=decision.as_of,
        window_end=decision.as_of,
        pdf=pdf,
        markup=html,
    )


def _to_pdf(html: str) -> bytes:
    """HTML to PDF bytes, and never to a file.

    Rendered to bytes rather than to a path so the plaintext PDF never exists on
    disk. Writing it and then encrypting in place would leave a window — and, on
    a crash inside it, a readable client document lying about.

    Deterministic, and this is checked rather than assumed: WeasyPrint 69 embeds
    no creation date, no modification date and no document id, so the bytes are
    a pure function of the markup. `test_artefacts_at_scale.py` asserts it, so
    that a version bump which starts stamping a timestamp fails a test rather
    than quietly breaking the regeneration guarantee.
    """
    from weasyprint import HTML  # imported lazily: pulls in cairo/pango

    return bytes(HTML(string=html, base_url=str(TEMPLATE_DIR)).write_pdf())


def digest(value: Any) -> str:
    """Canonical digest of a JSON-shaped value.

    Sorted keys, for the reason `lifecycle.content_hash` gives: key order
    carries no meaning, and a hash that changed when a dictionary was rebuilt
    would be useless for the wrong reason.
    """
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()
    ).hexdigest()


def inputs_hash(
    *,
    kind: str,
    ref_id: str,
    pack_id: str,
    pack_version: int,
    markup: str,
) -> str:
    """Everything the bytes are a function of, hashed.

    **The markup, not a list of the things that went into it.** That is the
    whole design, and it arrived by getting the other version wrong three times.

    Enumerating inputs meant enumerating them *correctly*, and each omission
    looked identical to a broken renderer: the firm's letterhead is in the
    document, so a trading-name change is a different document; the figures are
    in it, so `AU:2026-Q1:all` names a query rather than a result; and a
    determination's document shows whether it was later overridden, which is not
    covered by the determination's own chain hash. Three inputs, three
    false alarms, and no reason to believe the fourth would have been the last.

    The rendered HTML is every input by construction. Nothing can be forgotten
    from it, because anything that changes the document changes it. What is left
    over — identical markup producing different bytes — is a defect in the
    renderer with nowhere to hide, which is exactly what the guard should mean.
    """
    return digest(
        {
            "kind": kind,
            "ref_id": ref_id,
            "pack_id": pack_id,
            "pack_version": pack_version,
            # The document itself, hashed. The three fields above add nothing to
            # the comparison — the markup already differs if any of them do —
            # and they are here so that a row's fingerprint is legible next to
            # its neighbours rather than being one opaque digest.
            "markup": hashlib.sha256(markup.encode()).hexdigest(),
        }
    )


def _record(
    session: Session,
    *,
    kind: str,
    ref_id: str,
    title: str,
    template_name: str,
    pack_id: str,
    pack_version: int,
    window_start: date | None,
    window_end: date | None,
    pdf: bytes,
    markup: str,
) -> Artefact:
    """Seal the bytes and write the row that accounts for them.

    **Regeneration finds the existing row rather than writing a second one.**
    The same kind, the same subject and the same pack version is the same
    document — §S7 requires it to be byte-identical, and a second row claiming
    the same thing would make "which one did we file" a question with two
    answers. The row's `created_at` keeps the first production; a regeneration
    that produced different bytes would be a defect and is raised as one.

    The filename carries the content hash rather than a timestamp, so the file a
    regeneration writes is the file that was already there.
    """
    content_hash = hashlib.sha256(pdf).hexdigest()
    fingerprint = inputs_hash(
        kind=kind,
        ref_id=ref_id,
        pack_id=pack_id,
        pack_version=pack_version,
        markup=markup,
    )
    # The filename carries the content hash rather than a timestamp, so a
    # regeneration writes the file that is already there, and a document
    # produced from changed inputs sits beside the old one rather than
    # overwriting it. `ref_id` can hold a colon (a period reference is
    # `AU:2026-08:all`), which is legal in a filename and would be confusing in
    # one, so it is flattened.
    safe_ref = ref_id.replace(":", "-").replace("/", "-")
    filename = f"{kind}_{safe_ref}_v{pack_version}_{content_hash[:12]}.pdf"
    _seal(filename, pdf)

    existing = session.scalars(
        select(Artefact).where(
            Artefact.kind == kind,
            Artefact.ref_id == ref_id,
            Artefact.pack_version == pack_version,
        )
    ).first()
    if existing is not None:
        same_inputs = existing.inputs_hash == fingerprint
        if same_inputs and existing.content_hash and existing.content_hash != content_hash:
            raise NotDeterministic(
                kind,
                ref_id,
                existing.content_hash,
                content_hash,
                stored=read_pdf(existing.pdf_ref),
                produced=pdf,
            )
        # Filled in rather than left blank for rows written before provenance
        # existed. These are facts about the document, not guesses: the bytes in
        # front of us are what they describe.
        #
        # `generated_by` is the exception in both directions. It is *not*
        # overwritten when it is set — whoever first asked for a document is who
        # the row is about, and a regeneration is not a new document. But an
        # empty one is filled, because a row written before this column existed
        # records nobody, and the person who just produced the bytes on disk is
        # a better answer than none. Not a guess: they did.
        if not existing.generated_by:
            existing.generated_by = current_user_or_none() or ""
        existing.content_hash = content_hash
        existing.inputs_hash = fingerprint
        existing.pdf_ref = filename
        existing.template_version = template_name
        existing.pack_id = pack_id
        existing.window_start = window_start
        existing.window_end = window_end
        session.flush()
        return existing

    artefact = Artefact(
        kind=kind,
        ref_id=ref_id,
        title=title,
        template_version=template_name,
        pdf_ref=filename,
        pack_id=pack_id,
        pack_version=pack_version,
        window_start=window_start,
        window_end=window_end,
        generated_by=current_user_or_none() or "",
        content_hash=content_hash,
        inputs_hash=fingerprint,
    )
    session.add(artefact)
    session.flush()
    return artefact


def render_run(session: Session, *, kind: str, run_id: int) -> Artefact:
    """The document for one bulk sweep.

    The figures come from `bulk` rather than being recomputed here, for the same
    reason `render_period` takes its aggregation as an argument: what a caller
    saw on screen must be what reaches the PDF, and a renderer that recomputed
    would leave a window where the two could disagree.

    The pack is the one in force for the regime the run covered, at the run's own
    `as_of` — so a report about a sweep is titled by the rules that sweep used.
    For a dry run the version asked about may not be the one in force for this
    tenant, which is exactly what the document says on its face.
    """
    from .. import bulk
    from ..models import EvalRun

    run = session.get(EvalRun, run_id)
    if run is None:
        raise KeyError(f"unknown run {run_id}")

    jurisdiction = run.jurisdiction or service_module.DEFAULT_JURISDICTION
    pack = packs_repo.active(session, jurisdiction, run.as_of)
    if scope_of(kind, pack) != RUN_SCOPE:
        raise KeyError(f"{kind!r} is not a document about a sweep")
    template_name = pack.artefact_templates.get(kind)
    if template_name is None:
        raise KeyError(f"pack v{pack.version} defines no template for {kind!r}")

    title = pack.artefact_titles.get(kind, kind.replace("_", " ").title())
    stats = bulk.stats(session, run_id)
    # Bounded, and the document says when it is. A filing is not the right place
    # to read two thousand rows, and a report that silently stopped at a limit
    # would be worse than one that says it did.
    limit = 400
    deltas = bulk.deltas(session, run_id, limit=limit)

    html = _env.get_template(template_name).render(
        title=title,
        kind=kind,
        run=stats,
        deltas=deltas,
        truncated=stats["changed"] > len(deltas),
        pack=pack,
        branding=branding(session),
    )

    return _record(
        session,
        kind=kind,
        ref_id=f"run:{run_id}",
        title=title,
        template_name=template_name,
        pack_id=jurisdiction,
        pack_version=pack.version,
        window_start=run.as_of,
        window_end=run.as_of,
        pdf=_to_pdf(html),
        markup=html,
    )


def preview(
    session: Session,
    *,
    body: dict,
    kind: str,
    decision_id: int | None = None,
    report: dict | None = None,
) -> str:
    """The document a draft's templates would produce, as HTML, storing nothing.

    §S5 asks for an artefact template preview with sample data, and the reason it
    matters is invariant 8: artefact titles and templates are *pack content*. A
    specialist changing "Target Market Determination" to something else, or
    pointing a regime at a different template, is changing what a regulator
    receives — and finding out after publication is finding out too late.

    Both document shapes are covered, because a pack defines both and previewing
    only half of them would leave the periodic return — the one that actually
    gets filed — unlookable-at. Per-decision documents take a `decision_id`;
    period documents take an already-computed `report`, aggregated by the caller
    exactly as `render_period` requires, so that what is previewed is what the
    filed version would contain.

    Three deliberate differences from `render`:

    * **The pack comes from the draft, not from the shelf.** That is the whole
      point: it shows what the proposed content would produce, against real
      figures so the page is full of numbers a reader can check rather than
      `lorem ipsum`.
    * **HTML rather than PDF.** It is shown inline in the workbench and nobody
      is filing it, so paying WeasyPrint's several seconds per click would buy
      nothing the eye can see. The PDF pipeline is exercised by `render` and
      `render_period`, on every real artefact, and has its own tests.
    * **Nothing is written.** No `Artefact` row, no sealed file. A preview that
      left a document behind would put an unsigned pack's output into the
      evidence store, where it would be indistinguishable from one somebody
      meant to keep.
    """
    from ..engine import Pack as EnginePack

    pack = EnginePack.from_body(body)
    template_name = pack.artefact_templates.get(kind)
    if template_name is None:
        raise KeyError(
            f"this draft defines no template for {kind!r}. Known kinds: "
            + (", ".join(sorted(pack.artefact_templates)) or "none")
        )

    title = pack.artefact_titles.get(kind, kind.replace("_", " ").title())
    context: dict[str, Any] = {}

    if scope_of(kind, pack) == PERIOD_SCOPE:
        if report is None:
            raise KeyError(f"{kind!r} is a period document and needs a report")
        context["report"] = report
    else:
        if decision_id is None:
            raise KeyError(f"{kind!r} is a per-decision document and needs a decision")
        decision = session.get(Decision, decision_id)
        if decision is None:
            raise KeyError(f"unknown decision {decision_id}")
        # The decision is viewed through the *draft's* pack, which is what makes
        # this a preview of the change rather than of what is already in force.
        context["decision"] = decision_view(session, decision, pack)

    return _env.get_template(template_name).render(
        title=title,
        kind=kind,
        pack=pack,
        branding=branding(session),
        **context,
    )


def render_period(
    session: Session,
    *,
    kind: str,
    report: dict,
    jurisdiction: str = "AU",
) -> Artefact:
    """Render a period-scoped document from an already-computed aggregation.

    The aggregation is passed in rather than computed here so the exact figures
    a caller previewed on screen are the figures that reach the PDF. Recomputing
    inside the renderer would leave a window where the two could disagree.

    The template and title come from the pack in force at the *end* of the
    period — that is the configuration the document is filed under. Where the
    period straddles a pack change, every version applied is listed in the body,
    so the choice of reporting pack never hides one.
    """
    period_end = date.fromisoformat(report["period_end"])
    pack = packs_repo.active(session, jurisdiction, period_end)
    if scope_of(kind, pack) != PERIOD_SCOPE:
        raise KeyError(
            f"{jurisdiction} v{pack.version} does not declare {kind!r} as a period "
            "document. `artefact_scopes` in the pack decides that."
        )
    template_name = pack.artefact_templates.get(kind)
    if template_name is None:
        raise KeyError(f"pack v{pack.version} defines no template for {kind!r}")

    title = pack.artefact_titles.get(kind, kind.replace("_", " ").title())

    html = _env.get_template(template_name).render(
        title=title,
        kind=kind,
        report=report,
        pack=pack,
        branding=branding(session),
    )

    # `period` is validated against YYYY-MM / YYYY-Qn upstream, so it cannot
    # carry a path separator into the reference.
    scope = report["scenario"] or "all"
    return _record(
        session,
        kind=kind,
        ref_id=f"{jurisdiction}:{report['period']}:{scope}",
        title=title,
        template_name=template_name,
        pack_id=jurisdiction,
        pack_version=pack.version,
        window_start=date.fromisoformat(report["period_start"]),
        window_end=period_end,
        pdf=_to_pdf(html),
        markup=html,
    )
