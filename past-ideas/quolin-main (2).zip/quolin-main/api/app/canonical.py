"""Canonical JSON and the evidence hash chain.

Canonicalisation has to be stable or the chain is worthless: sorted keys,
no incidental whitespace, no float formatting differences (there are no floats).
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

GENESIS = "0" * 64


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def chain_hash(prev_hash: str, row: dict) -> str:
    return hashlib.sha256((prev_hash + canonical_json(row)).encode("utf-8")).hexdigest()


def content_hash(body: Any) -> str:
    """SHA-256 of a document, canonically serialised. What a signature attests to.

    Canonical because the hash has to be the same tomorrow: JSON key order is not
    meaningful, and a hash that changed when a dictionary was rebuilt would make
    "is this what was signed" unanswerable for the wrong reason.

    Deliberately **not** `canonical_json` above, and the difference is one flag.
    This has hashed pack bodies since Stage 5 with `ensure_ascii` left at its
    default, and every `pack_drafts.content_hash` on file was computed that way.
    Bringing it into line would be tidier and would silently invalidate every
    signature attestation already recorded — a change to stored evidence to make
    a serialisation consistent, which is not a trade worth making. So the two
    live side by side, with the reason written down.

    Moved here from `watch/lifecycle.py` because Q-04 needs the same value in
    the decision manifest, and `app/watch` may not be imported by the evidence
    layer. `lifecycle.content_hash` now delegates, so there is one definition
    and it produces exactly the bytes it always has.
    """
    return hashlib.sha256(
        json.dumps(body, sort_keys=True, separators=(",", ":"), default=str).encode()
    ).hexdigest()
