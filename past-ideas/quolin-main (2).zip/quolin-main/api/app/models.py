from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    Computed,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    LargeBinary,
    String,
    Text,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from .crypto import (
    EncryptedDate,
    EncryptedJSON,
    EncryptedText,
    PlatformEncryptedText,
)
from .db import Base
from .tenancy import current_tenant, current_user_or_none

APPEND_ONLY_TABLES = (
    "packs",
    # Q-12. Who put a piece of global rule content in front of every customer.
    "pack_publications",
    # Tier 3. Somebody rewriting a firm's evidence hashes, and why. A rechain
    # that could be un-recorded is a rechain that was never recorded.
    "chain_rechains",
    "decisions",
    "overrides",
    "audit_events",

    "chain_anchors",
    # Stage 5. How a piece of rule content came to be in force is evidence in
    # the same sense the decisions made under it are. A transition log that
    # could be edited would be a story rather than a record.
    "pack_draft_transitions",
    # Stage 9. The record somebody reads after an incident.
    "security_events",
    # Stage 10. A firm moving along the adoption ladder, and who signed for it.
    "tenant_stages",
    # Migration 0047. Who belongs to this firm. Append-only for a sharper
    # reason than most of this list: a membership somebody could delete is a
    # membership somebody could delete to make an actor stop resolving, which
    # is the exact defect the table was created to remove, performed one step
    # further down.
    "tenant_members",
    # Stage 6. What a model was asked and what it answered. An officer read a
    # summary and acted on it, so "what did it actually say" is part of how a
    # decision came to be made — and it has to be answerable in two years by
    # somebody who does not trust us.
    "watch_assist_calls",
    # FP3-10. Both of these carried the append-only trigger from the migration
    # that created them and were never named here, so this constant claimed
    # eleven protected tables against a database enforcing thirteen. Nothing was
    # unprotected by the omission — the triggers were always there — but every
    # test parametrised over this tuple skipped them, which is the failure mode
    # that matters: the assertion that they refuse a write was never made.
    #
    # `auth_attempts` is the record of an attack, and Stage 9's stated property
    # is that it survives the attacker. `source_verifications` is a named person
    # attesting that they checked a publication nothing can poll, which is the
    # evidence that monitoring happened at all.
    #
    # Clearing either is a real operation and both do it the sanctioned way:
    # `conftest.reset_rate_limit_for_tests` disables the trigger as the owner,
    # the only pattern in this repository allowed to write to an append-only
    # table — and it lives in the suite, not in `app.auth`, because F2 found
    # that leaving it in a module every request imports made this reachable
    # from a handler.
    "auth_attempts",
    "source_verifications",
    # FP3-03. When a regulator's feed was known to be dark, and when each firm
    # was told. "When did you know" is not a question whose answer may be edited.
    "source_breaches",
    "source_breach_notices",
    # FP3-08. Which firms were told that the rules governing them had changed,
    # and when. §S5's advance window is measured from it.
    "pack_events",
    "pack_event_notices",
    # FP3-27. Who agreed that a piece of rule content should govern every
    # customer on the platform.
    "publication_approvals",
    # FP3-17. The per-day record that a firm was told it is operating on
    # superseded rules — the answer to "did they know".
    "review_overdue_notices",
    # FP3-23. What the customer's own system said about a client on a date. It
    # is the number a shadow-mode engagement closes on, it was editable in place
    # by the application role, and every other figure here is chained precisely
    # so that cannot be done to it. A restatement is a new row now.
    "incumbent_outcomes",
)

#: Tables that are nobody's in particular — the platform's own, or facts about
#: the world rather than about a customer. Named here so the classification
#: assertion in `tests/test_rls.py` has one place to read rather than a list
#: maintained beside it.

#: **`artefacts` is deliberately not here.** FP3-10 found three lists disagreeing
#: — the old linter's regex named it, this tuple did not, and the schema carried
#: no trigger — and the first attempt at reconciling them made it append-only.
#: Sixteen tests went red and explained why: `artefacts/renderer.py` re-renders
#: an existing document in place, which is §S7's design rather than an
#: oversight. What is genuinely write-once is `content_hash`, the document's
#: identity, and migration 0041 enforces that with its own trigger.
#:
#: Tables that belong to exactly one customer, and are therefore protected by
#: row-level security. Every one of them carries `tenant_id NOT NULL`.
#:
#: `packs` and `assets` are deliberately absent. Packs are the product's
#: content — the same AU rules govern every customer, and copying them per
#: tenant would mean four jurisdictions times N customers of rule content to
#: keep in step, which is how two customers end up on different rules by
#: accident. Which packs a tenant has *enabled*, and its advance policy, are
#: tenant config and live on the tenant row.
#:
#: `watch_sources` and `watch_events` are also global: what a regulator
#: published is not a fact about a customer. When check history becomes
#: per-tenant it will be a separate table, not a column here.
TENANT_SCOPED_TABLES = (
    "clients",
    "decisions",
    "overrides",
    "artefacts",
    "audit_events",
    "pack_drafts",
    "auth_sessions",
    "chain_anchors",
    "tenant_keys",
    "user_roles",
    #: Who belongs to this firm, which is not the same fact as what they may do
    #: here — migration 0047. Tenant-scoped, because a membership is one firm's
    #: statement about one person and no other firm's business.
    "tenant_members",
    # Stage 4. Every one of these is a fact about one customer: who may call
    # their API, what has already been written once, where their events go, how
    # their field names map onto ours, and what their batch runs did.
    "api_clients",
    "idempotency_keys",
    "webhook_endpoints",
    "webhook_deliveries",
    "integr_mappings",
    "import_runs",
    # Stage 7. A document somebody asked for is that customer's business, and
    # the queue is read by workers that must not be able to claim across
    # tenants.
    "artefact_jobs",
    # Stage 9. What happened *to* the system: failed sign-ins, denials.
    "security_events",
    # Stage 10. Where a firm is on the adoption ladder, and what their own
    # system said about the same clients.
    "tenant_stages",
    # A named person attesting that they checked a publication nothing can
    # poll. One firm's attestations are not another's — a specialist verifying
    # for one licensee says nothing about a second licensee's monitoring — so
    # it is scoped like the rest of their evidence.
    "source_verifications",
    "incumbent_outcomes",
    # A rewrite of one firm's evidence chain is that firm's business.
    "chain_rechains",
    # FP3-11. How each of a firm's people came to hold a credential.
    "invitations",
    # FP3-17. Which days this firm was told its rules were superseded.
    "review_overdue_notices",
    # FP3-03. Which breaches this firm has already been told about. The breach
    # itself is global — a publisher being down is not a fact about a customer —
    # but what we told whom is per firm, and it carries `tenant_id`, which
    # `test_packs_stay_global` rightly refuses to see on a table with no policy.
    "source_breach_notices",
    # FP3-08, and the same split for the same reason: the pack event is global,
    # the record of telling this firm about it is theirs.
    "pack_event_notices",
    # Stage 8. A sweep of a book, its chunks of work, and what changed.
    "eval_runs",
    "eval_chunks",
    "eval_deltas",
    # Stage 5. A draft's history and a tenant's response to a new version are
    # both facts about one customer's workflow.
    "pack_draft_transitions",
    "tenant_advances",
)

#: Tables holding people rather than customers or content, and the reason there
#: are three categories rather than two.
#:
#: A user is not tenant-scoped: the execution document requires that one person
#: may hold different roles in different tenants, which a `tenant_id` column
#: cannot express. But they are emphatically not global either — `packs` are
#: global because every customer *should* see the same AU rules, whereas one
#: customer seeing another's staff list is precisely the disclosure Stage 1
#: exists to prevent.
#:
#: So these carry no `tenant_id` and are policed by reachability instead: a row
#: is visible when the current tenant holds a role grant for that user. The
#: policy lives in migration 0007 and is asserted in `tests/test_rls.py`
#: alongside the tenant-scoped ones, because "enabled and forced" has to be true
#: here for the same reason it does there.
PLATFORM_TABLES = (
    "users",
    "user_identities",
    "mfa_credentials",
)

#: The Postgres setting every policy reads. Set per request from the
#: authenticated session, and unset by default — a connection that has not said
#: who it is sees nothing.
TENANT_SETTING = "app.tenant_id"

#: The tenant a row belongs to, on every table in TENANT_SCOPED_TABLES.
#:
#: Declared per class rather than through a mixin so that the column, its
#: foreign key and its index are visible in the model somebody actually reads.
#: It is indexed on every table because the RLS policy adds `tenant_id = ...`
#: to every query against it, including the ones that already had a good index
#: — an unindexed predicate that appears in literally every plan is the kind of
#: thing that looks fine on demo data and falls over on a production book.
_TENANT_FK = "tenants.id"


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Tenant(Base):
    """A customer.

    Not itself tenant-scoped, for the obvious reason that the row defining a
    tenant cannot be filtered by the tenant it defines. It is readable by the
    application and writable only by the owner — creating a customer is an
    administrative act, not something a request does.
    """

    __tablename__ = "tenants"

    #: A slug, not a serial. It appears in `current_setting('app.tenant_id')`,
    #: in log lines and in support conversations, and "tenant 7" is a value
    #: somebody eventually mistypes as "tenant 8" without noticing.
    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String)
    #: Where this tenant's data is hosted. Recorded per tenant rather than read
    #: from the deployment, because a dedicated stack (Stage 11) may sit in a
    #: different region from the shared one and the answer to "where is our
    #: data" must not depend on which process is answering.
    #: Where this firm's data lives. **Required — no default.** FP3-02, audit G-07.
    #:
    #: This defaulted to `ap-southeast-2`, so a European customer created
    #: through the API was recorded as Sydney-resident by a default argument.
    #: Data residency is the first question a GDPR or APRA conversation asks and
    #: it is not one a keyword argument should answer quietly.
    #:
    #: Sydney is still the default *for the deployment* — `variable "region"` in
    #: `infra/variables.tf`, where somebody reads it in a plan. What is removed
    #: is the second, silent copy of that decision sitting on every new row.
    region: Mapped[str] = mapped_column(String)

    #: The clock this firm's business day is measured on, as an IANA name.
    #:
    #: FP3-05. A business date is not a fact about the process — `date.today()`
    #: on ECS is UTC, and for a Sydney firm that is the previous day for ten
    #: hours of every working morning.
    #:
    #: Null means "derive it from the region", which is right for every firm
    #: whose hosting region and business clock agree. A column that had to be
    #: filled in correctly for every new tenant is a column that is eventually
    #: filled in wrongly.
    #:
    #: Not in `config`, deliberately: `quolin_app` holds `UPDATE (config)` so a
    #: customer can change their own settings, and moving this retrospectively
    #: would change which pack version was in force for a day's determinations.
    #: It is provisioning, set by whoever sets the region.
    business_timezone: Mapped[str | None] = mapped_column(String, nullable=True)
    #: `shared` or `dedicated`. Stage 11 deploys the second from the same IaC.
    tier: Mapped[str] = mapped_column(String, default="shared")
    status: Mapped[str] = mapped_column(String, default="active", index=True)
    #: Where this firm is on the adoption ladder: `pilot`, `shadow`, `limited`
    #: or `full`. See `app/adoption.py`.
    #:
    #: Denormalised onto the row rather than derived from `tenant_stages`,
    #: because every determination asks it — whether an outcome may have an
    #: effect in the world depends on it — and a join on every write to answer
    #: a question that changes four times in a customer's life is the wrong
    #: trade. The transition log remains the record of how it got here.
    stage: Mapped[str] = mapped_column(
        String, default="pilot", server_default=text("'pilot'"), index=True
    )
    #: Enabled packs, advance policy, and anything else that is a choice this
    #: customer made rather than a property of the product.
    #:
    #: `quolin_app` holds `UPDATE (config)` — migration 0012 — so a firm can set
    #: its own advance policy through the product. Nothing that is a *control*
    #: belongs in here for exactly that reason; see the column below.
    config: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)
    #: Whether this firm may decide on rule content nobody has signed.
    #:
    #: The single override on the refusal the execution plan says cannot be
    #: waived, and therefore a column rather than a key in `config`. Q-11: it
    #: lived in that JSON blob, which the application role may rewrite, so any
    #: request path that touched `config` — today or the one written next
    #: quarter — carried the permit with it.
    #:
    #: No `UPDATE` grant to `quolin_app`, and column grants are additive, so
    #: this is unwritable by anything serving HTTP. It is set by an owner: by
    #: migration, or by somebody with a database session. See migration 0032 and
    #: `packs_repo._may_use_unreviewed`.
    illustrative_content_permitted: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default=text("false")
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class ChainAnchor(Base):
    """Where one tenant's evidence chain starts.

    Before multi-tenancy there was one chain and it began at a constant, sixty-
    four zeroes. That does not survive a second customer. Each decision's hash
    covers the previous decision's hash, so a single global chain threads
    through every tenant's records — and a tenant that can only see its own
    rows would find its chain full of links to hashes it has no row for. The
    guarantee would report itself broken, correctly, and be useless.

    So each tenant gets its own chain, and each chain gets its own start.

    **Why a stored row rather than a derived constant.** The obvious cheaper
    move is `sha256("genesis" + tenant_id)` — no table, no migration. It gives
    every tenant a distinct start, which is most of the value. What it does not
    give is a *moment*. This row records when a tenant's evidence began, and
    because `created_at` is inside the hash, a tenant that is deleted and
    recreated under the same slug does not silently inherit the old chain's
    identity: the new anchor differs, so nothing from the old chain verifies
    against it. A derived constant would let the two be confused, and "these
    records are from the account we closed and reopened" is precisely the kind
    of thing an auditor is entitled to be able to tell apart.

    Append-only and tenant-scoped like the decisions it anchors. Rewriting an
    anchor would rewrite the meaning of every hash beneath it, which makes it
    evidence in exactly the same sense.
    """

    __tablename__ = "chain_anchors"

    #: One chain per tenant, so the tenant is the key. A second anchor for the
    #: same tenant is not a supported state and the primary key says so.
    tenant_id: Mapped[str] = mapped_column(ForeignKey(_TENANT_FK), primary_key=True)
    #: `chain_hash(GENESIS, {"created_at": ..., "tenant_id": ...})`. The first
    #: decision's `prev_hash` is this value.
    genesis_hash: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class TenantKey(Base):
    """A customer's data key, wrapped by the master key this deployment holds.

    Deliberately *not* append-only, which makes it the only tenant-scoped table
    that is not. Rotation rewraps this row in place — that is the whole of what
    rotation does — and a table that refused UPDATE would make the one key
    operation the system supports impossible to perform.

    Why that is safe: the row holds no evidence. It is a key sealed under
    another key, and the value it protects is the plaintext data key, which
    never changes when the wrapper does. Overwriting `wrapped_key` with a
    rewrap of the *same* data key is not a rewrite of history; overwriting it
    with a wrap of a *different* one would make every ciphertext unreadable
    immediately and loudly, which is not a failure mode that hides.

    The reasoning for the envelope itself is in `app/crypto.py`.
    """

    __tablename__ = "tenant_keys"

    tenant_id: Mapped[str] = mapped_column(ForeignKey(_TENANT_FK), primary_key=True)
    #: `crypto.wrap(data_key, tenant_id)` — AES-256-GCM, with the tenant in the
    #: additional data, so this value is useless on any other tenant's row.
    wrapped_key: Mapped[bytes] = mapped_column(LargeBinary)
    #: How many times this key has been rewrapped. Not a version of the data
    #: key — there is only ever one of those per tenant — but a record that the
    #: rotation procedure has run, which is a question an auditor asks and a
    #: timestamp alone answers badly.
    rewraps: Mapped[int] = mapped_column(Integer, default=0, server_default=text("0"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    rewrapped_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class Client(Base):
    __tablename__ = "clients"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    scenario: Mapped[str] = mapped_column(String, index=True)
    #: Encrypted under the tenant's data key. The three columns that identify a
    #: human being rather than describe a position: what they are called, when
    #: they were born, and whatever an adviser has written about them.
    #:
    #: They are ciphertext in the database, which means Postgres cannot order,
    #: match or index them. `DbClientProvider.list` sorts by name in Python for
    #: exactly this reason. That cost is the point — a column the database can
    #: sort is a column the database can read.
    name: Mapped[str] = mapped_column(EncryptedText("clients.name"))
    dob: Mapped[date] = mapped_column(EncryptedDate("clients.dob"))
    client_category: Mapped[str] = mapped_column(String)
    knowledge_assessed: Mapped[bool] = mapped_column(Boolean)
    knowledge_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    loss_capacity_band: Mapped[int] = mapped_column(Integer)
    vulnerability_flag: Mapped[bool] = mapped_column(Boolean)
    assessable_portfolio_cents: Mapped[int] = mapped_column(BigInteger)
    prior_crypto_purchases: Mapped[int] = mapped_column(Integer, default=0)
    structural_acks: Mapped[list] = mapped_column(JSONB, default=list)
    default_trade_amount_cents: Mapped[int] = mapped_column(BigInteger)
    #: The jurisdiction of the licensee through which this client is advised.
    #: It is a property of the advice relationship, not of the person — which is
    #: why residency and domicile are separate columns rather than inferred.
    jurisdiction: Mapped[str] = mapped_column(String, default="AU")
    #: Where the client lives. Regimes attach to residents.
    residency: Mapped[str] = mapped_column(String, default="AU", server_default=text("'AU'"))
    #: Where the client is domiciled. Usually the same as residency, and when it
    #: is not, that difference is the whole reason a second regime applies.
    domicile: Mapped[str] = mapped_column(String, default="AU", server_default=text("'AU'"))
    note: Mapped[str] = mapped_column(EncryptedText("clients.note"), default="")
    # Membership of the hand-written demo book. Set by the seed and by nothing
    # else. An imported client is a real client, but it is not one of the six the
    # walkthrough was written around. This was previously inferred from `note`
    # being non-empty, which made cast membership something an importer could
    # grant itself by filling in a free-text column.
    is_cast: Mapped[bool] = mapped_column(Boolean, default=False, server_default=text("false"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Asset(Base):
    __tablename__ = "assets"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    symbol: Mapped[str] = mapped_column(String)
    name: Mapped[str] = mapped_column(String)


class Pack(Base):
    __tablename__ = "packs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    jurisdiction: Mapped[str] = mapped_column(String, index=True)
    version: Mapped[int] = mapped_column(Integer)
    effective_from: Mapped[date] = mapped_column(Date)
    effective_to: Mapped[date | None] = mapped_column(Date, nullable=True)
    body: Mapped[dict] = mapped_column(JSONB)
    signed_by: Mapped[str] = mapped_column(String, default="")
    signed_at: Mapped[str] = mapped_column(String, default="")
    #: `REVIEWED`, `PENDING_REVIEW` or `ILLUSTRATIVE`, generated by the database
    #: from the pack's own body (migration 0025).
    #:
    #: Generated rather than written, so the column and the content cannot
    #: disagree: there is no insert path that could set one without the other.
    #: `packs_repo` filters on it, and a CHECK constraint stops a row claiming
    #: REVIEWED with a placeholder where the signatory's name should be.
    content_status: Mapped[str] = mapped_column(
        Text,
        Computed(
            "COALESCE(NULLIF(body ->> 'content_status', ''), 'ILLUSTRATIVE')",
            persisted=True,
        ),
    )
    #: SHA-256 of `body`, canonically serialised. Written at publication, so
    #: "what are the bytes of this pack" is answerable without evaluating it.
    #:
    #: A plain column rather than a generated one, unlike `content_status`
    #: above: the hash has to be the same value Python computes, and Postgres's
    #: `jsonb::text` is not the canonical serialisation `app/canonical.py` uses.
    #: Empty on rows published before migration 0031 — `packs` is append-only,
    #: so there is no backfill, and an empty hash is the honest record of a pack
    #: published before hashes were kept.
    content_hash: Mapped[str] = mapped_column(String(64), default="")


class Decision(Base):
    __tablename__ = "decisions"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    client_id: Mapped[str] = mapped_column(ForeignKey("clients.id"), index=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id"))
    as_of: Mapped[date] = mapped_column(Date)
    #: The governing pack — the licensee's jurisdiction. It decides which
    #: artefact templates and titles this decision's documents are drawn from,
    #: and, on a cross-border decision, which pack's precedence block ordered
    #: the constraints. Nullable only so rows written before jurisdictions
    #: existed still read back; the seed writes it for every decision.
    pack_id: Mapped[str | None] = mapped_column(String, nullable=True, index=True)
    pack_version: Mapped[int] = mapped_column(Integer)
    #: Encrypted under the tenant's data key. The snapshot is the client's
    #: financial position, their portfolio, their holdings and their name, and
    #: it is the largest concentration of personal data in the system.
    #:
    #: Encrypting it does not weaken the chain: the hash is computed over the
    #: plaintext at the moment of the decision and stored beside it, so replay
    #: still reproduces the record exactly and a ciphertext that decoded to
    #: anything else would fail verification. `EncryptedJSON` encodes with the
    #: same canonical rules the hash uses, so the round trip is byte-exact.
    #:
    #: `rule_results` and `resolution` stay in JSONB. They are findings about
    #: rules — codes, thresholds and outcomes — and hold nothing that identifies
    #: anyone; encrypting them would cost the ability to aggregate over them for
    #: reports while protecting nothing.
    snapshot: Mapped[dict] = mapped_column(EncryptedJSON("decisions.snapshot"))
    rule_results: Mapped[dict] = mapped_column(JSONB)
    #: The bulk run that produced this determination, if one did. A
    #: determination made by an officer at a screen has none, and the
    #: distinction matters: "why is there a determination for this client on a
    #: Tuesday" is answered by naming the sweep.
    #:
    #: Unique together with the client and asset, which is what stops a chunk
    #: re-run after a mid-run kill from recording the same determination twice.
    #: The chunk transaction already prevents it; this is the second,
    #: independent statement of the same rule.
    run_id: Mapped[int | None] = mapped_column(
        ForeignKey("eval_runs.id"), nullable=True, index=True
    )
    #: Cross-border provenance: which jurisdictions applied, which one bound
    #: each constraint dimension, what each regime would have said alone, and
    #: every pair the packs gave no way to order. Null for a single-jurisdiction
    #: decision, because there was nothing to resolve.
    resolution: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)
    outcome: Mapped[str] = mapped_column(String, index=True)
    prev_hash: Mapped[str] = mapped_column(String)
    this_hash: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: The account that ran this check. Outside the hash on purpose — invariant 2
    #: says the frozen snapshot is the only input, and the operator is not one.
    #: Null on rows recorded before people existed; see migration 0008.
    decided_by: Mapped[str | None] = mapped_column(
        String, nullable=True, default=current_user_or_none
    )
    #: What actually ran, and on what content. See `app/manifest.py`.
    #:
    #: The pack's content hash, the snapshot's, the language version, the
    #: evaluator build and the snapshot-construction inputs. Inside the hashed
    #: payload under schema 2 below, because a manifest a later writer could
    #: change would attest to nothing.
    #:
    #: Null on every row written before migration 0031, which is what
    #: `payload_schema` records.
    manifest: Mapped[dict[str, Any] | None] = mapped_column(JSONB, nullable=True)
    #: Which shape this row's chain hash was computed over.
    #:
    #: 1 — everything before Q-04, hashed by a payload that has no manifest.
    #: 2 — the same fields plus the manifest.
    #:
    #: The chain hash is *recomputed* from these columns to verify it, so adding
    #: a field to the payload would break the chain on rows nobody had touched.
    #: Recording the shape instead means both can be verified forever, which is
    #: the same reason `engine/evaluate.py` keeps DSL v1 forever. See
    #: `app/manifest.py` and migration 0031.
    payload_schema: Mapped[int] = mapped_column(Integer, default=1)


class EvalRun(Base):
    """One sweep of a book, and why it happened.

    §S8: re-check the whole book when a new pack version becomes effective, when
    a client's profile changes, or on a schedule the pack configures. A run is
    the unit a compliance officer talks about — "pack v4 took effect and 212
    clients moved to REFER" is a sentence about a run — so it is a row rather
    than a log line.

    **Serialised within a tenant, and that is the evidence chain's doing.** Each
    determination's `prev_hash` is the previous determination's hash, so two
    workers appending to one tenant's chain at once would splice it. Chunks
    exist for resumability and progress, not for parallelism inside a tenant;
    parallelism is across tenants, where the chains are separate.
    """

    __tablename__ = "eval_runs"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    #: What caused it. `pack_effective`, `profile_change`, `periodic`, `manual`.
    #: Recorded rather than inferred, because "why was my whole book re-checked
    #: on a Tuesday" is the first question a customer asks about one of these.
    trigger: Mapped[str] = mapped_column(String, index=True)
    #: The regime swept, or empty for every regime this tenant is in.
    jurisdiction: Mapped[str] = mapped_column(String, default="")
    #: The date the determinations are made *as at*. A run is a re-check under
    #: today's rules by default, and pinning it is what makes a run reproducible.
    as_of: Mapped[date] = mapped_column(Date, default=date.today)

    status: Mapped[str] = mapped_column(String, default="planned", index=True)
    #: Evaluate and report, but record nothing.
    #:
    #: What a pinned tenant needs before they take a version: the deltas the new
    #: pack *would* produce, without determinations under rules they have not
    #: adopted. Writing those would put evidence in their chain that contradicts
    #: the version they are actually on, which is the opposite of what pinning
    #: is for.
    dry_run: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default=text("false")
    )
    #: The pack version a dry run is asking about, when it is not the one in
    #: force for this tenant. Null for an ordinary sweep.
    against_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    requested_by: Mapped[str] = mapped_column(String, default="")
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    finished_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    #: Per-run stats, which §S8 asks for by name. Counted as the run proceeds so
    #: that a half-finished run reports what it has actually done rather than
    #: nothing at all.
    pairs_total: Mapped[int] = mapped_column(Integer, default=0)
    pairs_done: Mapped[int] = mapped_column(Integer, default=0)
    changed: Mapped[int] = mapped_column(Integer, default=0)
    failures: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[str] = mapped_column(Text, default="")


class EvalChunk(Base):
    """A slice of a run's work, claimed by one worker at a time.

    The pairs are listed on the row rather than derived from an offset into an
    ordering. An offset is only stable if the underlying set is, and a client
    added mid-run would shift every chunk after it — silently re-doing some
    pairs and skipping others. A list cannot drift.

    One transaction per chunk, so a worker killed halfway leaves nothing
    half-written and the chunk is simply claimed again. The unique constraint on
    `decisions (run_id, client_id, asset_id)` is the second, independent
    statement of the same rule, for the case where a chunk committed and the
    process died before it could be marked done.
    """

    __tablename__ = "eval_chunks"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    run_id: Mapped[int] = mapped_column(ForeignKey("eval_runs.id"), index=True)
    seq: Mapped[int] = mapped_column(Integer)
    #: `[[client_id, asset_id], …]` — what this chunk is responsible for.
    pairs: Mapped[list] = mapped_column(JSONB, default=list)
    status: Mapped[str] = mapped_column(String, default="queued", index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    finished_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    last_error: Mapped[str] = mapped_column(Text, default="")


class EvalDelta(Base):
    """One client whose answer changed, and what changed it.

    §S8 calls the delta report a first-class artefact, and this is what it is
    built from. Stored rather than derived on demand for two reasons: the
    comparison is against *the determination in force before the run*, which
    stops being findable as soon as another run happens; and a pinned tenant's
    UAT decision in Stage 5 is made against this list, so it has to be the same
    list tomorrow.
    """

    __tablename__ = "eval_deltas"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    run_id: Mapped[int] = mapped_column(ForeignKey("eval_runs.id"), index=True)
    client_id: Mapped[str] = mapped_column(String, index=True)
    asset_id: Mapped[str] = mapped_column(String)
    from_outcome: Mapped[str] = mapped_column(String)
    to_outcome: Mapped[str] = mapped_column(String)
    from_pack_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    to_pack_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    #: Which rule made the difference, and the reason code it carries. "212
    #: clients moved to REFER" is a headline; "under AU-CONC-01, because the
    #: concentration limit moved from 15% to 10%" is what a regulator asks next.
    rule_id: Mapped[str] = mapped_column(String, default="")
    reason_code: Mapped[str] = mapped_column(String, default="")
    #: The determination this run produced. The one it replaced is reachable
    #: through the client's history and is deliberately not deleted.
    decision_id: Mapped[int | None] = mapped_column(
        ForeignKey("decisions.id"), nullable=True
    )


class Override(Base):
    __tablename__ = "overrides"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    decision_id: Mapped[int] = mapped_column(ForeignKey("decisions.id"), index=True)
    justification: Mapped[str] = mapped_column(Text)
    #: The name as it was given, kept because it is what the artefact printed.
    approver: Mapped[str] = mapped_column(String)
    #: The account behind that name, which is what separation of duties compares.
    #: Two people share a name; one person changes theirs.
    approved_by: Mapped[str | None] = mapped_column(
        String, nullable=True, default=current_user_or_none
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Artefact(Base):
    """A document that was produced, and everything needed to account for it.

    §S7: "every artefact records template version, pack version, data window,
    generator identity". The reason is a question a regulator asks about a
    document in front of them — *what produced this, from what, and who asked* —
    and the honest answer has four parts, none of which can be reconstructed
    later from the PDF itself.

    **The bytes are a function of the facts, and nothing else.** There is no
    wall-clock in the document: regenerating a return for the same period under
    the same pack version produces byte-identical output, which is §S7's gate
    and the property that makes `content_hash` worth storing. When it was
    produced is recorded here, beside the document, rather than printed inside
    it — those are two different facts and only one of them belongs in a filing.
    """

    __tablename__ = "artefacts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    kind: Mapped[str] = mapped_column(String)
    ref_id: Mapped[str] = mapped_column(String, index=True)
    title: Mapped[str] = mapped_column(String, default="")
    #: The template file, which is pack content. Named `template_version` since
    #: Stage 0 because the filename carries the version — `au_tmd_v2.html`.
    template_version: Mapped[str] = mapped_column(String)
    pdf_ref: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)

    #: Which regime's rules produced it, at which version. Not derivable from
    #: the template name: two versions of a pack can share a template, and the
    #: figures in the document come from the rules rather than the layout.
    pack_id: Mapped[str] = mapped_column(String, default="", server_default=text("''"))
    pack_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    #: The data this document covers. A period return covers a month; a
    #: determination document covers the day it was assessed. Stored for both,
    #: because "what window is this" is the same question either way and a
    #: reader should not have to know which kind they are holding.
    window_start: Mapped[date | None] = mapped_column(Date, nullable=True)
    window_end: Mapped[date | None] = mapped_column(Date, nullable=True)
    #: Who asked for it. A person or a machine credential — the same actor
    #: vocabulary the audit trail uses, so a document can be traced to the same
    #: row the quarterly access review asks about.
    generated_by: Mapped[str] = mapped_column(String, default="", server_default=text("''"))
    #: SHA-256 of the sealed document's plaintext bytes. Worth storing only
    #: because the bytes are deterministic: it is what makes "this is the same
    #: document we filed" a checkable claim rather than a hope.
    content_hash: Mapped[str] = mapped_column(String, default="", server_default=text("''"))
    #: SHA-256 over everything the bytes are a function of: the pack version,
    #: the subject, and the firm's own letterhead. What `content_hash` is
    #: compared against — without it, "the renderer started reading the clock"
    #: and "the customer changed their trading name" are the same observation.
    inputs_hash: Mapped[str] = mapped_column(String, default="", server_default=text("''"))


class TenantStageChange(Base):
    """A firm moving along the adoption ladder, and who signed for it.

    §S10: `pilot → shadow → limited → full`, and "transitions are logged,
    signed-off events". The signature is the point. Moving a customer from
    shadow to limited means their determinations start having effects in the
    world — an override reaching their case system, a document filed — and the
    question afterwards is always *who decided they were ready*.

    Append-only, like every other record of somebody deciding something. A
    ladder whose history could be edited would answer "when did they go live"
    with whatever is convenient.
    """

    __tablename__ = "tenant_stages"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    #: Null on the first row: a tenant coming into existence has no prior stage,
    #: and a sentinel would sort among the real ones in every query.
    from_stage: Mapped[str | None] = mapped_column(String, nullable=True)
    to_stage: Mapped[str] = mapped_column(String, index=True)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: The account that signed for it, and the name as given. Both, for the
    #: reason `pack_drafts` keeps both: two people share a name, and one person
    #: changes theirs.
    signed_by: Mapped[str] = mapped_column(String, default="")
    signed_by_user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    note: Mapped[str] = mapped_column(Text, default="")


class IncumbentOutcome(Base):
    """What the customer's existing system said about the same client and asset.

    §S10's comparison ingest. The whole value of shadow mode is the sentence
    "we agree with you 97% of the time, and here are the 3%" — which needs their
    answers beside ours, on the same pairs, as at the same date.

    **Their answer is recorded as given, including when it is unintelligible to
    us.** `outcome_raw` keeps whatever their file said; `outcome` is our
    mapping of it onto ALLOW/REFER/BLOCK. A firm whose system says `TIER_3` gets
    that preserved, because a divergence report that silently translated their
    vocabulary into ours would be arguing with a strawman.
    """

    __tablename__ = "incumbent_outcomes"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    client_id: Mapped[str] = mapped_column(String, index=True)
    asset_id: Mapped[str] = mapped_column(String, index=True)
    as_of: Mapped[date] = mapped_column(Date, index=True)
    #: Our three outcomes, or empty when their value did not map onto one.
    outcome: Mapped[str] = mapped_column(String, default="")
    #: Theirs, verbatim.
    outcome_raw: Mapped[str] = mapped_column(String, default="")
    #: Where the row came from — a file name, an API, a spreadsheet somebody
    #: sent. Kept because the first question about a divergence is whether their
    #: side of it is current.
    source: Mapped[str] = mapped_column(String, default="")
    received_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now
    )


class SecurityEvent(Base):
    """Something that happened *to* the system rather than in it.

    §S9 asks for alerting on auth anomalies and row-level-security denials, and
    neither had anywhere to be recorded. `audit_events` is the wrong home for
    both: an audit row names the person who acted, and the whole point of a
    failed sign-in is that nobody proved who they were. Stage 2 refuses an
    unattributed audit row, correctly, so these get their own table rather than
    a weakening of that rule.

    **Append-only.** This is the record somebody reads after an incident, and a
    record that can be edited afterwards answers a different question.

    **No email addresses.** A failed sign-in names the account when it resolves
    to one and says `unknown account` when it does not — because a table of
    addresses people typed at a login form is a list of who *might* have an
    account here, which is exactly what an attacker wants and what the rest of
    this system takes trouble to encrypt.
    """

    __tablename__ = "security_events"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    #: `auth.failed`, `auth.rate_limited`, `auth.reauth_failed`, `rls.denied`.
    kind: Mapped[str] = mapped_column(String, index=True)
    #: The account, when the attempt resolved to one. Never an address.
    user_id: Mapped[str | None] = mapped_column(String, nullable=True, index=True)
    #: Where from. Kept because a hundred failures from one address and a
    #: hundred from a hundred addresses are different incidents.
    source_ip: Mapped[str] = mapped_column(String, default="")
    detail: Mapped[str] = mapped_column(Text, default="")
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, index=True)


class AuthAttempt(Base):
    """Somebody tried to sign in. No tenant, because an attempt has none.

    §S12 found that failed sign-ins were being written to `security_events`,
    which is tenant-scoped, from `/auth/login`, where no tenant is in scope —
    so every one of them failed the policy's row check and was swallowed. Stage
    9's auth-anomaly alert was reading a table nothing was writing to.

    This is also the shared state that lets the API run more than one process.
    The rate limiter used to be a dictionary in memory, which meant a second
    task silently doubled the number of guesses an attacker got; `api_desired_count`
    was pinned at 1 for that reason, and pinned at 1 the API could use one core
    of twelve.

    **Append-only, and a success is a row rather than a deletion.** "A correct
    password clears the address" sounds like a DELETE and is not one: the
    limiter counts failures *since this address last succeeded*, so the record
    of an attack survives the attacker eventually guessing right.
    """

    __tablename__ = "auth_attempts"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    #: Where from. The only identifier available before anybody has proved who
    #: they are.
    source_ip: Mapped[str] = mapped_column(String, default="")
    #: The account, when the attempt resolved to one. Never an address typed
    #: into a form — see the note on SecurityEvent.
    user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    #: `failed`, `succeeded`, `rate_limited`.
    outcome: Mapped[str] = mapped_column(String)
    detail: Mapped[str] = mapped_column(Text, default="")
    #: The `X-Forwarded-For` header exactly as it arrived, and **not an address**.
    #:
    #: FP3-02. `source_ip` used to be the first entry of this header, which is
    #: whatever the client typed: thirty guesses from one host were recorded as
    #: thirty hosts that guessed once each, and the table Stage 9 describes as
    #: the record of an attack surviving the attacker recorded the attacker's
    #: chosen fiction instead.
    #:
    #: `source_ip` is now resolved by the ASGI server from the trusted proxy
    #: count. This is kept beside it because a spoofed header is itself worth
    #: seeing — and named at length so that nothing reads it as provenance.
    forwarded_for_untrusted: Mapped[str | None] = mapped_column(Text, nullable=True)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class ReviewOverdueNotice(Base):
    """One day on which one firm was told it is running on superseded rules.

    FP3-17. A pinned tenant whose review window has closed stays `PENDING` —
    the system does not auto-advance them and does not refuse their
    determinations. What it does instead is make the state impossible to miss
    and impossible to deny later, and this is the "impossible to deny" half.

    Unique on (tenant, regime, version, day), so a worker running every ten
    minutes sends one notification a day rather than a hundred and forty-four.
    An alert that arrives every ten minutes is one somebody filters into a
    folder, which is the same reasoning `source_alerts.page` gives.
    """

    __tablename__ = "review_overdue_notices"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(String, index=True, default=current_tenant)
    jurisdiction: Mapped[str] = mapped_column(String)
    pack_version: Mapped[int] = mapped_column(Integer)
    #: The firm's own business date. FP3-05.
    on_day: Mapped[date] = mapped_column(Date)
    days_overdue: Mapped[int] = mapped_column(Integer, default=0)
    sent_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class PlatformPublisher(Base):
    """Somebody at Quolin who may put rule content in front of every customer.

    FP3-27. `quolin_operator` is granted through `user_roles`, which is
    tenant-scoped — so a capability whose target is every tenant was authorised
    by a row belonging to one, and compromise of a single firm's role set
    reached every firm's regulatory content.

    **No `tenant_id` column, and no policy.** That is the control rather than an
    omission: a table with no tenant column cannot be written by a tenant-scoped
    grant, and there is nothing for a compromised firm's role set to say. The
    application may read it and cannot write it — minting a platform publisher
    is an owner operation, at the same bar as running a migration.
    """

    __tablename__ = "platform_publishers"

    user_id: Mapped[str] = mapped_column(String, primary_key=True)
    note: Mapped[str] = mapped_column(Text, default="")
    granted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    granted_by: Mapped[str] = mapped_column(String, default="")
    revoked_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class PublicationApproval(Base):
    """One platform publisher agreeing that a signed draft should go live.

    Publication needs two of these from two different people, neither of whom
    signed the draft. Three distinct humans: one attests the content is right,
    two each independently decide it should govern every customer.

    Append-only, because an approval somebody could withdraw quietly is not an
    approval. Unique per (draft, person), because two clicks from one publisher
    is one pair of eyes.
    """

    __tablename__ = "publication_approvals"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    draft_id: Mapped[int] = mapped_column(Integer, index=True)
    approved_by: Mapped[str] = mapped_column(String)
    #: The bytes this person approved. An approval of content that has since
    #: moved is not an approval of what is being published — F4's argument about
    #: the signature, applied to the second pair of eyes.
    content_hash: Mapped[str] = mapped_column(String, default="")
    approved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    note: Mapped[str] = mapped_column(Text, default="")


class Invitation(Base):
    """A single-use, expiring token that lets one person choose a password.

    FP3-11. `POST /admin/users` creates "a person, created with no way to sign
    in yet" and there was nothing that turned that into somebody who could sign
    in: no invite route, no set-password route, no reset. Every account that
    works today works because the seed gave it a password.

    The token is stored as a SHA-256 digest, like a session token, because this
    table is readable by the application role and a table of live credentials in
    plaintext is a worse problem than the one it solves.

    `consumed_at` rather than a delete: "this invitation was issued by that
    person on that date, and used on this one" is what an access review reads
    when it asks how somebody came to hold a credential — the same question
    `granted_by` answers for a role.
    """

    __tablename__ = "invitations"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(String, index=True, default=current_tenant)
    user_id: Mapped[str] = mapped_column(String, index=True)
    #: SHA-256 of the token. The token itself is returned once and never stored.
    token_hash: Mapped[str] = mapped_column(String)
    #: `invite` or `reset`. One mechanism; the word is what the trail says.
    kind: Mapped[str] = mapped_column(String, default="invite")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    created_by: Mapped[str] = mapped_column(String, default="")
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    consumed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class PackEvent(Base):
    """Something happened to global rule content, recorded for every firm to hear.

    FP3-08. `pack.staged` and `pack.published` went out through an RLS-scoped
    endpoint query inside the publisher's own tenant transaction — and packs are
    global while `quolin_operator` is held inside one tenant, so the only firm
    that could ever receive either was whichever tenant Quolin's own publisher
    happened to be acting in.

    Deliberately not the same table as `SourceBreach`. Both are global events
    fanned out per tenant, and one table with an `event` column would serve both
    — but the watch role holds INSERT on `source_breaches`, and a shared table
    would let a compromised sweep announce a publication that never happened to
    every customer on the platform.
    """

    __tablename__ = "pack_events"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    event: Mapped[str] = mapped_column(String)
    subject: Mapped[str] = mapped_column(String)
    #: The regime, so a firm licensed elsewhere is not told about it.
    jurisdiction: Mapped[str] = mapped_column(String)
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class PackEventNotice(Base):
    """One firm has been told about one pack event.

    §S5's advance window is measured from this: it is the evidence that a firm
    was given notice, which is a different claim from "we published something".
    """

    __tablename__ = "pack_event_notices"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    pack_event_id: Mapped[int] = mapped_column(BigInteger)
    tenant_id: Mapped[str] = mapped_column(String, default=current_tenant)
    notified_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class SourceBreach(Base):
    """A regulator's feed was dark, recorded by the only credential that saw it.

    FP3-03. The sweep used to notify tenants directly, which needed the owner
    connection to enumerate firms and the application connection to enqueue
    webhooks — neither of which the watch ECS task holds, and both of which
    `guard_no_watch_in_engine.sh` check 6 fails the build for granting it. So
    the notification could not run anywhere except a laptop.

    The sweep writes here with the credential it has. A worker holding the
    application role reads it and fans out. Global rather than tenant-scoped: a
    source being down is a fact about a publisher, not about a customer.
    """

    __tablename__ = "source_breaches"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    source_id: Mapped[str] = mapped_column(String)
    jurisdiction: Mapped[str] = mapped_column(String)
    #: The breach as the sweep saw it, so the notification is built from what
    #: was recorded rather than from a re-read of a row that has since moved on.
    detail: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class SourceBreachNotice(Base):
    """One tenant has been told about one breach.

    Not a column on `SourceBreach`: that table is append-only, so "has this been
    sent" cannot be a flag somebody flips. A second appended row per (breach,
    tenant) says the same thing and makes the worker idempotent by construction
    — it selects breaches with no notice, so a second run sends nothing twice.
    """

    __tablename__ = "source_breach_notices"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    breach_id: Mapped[int] = mapped_column(BigInteger)
    #: Whose record this is. Defaulted from the bound tenant like every other
    #: per-firm table, so the fan-out cannot write a row naming somebody else.
    tenant_id: Mapped[str] = mapped_column(String, default=current_tenant)
    notified_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class SourceVerification(Base):
    """A named person recording that they checked a source a machine cannot read.

    §S13 declared some publications `MANUAL` — behind a login, or a search
    portal whose front page moves without anything being published — and left
    the recording of a check unbuilt. Without it a real firm's manual sources
    drift to STALE with no way to say otherwise, which is honest and useless.

    **A table, not a column.** `watch_sources.last_checked_at` is derived state
    that every check overwrites. An attestation that somebody personally looked
    at a regulator's page is not something to overwrite: a firm asked why their
    sources were current in March needs March's attestation, not last week's.

    Append-only by trigger and revoked grant, like the rest of the evidence.
    Somebody is putting their name to a claim about what a regulator had
    published, which is the same kind of statement as a pack signature.
    """

    __tablename__ = "source_verifications"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    source_id: Mapped[str] = mapped_column(
        ForeignKey("watch_sources.id"), index=True
    )
    #: The date they say they looked, which is not always today — recording
    #: Friday's check on Monday is the normal case, and forcing it to now would
    #: make the record wrong to keep it tidy.
    verified_on: Mapped[date] = mapped_column(Date)
    #: The account, never a typed name. The point is that somebody can be asked.
    verified_by: Mapped[str] = mapped_column(String, index=True)
    note: Mapped[str] = mapped_column(Text, default="", server_default="")
    #: A ticket, a document reference, a filename. Free text: it points at
    #: somebody else's system and we should not pretend to validate it.
    attachment_ref: Mapped[str] = mapped_column(Text, default="", server_default="")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now
    )


class ArtefactJob(Base):
    """A document somebody asked for, waiting for a worker to produce it.

    §S7 moves artefact rendering to an async worker on a Postgres-backed queue —
    "no Redis/Kafka until measured need". A queue in the database it already has
    is not a compromise here: `SELECT … FOR UPDATE SKIP LOCKED` is exactly the
    claim primitive a queue needs, row-level security already stops a job being
    claimed on another tenant's behalf, and the job and the artefact it produced
    commit in the same transaction — which no external broker can offer, and
    without which "the document rendered but the queue still says pending" is a
    state somebody reconciles by hand.

    **Rendering takes hundreds of milliseconds and holds a worker.** A hundred
    documents inside requests is a hundred requests waiting, and the first thing
    to break is the determination endpoint sharing the pool. §S7's gate is that
    a hundred queued renders do not block the API; the way to pass it is not to
    make rendering faster.

    **Idempotent by construction.** A job carries the parameters it renders
    from, and asking twice for the same document returns the first job rather
    than making a second. With deterministic rendering, asking again after it
    has run produces the same bytes and the same artefact row.
    """

    __tablename__ = "artefact_jobs"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    kind: Mapped[str] = mapped_column(String, index=True)
    #: What to render from: a decision id, or a period and scope. JSONB rather
    #: than a column per kind, because the set of kinds is pack content and a
    #: column per kind would make adding a document a migration.
    params: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)
    #: A stable digest of `kind` plus `params`, so "is this already queued" is a
    #: lookup rather than a comparison of dictionaries whose key order carries
    #: no meaning.
    fingerprint: Mapped[str] = mapped_column(String, index=True)
    #: What a person would call it, for a queue screen — derived at enqueue
    #: time, because the alternative is a screen that shows a job id.
    subject: Mapped[str] = mapped_column(String, default="")

    status: Mapped[str] = mapped_column(String, default="queued", index=True)
    #: Lower is sooner, like `nice`. §S12: "bulk runs not starving interactive
    #: traffic (queue priorities)". Derived from the artefact's scope by
    #: `artefacts.queue.enqueue` rather than chosen by the caller — a priority
    #: parameter is one every caller sets to "urgent" within a year, each for a
    #: good local reason and collectively turning the column into a constant.
    priority: Mapped[int] = mapped_column(Integer, default=10, server_default="10")
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_error: Mapped[str] = mapped_column(Text, default="")

    requested_by: Mapped[str] = mapped_column(String, default="")
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: When a worker took it, and also the lease: a job left `running` by a
    #: worker that died is reclaimed once the lease expires, which is what makes
    #: a mid-run kill resumable rather than a job stuck forever.
    started_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    finished_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    artefact_id: Mapped[int | None] = mapped_column(
        ForeignKey("artefacts.id"), nullable=True
    )


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    actor: Mapped[str] = mapped_column(String)
    action: Mapped[str] = mapped_column(String)
    subject: Mapped[str] = mapped_column(String)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: The audit trail's own hash chain (migration 0026), closing T3 in the
    #: threat model. Same mechanism as `decisions`: one chain per tenant, each
    #: row committing to the one before it.
    #:
    #: Empty on rows written before the chain existed. That is an absence, not
    #: a break — `scripts/rechain.py --table audit_events` links them, and the
    #: verifier counts them separately so "we verified 40 of 1200 rows" is never
    #: reported as "we verified 1200 rows".
    prev_hash: Mapped[str] = mapped_column(Text, default="", server_default="")
    this_hash: Mapped[str] = mapped_column(Text, default="", server_default="")


class WatchSource(Base):
    """A regulatory publication being watched, for one regime.

    Sources are declared in pack content, not here — this table records what has
    been *done* about them: when each was last checked, and what was found. The
    separation matters because a source list is part of what a regime's content
    author maintains, while a check timestamp is an operational fact about this
    deployment.
    """

    __tablename__ = "watch_sources"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    jurisdiction: Mapped[str] = mapped_column(String, index=True)
    name: Mapped[str] = mapped_column(String)
    url: Mapped[str] = mapped_column(String, default="")
    #: How often this source is expected to be checked. Freshness is derived
    #: from this and `last_checked_at`, never stored — a stored status goes
    #: stale in exactly the situation it exists to warn about.
    cadence_days: Mapped[int] = mapped_column(Integer, default=7)
    #: `AUTOMATIC` or `MANUAL` (migration 0027). A publication that needs a
    #: login, or whose URL is a search form with no stable result, cannot be
    #: polled — and a screen that showed it as CURRENT would be reporting a
    #: check nobody performs.
    polling_status: Mapped[str] = mapped_column(
        Text, default="AUTOMATIC", server_default="AUTOMATIC"
    )
    #: The digest of what was last seen at this URL, for sources watched by
    #: page comparison rather than by a feed. Never the page itself: this table
    #: is monitoring state, not an archive.
    content_hash: Mapped[str] = mapped_column(Text, default="", server_default="")
    #: Which adapter last read it — `rss`, `atom`, `html`, or empty.
    fetcher: Mapped[str] = mapped_column(Text, default="", server_default="")
    last_checked_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    #: The mode the last check ran in. Recorded per source rather than read from
    #: the environment at display time, so a screen cannot claim a source was
    #: checked live because the process happens to be in live mode now.
    last_mode: Mapped[str] = mapped_column(String, default="")
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, server_default=text("true"))

    #: The specialist who gets paged when this source stops answering. Declared
    #: in pack content beside the source, because who owns a regime's monitoring
    #: is the same kind of fact as which publications that regime watches — and
    #: an alert with nobody's name on it is one everybody assumes somebody else
    #: is handling.
    owner: Mapped[str] = mapped_column(String, default="", server_default=text("''"))
    #: Consecutive failed checks. Reset by any success, so a source that flaps
    #: does not accumulate its way to an alert over a month of working fine.
    consecutive_failures: Mapped[int] = mapped_column(
        Integer, default=0, server_default=text("0")
    )
    #: How many consecutive failures before the owner is paged. §S6 says three;
    #: it is per source because a daily feed and a monthly one earn their alert
    #: at different speeds, and pack content is where that is declared.
    alert_after_failures: Mapped[int] = mapped_column(
        Integer, default=3, server_default=text("3")
    )
    #: Why the last failed check failed, in the words the person paged reads.
    last_error: Mapped[str] = mapped_column(Text, default="", server_default=text("''"))
    last_failed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    #: When the owner was last paged about this source. A delivery fact, so it is
    #: stored — unlike freshness, which is derived. Without it every sweep
    #: re-pages, and an alert that arrives every ten minutes is one that gets
    #: filtered into a folder nobody opens.
    alerted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class WatchEvent(Base):
    """Something published at a watched source.

    Deliberately *not* append-only, and deliberately not in the evidence chain.
    The hash chain covers determinations — things the firm asserted about a
    client. A watch queue is workflow: items get triaged, dismissed and
    actioned, and modelling that as immutable would mean either a second status
    table or a lie about what the chain protects. Every transition is written to
    `audit_events` instead, which is where "who did what" already lives.
    """

    __tablename__ = "watch_events"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    source_id: Mapped[str] = mapped_column(ForeignKey("watch_sources.id"), index=True)
    jurisdiction: Mapped[str] = mapped_column(String, index=True)
    #: Stable identity of the underlying publication, used to make polling
    #: idempotent. Re-running a poll must not re-raise items an officer has
    #: already dismissed, or the queue punishes them for doing their job.
    digest: Mapped[str] = mapped_column(String, unique=True, index=True)
    title: Mapped[str] = mapped_column(Text)
    summary: Mapped[str] = mapped_column(Text, default="")
    url: Mapped[str] = mapped_column(String, default="")
    published_at: Mapped[date] = mapped_column(Date)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: Which of the three triage tiers this landed in, and exactly what matched
    #: to put it there. The tier is a sort order for a human queue, never a
    #: decision — see `app/watch/triage.py`.
    tier: Mapped[str] = mapped_column(String, index=True)
    matched: Mapped[list] = mapped_column(JSONB, default=list)
    status: Mapped[str] = mapped_column(String, default="new", index=True)
    note: Mapped[str] = mapped_column(Text, default="")


class WatchAssistCall(Base):
    """One question put to a model, and what came back.

    Retained in full — §S6 asks for prompts and outputs kept for audit, and the
    reason is narrower than "logging". The claim this product makes is that no
    model decides anything. A reader is entitled to check that claim against
    what the model was actually asked and what it actually said, rather than
    against our description of it.

    Append-only for the same reason `decisions` is. A retention record that can
    be edited answers the question "what do you say it said".

    Not tenant-scoped: watch sources and events are not either. The publication
    is the same publication for every customer, and so is the reading of it.
    """

    __tablename__ = "watch_assist_calls"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    event_id: Mapped[int] = mapped_column(ForeignKey("watch_events.id"), index=True)
    #: The exact model, not a family name. "We use Claude" does not survive the
    #: question of which one, and behaviour differs between them.
    model: Mapped[str] = mapped_column(String)
    prompt: Mapped[str] = mapped_column(Text)
    output: Mapped[str] = mapped_column(Text)
    #: What the model said about its own certainty, as whole percent.
    #:
    #: An integer, not a float — invariant 3 is about money and basis points,
    #: but the habit is worth keeping where it costs nothing, and nobody is
    #: served by the difference between 71.4% and 71.40000000000001%. The exact
    #: value the model returned is in `output` verbatim, which is the copy that
    #: matters for audit; this column exists to be queried.
    confidence_pct: Mapped[int] = mapped_column(Integer)
    #: The tier the *pack vocabulary* produced, recorded beside the suggestion so
    #: the two can be compared later without re-deriving either.
    deterministic_tier: Mapped[str] = mapped_column(String)
    #: Whether this raised a hand, and the sentence saying why. A model's entire
    #: authority in this system is this boolean — see `watch/assist.py::apply`.
    escalated: Mapped[bool] = mapped_column(Boolean, default=False)
    escalation_reason: Mapped[str] = mapped_column(Text, default="")
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class PackDraft(Base):
    """A proposed change to a regime's rule content, and the signature gate.

    A draft is inert. Nothing in the evaluator can see this table, and no draft
    becomes rule content without a named person signing it — which is the whole
    point of the phase: a watch service that could edit live rules would be an
    unreviewed robot writing regulation.
    """

    __tablename__ = "pack_drafts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    #: Drafts are tenant-scoped even though packs are not. Content is the
    #: product; a proposal to change it is a piece of one customer's workflow,
    #: raised by their officer against their watch queue, and visible to them
    #: alone until a signatory publishes it into the global pack.
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    jurisdiction: Mapped[str] = mapped_column(String, index=True)
    #: The version this draft was cut from, and the version it would become.
    #: Both recorded, so a draft raised against a pack that has since been
    #: superseded can be spotted rather than silently applied to the wrong base.
    base_version: Mapped[int] = mapped_column(Integer)
    proposed_version: Mapped[int] = mapped_column(Integer)
    effective_from: Mapped[date] = mapped_column(Date)
    title: Mapped[str] = mapped_column(String, default="")
    rationale: Mapped[str] = mapped_column(Text, default="")
    #: The full proposed pack body. Stored whole rather than as a patch: a patch
    #: has to be re-applied to be read, and what a signatory signs must be the
    #: thing that becomes content, not a recipe for producing it.
    body: Mapped[dict] = mapped_column(JSONB)
    #: Which watch events argued for this change. A draft with no events behind
    #: it is legitimate — a consultant may simply author one — and prints as
    #: such rather than implying a source that does not exist.
    event_ids: Mapped[list] = mapped_column(JSONB, default=list)
    status: Mapped[str] = mapped_column(String, default="draft", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: Who wrote it, as an account and as a name — the pair `signed_by` and
    #: `signed_by_user_id` already are, and for the same reason: an id answers
    #: "who did this" only for somebody who can query the database.
    #:
    #: This table had neither until migration 0049, so §3.2's separation — the
    #: person who proposes a rule change is not the person who attests to it —
    #: could be neither enforced nor evidenced. Not null: a draft with no author
    #: is the state that migration exists to end. A draft the watch service cut
    #: records the watch service, which is exactly the case where the signature
    #: has to come from a human somewhere else.
    created_by_user_id: Mapped[str] = mapped_column(String)
    created_by: Mapped[str] = mapped_column(String, default="")
    signed_by: Mapped[str] = mapped_column(String, default="")
    #: The account that signed, as distinct from the name printed on the pack.
    #: What `publish` compares itself against to refuse a self-review.
    signed_by_user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    signed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    #: SHA-256 of the body as it stood when it was signed.
    #:
    #: A signatory attests to specific content, and "they signed version 4" is a
    #: weaker claim than "they signed these exact bytes" the moment somebody
    #: asks what changed between the signature and what went live. Captured at
    #: signing rather than computed on read, because computing it later would
    #: hash whatever is there now — which is precisely the question.
    content_hash: Mapped[str | None] = mapped_column(String, nullable=True)
    #: The qualification the signatory held at the moment they signed, copied
    #: from their `pack_signatory` grant rather than looked up at publication.
    #:
    #: What separates a review from a click by somebody holding the role. A
    #: grant can be revoked or corrected; what the published pack should record
    #: is the qualification that was claimed when the attestation was made.
    #: Beside `content_hash` because it is the same kind of fact: an
    #: attestation is a claim made at a moment, and the moment is part of it.
    #: See migration 0030 and `app/attestation.py`.
    signed_qualification_ref: Mapped[str] = mapped_column(String, default="")
    #: When it was put up for review, and by whom. Distinct from `created_at`:
    #: a draft can sit unfinished for weeks, and the clock a signatory is
    #: waiting on starts when somebody says it is ready.
    submitted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    submitted_by: Mapped[str | None] = mapped_column(String, nullable=True)
    signature_note: Mapped[str] = mapped_column(Text, default="")
    #: The independent read that lets an author sign their own content.
    #:
    #: A firm with one specialist for a regime would otherwise be unable to
    #: change its rules at all, and a rule nobody can satisfy is a rule people
    #: route around. So authorship and signature may be the same person provided
    #: somebody else — qualified for *this* regime, and neither the author nor
    #: the signer — has read the content and said so on the record.
    #:
    #: Nullable because the ordinary case needs none: a draft signed by somebody
    #: other than its author is already two people.
    #: `pack_drafts_signature_is_independent` is what makes the pairing of these
    #: fields something the database refuses rather than something Python
    #: remembers to check.
    second_reviewer_user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    #: The name beside the account, captured when the review happened. The same
    #: argument `signed_qualification_ref` makes: a name resolved at publication
    #: is whatever the directory says then, and what a published pack should
    #: record is the claim as it was made.
    second_reviewer: Mapped[str] = mapped_column(String, default="")
    second_reviewed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    #: The body's canonical hash as it stood when the review was recorded.
    #:
    #: Who and when were recorded from migration 0049; *what* was not, and both
    #: Gate A audits found the same hole through it. A reviewer approved, the
    #: author edited the body, and the author then signed their own draft —
    #: `sign` asked only whether `second_reviewer_user_id` was populated, and it
    #: still was. The signature blessed bytes nobody independent had seen and
    #: the row read as reviewed.
    #:
    #: Exactly the pattern `content_hash` above already applies to the window
    #: between the signature and publication, mirrored onto the window before
    #: it. Captured at the moment of the review, never computed on read: a hash
    #: taken later is a hash of whatever is there now, which is the question.
    second_reviewed_content_hash: Mapped[str | None] = mapped_column(
        String, nullable=True
    )
    published_by_user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    #: Its own field rather than an overloaded `signed_by`. Writing the person
    #: who declined a draft into the signature column made the row read as a
    #: signature on content nobody signed.
    rejected_by: Mapped[str] = mapped_column(String, default="")
    rejected_by_user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    rejected_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    published_pack_id: Mapped[int | None] = mapped_column(
        ForeignKey("packs.id"), nullable=True
    )


class AuthSession(Base):
    """A logged-in browser.

    Server-side on purpose. The cookie carries an opaque random id and nothing
    else — no claims, no expiry the client can read, no signature to verify. A
    self-describing token (a JWT, say) cannot be revoked without building the
    server-side list this table already is, so the list is the whole design
    rather than a fallback bolted under one.

    Only the SHA-256 of the session id is stored. A database dump, a log line
    that captured a query, or a backup on someone's laptop therefore does not
    contain anything replayable as a live session — the same reason a password
    is stored only as an Argon2id hash and never as itself.

    Deliberately not in APPEND_ONLY_TABLES: logging out must actually delete
    the row. A session that survives its own revocation is not a session.
    """

    __tablename__ = "auth_sessions"

    #: sha256 of the cookie value. The cookie value itself is never stored.
    token_hash: Mapped[str] = mapped_column(String, primary_key=True)
    #: Set instead of `user_id` when the principal is a machine — an integration
    #: holding OAuth2 client credentials rather than a person holding a password.
    #: Never both: a session naming two principals is one whose audit actor
    #: depends on which column the reader looked at first. See migration 0011.
    api_client_id: Mapped[str | None] = mapped_column(
        ForeignKey("api_clients.id"), nullable=True, index=True
    )
    #: Which customer this browser is logged in to. This is the column the whole
    #: mechanism hangs from: `app.tenant_id` is set from the session row on every
    #: request, so a session is the only thing that can name a tenant. A request
    #: cannot choose its own — there is no header, parameter or body field that
    #: reaches this value.
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), index=True)
    #: Last request seen on this session, for the idle timeout. Coarse by
    #: design — written at most once a minute, because touching a row on every
    #: request turns read-only screens into a write workload for no gain.
    last_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: Recorded for display on the sessions list, so "someone else is logged in
    #: as the demo user" is visible. Both fields are client-supplied and
    #: neither is trusted for anything but showing.
    user_agent: Mapped[str] = mapped_column(String, default="")
    created_ip: Mapped[str] = mapped_column(String, default="")
    #: Who this browser is logged in as. Nullable only so that the column could
    #: be added to a table that already had rows; every session created after
    #: Stage 2 has one, and `auth.resolve` refuses a session without one.
    user_id: Mapped[str | None] = mapped_column(
        ForeignKey("users.id"), nullable=True, index=True
    )
    #: When the credential behind this session was last presented in full.
    #: Distinct from `created_at` because a step-up re-authentication moves this
    #: forward without minting a new session — the browser stays logged in, but
    #: the clock that governs signing starts again.
    authenticated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now
    )
    #: Whether a second factor was presented on this session. Stored rather than
    #: derived from the user's enrolment, because "this person has TOTP set up"
    #: and "this browser proved it" are different claims and only the second one
    #: may open a signing screen.
    mfa_satisfied: Mapped[bool] = mapped_column(
        Boolean, default=False, server_default=text("false")
    )


#: Every role the product recognises, in order of increasing authority, and what
#: each is for. The list is closed: a role that is not here cannot be granted,
#: because `POST /admin/users/{id}/roles` checks membership before it writes.
#:
#: `pack_signatory` is the only one that carries a jurisdiction. Signing AU rule
#: content and signing EU rule content are different competencies attested by
#: different people, and a single un-scoped signatory role would let one of them
#: sign the other's regime.
ROLES = (
    "viewer",
    "operator",
    "approver",
    "pack_signatory",
    "tenant_admin",
    "quolin_support",
    # Quolin's own staff, and emphatically not the `operator` three lines above
    # — that is a compliance officer inside a customer's firm who runs checks.
    #
    # Q-12: `packs` is global, and the route that writes to it required
    # `tenant_admin`, which is a *customer's* administrator. One firm's staff
    # could put rule content in front of every other firm on the platform.
    # Drafting, editing, submitting, signing and rejecting all stay with the
    # firm, because proposing and reviewing a change is what their specialists
    # are for; only the step that writes to a table everybody reads is ours.
    "quolin_operator",
)

#: Roles for which a second factor is mandatory at sign-in, and the reasoning.
#:
#: These are the roles that can approve an override, sign rule content, or grant
#: another person a role — every one of them an act that a regulator would want
#: attributed to a specific human beyond doubt. `viewer` and `operator` are
#: deliberately absent: running a check and reading a decision are the work, and
#: putting an authenticator app in front of the work is how people share logins.
#: Roles a machine principal may hold on paper and may never exercise.
#:
#: Every one of them is half of a two-person act: approving an override, signing
#: rule content, administering the firm's people, publishing content to every
#: tenant. The whole argument for separation of duties is that two people acted,
#: and a secret in a config file is not the second one.
#:
#: `access_review.py` has listed three of these since it was written, as a
#: *report*: it names the problem quarterly and prevents none of it. The
#: middleware now drops them from a machine's held roles before the route table
#: is consulted, so the refusal covers every endpoint that needs one — including
#: the ones added next year. The report reads this same tuple, so there is one
#: list rather than two that drift.
ROLES_A_MACHINE_MAY_NOT_EXERCISE = (
    "approver",
    "pack_signatory",
    "tenant_admin",
    "quolin_operator",
)

MFA_REQUIRED_ROLES = (
    "approver",
    "pack_signatory",
    "tenant_admin",
    "quolin_support",
    "quolin_operator",
    # F8. `operator` was the omission, and it is the role that *produces* the
    # evidence: running determinations, importing a book, driving bulk sweeps,
    # generating artefacts and override reports, ingesting comparisons,
    # redelivering webhooks. Every one of those either records a determination
    # or emits something a customer relies on.
    #
    # The roles above were chosen as the ones that *authorise* — a second
    # signature, a published pack, a change to the firm. That reasoning is
    # right about authority and wrong about exposure: for an operator a phished
    # password is the whole credential, and what it buys is the ability to mint
    # evidence in a firm's own chain under a real person's name. There is no
    # second person anywhere on that path, which is precisely why it needs the
    # factor rather than why it does not.
    "operator",
)


class User(Base):
    """A person.

    Not tenant-scoped, and the exception is load-bearing rather than
    convenient: a consultant compliance officer serves several firms, and the
    execution document requires they hold different roles in each. A `tenant_id`
    on this row would force one user record per firm, which means one password
    per firm, which means the shared-credential problem Stage 2 exists to end.

    Visibility instead comes from `user_roles`: a tenant sees a person exactly
    when it has granted that person a role. See PLATFORM_TABLES.
    """

    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    #: Lowercased at write time and unique across the product.
    #:
    #: Deliberately *not* encrypted, unlike every other piece of personal data
    #: in the database. Sign-in has to find a row by email before it knows who
    #: the user is or which tenant they belong to, and an AES-GCM column cannot
    #: be searched — the ciphertext for one plaintext differs every time it is
    #: written, by design. The alternatives were a blind index (a keyed hash
    #: beside the ciphertext), which leaks equality anyway and adds a second
    #: thing to rotate, or scanning and decrypting every row on every login
    #: attempt, which is an unauthenticated denial-of-service invitation. The
    #: exposure is bounded and stated: a database dump reveals who has accounts,
    #: not what any of them did.
    email: Mapped[str] = mapped_column(String, unique=True, index=True)
    #: Shown next to decisions and on signatures. Encrypted under the platform
    #: key: unlike the email it is never queried, so there is no reason to leave
    #: a real person's name legible in a dump.
    display_name: Mapped[str] = mapped_column(
        PlatformEncryptedText("users.display_name")
    )
    #: `active`, `suspended` or `deleted`. Sign-in requires `active`; the other
    #: two exist because removing the row would orphan the audit trail that
    #: names it, and an audit trail with a dangling actor is worse than one
    #: naming someone who has left.
    status: Mapped[str] = mapped_column(String, default="active", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class UserIdentity(Base):
    """One way a user can prove who they are.

    Separate from `users` so that a person can move from the password fallback
    to their firm's identity provider without becoming a different person in the
    audit trail. Adding an OIDC identity is a row here, not a new user, so every
    decision they recorded last year still carries their name.
    """

    __tablename__ = "user_identities"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    #: `password` or `oidc`.
    provider: Mapped[str] = mapped_column(String, index=True)
    #: The issuer that vouches for `subject`. For `password` this is the empty
    #: string — the product is its own issuer. For `oidc` it is the `iss` claim,
    #: which is what makes the pair below unique across identity providers
    #: rather than only within one.
    issuer: Mapped[str] = mapped_column(String, default="")
    #: The identifier the issuer uses. For `password`, the lowercased email; for
    #: `oidc`, the `sub` claim — never the email, because an IdP may reassign an
    #: address to a new employee and `sub` is the claim that promises not to.
    subject: Mapped[str] = mapped_column(String)
    #: The Argon2id hash for `password`, empty for `oidc`. Argon2 output already
    #: carries its own salt and parameters and is not reversible, so it is not
    #: additionally encrypted — sealing a hash would protect nothing the hash
    #: does not already protect, and would make rehashing on parameter changes
    #: depend on the key being present.
    secret: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    last_used_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class UserRole(Base):
    """A grant of one role to one person within one tenant.

    Tenant-scoped, and it is the only identity table that is: the grant is the
    firm's decision about their own staff, so it belongs to them, is filtered by
    RLS like any other row of theirs, and is what makes the person visible to
    them at all.
    """

    __tablename__ = "user_roles"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    role: Mapped[str] = mapped_column(String, index=True)
    #: Set only for `pack_signatory`, empty otherwise. A signatory row names the
    #: regime the person is competent to sign for.
    jurisdiction: Mapped[str] = mapped_column(String, default="")
    #: What qualifies this person to hold the role, free text, printed on the
    #: signature. Empty for roles where the question does not arise.
    qualification_ref: Mapped[str] = mapped_column(String, default="")
    granted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: The user id of whoever granted it, or `bootstrap` for the rows the seed
    #: creates. Not a foreign key: a grant must survive the granter's deletion,
    #: and the access review report cares what the record says, not whether the
    #: person is still employed.
    granted_by: Mapped[str] = mapped_column(String, default="")
    #: When the grant lapses. Null for staff roles; always set for
    #: `quolin_support`, whose access the execution document requires to be
    #: time-boxed. Enforcement is in `app/rbac.py` rather than a delete job,
    #: because an expiry that depends on a cron having run is not an expiry.
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class TenantMember(Base):
    """This person is one of this firm's people. Not what they may do here.

    `user_roles` used to carry both facts, and revoking somebody's last grant
    therefore removed them from the firm entirely — every audit event naming
    them stopped resolving, which is precisely what FP3-13's suspension exists
    to prevent. Migration 0047 separates them.

    **Create-only, and there is no un-join.** A person who has left is a person
    with no live grants; that is what revocation and suspension already say. A
    row here says "this firm had this person", which stays true afterwards and
    is what makes an audit trail readable a year later.

    Written by `identity.ensure_member`, which `grant_role` calls itself so that
    no caller can produce a grant without the membership it implies.
    """

    __tablename__ = "tenant_members"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    joined_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: Provisioned, granted, or recovered by the backfill. Free text on purpose.
    reason: Mapped[str] = mapped_column(String, default="")


class MfaCredential(Base):
    """A second factor belonging to a person.

    Under the platform key, not a tenant key, for the same reason `users` has no
    `tenant_id`: the factor authenticates the human, and the human may serve
    several firms. Sealing it under one customer's key would make that
    customer's key a dependency of another customer's login.
    """

    __tablename__ = "mfa_credentials"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id"), index=True)
    #: `totp` today. The column exists so that adding WebAuthn later is a row
    #: kind rather than a table.
    kind: Mapped[str] = mapped_column(String, default="totp")
    label: Mapped[str] = mapped_column(String, default="")
    #: The shared secret, base32, sealed under the platform key.
    secret: Mapped[str] = mapped_column(
        PlatformEncryptedText("mfa_credentials.secret")
    )
    #: Null until the user has proved they can generate a code from it. An
    #: unconfirmed credential does not satisfy MFA — enrolment that stopped
    #: halfway must not lock someone out or, worse, wave them through.
    confirmed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    #: The highest time step already accepted. A TOTP code stays valid for its
    #: whole window, so without this a code read over someone's shoulder can be
    #: replayed within the same thirty seconds. Storing the counter makes every
    #: code single-use.
    last_used_counter: Mapped[int] = mapped_column(
        BigInteger, default=0, server_default=text("0")
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


APPEND_ONLY_GUARD = text(
    """
CREATE OR REPLACE FUNCTION quolin_append_only() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'table % is append-only', TG_TABLE_NAME;
END;
$$ LANGUAGE plpgsql;
"""
)


# --------------------------------------------------------------- Stage 4 --
#
# The tables that turn a demo into something a customer's engineer can connect
# to: who may call the API, what has already been done once, where events are
# sent, how a firm's field names map onto ours, and what every batch run did.


class ApiClient(Base):
    """A machine that may call the v1 API, and what it is allowed to do.

    Separate from `users` because it is not a person. An OAuth2
    client-credentials grant has no human behind it — nobody typed a password,
    nobody can be asked what they meant — so it gets its own table, its own
    audit actor prefix, and its own roles. Reusing `users` would have put a row
    in the staff list that no access review could sensibly ask about.

    Tenant-scoped, so a credential is a fact about one customer. A consultancy
    with three firms holds three sets of credentials, which is correct: an
    integration that could act for several customers is one whose blast radius
    is every customer it can reach.
    """

    __tablename__ = "api_clients"

    #: The public half, sent as the OAuth2 `client_id`. Random rather than
    #: derived from the tenant name: a credential that says which customer it
    #: belongs to is one that says which customers exist.
    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    #: What this integration is for, in a person's words. Printed by the access
    #: review, because "which of these four credentials is the batch job" is the
    #: first question anybody reviewing them asks.
    label: Mapped[str] = mapped_column(String)
    #: Argon2id, like a password. The secret is shown once at creation and never
    #: again — there is nothing to recover it from, deliberately.
    secret_hash: Mapped[str] = mapped_column(Text)
    #: The roles this credential acts with, from the same set people hold. A
    #: machine gets `operator` at most: approving an override and signing rule
    #: content are acts that need somebody who can be asked why.
    roles: Mapped[list[str]] = mapped_column(JSONB, default=list)
    #: `active`, `suspended` or `retired`. A credential that has acted is never
    #: deleted, for the reason `users.status` gives: the audit trail names it,
    #: and a trail with a dangling actor is worse than one naming something that
    #: has been retired. Retiring stops new tokens; the tokens already minted are
    #: killed by deleting the sessions, which is a separate act and is why the
    #: foreign key on `auth_sessions` refuses the other order.
    status: Mapped[str] = mapped_column(String, default="active", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    created_by: Mapped[str | None] = mapped_column(String, nullable=True)
    last_used_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    #: When this credential stops working. Nullable, but the API refuses to mint
    #: one without an expiry unless explicitly told to — a machine credential
    #: that never expires is one nobody ever rotates.
    expires_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class IdempotencyKey(Base):
    """One write, however many times it is sent.

    A customer's integration retries. The network drops a response, a queue
    redelivers, an engineer runs the script twice — and without this, each of
    those writes a second determination into an append-only evidence chain that
    cannot be tidied up afterwards. Duplicated evidence is not a cosmetic
    problem: it is two records of a decision that was made once.

    The stored response is returned verbatim on a repeat, rather than the
    request being re-executed. Re-executing would produce a *different*
    determination — a new id, a new hash, a new position in the chain — which is
    exactly what the caller was trying to avoid by sending a key.
    """

    __tablename__ = "idempotency_keys"

    key: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    #: The route this key was used against. A key replayed against a different
    #: endpoint is a bug in the caller, and answering it with the first
    #: endpoint's response would be a strange way to tell them.
    endpoint: Mapped[str] = mapped_column(String)
    #: SHA-256 of the canonical request body. A key reused with *different*
    #: content is the dangerous case — the caller believes they sent two things
    #: and got one — so it is refused rather than answered from the store.
    request_hash: Mapped[str] = mapped_column(String)
    status_code: Mapped[int] = mapped_column(Integer)
    response: Mapped[dict[str, Any]] = mapped_column(JSONB)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_now, index=True
    )


class WebhookEndpoint(Base):
    """Where one tenant wants to be told things, and the secret it will check.

    Per tenant and per endpoint, because "alerts land in the queue they already
    watch" means their case system, not ours — and a shared endpoint would mean
    a shared secret, which is one customer able to forge another's events.
    """

    __tablename__ = "webhook_endpoints"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    url: Mapped[str] = mapped_column(String)
    label: Mapped[str] = mapped_column(String, default="")
    #: Sealed under the tenant's data key like any other secret of theirs. It is
    #: signing material rather than a password, so it has to be recoverable —
    #: which is why this is encryption and not a hash.
    secret: Mapped[str] = mapped_column(EncryptedText("webhook_endpoints.secret"))
    #: Which event kinds to send. Empty means all of them, because a tenant that
    #: has not chosen wants to hear everything rather than nothing.
    events: Mapped[list[str]] = mapped_column(JSONB, default=list)
    status: Mapped[str] = mapped_column(String, default="active", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class WebhookDelivery(Base):
    """Every attempt to tell somebody something, and how it went.

    A log rather than a queue, and the distinction is the point: a queue is
    empty when the work is done, which means a delivery that failed, retried
    four times and eventually succeeded leaves no trace of having been late. A
    customer asking "did you tell us about decision 4,182, and when" needs the
    row to still be there.

    Deliberately *not* append-only at the database level, unlike the evidence
    tables. Attempt counts and status change as a delivery is retried, which is
    the one thing an append-only table cannot express — and a delivery log is
    operational rather than evidential. What it says about a decision is not
    what makes that decision true.
    """

    __tablename__ = "webhook_deliveries"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    endpoint_id: Mapped[str] = mapped_column(ForeignKey("webhook_endpoints.id"), index=True)
    event: Mapped[str] = mapped_column(String, index=True)
    subject: Mapped[str] = mapped_column(String)
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB)
    #: `pending`, `delivered`, or `dead`. Dead is visible on purpose: the gate
    #: for this stage is that a dead endpoint dead-letters *visibly*, because a
    #: silently dropped alert is worse than one that never existed — the
    #: customer believes they are being told.
    status: Mapped[str] = mapped_column(String, default="pending", index=True)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    last_status_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    last_error: Mapped[str] = mapped_column(Text, default="")
    next_attempt_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    delivered_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class IntegrationMapping(Base):
    """How one customer's field names become ours, and when that changed.

    Versioned, and a change is an event, because a mapping change can change
    determinations. If `risk_band` stops meaning `loss_capacity_band` and starts
    meaning something else, every subsequent decision is made on different facts
    — and the only way to explain a determination made last March is to know
    which mapping was in force when it was made.
    """

    __tablename__ = "integr_mappings"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    #: Which feed this mapping governs — `clients`, `positions`. A firm's CRM
    #: and its custodian do not agree on field names either.
    source: Mapped[str] = mapped_column(String, index=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    #: `{"their_field": {"canonical": "ours", "transform": "..."}}`.
    fields: Mapped[dict[str, Any]] = mapped_column(JSONB, default=dict)
    effective_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    created_by: Mapped[str | None] = mapped_column(String, nullable=True)
    note: Mapped[str] = mapped_column(Text, default="")


class ImportRun(Base):
    """One batch or upload, what it contained, and what it did.

    Per-tenant history, which is the difference between an importer and a
    gateway: a firm dropping a file nightly needs to answer "what did you load
    on the 14th" a year later, and a report that only existed in an HTTP
    response cannot.

    The row-level errors are stored rather than only returned, because the gate
    for this stage is that a malformed file produces row-level errors and not a
    failed run — and a run that produced errors nobody can retrieve afterwards
    has failed in the way that matters.
    """

    __tablename__ = "import_runs"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    #: `api`, `batch` or `console` — how the file arrived. A drop that was meant
    #: to be nightly and has been arriving by hand is a fact worth being able to
    #: see.
    channel: Mapped[str] = mapped_column(String, index=True)
    source: Mapped[str] = mapped_column(String, default="clients")
    filename: Mapped[str] = mapped_column(String, default="")
    #: SHA-256 of the bytes received. The same file dropped twice is the most
    #: common batch accident there is, and this is what makes it detectable.
    content_hash: Mapped[str] = mapped_column(String, index=True)
    status: Mapped[str] = mapped_column(String, default="pending", index=True)
    rows_total: Mapped[int] = mapped_column(Integer, default=0)
    rows_written: Mapped[int] = mapped_column(Integer, default=0)
    errors: Mapped[list[Any]] = mapped_column(JSONB, default=list)
    mapping_version: Mapped[int | None] = mapped_column(Integer, nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    finished_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    started_by: Mapped[str | None] = mapped_column(String, nullable=True)


class PackDraftTransition(Base):
    """One move of one draft from one state to another, and who moved it.

    The execution document asks for lifecycle states as first-class *with
    transitions logged: who moved it, when, from what to what*. A `status`
    column answers only the first of those — it says where a draft is now and
    destroys the record of how it got there every time it changes.

    That record is the thing an auditor asks for. "This pack became effective on
    the fourteenth" is a fact; "it was drafted by an operator on the second, put
    up for review on the ninth, signed by a named signatory on the eleventh and
    put in force by an administrator on the twelfth" is the answer to the
    question behind it. Rule content that appeared with no trail is rule content
    nobody can account for.

    Append-only at the database level, like the evidence tables. A transition
    log that could be edited would be a story rather than a record.
    """

    __tablename__ = "pack_draft_transitions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    draft_id: Mapped[int] = mapped_column(ForeignKey("pack_drafts.id"), index=True)
    #: Null on the first row, which records the draft coming into existence.
    #: Nullable rather than a sentinel string: "from nothing" is genuinely a
    #: different fact from "from draft", and a sentinel would sort among the
    #: real states in every query that groups by it.
    from_status: Mapped[str | None] = mapped_column(String, nullable=True)
    to_status: Mapped[str] = mapped_column(String, index=True)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, index=True)
    #: Who moved it. Defaults from the ambient scope for the same reason
    #: `audit_events.actor` does: a call site that had to remember to pass the
    #: person is a call site that records an unattributed move.
    by_actor: Mapped[str | None] = mapped_column(
        String, nullable=True, default=current_user_or_none
    )
    #: Why, where a reason exists. A rejection's note is the most valuable text
    #: in this table — it is the record that somebody looked and said no.
    note: Mapped[str] = mapped_column(Text, default="")


class TenantAdvance(Base):
    """One tenant meeting one new pack version, and what happened next.

    The answer to "how do you control vendor changes?", which is the first
    question a bank's diligence team asks about a rules vendor. A tenant either
    advances automatically when a version becomes effective, or is pinned and
    gets a window to check the change against their own book before it applies.

    Recorded per tenant per version rather than derived, because "we advanced on
    the fourteenth" and "we were never told" are the two answers a customer might
    give, and only one of them can be true. Every advance is a row.
    """

    __tablename__ = "tenant_advances"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    jurisdiction: Mapped[str] = mapped_column(String, index=True)
    pack_version: Mapped[int] = mapped_column(Integer)
    #: `pending` while a pinned tenant's window is open, `advanced` once they are
    #: on it, `declined` if they refused and escalated. A tenant on `auto` goes
    #: straight to `advanced` and the row is the record that they did.
    status: Mapped[str] = mapped_column(String, default="pending", index=True)
    #: Which policy was in force when this version arrived. Recorded rather than
    #: read from the tenant now: a firm that switched from pinned to auto last
    #: month did not thereby change what happened in March.
    policy: Mapped[str] = mapped_column(String)
    #: When a pinned tenant's window closes. Null for an auto tenant, which has
    #: no window.
    window_closes_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    noticed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    advanced_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    advanced_by: Mapped[str | None] = mapped_column(String, nullable=True)
    note: Mapped[str] = mapped_column(Text, default="")


class WorkerHeartbeat(Base):
    """The last time a scheduled job ran, and what it saw when it did.

    A monitor that is quiet because nothing is wrong and a monitor that is quiet
    because it died look identical from the outside. That was true of
    `scripts/health_alerts.py` — the §S9 paging path — for as long as it has
    existed, and it is the second half of the defect migration 0029 fixes: on a
    database where tenant enumeration returned nothing, the job would have
    reported all-clear forever and nothing could have noticed.

    One row per worker, overwritten on each run, because the question this
    answers is "when did it last run and what did it find", not "what has it
    ever done" — the audit trail is where history belongs, and a heartbeat table
    that grows without bound is a table somebody eventually truncates.

    Not tenant-scoped. It is a fact about a process on the platform, and the
    worker writing it is deliberately between tenants at that moment.
    """

    __tablename__ = "worker_heartbeats"

    worker: Mapped[str] = mapped_column(String(64), primary_key=True)
    ran_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: How many firms the run enumerated. Zero is the fault condition migration
    #: 0029 exists to make visible, and it is recorded rather than inferred so
    #: that a run which found nothing says so in a row somebody can query.
    tenants_seen: Mapped[int] = mapped_column(Integer, default=0)
    #: `ok`, `findings`, or `fault`. What the run concluded, in one word.
    outcome: Mapped[str] = mapped_column(String(32), default="ok")
    detail: Mapped[str] = mapped_column(Text, default="")


class PackPublication(Base):
    """Who put this piece of rule content in front of every customer.

    Q-12. `packs` is global by design and the design is right — every customer
    under a licence should see the same AU rules. But `pack_draft_transitions`,
    the record of who moved that content through review, is tenant-scoped, also
    correctly, because one firm's workflow is not another's. The two together
    left a firm inheriting rules with no way to see who wrote them, who signed
    them, or whether they had been reviewed at all.

    This is the narrow bridge. It carries what a firm being governed by the
    content is entitled to know — the regime and version, the firm the draft
    came from, the named signatory, the two distinct accounts that signed and
    published it, and the content hash — and nothing about the drafting workflow
    that produced it. Global, so every tenant reads it; append-only, because a
    record of a change to rules other people are bound by is evidence and an
    editable one is a story.

    Keyed by `pack_id`: there is exactly one publication per pack row, and a key
    of its own would allow two.
    """

    __tablename__ = "pack_publications"

    pack_id: Mapped[int] = mapped_column(ForeignKey("packs.id"), primary_key=True)
    jurisdiction: Mapped[str] = mapped_column(String, index=True)
    version: Mapped[int] = mapped_column(Integer)
    effective_from: Mapped[date] = mapped_column(Date)
    #: The firm whose staff drafted, reviewed and signed this. Not a tenant
    #: scope — every tenant reads every row — but the answer to "whose
    #: specialists proposed the rules I am being governed by".
    origin_tenant: Mapped[str] = mapped_column(String)
    #: Who wrote it, as a name — and, since migration 0049, the account beside
    #: it. This carried the creation transition's `by_actor` until then, which
    #: is an account id in a column every reader takes for a name.
    drafted_by: Mapped[str] = mapped_column(String, default="")
    drafted_by_user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    #: The independent read, where the signature needed one. Null on the
    #: ordinary publication, where the signer was not the author and there was
    #: nothing for a third person to make independent.
    second_reviewer_user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    drafted_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    signed_by: Mapped[str] = mapped_column(String, default="")
    signed_by_user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    signed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    published_by_user_id: Mapped[str | None] = mapped_column(String, nullable=True)
    published_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    content_hash: Mapped[str] = mapped_column(String(64), default="")
    #: The hash of the bytes the signatory actually signed, as against
    #: `content_hash` above, which describes the bytes that went live.
    #:
    #: F4: `publish` computed its own hash over a body it had just mutated and
    #: never compared it to the one `sign` recorded, so an edit between
    #: signature and publication put unsigned bytes into `packs` under a named
    #: specialist's signature. The comparison is in `drafts.publish`; this is
    #: where its result is kept, in an append-only table, so the attestation can
    #: still be checked long after the mutable draft row has moved on.
    #:
    #: Nullable because every publication made before migration 0035 has no
    #: honest value — nobody recorded one — and inventing one would mean writing
    #: to rows this table's trigger exists to protect.
    signed_content_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)


class ChainRechain(Base):
    """One rewrite of a firm's evidence hashes, and the reason somebody gave.

    `scripts/rechain.py` is the only thing in this system that rewrites hashes
    on rows already written, and its own module note says it looks exactly like
    a tamper. The only difference is that somebody meant it — and that
    difference was not written down anywhere.

    The tool wrote a single audit event afterwards naming the *new* tip. An
    auditor holding an export from before the rechain and one from after then
    has every hash different and nothing to reconcile them against, which is the
    position the tool's own docstring says it puts them in.

    `tip_before` is the field that was missing and the one that matters most: it
    is what lets somebody take an old export and say "yes, this is where that
    chain ended, and this row is why the numbers changed".
    """

    __tablename__ = "chain_rechains"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey(_TENANT_FK), index=True, default=current_tenant
    )
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    #: `decisions` or `audit_events`. The tool rebuilds either.
    table_name: Mapped[str] = mapped_column(String(32))
    #: A person, named by whoever ran it. "The system did it" is not an answer
    #: to "who rewrote this".
    by_operator: Mapped[str] = mapped_column(String)
    reason: Mapped[str] = mapped_column(Text)
    tip_before: Mapped[str] = mapped_column(String(64), default="")
    tip_after: Mapped[str] = mapped_column(String(64), default="")
    rows_changed: Mapped[int] = mapped_column(Integer, default=0)
