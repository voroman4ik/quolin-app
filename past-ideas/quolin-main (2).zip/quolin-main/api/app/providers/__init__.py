"""The hybrid boundary.

Everything mocked in the prototype sits behind one of these protocols. Post-raise
integration replaces implementations, not call sites.
"""

from __future__ import annotations

from datetime import date
from typing import Protocol


class ClientProvider(Protocol):
    def get(self, client_id: str) -> dict: ...

    def list(self, scenario: str | None = None) -> list[dict]: ...


class PositionsProvider(Protocol):
    def get(self, client_id: str, as_of: date) -> dict: ...


class QueueSink(Protocol):
    def notify(self, kind: str, subject: str, detail: dict) -> None: ...


from .fixtures import (  # noqa: E402
    AuditQueueSink,
    DbClientProvider,
    FixturePositionsProvider,
)

__all__ = [
    "ClientProvider",
    "PositionsProvider",
    "QueueSink",
    "DbClientProvider",
    "FixturePositionsProvider",
    "AuditQueueSink",
]
