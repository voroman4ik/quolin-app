"""Fixture-backed implementations of the mocked edges."""

from __future__ import annotations

import json
from datetime import date
from functools import lru_cache
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..engine.snapshot import NONE_ON_FILE
from ..models import Client

FIXTURES = Path(__file__).resolve().parents[3] / "fixtures"


@lru_cache(maxsize=1)
def _positions_fixture() -> dict:
    return json.loads((FIXTURES / "positions.json").read_text())


def _client_to_dict(row: Client) -> dict:
    return {
        "id": row.id,
        "name": row.name,
        "scenario": row.scenario,
        "jurisdiction": row.jurisdiction,
        "residency": row.residency,
        "domicile": row.domicile,
        "dob": row.dob,
        "client_category": row.client_category,
        "knowledge_assessed": row.knowledge_assessed,
        "knowledge_date": row.knowledge_date,
        "loss_capacity_band": row.loss_capacity_band,
        "vulnerability_flag": row.vulnerability_flag,
        "assessable_portfolio_cents": row.assessable_portfolio_cents,
        "prior_crypto_purchases": row.prior_crypto_purchases,
        "structural_acks": row.structural_acks or [],
        "default_trade_amount_cents": row.default_trade_amount_cents,
        "note": row.note,
    }


class DbClientProvider:
    """Stands in for the institution's CRM."""

    def __init__(self, session: Session):
        self.session = session

    def get(self, client_id: str) -> dict:
        row = self.session.get(Client, client_id)
        if row is None:
            raise KeyError(f"unknown client {client_id!r}")
        return _client_to_dict(row)

    def list(self, scenario: str | None = None) -> list[dict]:
        stmt = select(Client)
        if scenario:
            stmt = stmt.where(Client.scenario == scenario)
        # Sorted here rather than by Postgres, because `name` is ciphertext in
        # the database and ordering ciphertext orders nothing. That is the cost
        # of column-level encryption and it is the point of it: a column the
        # database can sort is a column the database can read.
        rows = [_client_to_dict(r) for r in self.session.scalars(stmt)]
        return sorted(rows, key=lambda r: r["name"])

    def cast_ids(self) -> set[str]:
        """The ids of the hand-written demo book.

        A separate query rather than a key on the dict `get` and `list` return,
        because that dict is the frozen snapshot every decision is recorded
        against: adding a key would change what replay reads back for decisions
        already on file (invariants 2 and 5). Cast membership has nothing to do
        with a determination in any case — it is a question only screens ask.
        """
        return set(self.session.scalars(select(Client.id).where(Client.is_cast)))


class FixturePositionsProvider:
    """Stands in for custody. Static positions, keyed by client."""

    #: What this provider is. Recorded in every snapshot it feeds, because
    #: "10% concentration, from custody" and "10% concentration, because nobody
    #: has told us otherwise" are different findings and a replay has to
    #: reproduce which one it was.
    SOURCE = "fixture"

    def get(self, client_id: str, as_of: date | None = None) -> dict:
        positions = _positions_fixture()
        entry = positions.get(client_id)
        if entry is None:
            # `none_on_file` rather than `fixture`, and the distinction is the
            # one `has_record` exists for: a client custody has never heard of is
            # assessed as holding nothing, and the snapshot must say that the
            # zero was an absence rather than a reading.
            return {
                "crypto_value_cents": 0,
                "holdings": [],
                # The engine recognises this exact string and withholds the
                # concentration calcs on it, so it is imported rather than
                # retyped — see `engine/snapshot.NONE_ON_FILE` and Q-06.
                "source": NONE_ON_FILE,
                "as_at": as_of.isoformat() if as_of else "",
            }
        return {
            "crypto_value_cents": int(entry["crypto_value_cents"]),
            "holdings": entry.get("holdings", []),
            "source": self.SOURCE,
            # The date the holdings are asserted as at, which is not the same as
            # the date the determination is made for — a custodian's overnight
            # file is yesterday's positions. Recorded so a reader can tell.
            "as_at": as_of.isoformat() if as_of else "",
        }

    def has_record(self, client_id: str) -> bool:
        """Whether custody holds anything at all for this client.

        `get` cannot answer this. It returns zero holdings both for a client who
        genuinely holds no crypto and for a client custody has never heard of,
        and those are different facts: the first makes a concentration figure of
        0% true, the second makes it fabricated. Imported clients are always the
        second kind, because a client CSV carries no positions.

        Deliberately not folded into `get`. `get` feeds the frozen snapshot, and
        changing that shape would change what replay reads back for every
        decision already recorded (invariants 2 and 5). This is a separate
        question asked by screens and importers, never by the engine.
        """
        return client_id in _positions_fixture()

    def covered_ids(self) -> set[str]:
        return set(_positions_fixture())


class AuditQueueSink:
    """Stands in for the institution's compliance queue webhook."""

    def __init__(self, session: Session):
        self.session = session

    def notify(self, kind: str, subject: str, detail: dict) -> None:
        # Routed through `service.audit` rather than writing the row here, so
        # that a queue notification is attributed by exactly the same rule as
        # everything else — and cannot become the one path that still writes a
        # placeholder name after the rest stopped.
        from ..service import audit

        audit(self.session, f"queue.{kind}", subject)
