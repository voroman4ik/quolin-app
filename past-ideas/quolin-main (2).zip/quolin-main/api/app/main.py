from __future__ import annotations

import csv
import io
import logging
import os
import time
from collections import Counter
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta, timezone
from typing import Any, cast
from urllib.parse import urlparse

import anyio.to_thread
from fastapi import Cookie, Depends, FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse, Response
from sqlalchemy import Table, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from starlette.routing import Match

from . import (
    adoption,
    advance,
    artefacts,
    auth,
    bulk,
    business_time,
    client_address,
    comparison,
    crypto,
    db,
    evidence,
    identity,
    importer,
    integrations,
    invitations,
    mfa,
    observability,
    oidc,
    pack_notices,
    packs_repo,
    rbac,
    reports,
    service,
    source_alerts,
    tenancy,
    v1,
    watch,
    webhooks,
)
from .db import SessionLocal, engine, get_session
from .engine import Pack as EnginePack
from .engine import crossborder
from .engine import validate as engine_validate
from .engine.dsl import PackError
from .models import (
    ROLES_A_MACHINE_MAY_NOT_EXERCISE,
    ApiClient,
    Artefact,
    ArtefactJob,
    Asset,
    AuthSession,
    Client,
    Decision,
    EvalRun,
    MfaCredential,
    Override,
    Pack,
    PackDraft,
    Tenant,
    TenantMember,
    User,
    UserRole,
    WatchEvent,
    WatchSource,
    WebhookDelivery,
)
from .providers import DbClientProvider, FixturePositionsProvider
from .schemas import (
    AdvanceDecision,
    AdvancePolicyRequest,
    ArtefactBatchRequest,
    ArtefactRequest,
    ClientImportRequest,
    ComparisonIngest,
    DraftEdit,
    DraftRequest,
    EvaluateRequest,
    GrantRoleRequest,
    LoginRequest,
    NewUserRequest,
    OverrideRequest,
    PeriodReportRequest,
    PublicationApprovalRequest,
    PublishRequest,
    ReauthRequest,
    ResetRequest,
    RevokeRequest,
    RunRequest,
    SecondFactorRequest,
    SecondReviewRequest,
    SetPasswordRequest,
    SignRequest,
    SourceVerificationRequest,
    StageRequest,
    SuspendUserRequest,
    TriageRequest,
)


@asynccontextmanager
async def lifespan(_: FastAPI):
    # The master key, checked at boot rather than on the first request. Without
    # it every client name and every snapshot is unreadable, so an API that
    # started anyway would serve errors on the first screen — or, far worse in
    # some future refactor, write plaintext. Neither is a state to discover in
    # front of somebody.
    crypto.master_key()

    # How many requests this process will work on at once, set to the same
    # number the connection pool is sized for. §S12: a request admitted to a
    # thread it cannot get a connection for has not been admitted, it has been
    # queued somewhere with a worse error message — thirty seconds later, as
    # `QueuePool limit of size 5 overflow 10 reached`.
    #
    # Starlette runs sync endpoints on anyio's default thread limiter, which
    # holds forty tokens and knows nothing about Postgres. This is the one place
    # the two can be told about each other.
    anyio.to_thread.current_default_thread_limiter().total_tokens = (
        db.MAX_CONCURRENT_REQUESTS
    )

    # Every route names the roles that may call it, checked here rather than on
    # the request that finds the gap. Routes are registered by the decorators
    # below, so this cannot run at import of the module that declares them; boot
    # is the first moment the table is complete. See app/rbac.py.
    rbac.check_every_route_is_classified(_declared_routes(), PUBLIC_PATHS)

    # Session storage is operational infrastructure, not demo content, so it
    # creates itself rather than waiting for a reseed. Deploying authentication
    # must not require dropping the evidence tables — on a hosted instance that
    # would mean destroying the hash chain to install a login screen.
    cast(Table, AuthSession.__table__).create(bind=engine, checkfirst=True)

    # WeasyPrint spends several seconds initialising fontconfig on first use.
    # Pay it at boot so the first Generate tap in a demo is fast.
    try:
        from weasyprint import HTML

        HTML(string="<p>warm</p>").write_pdf()
    except Exception as exc:  # a cold renderer must not stop the API booting
        print(f"renderer warm-up skipped: {exc}")
    yield


app = FastAPI(title="Quolin API", version="1.0.0", lifespan=lifespan)


# --------------------------------------------------------------------- CORS --
#
# Was `allow_origins=["*"]`, which is incompatible with what this phase adds:
# a browser refuses to send credentials to a wildcard origin, so the cookie
# would never arrive. The list is therefore explicit, and comes from the
# environment because the hostnames differ per deployment.
#
# The wildcard also had to go on its own merits. It let any page on the
# internet call this API from a visitor's browser; that was survivable only
# while there was nothing to authorise against.
def _allowed_origins() -> list[str]:
    raw = os.getenv("QUOLIN_ALLOWED_ORIGINS", "")
    if raw.strip():
        return [o.strip().rstrip("/") for o in raw.split(",") if o.strip()]
    # Local development default. Never includes a wildcard: an unset variable
    # in production must fail closed and visibly, not open and quietly.
    return [
        "http://localhost:3000",
        "http://localhost:3100",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3100",
    ]


# --------------------------------------------------------------------- auth --
#
# Default-deny. Every path is authenticated unless it appears below, which is
# the opposite of decorating each route with a dependency: forgetting to add a
# decorator opens a hole silently, whereas forgetting to add an exemption
# breaks the endpoint loudly the first time anyone calls it.
#
# `test_auth.py` asserts this list against the live route table, so a new
# endpoint cannot quietly join the public set.
# The docs routes are deliberately NOT here. FastAPI serves /docs, /redoc and
# /openapi.json publicly by default, which on a hosted deployment hands the
# entire API surface — every path, parameter and schema — to anyone with the
# URL and no account. It leaks no client data, but it is free reconnaissance
# for a demo whose whole claim is that it is private, and Swagger still works
# for anyone who has actually logged in.
PUBLIC_PATHS = frozenset(
    {
        "/health",       # the deployment's own liveness probe, before any login
        # The status page, which is public by definition — its whole purpose is
        # to be readable by somebody who cannot sign in, including because we
        # are the reason they cannot. It reports no per-customer state.
        "/status",
        "/auth/login",
        "/auth/logout",  # idempotent, and must work with a dead session
        "/auth/session", # answers "am I logged in?" — 200 either way
        # The two halves of a federated sign-in. Public for the same reason
        # `/auth/login` is: they are how a session comes to exist. The callback
        # is not "unauthenticated" in any meaningful sense — it refuses anything
        # without a signed state cookie and a verified identity token, which is
        # a harder credential than a password.
        "/auth/oidc/start",
        "/auth/oidc/callback",
        # The one unauthenticated route in /v1, and public for the same reason
        # `/auth/login` is: it is how a session comes to exist. It is rate
        # limited, it refuses every failure identically, and the tenant comes
        # from the credential rather than from anything the caller sends.
        "/v1/oauth/token",
        # FP3-11. How somebody who has never signed in comes to hold a
        # credential, and how somebody who has forgotten one gets another.
        # Public for the same reason `/auth/login` is, and defended the same
        # way: both are rate limited by address, both refuse every failure with
        # one message, and neither says whether an address names an account.
        "/auth/set-password",
        "/auth/reset",
    }
)


def _matched_route(request: Request) -> tuple[str, str] | None:
    """The (method, path template) this request will be routed to.

    Middleware runs before routing, so the template is not in the scope yet and
    has to be found by asking the router the same question it will ask itself.
    The template and not the URL: `/clients/margaret-wu` and `/clients/tom-askew`
    are one endpoint with one policy, and a table keyed by concrete paths would
    be a table with a hole in it for every client not yet created.
    """
    for route in app.router.routes:
        match, _ = route.matches(request.scope)
        if match == Match.FULL:
            return (request.method, getattr(route, "path", ""))
    return None


def _declared_routes() -> list[tuple[str, str]]:
    """Every (method, path template) the application serves, less the free ones.

    HEAD and OPTIONS are dropped: Starlette adds HEAD alongside every GET and
    answers OPTIONS itself, so neither is an endpoint anybody wrote or should
    have to classify.
    """
    out = []
    for route in app.router.routes:
        path = getattr(route, "path", "")
        for method in getattr(route, "methods", set()) or set():
            if method not in {"HEAD", "OPTIONS"}:
                out.append((method, path))
    return sorted(set(out))


@app.middleware("http")
async def one_line_per_request(request: Request, call_next):
    """A request id, and one structured line saying what happened.

    §S9's structured logging, at the only place that sees every request. The id
    is on the response too, so a customer reporting "it failed at half past
    three" can hand over a string that finds the line rather than a time and a
    guess.

    Registered *last* and therefore run first — Starlette inserts each new
    middleware at the front — so a request refused by the session guard below is
    still logged. A log that only records the requests that succeeded is a log
    that goes quiet exactly when something is wrong.
    """
    request_id = observability.new_request_id()
    started = time.monotonic()
    try:
        response = await call_next(request)
    except Exception:
        logging.getLogger("quolin.request").exception(
            "request failed",
            extra={
                "method": request.method,
                "path": request.url.path,
                "elapsed_ms": int((time.monotonic() - started) * 1000),
                "request_id": request_id,
            },
        )
        raise

    logging.getLogger("quolin.request").info(
        "request",
        extra={
            "method": request.method,
            "path": request.url.path,
            "status": response.status_code,
            "elapsed_ms": int((time.monotonic() - started) * 1000),
            "request_id": request_id,
        },
    )
    response.headers["X-Quolin-Request-Id"] = request_id
    return response


#: Methods that change nothing, and are therefore not what cross-site request
#: forgery is about. A cross-site GET is what CORS exists for: the request is
#: made, and the browser withholds the *response*. An unsafe method has already
#: had its effect by the time the browser decides whether to show the answer.
SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS", "TRACE"})


def _own_origin(request: Request) -> str:
    """The origin this API is being served on, as the caller reached it.

    Accepted alongside the configured list so that a same-origin request is
    always allowed, and so that the tools which talk to a deployment over HTTP —
    `scripts/smoke.py`, `scripts/load_test.py` — can identify themselves with
    the base URL they were pointed at rather than needing to know what the web
    client's hostname happens to be.
    """
    return f"{request.url.scheme}://{request.url.netloc}"


def _refuse_cross_site(request: Request) -> JSONResponse | None:
    """Refuse an unsafe method that did not come from somewhere we know.

    Q-05. The hosted deployment issues the session cookie `SameSite=None`,
    because the web client and the API are on different sites — which is exactly
    the configuration where a browser attaches credentials to a request that
    some other page caused. There was no second check of any kind, and a
    cross-site POST to `/auth/revoke-all` terminated 24 sessions.

    Here rather than on the routes. A per-route decorator is a thing somebody
    forgets to add and the failure mode of forgetting is silence; this covers
    every unsafe method on every path, including the ones added next year.

    **Not CORS.** `Access-Control-Allow-Origin` governs whether a response may
    be *read*. A POST that revokes sessions has revoked them before the browser
    decides it may not look at the answer.

    **`Origin` first, `Referer` only if there is none.** A `Referer` is trimmed
    or stripped by proxies and privacy settings, so it cannot be the primary
    check; but a request carrying one and no `Origin` has still said where it
    came from.

    **Neither header is a refusal, not a pass.** Every current browser sends
    `Origin` on an unsafe method, so a cookie-carrying POST with neither is not
    a browser doing something ordinary — and admitting it would leave this one
    omitted header away from being optional.

    **A request with no session cookie is exempt.** Cross-site request forgery
    works because a browser attaches an *ambient* credential by itself. A
    request carrying no session cookie has none to attach, so there is nothing
    to forge and nothing this check can protect.

    F2: that exemption was first written as `has_bearer and not has_cookie`,
    which is the same statement for every request except the one that matters.
    `POST /v1/oauth/token` carries no bearer — it is how a bearer comes to
    exist — and a server-to-server client sends no `Origin`, because it is not a
    browser and has no page to name. So every integration was refused 403 before
    its credential was read: Q-17's failure reintroduced one tier up, in the
    same fix pack. Neither the OpenAPI document nor the Postman collection ever
    mentioned an `Origin` requirement, so nobody building against this would
    have sent one.

    The cookie is the whole question, so the cookie is what is asked about.
    """
    if request.method.upper() in SAFE_METHODS:
        return None

    # The session cookie is the only credential a browser attaches on its own,
    # so it is the only one that can be used against its holder. No cookie, no
    # ambient authority, nothing to refuse — whether or not the caller offered a
    # bearer token, and whether or not it named an origin.
    if auth.COOKIE_NAME not in request.cookies:
        return None

    accepted = set(_allowed_origins()) | {_own_origin(request)}

    origin = (request.headers.get("origin") or "").strip().rstrip("/")
    if not origin:
        referer = (request.headers.get("referer") or "").strip()
        if referer:
            parsed = urlparse(referer)
            if parsed.scheme and parsed.netloc:
                origin = f"{parsed.scheme}://{parsed.netloc}"

    if origin and origin in accepted:
        return None

    return JSONResponse(
        status_code=403,
        content={
            "detail": (
                "This request did not come from an allowed origin, so it was "
                "refused before anything happened. A state-changing request must "
                "say where it came from — send `Origin`, or authenticate with a "
                "bearer token if you are not a browser."
            )
        },
    )


@app.middleware("http")
async def require_session(request: Request, call_next):
    # A preflight carries no cookie by design; rejecting it would fail the
    # request the browser makes *before* the one that does carry credentials.
    if request.method == "OPTIONS":
        return await call_next(request)

    # Before the public-path exemption, deliberately. `/auth/logout` is public
    # because it must work with a dead session, and it is still an action a
    # foreign page should not be able to cause; `/auth/login` is public because
    # it is how a session comes to exist, and a cross-site one would sign a
    # visitor into somebody else's account. Being reachable without a session is
    # not the same as being reachable from anywhere.
    refused = _refuse_cross_site(request)
    if refused is not None:
        return refused

    if request.url.path in PUBLIC_PATHS:
        return await call_next(request)

    # Two ways to present the same kind of session. A browser sends a cookie
    # because it is a browser and needs HttpOnly; an integration sends a bearer
    # token because it is not one, has no cross-site concerns, and would
    # otherwise have to fake a cookie jar. Both resolve to the same
    # `auth_sessions` row — one token format, one revocation path, and no second
    # way in that `revoke-all` would miss.
    token = request.cookies.get(auth.COOKIE_NAME)
    bearer = request.headers.get("authorization", "")
    if not token and bearer.lower().startswith("bearer "):
        token = bearer.split(" ", 1)[1].strip()

    db = SessionLocal()
    try:
        session_row = auth.resolve(db, token)
        # Read before the session closes. Closing rolls back, which expires
        # every loaded attribute, and reading one afterwards raises.
        tenant_id = session_row.tenant_id if session_row is not None else None
        user_id = session_row.user_id if session_row is not None else None
        api_client_id = session_row.api_client_id if session_row is not None else None
        mfa_satisfied = bool(session_row.mfa_satisfied) if session_row is not None else False
    finally:
        db.close()

    # The principal, whichever kind it is. A machine is an actor exactly as a
    # person is: it holds roles, it appears in the audit trail as itself, and the
    # quarterly access review asks about it. What it is not is a `users` row.
    principal = user_id or api_client_id

    # Stashed so a handler can ask what *kind* of principal is calling without a
    # second round trip to resolve the token again — and without having to know
    # whether it arrived as a cookie or a bearer header, which is exactly the
    # detail a handler should not be reasoning about.
    request.state.api_client_id = api_client_id

    # No session, or a session with no person behind it — the second being a row
    # written before Stage 2. Both are refused, and the second is refused rather
    # than honoured because an action nobody can be named for is exactly what
    # the identity work exists to make impossible; a grandfathered cookie would
    # be the one way left to perform one.
    if tenant_id is None or principal is None:
        # 401 rather than 403: the client should offer a login, not report a
        # permissions problem it cannot act on. The challenge names whichever
        # scheme the caller was reaching for, so an integration is told to send a
        # token rather than told to find a cookie jar.
        return JSONResponse(
            status_code=401,
            content={"detail": "Not signed in."},
            headers={"WWW-Authenticate": "Bearer" if bearer else "Cookie"},
        )

    # The session row is the only thing that names a tenant or a person. There
    # is no header, query parameter or body field that reaches either value,
    # which is what makes "read another customer's data" not a request anyone
    # can construct — the closest they can get is presenting somebody else's
    # cookie, which is the same problem as impersonation and has the same answer.
    #
    # The person is scoped here and not only where it is needed, because the
    # policies on the identity tables read `app.user_id` and the audit trail
    # reads the same value. A handler that had to remember to set it is a
    # handler that writes an unattributed row the day somebody forgets.
    # A privileged role with no verified second factor is confined to getting
    # one. Checked here rather than per route, because the set of things such a
    # session must not reach is "everything", and an allow-list of four paths is
    # the only shape of that rule which cannot be got wrong by adding a route.
    #
    # `MFA_REQUIRED_ROLES` has named these roles since Stage 2 and nothing
    # enforced it until Stage 13's external review; `app/mfa.py` carries the
    # reasoning.
    if user_id is not None and request.url.path not in mfa.UNLOCKED_PATHS:
        with tenancy.acting_as(tenant_id), tenancy.acting_as_user(principal):
            gate = SessionLocal()
            try:
                confined = mfa.locked_out(
                    gate,
                    user_id=user_id,
                    mfa_satisfied=mfa_satisfied,
                )
            finally:
                gate.close()
        if confined:
            return JSONResponse(status_code=403, content={"detail": mfa.MESSAGE})

    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(principal):
        # Opened inside the scope, not before it. `app.tenant_id` is bound on
        # the engine's begin event, so a session created outside would run its
        # whole transaction against an empty tenant and read no grants at all —
        # which would look exactly like a person who holds none.
        db = SessionLocal()
        try:
            if user_id is not None:
                held = frozenset(grant.role for grant in identity.roles_for(db, user_id))
            else:
                # A machine's roles are on its own row rather than in
                # `user_roles`, because a credential is not a person and a grant
                # is the firm's decision about a member of staff. Same set of
                # role names, same route table, different table.
                machine = db.get(ApiClient, principal)
                granted = frozenset(machine.roles or []) if machine is not None else frozenset()
                # Minus the ones that are half of a two-person act. Approving an
                # override, signing rule content, administering a firm's people,
                # publishing content to every tenant — the whole argument for
                # separation of duties is that two people acted, and a secret in
                # a config file is not the second one.
                #
                # Dropped here rather than refused per route, because the set of
                # endpoints this must not reach is "every one that needs such a
                # role", including the ones added next year.
                # `access_review.py` has named three of these as a quarterly
                # *report* since it was written; a report prevents nothing.
                held = granted - frozenset(ROLES_A_MACHINE_MAY_NOT_EXERCISE)
        finally:
            db.close()

        route = _matched_route(request)
        if route is None:
            # No route matched, so there is nothing to authorise. Let it through
            # to the 404 the router will produce: answering 403 here would tell
            # a caller that a path they invented exists but is forbidden.
            return await call_next(request)

        if not rbac.permitted(route[0], route[1], held):
            # 403, not 401. Signing in again will not help — this person's
            # account is fine and their roles are simply not these. The message
            # names what is missing because a permissions error nobody can act
            # on becomes a support ticket asking what it meant.
            return JSONResponse(
                status_code=403,
                content={
                    "detail": (
                        "Your roles do not allow this. Needed: "
                        + ", ".join(sorted(rbac.ROUTE_ROLES[route]))
                        + "; held: "
                        + (", ".join(sorted(held)) or "none")
                        + "."
                    )
                },
            )

        request.state.roles = held
        return await call_next(request)


# Registered *after* `require_session`, and the order is load-bearing.
#
# Starlette inserts each new middleware at the front of the list and runs the
# front of the list outermost, so the last one added is the outer layer. CORS
# has to be outside the auth check, because the auth check returns its 401
# directly instead of calling the route — and a response built inside CORS
# never gets CORS headers on the way out.
#
# With the order reversed, that 401 reaches the browser without
# `Access-Control-Allow-Origin`, so `fetch` rejects it as a network error
# rather than resolving with `status === 401`. The web client distinguishes
# those two cases deliberately: a 401 clears the cached client records and
# shows the lock screen, while a network error keeps them and says the engine
# is unreachable. Getting this backwards means an expired session leaves names,
# dates of birth and portfolio values on screen and tells the user it is a
# connectivity problem.
app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed_origins(),
    allow_credentials=True,
    # Every method the route table actually uses, and nothing else. A method
    # missing here fails the browser's *preflight*, so the real request is never
    # sent and the failure looks like a network error rather than a refusal —
    # which is how `PATCH /tenant/advance-policy` shipped unreachable from the
    # web client for the length of one commit. `test_auth.py` asserts this list
    # against the live route table so the next one cannot.
    allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
    allow_headers=["Content-Type", "Accept"],
    # The headers this API sends *as signals to the client*, rather than as part
    # of a payload. Without this list a browser cannot read any of them: only
    # the CORS-safelisted response headers are visible to cross-origin
    # JavaScript, and everything else reads back as `null`.
    #
    # This was missing, and `X-Quolin-MFA` is the one that mattered.
    # `POST /auth/login` answers 401 with it when an account owes a second
    # factor, and `web/lib/api.ts` branches on exactly that header to throw
    # `MfaRequired` — which is what makes `AuthGate` reveal the six-digit field
    # instead of showing a failure. The engine cannot say sooner that an account
    # has a factor without becoming an account-enumeration oracle, so the header
    # *is* the mechanism.
    #
    # The web client and the engine are different sites — that is the whole
    # reason the session cookie is `SameSite=None`, and it is true in
    # development too. So the branch never fired anywhere: the person saw the
    # "enter the six-digit code" sentence rendered as an error, with their
    # password cleared and no field to type a code into. **No privileged account
    # could complete a sign-in through the web client, on any deployment.**
    #
    # Nothing caught it because nothing exercised it. Every role that required a
    # factor was one the browser suite never signs in as, and the offline
    # regression signs in as the operator — who had no factor until F8 gave them
    # one, at which point the only browser test in the repository walked
    # straight into it.
    #
    # `X-Quolin-Reauth` is the same mechanism for credential freshness, and is
    # listed before a client reads it rather than after. `X-Quolin-Request-Id`
    # is on every response and is what the error messages tell people to quote
    # to support, which they cannot do if the page cannot see it.
    expose_headers=["X-Quolin-MFA", "X-Quolin-Reauth", "X-Quolin-Request-Id"],
)


SCENARIOS = {
    "meridian": {
        "id": "meridian",
        "name": "Meridian Digital",
        "kind": "Crypto platform",
        "blurb": "Australian exchange under licensing deadline. Volume gating and evidence.",
        "artefact_kind": "evidence_pack",
    },
    "sterling": {
        "id": "sterling",
        "name": "Sterling Private Wealth",
        "kind": "Private wealth manager",
        "blurb": "HNW adviser weighing digital assets. Suitability nuance and TMDs.",
        "artefact_kind": "tmd",
    },
}


# The v1 routes are appended to the table directly rather than through
# `app.include_router`, and that is not a style preference.
#
# This version of FastAPI wraps an included router in an `_IncludedRouter`
# object rather than flattening its routes into `app.routes`. Every guard in
# this codebase reads a flat table: `_declared_routes` below, `_matched_route`
# above, the RBAC boot check, and the generated walk in `test_auth.py`. Under
# `include_router` all four would have seen nothing — so `/v1` would have served
# traffic while being invisible to the default-deny middleware, absent from the
# permissions table, and skipped by the test that exists to catch exactly that.
#
# It shipped that way for about ten minutes and was caught by the route count
# being zero. The routes already carry their `/v1` prefix, so appending them is
# what `include_router` used to do and what every guard here expects.
app.router.routes.extend(v1.router.routes)


@app.get("/status")
def status(session: Session = Depends(get_session)):
    """What a customer sees on the status page.

    §S9 asks for one. The hard part of a status page is not rendering it — it is
    deciding what a company is willing to say when things are going badly, and
    the answer that survives contact with a bad day is: the same things it says
    on a good one.

    So this reports the two facts that matter to somebody wondering whether to
    trust us today — can the engine answer, and does the evidence still verify —
    and nothing about *which* customer, because this is public. The chain check
    runs for the deployment's own tenant only, which is enough to distinguish
    "everything is fine" from "something is very wrong" without turning a public
    endpoint into a per-customer disclosure.

    Deliberately not a green light computed from an uptime average. A page that
    says "operational" while the chain is broken is worse than no page.
    """
    packs = session.scalar(select(func.count()).select_from(Pack)) or 0
    evidence_ok: bool | None = None
    try:
        with tenancy.acting_as(tenancy.configured_tenant()):
            probe = SessionLocal()
            try:
                if probe.scalar(select(func.count()).select_from(Decision)):
                    evidence_ok = bool(evidence.verify_chain(probe).get("verified"))
            finally:
                probe.close()
    except Exception:  # noqa: BLE001 — a status page never fails loudly
        evidence_ok = False

    return {
        "engine": "answering" if packs else "no rule content loaded",
        "packs_in_force": packs,
        # None where there is nothing to verify — a deployment holding no
        # determinations is not "unverified", it is empty, and saying so is more
        # honest than a green tick that means nothing.
        "evidence_chain": (
            "verified"
            if evidence_ok
            else ("nothing recorded yet" if evidence_ok is None else "NOT VERIFIED")
        ),
        "statement": (
            "This page reports whether the engine answers and whether the "
            "evidence chain verifies. It does not report per-customer state, "
            "and it is not an uptime average: if the chain does not verify, "
            "this page says so on the day it happens."
        ),
    }


@app.get("/health")
def health(session: Session = Depends(get_session)):
    """Liveness, and proof the database answers. Deliberately no tenant data.

    This used to return the decision count. It cannot any more, and the reason
    is worth stating rather than quietly deleting: `/health` is public, so no
    tenant is in scope, so row-level security correctly reports zero decisions.
    A probe that answered "0" would look like an empty database rather than like
    a working guarantee.

    Counting packs instead is not a workaround. Packs are global content, not
    anybody's data, so the number is the same for every caller and tells an
    unauthenticated prober nothing it could not read on the marketing site —
    while still failing if the database is unreachable or unseeded.
    """
    packs = session.scalar(select(func.count()).select_from(Pack)) or 0
    # Which revision is answering. A blue-green cutover is only verifiable if
    # the new colour can be told apart from the old one, and a container still
    # running the previous image otherwise answers exactly like a fresh one —
    # which is how a deploy silently does nothing. `scripts/deploy.py` refuses
    # to move traffic when this does not match what it just started.
    #
    # Keep it a rotation label — `blue`, `green` — and not a build SHA or a
    # hostname. This endpoint is public, so whatever is put here is told to
    # anybody who asks, and the cutover needs only enough to distinguish two
    # colours. Nothing in `infra/` sets it, so a deployed instance reports
    # `unreported` and the gate accepts that rather than refusing to work.
    return {
        "status": "ok",
        "packs": packs,
        "revision": os.getenv("QUOLIN_REVISION", "").strip() or "unreported",
    }


def _acting_person(session: Session) -> User:
    """The signed-in human, for the handlers that must print their name.

    Read from the ambient scope rather than taken as a parameter, the same way
    `service.audit` reads the actor and for the same reason. Raises rather than
    returning None: every caller is behind the authentication middleware, so a
    miss here is a bug in the middleware and not a request to handle politely.
    """
    user_id = tenancy.current_user_or_none()
    user = session.get(User, user_id) if user_id else None
    if user is None:
        raise HTTPException(401, "Not signed in.")
    return user


#: FP3-02 moved the decision into `client_address` so that `main` and `v1` share
#: one answer instead of holding two copies that were wrong in the same way.
#: Kept under the old names because every call site in this module uses them.
_client_ip = client_address.client_ip
_forwarded_header = client_address.forwarded_header


@app.post("/auth/login")
def login(
    payload: LoginRequest,
    request: Request,
    response: Response,
    session: Session = Depends(get_session),
):
    """Sign one person in.

    The tenant is still the deployment's, not the user's. That is not the same
    compromise the shared passcode was: `user_roles` is tenant-scoped, so a
    person with no grant in this deployment's tenant is refused below, and a
    consultant who serves three firms holds three grants and signs in to
    whichever deployment they are pointed at. A tenant *switcher* — one session
    moving between firms — is a different feature and is in docs/post-raise.md.
    """
    ip = _client_ip(request)
    forwarded = _forwarded_header(request)
    try:
        auth.check_rate_limit(session, ip)
        # And against the account, before the password is checked, so that an
        # attacker spread across a thousand addresses meets a limit anyway.
        # FP3-02: the address counter assumes the attacker has one address.
        # Resolving the address properly stops them *choosing* it and does
        # nothing about them having a botnet.
        auth.check_account_rate_limit(session, identity.account_id_for(session, payload.email))
    except auth.RateLimited as exc:
        # Recorded on the request's own session now. It used to open a second
        # one to write a `security_events` row, which could never succeed:
        # that table is tenant-scoped and nobody has a tenant yet at this point
        # in the request. See migration 0022.
        auth.record_attempt(
            session,
            ip=ip,
            outcome=auth.RATE_LIMITED,
            detail=str(exc),
            forwarded_for=forwarded,
        )
        session.commit()
        raise HTTPException(
            status_code=429,
            detail=str(exc),
            headers={"Retry-After": str(exc.retry_after)},
        ) from exc

    result = identity.authenticate(
        session, email=payload.email, password=payload.password, code=payload.code
    )
    if result.user is None:
        # Named by account when the attempt resolved to a real one and left null
        # otherwise — never by the address that was typed, which would make this
        # a list of who might have an account here.
        #
        # This used to be an `observability.record` into `security_events` as
        # well, and that call was worse than useless. It could not succeed —
        # `security_events` is tenant-scoped and nobody has a tenant at this
        # point in the request — and on failing it called `session.rollback()`,
        # exactly as its docstring says it does, which threw away the row above
        # along with it. Two writes, one impossible, and the impossible one
        # taking the good one down with it.
        auth.record_failure(
            session,
            ip,
            user_id=result.user_id,
            # A wrong code and a wrong password are counted apart. One is
            # somebody guessing; the other is somebody who already holds the
            # password and not the phone, which is a leaked credential.
            second_factor=result.outcome is identity.Outcome.MFA_WRONG,
            forwarded_for=forwarded,
        )
        session.commit()  # a spent one-time code stays spent even on refusal
        # One message for every failure except the one the caller has already
        # earned the right to hear. Telling someone who has just proved they
        # hold the password that a second factor is needed reveals nothing they
        # did not know, and withholding it only breaks the login form.
        if result.outcome is identity.Outcome.MFA_REQUIRED:
            raise HTTPException(
                status_code=401,
                detail="Enter the six-digit code from your authenticator app.",
                headers={"X-Quolin-MFA": "required"},
            )
        raise HTTPException(status_code=401, detail="Those details are not correct.")

    # Ends the transaction `authenticate` opened, and it has to happen here
    # rather than at the end. `app.tenant_id` is bound on the *begin* event, so
    # a transaction that started before the tenant was known keeps the empty
    # value it was given no matter what scope is entered afterwards — and the
    # policy on `auth_sessions` then refuses the insert. Committing first means
    # the work below runs in a transaction that begins with the tenant set.
    # It also persists what authenticating already spent: a one-time code's
    # counter, and any password rehash.
    session.commit()

    # `/auth/login` is public, so no tenant is in scope when it is reached —
    # this is the request that decides one. The write has to happen inside that
    # decision, because the policy on `auth_sessions` refuses a row naming a
    # tenant the connection is not set to.
    tenant_id = tenancy.configured_tenant()
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(result.user.id):
        held = identity.roles_for(session, result.user.id)
        if not held:
            # An account that exists and has no business here. Refused with the
            # same message as a wrong password, because "your password is right
            # but you have no access to this firm" is a fact about the firm's
            # staff list and is not the login form's to disclose.
            auth.record_failure(
                session, ip, user_id=result.user.id, forwarded_for=forwarded
            )
            session.commit()
            raise HTTPException(status_code=401, detail="Those details are not correct.")

        auth.clear_failures(
            session, ip, user_id=result.user.id, forwarded_for=forwarded
        )
        token = auth.create_session(
            session,
            tenant_id=tenant_id,
            user_id=result.user.id,
            mfa_satisfied=result.mfa_satisfied,
            user_agent=request.headers.get("user-agent", ""),
            ip=ip,
        )
    response.set_cookie(value=token, **auth.cookie_kwargs())
    return {
        "status": "ok",
        "expires_hours": auth.SESSION_HOURS,
        "display_name": result.user.display_name,
        "roles": sorted({row.role for row in held}),
    }


def _oidc_state_cookie_kwargs() -> dict:
    """The short-lived cookie carrying one login attempt.

    Not `auth.cookie_kwargs()`. That cookie is `SameSite=None` on a hosted
    deployment because the web app and the API are different sites and it has to
    survive an XHR between them; this one only has to survive the identity
    provider's top-level redirect back, which `Lax` permits. Narrower is right
    where narrower works.
    """
    secure = auth.cookie_secure()
    return {
        "key": oidc.STATE_COOKIE,
        "httponly": True,
        "secure": secure,
        "samesite": "none" if secure else "lax",
        "path": "/auth/oidc",
        "max_age": oidc.STATE_TTL_SECONDS,
    }


@app.get("/auth/oidc/start")
def oidc_start():
    """Send the browser to the firm's identity provider.

    A redirect rather than a JSON body holding a URL, because the caller is a
    link the user clicked and the next thing that has to happen is a top-level
    navigation. Returning the URL for the page to follow would work identically
    and would put an attacker-influenceable URL through client-side code for no
    benefit.
    """
    try:
        begin = oidc.start(oidc.require_configured())
    except oidc.NotConfigured as exc:
        # 404 rather than 503: on a deployment with no identity provider this
        # endpoint does not exist as a capability, and saying so is not a
        # failure to be retried.
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except oidc.OidcError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    response = RedirectResponse(begin.url, status_code=307)
    response.set_cookie(value=begin.cookie, **_oidc_state_cookie_kwargs())
    return response


@app.get("/auth/oidc/callback")
def oidc_callback(
    request: Request,
    code: str = Query(default=""),
    state: str = Query(default=""),
    error: str = Query(default=""),
    session: Session = Depends(get_session),
):
    """Turn the provider's answer into a session, or refuse it.

    Ends in a redirect to the web app either way, because the browser arrived
    here by a top-level navigation and a JSON error body would leave the user
    looking at raw text with no way back. The failure carries a code in the
    query string and nothing else — the messages this endpoint can produce are
    about a protocol the user cannot act on, and one of them ("no account here")
    is a fact about the firm's staff list that the login screen does not
    disclose for the password path either.
    """
    provider = oidc.configured()
    if provider is None:
        raise HTTPException(
            status_code=404,
            detail="No identity provider is configured for this deployment.",
        )

    def refuse(reason: str) -> Response:
        response = RedirectResponse(
            f"{provider.post_login_url}?sso_error={reason}", status_code=303
        )
        response.delete_cookie(key=oidc.STATE_COOKIE, path="/auth/oidc")
        return response

    # The provider declined before we get to say anything — a user who pressed
    # cancel, or an administrator who has not assigned them the application.
    if error:
        return refuse("declined")

    try:
        claims = oidc.complete(
            provider,
            code=code,
            state=state,
            cookie=request.cookies.get(oidc.STATE_COOKIE),
        )
    except oidc.OidcError:
        return refuse("invalid")

    result = identity.accept_assertion(
        session,
        issuer=claims.issuer,
        subject=claims.subject,
        email=claims.email,
        email_verified=claims.email_verified,
        display_name=claims.display_name,
    )
    if result.user is None:
        session.commit()
        return refuse("no_account")

    # The same commit-then-act dance `/auth/login` performs, for the same
    # reason: `app.tenant_id` binds when a transaction begins, so the session
    # row has to be written by a transaction that started with the tenant known.
    session.commit()

    tenant_id = tenancy.configured_tenant()
    with tenancy.acting_as(tenant_id), tenancy.acting_as_user(result.user.id):
        held = identity.roles_for(session, result.user.id)
        if not held:
            session.commit()
            return refuse("no_account")

        # Authenticating through the firm's own provider is the one sign-in
        # worth a row of its own. It is where a second factor was actually
        # presented (to them, not to us), and where a person's account here
        # first comes under their employer's control.
        service.audit(
            session,
            "auth.oidc.link" if result.linked else "auth.oidc.signin",
            f"user:{result.user.id}",
        )
        token = auth.create_session(
            session,
            tenant_id=tenant_id,
            user_id=result.user.id,
            # The provider asserted the credential, and whether it was a second
            # factor is its policy rather than ours. Recorded as not satisfied,
            # so that signing a pack still demands a step-up here — an
            # assumption in the permissive direction is the one that would let a
            # signature be collected from a session nobody re-proved.
            mfa_satisfied=False,
            user_agent=request.headers.get("user-agent", ""),
            ip=_client_ip(request),
        )

    response = RedirectResponse(provider.post_login_url, status_code=303)
    response.set_cookie(value=token, **auth.cookie_kwargs())
    response.delete_cookie(key=oidc.STATE_COOKIE, path="/auth/oidc")
    return response


@app.post("/auth/mfa/enrol")
def enrol_second_factor(
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Start enrolling an authenticator app, and return the secret once.

    Reachable from a session that is otherwise locked, because the alternative
    is a privileged account with no way back in: there is no enrolment that does
    not need a session, so refusing to authenticate an unenrolled signatory
    would lock them out permanently.

    `identity.enrol_totp` has existed since Stage 2 and had no HTTP surface —
    the credential could be created by a script and by nothing a person could
    reach. This exposes what was already there rather than adding a mechanism.

    The secret is returned once, at the moment it is created, and there is no
    route that will show it again: a credential a server re-displays on request
    is one an attacker holding a session can steal without touching the phone.
    """
    row = auth.resolve(session, quolin_session)
    if row is None or row.user_id is None:
        raise HTTPException(401, "Not signed in.")
    user = session.get(User, row.user_id)
    if user is None:
        raise HTTPException(401, "Not signed in.")

    # `enrol_totp` returns the provisioning URI, not the raw secret — the
    # credential holds the secret, encrypted at rest. Both are returned: an
    # authenticator app scans the URI, and somebody without a camera types the
    # secret.
    credential, otpauth_url = identity.enrol_totp(session, user, label="authenticator")
    secret = credential.secret
    service.audit(session, "mfa.enrol", f"credential:{credential.id}")
    session.commit()
    return {
        "secret": secret,
        "otpauth_url": otpauth_url,
        "status": "unconfirmed",
        "statement": (
            "Add this to an authenticator app, then confirm the six-digit code. "
            "The secret is shown once and cannot be read back."
        ),
    }


@app.post("/auth/mfa/verify")
def verify_second_factor(
    payload: SecondFactorRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Confirm the enrolment, and lift the lock on this session.

    The session's flag is set here rather than requiring a fresh sign-in: the
    person has just proved possession of the factor, which is the same proof a
    sign-in would collect, a moment later and for no gain.
    """
    row = auth.resolve(session, quolin_session)
    if row is None or row.user_id is None:
        raise HTTPException(401, "Not signed in.")

    # Queried directly rather than through `identity.second_factors`, whose
    # exclusion of unconfirmed rows is deliberate and load-bearing: an abandoned
    # enrolment must never decide whether MFA is satisfied. This is the one
    # place that wants the unconfirmed ones.
    pending = [
        credential
        for credential in session.scalars(
            select(MfaCredential).where(MfaCredential.user_id == row.user_id)
        )
        if credential.confirmed_at is None
    ]
    if not pending:
        raise HTTPException(422, "There is no enrolment waiting to be confirmed.")

    if not any(
        identity.confirm_totp(session, credential, payload.code)
        for credential in pending
    ):
        service.audit(session, "mfa.verify_failed", f"user:{row.user_id}")
        session.commit()
        raise HTTPException(401, "That code is not correct.")

    auth.mark_reauthenticated(session, row, mfa_satisfied=True)
    service.audit(session, "mfa.verified", f"user:{row.user_id}")
    session.commit()
    return {"status": "ok", "mfa_satisfied": True}


@app.post("/auth/reauth")
def reauth(
    payload: ReauthRequest,
    request: Request,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Prove again, on a session that is already live.

    Signing a pack demands a credential presented within the last few minutes,
    which means there has to be a way to present one without signing out first —
    otherwise the answer to "confirm your password" is "log out and back in",
    and the draft on screen is lost.
    """
    ip = _client_ip(request)
    forwarded = _forwarded_header(request)
    try:
        auth.check_rate_limit(session, ip)
    except auth.RateLimited as exc:
        raise HTTPException(
            status_code=429, detail=str(exc), headers={"Retry-After": str(exc.retry_after)}
        ) from exc

    row = auth.resolve(session, quolin_session)
    if row is None or row.user_id is None:
        raise HTTPException(status_code=401, detail="Not signed in.")

    try:
        auth.check_account_rate_limit(session, row.user_id)
    except auth.RateLimited as exc:
        raise HTTPException(
            status_code=429, detail=str(exc), headers={"Retry-After": str(exc.retry_after)}
        ) from exc

    user = session.get(User, row.user_id)
    if user is None:
        raise HTTPException(status_code=401, detail="Not signed in.")

    result = identity.authenticate(
        session, email=user.email, password=payload.password, code=payload.code
    )
    if result.user is None or result.user.id != row.user_id:
        auth.record_failure(
            session,
            ip,
            user_id=row.user_id,
            second_factor=result.outcome is identity.Outcome.MFA_WRONG,
            forwarded_for=forwarded,
        )
        session.commit()
        raise HTTPException(status_code=401, detail="That password is not correct.")

    auth.clear_failures(session, ip, user_id=row.user_id, forwarded_for=forwarded)
    auth.mark_reauthenticated(session, row, mfa_satisfied=result.mfa_satisfied)
    return {"status": "ok", "fresh_for_minutes": auth.REAUTH_MINUTES}


@app.post("/auth/logout")
def logout(
    response: Response,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Always 200, whether or not there was a session to end.

    Reporting "you were not logged in" would be a way to probe cookie validity
    without credentials, and there is nothing the caller could do differently.
    """
    ended = auth.destroy(session, quolin_session)
    response.delete_cookie(key=auth.COOKIE_NAME, path="/")
    return {"status": "ok", "ended": ended}


@app.get("/auth/session")
def auth_session(
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Whether this browser is signed in. Public, and 200 either way.

    The web app asks this on load to decide between the login screen and the
    app. A 401 here would be indistinguishable from a 401 caused by a genuine
    request failing, and the client needs to tell those apart.
    """
    row = auth.resolve(session, quolin_session)
    if row is None or row.user_id is None:
        return {"authenticated": False}

    # This path is public, so the middleware set no scope and the transaction
    # `resolve` opened was bound to no tenant and no person — `app.tenant_id`
    # and `app.user_id` are set on the *begin* event and cannot be changed after
    # it. Committing ends that transaction so the reads below run in one that
    # begins inside the scope, and without it every policy on `users` sees an
    # empty string and this endpoint reports a live session as signed out.
    session.commit()

    with tenancy.acting_as(row.tenant_id), tenancy.acting_as_user(row.user_id):
        user = session.get(User, row.user_id)
        roles = sorted({grant.role for grant in identity.roles_for(session, row.user_id)})
        # FP3-12(a). The web app needs to know that this session is confined to
        # enrolling a second factor, so it can show the enrolment screen rather
        # than the app and a wall of 403s.
        #
        # Answered here rather than by the client comparing `roles` against its
        # own copy of `MFA_REQUIRED_ROLES`. A duplicated policy list is a policy
        # list that drifts, and the direction it drifts in is the dangerous one:
        # a role added to the server's set would be enforced by the middleware
        # and unknown to the client, which is a privileged account that gets
        # 403s it cannot explain and no way to fix it.
        mfa_confined = mfa.locked_out(
            session, user_id=row.user_id, mfa_satisfied=bool(row.mfa_satisfied)
        )
    if user is None:
        return {"authenticated": False}

    return {
        "authenticated": True,
        "since": row.created_at.isoformat(),
        "expires": row.expires_at.isoformat(),
        "user": {"email": user.email, "display_name": user.display_name},
        "roles": roles,
        # Whether an action that demands a freshly presented credential would
        # go through right now. The client reads it to decide between showing a
        # Sign button and showing a confirm-your-password step, rather than
        # letting the user compose a signature and then refusing it.
        "credential_fresh": auth.credential_is_fresh(row),
        # How long a presented credential lasts, so the client can say it rather
        # than hardcode a number that stops matching the day the env var moves.
        "credential_fresh_minutes": auth.REAUTH_MINUTES,
        "mfa_satisfied": row.mfa_satisfied,
        #: This session can do nothing but enrol an authenticator. FP3-12(a).
        "mfa_required": mfa_confined,
    }


@app.get("/auth/sessions")
def list_sessions(session: Session = Depends(get_session)):
    """Every browser currently holding a live session.

    Authenticated, so it is only visible to someone already inside. Exists so
    that "who else has this open" has an answer during a demo, and so revoking
    is a decision made against something visible rather than a guess.
    """
    auth.purge_expired(session)
    rows = auth.active_sessions(session)
    return {
        "count": len(rows),
        "sessions": [
            {
                # Never the token, and never its full hash: an 8-character
                # prefix is enough to tell two rows apart on screen and not
                # enough to be worth anything if this response is shared.
                "ref": r.token_hash[:8],
                "created_at": r.created_at.isoformat(),
                "last_seen_at": r.last_seen_at.isoformat(),
                "expires_at": r.expires_at.isoformat(),
                "user_agent": r.user_agent,
                "created_ip": r.created_ip,
            }
            for r in rows
        ],
    }


#: Which sessions `/auth/revoke-all` ends. `me` is the default and is what the
#: break-glass case actually needs; `tenant` is an administrative act.
REVOKE_SCOPES = ("me", "tenant")

#: The roles that may end every session in the firm. `tenant_admin` administers
#: the firm's people, which is what this is.
FIRM_WIDE_REVOKE_ROLES = frozenset({"tenant_admin"})


@app.post("/auth/revoke-all")
def revoke_all(
    request: Request,
    response: Response,
    payload: RevokeRequest | None = None,
    session: Session = Depends(get_session),
):
    """Sign this person out of every browser — or, for an administrator, the firm.

    The control for "a laptop has gone missing" and for "somebody left today".
    Suspending an account or changing a password stops new sign-ins but does
    nothing about sessions already minted, which is exactly the case where you
    most want them gone.

    **`me` by default, and open to every role.** Somebody whose credential has
    just leaked needs their own sessions gone immediately, not after they have
    found an administrator. That is a decision about *people* and it has not
    changed.

    **`tenant` is administrative.** Q-14: this route used to end every session
    in the firm for anybody who called it, `viewer` included. Signing out every
    employee to deal with one person's leaked password is a denial of service —
    which is the argument the route already made about machines, and it applies
    just as well to a borrowed cookie or an accidental double-click.

    A machine may do neither. An integration has no sessions of its own worth
    ending this way and no business ending the firm's. The check is here rather
    than in the route table for the same reason the separation-of-duties rules
    are: the table classifies routes by role, and this is a fact about what kind
    of principal is asking.

    An unrecognised scope is refused rather than narrowed to the default. An
    administrator dealing with a real incident must not be told "ok" over a
    sweep that did the smaller thing.
    """
    if getattr(request.state, "api_client_id", None) is not None:
        raise HTTPException(
            403,
            "An integration may not sign the firm's people out. This is a "
            "break-glass control for a person whose own credential has leaked. "
            "If this integration's secret has leaked, suspend the credential "
            "and revoke its tokens instead.",
        )

    scope = (payload.scope if payload is not None else "me") or "me"

    if scope == "tenant":
        held: frozenset[str] = getattr(request.state, "roles", frozenset())
        if not (held & FIRM_WIDE_REVOKE_ROLES):
            raise HTTPException(
                403,
                "Signing every person in the firm out is an administrative act. "
                "Your own sessions are yours to end — call this again without a "
                "scope, or with `\"scope\": \"me\"`. Needed for the firm: "
                + ", ".join(sorted(FIRM_WIDE_REVOKE_ROLES))
                + ".",
            )
        count = auth.destroy_all(session)
    else:
        row = auth.resolve(session, request.cookies.get(auth.COOKIE_NAME))
        user_id = row.user_id if row is not None else None
        if user_id is None:
            raise HTTPException(401, "Not signed in.")
        count = auth.destroy_mine(session, user_id=user_id)

    response.delete_cookie(key=auth.COOKIE_NAME, path="/")
    return {"status": "ok", "scope": scope, "revoked": count}


@app.get("/scenarios")
def scenarios():
    return list(SCENARIOS.values())


@app.get("/assets")
def list_assets(
    jurisdiction: str = service.DEFAULT_JURISDICTION,
    session: Session = Depends(get_session),
):
    """The tradeable list, classified by one jurisdiction's pack.

    A classification is not a property of the asset; it is a property of the
    pack reading it. So the response names the pack that produced it, and the
    caller can ask a different one.
    """
    rows = session.scalars(select(Asset).order_by(Asset.id))
    try:
        pack = packs_repo.describe(session, jurisdiction, business_time.business_today(session))
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc
    out = []
    for row in rows:
        classification = pack.asset_classes.get(row.id, {})
        out.append(
            {
                "id": row.id,
                "symbol": row.symbol,
                "name": row.name,
                "class": classification.get("class"),
                "volatility_band": classification.get("volatility_band"),
                "leverage": classification.get("leverage"),
                "structural_flags": classification.get("structural_flags", []),
                "classified_by": pack.pack_id,
                "classified_by_version": pack.version,
            }
        )
    return out


@app.get("/clients")
def list_clients(
    scenario: str | None = None,
    cast_only: bool = False,
    limit: int = Query(default=250, le=500),
    session: Session = Depends(get_session),
):
    provider = DbClientProvider(session)
    clients = provider.list(scenario)
    if cast_only:
        # Seeded membership, not "has a note". An imported book carries notes of
        # its own, and a client who arrived by CSV should not be able to walk
        # onto the home screen because someone filled in the note column.
        cast = provider.cast_ids()
        clients = [c for c in clients if c["id"] in cast]
    return [
        {
            "id": c["id"],
            "name": c["name"],
            "scenario": c["scenario"],
            "loss_capacity_band": c["loss_capacity_band"],
            "vulnerability_flag": c["vulnerability_flag"],
            "knowledge_assessed": c["knowledge_assessed"],
            "assessable_portfolio_cents": c["assessable_portfolio_cents"],
            "jurisdiction": c.get("jurisdiction"),
            "residency": c.get("residency"),
            "domicile": c.get("domicile"),
            "cross_border": len({c.get("jurisdiction"), c.get("residency"), c.get("domicile")}) > 1,
            "note": c["note"],
        }
        for c in clients[:limit]
    ]


def _under_support_grant(session: Session) -> bool:
    """Whether the person making this request holds `quolin_support`.

    FP3-14. Support access is documented as "every access logged" and was logged
    nowhere. The role is checked rather than the route, because what makes a
    support read worth recording is who is doing it, not what they asked for.
    """
    user_id = tenancy.current_user_or_none()
    if not user_id:
        return False
    try:
        return any(g.role == "quolin_support" for g in identity.roles_for(session, user_id))
    except Exception:  # noqa: BLE001 — a read must not fail because auditing did
        return False


@app.get("/clients/{client_id}")
def get_client(client_id: str, session: Session = Depends(get_session)):
    try:
        client = DbClientProvider(session).get(client_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc

    today = business_time.business_today(session)
    custody = FixturePositionsProvider()
    positions = custody.get(client_id, today)
    licensee = client.get("jurisdiction") or service.DEFAULT_JURISDICTION
    pack = packs_repo.describe(session, licensee, today)
    portfolio = client["assessable_portfolio_cents"]
    exposure_bps = (positions["crypto_value_cents"] * 10_000 // portfolio) if portfolio else 0

    # Zero holdings and no custody record produce the same figures and mean
    # entirely different things. Imported clients are always the second kind, so
    # the screen needs to be able to tell them apart and say which it is showing.
    custody_on_file = custody.has_record(client_id)

    # FP3-14. This returns a name, a date of birth and contact details, to
    # anybody holding `viewer`, and nothing recorded that it had been read.
    service.audit_read(
        session,
        resource="client",
        subject=f"client:{client_id}",
        support=_under_support_grant(session),
    )
    # Committed here rather than at the end of the handler. A GET has no other
    # write to batch it with, and the read has already happened — the record of
    # it should not depend on the rest of the response being assembled without
    # error.
    session.commit()

    history = session.scalars(
        select(Decision).where(Decision.client_id == client_id).order_by(Decision.id.desc())
    ).all()

    # Which regimes this client answers to, before any trade is proposed. The
    # screen shows it up front because "who governs this relationship" is not a
    # detail that should first appear on a determination.
    # Shaped like a snapshot so the same two engine functions answer here as on
    # a determination. Deriving "who governs" twice, two ways, is how a client
    # screen and the decision it leads to end up disagreeing.
    facts = {
        "licensee": {"jurisdiction": licensee},
        "client": {
            "residency": client.get("residency"),
            "domicile": client.get("domicile"),
        },
    }
    matched, unmatched = crossborder.select_packs(
        facts, packs_repo.describe_all(session, today)
    )
    basis = crossborder.code_basis(facts)

    return {
        **{k: (v.isoformat() if isinstance(v, date) else v) for k, v in client.items()},
        "positions": positions,
        "custody_on_file": custody_on_file,
        "exposure_bps": exposure_bps,
        "concentration_cap_bps": pack.thresholds["max_crypto_concentration_bps"],
        "pack_version": pack.version,
        "pack_content_status": pack.content_status,
        "cross_border": len(matched) > 1,
        "applicable_jurisdictions": [
            {
                "jurisdiction": p.pack_id,
                "pack_version": p.version,
                "content_status": p.content_status,
                "covers_states": p.covers_states,
                "basis": crossborder.basis_for(basis, p),
                "governing": p.pack_id == pack.pack_id,
            }
            for p in matched
        ],
        "jurisdictions_without_packs": unmatched,
        "decisions": [
            {
                "id": d.id,
                "asset_id": d.asset_id,
                "outcome": d.outcome,
                "as_of": d.as_of.isoformat(),
                "pack_id": d.pack_id,
                "pack_version": d.pack_version,
                "cross_border": bool(d.resolution),
                "created_at": d.created_at.isoformat(),
            }
            for d in history
        ],
    }


@app.post("/evaluate")
def evaluate(payload: EvaluateRequest, session: Session = Depends(get_session)):
    # F7, shared with `/v1` rather than restated, so the two cannot drift into
    # allowing different dates.
    v1.check_as_of(session, payload.as_of, payload.as_of_reason)
    if payload.as_of is not None and payload.as_of < business_time.business_today(session):
        service.audit(
            session,
            v1.BACKDATED_ACTION,
            f"client:{payload.client_id} as at {payload.as_of.isoformat()} — "
            f"{(payload.as_of_reason or '').strip()}",
        )

    try:
        decision = service.evaluate(
            session,
            client_id=payload.client_id,
            asset_id=payload.asset_id,
            as_of=payload.as_of,
            amount_cents=payload.amount_cents,
        )
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc
    except LookupError as exc:
        raise HTTPException(422, str(exc)) from exc
    except PackError as exc:
        raise HTTPException(422, v1.unusable_facts(exc)) from exc

    view = service.decision_view(session, decision)
    session.commit()
    return view


@app.get("/decisions")
def list_decisions(
    client_id: str | None = None,
    outcome: str | None = None,
    limit: int = Query(default=50, le=500),
    session: Session = Depends(get_session),
):
    stmt = select(Decision).order_by(Decision.id.desc()).limit(limit)
    if client_id:
        stmt = stmt.where(Decision.client_id == client_id)
    if outcome:
        stmt = stmt.where(Decision.outcome == outcome)
    return [
        {
            "id": d.id,
            "client_id": d.client_id,
            "client_name": d.snapshot["client"]["name"],
            "asset_id": d.asset_id,
            "outcome": d.outcome,
            "as_of": d.as_of.isoformat(),
            "pack_version": d.pack_version,
            "created_at": d.created_at.isoformat(),
        }
        for d in session.scalars(stmt)
    ]


@app.get("/decisions/{decision_id}")
def get_decision(decision_id: int, session: Session = Depends(get_session)):
    decision = session.get(Decision, decision_id)
    if decision is None:
        raise HTTPException(404, "unknown decision")

    # The snapshot carries the client's frozen facts, so reading a determination
    # is reading the client. FP3-14.
    service.audit_read(
        session,
        resource="decision",
        subject=f"decision:{decision_id} client:{decision.client_id}",
        support=_under_support_grant(session),
    )
    view = service.decision_view(session, decision)
    session.commit()
    return view


@app.post("/decisions/{decision_id}/replay")
def replay_decision(decision_id: int, session: Session = Depends(get_session)):
    decision = session.get(Decision, decision_id)
    if decision is None:
        raise HTTPException(404, "unknown decision")
    result = service.replay(session, decision)
    session.commit()
    return result


@app.post("/decisions/{decision_id}/override")
def override_decision(
    decision_id: int,
    payload: OverrideRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    decision = session.get(Decision, decision_id)
    if decision is None:
        raise HTTPException(404, "unknown decision")

    # The second half of a two-person act, asserted at the action.
    #
    # The whole argument for separation of duties is that two people had to act.
    # If one of them is a password somebody was phished out of, there was one —
    # so an approver without a second factor may not complete this even from a
    # session the door let through.
    row = auth.resolve(session, quolin_session)
    if row is not None and row.user_id is not None:
        try:
            mfa.assert_second_factor(
                session, user_id=row.user_id, mfa_satisfied=bool(row.mfa_satisfied)
            )
        except mfa.MfaRequired as exc:
            raise HTTPException(403, str(exc)) from exc

    try:
        service.override(
            session,
            decision,
            justification=payload.justification,
            approver=_acting_person(session).display_name,
        )
    except service.SelfApproval as exc:
        # 409, not 403. This person holds `approver` and the role is right; what
        # is wrong is this pairing of person and decision.
        raise HTTPException(409, str(exc)) from exc
    view = service.decision_view(session, decision)
    session.commit()
    return view


@app.post("/artefacts/batch")
def queue_artefacts(payload: ArtefactBatchRequest, session: Session = Depends(get_session)):
    """Ask for many documents. Renders none of them now.

    §S7's gate is that a hundred queued renders do not block the API, and the
    way to pass it is not to make rendering faster. A PDF takes hundreds of
    milliseconds and holds a worker; a hundred inside requests is a hundred
    requests waiting, and the first thing to break is the determination endpoint
    sharing the pool.

    **One document stays synchronous** — `POST /artefacts/{kind}` still renders
    and returns, because somebody is looking at a screen and a spinner is the
    right answer for three hundred milliseconds. A hundred documents is not a
    request, and this is the endpoint for that.

    Idempotent: asking twice for the same document while one is outstanding
    returns the first job. A screen with an eager button, a retrying client and
    a month-end schedule all asking at once would otherwise render it three
    times and leave three rows claiming to be what was filed.
    """
    accepted: list[dict] = []
    params: dict[str, str | None]
    today = business_time.business_today(session)
    declared = packs_repo.active_all(session, today)
    for item in payload.jobs:
        kind = item.kind
        regime = (item.jurisdiction or service.DEFAULT_JURISDICTION).upper()
        pack = declared.get(regime)
        if pack is None:
            raise HTTPException(404, f"no {regime} pack in force")
        if kind not in (pack.artefact_templates or {}):
            raise HTTPException(
                404,
                f"{regime} v{pack.version} declares no document called {kind!r}. "
                f"It declares: {', '.join(artefacts.renderer.kinds_for(pack)) or 'none'}.",
            )
        scope = artefacts.renderer.scope_of(kind, pack)
        if scope == artefacts.renderer.RUN_SCOPE:
            if not item.run_id:
                raise HTTPException(422, f"{kind} needs a run_id")
            params = {"run_id": str(item.run_id)}
            subject = f"sweep {item.run_id}"
        elif scope == artefacts.renderer.PERIOD_SCOPE:
            if not item.period:
                raise HTTPException(422, f"{kind} needs a period")
            params = {
                "period": item.period,
                "jurisdiction": regime,
                "scenario": item.scenario,
            }
            subject = f"{regime} {item.period}"
        else:
            if not item.decision_id:
                raise HTTPException(422, f"{kind} needs a decision_id")
            params = {"decision_id": str(item.decision_id)}
            subject = f"determination #{item.decision_id}"

        job, created = artefacts.queue.enqueue(
            session,
            kind=kind,
            params=params,
            subject=subject,
            requested_by=_acting_person(session).id,
            # The scope this pack declares for this kind, which is what decides
            # the job's place in the queue. Passed rather than re-derived inside
            # `enqueue`, because it has already been computed above and a second
            # derivation is a second thing that can disagree.
            scope=scope,
        )
        accepted.append({**artefacts.queue.view(job), "created": created})

    service.audit(session, "artefact.queue", f"{len(accepted)} document(s)")
    session.commit()
    # 202: accepted, not done. A 200 here would be a lie a client would believe.
    return JSONResponse(status_code=202, content={"jobs": accepted})


@app.get("/adoption")
def get_adoption(session: Session = Depends(get_session)):
    """Where this firm is on the ladder, and what that means for them today.

    The explanation travels with the stage because it is shown to customers. A
    screen that said "shadow" and nothing else would leave the most important
    fact — that nothing we decide is reaching anybody — as tribal knowledge.
    """
    tenant = session.get(Tenant, tenancy.current_tenant())
    stage = adoption.stage_of(tenant)
    return {
        "stage": stage,
        "means": adoption.WHAT_EACH_MEANS[stage],
        "ladder": list(adoption.LADDER),
        "limited_scope": adoption.scope_of(tenant),
        # §S10's target metric, reported beside the stage it measures.
        "onboarding": adoption.onboarding(session),
        "history": adoption.history(session),
    }


@app.post("/adoption")
def move_adoption(
    payload: StageRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Move this firm one rung, with a signature.

    Re-authentication is required for the same reason signing a pack is: this
    is the act that makes a customer's determinations start affecting their
    clients, and an unattended screen must not be able to perform it.
    """
    row = auth.resolve(session, quolin_session)
    if row is None:
        raise HTTPException(401, "Not signed in.")
    person = _acting_person(session)
    try:
        auth.require_fresh_credential(
            row, action="Moving a firm along the adoption ladder"
        )
    except auth.ReauthenticationRequired as exc:
        raise HTTPException(
            401, str(exc), headers={"X-Quolin-Reauth": "required"}
        ) from exc

    try:
        change = adoption.move(
            session,
            to_stage=payload.stage,
            signed_by=payload.signed_by or person.display_name,
            note=payload.note or "",
        )
    except adoption.LadderError as exc:
        raise HTTPException(409, str(exc)) from exc

    service.audit(
        session,
        "adoption.move",
        f"{change.from_stage} → {change.to_stage}, signed {change.signed_by}",
    )
    session.commit()
    return {
        "stage": change.to_stage,
        "means": adoption.WHAT_EACH_MEANS[change.to_stage],
        "signed_by": change.signed_by,
        "at": change.at.isoformat(),
    }


# ------------------------------------------------------------ provisioning --
#
# Until now, a person and a role grant could only be created from a database
# shell. `identity.grant_role` defaulted its granter to the string "bootstrap",
# and the quarterly access review therefore reported, accurately and uselessly,
# on a set of permissions whose authorisation was a word.
#
# The SOC 2 control is not that access exists. It is that somebody authorised it
# and somebody else can see who.
#
# `quolin_operator` only, deliberately. A customer's `tenant_admin` still cannot
# grant roles, because Q-12 rests on them being unable to grant themselves the
# role that publishes rule content to every tenant — splitting the vocabulary
# into "roles a customer may grant" and "roles only we may grant" is a design
# decision larger than this. Nobody loses anything: this replaces a psql prompt,
# not a screen.


def _provisioning_principal(session: Session, token: str | None) -> User:
    """The account behind a provisioning act, with a credential presented lately.

    Freshness for the reason signing rule content has it: creating an account or
    handing somebody a role is at least as weighty, and an unattended screen
    must not be able to do either.
    """
    row = auth.resolve(session, token)
    if row is None or row.user_id is None:
        raise HTTPException(401, "Not signed in.")
    try:
        auth.require_fresh_credential(row, action="Provisioning access")
    except auth.ReauthenticationRequired as exc:
        raise HTTPException(
            401, str(exc), headers={"X-Quolin-Reauth": "required"}
        ) from exc
    return _acting_person(session)


@app.get("/admin/users")
def list_users(
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """This firm's people and the roles they hold.

    **New API surface, and FP3-26 says to say so.** Every other screen in that
    finding consumes routes that already existed; a user-administration screen
    genuinely cannot be built without a way to list the people it administers,
    and provisioning, granting, revoking and suspending were all POSTs with no
    corresponding read.

    Scoped by `tenant_members`: a person is this firm's to see because this firm
    provisioned them or granted them something, and a consultant serving three
    firms appears in three lists and not in a fourth.

    **Membership rather than `user_roles`, and the difference is visible on the
    screen.** This listed grant-holders until migration 0047, so revoking
    somebody's last role made them vanish from the very screen an administrator
    would use to re-grant it or to suspend them — an act that quietly removed
    its own undo. Found by revoking a last grant through the UI after 0047
    landed. A person with no live grants is now listed with an empty `roles`,
    which is a true statement about somebody who is still one of this firm's
    people and currently holds nothing.

    **Read through the request's own session, which is the connection this
    handler is entitled to.** It used to open `OwnerSessionLocal` — the role
    that owns every append-only trigger, is exempt from FORCE row-level
    security, and is what `scripts/rechain.py` rewrites evidence hashes with —
    inside a request, and justified it on the ground that `users` is a platform
    table invisible until `app.user_id` names the row.

    That was true of `user_self` and had already stopped being the whole story:
    migration 0047 re-pointed `user_reachable` at `tenant_members`, which is
    exactly the roster this handler lists. Every person it enumerates is
    therefore visible to the firm's own connection, and the owner read was
    buying nothing.

    It was also **broken in production**, which nothing said. FP3-04 removed
    `DATABASE_URL` from the request-serving task, and `db.py` falls back to a
    hardcoded `localhost:5433` when it is absent — so in the deployment this
    screen did not bypass a boundary, it failed to connect. The bypass was
    reachable only where the owner connection happens to be lying about, which
    is a developer's laptop and the suite.

    `app/owner_only.py` exists to make that mistake loud and cannot prevent it
    being made by importing `app.db` directly, which is what this did.
    `scripts/guard_no_owner_in_request_path.sh` is what prevents it now.

    **No credential-freshness check, unlike every write on this screen.**
    `_provisioning_principal` demands one because "an unattended screen must not
    be able to *do* either" — creating an account, handing over a role. Reading
    who already holds what is not one of those acts, and requiring freshness for
    it would mean the administration screen could not load at all until somebody
    retyped a password, which trains people to retype passwords at prompts. The
    role check in `rbac.ROUTE_ROLES` is what bounds this, and it is the same
    role that bounds the writes.
    """
    row = auth.resolve(session, quolin_session)
    if row is None or row.user_id is None:
        raise HTTPException(401, "Not signed in.")
    tenant_id = tenancy.current_tenant()

    grants = list(session.scalars(select(UserRole).order_by(UserRole.granted_at)))
    by_user: dict[str, list[UserRole]] = {}
    for grant in grants:
        by_user.setdefault(grant.user_id, []).append(grant)

    # The roster is the membership, not the grants. Both are read under the
    # tenant's own policies, so the owner read below is bounded by what this
    # firm may already see.
    members = list(
        session.scalars(select(TenantMember).order_by(TenantMember.joined_at))
    )

    people: list[dict[str, Any]] = []
    for member in members:
        user_id = member.user_id
        held = by_user.get(user_id, [])
        person = session.get(User, user_id)
        if person is None:
            # A membership whose person this firm cannot see. Skipped rather
            # than rendered as a blank row, and it should be unreachable:
            # `tenant_members` is what `user_reachable` reads, so a row here
            # with no visible person means the two have come apart.
            continue
        people.append(
            {
                "id": person.id,
                "email": person.email,
                "display_name": person.display_name,
                "status": person.status,
                "roles": [
                    {
                        "id": g.id,
                        "role": g.role,
                        "jurisdiction": g.jurisdiction,
                        "granted_by": g.granted_by,
                        "granted_at": g.granted_at.isoformat(),
                        "expires_at": (
                            g.expires_at.isoformat() if g.expires_at else None
                        ),
                    }
                    for g in held
                ],
            }
        )

    people.sort(key=lambda p: p["display_name"].lower())
    return {"tenant_id": tenant_id, "users": people}


@app.post("/admin/users")
def provision_user(
    payload: NewUserRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Create a person, and mint the invitation that lets them choose a password."""
    granter = _provisioning_principal(session, quolin_session)

    existing = identity.find_by_email(session, payload.email)
    if existing is not None:
        # Not an error. A consultant compliance officer serves several firms and
        # already exists as a person; what this firm is doing is granting them a
        # role, which is the next call. Returning the id makes that possible
        # without the caller having to know which case they were in.
        service.audit(
            session, "identity.user.existing", f"{existing.id} ({payload.email})"
        )
        session.commit()
        return {"id": existing.id, "email": existing.email, "created": False}

    person = identity.create_user(
        session, email=payload.email, display_name=payload.display_name
    )
    session.flush()

    # One of this firm's people from the moment it created them, before any
    # role. Migration 0047's reasoning: `identity.invitation.consumed` names the
    # invited person as its actor, correctly, at a moment when they hold no
    # grant — so without this the window between choosing a password and being
    # given a role is a window in which the audit trail names somebody the firm
    # cannot resolve.
    #
    # Only on this branch. The existing-person branch above returns before it,
    # deliberately: a consultant who already has an account does not become
    # visible to a firm because somebody typed their address, only when that
    # firm actually grants them something — and `grant_role` does it there.
    identity.ensure_member(session, user_id=person.id, reason="provisioned")

    service.audit(session, "identity.user.create", f"{person.id} ({person.email})")

    # FP3-11. Until this, `POST /admin/users` created — in its own docstring —
    # "a person, created with no way to sign in yet", and there was nothing that
    # turned that into somebody who could. `set_password` had two callers: the
    # seed and the load model. The first customer's first user could be created
    # and could never sign in.
    #
    # The token comes back once, here, to the administrator who created the
    # account. It is not stored — only its digest is — so there is no route that
    # can reveal it again, which is what makes hashing it worth anything.
    invitation, token = invitations.issue(
        session, user=person, created_by=granter.id
    )
    service.audit(
        session,
        "identity.invitation.issued",
        f"{person.id} ({person.email}) invited by {granter.id}, "
        f"expires {invitation.expires_at.isoformat()}",
    )
    session.commit()
    return {
        "id": person.id,
        "email": person.email,
        "created": True,
        "invitation": {
            "token": token,
            "expires_at": invitation.expires_at.isoformat(),
        },
    }


@app.post("/auth/set-password")
def set_password_from_invitation(
    payload: SetPasswordRequest,
    request: Request,
    session: Session = Depends(get_session),
):
    """Choose a password, using a single-use invitation. FP3-11.

    Public, and it has to be: this is how somebody who has never signed in comes
    to have a credential. It is a credential-granting endpoint, so it carries
    the same defences `/auth/login` does — the address counter and the
    per-account counter from FP3-02 — because an invitation token is guessable
    in exactly the way a password is, only shorter-lived.

    **One message for every failure.** Expired, already used, and never ours are
    three facts about our records, and telling somebody holding a bad token
    which one applies tells them something about an account they may not hold.

    The password policy is checked before the invitation is spent, so a first
    attempt that is too short leaves the link live. The failure mode of a
    password rule that spends the token on a rejected attempt is that people
    lock themselves out by trying to obey it.
    """
    ip = client_address.client_ip(request)
    forwarded = client_address.forwarded_header(request)

    # The tenant is entered **before the first query**, not before the first
    # query that needs it. `app.tenant_id` binds on the engine's `begin` event,
    # so whichever statement opens the transaction fixes the tenant for every
    # statement after it — and `check_rate_limit` opens it.
    #
    # This route is public, so the middleware binds nothing, and the first draft
    # had the rate-limit check outside the scope: the invitation lookup then ran
    # under `app.tenant_id = ''`, matched no row, and every valid link in the
    # world was told it was not valid. The same defect F2 fixed in
    # `/v1/oauth/token`, written again in the next public route.
    tenant_id = tenancy.configured_tenant()
    with tenancy.acting_as(tenant_id):
        try:
            auth.check_rate_limit(session, ip)
        except auth.RateLimited as exc:
            auth.record_attempt(
                session,
                ip=ip,
                outcome=auth.RATE_LIMITED,
                detail=str(exc),
                forwarded_for=forwarded,
            )
            session.commit()
            raise HTTPException(
                429, str(exc), headers={"Retry-After": str(exc.retry_after)}
            ) from exc

        try:
            user = invitations.consume(
                session, payload.token, password=payload.password
            )
        except invitations.InvitationInvalid as exc:
            auth.record_failure(session, ip, forwarded_for=forwarded)
            session.commit()
            raise HTTPException(400, str(exc)) from exc
        except ValueError as exc:
            # The password policy. Not a failed attempt — the person holds a
            # valid link and typed something too weak — so it is not counted
            # against them and the link is still live.
            raise HTTPException(422, str(exc)) from exc

        with tenancy.acting_as_user(user.id):
            service.audit(
                session,
                "identity.invitation.consumed",
                f"{user.id} ({user.email}) set a password",
            )
        auth.clear_failures(session, ip, user_id=user.id, forwarded_for=forwarded)
        session.commit()

    return {
        "status": "ok",
        "email": user.email,
        "next": "Sign in with your new password.",
    }


@app.post("/auth/reset")
def request_password_reset(
    payload: ResetRequest,
    request: Request,
    session: Session = Depends(get_session),
):
    """Ask for a link to choose a new password. FP3-11.

    **Answers identically whether or not the address names an account.** This is
    the one endpoint that must be reachable by somebody who cannot sign in, so a
    response that distinguished the two cases would be an enumeration oracle on
    exactly the surface that has none of the other defences.

    Which means the token cannot come back in the response, unlike the
    provisioning route where it goes to an administrator who has already
    authenticated. Delivery is out of scope here and is stated rather than
    implied: **this repository sends no email.** The row is written and an
    operator hands the link over. That is a smaller gap than having no reset at
    all, and it is recorded in the change log rather than left for somebody to
    discover.
    """
    ip = client_address.client_ip(request)
    forwarded = client_address.forwarded_header(request)

    # Scope entered before the first query, for the reason above.
    tenant_id = tenancy.configured_tenant()
    with tenancy.acting_as(tenant_id):
        try:
            auth.check_rate_limit(session, ip)
        except auth.RateLimited as exc:
            raise HTTPException(
                429, str(exc), headers={"Retry-After": str(exc.retry_after)}
            ) from exc

        user = identity.find_by_email(session, payload.email)
        if user is not None and not invitations.outstanding(session, user.id):
            invitations.issue(
                session, user=user, created_by="self-service", kind=invitations.RESET
            )
            with tenancy.acting_as_user(user.id):
                service.audit(
                    session,
                    "identity.reset.requested",
                    f"{user.id} requested a password reset",
                )
        # Recorded either way, so a spray of addresses against this endpoint is
        # visible even though none of them is told anything.
        auth.record_attempt(
            session,
            ip=ip,
            outcome=auth.FAILED if user is None else auth.SUCCEEDED,
            detail="password reset requested",
            user_id=user.id if user else None,
            forwarded_for=forwarded,
        )
        session.commit()

    return {
        "status": "ok",
        "message": (
            "If that address has an account, a link to choose a new password "
            "has been created. Ask your administrator for it."
        ),
    }


@app.post("/admin/users/{user_id}/roles")
def provision_role(
    user_id: str,
    payload: GrantRoleRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Grant one role, naming the account that granted it."""
    granter = _provisioning_principal(session, quolin_session)

    # Not `session.get`. `users` is policed by reachability — a firm sees a
    # person exactly when it has granted them a role — so the request about to
    # make the *first* grant cannot see the person it is granting to. See
    # `identity.find_by_id`.
    person = identity.find_by_id(session, user_id)
    if person is None:
        raise HTTPException(404, f"no user {user_id}")

    try:
        grant = identity.grant_role(
            session,
            user_id=user_id,
            role=payload.role,
            jurisdiction=payload.jurisdiction,
            qualification_ref=payload.qualification_ref,
            expires_at=payload.expires_at,
            granted_by=granter.id,
        )
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc

    service.audit(
        session,
        "identity.role.grant",
        f"{user_id} granted {grant.role}"
        + (f" for {grant.jurisdiction}" if grant.jurisdiction else "")
        + f", by {granter.id}",
    )
    session.commit()
    return {
        "id": grant.id,
        "user_id": grant.user_id,
        "role": grant.role,
        "jurisdiction": grant.jurisdiction,
        "granted_by": grant.granted_by,
        "granted_at": grant.granted_at.isoformat(),
        "expires_at": grant.expires_at.isoformat() if grant.expires_at else None,
    }


@app.post("/admin/roles/{grant_id}/revoke")
def revoke_role(
    grant_id: str,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Take a role away, and say who did.

    The row is deleted rather than flagged, which is what `access_review.py`
    already assumes and what `roles_for` reads. The audit event is the record
    that it happened — `user_roles` is not append-only, and making it so would
    mean a revocation could never be undone by re-granting.
    """
    revoker = _provisioning_principal(session, quolin_session)

    grant = session.get(UserRole, grant_id)
    if grant is None:
        raise HTTPException(404, f"no grant {grant_id}")

    subject = (
        f"{grant.user_id} lost {grant.role}"
        + (f" for {grant.jurisdiction}" if grant.jurisdiction else "")
        + f", by {revoker.id}"
    )
    session.delete(grant)
    service.audit(session, "identity.role.revoke", subject)
    session.commit()
    return {"status": "ok", "revoked": grant_id}


@app.post("/admin/users/{user_id}/suspend")
def suspend_user(
    user_id: str,
    payload: SuspendUserRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """End somebody's access, now, and say who decided and why.

    FP3-13. `user.status` was checked at sign-in and set by nothing but the
    seed, so the control worked and could not be used. Off-boarding meant
    revoking each grant one at a time — which leaves the trail recording N
    revocations and no statement that a person had left, and leaves any browser
    they had open working until the cookie expires.

    Three things in one act, which is the point of it being one act:

      * the account stops authenticating (`authenticate` already refuses
        anything that is not `active`);
      * every live session of theirs ends, rather than expiring in its own time;
      * one audit event says who decided, about whom, and on what grounds.

    Roles are **not** revoked. A suspended person who returns from leave should
    come back to the access they had, and an access review reading a list of
    grants held by a suspended account is reading something true. What stops
    them is `status`, in one place.

    Admin-scoped, second factor, and a credential presented in the last few
    minutes — the same bar as provisioning, because ending access and granting
    it are the same weight.
    """
    actor = _provisioning_principal(session, quolin_session)

    if user_id == actor.id:
        # Not fastidiousness: an administrator who suspends themselves has
        # locked the door from the outside, and on a firm with one admin that is
        # an outage only we can fix.
        raise HTTPException(
            422,
            "You cannot suspend your own account. Ask another administrator, so "
            "that somebody is still able to undo it.",
        )

    try:
        user = identity.set_status(
            session, user_id=user_id, status=identity.SUSPENDED
        )
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc

    ended = auth.destroy_for(session, user_id=user_id)

    service.audit(
        session,
        "user.suspended",
        f"{user.id} ({user.email}) suspended by {actor.id}: {payload.reason} "
        f"[{ended} session(s) ended]",
    )
    session.commit()
    return {
        "status": "ok",
        "user_id": user.id,
        "account_status": user.status,
        "sessions_ended": ended,
    }


@app.post("/admin/users/{user_id}/reinstate")
def reinstate_user(
    user_id: str,
    payload: SuspendUserRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Put a suspended account back, with the same ceremony.

    A suspension that cannot be undone is one nobody uses for a person on leave,
    and a suspension people avoid using is one that does not happen when
    somebody actually leaves. It takes a reason too: "why is this account live
    again" is the same question in the other direction.
    """
    actor = _provisioning_principal(session, quolin_session)

    try:
        user = identity.set_status(session, user_id=user_id, status=identity.ACTIVE)
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc

    service.audit(
        session,
        "user.reinstated",
        f"{user.id} ({user.email}) reinstated by {actor.id}: {payload.reason}",
    )
    session.commit()
    return {"status": "ok", "user_id": user.id, "account_status": user.status}


@app.get("/tenant/advance-policy")
def get_advance_policy(session: Session = Depends(get_session)):
    """How a new version of a rule pack reaches this firm.

    The explanation travels with the value for the reason `/adoption` gives: a
    screen that said "pinned" and nothing else would leave the fact that
    matters — that rule content will not change under this firm without
    somebody looking — as tribal knowledge.
    """
    tenant = session.get(Tenant, tenancy.current_tenant())
    policy, window = advance.policy_for(tenant)
    return {
        "policy": policy,
        "window_days": window,
        "means": advance.WHAT_EACH_MEANS[policy],
        "policies": {name: advance.WHAT_EACH_MEANS[name] for name in advance.POLICIES},
        "default": advance.DEFAULT_POLICY,
    }


@app.patch("/tenant/advance-policy")
def set_advance_policy(
    payload: AdvancePolicyRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Set it. Q-15: nothing could, and this is a customer's headline lever.

    `advance.policy_for` has read this on every version arrival since §S5 and
    there was no endpoint, no screen and no API behind it — a firm wanting to
    pin their rules had to ask somebody here to run an UPDATE.

    Held to the same bar as moving along the adoption ladder, because it is the
    same kind of act: a decision about whether this firm's determinations can
    change without anybody being asked again. Hence the freshness check — an
    unattended screen must not be able to move it.

    Writes only the two keys it owns. `config` is a shared blob and a handler
    that replaced it wholesale would drop whatever else a firm had set; it is
    also the reason Q-11 moved the unreviewed-content permit out of here.
    """
    row = auth.resolve(session, quolin_session)
    if row is None:
        raise HTTPException(401, "Not signed in.")
    try:
        auth.require_fresh_credential(row, action="Changing the advance policy")
    except auth.ReauthenticationRequired as exc:
        raise HTTPException(
            401, str(exc), headers={"X-Quolin-Reauth": "required"}
        ) from exc

    tenant = session.get(Tenant, tenancy.current_tenant())
    if tenant is None:
        raise HTTPException(404, "No such firm.")

    was_policy, was_window = advance.policy_for(tenant)
    window = payload.window_days if payload.window_days is not None else was_window

    # Rebuilt rather than mutated in place: `config` is JSONB and SQLAlchemy
    # does not see an in-place change to a dict it handed out, so a mutation
    # would be accepted and never written.
    tenant.config = {
        **(tenant.config or {}),
        "advance_policy": payload.policy,
        "uat_window_days": window,
    }

    service.audit(
        session,
        "tenant.advance_policy",
        f"{was_policy} ({was_window}d) → {payload.policy} ({window}d)",
    )
    session.commit()

    return {
        "policy": payload.policy,
        "window_days": window,
        "means": advance.WHAT_EACH_MEANS[payload.policy],
        "was": {"policy": was_policy, "window_days": was_window},
    }


@app.post("/comparison/ingest")
def ingest_comparison(payload: ComparisonIngest, session: Session = Depends(get_session)):
    """Take a customer's extract of what their own system decided.

    The shape is theirs: client, asset, date, and whatever word they use for the
    outcome. Words we do not recognise are kept verbatim and reported as
    unmapped rather than guessed at — a comparison that mapped an unknown code
    to the nearest-sounding outcome would manufacture agreement nobody decided.
    """
    tally = comparison.ingest(
        session,
        [row.model_dump() for row in payload.rows],
        source=payload.source or "upload",
        vocabulary=payload.vocabulary,
    )
    service.audit(
        session,
        "comparison.ingest",
        f"{tally['received']} row(s) from {payload.source or 'upload'}",
    )
    session.commit()
    return tally


@app.get("/comparison")
def get_comparison(
    since: date | None = None,
    until: date | None = None,
    session: Session = Depends(get_session),
):
    """The weekly comparison report: agreement rate, and every divergence."""
    return comparison.compare(session, since=since, until=until)


@app.post("/runs")
def start_run(payload: RunRequest, session: Session = Depends(get_session)):
    """Ask for a book to be re-checked. Evaluates nothing now.

    Planning is cheap and bounded — it enumerates pairs and writes chunks — so
    it happens in the request and the caller gets a run id to watch. The work
    itself is the bulk worker's, for the reason §S7 established about documents
    and §S8 repeats at a hundred times the scale: a request is not where minutes
    of work belong.
    """
    try:
        run = bulk.plan(
            session,
            trigger=payload.trigger or bulk.MANUAL,
            jurisdiction=payload.jurisdiction or "",
            client_ids=payload.client_ids,
            requested_by=_acting_person(session).id,
            dry_run=bool(payload.dry_run),
            note=payload.note or "",
        )
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc

    if run.pairs_total == 0:
        session.rollback()
        raise HTTPException(
            422,
            "That would re-check nothing — no client in this firm's book matches. "
            "A run over zero pairs is a row somebody has to open to find out it "
            "means nothing.",
        )

    service.audit(session, "bulk.plan", f"run:{run.id} ({run.pairs_total} pairs)")
    session.commit()
    return JSONResponse(status_code=202, content=bulk.stats(session, run.id))


@app.get("/runs")
def list_runs(session: Session = Depends(get_session)):
    """Every sweep this firm has had, newest first."""
    rows = session.scalars(select(EvalRun).order_by(EvalRun.id.desc()).limit(100)).all()
    return {"runs": [bulk.stats(session, row.id) for row in rows]}


@app.get("/runs/{run_id}")
def get_run(run_id: int, session: Session = Depends(get_session)):
    try:
        return bulk.stats(session, run_id)
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc


@app.get("/runs/{run_id}/deltas")
def get_run_deltas(run_id: int, session: Session = Depends(get_session)):
    """What changed, worst move first.

    The list a compliance officer evidences to a regulator, and the one a pinned
    tenant reads during their Stage 5 review window before deciding whether to
    take a version.
    """
    run = session.get(EvalRun, run_id)
    if run is None:
        raise HTTPException(404, f"no run {run_id}")
    return {
        "run": bulk.stats(session, run_id),
        "deltas": bulk.deltas(session, run_id, limit=2000),
        "note": (
            "Every determination whose outcome moved, with the rule that moved "
            "it. A rewording or a renumbered rule is not a change here: what a "
            "compliance officer acts on is an outcome."
            + (
                " This run recorded nothing — it reports what the version would "
                "do, not what it did."
                if run.dry_run
                else ""
            )
        ),
    }


@app.get("/artefacts/jobs")
def list_artefact_jobs(status: str | None = None, session: Session = Depends(get_session)):
    """What is outstanding, newest first, with the failures visible.

    Failures are kept rather than deleted: a document somebody asked for and
    never received has to be findable, by them and by whoever is asked why it
    never arrived.
    """
    stmt = select(ArtefactJob).order_by(ArtefactJob.id.desc()).limit(200)
    if status:
        stmt = stmt.where(ArtefactJob.status == status)
    jobs = [artefacts.queue.view(j) for j in session.scalars(stmt)]
    return {"jobs": jobs, "depth": artefacts.queue.depth(session)}


@app.get("/artefacts/jobs/{job_id}")
def get_artefact_job(job_id: int, session: Session = Depends(get_session)):
    job = session.get(ArtefactJob, job_id)
    if job is None:
        raise HTTPException(404, "unknown job")
    return artefacts.queue.view(job)


# Declared before `/artefacts/{kind}`, and that ordering is load-bearing:
# FastAPI matches in declaration order, so with the parameterised route first
# every call to `/artefacts/batch` arrives as a request to render an artefact of
# kind "batch". It answers 422 about a missing `decision_id`, which is a long
# way from the cause.
@app.post("/artefacts/{kind}")
def create_artefact(
    kind: str, payload: ArtefactRequest, session: Session = Depends(get_session)
):
    """One document, now, for a person who is waiting for it.

    Which kinds exist is pack content: a kind is renderable because a pack
    declares a template for it, and for no other reason. §S7 puts it plainly —
    return formats are pack content, engineering is the pipeline — so a regime
    that adds a statutory document does not need a deploy, and the list here
    does not need maintaining against four packs.
    """
    try:
        artefact = artefacts.render(session, kind=kind, decision_id=payload.decision_id)
    except KeyError as exc:
        # The renderer refuses a kind the governing pack declares no template
        # for, and says which pack. That is a better 404 than a list of kinds
        # maintained here, which would go stale the first time a pack changed.
        raise HTTPException(404, str(exc)) from exc

    service.audit(session, "artefact.generate", f"artefact:{artefact.id}")
    session.commit()
    return {
        "id": artefact.id,
        "kind": artefact.kind,
        "title": artefact.title,
        "template_version": artefact.template_version,
        "download_url": f"/artefacts/{artefact.id}/pdf",
        "created_at": artefact.created_at.isoformat(),
    }


@app.get("/artefacts/{artefact_id}/pdf")
def download_artefact(artefact_id: int, session: Session = Depends(get_session)):
    artefact = session.get(Artefact, artefact_id)
    if artefact is None:
        raise HTTPException(404, "unknown artefact")
    # Served from memory rather than from the path, because the path holds
    # ciphertext. Decrypting to a temporary file first would put a readable
    # client document on disk to save copying a few hundred kilobytes.
    pdf = artefacts.read_pdf(artefact.pdf_ref)
    if pdf is None:
        raise HTTPException(410, "artefact file missing; regenerate")

    # The document itself. FP3-14: recorded *before* it is served, so a download
    # that is interrupted still leaves the record that it was requested.
    service.audit_read(
        session,
        resource="artefact",
        subject=f"artefact:{artefact_id} kind:{artefact.kind} ref:{artefact.ref_id}",
        support=_under_support_grant(session),
    )
    session.commit()

    return Response(
        pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{artefact.pdf_ref}"'},
    )


@app.get("/reports/periods")
def list_report_periods(
    scenario: str | None = None,
    jurisdiction: str = service.DEFAULT_JURISDICTION,
    session: Session = Depends(get_session),
):
    """Periods that contain determinations, so the UI cannot offer an empty one.

    Scoped by regulator as well as by book. A return is filed with one regulator,
    so a dropdown offering a period that is only populated under another one
    leads straight to an empty document.
    """
    return reports.available_periods(session, scenario, jurisdiction.upper())


@app.get("/reports/preview")
def preview_report(
    kind: str = Query(pattern="^(regulatory_return|override_report)$"),
    period: str = Query(pattern=r"^\d{4}-(0[1-9]|1[0-2]|Q[1-4])$"),
    jurisdiction: str = service.DEFAULT_JURISDICTION,
    scenario: str | None = None,
    session: Session = Depends(get_session)):
    """The exact figures the PDF will contain, before anyone commits to one."""
    return _aggregate(session, kind, period, jurisdiction.upper(), scenario)


def _aggregate(session: Session, kind: str, period: str, jurisdiction: str, scenario: str | None):
    builder = (
        reports.distribution_return
        if kind == "regulatory_return"
        else reports.override_register
    )
    try:
        return builder(session, period=period, jurisdiction=jurisdiction, scenario=scenario)
    except reports.PeriodError as exc:
        raise HTTPException(422, str(exc)) from exc
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc


def _generate_period_report(
    session: Session, kind: str, payload: PeriodReportRequest
) -> dict:
    jurisdiction = payload.jurisdiction.upper()
    report = _aggregate(session, kind, payload.period, jurisdiction, payload.scenario)
    try:
        artefact = artefacts.render_period(
            session, kind=kind, report=report, jurisdiction=jurisdiction
        )
    except (KeyError, LookupError) as exc:
        raise HTTPException(404, str(exc)) from exc

    service.audit(session, f"{kind}.generate", f"artefact:{artefact.id}")
    session.commit()
    return {
        "id": artefact.id,
        "kind": artefact.kind,
        "title": artefact.title,
        "period": payload.period,
        "template_version": artefact.template_version,
        "download_url": f"/artefacts/{artefact.id}/pdf",
        "created_at": artefact.created_at.isoformat(),
    }


@app.post("/returns")
def create_return(payload: PeriodReportRequest, session: Session = Depends(get_session)):
    return _generate_period_report(session, "regulatory_return", payload)


@app.post("/reports/overrides")
def create_override_report(
    payload: PeriodReportRequest, session: Session = Depends(get_session)
):
    return _generate_period_report(session, "override_report", payload)


@app.get("/audit/export")
def export_audit(
    start: date | None = None,
    end: date | None = None,
    session: Session = Depends(get_session),
):
    """The audit trail as CSV.

    `audit_events` is append-only — Postgres refuses UPDATE and DELETE on it —
    but it is not hash-chained the way `decisions` is. The header below says so
    on the response itself; the reporting screen repeats it in words, because a
    downloaded file loses its headers and a reader should not have to infer the
    guarantee from the absence of one.
    """
    rows = reports.audit_rows(session, start=start, end=end)

    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=reports.AUDIT_COLUMNS, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    return Response(
        content=buffer.getvalue(),
        media_type="text/csv",
        headers={
            "Content-Disposition": f'attachment; filename="quolin_audit_{stamp}.csv"',
            "X-Quolin-Integrity": "append-only-trigger; not-hash-chained",
            "X-Quolin-Rows": str(len(rows)),
        },
    )


@app.get("/audit/certificate")
def audit_certificate(session: Session = Depends(get_session)):
    """The chain, verified now, in a form somebody can put beside the export.

    §S7 asks for an "audit export with chain-verification certificate", and the
    two halves say different things — which is the point of having both.

    The CSV is `audit_events`: append-only at the database level and *not*
    hash-chained. This is `decisions`: every link recomputed from the tenant's
    own anchor, right now. A reader holding both knows exactly which guarantee
    covers which file, instead of inferring one from the other.

    **Recomputed on request, never cached.** A stored "verified" is a claim
    about a moment that has passed, and the moment it goes stale is precisely
    the moment it matters. The cost is a walk of the chain, which is what the
    claim is worth.

    **A broken chain is a 200 with `verified: false`.** Not an error: the
    endpoint worked, and the answer is the finding. An error status would put
    the most important result this system can produce into a client's retry
    logic.
    """
    result = evidence.verify_chain(session)
    tenant = session.get(Tenant, tenancy.current_tenant())
    checked_at = datetime.now(timezone.utc)

    verdict = "verified" if result["verified"] else "BROKEN"
    service.audit(
        session,
        "audit.certificate",
        f"chain {verdict} over {result['checked']} decisions",
    )
    session.commit()

    return {
        **result,
        "tenant_name": tenant.name if tenant is not None else "",
        "checked_at": checked_at.isoformat(),
        "covers": "decisions",
        "statement": (
            "Every determination recorded for this tenant was rehashed from the "
            "tenant's own anchor and compared with the hash stored beside it. "
            "This certificate covers the decision chain. The audit export "
            "(/audit/export) covers `audit_events`, which is append-only at the "
            "database level and is not hash-chained — the two files make "
            "different claims and neither implies the other."
        ),
    }


@app.get("/integrations")
def list_integrations(session: Session = Depends(get_session)):
    """What is real, what is standing in, and what each mock costs a reader.

    Computed from live counts rather than a hardcoded list, so a label cannot
    quietly stop being true.
    """
    return integrations.summary(session)


@app.post("/import/clients")
def import_clients(
    payload: ClientImportRequest, session: Session = Depends(get_session)
):
    """Validate a client-book CSV, and write it only if every row is good.

    All-or-nothing on purpose. A partial import leaves a book half in one state
    and half in another, and nobody can describe the result afterwards — least
    of all the person who has to explain it to a regulator. Either the file is
    good and all of it lands, or none of it does and every rejected row is
    named with its row number and column.

    `commit` defaults to False, so this same endpoint is the preview.
    """
    try:
        report = importer.parse(
            payload.csv_text, today=business_time.business_today(session)
        )
    except importer.ImportError_ as exc:
        raise HTTPException(422, str(exc)) from exc

    # Existence is decided here rather than in the parser: the parser is pure
    # and testable without a database, and this is the only layer that can see
    # what is already stored.
    for row in report.valid:
        row.exists = session.get(Client, row.values["id"]) is not None

    if not payload.commit or not report.ok:
        return report.as_dict(committed=False)

    # Which rows actually move a fact the engine reads. Collected as the rows
    # are written, because that is the only moment the previous values still
    # exist — the same reasoning, and the same predicate, as the audit diff on
    # the `/v1` upsert path.
    moved: list[str] = []

    try:
        for row in report.valid:
            values = row.values
            existing = session.get(Client, values["id"])
            if existing is None:
                session.add(Client(**values))
            else:
                if v1._fact_diff(existing, values):
                    moved.append(values["id"])
                for column, value in values.items():
                    setattr(existing, column, value)
        session.flush()
    except IntegrityError as exc:
        # F5, the second upsert path. Same finding, same answer: `clients.id` is
        # platform-wide, so a row naming an id another firm holds is invisible
        # here and collides on insert. The refusal names no constraint, no table
        # and no tenant — see `v1.CLIENT_REFUSED`, which this shares so the two
        # paths cannot drift into telling a caller different amounts.
        session.rollback()
        raise HTTPException(409, v1.CLIENT_REFUSED) from exc

    service.audit(
        session,
        action="import.clients",
        subject=(
            f"{len(report.valid)} rows "
            f"({sum(1 for r in report.valid if not r.exists)} new, "
            f"{sum(1 for r in report.valid if r.exists)} updated, "
            f"{len(moved)} with decision-relevant changes)"
        ),
    )

    if moved:
        # §S8's profile-change trigger, from the other write path.
        #
        # One run over the changed subset, not one per row: a firm re-loading a
        # book of nine thousand where forty moved wants a single re-check of
        # forty. `on_profiles_changed` is `on_profile_change` with a list, so
        # both paths mean the same thing rather than two call sites that drift.
        #
        # After the import has been written and before the commit, so the run
        # and the rows it re-checks land in one transaction. A run planned for
        # rows a later failure rolled back would be a re-check of a state that
        # never existed — and the endpoint's whole promise is all-or-nothing.
        bulk.on_profiles_changed(
            session,
            client_ids=moved,
            requested_by=tenancy.current_user_or_none() or "",
            note=f"{len(moved)} client(s) changed in an import",
        )

    session.commit()
    return report.as_dict(committed=True)


@app.get("/packs")
def list_packs(session: Session = Depends(get_session)):
    """Every regime on the shelf, with the version in force today.

    The pack screen used to open on one jurisdiction because there was only one.
    A shelf that shows four is the architectural claim made visible: the same
    engine, four sets of content, and the decisions counted per regime so nobody
    has to take "it supports four jurisdictions" on trust.
    """
    today = business_time.business_today(session)
    governed: dict[str | None, int] = dict(
        cast(
            "list[tuple[str | None, int]]",
            session.execute(
                select(Decision.pack_id, func.count(Decision.id)).group_by(Decision.pack_id)
            ).all(),
        )
    )
    # Decisions written before packs recorded their regime are all from the
    # single-jurisdiction era, which is what the default means here.
    governed[service.DEFAULT_JURISDICTION] = governed.get(
        service.DEFAULT_JURISDICTION, 0
    ) + governed.pop(None, 0)

    # Governing and considering are different jobs, and a shelf that reported
    # only the first would say a pack that blocked a trade had touched nothing.
    # A regime reached by residency never governs and is not thereby idle.
    # Filtered in Python rather than in SQL: a JSON column holding the value
    # `null` is not SQL NULL, and `IS NOT NULL` lets those rows through.
    considered: Counter[str | None] = Counter(governed)
    for row in session.scalars(select(Decision)):
        for code in (row.resolution or {}).get("outcome_by_jurisdiction", {}):
            if code != (row.pack_id or service.DEFAULT_JURISDICTION):
                considered[code] += 1

    shelf = []
    for code in packs_repo.jurisdictions(session):
        rows = packs_repo.all_versions(session, code)
        latest = packs_repo.by_version(session, code, rows[-1].version)
        try:
            in_force = packs_repo.describe(session, code, today)
        except LookupError:
            # Staged for a future date and not yet in force. Listed anyway,
            # described by its latest version: a pack nobody can see is a pack
            # nobody reviews.
            in_force = None
        described = in_force or latest
        shelf.append(
            {
                "jurisdiction": code,
                # Named from content. A screen that mapped a code to a
                # regulator's name would hold jurisdiction knowledge outside the
                # pack, which is invariant 1 broken in a different language.
                "name": described.jurisdiction_name,
                "regulator": described.regulator,
                "current_version": in_force.version if in_force else None,
                "versions": len(rows),
                "content_status": described.content_status,
                "covers_states": described.covers_states,
                "signed_by": described.signed_by,
                "decisions_governed": governed.get(code, 0),
                "decisions_considered": considered.get(code, 0),
            }
        )
    return shelf


@app.get("/packs/{jurisdiction}")
def get_packs(jurisdiction: str, session: Session = Depends(get_session)):
    rows = packs_repo.all_versions(session, jurisdiction.upper())
    if not rows:
        raise HTTPException(404, "unknown jurisdiction pack")
    today = business_time.business_today(session)
    current = packs_repo.describe(session, jurisdiction.upper(), today)

    diffs = [
        packs_repo.diff(rows[i - 1].body, rows[i].body) for i in range(1, len(rows))
    ]
    return {
        "jurisdiction": jurisdiction.upper(),
        "name": current.jurisdiction_name,
        "regulator": current.regulator,
        "current_version": current.version,
        "content_status": current.content_status,
        "covers_states": current.covers_states,
        "versions": [
            {
                "version": r.version,
                "effective_from": r.effective_from.isoformat(),
                "effective_to": r.effective_to.isoformat() if r.effective_to else None,
                "signed_by": r.signed_by,
                "signed_at": r.signed_at,
                # Per version, not per jurisdiction: content is reviewed one
                # version at a time, and a screen showing v1's badge on v2 would
                # be making a claim about a file nobody has read.
                "content_status": r.body.get("content_status", ""),
                "notes": r.body.get("notes", ""),
                "rule_count": len(r.body["rules"]),
                "thresholds": r.body["thresholds"],
                "rules": [
                    {
                        "rule_id": rule["rule_id"],
                        "title": rule.get("title", ""),
                        "on_fail": rule["on_fail"],
                        "reason_code": rule["reason_code"],
                    }
                    for rule in r.body["rules"]
                ],
            }
            for r in rows
        ],
        "diffs": diffs,
    }


@app.get("/queue")
def queue(scenario: str | None = None, session: Session = Depends(get_session)):
    stmt = select(Decision).where(Decision.outcome == "REFER")
    if scenario:
        stmt = stmt.join(Client, Client.id == Decision.client_id).where(
            Client.scenario == scenario
        )
    refers = session.scalars(stmt.order_by(Decision.id.desc()).limit(50)).all()
    overridden = {
        o.decision_id: o
        for o in session.scalars(select(Override).order_by(Override.id.desc()))
    }
    return [
        {
            "decision_id": d.id,
            "client_id": d.client_id,
            "client_name": d.snapshot["client"]["name"],
            "asset_id": d.asset_id,
            "as_of": d.as_of.isoformat(),
            "pack_version": d.pack_version,
            "reason_codes": [
                r["reason_code"] for r in d.rule_results["results"] if not r["passed"]
            ],
            "resolved": d.id in overridden,
            "approver": overridden[d.id].approver if d.id in overridden else None,
        }
        for d in refers
    ]


@app.get("/dashboard")
def dashboard(scenario: str | None = None, session: Session = Depends(get_session)):
    """The overview screen, in aggregate queries rather than in Python.

    §S12 rewrote this. It used to load every determination the firm had ever
    made — `select(Decision).order_by(id.desc()).all()` — and then count, filter
    and slice the list in memory, alongside every override and a full walk of
    the hash chain. Against two thousand determinations that was 197ms of
    loading plus 268ms of hashing; against a real book it is seconds, and it
    grows for as long as the customer stays. A screen that gets slower every day
    it is used is a screen that eventually stops being opened.

    Every figure below is now one indexed aggregate, and the chain check is
    bounded and says what it checked. The numbers are the same numbers.
    """
    today = business_time.business_today(session)
    month_start = today.replace(day=1)

    def scoped(stmt):
        """Narrow to one scenario, when the screen is filtered to one."""
        if not scenario:
            return stmt
        return stmt.join(Client, Client.id == Decision.client_id).where(
            Client.scenario == scenario
        )

    # One grouped count instead of three passes over every row in memory.
    by_outcome = {
        outcome: count
        for outcome, count in session.execute(
            scoped(select(Decision.outcome, func.count(Decision.id))).group_by(
                Decision.outcome
            )
        ).all()
    }

    # `func.date` rather than a Python-side `.date()` comparison, matching the
    # overrides query below. `time` in this module is the stdlib clock, not
    # `datetime.time` — a detail that cost a mypy error and is worth not
    # re-learning.
    decisions_today = session.scalar(
        scoped(select(func.count(Decision.id))).where(
            func.date(Decision.created_at) >= today - timedelta(days=1)
        )
    )

    overrides_this_month = session.scalar(
        select(func.count(Override.id)).where(func.date(Override.created_at) >= month_start)
    )

    # "REFER, and nobody has resolved it" — as a NOT EXISTS rather than by
    # loading every override into a set. The set was fine at forty overrides and
    # is a second table scan at forty thousand.
    unresolved = ~select(Override.id).where(Override.decision_id == Decision.id).exists()
    refers_pending = session.scalar(
        scoped(select(func.count(Decision.id)))
        .where(Decision.outcome == "REFER")
        .where(unresolved)
    )

    # The queue the screen actually shows. Twenty rows, ordered by the database,
    # rather than every REFER the firm has ever made sliced down to twenty after
    # they were all decrypted.
    pending_rows = session.scalars(
        scoped(select(Decision))
        .where(Decision.outcome == "REFER")
        .where(unresolved)
        .order_by(Decision.id.desc())
        .limit(20)
    ).all()

    return {
        "scenario": scenario,
        "decisions_today": decisions_today or 0,
        "decisions_total": sum(by_outcome.values()),
        "refers_pending": refers_pending or 0,
        "overrides_this_month": overrides_this_month or 0,
        "blocks_total": by_outcome.get("BLOCK", 0),
        "allows_total": by_outcome.get("ALLOW", 0),
        # Bounded, and labelled with what it covered. The full walk runs
        # nightly and in the health checks; a screen re-hashing a customer's
        # entire history on every page load was the most expensive thing on it
        # and the least likely to find anything the nightly run had not.
        "chain": evidence.verify_tail(session),
        "pending": [
            {
                "decision_id": d.id,
                "client_id": d.client_id,
                "client_name": d.snapshot["client"]["name"],
                "asset_id": d.asset_id,
                "as_of": d.as_of.isoformat(),
                "reason_codes": [
                    r["reason_code"] for r in d.rule_results["results"] if not r["passed"]
                ],
            }
            for d in pending_rows
        ],
    }


@app.post("/currency/sources/{source_id}/verify")
def verify_source(
    source_id: str,
    payload: SourceVerificationRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Record that a person checked a source nothing can poll.

    §S13 declared some publications `MANUAL` and left this unbuilt, which meant
    the only way to attest to one was editing seed data — so a real firm's
    manual sources would drift to STALE with no way to say otherwise.

    Held to the same bar as signing rule content, and for the same reason. This
    is somebody putting their name to a claim about what a regulator had
    published on a date, which a compliance officer may later rely on:

    - **A signatory for *this* jurisdiction.** Competence to attest for one
      regime is not competence to attest for another, and the route table cannot
      see which regime a source belongs to.
    - **A second factor.** Asserted here as well as at the door, because a
      middleware allow-list is a list somebody adds to.
    - **Not a fresh-credential check.** Signing rule content demands one because
      it puts content into force; this records an observation. Demanding a
      password re-entry for every source check is how a control becomes
      something people batch up and do carelessly on a Friday.
    """
    row = auth.resolve(session, quolin_session)
    if row is None or row.user_id is None:
        raise HTTPException(401, "Not signed in.")

    source = session.get(WatchSource, source_id)
    if source is None:
        raise HTTPException(404, f"no watch source {source_id!r}")

    grants = identity.roles_for(session, row.user_id)
    covered = {g.jurisdiction for g in grants if g.role == "pack_signatory"}
    if source.jurisdiction not in covered:
        raise HTTPException(
            403,
            f"You are not a signatory for {source.jurisdiction}. "
            f"Your signatory grants cover: {', '.join(sorted(covered)) or 'nothing'}.",
        )

    try:
        mfa.assert_second_factor(
            session, user_id=row.user_id, mfa_satisfied=bool(row.mfa_satisfied)
        )
    except mfa.MfaRequired as exc:
        raise HTTPException(403, str(exc)) from exc

    try:
        recorded = watch.sources.verify_manually(
            session,
            source_id,
            verified_on=payload.verified_on,
            verified_by=row.user_id,
            note=payload.note or "",
            attachment_ref=payload.attachment_ref or "",
        )
    except watch.sources.NotManual as exc:
        raise HTTPException(409, str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc

    service.audit(
        session,
        "watch.source.verified",
        f"{source_id} checked on {payload.verified_on.isoformat()}",
    )
    session.commit()
    return {
        "id": recorded.id,
        "source_id": source_id,
        "verified_on": recorded.verified_on.isoformat(),
        "verified_by": _acting_person(session).display_name,
        "freshness": watch.sources.freshness(
            source.last_checked_at,
            source.cadence_days,
            datetime.now(timezone.utc),
            polling_status=source.polling_status,
        ),
    }


@app.get("/webhooks/deliveries")
def list_deliveries(
    status: str | None = None,
    limit: int = 100,
    session: Session = Depends(get_session),
):
    """What we sent this firm's systems, and what came back.

    Readable in the console rather than only in the database. §S9's
    webhook-storm runbook tells an operator to "tell the customer their endpoint
    has been failing, then replay the dead deliveries once they have fixed it" —
    and until now both halves needed a psql prompt, which is how an operator
    action at 3am ends up unrecorded.

    The payload is not returned. It carries whatever the event carried, which
    for a determination is a client and an outcome, and a delivery list is a
    screen an operator scans rather than a place to read a customer's book.
    """
    stmt = select(WebhookDelivery).order_by(WebhookDelivery.id.desc())
    if status:
        if status not in webhooks.STATUSES:
            raise HTTPException(
                422,
                f"{status!r} is not a delivery status. "
                f"Known: {', '.join(webhooks.STATUSES)}.",
            )
        stmt = stmt.where(WebhookDelivery.status == status)

    rows = session.scalars(stmt.limit(min(limit, 500))).all()
    return {
        "deliveries": [
            {
                "id": row.id,
                "endpoint_id": row.endpoint_id,
                "event": row.event,
                "subject": row.subject,
                "status": row.status,
                "attempts": row.attempts,
                "last_status_code": row.last_status_code,
                "last_error": row.last_error,
                "created_at": row.created_at.isoformat(),
                "delivered_at": (
                    row.delivered_at.isoformat() if row.delivered_at else None
                ),
                "next_attempt_at": (
                    row.next_attempt_at.isoformat() if row.next_attempt_at else None
                ),
            }
            for row in rows
        ],
        "dead": session.scalar(
            select(func.count(WebhookDelivery.id)).where(
                WebhookDelivery.status == webhooks.DEAD
            )
        )
        or 0,
    }


@app.post("/webhooks/deliveries/{delivery_id}/redeliver")
def redeliver(delivery_id: str, session: Session = Depends(get_session)):
    """Put a dead delivery back on the queue. Audited, because somebody decided.

    The runbook's last step, as an action with a name against it rather than an
    UPDATE somebody runs by hand. It does not send anything now — the worker
    does that — so this stays a request and the retry schedule stays in one
    place.
    """
    delivery = session.get(WebhookDelivery, delivery_id)
    if delivery is None:
        raise HTTPException(404, f"no delivery {delivery_id}")

    try:
        webhooks.revive(session, delivery)
    except ValueError as exc:
        # 409, not 422: the request is well formed and the delivery is real —
        # what is wrong is its state, and the caller's move is to look at it
        # rather than to fix their request.
        raise HTTPException(409, str(exc)) from exc

    service.audit(session, "webhook.redeliver", f"delivery:{delivery.id}")
    session.commit()
    return {
        "id": delivery.id,
        "status": delivery.status,
        "attempts": delivery.attempts,
        "statement": (
            "Queued for the worker to attempt again, with the full backoff. "
            "Nothing has been sent yet."
        ),
    }


@app.get("/evidence/verify")
def verify(session: Session = Depends(get_session)):
    """Both of this firm's chains, walked end to end.

    Determinations and the audit trail are separate chains with separate
    genesis hashes, and both are reported — §S13 closed T3 by chaining the
    trail, and a verifier that checked only half of the evidence would leave
    the same gap with a tick over it.

    The determination result keeps its existing shape, so anything already
    reading this endpoint is unaffected.
    """
    result = dict(evidence.verify_chain(session))
    audit = evidence.verify_audit_chain(session)
    result["audit_chain"] = audit
    # One answer for "is this firm's evidence intact", because that is the
    # question being asked. A caller that wants to know which half failed reads
    # the two blocks.
    result["everything_verified"] = bool(result.get("verified")) and bool(
        audit.get("verified")
    )
    return result


# --- Regulatory currency -----------------------------------------------------
#
# Everything below reads publications and proposes changes. None of it evaluates
# anything. The one route that can alter what the evaluator uses is the sign
# route, and it can only do so because a named person put their name in the body
# of the request.


@app.get("/currency")
def currency(session: Session = Depends(get_session)):
    """Is what this system enforces still current, and how would we know?

    Scoped to the regimes this customer operates in. §S6 asks for the screen to
    gain tenancy, and the reason is that a rollup covering regimes a firm is not
    licensed in is a rollup they learn to ignore: amber because an ESMA feed is
    late, for a firm that has never advised a European client.

    A tenant that has not declared its regimes sees all of them. That is not the
    same as seeing none — a screen reporting perfect currency because it is
    watching nothing is the worst answer available here.
    """
    tenant = session.get(Tenant, tenancy.current_tenant())
    return watch.currency.overview(session, regimes=source_alerts.regimes_for(tenant))


@app.get("/currency/sources/{source_id}/verifications")
def source_verifications(source_id: str, session: Session = Depends(get_session)):
    """Every attestation somebody has recorded against this source.

    FP3-16. `watch.sources.verifications` was written, tested and never reached
    by anything: the attestations were stored and there was no way to read them
    back. A specialist put their name to "I checked this publication on the
    14th", and the only thing anybody could see afterwards was that the source
    was fresh — which is the derived state, not the evidence for it.

    That matters most for exactly the sources this exists for. §S13 declared
    some publications `MANUAL` — behind a login, or a search form nothing can
    poll — so for those the attestation *is* the monitoring, and a currency
    screen showing green with no way to ask who said so is showing an opinion.

    Newest first, and bounded: this is a history to read, not a report to run.
    """
    row = session.get(WatchSource, source_id)
    if row is None:
        raise HTTPException(404, f"unknown source {source_id!r}")

    rows = watch.sources.verifications(session, source_id)
    return {
        "source_id": source_id,
        "name": row.name,
        "jurisdiction": row.jurisdiction,
        "polling_status": row.polling_status,
        "verifications": [
            {
                "id": v.id,
                "verified_on": v.verified_on.isoformat(),
                "verified_by": v.verified_by,
                "note": v.note,
                "attachment_ref": v.attachment_ref,
            }
            for v in rows
        ],
    }


@app.post("/watch/poll")
def poll_sources(session: Session = Depends(get_session)):
    """Check every source that is due and record anything not already seen.

    A live sweep can partly fail — one regulator's site is down while the other
    three answer — and that is a successful poll with recorded failures, not an
    error. The failures come back in the body, and any source that has now
    missed its threshold pages the specialist who owns it.
    """
    try:
        result = watch.poll.poll(session, business_time.platform_today())
    except watch.poll.LiveModeUnavailable as exc:
        # 501, not 500 and not a silent fixture fallback. The mode was asked for
        # and this build cannot honour it; saying so is the whole contract.
        raise HTTPException(501, str(exc)) from exc

    paged = source_alerts.page(session)
    service.audit(
        session,
        action="watch.poll",
        subject=(
            f"{result['sources_checked']} sources in {result['mode']} mode, "
            f"{result['new_events']} new, {result['already_seen']} already seen"
            + (f", {result['sources_failed']} unreachable" if result["sources_failed"] else "")
        ),
    )
    session.commit()
    return {**result, "paged": paged}


@app.get("/watch/alerts")
def watch_alerts(session: Session = Depends(get_session)):
    """Sources that have stopped answering, and who is supposed to be on it.

    Everything in breach, not only what was paged this sweep. An outage somebody
    was told about on Monday is still an outage on Wednesday, and a screen that
    hid it once the alert had been sent would make the quiet look like a fix.
    """
    return {
        "breaches": source_alerts.open_breaches(session),
        "note": (
            "A source in breach has failed its own number of consecutive checks. "
            "Nothing has been checked off: the count clears when the source "
            "answers again, not when somebody reads this."
        ),
    }


@app.get("/watch/events")
def list_watch_events(
    jurisdiction: str | None = None,
    tier: str | None = None,
    status: str | None = None,
    session: Session = Depends(get_session),
):
    """The queue, worst tier first and newest first within a tier.

    Sorted in Python rather than in SQL because the tier order is a property of
    `triage.TIERS` — a reading order the content team owns — and encoding it as
    a CASE expression here would put it in two places that could disagree.
    """
    stmt = select(WatchEvent)
    if jurisdiction:
        stmt = stmt.where(WatchEvent.jurisdiction == jurisdiction)
    if tier:
        stmt = stmt.where(WatchEvent.tier == tier)
    if status:
        stmt = stmt.where(WatchEvent.status == status)
    rows = list(session.scalars(stmt))
    rows.sort(key=lambda e: (watch.triage.sort_key(e.tier), -e.published_at.toordinal(), e.id))

    return {
        "mode": watch.sources.mode(),
        "tiers": [
            {
                "id": t,
                "label": watch.triage.TIER_LABELS[t],
                "explanation": watch.triage.TIER_EXPLANATIONS[t],
            }
            for t in watch.triage.TIERS
        ],
        "events": [
            {
                "id": e.id,
                "source_id": e.source_id,
                "jurisdiction": e.jurisdiction,
                "title": e.title,
                "summary": e.summary,
                "url": e.url,
                "published_at": e.published_at.isoformat(),
                "observed_at": e.observed_at.isoformat() if e.observed_at else None,
                "tier": e.tier,
                "tier_label": watch.triage.TIER_LABELS.get(e.tier, e.tier),
                "matched": e.matched or [],
                "touches": watch.triage.touched_refs(e.matched or []),
                "status": e.status,
                "note": e.note,
            }
            for e in rows
        ],
    }


@app.post("/watch/events/{event_id}/triage")
def triage_event(
    event_id: int, payload: TriageRequest, session: Session = Depends(get_session)
):
    """Move a queue item along.

    `watch_events` is not append-only and not in the hash chain — the chain
    covers determinations, and a triage queue is workflow. Every transition is
    written to `audit_events` instead, which is where "who did what" already
    lives, so the mutability costs no accountability.
    """
    event = session.get(WatchEvent, event_id)
    if event is None:
        raise HTTPException(404, f"no watch event {event_id}")
    before = event.status
    event.status = payload.status
    if payload.note:
        event.note = payload.note
    service.audit(
        session,
        action="watch.triage",
        subject=f"event {event_id} {before} -> {payload.status}",
    )
    session.commit()
    return {"id": event.id, "status": event.status, "note": event.note, "was": before}


@app.post("/watch/drafts")
def create_draft(payload: DraftRequest, session: Session = Depends(get_session)):
    """Cut a draft pack version from the one in force. Inert until signed.

    The author is the person holding the session, read the same way the
    signatory is and for the same reason: an authorship you can type somebody
    else's name into is not one anybody can be asked about. It is recorded on
    the row rather than left to the transition log, because §3.2's separation is
    a rule about this draft and a rule enforced against a log is a rule enforced
    against something a query has to reconstruct.
    """
    try:
        draft = watch.drafts.create(
            session,
            jurisdiction=payload.jurisdiction,
            on=business_time.platform_today(),
            effective_from=payload.effective_from,
            title=payload.title,
            rationale=payload.rationale,
            author=_acting_person(session).display_name,
            threshold_changes=payload.threshold_changes,
            event_ids=payload.event_ids,
        )
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc
    except KeyError as exc:
        raise HTTPException(422, str(exc.args[0])) from exc

    service.audit(
        session,
        action="watch.draft.create",
        subject=(
            f"{draft.jurisdiction} v{draft.base_version} -> v{draft.proposed_version}, "
            f"effective {draft.effective_from.isoformat()}, unsigned, "
            f"drafted by {draft.created_by_user_id}"
        ),
    )
    session.commit()
    return watch.drafts.view(draft, today=business_time.platform_today()) | {
        "delta": watch.drafts.delta(session, draft)
    }


@app.get("/watch/drafts")
def list_drafts(session: Session = Depends(get_session)):
    rows = session.scalars(select(PackDraft).order_by(PackDraft.id.desc())).all()
    today = business_time.platform_today()
    return {
        "statuses": list(watch.drafts.STATUSES),
        "drafts": [watch.drafts.view(d, today=today) for d in rows],
    }


@app.get("/watch/drafts/{draft_id}")
def get_draft(draft_id: int, session: Session = Depends(get_session)):
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise HTTPException(404, f"no draft {draft_id}")
    events = (
        list(session.scalars(select(WatchEvent).where(WatchEvent.id.in_(draft.event_ids))))
        if draft.event_ids
        else []
    )
    return watch.drafts.view(draft, today=business_time.platform_today()) | {
        "delta": watch.drafts.delta(session, draft),
        "body": draft.body,
        "events": [
            {
                "id": e.id,
                "title": e.title,
                "url": e.url,
                "published_at": e.published_at.isoformat(),
                "tier": e.tier,
                "jurisdiction": e.jurisdiction,
            }
            for e in events
        ],
    }


@app.get("/advances")
def list_advances(session: Session = Depends(get_session)):
    """Pack versions staged for this tenant, and how long they have.

    The customer-facing half of "how do you control vendor changes?". A pinned
    firm sees what is waiting and how long is left; an auto firm sees an empty
    list and the policy that explains why, which is a different answer from
    "nothing has changed" and worth being able to tell apart.
    """
    tenant = session.get(Tenant, tenancy.configured_tenant())
    policy, window = advance.policy_for(tenant)
    return {
        "policy": policy,
        "uat_window_days": window,
        "pending": advance.pending(session),
    }


@app.post("/advances/{advance_id}/take")
def take_advance(
    advance_id: str, payload: AdvanceDecision, session: Session = Depends(get_session)
):
    """A pinned tenant taking a version they have checked."""
    try:
        row = advance.advance(
            session,
            advance_id,
            actor=_acting_person(session).id,
            note=payload.note,
        )
    except advance.AdvanceError as exc:
        raise HTTPException(409, str(exc)) from exc

    service.audit(
        session,
        "pack.advance.taken",
        f"{row.jurisdiction} v{row.pack_version}",
    )
    session.commit()
    return {"id": row.id, "status": row.status, "advanced_at": row.advanced_at}


@app.post("/advances/{advance_id}/decline")
def decline_advance(
    advance_id: str, payload: AdvanceDecision, session: Session = Depends(get_session)
):
    """A pinned tenant that has looked and will not take this version.

    Not a fork. There is one pack; a firm that will not take a version stays on
    what they have and has a conversation to have. The note is required because
    it is the thing that gets escalated.
    """
    try:
        row = advance.decline(
            session,
            advance_id,
            actor=_acting_person(session).id,
            note=payload.note,
        )
    except advance.AdvanceError as exc:
        raise HTTPException(422, str(exc)) from exc

    service.audit(
        session,
        "pack.advance.declined",
        f"{row.jurisdiction} v{row.pack_version}: {row.note}",
    )
    session.commit()
    return {"id": row.id, "status": row.status, "note": row.note}


@app.get("/watch/drafts/{draft_id}/preview/{kind}")
def preview_artefact(
    draft_id: int, kind: str, session: Session = Depends(get_session)
):
    """What this draft's templates would produce, as HTML, storing nothing.

    Invariant 8 is why this exists: artefact titles and templates are pack
    content. A specialist changing what a regulator receives should see it
    before they sign, not after it is published.

    Real figures are the sample, not invented ones — the most recent
    determination for a per-decision document, the most recent period with data
    for a return. A preview full of placeholders would show the template's shape
    and hide every question worth asking about it.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise HTTPException(404, f"no draft {draft_id}")

    sample_decision: int | None = None
    report: dict | None = None

    if artefacts.renderer.scope_of(kind, EnginePack.from_body(draft.body)) == (
        artefacts.renderer.PERIOD_SCOPE
    ):
        periods = reports.available_periods(session, jurisdiction=draft.jurisdiction)
        if not periods:
            raise HTTPException(
                409,
                f"No determination has been made under {draft.jurisdiction}, so there "
                "is no period to report on. Run one first — a preview with invented "
                "figures would show a document nobody could check.",
            )
        report = _aggregate(
            session, kind, periods[0]["period"], draft.jurisdiction, None
        )
    else:
        decision = session.scalars(
            select(Decision)
            .where(Decision.pack_id == draft.jurisdiction)
            .order_by(Decision.id.desc())
        ).first()
        if decision is None:
            raise HTTPException(
                409,
                f"No determination has been made under {draft.jurisdiction}, so there "
                "is nothing to preview against. Run one first — a preview with "
                "invented figures would show a document nobody could check.",
            )
        sample_decision = decision.id

    try:
        html = artefacts.preview(
            session,
            body=draft.body,
            kind=kind,
            decision_id=sample_decision,
            report=report,
        )
    except KeyError as exc:
        raise HTTPException(404, str(exc)) from exc

    return Response(content=html, media_type="text/html")


@app.get("/watch/drafts/{draft_id}/history")
def draft_history(draft_id: int, session: Session = Depends(get_session)):
    """Every move this draft has made, and who made it.

    Its own endpoint rather than a field on the draft, because it is read at a
    different moment: the draft is what somebody is working on, and the history
    is what they open when a question is asked about how it got here.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise HTTPException(404, f"no draft {draft_id}")
    return {
        "draft_id": draft_id,
        "status": draft.status,
        "content_hash": draft.content_hash,
        "transitions": watch.lifecycle.history(session, draft_id),
    }


@app.post("/watch/drafts/{draft_id}/validate")
def validate_draft(
    draft_id: int, payload: DraftEdit, session: Session = Depends(get_session)
):
    """Check an edit without saving it. What the workbench calls as you type.

    Deliberately does not write. A specialist trying a threshold to see what it
    would break must not be leaving half-edited content behind them, and a
    validator that had to save first would make "what if" a destructive act.

    The faults come back exactly as the pack validator produces them, because
    they were written for this reader — every one names the rule, the problem
    and where possible the fix.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise HTTPException(404, f"no draft {draft_id}")

    body = _edited(draft, payload)
    try:
        faults = engine_validate(EnginePack.from_body(body))
    except Exception as exc:
        # A body so malformed it will not even load — a rule that is not an
        # object, a missing top-level key. Reported as one fault rather than
        # raised, because the workbench asks this on every keystroke and a 500
        # while somebody is mid-edit is not a useful answer.
        return {"ok": False, "faults": [f"this draft cannot be loaded at all: {exc}"]}

    return {"ok": not faults, "faults": faults, "rules": len(body.get("rules", []))}


def _edited(draft: PackDraft, payload: DraftEdit) -> dict:
    """The draft's body with this edit applied, without touching the row."""
    import copy as _copy

    body = _copy.deepcopy(draft.body)
    for field in ("thresholds", "rules", "reason_codes"):
        value = getattr(payload, field)
        if value is not None:
            body[field] = value
    if payload.notes is not None:
        body["notes"] = payload.notes
    return body


@app.patch("/watch/drafts/{draft_id}")
def edit_draft(
    draft_id: int, payload: DraftEdit, session: Session = Depends(get_session)
):
    """Save an edit. Refused once anybody has signed.

    The refusal is the point. A signature attests to specific bytes, and an edit
    after one would leave a named person's name on content they never saw —
    which is worse than an unsigned pack, because it reads as reviewed. The way
    to change signed content is a superseding draft.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise HTTPException(404, f"no draft {draft_id}")
    if draft.status not in (watch.drafts.DRAFT, watch.drafts.IN_REVIEW):
        raise HTTPException(
            409,
            f"draft {draft_id} is {draft.status!r} and can no longer be edited. A "
            "signature attests to specific content; changing it afterwards would "
            "leave a named person's name on bytes they never saw. Raise a new "
            "draft from the current version instead.",
        )

    body = _edited(draft, payload)
    # F-03, the same hole as in `publish_draft`: a body that will not parse
    # never reached `engine_validate`, so an edit that broke the shape of the
    # pack answered 500 instead of the fault list the workbench renders.
    try:
        parsed = EnginePack.from_body(body)
    except PackError as exc:
        raise HTTPException(
            422,
            {
                "detail": "This edit would not leave a well-formed pack.",
                "faults": [str(exc)],
            },
        ) from exc

    faults = engine_validate(parsed)
    if faults:
        # Saved anyway is the wrong answer and refused-with-a-list is the right
        # one: a specialist mid-edit wants to know what is wrong, and a draft
        # that cannot evaluate must not be one keystroke from being signed.
        raise HTTPException(
            422,
            {
                "detail": f"This edit would not evaluate — {len(faults)} problem(s).",
                "faults": faults,
            },
        )

    changed = body != draft.body
    draft.body = body
    # B1. A review of superseded content is not a review. Migration 0049 made
    # "somebody independent read this" a fact the row holds and `sign` leans on,
    # and this route could move the bytes out from under it: review, edit, sign,
    # and the signature attested to content nobody but its author had seen.
    #
    # Cleared rather than flagged, and cleared here rather than left to `sign`'s
    # hash check alone. The hash is what makes the signature refuse; this is
    # what stops a stale reviewer's name sitting on the draft view, in the
    # workbench and in the table, reading as a review that happened.
    forgotten = changed and watch.drafts.invalidate_second_review(draft)
    service.audit(
        session,
        "watch.draft.edit",
        f"draft {draft_id}"
        + (
            "; the independent second review was cleared, because it was of the "
            "previous content"
            if forgotten
            else ""
        ),
    )
    session.commit()
    return watch.drafts.view(draft, today=business_time.platform_today()) | {"body": draft.body}


@app.post("/watch/drafts/{draft_id}/submit")
def submit_draft(draft_id: int, session: Session = Depends(get_session)):
    """Put a draft up for a signatory to look at.

    A state rather than a flag, because "how long has this been sitting with us"
    is a question a firm asks about its own backlog — and the clock a signatory
    is waiting on starts here rather than when the draft was first written.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise HTTPException(404, f"no draft {draft_id}")
    try:
        watch.lifecycle.move(
            session, draft, watch.drafts.IN_REVIEW, note="submitted for review"
        )
    except watch.drafts.IllegalTransition as exc:
        raise HTTPException(409, str(exc)) from exc

    draft.submitted_at = datetime.now(timezone.utc)
    draft.submitted_by = _acting_person(session).id
    service.audit(session, "watch.draft.submit", f"draft {draft_id}")
    session.commit()
    return watch.drafts.view(draft, today=business_time.platform_today())


@app.post("/watch/drafts/{draft_id}/second-review")
def second_review_draft(
    draft_id: int,
    payload: SecondReviewRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Record that somebody other than the author has read this draft.

    What lets a firm's only specialist for a regime sign content they wrote. The
    alternative to having this route is not a stricter rule — it is a firm that
    cannot change its own rules, which in practice means the specialist writes
    the draft and a colleague signs it having read nothing. That is the same
    single-reader review with a second name on it, and it is worse, because it
    reads as compliant.

    Held to the same bar as the signature it stands in for. The reviewer is the
    person holding the session; their `pack_signatory` grant must name *this
    draft's* jurisdiction; a second factor must have been passed; and a
    credential must have been presented in the last few minutes, because an
    unattended screen must not be able to supply the independence that lets
    somebody else's signature through.
    """
    row = auth.resolve(session, quolin_session)
    if row is None or row.user_id is None:
        raise HTTPException(401, "Not signed in.")

    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise HTTPException(404, f"no draft {draft_id}")

    try:
        mfa.assert_second_factor(
            session, user_id=row.user_id, mfa_satisfied=bool(row.mfa_satisfied)
        )
    except mfa.MfaRequired as exc:
        raise HTTPException(403, str(exc)) from exc

    try:
        auth.require_fresh_credential(row, action="Recording an independent review")
    except auth.ReauthenticationRequired as exc:
        raise HTTPException(401, str(exc), headers={"X-Quolin-Reauth": "required"}) from exc

    try:
        reviewed = watch.drafts.record_second_review(
            session,
            draft_id,
            reviewer_name=_acting_person(session).display_name,
            # F1. What the caller says it read, not what this request finds on
            # the row. The two are the same only when nothing moved while the
            # draft was being read, and the whole of F1 is that they were
            # assumed to be.
            reviewed_content_hash=payload.reviewed_content_hash,
            note=payload.note,
        )
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc
    # F1. 409 rather than 409-by-way-of-ValueError, and rather than 403: the
    # reviewer's grant is right and the door was the right door. What is wrong
    # is that the draft moved underneath them, which is a fact about the draft
    # and not about them — and a 403 would send a reviewer to an administrator
    # to fix a grant that is already correct.
    except watch.drafts.ReviewedBytesMoved as exc:
        raise HTTPException(409, str(exc)) from exc
    except watch.drafts.NotQualifiedToReview as exc:
        # 403 here and 409 on `sign`, and the difference is real. Here the
        # caller's own grant is the thing that is wrong and an administrator can
        # fix it; there, the caller is qualified and the *draft* is the problem.
        raise HTTPException(403, str(exc)) from exc
    except watch.drafts.NotIndependent as exc:
        raise HTTPException(409, str(exc)) from exc
    except (ValueError, watch.drafts.AlreadyResolved) as exc:
        raise HTTPException(409, str(exc)) from exc

    service.audit(
        session,
        "watch.draft.second_review",
        f"draft {draft_id}: {reviewed.jurisdiction} v{reviewed.proposed_version}, "
        f"written by {reviewed.created_by_user_id}",
    )
    session.commit()
    return watch.drafts.view(reviewed, today=business_time.platform_today())


@app.post("/watch/drafts/{draft_id}/sign")
def sign_draft(
    draft_id: int,
    payload: SignRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Record that a named person accepts this content. It does not go live.

    `watch.drafts.publish` refuses any draft whose status is not `signed`, so
    publication is reachable only after a named person has been recorded against
    this content — and publication is a different route held by a different
    role, so it is reachable only by somebody else.

    Three things are checked here that RBAC cannot check. The signatory is the
    person holding the session rather than a name in the request body — a
    signature you can type someone else's name into is not a signature. Their
    `pack_signatory` grant must name *this draft's jurisdiction*, because
    competence to sign for one regime is not competence to sign for another and
    the route table cannot see the draft. And a credential must have been
    presented in the last few minutes, so that an unattended screen cannot sign
    rule content on its owner's behalf.
    """
    row = auth.resolve(session, quolin_session)
    if row is None or row.user_id is None:
        raise HTTPException(401, "Not signed in.")

    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise HTTPException(404, f"no draft {draft_id}")

    grants = identity.roles_for(session, row.user_id)
    covered = {g.jurisdiction for g in grants if g.role == "pack_signatory"}
    if draft.jurisdiction not in covered:
        raise HTTPException(
            403,
            f"You are not a signatory for {draft.jurisdiction}. "
            f"Your signatory grants cover: {', '.join(sorted(covered)) or 'nothing'}.",
        )

    # The engagement behind the name, read from the grant for *this* regime.
    # Recorded on the draft at signature time rather than looked up again at
    # publication, because a grant can be revoked or corrected afterwards and
    # what the pack should say is what was claimed when it was signed.
    #
    # An empty or placeholder reference does not stop the signature — a
    # specialist may perfectly well sign content before their engagement is
    # recorded — it stops the published pack claiming to have been reviewed.
    # See `app/attestation.py`, and Q-02 in docs/spec-changes.md.
    qualification = next(
        (
            g.qualification_ref
            for g in grants
            if g.role == "pack_signatory" and g.jurisdiction == draft.jurisdiction
        ),
        "",
    )

    # Asserted here as well as at the door. The middleware confines an
    # unenrolled privileged session to the enrolment routes; this is what still
    # refuses if that allow-list ever grows to include a path that reaches here.
    try:
        mfa.assert_second_factor(
            session, user_id=row.user_id, mfa_satisfied=bool(row.mfa_satisfied)
        )
    except mfa.MfaRequired as exc:
        raise HTTPException(403, str(exc)) from exc

    try:
        auth.require_fresh_credential(row, action="Signing rule content")
    except auth.ReauthenticationRequired as exc:
        # 401 with a distinguishable code, not 403. The client's move is to ask
        # for the password again and retry, which is a thing it can do — a bare
        # 403 would tell it to give up.
        raise HTTPException(401, str(exc), headers={"X-Quolin-Reauth": "required"}) from exc

    try:
        signed = watch.drafts.sign(
            session,
            draft_id,
            signatory=_acting_person(session).display_name,
            # The bytes the caller says it read, not the bytes this request
            # finds on the row. The two are the same only when nothing moved
            # while the draft was being read, and the auditor showed that they
            # were assumed to be — through this route, with a 200.
            signed_content_hash=payload.signed_content_hash,
            qualification_ref=qualification or "",
            note=payload.note,
        )
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc
    # 409, not 403. The role is right and the door was the right door; what is
    # wrong is this pairing of person and content, which is the same reason
    # `service.SelfApproval` answers 409 on an override. A 403 would tell a
    # signatory their grant is wrong and send them to an administrator.
    except (
        watch.drafts.SelfAuthoredSignature,
        watch.drafts.NotQualifiedToReview,
        # B1. 409 alongside the other two and for the same reason: the caller's
        # grant is right and the door was the right door. What is wrong is that
        # this draft's bytes have moved since the review the author's own
        # signature depends on.
        watch.drafts.ReviewedBytesChanged,
        # And the reading window before it. 409 alongside the rest and for the
        # same reason: the signatory's grant is right, the door was the right
        # door, and what is wrong is that the draft moved underneath them while
        # they read it — a fact about the draft rather than about them.
        watch.drafts.SignedBytesMoved,
    ) as exc:
        raise HTTPException(409, str(exc)) from exc
    except (ValueError, watch.drafts.AlreadyResolved) as exc:
        raise HTTPException(409, str(exc)) from exc
    except IntegrityError as exc:
        # H1, and the same reasoning as on the publish route. A signature is an
        # UPDATE to `pack_drafts`, so a row that predates either constraint is
        # re-checked here too. The Python check above catches the ordinary shape
        # of this first; what reaches here is a row whose stored columns already
        # disagree with a rule added later.
        session.rollback()
        refusal = watch.drafts.refusal_for_a_violating_row(draft_id, exc)
        if refusal is None:
            raise
        raise HTTPException(409, str(refusal)) from exc

    # Signed and awaiting a second pair of eyes. Worth telling a firm about
    # separately from publication: this is the point at which somebody of theirs
    # has to act, and publication is the point at which it is too late to object.
    #
    # FP3-08. This used to call `service._tell_the_customers_systems` directly,
    # which resolves subscribers with an RLS-scoped query inside *this* tenant's
    # transaction. Packs are global and `quolin_operator` is Quolin's own role
    # granted inside a tenant, so the only firm that could ever receive
    # `pack.staged` was whichever tenant the signer happened to be acting in —
    # which is not a customer. §S4's staged-pack notice had never reached
    # anybody.
    #
    # Recorded here, fanned out by the worker that can enumerate firms. The API
    # task cannot: FP3-04 removed its owner connection.
    pack_notices.record(
        session,
        event="pack.staged",
        subject=f"draft {draft_id}",
        jurisdiction=signed.jurisdiction,
        payload={
            "draft_id": draft_id,
            "jurisdiction": signed.jurisdiction,
            "proposed_version": signed.proposed_version,
            "effective_from": signed.effective_from.isoformat(),
            "signed_by": signed.signed_by,
        },
    )
    service.audit(
        session,
        "watch.draft.sign",
        f"draft {draft_id}: {signed.jurisdiction} v{signed.proposed_version}",
    )

    session.commit()
    return watch.drafts.view(signed, today=business_time.platform_today()) | {
        "published_pack_id": None
    }


@app.post("/watch/drafts/{draft_id}/publish")
def publish_draft(
    draft_id: int,
    payload: PublishRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """Publish a signed draft. Refuses an unsigned one with 409, never 500.

    Also refuses one the caller signed themselves. That is a 409 rather than a
    403 for the same reason `NotSigned` is: nothing about this person's
    permissions is wrong — they hold exactly the role this route requires — and
    what is wrong is the state of this particular draft with respect to them.

    And it refuses content that would not evaluate. That check lives here rather
    than inside `watch.drafts` because invariant 6 forbids the drafting service
    from importing the engine at all — so this handler, which already knows about
    both halves, is where the two meet. It is the last moment before a draft
    becomes live rule content, and a pack in force that fails at evaluation
    takes every determination in that regime down with it.

    And, since the census, a body: `published_content_hash` says which bytes this
    publisher read. Pressing publish counts as one of the two approvals a
    publication needs, so the publisher is an attester — and this route, like
    `approve-publication`, took no body at all, which left them in the same
    unbound reading window. See `ApprovedBytesMoved`.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise HTTPException(404, f"no draft {draft_id}")

    # The same two checks signing and overriding already make, and for a larger
    # action than either. Q-05: this endpoint asserted neither, so the second
    # pair of eyes was the only control on the path — and `packs` is global, so
    # one unattended screen puts staged rule content in front of every tenant on
    # the platform.
    #
    # Skipped for a machine principal rather than refused here: a session with
    # no `user_id` belongs to an API client, which holds no second factor to
    # present and no password to have typed recently. Tier 3 item 2 is where
    # machine tokens are refused two-person actions outright.
    acting = auth.resolve(session, quolin_session)
    if acting is not None and acting.user_id is not None:
        try:
            mfa.assert_second_factor(
                session, user_id=acting.user_id, mfa_satisfied=bool(acting.mfa_satisfied)
            )
        except mfa.MfaRequired as exc:
            raise HTTPException(403, str(exc)) from exc
        try:
            auth.require_fresh_credential(acting, action="Publishing rule content")
        except auth.ReauthenticationRequired as exc:
            # 401 with a distinguishable code, not 403, for the reason the
            # signing route gives: the client's move is to ask for the password
            # again and retry, and a bare 403 would tell it to give up.
            raise HTTPException(
                401, str(exc), headers={"X-Quolin-Reauth": "required"}
            ) from exc

    # F-03: `engine_validate` takes a `Pack`, so for a structurally malformed
    # body it never ran — `from_body` raised first, and nothing caught it, so
    # the 422 below was unreachable for exactly the drafts that most needed it.
    # `from_body` is total now and answers `PackError`, which lands here as the
    # same 422 a semantic fault does: in both cases the content is wrong.
    try:
        parsed = EnginePack.from_body(draft.body)
    except PackError as exc:
        raise HTTPException(
            422,
            {
                "detail": "This draft is not a well-formed pack.",
                "faults": [str(exc)],
            },
        ) from exc

    faults = engine_validate(parsed)
    if faults:
        # 422 rather than 409: this is not a question of the draft's state or of
        # who is asking, it is that the content itself is wrong. Every fault is
        # returned, because a specialist fixing one and rediscovering the next on
        # the following attempt is being made to do the work twice.
        raise HTTPException(
            422,
            {
                "detail": f"This draft would not evaluate — {len(faults)} problem(s).",
                "faults": faults,
            },
        )

    try:
        row = watch.drafts.publish(
            session, draft_id, published_content_hash=payload.published_content_hash
        )
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc
    except watch.drafts.NotAPlatformPublisher as exc:
        # 403 rather than 409, and the distinction is the finding. The others in
        # this block are "this draft is in the wrong state for you"; this one is
        # "your permission is wrong" — the account holds `quolin_operator` in
        # some tenant and does not hold platform publication, which is exactly
        # the gap FP3-27 closes.
        raise HTTPException(403, str(exc)) from exc
    except (
        watch.drafts.NotSigned,
        watch.drafts.SelfReview,
        # F4. 409 alongside the other two, and for the same reason: nothing
        # about this person's permissions is wrong, and what is wrong is the
        # state of this particular draft — its bytes have moved since somebody
        # attested to them.
        watch.drafts.SignedBytesChanged,
        # FP3-27. Also a state problem rather than a permission one: the caller
        # may publish, and this draft has not yet been approved by a second
        # person who is not the signer.
        watch.drafts.NeedsASecondApprover,
        # The census. The publisher's own reading window, raised after
        # `SignedBytesChanged` so that a draft edited after its signature
        # reports the tampering rather than a stale screen.
        watch.drafts.ApprovedBytesMoved,
    ) as exc:
        raise HTTPException(409, str(exc)) from exc
    except IntegrityError as exc:
        # H1. Migration 0049's CHECK, and 0050's, are both `NOT VALID` — which
        # enforces them on every write from here and asserts nothing about rows
        # written before they existed. It does *not* mean an old row is never
        # checked: publication updates `pack_drafts`, and an UPDATE re-checks
        # the constraint on the row it touches. So a draft signed under the
        # earlier rules, reaching this endpoint, made Postgres raise correctly
        # and made this route answer 500 with a traceback.
        #
        # A refusal naming the draft and the rule instead. Anything else this
        # transaction can collide on — a duplicate pack version under migration
        # 0031's UNIQUE — is a different incident and is re-raised untouched.
        session.rollback()
        refusal = watch.drafts.refusal_for_a_violating_row(draft_id, exc)
        if refusal is None:
            raise
        raise HTTPException(409, str(refusal)) from exc

    # FP3-17. The review window starts here, on publication, rather than when
    # the version becomes effective.
    #
    # `advance.notice` was reachable only from `advance.sweep`, which selects
    # `effective_from <= today` — so a pinned firm learned a new version existed
    # on the day it was already governing everybody on auto. §S5's "UAT space
    # before advancing" described a window that opened after the thing it is a
    # window for had happened.
    #
    # For the publisher's own tenant here; every other firm is noticed by the
    # worker, which is the same split FP3-08 makes and for the same reason —
    # enumerating firms needs a credential the request path must not hold.
    advance.notice(
        session,
        tenant_id=tenancy.current_tenant(),
        jurisdiction=row.jurisdiction,
        pack_version=row.version,
        effective_from=datetime(
            row.effective_from.year,
            row.effective_from.month,
            row.effective_from.day,
            tzinfo=timezone.utc,
        ),
    )

    # FP3-08, the same as `pack.staged` above and with more at stake: this is
    # the event §S5's "tenants notified" gate is measured from, and it reached
    # exactly one tenant — the publisher's own.
    pack_notices.record(
        session,
        event="pack.published",
        subject=f"{row.jurisdiction} v{row.version}",
        jurisdiction=row.jurisdiction,
        payload={
            "jurisdiction": row.jurisdiction,
            "version": row.version,
            "effective_from": row.effective_from.isoformat(),
            "signed_by": row.signed_by,
            "pack_id": row.id,
        },
    )
    service.audit(
        session,
        action="watch.draft.publish",
        subject=(
            f"{row.jurisdiction} v{row.version} effective "
            f"{row.effective_from.isoformat()} (pack {row.id})"
        ),
    )
    session.commit()
    return {
        "pack_id": row.id,
        "jurisdiction": row.jurisdiction,
        "version": row.version,
        "effective_from": row.effective_from.isoformat(),
        "days_until_effective": (row.effective_from - business_time.platform_today()).days,
        "signed_by": row.signed_by,
    }


@app.post("/watch/drafts/{draft_id}/approve-publication")
def approve_publication(
    draft_id: int,
    payload: PublicationApprovalRequest,
    quolin_session: str | None = Cookie(default=None, alias=auth.COOKIE_NAME),
    session: Session = Depends(get_session),
):
    """One platform publisher agrees that a signed draft should go live. FP3-27.

    Publication needs two of these from two different people, neither of whom
    signed the draft. Pressing publish counts as one, so in practice this is the
    *other* person — requiring the publisher to record a separate approval first
    would be ceremony rather than control.

    Same bar as publishing itself: a second factor and a credential presented in
    the last few minutes. An unattended screen must not be able to supply the
    second pair of eyes, which is the only thing the second pair of eyes is for.

    And, since the census, a body: `approved_content_hash` says which bytes this
    approver read. This route had none at all, which is why it was the third
    instance of F1's defect — the recorder hashed the row when the POST arrived,
    and the approver had no way to say otherwise. See `ApprovedBytesMoved`.
    """
    row = auth.resolve(session, quolin_session)
    if row is None or row.user_id is None:
        raise HTTPException(401, "Not signed in.")

    try:
        mfa.assert_second_factor(
            session, user_id=row.user_id, mfa_satisfied=bool(row.mfa_satisfied)
        )
    except mfa.MfaRequired as exc:
        raise HTTPException(403, str(exc)) from exc

    try:
        auth.require_fresh_credential(row, action="Approving a publication")
    except auth.ReauthenticationRequired as exc:
        raise HTTPException(
            401, str(exc), headers={"X-Quolin-Reauth": "required"}
        ) from exc

    try:
        approval = watch.drafts.approve_publication(
            session,
            draft_id,
            approved_content_hash=payload.approved_content_hash,
            note=payload.note,
        )
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc
    except watch.drafts.NotAPlatformPublisher as exc:
        raise HTTPException(403, str(exc)) from exc
    except (
        watch.drafts.NotSigned,
        watch.drafts.SelfReview,
        # 409 for the reason the other two are: this publisher's grant is right
        # and the door was the right door. What is wrong is that the draft is
        # not the one they read.
        watch.drafts.ApprovedBytesMoved,
    ) as exc:
        raise HTTPException(409, str(exc)) from exc
    except IntegrityError as exc:
        # `uq_one_approval_each`. Two clicks from one publisher is one pair of
        # eyes, and 409 says so rather than silently counting it twice.
        session.rollback()
        raise HTTPException(
            409, "You have already approved this publication."
        ) from exc

    service.audit(
        session,
        action="watch.publication.approved",
        subject=f"draft {draft_id} approved by {approval.approved_by}",
    )
    session.commit()

    recorded = watch.drafts.approvals_for(session, draft_id)
    return {
        "draft_id": draft_id,
        "approvals": [
            {"approved_by": a.approved_by, "approved_at": a.approved_at.isoformat()}
            for a in recorded
        ],
        "required": watch.drafts.REQUIRED_APPROVALS,
        "still_needed": max(
            0, watch.drafts.REQUIRED_APPROVALS - len(recorded) - 1
        ),
    }


@app.post("/watch/drafts/{draft_id}/reject")
def reject_draft(
    draft_id: int, payload: TriageRequest, session: Session = Depends(get_session)
):
    """Decline a draft, and keep it. The record that somebody looked matters."""
    try:
        draft = watch.drafts.reject(
            session,
            draft_id,
            rejected_by=_acting_person(session).display_name,
            note=payload.note,
        )
    except LookupError as exc:
        raise HTTPException(404, str(exc)) from exc
    except watch.drafts.AlreadyResolved as exc:
        raise HTTPException(409, str(exc)) from exc
    service.audit(
        session,
        action="watch.draft.reject",
        subject=f"draft {draft_id}: {draft.jurisdiction} v{draft.proposed_version}",
    )
    session.commit()
    return watch.drafts.view(draft, today=business_time.platform_today())
