"""What a scheduled job does before it has a tenant, and how it says it ran.

Every worker in `scripts/` opens the same way: find the active firms, then bind
each one in turn. Two things about that first step were wrong, and both were
invisible in development.

The first is that enumeration went through a policy on `tenants` that only a
superuser or a BYPASSRLS role walks past. Migration 0029 replaces the attribute
with a grant. Nothing in this module is needed for that — the owner holds the
grant — but the enumeration is gathered here so there is one query rather than
four near-copies, and so the next worker to be written inherits the behaviour
instead of the near-copy.

The second is that finding nothing was a pass. A nightly sweep that enumerates
zero firms on a platform with paying customers has not had a quiet night; it has
failed to see the work, and exiting 0 is how that failure stays invisible for as
long as the deployment lives. So zero is a fault here, stated once, and every
caller reports it the same way.

The heartbeat is the other side of the same problem. Silence because all is well
and silence because the process is dead are indistinguishable from outside, so
each run leaves a row saying when it ran and what it saw.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select, text
from sqlalchemy.orm import Session

from .models import Tenant, WorkerHeartbeat

#: What a run concluded, in one word. `fault` is the one that must never be
#: reachable by a job that simply had nothing to do — see `NoActiveTenants`.
OK = "ok"
FINDINGS = "findings"
FAULT = "fault"


class NoActiveTenants(RuntimeError):
    """Raised when enumeration found no firms at all.

    Deliberately an exception rather than an empty list quietly returned. A
    caller that forgets to check a list still exits 0; a caller that forgets to
    catch this does not.
    """


#: The role membership that admits a connection to the whole tenant list.
#: Migration 0029 creates it and grants it to the schema owner.
MAINTENANCE_ROLE = "quolin_maintenance"


def holds_the_maintenance_grant(session: Session) -> bool:
    """Whether this connection is a member of `quolin_maintenance`.

    Q-01's remaining assumption, made checkable. Migration 0029 grants the role
    `TO current_user` — the account running alembic — and every worker's ability
    to enumerate firms then rests on that being the same account the workers
    connect as. On a laptop it is. On a deployment where migrations run as a
    migrator and the workers run as somebody else, it is not, and nothing
    anywhere said so.

    The failure without this is not silent — `NoActiveTenants` already refuses
    to let an empty enumeration read as success — but it is *misdiagnosed*. An
    operator paged at 03:00 reads "no active firms were visible" and goes to
    look at the `tenants` table, which is full. This is the question they
    actually needed answered, asked directly.
    """
    granted = session.execute(
        text("SELECT pg_has_role(current_user, :role, 'member')"),
        {"role": MAINTENANCE_ROLE},
    ).scalar()
    return bool(granted)


def assert_can_enumerate(session: Session) -> None:
    """Refuse before the work starts if this connection cannot see the firms.

    A preflight rather than a check folded into `active_tenants`, because the
    two answer different questions: this one is about the connection, and that
    one is about the data. Reported separately so the message names the cause.
    """
    if holds_the_maintenance_grant(session):
        return
    raise NoActiveTenants(
        f"this connection is not a member of {MAINTENANCE_ROLE!r}, so it cannot "
        f"read `tenants` and every scheduled job would enumerate nothing. "
        f"Migration 0029 grants that role to the account it is applied by — if "
        f"migrations run as one account and the workers connect as another, the "
        f"grant landed on the wrong one. Grant it to the workers' role and "
        f"re-run: GRANT {MAINTENANCE_ROLE} TO <the workers' role>;"
    )


def active_tenants(session: Session) -> list[Tenant]:
    """Every active firm, ordered, as a role holding the maintenance grant sees them.

    Raises `NoActiveTenants` rather than returning `[]`. There is no deployment
    of this system with zero active firms that also has scheduled jobs pointed
    at it: the seed creates one and a hosted instance is created for a customer.
    An empty answer means the connection cannot see the table, which is the
    exact failure migration 0029 exists to end, and it must not read as success.
    """
    rows = list(
        session.scalars(select(Tenant).where(Tenant.status == "active").order_by(Tenant.id))
    )
    if not rows:
        raise NoActiveTenants(
            "no active tenants were visible to this connection. Either the "
            "database genuinely holds none — in which case nothing should be "
            "scheduled against it — or this role cannot read `tenants`. "
            "Migration 0029 grants `quolin_maintenance` to the schema owner; "
            "check that it has been applied and that this process connects as "
            "the role it was applied by."
        )
    return rows


def active_tenant_ids(session: Session) -> list[str]:
    """The ids alone, for the workers that do not need the rest of the row."""
    return [tenant.id for tenant in active_tenants(session)]


def heartbeat(
    session: Session,
    worker: str,
    *,
    tenants_seen: int,
    outcome: str,
    detail: str = "",
) -> None:
    """Record that `worker` ran, so that its silence becomes observable.

    Upserted rather than appended: the question is "when did it last run and
    what did it find", and a table that grows a row per minute per worker is one
    somebody eventually truncates, taking the answer with it.

    Takes a session rather than opening one, so the write lands in the caller's
    transaction and a heartbeat cannot claim a run that then rolled back.
    """
    row = session.get(WorkerHeartbeat, worker)
    if row is None:
        row = WorkerHeartbeat(worker=worker)
        session.add(row)
    row.ran_at = datetime.now(timezone.utc)
    row.tenants_seen = tenants_seen
    row.outcome = outcome
    row.detail = detail[:2000]
