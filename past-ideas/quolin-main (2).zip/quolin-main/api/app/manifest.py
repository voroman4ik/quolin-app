"""What ran, on what content — so replay can prove it, not merely assert it.

"Every determination replays forever" is the claim this product rests on, and
until Q-04 the recorded evidence could not support it.

A decision committed to `pack_version`: an integer. Nothing made that integer
unique — `packs` had no constraint on `(jurisdiction, version)` and versions were
allocated at draft time, so two drafts cut on the same afternoon proposed the
same number — and `by_version` read with `.first()` and no `ORDER BY`. Replay
reading the wrong row would reproduce a different answer and report it as a
rule-level difference, which is what a genuine regression looks like.

And the decision recorded nothing at all about the *evaluator*. Replay runs
whatever engine is installed today. A determination that reproduces under an
engine three years newer has demonstrated that the two engines agree today; it
has not demonstrated what was decided in 2026. That is a drift detector, and it
was being read as an archival guarantee.

So a decision now carries a manifest of its execution:

    dsl_version         the language semantics the governing pack declared
    pack_content_hash   the bytes of the pack it was decided on
    other_pack_hashes   the same, per regime, on a cross-border determination
    snapshot_hash       the bytes of the facts it was decided from
    evaluator           which build of this engine ran
    snapshot_inputs     the configuration the snapshot was constructed under

Replay compares the manifest against the environment it is running in, and
reports any difference as **drift**, separately from a rule-outcome mismatch. The
two are different findings and only one of them means the evaluator is wrong.

**Why this arrives as a payload schema rather than another key.**

The determination hash is recomputed from stored columns to verify the chain.
Adding a field to that payload would change the recomputed hash of every
determination already recorded, and the chain would break on rows nobody had
touched — invariant 5, broken to improve provenance. So `decisions.payload_schema`
says which shape a row was hashed under. Rows written before this are schema 1
and are verified by a payload that does not know the manifest exists; new rows
are schema 2. Both live forever, for the same reason `engine/evaluate.py` keeps
DSL v1 forever.
"""

from __future__ import annotations

import os
import subprocess
from functools import lru_cache
from typing import Any

from .canonical import content_hash
from .engine import Pack, calcs
from .engine.dsl import DEFAULT_DSL_VERSION

#: The payload shape a determination was hashed under.
#:
#: 1 — everything up to Q-04. No manifest.
#: 2 — the same fields plus `manifest`.
#:
#: This list only ever grows, and support for an old schema is never removed:
#: verifying a 2026 determination in 2031 means recomputing the payload the way
#: 2026 did.
PAYLOAD_SCHEMAS = (1, 2)
CURRENT_PAYLOAD_SCHEMA = 2

#: The schema every row written before Q-04 is on. Set as a column default so
#: existing rows are classified by the migration rather than by a guess at read
#: time.
LEGACY_PAYLOAD_SCHEMA = 1


@lru_cache(maxsize=1)
def evaluator_release() -> str:
    """Which build of this engine ran, as precisely as the deployment can say.

    `QUOLIN_RELEASE` first, because a container knows what it is and a container
    has no git checkout. Then the commit, for a developer machine and for CI. A
    package version last: it is coarse — every build of 1.0.0 answers the same —
    but it is better than an empty string, and an empty string in an archival
    record is the failure this field exists to prevent.

    Never blank. `unrecorded` is an honest answer that a reader can act on;
    silence is not.

    Cached, because this runs on every determination and none of the three
    sources can change inside a process.
    """
    declared = os.getenv("QUOLIN_RELEASE", "").strip()
    if declared:
        return declared

    try:
        commit = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=2,
            cwd=os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        )
        if commit.returncode == 0 and commit.stdout.strip():
            return f"git:{commit.stdout.strip()}"
    except (OSError, subprocess.SubprocessError):
        pass

    try:
        from importlib.metadata import version

        return f"pkg:{version('quolin-api')}"
    except Exception:  # noqa: BLE001 — an unnamed evaluator is the thing to avoid
        return "unrecorded"


def snapshot_inputs() -> dict[str, Any]:
    """The configuration a snapshot was constructed under, not its contents.

    The snapshot itself is hashed and stored; what is not in it is the shape of
    the machinery that built it. A calc added, removed or renamed changes what
    every future snapshot carries, and a determination that replays against a
    registry with different members has been replayed under different
    normalisation — which is worth knowing even when the answer is the same.

    Names and units rather than the whole registry: the description is prose
    that can be improved without changing a single number, and putting it here
    would report drift every time somebody fixed a typo.
    """
    return {
        "calcs": {name: calc.unit for name, calc in calcs.registered().items()},
        "default_dsl_version": DEFAULT_DSL_VERSION,
    }


def build(*, governing: Pack, others: list[Pack], snapshot: dict[str, Any]) -> dict[str, Any]:
    """The manifest for one determination, computed at the moment it is made."""
    return {
        "dsl_version": int(governing.dsl_version),
        "pack_content_hash": content_hash(governing.source_body),
        "other_pack_hashes": {
            pack.pack_id: content_hash(pack.source_body)
            for pack in sorted(others, key=lambda p: p.pack_id)
            if pack.pack_id != governing.pack_id
        },
        "snapshot_hash": content_hash(snapshot),
        "evaluator": evaluator_release(),
        "snapshot_inputs": snapshot_inputs(),
    }


#: Manifest fields that identify *what was decided on*. A difference in any of
#: them means replay is not reading the record — different rules, or different
#: facts — and the replay has failed however well the outcomes happen to agree.
IDENTIFYING = ("pack_content_hash", "other_pack_hashes", "snapshot_hash", "dsl_version")

#: Fields that describe *what did the deciding*. A difference here is real and
#: worth reporting and is **not** a failure: the evaluator's build changes on
#: every deploy, and a calc added to the registry does not alter what a stored
#: snapshot replays to. Folding these into the verdict would make every
#: determination on file "fail to reproduce" the moment anything shipped, which
#: is how a real signal gets switched off.
ENVIRONMENTAL = ("evaluator", "snapshot_inputs")


def check(
    recorded: dict[str, Any] | None,
    *,
    governing: Pack,
    others: dict[str, Pack] | None = None,
    snapshot: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Compare a recorded manifest against what is about to replay it.

    Three-valued on purpose, twice over.

    `matches` is `None` when the determination carries no manifest — every row
    written before Q-04 — because there is nothing to compare. Reporting `False`
    would have turned a firm's whole history into provenance failures on the day
    this shipped.

    `content_matches` is the one that decides whether a replay has succeeded,
    and it is deliberately narrower than `matches`. Reading different rules is a
    failure; running a newer build of the evaluator is a fact. The first version
    of this function conflated them, and the suite said so immediately: 1818
    determinations "failed to reproduce" with an empty list of differences,
    because the git commit had moved. Every deploy would have done that.

    Every difference is reported, not the first, because a replay that read the
    wrong pack *and* ran a different evaluator has two problems and an operator
    who fixes one and rediscovers the other is doing the work twice.
    """
    if not recorded:
        return {
            "matches": None,
            "content_matches": None,
            "drift": {},
            "note": "recorded before manifests existed",
        }

    current: dict[str, Any] = {
        "dsl_version": int(governing.dsl_version),
        "pack_content_hash": content_hash(governing.source_body),
        "evaluator": evaluator_release(),
        "snapshot_inputs": snapshot_inputs(),
    }
    if others is not None:
        current["other_pack_hashes"] = {
            code: content_hash(pack.source_body)
            for code, pack in sorted(others.items())
            if pack.pack_id != governing.pack_id
        }
    if snapshot is not None:
        current["snapshot_hash"] = content_hash(snapshot)

    drift = {
        field: {"recorded": recorded.get(field), "now": value}
        for field, value in current.items()
        if field in recorded and recorded[field] != value
    }
    content_drift = sorted(field for field in drift if field in IDENTIFYING)
    return {
        "matches": not drift,
        "content_matches": not content_drift,
        "drift": drift,
        "note": (
            ""
            if not drift
            else (
                "the rules and facts of record are intact; "
                + ", ".join(sorted(f for f in drift if field_is_environmental(f)))
                + " differ from the environment that made this determination"
            )
            if not content_drift
            else f"replay is not reading the record: {', '.join(content_drift)} differ"
        ),
    }


def field_is_environmental(field: str) -> bool:
    return field in ENVIRONMENTAL
