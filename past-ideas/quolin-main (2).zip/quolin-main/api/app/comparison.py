"""What their system said, what ours said, and every place the two differ.

§S10: shadow mode exists to produce one sentence — "we agree with your existing
process 97% of the time, and here are the 3%" — and then to make the 3% legible
enough that a compliance officer can sort it themselves.

**Divergences are triaged into two categories and the categories are not
symmetric.** §S10 puts it plainly: their process gap is the sales close, and our
defect is free QA. This module refuses to guess which is which. It reports the
rule that produced our answer and the facts it read, and leaves the judgement to
a person — because a system that graded its own disagreements would grade them
in its own favour, and the one thing shadow mode cannot afford is to be seen
doing that.

**Agreement is measured only on pairs both sides answered.** A client their
extract does not cover is not agreement and not disagreement; counting it either
way would move the headline number without anybody deciding anything. The
report says how many pairs were compared and how many were not, so the number
has a denominator a reader can check.

**Their vocabulary is preserved.** `TIER_3` stays `TIER_3` in the report beside
whatever we mapped it to, because the mapping is exactly the kind of thing that
turns out to be wrong in week one — and a report that had already translated it
would hide the error inside the number.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Any, Iterable

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import business_time
from .models import Decision, IncumbentOutcome

#: Our three. Anything else a customer sends is kept verbatim and reported as
#: unmapped rather than forced into one of these.
OUTCOMES = ("ALLOW", "REFER", "BLOCK")

#: The two categories §S10 names, plus the one it implies. Neither of the first
#: two is chosen by this module — a person picks, and the report exists to make
#: picking possible.
OUR_DEFECT = "our_defect"
THEIR_GAP = "their_process_gap"
UNTRIAGED = "untriaged"

#: How a customer's own vocabulary maps onto ours, when they have not said.
#: Deliberately small: guessing at a firm's internal codes is how a comparison
#: report ends up confidently wrong. Anything unrecognised is reported unmapped,
#: which is a question for the customer rather than an answer from us.
DEFAULT_VOCABULARY = {
    "allow": "ALLOW",
    "approved": "ALLOW",
    "pass": "ALLOW",
    "yes": "ALLOW",
    "refer": "REFER",
    "review": "REFER",
    "escalate": "REFER",
    "block": "BLOCK",
    "reject": "BLOCK",
    "decline": "BLOCK",
    "no": "BLOCK",
}


@dataclass(frozen=True)
class Divergence:
    """One pair where the two systems disagreed."""

    client_id: str
    asset_id: str
    as_of: str
    ours: str
    theirs: str
    theirs_raw: str
    rule_id: str
    reason_code: str
    explanation: str
    decision_id: int | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "client_id": self.client_id,
            "asset_id": self.asset_id,
            "as_of": self.as_of,
            "ours": self.ours,
            "theirs": self.theirs,
            "theirs_raw": self.theirs_raw,
            "rule_id": self.rule_id,
            "reason_code": self.reason_code,
            "explanation": self.explanation,
            "decision_id": self.decision_id,
            "triage": UNTRIAGED,
        }


def map_outcome(raw: str, vocabulary: dict[str, str] | None = None) -> str:
    """Their word, as one of our three — or empty when we do not recognise it.

    Empty rather than a guess. A comparison that mapped an unknown code to the
    nearest-sounding outcome would produce agreement or disagreement that nobody
    decided, and both are worse than a question.
    """
    table = {**DEFAULT_VOCABULARY, **{k.lower(): v for k, v in (vocabulary or {}).items()}}
    return table.get(str(raw or "").strip().lower(), "")


def latest_by_pair(
    session: Session, *, since: date | None = None, until: date | None = None
) -> dict[tuple[str, str], IncumbentOutcome]:
    """The newest recorded answer per (client, asset). FP3-23.

    Since a restatement is a new row rather than an edit, "what does their
    system say" is the last row written for that pair, not the only one. Ordered
    by `as_of` and then by `id`, so two restatements of the same date resolve to
    the one written later rather than to whichever the plan returned first —
    which is the same tiebreak `packs_repo` uses and for the same reason.

    The older rows are kept and are readable. "Their answer changed on Tuesday"
    is a fact about a comparison, and the version of this that overwrote them
    could not tell anybody it had happened.
    """
    stmt = select(IncumbentOutcome)
    if since:
        stmt = stmt.where(IncumbentOutcome.as_of >= since)
    if until:
        stmt = stmt.where(IncumbentOutcome.as_of <= until)

    newest: dict[tuple[str, str], IncumbentOutcome] = {}
    for row in session.scalars(
        stmt.order_by(IncumbentOutcome.as_of, IncumbentOutcome.id)
    ):
        newest[(row.client_id, row.asset_id)] = row
    return newest


def ingest(
    session: Session,
    rows: Iterable[dict[str, Any]],
    *,
    source: str,
    vocabulary: dict[str, str] | None = None,
) -> dict[str, int]:
    """Take a customer's extract of their own outcomes.

    Re-sending a corrected extract replaces the row it corrects rather than
    adding a second opinion nobody can choose between — a unique index on the
    pair and date enforces it, and the correction is the point of a re-send.

    **The same applies within one file.** An extract that states a pair twice is
    ordinary: somebody appended a correction rather than editing the line above.
    The last line wins, which is what a person reading the file top to bottom
    would conclude. The first version of this deduplicated against the database
    and not against the batch, so a file like that failed on the unique index
    with a message about nothing the customer had done wrong.
    """
    tally = {"received": 0, "mapped": 0, "unmapped": 0, "replaced": 0, "restated": 0}
    staged: dict[tuple[str, str, date], IncumbentOutcome] = {}

    for row in rows:
        tally["received"] += 1
        client_id = str(row.get("client_id", "")).strip()
        asset_id = str(row.get("asset_id", "")).strip()
        raw = str(row.get("outcome", "")).strip()
        if not client_id or not asset_id:
            continue

        as_of = row.get("as_of")
        when = (
            date.fromisoformat(as_of)
            if isinstance(as_of, str)
            else (as_of or business_time.business_today(session))
        )
        mapped = map_outcome(raw, vocabulary)
        tally["mapped" if mapped else "unmapped"] += 1

        key = (client_id, asset_id, when)

        # FP3-23. Both branches below used to *edit* a row in place — the one
        # staged earlier in this file, or one already committed from a previous
        # file. `incumbent_outcomes` carried no append-only trigger and no
        # revoked grants, so the customer's recorded answer for a pair on a date
        # could be overwritten by the application role with nothing recording
        # that it had changed.
        #
        # That is the number a shadow-mode engagement closes on. "We agree with
        # you 97% of the time" is movable in either direction — up to close a
        # sale, down to argue a divergence was theirs — and every other figure in
        # this system is chained precisely so that cannot be done to it.
        #
        # So a restatement is a **new row**, and the old one stays. Not a
        # refusal: a firm genuinely re-sends a corrected file, and refusing the
        # second one would leave the comparison reporting last week's answer.
        # `latest_by_pair` is what every reader uses, so the newest row wins for
        # everybody without anybody editing anything.
        pending = staged.get(key)
        if pending is not None:
            tally["restated"] += 1
        else:
            existing = session.scalars(
                select(IncumbentOutcome).where(
                    IncumbentOutcome.client_id == client_id,
                    IncumbentOutcome.asset_id == asset_id,
                    IncumbentOutcome.as_of == when,
                )
            ).first()
            if existing is not None:
                tally["replaced"] += 1

        fresh = IncumbentOutcome(
            client_id=client_id,
            asset_id=asset_id,
            as_of=when,
            outcome=mapped,
            outcome_raw=raw,
            source=source,
        )
        session.add(fresh)
        staged[key] = fresh
    session.flush()
    return tally


def _ours(session: Session, *, since: date | None, until: date | None) -> dict:
    """Our latest determination per pair in the window."""
    stmt = select(Decision).order_by(Decision.client_id, Decision.asset_id, Decision.id.desc())
    if since:
        stmt = stmt.where(Decision.as_of >= since)
    if until:
        stmt = stmt.where(Decision.as_of <= until)
    stmt = stmt.distinct(Decision.client_id, Decision.asset_id)
    return {(d.client_id, d.asset_id): d for d in session.scalars(stmt)}


def _explain(decision: Decision) -> tuple[str, str, str]:
    """Why we said what we said, in a sentence a compliance officer can read.

    Assembled from the rule's own title and the facts it read, both of which the
    determination already carries. Nothing is invented here: if the reason card
    on screen and this sentence ever disagree, one of them is lying, so both are
    built from the same stored results.
    """
    results = list((decision.rule_results or {}).get("results", []))
    for block in ((decision.rule_results or {}).get("other_jurisdictions") or {}).values():
        results.extend(block.get("results", []))

    for result in results:
        if result.get("passed") or result.get("outcome") != decision.outcome:
            continue
        read = ", ".join(
            f"{entry.get('ref')} was {entry.get('value')}"
            for entry in (result.get("inputs_read") or [])[:3]
        )
        title = str(result.get("title") or result.get("rule_id") or "a rule")
        return (
            str(result.get("rule_id") or ""),
            str(result.get("reason_code") or ""),
            f"{title} — {read}" if read else title,
        )
    return "", "", "Every rule passed, so the determination is ALLOW."


def compare(
    session: Session,
    *,
    since: date | None = None,
    until: date | None = None,
    limit: int = 500,
) -> dict[str, Any]:
    """The weekly comparison: agreement rate, and every divergence explained.

    The number a customer repeats is the agreement rate, so it is computed the
    way somebody checking it would: over the pairs both sides answered, with the
    pairs neither could be compared on reported separately rather than folded in.
    """
    ours = _ours(session, since=since, until=until)

    theirs = latest_by_pair(session, since=since, until=until)

    compared: list[Divergence] = []
    agreed = 0
    unmapped = 0
    for pair, incumbent in theirs.items():
        decision = ours.get(pair)
        if decision is None:
            continue
        if not incumbent.outcome:
            unmapped += 1
            continue
        if incumbent.outcome == decision.outcome:
            agreed += 1
            continue
        rule_id, reason_code, explanation = _explain(decision)
        compared.append(
            Divergence(
                client_id=pair[0],
                asset_id=pair[1],
                as_of=decision.as_of.isoformat(),
                ours=decision.outcome,
                theirs=incumbent.outcome,
                theirs_raw=incumbent.outcome_raw,
                rule_id=rule_id,
                reason_code=reason_code,
                explanation=explanation,
                decision_id=decision.id,
            )
        )

    # Worst disagreement first: a pair where we block and they allow is the one
    # that matters most in both directions — either their process is letting
    # something through, or ours is stopping something it should not.
    severity = {"BLOCK": 0, "REFER": 1, "ALLOW": 2}
    compared.sort(key=lambda d: (severity.get(d.ours, 3), d.client_id, d.asset_id))

    comparable = agreed + len(compared)
    return {
        "window": {
            "from": since.isoformat() if since else None,
            "to": until.isoformat() if until else None,
        },
        "compared": comparable,
        "agreed": agreed,
        "diverged": len(compared),
        # None rather than 100% when nothing was comparable. A rate computed
        # over zero pairs is not a rate, and printing "100%" for it would be the
        # single most misleading number this report could carry.
        "agreement_rate": (agreed / comparable) if comparable else None,
        "their_rows": len(theirs),
        "our_rows": len(ours),
        # Counted and named rather than folded into the rate: a pair only one
        # side answered is a question about coverage, not about agreement.
        "only_ours": len([p for p in ours if p not in theirs]),
        "only_theirs": len([p for p in theirs if p not in ours]),
        "unmapped_outcomes": unmapped,
        "divergences": [d.as_dict() for d in compared[:limit]],
        "truncated": len(compared) > limit,
        "statement": (
            "Agreement is measured over the pairs both systems answered. A "
            "divergence is not a finding against either side until somebody "
            "reads it: this report says what each system decided and why ours "
            "decided it, and leaves the judgement to a person."
        ),
    }
