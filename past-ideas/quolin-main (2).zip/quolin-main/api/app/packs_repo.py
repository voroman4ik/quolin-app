from __future__ import annotations

from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import adoption, advance
from .engine import Pack
from .engine.pack import REVIEWED
from .models import Pack as PackRow
from .models import Tenant
from .tenancy import current_tenant, current_tenant_or_none


class NoReviewedPackAvailable(LookupError):
    """A firm that can act on determinations asked for rules nobody has signed.

    The execution plan's rule that cannot be waived: no jurisdiction ships to a
    production tenant on in-house content, however good the in-house content
    looks. The flag existed on every pack and nothing enforced it — `active`
    selected on jurisdiction and effective date, so a live customer would have
    been served `PENDING_REVIEW` rules and told nothing.

    Raised rather than returned as an empty shelf, and raised naming the
    jurisdiction, because the person reading it needs to know which specialist
    to engage. An empty shelf would have been a determination that found no
    applicable regime, which is a different and much quieter answer.
    """


#: Rungs at which a determination reaches the world. `pilot` and `shadow`
#: withhold every outbound effect (see `app/adoption.py`), so a firm on those
#: rungs may compute against unreviewed rules — nobody is relying on the answer.
#: `limited` and `full` may not.
ACTING_STAGES = (adoption.LIMITED, adoption.FULL)

#: The one escape hatch, and it is a recorded property of a tenant rather than
#: a name in this file.
#:
#: The demonstration firm sits at `full` — it has to, or its webhooks and
#: referrals go quiet and the demo stops being a demo — and it runs on the
#: shipped illustrative content. That is legitimate and it is exactly the
#: situation this module exists to refuse for everybody else, so it is declared
#: on the tenant's own row where an access review can see it, rather than
#: inferred from the tenant being called `demo`.
#:
#: A column since migration 0032, not a key in `config`. Q-11: `quolin_app`
#: holds `UPDATE (config)` so that a firm can set its own advance policy, which
#: put the single override on the most important refusal in reach of a request.
#: The column carries no such grant. The name is kept as a constant because the
#: seed and the access review both refer to it.
PERMIT_COLUMN = "illustrative_content_permitted"


def _may_use_unreviewed(session: Session) -> bool:
    """Whether the firm in scope may decide on content nobody has signed.

    F11: this used to answer `True` with no tenant bound, reasoning that no firm
    in scope meant a script or a screen rather than a determination. The
    reasoning is sound and the direction is wrong. An unbound tenant is not
    evidence that this is a screen — it is the absence of evidence either way,
    and every caller that decides binds one, so an unbound one is a caller that
    has gone wrong. Answering *yes* to "may this firm act on rules nobody has
    signed" when you cannot tell which firm is asking fails open on the single
    refusal the execution plan says cannot be waived.

    `current_tenant()` raises in exactly this situation and the whole of §S11
    rests on that; this was the one place that quietly answered instead.

    Screens are unaffected because they never came through here: `describe` and
    `describe_all` apply no gate at all, which is why they are two names rather
    than a flag on this one.
    """
    tenant_id = current_tenant()
    tenant = session.get(Tenant, tenant_id)
    if tenant is None:
        return False
    # The column, never `config`. Reading both would mean two answers to one
    # question and the JSON one is the writable one — which is the whole finding.
    if bool(getattr(tenant, PERMIT_COLUMN, False)):
        return True
    return adoption.stage_of(tenant) not in ACTING_STAGES


#: The tiebreak every shelf query ends with.
#:
#: Q-04: `active`, `active_all` and `active_rows` ordered by `effective_from`
#: alone, and several packs sharing an effective date is ordinary — a regime
#: that publishes three amendments to take effect on the first of the month has
#: three. With no tiebreak, "the newest pack on this date" was whatever order
#: the plan happened to return, so the same determination made twice in one
#: second could have been made against two different packs.
#:
#: `id` rather than `version`, and deliberately: `id` is the order rows were
#: written, which is the order they were published in, and it is unique by
#: construction. `by_version` took `.first()` with no ordering at all, which was
#: safe only because nothing enforced the uniqueness that would have made it
#: safe — migration 0031 now does, and the ordering stays as the second lock.
_NEWEST_FIRST = (PackRow.effective_from.desc(), PackRow.id.desc())


def _usable(
    session: Session,
    rows: list[PackRow],
    jurisdiction: str,
    permitted: bool | None = None,
) -> list[PackRow]:
    """Filter a candidate list to what this firm is allowed to decide on.

    `permitted` is threaded through by callers that have already asked, so that
    assembling a shelf of five regimes does not read the tenant row five times.
    """
    if permitted is None:
        permitted = _may_use_unreviewed(session)
    if permitted:
        return rows

    # FP3-06. This compared `content_status == REVIEWED` and nothing else.
    #
    # `Pack.is_production_grade` was written to answer exactly the question this
    # line asks — "may a firm that acts on its determinations decide on this" —
    # and the fix-pack entry describing it said it "answers the loader's
    # question". It had **zero callers**. The three-layer claim was two: the
    # status check here, and the CHECK constraint in migration 0025.
    #
    # The half that was missing is the one a status column cannot express. A
    # pack can be `REVIEWED` and signed by `[unsigned]` or by an
    # `ILLUSTRATIVE ...` placeholder — content that has moved through the
    # lifecycle without a real person's name on it. The database refuses that
    # pairing, so the gap was never *exploitable* through a normal write path;
    # what it meant is that the application had no opinion, and the only thing
    # standing between a firm and unsigned content was one constraint.
    reviewed = [row for row in rows if Pack.from_body(row.body).is_production_grade]
    if rows and not reviewed:
        raise NoReviewedPackAvailable(
            f"{jurisdiction} has no signed pack in force. This firm acts on its "
            f"determinations, so it cannot decide on content nobody qualified "
            f"has reviewed. The {jurisdiction} pack is "
            f"{rows[0].content_status} until a specialist signs it."
        )
    return reviewed


def _pinned_row(
    session: Session,
    jurisdiction: str,
    in_force: PackRow,
    taken_version: int | None,
    permitted: bool,
) -> PackRow | None:
    """The version this firm's advance policy holds them on, when it is not the shelf's.

    F1: the advance policy had a complete write path and no read path. A firm
    that chose `pinned` and was shown a review window still had every
    determination — interactive, periodic sweep, profile change — recorded
    against the newest effective pack, hash-chained under a version they had
    not taken. The pin is applied here, where the shelf is assembled, so that
    the service, every bulk trigger and the dashboard cannot disagree about
    which rules a firm is on.

    Three semantics, and each is a decision rather than an implementation
    detail:

    * **A taken version newer than the one in force is not yet effective.** A
      firm may be noticed about and take a version before its date arrives —
      that is what the window is for — and taking it early must not backdate
      its effect. `advance.newest_taken` ignores anything above what is in
      force, so a firm on v2 that takes a future-dated v4 stays on v2 rather
      than being carried to the v3 they never looked at. A pin holds a firm
      back and never pushes them forward.
    * **An older taken version is read by number, not by date.** Superseding
      may have closed its window, so the effective-date query that produced
      `in_force` would not return it at all. What the firm took is what governs
      until they take the next one.
    * **A pinned version that this firm may not act on is a refusal.** Quietly
      promoting them to the signed version above would be the pin failing open,
      which is the one direction it must never fail.

    `None` means the shelf governs, which is the answer for every `auto` firm
    and for every pinned firm that has not yet taken anything.
    """
    if taken_version is None or taken_version >= in_force.version:
        return None
    row = session.scalars(
        select(PackRow)
        .where(PackRow.jurisdiction == jurisdiction)
        .where(PackRow.version == taken_version)
        .order_by(PackRow.id)
    ).first()
    if row is None:
        # A recorded advance naming a version this deployment does not hold.
        # The shelf is the safe answer and the honest one: inventing a pack is
        # not available, and refusing every determination for a firm because an
        # advance row outlived its pack would be a worse failure than moving
        # them to what is actually in force.
        return None
    if not permitted and row.content_status != REVIEWED:
        raise NoReviewedPackAvailable(
            f"{jurisdiction} v{row.version} is the version this firm has taken, "
            f"and it is {row.content_status} rather than signed. This firm acts "
            f"on its determinations, so it cannot decide on content nobody "
            f"qualified has reviewed — and it is not moved onto "
            f"v{in_force.version} instead, because a version applies to this "
            f"firm when they take it and not before."
        )
    return row


def _pin_for(session: Session, jurisdiction: str, in_force_version: int) -> int | None:
    """The version the firm in scope has taken in this regime, if any.

    No firm in scope means a script or a screen rather than a determination, and
    those read the shelf — the same reasoning `_may_use_unreviewed` gives.
    """
    tenant_id = current_tenant_or_none()
    if tenant_id is None:
        return None
    return advance.effective_version_for(
        session,
        tenant_id=tenant_id,
        jurisdiction=jurisdiction,
        not_after=in_force_version,
    )


def active(session: Session, jurisdiction: str, effective_on: date) -> Pack:
    stmt = (
        select(PackRow)
        .where(PackRow.jurisdiction == jurisdiction)
        .where(PackRow.effective_from <= effective_on)
        .where((PackRow.effective_to.is_(None)) | (PackRow.effective_to >= effective_on))
        .order_by(*_NEWEST_FIRST)
    )
    rows = list(session.scalars(stmt))
    if not rows:
        raise LookupError(f"no {jurisdiction} pack effective on {effective_on.isoformat()}")
    permitted = _may_use_unreviewed(session)
    usable = _usable(session, rows, jurisdiction, permitted)
    if not usable:
        raise LookupError(f"no {jurisdiction} pack effective on {effective_on.isoformat()}")
    in_force = usable[0]
    pinned = _pinned_row(
        session,
        jurisdiction,
        in_force,
        _pin_for(session, jurisdiction, in_force.version),
        permitted,
    )
    return Pack.from_body((pinned or in_force).body)


def active_all(session: Session, effective_on: date) -> dict[str, Pack]:
    """Every jurisdiction's pack in force on a date, keyed by jurisdiction.

    The cross-border resolver needs the whole shelf, not one pack, because
    which packs apply is a property of the client rather than of the caller.
    """
    stmt = (
        select(PackRow)
        .where(PackRow.effective_from <= effective_on)
        .where((PackRow.effective_to.is_(None)) | (PackRow.effective_to >= effective_on))
        .order_by(PackRow.jurisdiction, *_NEWEST_FIRST)
    )
    permitted = _may_use_unreviewed(session)
    in_force: dict[str, PackRow] = {}
    for row in session.scalars(stmt):
        # A firm that acts on its determinations sees only signed content. The
        # unreviewed pack is not hidden from screens — `describe` returns it —
        # it is withheld from the shelf that decides.
        if not permitted and row.content_status != REVIEWED:
            continue
        # Ordered newest-first within a jurisdiction, so the first wins.
        in_force.setdefault(row.jurisdiction, row)

    # F1. The advance policy is applied here rather than in the service, so that
    # an interactive determination, a periodic sweep, a profile-change sweep and
    # the dashboard all read the same version — the one the firm actually took.
    # A shelf that honoured the pin in one caller and not the others would be
    # the same finding again, one layer up.
    tenant_id = current_tenant_or_none()
    taken = advance.taken_versions(session, tenant_id=tenant_id) if tenant_id else {}

    out: dict[str, Pack] = {}
    for jurisdiction, row in in_force.items():
        pinned = _pinned_row(
            session,
            jurisdiction,
            row,
            advance.newest_taken(
                taken.get(jurisdiction, []), not_after=row.version
            ),
            permitted,
        )
        out[jurisdiction] = Pack.from_body((pinned or row).body)
    return out


def describe(session: Session, jurisdiction: str, effective_on: date) -> Pack:
    """The pack in force, whatever its content status. For screens, never decisions.

    Split from `active` deliberately. A compliance officer must be able to open
    `/packs` and read that AU is `PENDING_REVIEW` — that is the disclosure
    working — and the same call must not be reachable from anything that
    produces a determination. Two names rather than a flag, because a flag is
    what every caller eventually sets.
    """
    stmt = (
        select(PackRow)
        .where(PackRow.jurisdiction == jurisdiction)
        .where(PackRow.effective_from <= effective_on)
        .where((PackRow.effective_to.is_(None)) | (PackRow.effective_to >= effective_on))
        .order_by(*_NEWEST_FIRST)
    )
    row = session.scalars(stmt).first()
    if row is None:
        raise LookupError(f"no {jurisdiction} pack effective on {effective_on.isoformat()}")
    return Pack.from_body(row.body)


def describe_all(session: Session, effective_on: date) -> dict[str, Pack]:
    """Every pack in force, whatever its status. For screens, never decisions."""
    stmt = (
        select(PackRow)
        .where(PackRow.effective_from <= effective_on)
        .where((PackRow.effective_to.is_(None)) | (PackRow.effective_to >= effective_on))
        .order_by(PackRow.jurisdiction, *_NEWEST_FIRST)
    )
    out: dict[str, Pack] = {}
    for row in session.scalars(stmt):
        out.setdefault(row.jurisdiction, Pack.from_body(row.body))
    return out


def active_rows(session: Session, effective_on: date) -> dict[str, PackRow]:
    """The in-force pack *row* per jurisdiction, unparsed.

    The watch service reads pack bodies rather than `engine.Pack` objects, and
    this is deliberate. `engine.Pack` is exactly as wide as evaluation needs;
    hanging a `watch` field off it would put monitoring content inside the type
    the evaluator holds, and the claim this phase makes is that no watch content
    can reach a determination. Reading the raw body keeps that structural rather
    than a matter of nobody having written the wrong line yet.
    """
    stmt = (
        select(PackRow)
        .where(PackRow.effective_from <= effective_on)
        .where((PackRow.effective_to.is_(None)) | (PackRow.effective_to >= effective_on))
        .order_by(PackRow.jurisdiction, *_NEWEST_FIRST)
    )
    out: dict[str, PackRow] = {}
    for row in session.scalars(stmt):
        out.setdefault(row.jurisdiction, row)
    return out


def pending_rows(session: Session, on: date) -> list[PackRow]:
    """Packs signed and stored but not yet in force, soonest first.

    `active()` already excludes these — a future-dated pack has no effect on any
    determination made today, which is the property that makes it safe to store
    one at all. This function exists so a screen can say *when* it starts to
    matter, rather than the pack appearing on the shelf the morning it silently
    takes over.
    """
    stmt = (
        select(PackRow)
        .where(PackRow.effective_from > on)
        .order_by(PackRow.effective_from, PackRow.jurisdiction)
    )
    return list(session.scalars(stmt))


def jurisdictions(session: Session) -> list[str]:
    return sorted(set(session.scalars(select(PackRow.jurisdiction))))


def by_version(session: Session, jurisdiction: str, version: int) -> Pack:
    """The pack a determination names, read back for replay.

    Ordered even though migration 0031 makes `(jurisdiction, version)` unique
    and this can therefore only match one row. The ordering is the second lock:
    this is the function replay reads the pack of record with, and `.first()`
    over an unordered result was — until that constraint existed — a coin toss
    between two different pieces of rule content bearing the same name.
    """
    stmt = (
        select(PackRow)
        .where(PackRow.jurisdiction == jurisdiction)
        .where(PackRow.version == version)
        .order_by(PackRow.id)
    )
    row = session.scalars(stmt).first()
    if row is None:
        raise LookupError(f"no {jurisdiction} pack version {version}")
    return Pack.from_body(row.body)


def all_versions(session: Session, jurisdiction: str) -> list[PackRow]:
    stmt = (
        select(PackRow)
        .where(PackRow.jurisdiction == jurisdiction)
        .order_by(PackRow.version)
    )
    return list(session.scalars(stmt))


def diff(previous: dict, current: dict) -> dict:
    """Threshold and rule-set delta between two pack bodies, for the pack viewer."""
    prev_thresholds, cur_thresholds = previous["thresholds"], current["thresholds"]
    changed = [
        {"name": key, "from": prev_thresholds.get(key), "to": cur_thresholds[key]}
        for key in sorted(cur_thresholds)
        if key in prev_thresholds and prev_thresholds[key] != cur_thresholds[key]
    ]
    added_thresholds = [
        {"name": key, "to": cur_thresholds[key]}
        for key in sorted(cur_thresholds)
        if key not in prev_thresholds
    ]

    prev_rules = {r["rule_id"]: r for r in previous["rules"]}
    cur_rules = {r["rule_id"]: r for r in current["rules"]}
    return {
        "from_version": previous["version"],
        "to_version": current["version"],
        "thresholds_changed": changed,
        "thresholds_added": added_thresholds,
        "rules_added": [cur_rules[k] for k in sorted(set(cur_rules) - set(prev_rules))],
        "rules_removed": sorted(set(prev_rules) - set(cur_rules)),
        "rules_modified": sorted(
            k for k in set(cur_rules) & set(prev_rules) if cur_rules[k] != prev_rules[k]
        ),
    }
