"""The two things in `api/app` that need the schema owner, behind a locked door.

FP3-04. `DATABASE_URL` — the role that owns every table, owns every append-only
trigger, bypasses FORCE row-level security, and is what `scripts/rechain.py`
uses to rewrite evidence hashes — was injected into the ECS task that serves
requests. It sat in the environment of the one process an attacker reaches
first.

It was there for nothing. Inside `api/app`, the owner connection had exactly two
users: `auth._reset_rate_limit_for_tests`, which only the suite called, and
`source_alerts.all_tenant_ids`, which is the watch path FP3-03 moved out. The
Dockerfile runs no migration at start. Nothing serving a request has ever needed
it.

**Nothing under `api/app` imports this module any more.** B2 deleted
`source_alerts.all_tenant_ids`; F2 moved the rate-limit reset to
`conftest.reset_rate_limit_for_tests`, where its only caller lives. What remains
here is called from the suite and from nowhere in the request path, which is why
`guard_no_owner_in_request_path.sh` has no allow-list entry for this door any
more and the AST twin's `MAY_OPEN_IT` is empty.

`active_tenant_ids` has no caller anywhere in the tree — every worker enumerates
through `maintenance.active_tenant_ids` on its own owner session. It is left
here rather than deleted because *this* module is the door, not a request-path
module that happens to hold a key: what made `source_alerts.all_tenant_ids`
worth deleting was where it sat. Recorded so that the observation is not lost
rather than because it is load-bearing.

The comment in `infra/compute.tf` justifying its presence said that "without
this the API would fall back to the owner connection", which is backwards twice
over: the variable *is* the owner connection, and what `db.py` falls back to
when it is missing is a hardcoded `localhost:5433`.

**So this module refuses to import without it.** Not a runtime check inside each
function — an `ImportError` raised while the module is being loaded, so that
code reaching for the owner connection in a process that has no business holding
one fails at the import rather than three frames into a request, and fails
whether or not the code path is exercised in a test.

Importing this from anything a request can reach is a mistake this cannot
prevent. What it can do is make that mistake loud in the environment where it
matters, which is the deployment where `DATABASE_URL` is now absent.
"""

from __future__ import annotations

from sqlalchemy import text
from sqlalchemy.orm import Session

from .db import OWNER_URL_WAS_SUPPLIED

# F2. The question is unchanged — was an owner connection supplied — and it is
# now asked through `db.py` rather than by reading the environment here. The
# guard's third rule forbids naming `DATABASE_URL`, `create_engine` or
# `psycopg.connect` anywhere under `api/app` except `db.py`, because a module
# that can build its own engine does not need anyone's door. This module is the
# door; it should not also be a second place the key is spelled.
if not OWNER_URL_WAS_SUPPLIED:
    raise ImportError(
        "app.owner_only needs DATABASE_URL, the schema owner's connection. "
        "This process was not given one — which is correct for anything that "
        "serves a request, and is why this module refuses to load rather than "
        "quietly falling back to a hardcoded localhost. If you are a worker "
        "that genuinely owns the schema, set DATABASE_URL; if you are the API, "
        "you have reached for something you must not hold."
    )


def active_tenant_ids() -> list[str]:
    """Every active firm, through the guard every other enumerator uses.

    FP3-03 gave this the `assert_can_enumerate` preflight it never had — it was
    the one enumerator in the codebase with the Q-01 shape, where a connection
    that cannot see `tenants` returns an empty list and the caller reads that as
    "nothing to do".
    """
    from . import maintenance
    from .db import OwnerSessionLocal

    session = OwnerSessionLocal()
    try:
        maintenance.assert_can_enumerate(session)
        return maintenance.active_tenant_ids(session)
    finally:
        session.close()


def reset_rate_limit(session: Session | None = None) -> None:
    """Forget every sign-in attempt. Owner-only, and only ever called by the suite.

    `auth_attempts` is append-only to the application role by grant *and* by
    trigger, so this cannot be done through the connection the application uses
    — which is the property working, not an inconvenience to route around. The
    suite holds the owner's connection; nothing that serves a request does, and
    since FP3-04 nothing that serves a request is even given one.
    """
    from .db import OwnerSessionLocal

    owner = session or OwnerSessionLocal()
    try:
        owner.execute(
            text("ALTER TABLE auth_attempts DISABLE TRIGGER auth_attempts_append_only")
        )
        owner.execute(text("DELETE FROM auth_attempts"))
        owner.execute(
            text("ALTER TABLE auth_attempts ENABLE TRIGGER auth_attempts_append_only")
        )
        owner.commit()
    finally:
        if session is None:
            owner.close()
