"""The versioned API a customer's engineer integrates against.

Everything in this module is somebody else's contract. The rest of the codebase
serves our own web client, which ships in the same commit as the API it calls —
so a breaking change there is a nuisance. A breaking change *here* is a customer
whose nightly job stopped working, found out from their compliance team, and now
does not trust us with the next release either.

That difference drives every decision below.

**Versioned in the path.** `/v1` is a promise that these shapes do not change.
Additive changes are fine; removing a field or narrowing a type is `/v2`. The
version is in the path rather than a header because a customer debugging at
02:00 should be able to see which contract they are on in the URL they are
looking at.

**Bearer tokens, not cookies.** The web client uses a cookie because it is a
browser and needs `HttpOnly`. An integration is not a browser, has no cross-site
concerns, and would have to fake a cookie jar. Both resolve to the same
`auth_sessions` row — one token format, one revocation path, no second way in.

**Idempotency on every write.** Integrations retry: a dropped response, a
redelivered queue message, a script run twice. Without a key each retry writes
another determination into an append-only chain that cannot be tidied up
afterwards, and duplicated evidence is not cosmetic — it is two records of a
decision made once.

**Cursor pagination, not offsets.** An offset over a table that is being written
to skips rows and repeats rows, and a customer paging through decisions while
determinations are being made would silently miss some. The cursor is the last
id seen, which is stable under insertion.

**Errors say what to do.** Every failure carries a machine-readable `code` and a
sentence a human can act on. `{"detail": "Bad Request"}` at 02:00 is how an
integration goes unfixed for a week.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
from datetime import date, datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field, model_validator
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from . import (
    artefacts,
    auth,
    business_time,
    client_address,
    packs_repo,
    passwords,
    service,
    tenancy,
)
from .db import get_session
from .engine.dsl import PackError
from .models import ApiClient, Artefact, Client, Decision, IdempotencyKey, Override

router = APIRouter(prefix="/v1", tags=["v1"])

#: How long an access token lasts. Short enough that a leaked one is a limited
#: problem, long enough that a batch job is not re-authenticating between files.
TOKEN_MINUTES = 60

#: The largest page anybody may ask for. A customer who wants everything gets it
#: by paging, which is bounded work per request — an unbounded `limit` is one
#: slow query away from being everyone else's outage too.
MAX_PAGE = 200
DEFAULT_PAGE = 50

#: How long an idempotency key is honoured. A day covers every retry pattern we
#: have seen; beyond that a caller re-sending the same key means something else,
#: and answering with a day-old response would be a stranger answer than a new
#: determination.
IDEMPOTENCY_HOURS = 24


def _now() -> datetime:
    return datetime.now(timezone.utc)


def fail(status: int, code: str, message: str) -> HTTPException:
    """Every error the same shape, with a code a program can branch on.

    The message is for the engineer reading the log; the code is for the code.
    An integration that has to string-match a sentence to tell "your token
    expired" from "you may not do that" is one that breaks when we improve the
    wording.
    """
    return HTTPException(status, {"code": code, "message": message})


# ------------------------------------------------------------------- tokens --


class TokenRequest(BaseModel):
    grant_type: str = Field(description="Must be `client_credentials`.")
    client_id: str
    client_secret: str


@router.post("/oauth/token", summary="Exchange client credentials for a token")
def issue_token(
    payload: TokenRequest, request: Request, session: Session = Depends(get_session)
) -> dict[str, Any]:
    """OAuth2 client credentials. The only unauthenticated route in `/v1`.

    The tenant comes from the credential rather than from anything the caller
    sends. There is no header, parameter or body field by which an integration
    can name a customer — which is what makes "read another customer's data" not
    a request anybody can construct, rather than a check somebody has to
    remember to write.
    """
    if payload.grant_type != "client_credentials":
        raise fail(
            400,
            "unsupported_grant_type",
            "Only `client_credentials` is supported. There is no user to redirect, "
            "so the authorization-code and password grants do not apply here.",
        )

    # FP3-02. This used to be `x-forwarded-for`.split(",")[0], which is the
    # entry the caller supplies: an integration credential could be brute-forced
    # from one host by changing a header per request. The address is resolved by
    # the ASGI server from the trusted proxy count now, in one place — see
    # `main._client_ip` for why the first entry is the wrong one and why
    # `--forwarded-allow-ips='*'` would reintroduce this exactly.
    ip = client_address.client_ip(request)
    forwarded = client_address.forwarded_header(request)

    # The tenant is entered *before the first query*, not before the first query
    # that needs it. `app.tenant_id` is bound on the engine's `begin` event, so
    # whichever statement opens the transaction fixes the tenant for every
    # statement after it — and `check_rate_limit` opens it.
    #
    # This route is public, so the middleware binds nothing, and the rate-limit
    # check therefore opened the transaction with `app.tenant_id = ''`. The
    # `api_clients` lookup below then ran under that empty tenant, matched no
    # row, and every integration in the world was told its credentials were
    # wrong. Proven over HTTP against a running server: a valid credential
    # returned `invalid_client`.
    #
    # The suite could not see it. `tests/conftest.py` holds a session-scoped
    # `acting_as(DEMO_TENANT)` open for the whole run, so under pytest there is
    # always an ambient tenant and the transaction opened correctly bound.
    # `tests/test_v1_token_needs_no_ambient_tenant.py` clears it deliberately.
    tenant_id = tenancy.configured_tenant()
    with tenancy.acting_as(tenant_id):
        try:
            auth.check_rate_limit(session, ip)
            # And against the credential itself, so a spray across many hosts
            # meets a limit the address counter cannot see.
            auth.check_account_rate_limit(session, payload.client_id)
        except auth.RateLimited as exc:
            raise HTTPException(
                429,
                {"code": "rate_limited", "message": str(exc)},
                headers={"Retry-After": str(exc.retry_after)},
            ) from exc

        client = session.get(ApiClient, payload.client_id)

        # One refusal for every reason, and the same work done either way.
        # Distinguishing "no such client" from "wrong secret" would turn this
        # endpoint into an oracle for which credentials exist.
        if client is None:
            passwords.waste_time()
            auth.record_failure(session, ip, forwarded_for=forwarded)
            raise fail(401, "invalid_client", "Those credentials are not correct.")

        matched, _ = passwords.verify(client.secret_hash, payload.client_secret)
        expired = client.expires_at is not None and client.expires_at <= _now()
        if not matched or client.status != "active" or expired:
            auth.record_failure(
                session, ip, user_id=client.id, forwarded_for=forwarded
            )
            raise fail(401, "invalid_client", "Those credentials are not correct.")

        auth.clear_failures(
            session, ip, user_id=client.id, forwarded_for=forwarded
        )
        client.last_used_at = _now()
        session.commit()

        token = auth.create_session(
            session,
            tenant_id=tenant_id,
            api_client_id=client.id,
            user_agent=request.headers.get("user-agent", "")[:300],
            ip=ip,
        )

    return {
        "access_token": token,
        "token_type": "Bearer",
        "expires_in": TOKEN_MINUTES * 60,
        "scope": " ".join(sorted(client.roles or [])),
    }


# ------------------------------------------------------------- idempotency --


def _canonical(body: Any) -> str:
    return json.dumps(body, sort_keys=True, separators=(",", ":"), default=str)


def replay_or_reserve(
    session: Session, *, key: str | None, endpoint: str, body: Any
) -> dict[str, Any] | None:
    """The stored response for this key, or None if this is the first time.

    Returns the *original* response rather than re-executing. Re-executing would
    produce a different decision id and a different position in the hash chain,
    which is exactly what the caller sent a key to avoid.

    A key re-used with a different body is refused. The caller believes they sent
    two things; answering with the first one's response would be a strange way to
    tell them otherwise, and quietly doing the second would be worse.
    """
    if not key:
        return None

    digest = hashlib.sha256(f"{endpoint}\n{_canonical(body)}".encode()).hexdigest()
    stored = session.get(IdempotencyKey, key)
    if stored is None:
        return None

    if stored.created_at < _now() - timedelta(hours=IDEMPOTENCY_HOURS):
        session.delete(stored)
        session.flush()
        return None

    if stored.endpoint != endpoint:
        raise fail(
            409,
            "idempotency_key_reused",
            f"This key was already used against {stored.endpoint}. A key belongs to "
            "one request; using it for another is a bug in the caller.",
        )
    if stored.request_hash != digest:
        raise fail(
            409,
            "idempotency_key_reused",
            "This key was already used with a different request body. Send a new key "
            "for a new request — answering with the first one's response would tell "
            "you the second had succeeded when it never ran.",
        )
    return {"status": stored.status_code, "body": stored.response}


def remember(
    session: Session, *, key: str | None, endpoint: str, body: Any, response: dict
) -> None:
    if not key:
        return
    digest = hashlib.sha256(f"{endpoint}\n{_canonical(body)}".encode()).hexdigest()
    session.add(
        IdempotencyKey(
            key=key,
            endpoint=endpoint,
            request_hash=digest,
            status_code=200,
            response=response,
            created_at=_now(),
        )
    )
    session.flush()


# ------------------------------------------------------------------ paging --


def encode_cursor(last_id: Any) -> str:
    """Opaque on purpose.

    A cursor a customer can read is a cursor a customer will construct, and then
    our paging is their contract. Base64 is not security — it is a sign that says
    "this is ours".
    """
    return base64.urlsafe_b64encode(str(last_id).encode()).decode().rstrip("=")


def decode_cursor(cursor: str | None) -> str | None:
    if not cursor:
        return None
    try:
        padded = cursor + "=" * (-len(cursor) % 4)
        return base64.urlsafe_b64decode(padded).decode()
    except (binascii.Error, UnicodeDecodeError) as exc:
        raise fail(
            400,
            "invalid_cursor",
            "That cursor is not one we issued. Pass the `next_cursor` from the "
            "previous page, or omit it to start again.",
        ) from exc


def page(rows: list, limit: int, key) -> dict[str, Any]:
    """A page, and how to ask for the next one.

    `has_more` is computed by asking for one row more than the caller wanted and
    reporting whether it arrived. The alternative — a count query — is a second
    scan of the same table to answer a question the first scan already knew.
    """
    more = len(rows) > limit
    visible = rows[:limit]
    return {
        "data": visible,
        "has_more": more,
        "next_cursor": encode_cursor(key(visible[-1])) if more and visible else None,
    }


def _limit(limit: int) -> int:
    if limit < 1 or limit > MAX_PAGE:
        raise fail(
            400,
            "invalid_limit",
            f"`limit` must be between 1 and {MAX_PAGE}. A customer who wants "
            "everything gets it by paging, which is bounded work per request.",
        )
    return limit


# ------------------------------------------------------------------ clients --


class ClientUpsert(BaseModel):
    id: str
    name: str
    scenario: str = "meridian"
    jurisdiction: str = "AU"
    residency: str | None = None
    domicile: str | None = None
    dob: date
    client_category: str = "retail"
    knowledge_assessed: bool = False
    knowledge_date: date | None = None
    loss_capacity_band: int = Field(ge=1, le=5)
    vulnerability_flag: bool = False
    assessable_portfolio_cents: int = Field(
        ge=0, description="Whole cents. $25,000 is 2500000, never 25000.00."
    )
    prior_crypto_purchases: int = Field(default=0, ge=0)
    structural_acks: list[str] = Field(default_factory=list)
    default_trade_amount_cents: int = Field(default=0, ge=0)
    note: str = ""

    @model_validator(mode="after")
    def _a_knowledge_assessment_cannot_be_dated_ahead(self) -> "ClientUpsert":
        """FP3-18. A check that has not happened is not a check.

        `build_snapshot` derives `knowledge_assessed_days_ago` as `as_of -
        knowledge_date`, so a date in the future produces a **negative** number
        — and every rule that asks "was this assessed within N months" reads a
        negative as comfortably inside the window. It is the laxest possible
        answer to the question, produced by the one input that should have been
        refused.

        Worse, it is durable. The snapshot is frozen on the decision row, so
        replay reproduces the impossible fact deterministically for as long as
        the record exists, and the determination looks entirely ordinary.

        Found in the seeded book: five determinations carry
        `knowledge_assessed_days_ago` of -22, -45, -112, -178 and -191, and in
        every one of them `created_at` equals `as_of` — so these are not
        backdated reconstructions, they are determinations made on the day, for
        a client whose assessment was dated later than the day. Those rows are
        left exactly as they are; rewriting stored evidence to tidy up a finding
        is the shape of the finding.

        Bounded against the *business* date rather than `as_of`: this is a write
        of a client record, which has no `as_of`, and "assessed next Tuesday" is
        wrong on any reading. The narrower question — whether a backdated
        determination should read a later assessment as current — is a semantics
        change to the snapshot builder and is recorded in the change log rather
        than made here.
        """
        if self.knowledge_date is None:
            return self

        today = business_time.platform_today()
        if self.knowledge_date > today:
            raise ValueError(
                f"knowledge_date is {self.knowledge_date.isoformat()}, which is "
                f"after today ({today.isoformat()}). A knowledge assessment that "
                "has not happened cannot be recorded as having happened: the "
                "engine derives how long ago it was from this date, and a future "
                "one produces a negative age that every currency rule reads as "
                "comfortably recent."
            )
        return self


#: What a refused client write says, and deliberately all it says.
#:
#: F5. `clients.id` is a platform-wide primary key and `decisions.client_id`
#: references it, so a firm upserting an id another firm holds sees no row under
#: row-level security, inserts, and meets a constraint that spans every tenant.
#: The `IntegrityError` escaped as a 500, which is a different answer from the
#: 200 a free id gets — and 500s carry constraint names into logs and error
#: trackers.
#:
#: One message for every integrity failure, naming no constraint, no table, no
#: tenant and no holder. A refusal that explained itself would be the same leak
#: wearing a different status code.
#:
#: **What this does not close.** A caller can still tell a refused id from an
#: accepted one, because it has to: the answer to "did my write land" is the
#: point of the endpoint. Removing that signal needs the composite key
#: `(tenant_id, id)`, which is DDL on the evidence table — recorded under
#: "Decisions requested" in docs/spec-changes.md and not attempted here.
CLIENT_REFUSED = (
    "This client record was refused and nothing was stored. Check the values "
    "and try again with a different id; if you believe the record is correct, "
    "contact support with the request id rather than retrying."
)


def unusable_facts(exc: PackError) -> str:
    """What a determination that could not be computed says, and who it points at.

    F6. `POST /v1/clients` accepts `knowledge_assessed: true` with
    `knowledge_date: null` — the CSV importer refuses exactly that pair, so the
    same book loaded two ways gets two different answers. The snapshot then
    derives a null `knowledge_assessed_days_ago`, the DSL evaluates
    `None <= 730`, and the `TypeError` arrives as a `PackError`. DSL v2's
    missing-data referral does not catch it, because the field is *present*.

    Nothing caught the `PackError` either, so the endpoint the whole product
    exists for answered 500 — with text naming the rule pack, for a record the
    API itself had accepted. Whoever read it opened rule content that was
    correct.

    The underlying detail is kept, because it names the rule and the comparison
    and that is genuinely useful once you are looking in the right place. What
    changes is that the sentence in front of it points at the client record.

    This is the handling half only. Whether a present-but-null fact should refer
    as `DATA_MISSING` under DSL v2, or be refused by `POST /v1/clients` as the
    importer already refuses it, is a question about what a determination means
    — recorded as a decision in docs/spec-changes.md rather than settled here.
    """
    return (
        "This determination could not be made from the facts on file for this "
        "client: a fact a rule needs is missing, or is not the kind of value it "
        "can be compared against. The rule content is not at fault — check the "
        f"client record. ({exc})"
    )


@router.post("/clients", summary="Create or update a client")
def upsert_client(
    payload: ClientUpsert,
    session: Session = Depends(get_session),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict[str, Any]:
    """Upsert, because an integration re-sending a book should not have to know
    which of its clients we have already seen."""
    replayed = replay_or_reserve(
        session, key=idempotency_key, endpoint="POST /v1/clients", body=payload.model_dump()
    )
    if replayed:
        return replayed["body"]

    values = payload.model_dump()
    values["residency"] = values["residency"] or values["jurisdiction"]
    values["domicile"] = values["domicile"] or values["jurisdiction"]

    existing = session.get(Client, payload.id)
    created = existing is None
    # Computed before the columns are overwritten, which is the only moment the
    # previous values still exist anywhere.
    diff = "" if existing is None else _fact_diff(existing, values)
    try:
        if existing is None:
            session.add(Client(**values))
        else:
            for column, value in values.items():
                setattr(existing, column, value)
        # Flushed here rather than left to the commit below, so the refusal is
        # raised at the statement that caused it and nothing else in this
        # request has run yet.
        session.flush()
    except IntegrityError as exc:
        session.rollback()
        raise HTTPException(409, CLIENT_REFUSED) from exc

    service.audit(
        session,
        "v1.client.upsert",
        f"client:{payload.id} ({'created' if created else 'updated'})"
        + (f" — {diff}" if diff else ""),
    )

    if diff:
        # §S8's third trigger, connected.
        #
        # The stage names three things that re-check a book: a pack version
        # becoming effective, a client profile change, and the periodic review.
        # The other two are wired into `scripts/settle_packs.py`;
        # `bulk.on_profile_change` was written, documented and unit-tested with
        # no caller anywhere — the same shape as F1, where the advance policy's
        # read path was built and never connected.
        #
        # **Gated on `diff`, not on the write.** An integration re-sends its
        # whole client list nightly and almost none of those rows have moved;
        # planning a run for each would bury the handful that matter and have
        # the queue re-deriving thousands of unchanged answers every night. The
        # condition is the same one that writes the audit diff above — the
        # engine-relevant columns actually changed — so a corrected spelling
        # re-checks nobody and a moved `loss_capacity_band` re-checks one
        # person.
        #
        # One run per changed client rather than one run per request: that is
        # what `on_profile_change` is shaped for, and its own note gives the
        # reason — a profile change is not a reason to re-check nine thousand
        # other people. Planning is two inserts and evaluates nothing; the
        # worker does the work.
        from . import bulk

        bulk.on_profile_change(
            session, client_id=payload.id, requested_by=tenancy.current_user_or_none() or ""
        )
    body = {"id": payload.id, "created": created}
    remember(
        session,
        key=idempotency_key,
        endpoint="POST /v1/clients",
        body=payload.model_dump(),
        response=body,
    )
    session.commit()
    return body


@router.get("/clients", summary="List clients")
def list_clients(
    session: Session = Depends(get_session),
    limit: int = Query(default=DEFAULT_PAGE),
    cursor: str | None = Query(default=None),
) -> dict[str, Any]:
    limit = _limit(limit)
    after = decode_cursor(cursor)
    stmt = select(Client).order_by(Client.id).limit(limit + 1)
    if after:
        stmt = stmt.where(Client.id > after)
    rows = list(session.scalars(stmt))
    return page(
        [{"id": c.id, "name": c.name, "jurisdiction": c.jurisdiction} for c in rows],
        limit,
        lambda row: row["id"],
    )


# -------------------------------------------------------------- evaluations --


class EvaluationRequest(BaseModel):
    client_id: str
    asset_id: str
    amount_cents: int | None = Field(
        default=None, ge=0, description="Whole cents. Omit to use the client's default."
    )
    as_of: date | None = Field(
        default=None,
        description=(
            "Defaults to today. A determination is made as at a date. A future "
            "date is refused; a past date requires `as_of_reason` and is "
            "recorded as a backdated determination."
        ),
    )
    as_of_reason: str | None = Field(
        default=None,
        description=(
            "Why this determination is being made as at a past date — a "
            "complaint reference, a period being re-filed. Required whenever "
            "`as_of` is earlier than today, and written to the audit trail."
        ),
    )


#: The client columns a determination is actually made from.
#:
#: F9. An update to a client wrote one audit row reading `(updated)` and nothing
#: else. An operator can raise `loss_capacity_band`, clear `vulnerability_flag`
#: or restate `assessable_portfolio_cents`, re-evaluate, and get the answer they
#: wanted — and the chain then proves that determination against facts whose
#: previous values are nowhere on file. The determination is tamper-evident; the
#: edit that enabled it was one word.
#:
#: Deliberately not every column. A corrected spelling of somebody's name is not
#: what this records, and a diff carrying every field would bury the three that
#: move outcomes. This is the set the engine reads — the facts a rule can test —
#: so a change to any of them can change a determination and a change to
#: anything else cannot.
DECISION_RELEVANT_COLUMNS = (
    "dob",
    "client_category",
    "knowledge_assessed",
    "knowledge_date",
    "loss_capacity_band",
    "vulnerability_flag",
    "assessable_portfolio_cents",
    "prior_crypto_purchases",
    "structural_acks",
    "default_trade_amount_cents",
    "jurisdiction",
    "residency",
    "domicile",
)


def _fact_diff(existing: Client, values: dict[str, Any]) -> str:
    """What is about to change among the facts a determination rests on.

    Rendered into the audit event's `subject`, which is inside the audit hash
    chain (migration 0026). A before/after recorded anywhere else would be a
    record of the change that could itself be edited without breaking anything,
    which is the shape of this finding rather than a fix for it.

    Empty when nothing decision-relevant moved, so that an integration
    re-sending its whole book nightly does not bury the rows that matter under
    thousands that do not.
    """
    changes: list[str] = []
    for column in DECISION_RELEVANT_COLUMNS:
        if column not in values:
            continue
        before = getattr(existing, column, None)
        after = values[column]
        if before == after:
            continue
        changes.append(f"{column} {before!r} -> {after!r}")
    return "; ".join(changes)


#: The audit action a backdated determination writes, in addition to the
#: ordinary one. Named so the quarterly access review can list them: "which
#: determinations were made as at a date other than the day they were made" is
#: a question a reviewer asks, and it was previously answerable only by reading
#: every decision row and comparing two dates.
BACKDATED_ACTION = "v1.evaluation.backdated"


def check_as_of(session: Session, as_of: date | None, reason: str | None) -> None:
    """Refuse a determination dated somewhere it has no business being.

    F7. `as_of` was caller-controlled and unbounded, and it chooses the pack.

    **Forward-dating does not select a pack, it rewrites the client.**
    `age_years` and `knowledge_assessed_days_ago` are both derived from `as_of`
    in `build_snapshot`, so a date far enough ahead turns a minor into an adult
    and a lapsed knowledge assessment into a current one — in a determination
    that looks entirely ordinary afterwards. There is no legitimate reading of
    "as at a date that has not happened", so it is refused outright rather than
    made explainable.

    **Backdating is legitimate and is not refused.** A determination
    reconstructed for a complaint, or a period being re-filed, is real work. What
    it must not be is anonymous: a backdated determination selects whichever pack
    was in force then, which on a regime that has since tightened a threshold is
    the laxer content — and the resulting row is indistinguishable from an
    ordinary one. So it needs a reason, and the reason goes in the audit trail.

    Raised as `HTTPException` rather than validated in the pydantic model,
    because "earlier than today" is a fact about when the request arrives rather
    than about its shape, and both the `/v1` and console handlers need the same
    answer.

    **Whose today, though.** FP3-05: this compared against `date.today()`, the
    container's calendar date, which on ECS is UTC. Reproduced at
    2026-08-27T23:30:00Z — 09:30 on the 28th in Sydney — a Sydney operator
    asking for `as_of` 2026-08-28 was told it was in the future. The firm's own
    working morning was refused as forward-dating for the first ten hours of
    every day. It takes the session so it can ask which firm is in scope.
    """
    if as_of is None:
        return

    today = business_time.business_today(session)
    if as_of > today:
        raise HTTPException(
            422,
            {
                "code": "as_of_in_the_future",
                "message": (
                    f"`as_of` is {as_of.isoformat()}, which is in the future. A "
                    "determination is a statement about facts as they stood on a "
                    "date, and the facts for that date do not exist yet — the "
                    "client's age and the currency of their knowledge assessment "
                    "are both derived from it, so a forward-dated determination "
                    "assesses somebody who does not exist yet."
                ),
            },
        )

    if as_of < today and not (reason or "").strip():
        raise HTTPException(
            422,
            {
                "code": "as_of_needs_a_reason",
                "message": (
                    f"`as_of` is {as_of.isoformat()}, earlier than today, so this "
                    "determination will be made against whichever rule pack was "
                    "in force then rather than the one in force now. That is "
                    "allowed and is sometimes necessary — but not anonymously. "
                    "Send `as_of_reason` saying why; it is written to the audit "
                    "trail and listed in the quarterly access review."
                ),
            },
        )


def _decision_body(session: Session, decision: Decision) -> dict[str, Any]:
    pack = packs_repo.by_version(
        session, decision.pack_id or "AU", decision.pack_version
    )
    from .engine import failing_reasons

    evaluation = {
        "outcome": decision.outcome,
        "rule_results": decision.rule_results["results"],
    }
    override = session.scalars(
        select(Override).where(Override.decision_id == decision.id)
    ).first()
    return {
        "id": decision.id,
        "client_id": decision.client_id,
        "asset_id": decision.asset_id,
        "as_of": decision.as_of.isoformat(),
        "outcome": decision.outcome,
        "pack": {"id": decision.pack_id, "version": decision.pack_version},
        "reasons": [
            {
                "rule_id": r["rule_id"],
                "reason_code": r["reason_code"],
                "title": r.get("reason_title", ""),
                "plain_english": r.get("reason_plain_english", ""),
                "inputs_read": r.get("inputs_read", []),
                "thresholds_used": r.get("thresholds_used", []),
            }
            for r in failing_reasons(evaluation, pack)
        ],
        "override": (
            {
                "approver": override.approver,
                "justification": override.justification,
                "at": override.created_at.isoformat(),
            }
            if override
            else None
        ),
        "evidence": {"this_hash": decision.this_hash, "prev_hash": decision.prev_hash},
    }


@router.post("/evaluations", summary="Request a determination")
def request_evaluation(
    payload: EvaluationRequest,
    session: Session = Depends(get_session),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict[str, Any]:
    """The endpoint the whole product exists for.

    **Send an `Idempotency-Key`.** A determination is written to an append-only
    evidence chain; a retry without a key writes a second one, and there is no
    way to remove it afterwards. Two records of a decision made once is not a
    cosmetic problem — it is the evidence disagreeing with itself.
    """
    endpoint = "POST /v1/evaluations"

    # Before the idempotency key is reserved: a request that is going to be
    # refused should not consume a key, or the caller's corrected retry with the
    # same key gets the refusal played back at it.
    check_as_of(session, payload.as_of, payload.as_of_reason)

    replayed = replay_or_reserve(
        session, key=idempotency_key, endpoint=endpoint, body=payload.model_dump()
    )
    if replayed:
        return replayed["body"]

    if payload.as_of is not None and payload.as_of < business_time.business_today(session):
        # A distinct action, not a note on the ordinary one. The access review
        # lists actions; a backdated determination hidden inside
        # `v1.evaluation.created` is one nobody can query for.
        service.audit(
            session,
            BACKDATED_ACTION,
            f"client:{payload.client_id} as at {payload.as_of.isoformat()} — "
            f"{(payload.as_of_reason or '').strip()}",
        )

    try:
        decision = service.evaluate(
            session,
            client_id=payload.client_id,
            asset_id=payload.asset_id,
            amount_cents=payload.amount_cents,
            as_of=payload.as_of,
        )
    except KeyError as exc:
        raise fail(404, "not_found", str(exc)) from exc
    except PackError as exc:
        # F6. Same finding as on the console path: a client record this API
        # accepted produces a fact the rules cannot compare, and the resulting
        # PackError was uncaught — a 500 blaming rule content that is correct.
        # `unprocessable` rather than `not_found`: the record exists, and what
        # cannot be done is the determination.
        raise fail(422, "unprocessable", unusable_facts(exc)) from exc

    body = _decision_body(session, decision)
    remember(
        session,
        key=idempotency_key,
        endpoint=endpoint,
        body=payload.model_dump(),
        response=body,
    )
    session.commit()
    return body


# ---------------------------------------------------------------- decisions --


@router.get("/decisions", summary="List determinations")
def list_decisions(
    session: Session = Depends(get_session),
    client_id: str | None = Query(default=None),
    outcome: str | None = Query(default=None),
    limit: int = Query(default=DEFAULT_PAGE),
    cursor: str | None = Query(default=None),
) -> dict[str, Any]:
    limit = _limit(limit)
    after = decode_cursor(cursor)

    stmt = select(Decision).order_by(Decision.id).limit(limit + 1)
    if after:
        stmt = stmt.where(Decision.id > int(after))
    if client_id:
        stmt = stmt.where(Decision.client_id == client_id)
    if outcome:
        stmt = stmt.where(Decision.outcome == outcome.upper())

    rows = list(session.scalars(stmt))
    return page(
        [
            {
                "id": d.id,
                "client_id": d.client_id,
                "asset_id": d.asset_id,
                "as_of": d.as_of.isoformat(),
                "outcome": d.outcome,
                "pack": {"id": d.pack_id, "version": d.pack_version},
            }
            for d in rows
        ],
        limit,
        lambda row: row["id"],
    )


@router.get("/decisions/{decision_id}", summary="Read one determination")
def read_decision(
    decision_id: int, session: Session = Depends(get_session)
) -> dict[str, Any]:
    decision = session.get(Decision, decision_id)
    if decision is None:
        raise fail(404, "not_found", f"No decision {decision_id} in this tenant.")
    return _decision_body(session, decision)


@router.post("/decisions/{decision_id}/replay", summary="Reproduce a determination")
def replay_decision(
    decision_id: int, session: Session = Depends(get_session)
) -> dict[str, Any]:
    """Re-evaluate a stored determination against the pack of record.

    Here because it is the product's central claim and a customer should be able
    to check it themselves rather than take our word for it. A diligence team
    that can run this against their own history is a diligence team that does not
    need to trust the sentence in the brochure.
    """
    decision = session.get(Decision, decision_id)
    if decision is None:
        raise fail(404, "not_found", f"No decision {decision_id} in this tenant.")

    result = service.replay(session, decision)
    session.commit()
    return {
        "decision_id": decision_id,
        "match": result["match"],
        "stored_outcome": result["stored_outcome"],
        "replayed_outcome": result["replayed_outcome"],
        "differences": result["differences"],
        "chain": result["chain"],
    }


# ---------------------------------------------------------------- artefacts --


@router.get("/artefacts/{artefact_id}", summary="Retrieve a generated document")
def read_artefact(
    artefact_id: int, session: Session = Depends(get_session)
) -> Response:
    row = session.get(Artefact, artefact_id)
    if row is None:
        raise fail(404, "not_found", f"No artefact {artefact_id} in this tenant.")
    # None rather than an exception when the file is gone, which is a normal
    # state rather than an error: the hosted API writes documents to the
    # container's filesystem, so every one of them predates the current machine
    # by at most a deploy. 410 rather than 404 — the artefact existed and the
    # determination behind it is unchanged, so "generate it again" is the whole
    # of the caller's move.
    pdf = artefacts.read_pdf(row.pdf_ref)
    if pdf is None:
        raise fail(
            410,
            "artefact_gone",
            "The stored file for this artefact is not present. Generate it again — "
            "the determination it was made from is unchanged.",
        )
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{row.kind}-{row.id}.pdf"'},
    )


# -------------------------------------------------------------------- queue --


@router.get("/queue", summary="Determinations awaiting a person")
def read_queue(
    session: Session = Depends(get_session),
    limit: int = Query(default=DEFAULT_PAGE),
    cursor: str | None = Query(default=None),
) -> dict[str, Any]:
    limit = _limit(limit)
    after = decode_cursor(cursor)

    stmt = (
        select(Decision)
        .where(Decision.outcome == "REFER")
        .order_by(Decision.id)
        .limit(limit + 1)
    )
    if after:
        stmt = stmt.where(Decision.id > int(after))
    rows = list(session.scalars(stmt))

    resolved = {
        o.decision_id
        for o in session.scalars(
            select(Override).where(Override.decision_id.in_([d.id for d in rows] or [0]))
        )
    }
    return page(
        [
            {
                "decision_id": d.id,
                "client_id": d.client_id,
                "as_of": d.as_of.isoformat(),
                "resolved": d.id in resolved,
            }
            for d in rows
        ],
        limit,
        lambda row: row["decision_id"],
    )


# --------------------------------------------------------------------- bulk --


class BulkRequest(BaseModel):
    pairs: list[EvaluationRequest] = Field(
        max_length=500,
        description="Up to 500 client/asset pairs. Split a larger book across calls.",
    )


@router.post("/bulk", summary="Evaluate many pairs in one call")
def bulk_evaluate(
    payload: BulkRequest,
    session: Session = Depends(get_session),
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict[str, Any]:
    """Many determinations, and a per-pair result rather than a single verdict.

    One bad pair does not fail the call, for the same reason a malformed batch
    row does not fail the file: a caller evaluating five hundred pairs and
    getting one error back has learned nothing about the other four hundred and
    ninety-nine. Each pair reports its own outcome or its own reason.
    """
    endpoint = "POST /v1/bulk"
    replayed = replay_or_reserve(
        session, key=idempotency_key, endpoint=endpoint, body=payload.model_dump()
    )
    if replayed:
        return replayed["body"]

    results = []
    for item in payload.pairs:
        try:
            decision = service.evaluate(
                session,
                client_id=item.client_id,
                asset_id=item.asset_id,
                amount_cents=item.amount_cents,
                as_of=item.as_of,
            )
            results.append(
                {
                    "client_id": item.client_id,
                    "asset_id": item.asset_id,
                    "decision_id": decision.id,
                    "outcome": decision.outcome,
                    "error": None,
                }
            )
        except (KeyError, ValueError) as exc:
            results.append(
                {
                    "client_id": item.client_id,
                    "asset_id": item.asset_id,
                    "decision_id": None,
                    "outcome": None,
                    "error": {"code": "not_found", "message": str(exc)},
                }
            )

    body = {
        "requested": len(payload.pairs),
        "evaluated": sum(1 for r in results if r["decision_id"]),
        "failed": sum(1 for r in results if r["error"]),
        "results": results,
    }
    remember(
        session,
        key=idempotency_key,
        endpoint=endpoint,
        body=payload.model_dump(),
        response=body,
    )
    session.commit()
    return body


# ----------------------------------------------------------------- webhooks --


@router.get("/webhooks/deliveries", summary="Delivery log")
def list_deliveries(
    session: Session = Depends(get_session),
    status: str | None = Query(default=None, description="`pending`, `delivered`, `dead`"),
    limit: int = Query(default=DEFAULT_PAGE),
    cursor: str | None = Query(default=None),
) -> dict[str, Any]:
    """What we tried to tell you, and how it went.

    The gate for this stage is that a dead endpoint dead-letters *visibly*, and
    this is where it is visible. A delivery that failed six times over half an
    hour is here with its last error, not gone.
    """
    from .models import WebhookDelivery

    limit = _limit(limit)
    after = decode_cursor(cursor)

    stmt = select(WebhookDelivery).order_by(WebhookDelivery.id).limit(limit + 1)
    if after:
        stmt = stmt.where(WebhookDelivery.id > after)
    if status:
        stmt = stmt.where(WebhookDelivery.status == status)
    rows = list(session.scalars(stmt))

    return page(
        [
            {
                "id": d.id,
                "event": d.event,
                "subject": d.subject,
                "status": d.status,
                "attempts": d.attempts,
                "last_status_code": d.last_status_code,
                "last_error": d.last_error,
                "created_at": d.created_at.isoformat(),
                "delivered_at": d.delivered_at.isoformat() if d.delivered_at else None,
            }
            for d in rows
        ],
        limit,
        lambda row: row["id"],
    )


# ------------------------------------------------------------------ imports --


@router.get("/imports", summary="Batch and upload history")
def list_imports(session: Session = Depends(get_session)) -> dict[str, Any]:
    from . import batch

    return {"data": batch.history(session), "has_more": False, "next_cursor": None}
