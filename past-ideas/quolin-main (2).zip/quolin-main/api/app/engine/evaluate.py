"""The evaluator. Pure: (pack, snapshot) in, outcome plus provenance out."""

from __future__ import annotations

from typing import Any

from .dsl import DATA_MISSING, MissingField, Read, _walk, evaluate_condition
from .pack import Pack

ALLOW, REFER, BLOCK = "ALLOW", "REFER", "BLOCK"
_RANK = {ALLOW: 0, REFER: 1, BLOCK: 2}


#: The provenance kind an applicability read is recorded under.
#:
#: Distinct from `field` and `calc` on purpose. Those are what a rule *tested*;
#: this is what decided whether the rule was consulted at all, and a reason card
#: that mixed them would say a rule read the asset class as part of its
#: predicate when it did not.
#:
#: F10. A rule that does not apply is currently a rule id in
#: `rules_not_applicable` and nothing else, so "why is this rule not in the
#: list" has no answer on the screen. That matters more than it sounds, because
#: `worst_of(..., default=ALLOW)` means an asset class no rule names passes
#: silently — and the first question anybody asks about a silent ALLOW is which
#: rules were considered.
APPLICABILITY = "applicability"


def rule_applies(
    rule: dict[str, Any],
    snapshot: dict[str, Any],
    thresholds: dict[str, Any],
    reads: list[Read] | None = None,
) -> bool:
    """Whether this rule has anything to say about this trade.

    Raises `MissingField` rather than answering, if the applicability condition
    itself reads a field that is not there. That is deliberate and it is the
    subtler half of the missing-data rule: answering "no, it does not apply"
    when the truth is "we cannot tell" is a silent pass, and a silent pass on
    missing data is the failure the rule exists to prevent. The caller decides
    what to do with it, which under DSL v2 is to refer.

    `reads` collects what was consulted to reach the answer, under the
    `applicability` kind. Optional and defaulted, because this function is part
    of the engine's public surface and every existing caller asks the question
    without wanting the workings.
    """
    scope = rule.get("applies_to") or {}
    collected: list[Read] = reads if reads is not None else []

    # Read through `_walk` rather than by subscript, and that is not a style
    # choice. A raw `snapshot["asset"]["class"]` raises `KeyError` on a snapshot
    # that does not carry it — straight past the missing-data machinery, out of
    # `evaluate_snapshot`, and into the caller as a crash. The two scope filters
    # were the last places in the engine still doing that, which is exactly the
    # kind of gap a fuzzer finds and a reader does not.
    classes = scope.get("asset_class")
    if classes is not None:
        found = _walk(snapshot, "asset.class")
        collected.append(Read(kind=APPLICABILITY, ref="asset.class", value=found))
        if found not in classes:
            return False

    flags = scope.get("structural_flags_any")
    if flags is not None:
        present = _walk(snapshot, "asset.structural_flags")
        collected.append(
            Read(kind=APPLICABILITY, ref="asset.structural_flags", value=present)
        )
        if not set(flags) & set(present):
            return False

    when = scope.get("when")
    if when is not None:
        # The `when` clause's own reads are collected too, and relabelled to the
        # applicability kind: they are facts that decided whether the rule was
        # consulted, not facts the rule tested.
        inner: list[Read] = []
        answer = evaluate_condition(when, snapshot, thresholds, inner)
        collected.extend(
            Read(kind=APPLICABILITY, ref=read.ref, value=read.value) for read in inner
        )
        if not answer:
            return False

    return True


def _provenance(reads: list[Read], kinds: tuple[str, ...]) -> list[dict[str, Any]]:
    """Provenance is what a rule read, not how many times it read it.

    A predicate that names the same field in two branches of an `or` reads it
    twice; showing it twice would make the reason card look confused.
    """
    seen: dict[tuple[str, str, str], dict[str, Any]] = {}
    for read in reads:
        if read.kind not in kinds:
            continue
        entry = read.as_dict()
        seen.setdefault((entry["kind"], entry["ref"], str(entry["value"])), entry)
    return list(seen.values())


def apply_rule(
    rule: dict[str, Any], snapshot: dict[str, Any], thresholds: dict[str, Any]
) -> dict[str, Any]:
    """A rule sees the snapshot and the pack's own thresholds. Nothing else."""
    reads: list[Read] = []
    passed = evaluate_condition(rule["predicate"], snapshot, thresholds, reads)
    outcome = ALLOW if passed else rule["on_fail"]

    inputs_read = _provenance(reads, ("field", "calc"))
    thresholds_used = _provenance(reads, ("threshold", "lookup"))

    return {
        "rule_id": rule["rule_id"],
        "title": rule.get("title", rule["rule_id"]),
        "passed": passed,
        "outcome": outcome,
        "reason_code": None if passed else rule["reason_code"],
        "severity": rule["severity"],
        "inputs_read": inputs_read,
        "thresholds_used": thresholds_used,
    }


def worst_of(outcomes: list[str]) -> str:
    """BLOCK > REFER > ALLOW. Commutative: max over a total order."""
    return max(outcomes, key=lambda o: _RANK[o], default=ALLOW)


def outcome_rank(outcome: str) -> int:
    """Severity as a number, so findings from several regimes sort together.

    Public because the same order has to hold across packs: a caller merging
    findings from three regimes must not form a second opinion about whether a
    BLOCK outranks a REFER.
    """
    return _RANK[outcome]


def _referred_for_missing_data(rule: dict[str, Any], path: str) -> dict[str, Any]:
    """The result a rule produces when the snapshot cannot answer it.

    REFER rather than BLOCK, because absent data is not evidence that the trade
    is wrong — it is evidence that nobody can yet say. And REFER rather than
    ALLOW for the same reason from the other side. The field is named in the
    provenance so the reason card can say which one, which is the difference
    between a refusal somebody can act on and one they can only escalate.

    The rule's own `on_fail` is deliberately ignored. A rule that would BLOCK is
    not entitled to BLOCK on a fact nobody has established.
    """
    return {
        "rule_id": rule["rule_id"],
        "title": rule.get("title", rule["rule_id"]),
        "passed": False,
        "outcome": REFER,
        "reason_code": DATA_MISSING,
        "severity": rule["severity"],
        "inputs_read": [{"kind": "missing", "ref": path, "value": None}],
        "thresholds_used": [],
    }


def evaluate_snapshot(pack: Pack, snapshot: dict[str, Any]) -> dict[str, Any]:
    """Evaluate every applicable rule, under the DSL semantics the pack declares.

    The dispatch on `pack.dsl_version` is what makes invariant 5 survive a change
    to the language rather than only to the content. A pack written against v1
    keeps v1's behaviour forever, including the behaviour Stage 3 considered a
    defect — because a determination recorded under those semantics has to
    reproduce under them, and "we fixed it later" is not a reproduction.
    """
    v2_or_later = pack.dsl_version >= 2
    results: list[dict[str, Any]] = []
    applicability: list[dict[str, Any]] = []

    for rule in pack.rules:
        try:
            asked: list[Read] = []
            applies = rule_applies(rule, snapshot, pack.thresholds, asked)
            applicability.append(
                {
                    "rule_id": rule["rule_id"],
                    "title": rule.get("title", rule["rule_id"]),
                    "applied": applies,
                    "reads": _provenance(asked, (APPLICABILITY,)),
                }
            )
            if not applies:
                continue
            results.append(apply_rule(rule, snapshot, pack.thresholds))
        except MissingField as missing:
            # v1 lets this propagate, which fails the whole determination. That
            # was the behaviour before Stage 3 and it stays available forever
            # for packs that declare v1 — see DSL_VERSIONS.
            if not v2_or_later:
                raise
            results.append(_referred_for_missing_data(rule, missing.path))

    evaluated = {r["rule_id"] for r in results}
    skipped = [r["rule_id"] for r in pack.rules if r["rule_id"] not in evaluated]

    return {
        "outcome": worst_of([r["outcome"] for r in results]),
        "rule_results": sorted(results, key=lambda r: r["rule_id"]),
        "rules_not_applicable": sorted(skipped),
        # F10. Why each rule was in or out, for a reason card.
        #
        # **A new key rather than a richer `rules_not_applicable`**, and that is
        # the whole design. `rules_not_applicable` is stored on every decision
        # and compared field-by-field by `evidence.replay`; widening it would
        # make every determination on file fail to reproduce, which
        # docs/runbooks/chain-mismatch.md says to treat as tampering.
        # `evidence.record` reads exactly two keys out of this dict, so an
        # additional one is invisible to storage and to the chain.
        #
        # Recomputed rather than recorded, and safely so: the snapshot is frozen,
        # so the same reads come back on the same facts for as long as the pack
        # of record loads.
        "applicability": sorted(applicability, key=lambda r: r["rule_id"]),
        "pack_version": pack.version,
    }


#: The one reason code whose text the engine supplies rather than the pack.
#:
#: Public, because the reporting layer needs the same fallback. Q-06 made
#: `DATA_MISSING` reachable in ordinary operation — a client with no custody
#: record refers rather than being assessed as holding nothing — and the first
#: run of the regulatory return afterwards printed a finding whose title was the
#: bare code, because `reports._reason_titles` reads pack content only and no
#: pack defines this one.
#:
#: Every other code names something a regime decided, so its wording is content
#: and lives in the pack — invariant 1. `DATA_MISSING` names something the
#: *language* decided: it is raised by the evaluator, on behalf of no regulator,
#: and a pack that had to define it would be a pack that could get it wrong or
#: omit it and render a blank reason card. A pack may still override the wording
#: by defining the code itself, because a regime that wants to say this in its
#: own words is making a content decision and that is theirs to make.
DATA_MISSING_TEXT = {
    "title": "Information missing",
    "plain_english": (
        "This check could not be completed, because a fact it depends on is not "
        "recorded for this client. The evidence names the missing field. It is "
        "referred for a person to look at rather than passed or blocked, because "
        "an absent fact is not evidence in either direction."
    ),
}


def failing_reasons(evaluation: dict[str, Any], pack: Pack) -> list[dict[str, Any]]:
    """Rules that did not pass, dressed with the pack's plain-English text."""
    out: list[dict[str, Any]] = []
    for result in evaluation["rule_results"]:
        if result["passed"]:
            continue
        text = pack.reason_codes.get(result["reason_code"], {})
        if not text and result["reason_code"] == DATA_MISSING:
            text = DATA_MISSING_TEXT
        out.append(
            {
                **result,
                "reason_title": text.get("title", result["reason_code"]),
                "reason_plain_english": text.get("plain_english", ""),
            }
        )
    return sorted(out, key=lambda r: (_RANK[r["outcome"]] * -1, r["severity"], r["rule_id"]))
