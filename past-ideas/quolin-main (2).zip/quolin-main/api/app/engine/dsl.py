"""The condition DSL used by jurisdiction packs.

Comparisons, boolean composition and table lookups only. There is deliberately
no arithmetic and no way to express arbitrary code: a pack must stay reviewable
by a non-programmer compliance specialist.

Every resolution is recorded so the UI can render a decision entirely from
stored provenance.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import asdict, dataclass
from typing import Any

#: The DSL semantics a pack is written against.
#:
#: Not the pack's own `version`, which counts revisions of its *content*. This
#: counts revisions of the *language*, and it exists so that a determination
#: made in 2026 replays in 2031 under 2026 semantics — the claim the whole
#: product rests on. The engine keeps every version it has ever shipped, and
#: `evaluate.py` dispatches on this number.
#:
#: * **1** — the language as it stood before Stage 3. A rule that reads a
#:   snapshot field which is not there raises, and the determination fails.
#: * **2** — a rule that reads an absent field produces REFER with reason code
#:   `DATA_MISSING`, naming the field. Nothing else differs.
#:
#: Changes are additive and removals are deprecations that never delete
#: evaluation support, so this list only ever grows. See docs/dsl-spec.md.
DSL_VERSIONS = (1, 2)
DEFAULT_DSL_VERSION = 1
CURRENT_DSL_VERSION = 2

#: The reason code a v2 pack reports when a rule cannot be evaluated because the
#: snapshot does not carry a field it reads. Reserved: a pack may give it a title
#: and plain-English text like any other code, but it may not mean anything else.
DATA_MISSING = "DATA_MISSING"


class PackError(ValueError):
    pass


class MissingField(PackError):
    """A rule read a snapshot field that is not there.

    A subclass rather than a flag on `PackError`, because the two are handled in
    different places and for different reasons. Every other `PackError` is a
    fault in the *pack* — an unknown op, a threshold that does not exist — and
    the right response is to refuse to load it. This one is a fault in the
    *data*, arrives at evaluation time with a real client in front of somebody,
    and under DSL v2 the right response is to refer the case to a human with the
    missing field named.
    """

    def __init__(self, path: str):
        self.path = path
        super().__init__(f"snapshot has no field {path!r}")


@dataclass(frozen=True)
class Read:
    kind: str
    ref: str
    value: Any

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _no_floats(value: Any, ref: str) -> Any:
    # Float drift breaks replay equality. Money is cents, ratios are basis points.
    if isinstance(value, float):
        raise PackError(f"float encountered at {ref!r}; use integer cents or basis points")
    return value


def _walk(root: dict[str, Any], path: str) -> Any:
    """Read a dotted path out of the snapshot, or say which one was missing.

    A present field holding `None` is *not* missing. The distinction is the one
    the missing-data rule turns on: `knowledge_assessed_days_ago` is null for a
    client who has never been assessed, and that is a fact the snapshot is
    recording rather than a hole in it. A comparison against null will fail its
    own way — see the note on `evaluate_condition`.
    """
    node: Any = root
    for part in path.split("."):
        if not isinstance(node, dict) or part not in node:
            raise MissingField(path)
        node = node[part]
    return node


def resolve(
    term: dict[str, Any],
    snapshot: dict[str, Any],
    thresholds: dict[str, Any],
    reads: list[Read],
) -> Any:
    if not isinstance(term, dict) or len(term) == 0:
        raise PackError(f"malformed term: {term!r}")

    if "const" in term:
        return _no_floats(term["const"], "const")

    if "field" in term:
        ref = term["field"]
        value = _no_floats(_walk(snapshot, ref), ref)
        reads.append(Read("field", ref, value))
        return value

    if "calc" in term:
        ref = term["calc"]
        value = _no_floats(_walk(snapshot, f"calc.{ref}"), ref)
        reads.append(Read("calc", ref, value))
        return value

    if "threshold" in term:
        ref = term["threshold"]
        if ref not in thresholds:
            raise PackError(f"pack has no threshold {ref!r}")
        value = _no_floats(thresholds[ref], ref)
        reads.append(Read("threshold", ref, value))
        return value

    if "lookup" in term:
        table_name = term["lookup"]
        table = thresholds.get(table_name)
        if not isinstance(table, dict):
            raise PackError(f"pack has no lookup table {table_name!r}")
        key = resolve(term["key"], snapshot, thresholds, reads)

        # FP3-19. `str(key)` is Python's spelling, not JSON's, and the two
        # disagree on exactly the values a lookup table is most likely to be
        # keyed on. A table keyed on a boolean had to be written `{"True": ...}`
        # — a specialist writing the JSON they were shown, `{"true": ...}`, got
        # a `PackError` at *evaluation*, after validation had passed, on a pack
        # that had already been signed.
        #
        # Canonicalised to what JSON would write, with the Python spelling
        # accepted as a fallback so no shipped pack changes behaviour. All five
        # packs in `packs/` were checked before this changed; none is keyed on a
        # boolean or a null.
        lookup_key = _json_key(key)
        if lookup_key in table:
            spelling = lookup_key
        elif str(key) in table:
            spelling = str(key)
        else:
            raise PackError(
                f"lookup table {table_name!r} has no entry for {key!r} "
                f"(looked for {lookup_key!r})"
            )
        value = _no_floats(table[spelling], table_name)
        reads.append(Read("lookup", f"{table_name}[{lookup_key}]", value))
        return value

    raise PackError(f"unknown term type: {sorted(term)}")


def _json_key(value: Any) -> str:
    """How JSON would spell this value as an object key.

    `str(True)` is `"True"` and JSON's is `"true"`; `str(None)` is `"None"` and
    JSON's is `"null"`. Numbers and strings agree. Everything else falls back to
    `str`, because a lookup keyed on a list is a pack fault the table lookup
    will report in its own words.
    """
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return "null"
    return str(value)


_BINARY: dict[str, Callable[[Any, Any], Any]] = {
    "eq": lambda a, b: a == b,
    "neq": lambda a, b: a != b,
    "lt": lambda a, b: a < b,
    "lte": lambda a, b: a <= b,
    "gt": lambda a, b: a > b,
    "gte": lambda a, b: a >= b,
    "in": lambda a, b: a in b,
    "not_in": lambda a, b: a not in b,
    "contains": lambda a, b: b in a,
    "not_contains": lambda a, b: b not in a,
}


def evaluate_condition(
    cond: dict[str, Any],
    snapshot: dict[str, Any],
    thresholds: dict[str, Any],
    reads: list[Read],
) -> bool:
    if not isinstance(cond, dict):
        raise PackError(f"condition is not an object: {cond!r}")

    op = cond.get("op")
    if op is None:
        raise PackError(f"condition has no op: {cond!r}")

    # Every part of a condition is read with `.get` and a named refusal rather
    # than by subscript. A malformed condition is a fault in the pack, and a
    # fault in a pack must arrive as `PackError` — the exception the callers
    # above know how to turn into a refusal — rather than as the `KeyError` a
    # bare subscript produces, which reads to everything upstream as a bug in
    # the engine. The validator catches these when a pack is loaded; this is the
    # second line, for a pack that reached evaluation another way.
    if op in ("and", "or"):
        branches = cond.get("of")
        if not isinstance(branches, list):
            raise PackError(f"{op!r} needs a list of conditions in 'of': {cond!r}")
        # Every branch of an `or` is evaluated, even after one has passed:
        # provenance must show what the officer would have to argue with, not
        # just the first branch that happened to succeed.
        #
        # `and` is the same, and FP3-20 / audit C-05 is the consequence: **a
        # null-guard cannot be written.** `{"and": [x != null, x <= 90]}` still
        # evaluates the second branch for a client who has never been assessed,
        # compares null with a number, and raises. Documented in
        # `docs/dsl-spec.md` §5 rather than fixed here, because short-circuiting
        # would drop the skipped branches out of `inputs_read` — which is stored
        # on every determination ever made, so every one of them would stop
        # reproducing. That is an additive DSL v3 change, not a v2 repair.
        outcomes = [evaluate_condition(c, snapshot, thresholds, reads) for c in branches]
        return all(outcomes) if op == "and" else any(outcomes)

    if op == "not":
        if "of" not in cond:
            raise PackError(f"'not' needs an 'of' condition: {cond!r}")
        return not evaluate_condition(cond["of"], snapshot, thresholds, reads)

    fn = _BINARY.get(op)
    if fn is None:
        raise PackError(f"unknown op {op!r}")

    for side in ("left", "right"):
        if side not in cond:
            raise PackError(f"{op!r} has no {side!r} operand: {cond!r}")

    left = resolve(cond["left"], snapshot, thresholds, reads)
    right = resolve(cond["right"], snapshot, thresholds, reads)
    try:
        return bool(fn(left, right))
    except TypeError as exc:
        # Comparing a number to a list, or `in` against something that is not a
        # collection. A type error is still a fault in the pack — the rule is
        # comparing two things that cannot be compared — so it is reported as
        # one, naming both sides so the author can see which is which.
        raise PackError(
            f"{op!r} cannot compare {left!r} with {right!r}: {exc}"
        ) from exc
