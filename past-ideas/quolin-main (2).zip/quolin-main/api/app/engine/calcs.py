"""The derived values a pack is allowed to name, and nothing else.

A pack cannot do arithmetic. That is the central constraint of the DSL and the
reason a compliance specialist can review one: a rule compares things, and every
number it compares is either written in the pack or computed by a function that
lives here, is named, is documented, and is individually tested.

**Why a registry rather than a dict comprehension in the snapshot builder.**
Before this stage the derived values were computed inline while building the
snapshot, which worked and had three problems. A pack naming a calc that did not
exist failed at *evaluation* with `snapshot has no field 'calc.whatever'` — a
message about an internal data structure, delivered to a specialist, at the
moment a determination was being made rather than when the pack was loaded.
Nothing listed what the available calcs were, so `docs/dsl-spec.md` could not be
written from the code and would have drifted from it. And no calc had a test of
its own; they were tested incidentally, through whichever rule happened to read
them.

Each entry below therefore carries what it needs to be reviewable as well as
computable: the inputs it reads, the unit it is expressed in, and a sentence a
non-programmer can check against a regulation. `docs/dsl-spec.md` is generated
from these fields in the sense that matters — it says the same things, and
`test_dsl_spec.py` fails when it stops doing so.

**Units are part of the contract.** `post_trade_crypto_bps` is basis points and
`post_trade_crypto_cents` is cents, and a rule comparing one to a threshold
expressed in the other is a rule that is wrong by a factor of ten thousand while
looking perfectly reasonable. The unit is recorded so the spec can state it and
so a future pack validator can check it; today it is documentation.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

#: Basis points in a whole. One per cent is 100 bps.
BPS = 10_000


class CalcError(ValueError):
    """A calc could not be computed from the inputs it was given."""


@dataclass(frozen=True)
class Calc:
    """One derived value: how to compute it, and how to explain it."""

    name: str
    unit: str
    #: The snapshot fields this reads, in dotted form, for the spec and for
    #: anybody tracing why a number came out the way it did.
    reads: tuple[str, ...]
    #: One sentence, for a reader who is checking the pack against a regulation
    #: rather than reading Python.
    description: str
    fn: Callable[..., int]


_REGISTRY: dict[str, Calc] = {}


def register(calc: Calc) -> Calc:
    if calc.name in _REGISTRY:
        raise ValueError(f"calc {calc.name!r} is already registered")
    _REGISTRY[calc.name] = calc
    return calc


def registered() -> dict[str, Calc]:
    """Every calc a pack may name. Ordered, so the spec and the error messages
    both list them the same way every time."""
    return dict(sorted(_REGISTRY.items()))


def is_registered(name: str) -> bool:
    return name in _REGISTRY


def names() -> tuple[str, ...]:
    return tuple(sorted(_REGISTRY))


# ------------------------------------------------------------------ the calcs --


def _ratio_bps(part_cents: int, whole_cents: int) -> int:
    """`part` as a share of `whole`, in basis points.

    Integer floor division throughout, which is the whole reason this is a
    function rather than an expression. A float here would drift, and a drifting
    number in a snapshot is a decision that stops replaying — invariant 3 exists
    because of exactly this arithmetic.

    A portfolio of zero is not an error and must not divide by zero. Somebody
    with no assessable portfolio who buys anything has put all of it into that
    purchase, so the answer is the whole: 10,000 bps. Buying nothing with
    nothing is zero, not undefined.
    """
    if whole_cents <= 0:
        return BPS if part_cents > 0 else 0
    return (part_cents * BPS) // whole_cents


existing_crypto_cents = register(
    Calc(
        name="existing_crypto_cents",
        unit="cents",
        reads=("positions.crypto_value_cents",),
        description=(
            "What the client already holds in crypto-assets, before this trade, "
            "as reported by custody."
        ),
        fn=lambda *, existing_cents, **_: int(existing_cents),
    )
)

post_trade_crypto_cents = register(
    Calc(
        name="post_trade_crypto_cents",
        unit="cents",
        reads=("positions.crypto_value_cents", "trade.amount_cents"),
        description=(
            "What the client would hold in crypto-assets if this trade went "
            "ahead: their existing holding plus the amount being bought."
        ),
        fn=lambda *, existing_cents, amount_cents, **_: int(existing_cents) + int(amount_cents),
    )
)

post_trade_crypto_bps = register(
    Calc(
        name="post_trade_crypto_bps",
        unit="bps",
        reads=(
            "positions.crypto_value_cents",
            "trade.amount_cents",
            "client.assessable_portfolio_cents",
        ),
        description=(
            "The share of the client's assessable portfolio that would be held "
            "in crypto-assets after this trade. This is the number a "
            "concentration limit is compared against."
        ),
        fn=lambda *, existing_cents, amount_cents, portfolio_cents, **_: _ratio_bps(
            int(existing_cents) + int(amount_cents), int(portfolio_cents)
        ),
    )
)

trade_share_bps = register(
    Calc(
        name="trade_share_bps",
        unit="bps",
        reads=("trade.amount_cents", "client.assessable_portfolio_cents"),
        description=(
            "This trade alone, as a share of the client's assessable portfolio. "
            "Distinct from the concentration figure because some regimes cap a "
            "first purchase as a proportion of the portfolio rather than as a "
            "cash sum, and a proportion and a sum have no common ordering."
        ),
        fn=lambda *, amount_cents, portfolio_cents, **_: _ratio_bps(
            int(amount_cents), int(portfolio_cents)
        ),
    )
)


#: The prefix that marks a snapshot field as coming from custody. Used to work
#: out which calcs cannot be computed when nobody has told us what a client
#: holds — read off each calc's declared `reads` rather than kept as a second
#: list, so a calc added later is classified by its own declaration.
CUSTODY_PREFIX = "positions."


def custody_dependent() -> tuple[str, ...]:
    """The calcs that cannot be computed without a custody reading.

    `trade_share_bps` is deliberately not one of them: it is this trade against
    the client's portfolio, and both of those are facts the firm supplied. A
    blanket "withhold every calc" would have referred cases that could be
    decided.
    """
    return tuple(
        name
        for name, calc in registered().items()
        if any(read.startswith(CUSTODY_PREFIX) for read in calc.reads)
    )


def compute_all(
    *,
    existing_cents: int,
    amount_cents: int,
    portfolio_cents: int,
    custody_known: bool = True,
) -> dict[str, Any]:
    """Every registered calc, for one snapshot.

    All of them, every time, rather than only the ones this pack happens to
    name. The snapshot is the frozen record of what was true, and which calcs
    a *rule* read is recorded separately in each rule's provenance — so a
    snapshot holding only the calcs one pack asked for would be a snapshot that
    could not be re-evaluated against a different pack, which is precisely what
    cross-border resolution does.

    **Except when custody has told us nothing.** Q-06: a client who arrived by
    CSV, file drop or API has no custody record, and `existing_cents` is then a
    zero meaning "nobody has said" rather than "they hold nothing". Computing a
    concentration from it produces a figure that is not merely unknown but
    fabricated — and the determination made on it is hash-chained and replays
    that way forever. One was recorded as ALLOW at 500 bps for a client whose
    real holdings nobody had asked about.

    So those calcs are withheld rather than invented. An absent snapshot field
    is a thing the language already knows how to handle: DSL v2 refers the case
    to a human and names the field. Absent custody is the same class of fact,
    and this is the smallest way to say so — no new mechanism, no new outcome,
    and rules that do not read custody still decide normally.
    """
    inputs = {
        "existing_cents": int(existing_cents),
        "amount_cents": int(amount_cents),
        "portfolio_cents": int(portfolio_cents),
    }
    withheld = () if custody_known else custody_dependent()
    computed: dict[str, Any] = {}
    for name, calc in registered().items():
        if name in withheld:
            continue
        try:
            computed[name] = calc.fn(**inputs)
        except Exception as exc:  # pragma: no cover - a registry bug, not input
            raise CalcError(f"calc {name!r} failed on {inputs!r}: {exc}") from exc
    return computed
