"""A pack is content. This module only gives it a typed shape."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any, cast

from .dsl import DEFAULT_DSL_VERSION, DSL_VERSIONS, PackError

#: Content that a named professional has reviewed and signed.
REVIEWED = "REVIEWED"
#: Content authored as a reference implementation, signatory not yet engaged.
PENDING_REVIEW = "PENDING_REVIEW"
#: Content written to exercise the architecture. Nobody has reviewed the rules.
ILLUSTRATIVE = "ILLUSTRATIVE"

CONTENT_STATUSES = (REVIEWED, PENDING_REVIEW, ILLUSTRATIVE)


@dataclass(frozen=True)
class Pack:
    pack_id: str
    version: int
    effective_from: date
    effective_to: date | None
    signed_by: str
    signed_at: str
    thresholds: dict[str, Any]
    asset_classes: dict[str, dict[str, Any]]
    rules: list[dict[str, Any]]
    reason_codes: dict[str, dict[str, str]]
    artefact_templates: dict[str, str]
    artefact_titles: dict[str, str]
    #: Which documents are about one determination and which are about a period.
    #:
    #: Content, not code. §S7's own words are "return formats are pack content,
    #: engineering is the pipeline" — so a regime that needs a document nobody
    #: has thought of yet declares it here with a template, and the pipeline
    #: renders it. The alternative, which this replaces, was a tuple of kind
    #: names in the renderer: adding a statutory document to one jurisdiction
    #: meant a deploy, and a code review of a decision the content team owns.
    #:
    #: Kinds absent from this map are per-determination, because that is what
    #: every document was before periods existed and silence should not change
    #: an existing pack's behaviour.
    artefact_scopes: dict[str, str]
    #: Which version of the condition language this pack's rules are written
    #: against. Not `version`, which counts revisions of the content.
    #:
    #: A pack that does not say is read as version 1, because every pack authored
    #: before this field existed was written against version 1 and a default of
    #: "the newest" would silently re-interpret them. The engine keeps every
    #: version forever; see DSL_VERSIONS in engine/dsl.py.
    dsl_version: int = DEFAULT_DSL_VERSION
    #: How far this pack's rule content can be trusted. A pack that does not
    #: say is treated as the weakest claim, never the strongest: content whose
    #: provenance is unstated has not been reviewed.
    content_status: str = ILLUSTRATIVE
    #: For a pack that speaks for more than one state or territory, the ones it
    #: covers. Empty means the pack covers exactly its own `pack_id`.
    covers_states: list[str] = field(default_factory=list)
    #: What to call this regime, and who writes its rules. Content, because a
    #: screen that mapped a code to a regulator's name would be holding
    #: jurisdiction knowledge outside the pack — the exact thing invariant 1
    #: forbids, only in TypeScript rather than in Python.
    jurisdiction_name: str = ""
    regulator: str = ""
    #: How this pack orders two constraints on the same dimension when it is
    #: the licensee's pack. Content, not engine code: which of two numbers is
    #: the stricter one is a question about a regime, not about arithmetic.
    precedence: dict[str, Any] = field(default_factory=dict)
    notes: str = ""
    #: Who proposed this content, and — where the signatory was also its author
    #: — who read it independently before they signed.
    #:
    #: Beside `signed_by` because they answer the same question and a document
    #: carrying only the signature answers half of it. §3.2 asks that the person
    #: who writes a rule change is not the person who attests to it; `signed_by`
    #: alone cannot show whether that held, which made the separation something
    #: a compliance officer had to reconcile against our transition log rather
    #: than read. Both empty on every pack published before migration 0049, and
    #: empty reads as "not recorded" rather than as "nobody".
    drafted_by: str = ""
    second_reviewer: str = ""
    #: The body this pack was parsed from, kept verbatim.
    #:
    #: Not for evaluation — nothing in this module reads it — but so that a
    #: determination can commit to the *content* it was decided on rather than
    #: to a version number. Q-04: `packs` had no uniqueness on
    #: `(jurisdiction, version)`, so the integer named a row that could be one
    #: of two, and a replay reading the wrong one reported a rule-outcome
    #: difference indistinguishable from the engine having changed its mind.
    #:
    #: The original bytes rather than a re-serialisation of the fields above:
    #: `from_body` deliberately ignores keys the evaluator has no use for, and a
    #: hash of what this class kept would not be a hash of what was published.
    #:
    #: `compare=False` so that adding it changes neither equality nor hashing of
    #: `Pack`, which a mutable field would otherwise break outright.
    source_body: dict[str, Any] = field(default_factory=dict, compare=False, repr=False)

    @staticmethod
    def from_body(body: dict[str, Any]) -> "Pack":
        """Build a typed pack from a stored body, or say exactly what is wrong.

        **Total over anything `json.loads` can produce.** F-03: this used to
        index and coerce the body directly — `body["pack_id"]`,
        `date.fromisoformat(body["effective_from"])`,
        `int(body.get("dsl_version", ...))` — so a malformed body left as a raw
        `KeyError`, `ValueError`, `TypeError` or `AttributeError`. Only the
        dsl_version-not-implemented case raised `PackError`.

        That is the difference between a fault and a crash, and the two are
        handled in completely different places. `evidence.replay` classifies a
        pack that will not *validate* as `PACK_INVALID_AT_REPLAY`, counts it and
        carries on; a pack that will not *parse* never reached that
        classification, because `validate` takes a `Pack` that `from_body` has
        to have built first. So a stored historical pack with
        `effective_from="not-a-date"` ended a nightly replay that had a whole
        book left to check. `main.engine_validate` has the same shape and the
        same hole.

        §S3: malformed packs and snapshots produce validation errors, never
        crashes. Every fault below names the field, because a message that says
        only "invalid pack" sends somebody to read a thousand lines of content.
        """
        if not isinstance(body, dict):
            raise PackError(
                f"a pack body must be a JSON object, not {type(body).__name__}. "
                "A stored `jsonb` column can hold a string, a number or an array, "
                "and none of them is a pack."
            )

        def where() -> str:
            # Read with `.get` and printed with `!r`, because this is the one
            # message that has to survive the pack being unidentifiable.
            return f"pack {body.get('pack_id')!r} v{body.get('version')!r}"

        def required(key: str) -> Any:
            if key not in body:
                raise PackError(f"{where()}: {key!r} is required and is missing.")
            return body[key]

        def as_text(key: str, value: Any) -> str:
            if not isinstance(value, str) or not value.strip():
                raise PackError(
                    f"{where()}: {key!r} must be a non-empty string, got {value!r}."
                )
            return value

        def as_optional_text(key: str, default: str = "") -> str:
            value = body.get(key, default)
            if value is None:
                return default
            if not isinstance(value, str):
                raise PackError(f"{where()}: {key!r} must be a string, got {value!r}.")
            return value

        def as_whole(key: str, value: Any) -> int:
            # `bool` is an `int` in Python and is not a version number.
            if isinstance(value, bool) or not isinstance(value, int):
                raise PackError(
                    f"{where()}: {key!r} must be a whole number, got {value!r}."
                )
            return value

        def as_mapping(key: str, value: Any) -> dict[str, Any]:
            if not isinstance(value, dict):
                raise PackError(
                    f"{where()}: {key!r} must be a JSON object, "
                    f"got {type(value).__name__}."
                )
            return value

        def optional_mapping(key: str) -> dict[str, Any]:
            value = body.get(key)
            if value is None:
                return {}
            return as_mapping(key, value)

        def as_sequence(key: str, value: Any) -> list[Any]:
            if not isinstance(value, list):
                raise PackError(
                    f"{where()}: {key!r} must be a JSON array, "
                    f"got {type(value).__name__}."
                )
            return value

        def as_date(key: str, value: Any, *, optional: bool) -> date | None:
            if value is None or value == "":
                if optional:
                    return None
                raise PackError(f"{where()}: {key!r} is required and is empty.")
            if not isinstance(value, str):
                raise PackError(
                    f"{where()}: {key!r} must be an ISO date string, got {value!r}."
                )
            try:
                return date.fromisoformat(value)
            except ValueError as exc:
                raise PackError(
                    f"{where()}: {key!r} is not an ISO date: {value!r}."
                ) from exc

        # `int(...)` rather than a strict type check, so a pack that has always
        # said `"dsl_version": "1"` goes on loading. What changes is that a value
        # which cannot be read as a number is a fault rather than a crash.
        raw_dsl = body.get("dsl_version", DEFAULT_DSL_VERSION)

        # FP3-19. `int()` is not a check, it is a conversion, and it converts
        # things nobody meant: `2.9` becomes 2, `True` becomes 1, and `"02"`
        # becomes 2. Each of those is a pack declaring semantics it was not
        # written against, loading quietly, and producing determinations that
        # are wrong in a way no rule result shows.
        #
        # `2.9` is the one worth naming. A specialist writing a version number
        # the way a person writes a version number gets DSL v2 semantics applied
        # to content written for something else, with no error anywhere.
        if isinstance(raw_dsl, bool) or not isinstance(raw_dsl, (int, str)):
            raise PackError(
                f"{where()}: 'dsl_version' must be a whole number, got "
                f"{raw_dsl!r} ({type(raw_dsl).__name__}). A version that has to "
                "be converted is a version somebody meant differently."
            )
        if isinstance(raw_dsl, str) and not raw_dsl.strip().lstrip("+-").isdigit():
            raise PackError(
                f"{where()}: 'dsl_version' must be a whole number, got {raw_dsl!r}."
            )
        try:
            declared = int(raw_dsl)
        except (TypeError, ValueError) as exc:
            raise PackError(
                f"{where()}: 'dsl_version' must be a whole number, got {raw_dsl!r}."
            ) from exc
        if declared not in DSL_VERSIONS:
            # Refused at load rather than at evaluation. A pack written against
            # semantics this engine does not have is a pack whose determinations
            # would be wrong in a way no rule result would show — and the likely
            # cause is a deployment running an engine older than its content,
            # which the message says so that nobody goes looking in the rules.
            raise PackError(
                f"pack {body.get('pack_id', '?')} v{body.get('version', '?')} declares "
                f"dsl_version {declared}, which this engine does not implement. "
                f"Known versions: {', '.join(str(v) for v in DSL_VERSIONS)}. "
                "This engine is older than the pack; upgrade the engine rather "
                "than lowering the pack."
            )

        pack_id = as_text("pack_id", required("pack_id"))

        asset_classes = as_mapping("asset_classes", required("asset_classes"))
        for asset_id, classification in asset_classes.items():
            as_mapping(f"asset_classes[{asset_id!r}]", classification)

        rules = as_sequence("rules", required("rules"))
        for index, rule in enumerate(rules):
            as_mapping(f"rules[{index}]", rule)

        covers = as_sequence("covers_states", body.get("covers_states") or [])
        for index, code in enumerate(covers):
            as_text(f"covers_states[{index}]", code)

        return Pack(
            pack_id=pack_id,
            version=as_whole("version", required("version")),
            effective_from=cast(
                "date",
                as_date("effective_from", required("effective_from"), optional=False),
            ),
            effective_to=as_date(
                "effective_to", body.get("effective_to"), optional=True
            ),
            signed_by=as_optional_text("signed_by"),
            signed_at=as_optional_text("signed_at"),
            drafted_by=as_optional_text("drafted_by"),
            second_reviewer=as_optional_text("second_reviewer"),
            thresholds=as_mapping("thresholds", required("thresholds")),
            asset_classes=asset_classes,
            rules=rules,
            reason_codes=optional_mapping("reason_codes"),
            artefact_templates=optional_mapping("artefact_templates"),
            artefact_titles=optional_mapping("artefact_titles"),
            artefact_scopes=optional_mapping("artefact_scopes"),
            dsl_version=declared,
            content_status=as_optional_text("content_status", ILLUSTRATIVE)
            or ILLUSTRATIVE,
            covers_states=list(covers),
            # Falls back to the code, so a pack that says nothing renders as its
            # own id rather than as a blank.
            jurisdiction_name=as_optional_text("jurisdiction_name") or pack_id,
            regulator=as_optional_text("regulator"),
            precedence=optional_mapping("precedence"),
            notes=as_optional_text("notes"),
            source_body=dict(body),
        )

    def classify(self, asset_id: str) -> dict[str, Any]:
        if asset_id not in self.asset_classes:
            raise KeyError(f"asset {asset_id!r} is not classified in pack v{self.version}")
        return self.asset_classes[asset_id]

    @property
    def is_illustrative(self) -> bool:
        """Whether a determination under this pack rests on unreviewed content.

        Screens and artefacts ask this to decide whether to carry the badge.
        The engine never asks it: an illustrative pack evaluates exactly like a
        reviewed one, because the whole claim being made is that the engine
        cannot tell them apart.
        """
        return self.content_status == ILLUSTRATIVE

    @property
    def is_production_grade(self) -> bool:
        """Whether a firm that acts on its determinations may decide on this.

        A separate property from `is_illustrative` rather than a widening of
        it, and the separation is load-bearing. `is_illustrative` is recorded
        inside `resolution.illustrative` on every cross-border determination
        ever made; broadening it to mean "anything unsigned" would make replay
        of those determinations recompute a different list from the one on
        file — a mismatch on stored evidence, which is invariant 5 broken to
        fix a different problem. The seeded demo holds decisions in exactly
        that state: a recorded list that omits a regime whose pack is
        `PENDING_REVIEW`, because under the meaning in force when the
        determination was made, it was not illustrative.

        So `is_illustrative` keeps its meaning — "this badge belongs on the
        screen" — and this answers the different question the loader asks.
        `PENDING_REVIEW` is honest content awaiting a specialist, and it is not
        something a firm which acts on its determinations may decide on.
        """
        if self.content_status != REVIEWED:
            return False
        signatory = (self.signed_by or "").strip()
        # The two placeholder conventions this repository uses. Checked by
        # shape, because the next placeholder will be spelled differently and
        # will still be a placeholder. The database enforces the same rule in
        # migration 0025; this is the second lock.
        if not signatory or signatory.startswith("["):
            return False
        return "ILLUSTRATIVE" not in signatory.upper()

    def strictness(self, scale: str) -> str | None:
        """Which direction is stricter on this scale, per this pack's content.

        Returns `lower_is_stricter`, `higher_is_stricter`, or None when the
        pack does not say — and None means the constraint is not orderable,
        which the resolver records rather than guesses around.
        """
        return cast("str | None", self.precedence.get("scales", {}).get(scale))
