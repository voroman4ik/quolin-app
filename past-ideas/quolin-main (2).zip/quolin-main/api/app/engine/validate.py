"""Everything wrong with a pack, found when it is loaded rather than when it runs.

Before this stage a pack was checked by evaluating it. A rule naming a threshold
that did not exist, an operator that was never implemented, or a calc nobody had
written raised at the moment a determination was being made — with a client on
the phone, and with a message about a Python dictionary.

That is the wrong time and the wrong audience. A pack is content, authored by a
compliance specialist and reviewed by another one, and the errors it can contain
are the ordinary errors of writing content: a typo in a threshold name, a rule
pointing at a reason code somebody renamed. Those should be found by the person
authoring it, in a sentence that names the rule and suggests the fix.

**Every message names three things**: which rule, what is wrong, and what the
valid options are. A specialist who reads `pack has no threshold
'max_crypto_concetration_bps'` has to go and find the list themselves; one who
reads that plus `did you mean max_crypto_concentration_bps?` has been handed
the answer. `difflib` is doing the suggesting, which is enough — these are
typos, not translations.

**What this does not check.** Whether the rules are *correct* — whether a
concentration limit of 8% is the right limit — is not a question any validator
can answer, and pretending otherwise would be worse than saying nothing. That is
what the signatory and `content_status` are for.
"""

from __future__ import annotations

import difflib
from collections.abc import Iterable
from datetime import date
from typing import Any

from . import calcs
from .dsl import _BINARY, DATA_MISSING, PackError
from .pack import Pack

#: The top-level snapshot sections a rule may read from. A `field` term naming
#: anything else is a typo — there is no path by which another section appears.
SNAPSHOT_SECTIONS = (
    "as_of",
    "licensee",
    "client",
    "asset",
    "jurisdictions",
    "trade",
    "positions",
    "calc",
)

#: Every field path a rule may read, declared rather than discovered.
#:
#: Declared because the validator has to answer "does this field exist" without
#: a snapshot in front of it — a pack is checked when it is loaded, which is
#: before any client has been looked at. `test_dsl.py` asserts this list against
#: a snapshot `build_snapshot` actually produced, so it cannot drift from the
#: builder without a test failing.
#:
#: Without this, a rule reading `client.net_worth_in_guineas` loaded cleanly and
#: referred every determination for missing data — correct behaviour for absent
#: *data*, and the wrong answer for a *typo*, which is a fault in the pack and
#: should be caught when it is written. The fuzzer found the gap.
SNAPSHOT_FIELDS = (
    "as_of",
    "licensee.jurisdiction",
    "client.id",
    "client.name",
    "client.scenario",
    "client.residency",
    # Whether the residency above was supplied by the firm or assumed from the
    # licence. A regime that wants to refer on an assumed residency writes that
    # rule; the engine does not decide it. See `build_snapshot`.
    "client.residency_source",
    "client.domicile",
    "client.domicile_source",
    "client.age_years",
    "client.client_category",
    "client.knowledge_assessed",
    "client.knowledge_assessed_days_ago",
    "client.loss_capacity_band",
    "client.vulnerability_flag",
    "client.assessable_portfolio_cents",
    "client.prior_crypto_purchases",
    "client.structural_acks",
    "asset.id",
    "asset.symbol",
    "asset.name",
    "asset.class",
    "asset.volatility_band",
    "asset.leverage",
    "asset.structural_flags",
    "trade.amount_cents",
    # Where the holdings behind the concentration figure came from, and as at
    # when. A rule may read these: "custody says 10%" and "10%, because nobody
    # has told us otherwise" are different findings, and a regime may reasonably
    # want to refer rather than allow on the second.
    "positions.source",
    "positions.as_at",
)

#: What each declared field holds. Declared for the same reason the paths above
#: are: a pack is checked when it is loaded, which is before any client has been
#: looked at, so there is no snapshot to inspect. `test_dsl.py` asserts this
#: against one `build_snapshot` actually produced, so it cannot drift from the
#: builder without a test failing.
#:
#: Added for Q-07 and Q-08. Without it the validator could tell that a field
#: exists and not what kind of thing it is, so `client.loss_capacity_band` could
#: be compared for equality with a boolean threshold — `3 == True` is False and
#: `1 == True` is True, silently — and `contains` could be applied to a string,
#: where it means substring rather than membership. Neither is visible to
#: somebody reading the JSON who does not think in Python.
#:
#: A nullable field is declared as the type it holds when it holds anything:
#: `knowledge_assessed_days_ago` is an integer for a client who has been
#: assessed and null for one who has not, and the missing-data rule already
#: covers the second case.
SNAPSHOT_FIELD_TYPES: dict[str, str] = {
    "as_of": "str",
    "licensee.jurisdiction": "str",
    "client.id": "str",
    "client.name": "str",
    "client.scenario": "str",
    "client.residency": "str",
    "client.residency_source": "str",
    "client.domicile": "str",
    "client.domicile_source": "str",
    "client.age_years": "int",
    "client.client_category": "str",
    "client.knowledge_assessed": "bool",
    "client.knowledge_assessed_days_ago": "int",
    "client.loss_capacity_band": "int",
    "client.vulnerability_flag": "bool",
    "client.assessable_portfolio_cents": "int",
    "client.prior_crypto_purchases": "int",
    "client.structural_acks": "list",
    "asset.id": "str",
    "asset.symbol": "str",
    "asset.name": "str",
    "asset.class": "str",
    "asset.volatility_band": "int",
    "asset.leverage": "bool",
    "asset.structural_flags": "list",
    "trade.amount_cents": "int",
    "positions.source": "str",
    "positions.as_at": "str",
}

#: The quantities this system counts in, and the word each one is spelled with.
#:
#: Q-09. `calcs.py` has recorded a unit on every derived value since it was
#: written and observed of it: "today documentation". A basis-points figure
#: compared to a cents threshold produces a verdict from two integers that
#: measure different things — 1000 bps is ten per cent and 1000 cents is ten
#: dollars — and nothing said so. SG caps a first purchase in basis points where
#: AU caps it in cents, so this is not hypothetical: the two regimes' thresholds
#: are named `first_exposure_limit_bps` and `first_exposure_limit_cents`, and
#: the suffix was the only thing that ever distinguished them.
#:
#: Read from the name rather than from a new declaration in the pack body,
#: because the names already carry it — every threshold and every quantity field
#: in every pack in this repository is spelled this way — and because adding a
#: required field to the pack format would be a change to the language, which
#: this deliberately is not.
UNITS = ("cents", "bps", "days", "years")

#: Ops that put two quantities side by side and produce a verdict from the
#: comparison. `in`, `contains` and their negations are not here: those are
#: about membership, and are checked for shape rather than for unit.
_COMPARISONS = ("eq", "neq", "lt", "lte", "gt", "gte")

#: The subset that also *orders* its operands.
_ORDERING = ("lt", "lte", "gt", "gte")

#: Paths under this section are keyed by pack id and so cannot be enumerated —
#: a cross-border rule reads `jurisdictions.HK.asset.class`, and which regimes
#: appear depends on the client rather than on the pack.
UNENUMERABLE_SECTION = "jurisdictions"

#: Outcomes a rule may declare when it fails.
OUTCOMES = ("REFER", "BLOCK")

#: What a rule's provenance has to say, when it says anything.
#:
#: §S5 asks for this per rule — source document, section, verified-by, date —
#: and is specific that it is "the database-right structuring, recorded as data,
#: not comments". That phrasing is the whole design. A note saying "per ASIC RG
#: 227 s4.2" is unsearchable, unverifiable and impossible to report on; four
#: fields are a table a specialist can be handed, sorted by verification date,
#: when somebody asks which rules have been checked this year.
#:
#: Optional on a rule, and required to be complete when present. Half a
#: provenance is worse than none: it looks like the question was answered.
PROVENANCE_FIELDS = ("source_document", "section", "verified_by", "verified_on")


def _suggest(name: str, options: Iterable[str]) -> str:
    """" Did you mean X?" when the fault looks like a typo, otherwise nothing.

    `difflib` is enough here and a spell-checker would not be. These are
    mistypings of a name the author has in front of them, not translations —
    and a suggestion that fires on anything vaguely similar is a suggestion that
    sends somebody to change a line that was correct.
    """
    close = difflib.get_close_matches(name, sorted(options), n=1, cutoff=0.6)
    return f" Did you mean {close[0]!r}?" if close else ""


class PackInvalid(PackError):
    """One or more faults in a pack, listed.

    Every fault at once rather than the first one, because a specialist fixing a
    pack should get the whole list and not discover the second problem after
    re-running the loader.
    """

    def __init__(self, pack_id: str, version: object, faults: list[str]):
        self.pack_id = pack_id
        self.faults = faults
        listed = "\n".join(f"  - {f}" for f in faults)
        super().__init__(
            f"pack {pack_id} v{version} cannot be loaded — "
            f"{len(faults)} problem(s):\n{listed}"
        )


def _unit_of(name: str) -> str | None:
    """The quantity a name declares it is counting in, if it declares one.

    Matched on whole underscore-separated words rather than as a suffix, because
    `client.knowledge_assessed_days_ago` is a number of days and does not end in
    one. A name carrying two different unit words declares nothing usable and is
    treated as unknown rather than guessed at.
    """
    tokens = set(name.rsplit(".", 1)[-1].split("_"))
    found = [unit for unit in UNITS if unit in tokens]
    return found[0] if len(found) == 1 else None


def _type_of_value(value: Any) -> str | None:
    """The kind of a literal. `bool` before `int`, and that ordering is the bug.

    `isinstance(True, int)` is True in Python, which is exactly why a boolean
    threshold slipped past a comparison with an integer field: to anything that
    asks "is this a number", it is one.
    """
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "int"
    if isinstance(value, str):
        return "str"
    if isinstance(value, list):
        return "list"
    if isinstance(value, dict):
        return "table"
    return None


def _shape_of(term: Any, pack: Pack) -> tuple[str | None, str | None]:
    """What kind of thing this operand is, and what it counts in.

    `(None, None)` means "cannot tell", and every check below treats that as
    permission. A validator that refused what it could not identify would refuse
    most of a real pack — a cross-border rule reads `jurisdictions.HK.asset.class`
    and which regimes appear depends on the client.
    """
    if not isinstance(term, dict) or not term:
        return None, None

    if "const" in term:
        # A literal has no unit and cannot be given one. It is written next to
        # the thing it is being compared with, and that is where its meaning
        # comes from.
        return _type_of_value(term["const"]), None

    if "field" in term:
        ref = str(term["field"])
        return SNAPSHOT_FIELD_TYPES.get(ref), _unit_of(ref)

    if "calc" in term:
        ref = str(term["calc"])
        registered = calcs.registered().get(ref)
        return ("int" if registered else None), (registered.unit if registered else None)

    if "threshold" in term:
        ref = str(term["threshold"])
        if ref not in pack.thresholds:
            return None, None
        return _type_of_value(pack.thresholds[ref]), _unit_of(ref)

    if "lookup" in term:
        ref = str(term["lookup"])
        table = pack.thresholds.get(ref)
        if not isinstance(table, dict) or not table:
            return None, None
        kinds = {_type_of_value(v) for v in table.values()}
        return (kinds.pop() if len(kinds) == 1 else None), _unit_of(ref)

    return None, None


def _check_operand_kinds(
    cond: dict[str, Any], op: str, *, where: str, pack: Pack, faults: list[str]
) -> None:
    """The three mistakes where everything named exists and the rule is nonsense.

    Q-07, Q-08 and Q-09. Each one loaded clean, evaluated without complaint, and
    produced a determination that meant nothing — and none of the three is
    visible to a specialist reading the JSON who does not think in Python.
    """
    left, right = cond.get("left"), cond.get("right")
    if left is None or right is None:
        return
    left_type, left_unit = _shape_of(left, pack)
    right_type, right_unit = _shape_of(right, pack)

    # Q-07. `3 == True` is False and `1 == True` is True. Mixing is the fault,
    # not booleans: comparing two booleans is an ordinary rule and stays legal.
    if op in _COMPARISONS:
        booleans = [t == "bool" for t in (left_type, right_type) if t is not None]
        if len(booleans) == 2 and booleans[0] != booleans[1]:
            other = left_type if right_type == "bool" else right_type
            faults.append(
                f"{where}: {op!r} compares a boolean with a {other}. "
                "In Python `3 == True` is False and `1 == True` is True, so this "
                "produces a determination and means nothing. Compare a boolean "
                "with a boolean, or a number with a number."
            )
        elif op in _ORDERING and "bool" in (left_type, right_type):
            faults.append(
                f"{where}: {op!r} puts a boolean in an ordering comparison. "
                "`False < 1` is True in Python and is not a thing a regulation "
                "says. Use `eq` or `neq`."
            )

        # Q-09. Two integers, two different quantities, one comparison.
        if left_unit and right_unit and left_unit != right_unit:
            faults.append(
                f"{where}: {op!r} compares two different units, {left_unit} with "
                f"{right_unit}. Both are "
                "whole numbers and they measure different things — 1000 bps is ten "
                "per cent, 1000 cents is ten dollars — so the comparison runs and "
                "the verdict is meaningless."
            )

    # Q-08. `'com' in 'complex'` is True, and is substring containment wearing
    # the shape of set membership.
    if op in ("in", "not_in") and right_type is not None and right_type != "list":
        faults.append(
            f"{where}: {op!r} tests membership of a {right_type}, not a list. "
            "Against text this is substring containment — `'com' in 'complex'` "
            "is True — which reads exactly like the rule that was meant and is "
            "not it."
        )
    if op in ("contains", "not_contains") and left_type is not None and left_type != "list":
        faults.append(
            f"{where}: {op!r} reads its left operand as the collection, and this "
            f"one is a {left_type} rather than a list. Against text it tests for a "
            "substring rather than for membership."
        )


def _check_term(term: Any, *, where: str, pack: Pack, faults: list[str]) -> None:
    """One operand of one comparison."""
    if not isinstance(term, dict) or not term:
        faults.append(f"{where}: expected a term like {{'field': ...}}, got {term!r}")
        return

    if "const" in term:
        if isinstance(term["const"], float):
            faults.append(
                f"{where}: constant {term['const']!r} is a decimal number. Money is "
                "whole cents and proportions are basis points, so that a stored "
                "decision reproduces exactly years later (invariant 3)."
            )
        return

    if "field" in term:
        ref = str(term["field"])
        section = ref.split(".")[0]
        if section not in SNAPSHOT_SECTIONS:
            faults.append(
                f"{where}: reads {ref!r}, but {section!r} is not part of the "
                f"snapshot. Available sections: {', '.join(SNAPSHOT_SECTIONS)}."
                + _suggest(section, SNAPSHOT_SECTIONS)
            )
        elif section == "calc":
            faults.append(
                f"{where}: reads {ref!r} as a field. Derived values are named with "
                f"{{'calc': {ref.split('.', 1)[-1]!r}}} rather than as a field path."
            )
        elif section != UNENUMERABLE_SECTION and ref not in SNAPSHOT_FIELDS:
            faults.append(
                f"{where}: reads {ref!r}, which the snapshot does not contain. A "
                "rule reading a field that never exists would refer every "
                "determination for missing data." + _suggest(ref, SNAPSHOT_FIELDS)
            )
        return

    if "calc" in term:
        ref = str(term["calc"])
        if not calcs.is_registered(ref):
            faults.append(
                f"{where}: names the derived value {ref!r}, which does not exist. "
                f"A pack may only use registered values: {', '.join(calcs.names())}."
                + _suggest(ref, calcs.names())
            )
        return

    if "threshold" in term:
        ref = str(term["threshold"])
        if ref not in pack.thresholds:
            faults.append(
                f"{where}: names the threshold {ref!r}, which this pack does not "
                "define." + _suggest(ref, pack.thresholds)
            )
        return

    if "lookup" in term:
        ref = str(term["lookup"])
        table = pack.thresholds.get(ref)
        if not isinstance(table, dict):
            faults.append(
                f"{where}: names the lookup table {ref!r}, which this pack does not "
                "define as a table." + _suggest(ref, pack.thresholds)
            )
        if "key" not in term:
            faults.append(f"{where}: lookup {ref!r} has no 'key' saying what to look up.")
        else:
            _check_term(term["key"], where=f"{where} → lookup key", pack=pack, faults=faults)
        return

    faults.append(
        f"{where}: {sorted(term)} is not a kind of term. Use one of: const, field, "
        "calc, threshold, lookup."
    )


def _check_condition(cond: Any, *, where: str, pack: Pack, faults: list[str]) -> None:
    if not isinstance(cond, dict):
        faults.append(f"{where}: expected a condition, got {cond!r}")
        return

    op = cond.get("op")
    if op is None:
        faults.append(f"{where}: condition has no 'op'.")
        return

    if op in ("and", "or"):
        branches = cond.get("of")
        if not isinstance(branches, list) or not branches:
            faults.append(f"{where}: {op!r} needs a non-empty 'of' list of conditions.")
            return
        for i, branch in enumerate(branches):
            _check_condition(branch, where=f"{where} → {op}[{i}]", pack=pack, faults=faults)
        return

    if op == "not":
        if "of" not in cond:
            faults.append(f"{where}: 'not' needs an 'of' condition.")
            return
        _check_condition(cond["of"], where=f"{where} → not", pack=pack, faults=faults)
        return

    if op not in _BINARY:
        faults.append(
            f"{where}: {op!r} is not an operator. Available: "
            f"{', '.join(sorted(_BINARY))}, and, or, not." + _suggest(op, _BINARY)
        )
        # Falls through rather than returning. The operands of a comparison with
        # a misspelled operator are still operands, and a specialist who fixes
        # the operator only to be told about the field name on the next run has
        # been made to do two passes over one line.

    for side in ("left", "right"):
        if side not in cond:
            faults.append(f"{where}: {op!r} has no {side!r} operand.")
        else:
            _check_term(cond[side], where=f"{where} → {side}", pack=pack, faults=faults)

    # After the operands are known to name real things, and only for an operator
    # that exists. Reporting that a boolean was compared with an integer under
    # an operator the engine does not have would be two complaints about one
    # line, and the second is not the one to fix first.
    if op in _BINARY:
        _check_operand_kinds(cond, op, where=where, pack=pack, faults=faults)


def _looks_numeric(value: str) -> bool:
    """Whether this text is a number wearing quotes.

    Deliberately generous about what counts — a leading minus, a decimal point,
    surrounding whitespace — because the question is "did somebody mean a
    number here", and every one of those forms means yes.
    """
    try:
        float(value.strip())
    except (TypeError, ValueError):
        return False
    return True


def _no_decimal_thresholds(pack: Pack) -> list[str]:
    """No threshold value is a decimal number or a number in quotes.

    Checked across the whole table rather than only where a rule reaches, and the
    difference matters. The evaluator refuses a float when it *reads* one, so an
    unread decimal threshold produces no wrong determination today — it waits.
    The rule that reads it gets written next quarter by somebody who has no
    reason to look at the number's type, and the failure surfaces then, as a
    refused determination rather than as a pack that would not load.

    Found by the property suite, which generated a pack with a decimal threshold
    that happened to be scoped out of every rule and therefore produced a
    perfectly ordinary determination.
    """
    faults = []

    def walk(node: Any, path: str) -> None:
        if isinstance(node, float):
            faults.append(
                f"threshold {path!r} is the decimal number {node!r}. Money is whole "
                "cents and proportions are basis points (invariant 3). Nothing reads "
                "it wrongly today, but the rule that reads it next will fail."
            )
        elif isinstance(node, str) and _looks_numeric(node):
            # A number that lost its type. `"500"` and `500` compare differently
            # against an integer, and `"5.5"` is a decimal wearing a disguise
            # that the float check above cannot see.
            #
            # Found in the workbench: typing a decimal into a threshold produced
            # a string, the float check passed it, and the fault only appeared
            # at evaluation — which is the moment this whole validator exists to
            # move away from. A threshold that is genuinely text (a category
            # name, a code) is untouched, because it does not parse as a number.
            faults.append(
                f"threshold {path!r} is the text {node!r} rather than a number. A "
                "quoted number compares as text — `\"500\"` is not 500 — so a rule "
                "reading it would fail or, worse, compare wrongly. Money is whole "
                "cents and proportions are whole basis points."
            )
        elif isinstance(node, dict):
            for key, value in node.items():
                walk(value, f"{path}[{key}]")
        elif isinstance(node, list):
            for i, value in enumerate(node):
                walk(value, f"{path}[{i}]")

    for name, value in pack.thresholds.items():
        walk(value, name)
    return faults


def _check_provenance(rule: dict[str, Any], where: str) -> list[str]:
    """A rule's provenance is complete, or absent. Never half.

    Absent is legitimate — illustrative content has no source document, and
    pretending otherwise would be the exact dishonesty `content_status` exists to
    prevent. What is refused is a partial one, because a rule carrying a source
    document and no verifier reads as checked when nobody has checked it.

    `verified_on` is required to be a date rather than free text so that "which
    rules have not been verified since the last amendment" is a query rather
    than a reading exercise.
    """
    provenance = rule.get("provenance")
    if provenance is None:
        return []
    if not isinstance(provenance, dict):
        return [f"{where}: 'provenance' should be an object, got {provenance!r}"]

    faults = []
    missing = [f for f in PROVENANCE_FIELDS if not str(provenance.get(f, "")).strip()]
    if missing:
        faults.append(
            f"{where}: provenance is incomplete — {', '.join(missing)} missing. A rule "
            "with a source document and no verifier reads as checked when nobody has "
            "checked it, so provenance is all four fields or none."
        )

    on = str(provenance.get("verified_on", "")).strip()
    if on:
        try:
            date.fromisoformat(on)
        except ValueError:
            faults.append(
                f"{where}: provenance 'verified_on' is {on!r}, which is not a date "
                "(expected YYYY-MM-DD). It is a date so that "
                "\"which rules have not been verified since the amendment\" is a "
                "query rather than a reading exercise."
            )

    unknown = sorted(set(provenance) - set(PROVENANCE_FIELDS) - {"note"})
    if unknown:
        faults.append(
            f"{where}: provenance names {', '.join(unknown)}, which is not part of it. "
            f"The fields are: {', '.join(PROVENANCE_FIELDS)}, and an optional 'note'."
        )
    return faults


def _lookups_keyed_by(rules: list[Any], field: str) -> set[str]:
    """Every lookup table in these rules whose key is the named snapshot field."""
    found: set[str] = set()

    def walk(node: Any) -> None:
        if isinstance(node, list):
            for item in node:
                walk(item)
            return
        if not isinstance(node, dict):
            return
        if "lookup" in node and node.get("key") == {"field": field}:
            found.add(str(node["lookup"]))
        for value in node.values():
            walk(value)

    walk(rules)
    return found


def _lookup_tables_cover_every_class(pack: Pack) -> list[str]:
    """A table keyed by asset class must have a row for every class the pack uses.

    A gap here is not a typo and would not be caught by any of the checks above:
    every name resolves, every operator exists, and the pack loads. It fails only
    when somebody trades the one asset whose class is missing — as a crash, mid
    determination, in whichever regime the gap is in.

    Adding a new asset class to `asset_classes` and forgetting one of the tables
    is exactly how it happens, which is why this is checked from the classes
    rather than from the tables.
    """
    used = {str(entry.get("class")) for entry in pack.asset_classes.values()}
    faults = []
    for table_name in sorted(_lookups_keyed_by(pack.rules, "asset.class")):
        table = pack.thresholds.get(table_name)
        if not isinstance(table, dict):
            continue  # already reported as a missing table
        for missing in sorted(used - set(table)):
            faults.append(
                f"lookup table {table_name!r} has no entry for the asset class "
                f"{missing!r}, which this pack classifies assets into. A trade in "
                "such an asset would fail rather than be decided."
            )
    return faults


def validate(pack: Pack) -> list[str]:
    """Every fault in this pack, as sentences. Empty means it will load and run.

    Returned rather than raised so that a caller listing problems across a whole
    directory of packs can do so in one pass. `check` is the raising form.
    """
    faults: list[str] = []
    seen_ids: set[str] = set()

    if not pack.rules:
        faults.append("the pack defines no rules, so every trade would be allowed.")

    faults.extend(_no_decimal_thresholds(pack))
    faults.extend(_lookup_tables_cover_every_class(pack))

    for index, rule in enumerate(pack.rules):
        if not isinstance(rule, dict):
            faults.append(f"rule[{index}]: expected an object, got {rule!r}")
            continue

        # The identifier, checked for type and then used — as itself — for both
        # the duplicate test and the record of what has been seen.
        #
        # This read `rule_id in seen_ids` against the raw value and stored
        # `str(rule_id)`, which is two defects in one line and both of them
        # real. A list-valued `rule_id` raised `TypeError: unhashable type` out
        # of the validator, where §S3 requires a validation fault; and two rules
        # numbered `1` never collided, because `1 in {"1"}` is False — so a pack
        # with two rules sharing an id loaded, and one of them was invisible in
        # the evidence, which is precisely what the duplicate check exists to
        # prevent.
        #
        # Normalising both sides would have fixed the crash and kept the second
        # defect wearing a different hat: `1` and `"1"` would then be *one* rule
        # id, so a pack could name a rule two ways and a determination's
        # evidence would key on whichever spelling the writer happened to use.
        # A rule id is a string. Anything else is a fault that names the type.
        raw_id = rule.get("rule_id")
        rule_id: str | None = None
        if raw_id is None or raw_id == "":
            faults.append(f"rule[{index}]: has no 'rule_id'.")
        elif not isinstance(raw_id, str):
            faults.append(
                f"rule[{index}]: 'rule_id' is a {type(raw_id).__name__} ({raw_id!r}), "
                "and a rule id must be a string. Results are keyed by it and it is "
                "printed into evidence, so `1` and \"1\" must not be two spellings of "
                "one rule."
            )
        else:
            rule_id = raw_id

        where = f"rule {rule_id!r}" if rule_id else f"rule[{index}]"

        if rule_id is not None:
            if rule_id in seen_ids:
                faults.append(
                    f"{where}: two rules share this id. Results are keyed by rule id, "
                    "so one of them would be invisible in the evidence."
                )
            else:
                seen_ids.add(rule_id)

        on_fail = rule.get("on_fail")
        if on_fail not in OUTCOMES:
            faults.append(
                f"{where}: 'on_fail' is {on_fail!r}; it must be one of "
                f"{', '.join(OUTCOMES)}. A rule that passes needs no outcome, and a "
                "rule cannot allow on failure."
            )

        if not rule.get("severity"):
            faults.append(f"{where}: has no 'severity'.")

        # The same class of defect, and the second instance of it in this file.
        # `pack.reason_codes` is a mapping, so `reason_code not in
        # pack.reason_codes` hashes the raw value — a list-valued reason code
        # raised `TypeError: unhashable type` here exactly as it did above,
        # while `_suggest(str(reason_code), ...)` normalised for the message
        # only. Type-checked first, so the membership test below always has a
        # string in front of it.
        reason_code = rule.get("reason_code")
        if reason_code is None or reason_code == "":
            faults.append(f"{where}: has no 'reason_code', so a refusal would name nothing.")
        elif not isinstance(reason_code, str):
            faults.append(
                f"{where}: 'reason_code' is a {type(reason_code).__name__} "
                f"({reason_code!r}), and a reason code must be a string. It is the "
                "key a refusal's explanation is looked up by and the text a client "
                "reads on a blocked trade."
            )
        elif reason_code == DATA_MISSING:
            faults.append(
                f"{where}: uses the reserved reason code {DATA_MISSING!r}, which the "
                "engine raises when the snapshot cannot answer a rule. A rule may not "
                "claim it for anything else."
            )
        elif reason_code not in pack.reason_codes:
            faults.append(
                f"{where}: fails with reason code {reason_code!r}, which the pack does "
                "not define, so the refusal would print no explanation."
                + _suggest(reason_code, pack.reason_codes)
            )

        if "predicate" not in rule:
            faults.append(f"{where}: has no 'predicate', so there is nothing to check.")
        else:
            _check_condition(
                rule["predicate"], where=f"{where} predicate", pack=pack, faults=faults
            )

        faults.extend(_check_provenance(rule, where))

        scope = rule.get("applies_to") or {}
        if not isinstance(scope, dict):
            faults.append(f"{where}: 'applies_to' should be an object, got {scope!r}")
        elif scope.get("when") is not None:
            _check_condition(
                scope["when"], where=f"{where} applies_to.when", pack=pack, faults=faults
            )

    return faults


def check(pack: Pack) -> Pack:
    """Raise `PackInvalid` unless this pack is loadable. Returns it for chaining."""
    faults = validate(pack)
    if faults:
        raise PackInvalid(pack.pack_id, pack.version, faults)
    return pack
