"""Cross-border conflict resolution.

When more than one regime reaches a client, something has to say what actually
governs. This module does that, and it does it without knowing the name of a
single jurisdiction: it groups constraints by the dimension the packs declare,
orders them using the direction the governing pack's `precedence` block states,
and — this is the part that matters — refuses to order two constraints that the
content gives it no basis to order.

A fake ordering would be worse than none. A compliance officer can defend "both
of these bind and neither is stricter than the other". Nobody can defend a
number that came from an engine's guess about which regulator is tougher.
"""

from __future__ import annotations

from typing import Any

from .dsl import PackError, resolve
from .evaluate import ALLOW, worst_of
from .pack import Pack

#: Why a set of constraints on one dimension could not be put in order.
NO_COMMON_SCALE = "no_common_scale"
NOT_ORDERABLE = "scale_not_orderable"
SINGLE_CONSTRAINT = "single_constraint"

LOWER = "lower_is_stricter"
HIGHER = "higher_is_stricter"


def applicable_codes(snapshot: dict[str, Any]) -> list[str]:
    """The jurisdiction codes a determination has to answer to.

    Licensee first — it is the one that governs artefacts and precedence —
    then residency, then domicile. Order is stable so the recorded provenance
    is stable, and duplicates collapse: most clients are all three at once.
    """
    codes = [
        snapshot.get("licensee", {}).get("jurisdiction"),
        snapshot.get("client", {}).get("residency"),
        snapshot.get("client", {}).get("domicile"),
    ]
    seen: list[str] = []
    for code in codes:
        if code and code not in seen:
            seen.append(code)
    return seen


def code_basis(snapshot: dict[str, Any]) -> dict[str, list[str]]:
    """Which of the three facts named each jurisdiction code.

    Recorded so a panel can say *why* a regime applied, not merely that it did.
    "Because the client lives there" and "because your licence is there" are
    different arguments to have with a regulator.
    """
    pairs = [
        (snapshot.get("licensee", {}).get("jurisdiction"), "licensee"),
        (snapshot.get("client", {}).get("residency"), "residency"),
        (snapshot.get("client", {}).get("domicile"), "domicile"),
    ]
    basis: dict[str, list[str]] = {}
    for code, why in pairs:
        if code:
            basis.setdefault(code, []).append(why)
    return basis


def basis_for(code_to_basis: dict[str, list[str]], pack: Pack) -> list[str]:
    """Why this pack is in play: which of the three facts pulled it in."""
    reasons: list[str] = []
    for code, why in code_to_basis.items():
        if code == pack.pack_id or code in pack.covers_states:
            for reason in why:
                if reason not in reasons:
                    reasons.append(reason)
    return reasons


def match_packs(codes: list[str], available: dict[str, Pack]) -> tuple[list[Pack], list[str]]:
    """Match jurisdiction codes to packs, including packs that cover a bloc.

    A pack answers for a code when the code is its own id or appears in its
    `covers_states`. That is the whole of the "one pack, thirty states" claim,
    and it is content: this function never names a bloc.

    Returns the matched packs and the codes nothing matched. Unmatched codes
    are returned rather than dropped — a regime with no pack is a gap in
    coverage, and a gap that is not shown is a gap nobody closes.
    """
    matched: list[Pack] = []
    unmatched: list[str] = []
    for code in codes:
        found = next(
            (p for p in available.values() if code == p.pack_id or code in p.covers_states),
            None,
        )
        if found is None:
            unmatched.append(code)
        elif found.pack_id not in {p.pack_id for p in matched}:
            matched.append(found)
    return matched, unmatched


def select_packs(
    snapshot: dict[str, Any], available: dict[str, Pack]
) -> tuple[list[Pack], list[str]]:
    """The packs a frozen snapshot answers to, derived from the snapshot alone.

    Deriving this from the snapshot rather than from the client record is what
    makes a cross-border decision replayable: the three facts that pull a regime
    in are frozen, so the same packs are selected on replay as on the day.
    """
    return match_packs(applicable_codes(snapshot), available)


def view_for(snapshot: dict[str, Any], pack: Pack) -> dict[str, Any]:
    """The snapshot as this pack sees it.

    Only the asset classification differs between regimes — one regulator's
    major asset is another's complex product — and the alternative
    classifications are frozen into the snapshot at `jurisdictions`, so replay
    reads back exactly the classification each pack was evaluated against.
    """
    alt = (snapshot.get("jurisdictions") or {}).get(pack.pack_id)
    if not alt or "asset" not in alt:
        return snapshot
    return {**snapshot, "asset": alt["asset"]}


def _magnitude(pack: Pack, rule: dict[str, Any], view: dict[str, Any]) -> Any:
    """Resolve a constraint's magnitude through the same DSL the rule used.

    Not read back out of the rule result's provenance, because a short-circuited
    boolean may never have read it. Resolving it here uses the same terms, the
    same thresholds and the same frozen snapshot, so the number compared is the
    number the rule would have compared.
    """
    term = (rule.get("constraint") or {}).get("magnitude")
    if term is None:
        return None
    try:
        return resolve(term, view, pack.thresholds, [])
    except PackError:
        # A magnitude that will not resolve is not a magnitude. Say so by
        # returning nothing rather than substituting a number nobody wrote.
        return None


def _names(entries: list[dict[str, Any]]) -> str:
    """`AU`, `AU and HK`, `AU, HK and SG` — read aloud without stumbling."""
    codes = [e["jurisdiction"] for e in entries]
    if len(codes) <= 1:
        return "".join(codes)
    return f"{', '.join(codes[:-1])} and {codes[-1]}"


def _rationale(
    dimension: str,
    direction: str | None,
    binding: list[dict[str, Any]],
    others: list[dict[str, Any]],
    reason: str | None,
    scales: list[str],
    governing: Pack,
) -> str:
    """One sentence a compliance officer could read into a file note.

    Written from what actually happened rather than from a template with a hole
    in it. Three regimes that agree on a limit did not fail to be ordered, and a
    single constraint on a scale nobody declared a direction for is not the same
    event as two constraints measured in different units — saying either of
    those with the other's words would misdescribe the record it is attached to.
    """
    subject = dimension.replace("_", " ")
    names = _names(binding)

    def phrase(entry: dict[str, Any]) -> str:
        return f"{entry['jurisdiction']} {entry['magnitude']}"

    if direction is None:
        # Two distinguishable failures, and the difference is the whole point.
        if reason == NO_COMMON_SCALE:
            return (
                f"{names} each state a {subject} constraint, measured in "
                f"{' and '.join(scales)}. Those are not the same kind of quantity, so "
                "neither can be called the stricter, and no ordering was attempted. "
                "Each is recorded as independently binding."
            )
        declared = f"{governing.pack_id} v{governing.version}"
        scale_word = scales[0] if len(scales) == 1 else " and ".join(scales)
        if len(binding) == 1:
            return (
                f"{names} states a {subject} constraint on the {scale_word} scale, which the "
                f"governing pack ({declared}) declares no direction for. Nothing was ordered "
                "against it and it binds on its own terms."
            )
        return (
            f"{names} each state a {subject} constraint on the {scale_word} scale, which the "
            f"governing pack ({declared}) declares no direction for. No ordering was "
            "possible, so each is recorded as independently binding."
        )

    word = "lower" if direction == LOWER else "higher"

    if not others:
        if len(binding) == 1:
            return (
                f"Only {names} constrains {subject}; there was nothing to order it against."
            )
        # Everything binds. Either they agree, or every one of them failed.
        magnitudes = {e["magnitude"] for e in binding}
        if len(magnitudes) == 1:
            return (
                f"{names} each set {binding[0]['magnitude']} {scales[0]} on {subject} — the "
                "same limit in every regime that states one, so none is stricter than "
                "another and all of them bind."
            )
        return (
            f"{'; '.join(phrase(e) for e in binding)}. On this scale {word} is stricter, "
            "but every one of these rules failed, and a failure is not set aside by another "
            "regime being stricter. All of them bind."
        )

    return (
        f"{'; '.join(phrase(e) for e in binding)} against {'; '.join(phrase(e) for e in others)}. "
        f"On this scale {word} is stricter, so "
        f"{', '.join(e['jurisdiction'] for e in binding)} binds."
    )


def _resolve_dimension(
    dimension: str,
    entries: list[dict[str, Any]],
    governing: Pack,
) -> dict[str, Any]:
    """Order one dimension's constraints, or record honestly that we could not."""
    scales = sorted({e["scale"] for e in entries})
    direction = governing.strictness(scales[0]) if len(scales) == 1 else None
    reason = None

    if len(scales) > 1:
        reason = NO_COMMON_SCALE
    elif direction is None:
        reason = NOT_ORDERABLE

    comparable = [e for e in entries if e["magnitude"] is not None]
    if direction is not None and len(comparable) != len(entries):
        # Some constraint on an orderable scale had no resolvable magnitude.
        # Ordering a subset and presenting it as the answer would hide the rest.
        direction, reason = None, NOT_ORDERABLE

    if direction is None:
        failing = [e for e in entries if not e["passed"]]
        binding = failing or entries
        return {
            "dimension": dimension,
            "orderable": False,
            "ordering": "none",
            "reason": reason,
            "scales": sorted({e["scale"] for e in entries}),
            "direction": None,
            "binding": binding,
            "evaluated_not_binding": [e for e in entries if e not in binding],
            "rationale": _rationale(
                dimension, None, binding, [], reason, scales, governing
            ),
        }

    single = SINGLE_CONSTRAINT if len(entries) == 1 else None
    pick = min if direction == LOWER else max
    strictest = pick(e["magnitude"] for e in entries)
    # The strictest constraint governs the dimension; any regime whose own rule
    # failed also binds, even if its number was the laxer one. A failure is not
    # made irrelevant by someone else being stricter.
    binding = [e for e in entries if e["magnitude"] == strictest or not e["passed"]]
    others = [e for e in entries if e not in binding]

    return {
        "dimension": dimension,
        "orderable": True,
        "ordering": direction,
        "reason": single,
        "scales": scales,
        "direction": direction,
        "binding": binding,
        "evaluated_not_binding": others,
        "rationale": _rationale(
            dimension, direction, binding, others, single, scales, governing
        ),
    }


def resolve_across(
    *,
    snapshot: dict[str, Any],
    evaluations: list[tuple[Pack, dict[str, Any]]],
    governing: Pack,
) -> dict[str, Any]:
    """Combine per-pack evaluations into one determination, with provenance.

    `evaluations` is every applicable pack paired with what it decided on its
    own. Nothing here re-runs a rule: this reads results and the constraint
    metadata the packs declare, so the resolution can never disagree with the
    evaluations it is built from.

    Everything in the returned dict is a function of the frozen snapshot and
    these evaluations, and of nothing else. That is not a stylistic preference:
    the resolution is inside the hash and replay has to rebuild it byte for
    byte, so a field that quietly depended on today's pack shelf would break
    invariant 5 the first time the shelf changed.
    """
    by_dimension: dict[str, list[dict[str, Any]]] = {}
    not_applicable: list[dict[str, Any]] = []

    for pack, evaluation in evaluations:
        view = view_for(snapshot, pack)
        rules = {r["rule_id"]: r for r in pack.rules}
        skipped = set(evaluation["rules_not_applicable"])

        for rule_id in sorted(skipped):
            constraint = (rules[rule_id].get("constraint") or {})
            not_applicable.append(
                {
                    "jurisdiction": pack.pack_id,
                    "rule_id": rule_id,
                    "dimension": constraint.get("dimension"),
                    "title": rules[rule_id].get("title", rule_id),
                }
            )

        for result in evaluation["rule_results"]:
            rule = rules[result["rule_id"]]
            constraint = rule.get("constraint") or {}
            dimension = constraint.get("dimension")
            if not dimension:
                # A rule that declares no dimension is still evaluated and still
                # counts towards the outcome; it simply cannot take part in a
                # comparison. Recorded, not silently dropped.
                not_applicable.append(
                    {
                        "jurisdiction": pack.pack_id,
                        "rule_id": result["rule_id"],
                        "dimension": None,
                        "title": result["title"],
                        "note": "no constraint dimension declared",
                    }
                )
                continue
            by_dimension.setdefault(dimension, []).append(
                {
                    "jurisdiction": pack.pack_id,
                    "pack_version": pack.version,
                    "rule_id": result["rule_id"],
                    "title": result["title"],
                    "scale": constraint.get("scale", "qualitative"),
                    "magnitude": _magnitude(pack, rule, view),
                    "passed": result["passed"],
                    "outcome": result["outcome"],
                    "reason_code": result["reason_code"],
                }
            )

    dimensions = [
        _resolve_dimension(name, entries, governing)
        for name, entries in sorted(by_dimension.items())
    ]

    # Pack selection re-derived from the snapshot and the packs that applied,
    # rather than passed in by the caller. A code nothing here answers for is a
    # code nothing answered for on the day, so the coverage gap reproduces too.
    requested = applicable_codes(snapshot)
    packs = {pack.pack_id: pack for pack, _ in evaluations}
    matched, unmatched = match_packs(requested, packs)
    basis = code_basis(snapshot)

    return {
        "outcome": worst_of([e["outcome"] for _, e in evaluations] or [ALLOW]),
        "outcome_by_jurisdiction": {
            pack.pack_id: evaluation["outcome"] for pack, evaluation in evaluations
        },
        "governing": {"jurisdiction": governing.pack_id, "pack_version": governing.version},
        "precedence_source": {
            "jurisdiction": governing.pack_id,
            "pack_version": governing.version,
            "note": (
                "Ordering follows the governing pack's precedence block. Which pack "
                "supplies it is itself part of the record."
            ),
        },
        "dimensions": dimensions,
        "rules_not_applicable": not_applicable,
        "unordered_dimensions": [d["dimension"] for d in dimensions if not d["orderable"]],
        "illustrative": sorted(p.pack_id for p, _ in evaluations if p.is_illustrative),
        "requested": requested,
        "applicable": [
            {
                "jurisdiction": pack.pack_id,
                "pack_version": pack.version,
                "content_status": pack.content_status,
                "covers_states": pack.covers_states,
                "basis": basis_for(basis, pack),
                # Identity, not an id comparison: `matched` is drawn from the
                # very objects `evaluations` carries, and the governing pack is
                # always one of them.
                "governing": pack is governing,
            }
            for pack in matched
        ],
        # A regime with no pack is a hole in coverage, and it is stated on the
        # decision rather than left for someone to notice later.
        "unmatched": unmatched,
    }


__all__ = [
    "applicable_codes",
    "basis_for",
    "code_basis",
    "match_packs",
    "select_packs",
    "view_for",
    "resolve_across",
    "NO_COMMON_SCALE",
    "NOT_ORDERABLE",
    "SINGLE_CONSTRAINT",
    "LOWER",
    "HIGHER",
]
