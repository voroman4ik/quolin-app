"""Builds the frozen input snapshot.

Everything a rule is allowed to read must end up in here. Once built, the
snapshot is the only input to evaluation: no live DB, no clock, no network.
"""

from __future__ import annotations

from datetime import date
from typing import Any

from . import calcs
from .pack import Pack

#: Re-exported so that callers importing BPS from here keep working. The
#: definition lives with the arithmetic that uses it.
BPS = calcs.BPS

#: What a positions provider reports when it has never heard of this client, as
#: distinct from reporting that they hold nothing. The two produce identical
#: figures and mean entirely different things, which is the whole of Q-06.
#:
#: Defined here rather than in `app/providers` because the engine may not import
#: the application around it, and this is the value the engine has to recognise.
#: `tests/test_ingested_clients_are_not_assessed_as_empty.py` asserts the
#: provider still uses this exact string.
NONE_ON_FILE = "none_on_file"


def _age_years(dob: date, as_of: date) -> int:
    return as_of.year - dob.year - ((as_of.month, as_of.day) < (dob.month, dob.day))


def build_snapshot(
    *,
    pack: Pack,
    client: dict[str, Any],
    positions: dict[str, Any],
    asset: dict[str, str],
    amount_cents: int,
    as_of: date,
    licensee_jurisdiction: str | None = None,
    also_classified_by: list[Pack] | None = None,
) -> dict[str, Any]:
    classification = pack.classify(asset["id"])

    dob = client["dob"] if isinstance(client["dob"], date) else date.fromisoformat(client["dob"])
    knowledge_date = client.get("knowledge_date")
    if knowledge_date and not isinstance(knowledge_date, date):
        knowledge_date = date.fromisoformat(knowledge_date)

    existing_crypto_cents = int(positions["crypto_value_cents"])
    portfolio_cents = int(client["assessable_portfolio_cents"])

    # Whether anybody has actually told us what this client holds. A client who
    # arrived by CSV, by file drop or through the API has no custody record, and
    # the zero that comes back is an absence rather than a reading.
    custody_known = str(positions.get("source", "unknown")) != NONE_ON_FILE

    # Which regimes reach this client is a question about three facts, and all
    # three have to be inside the frozen snapshot: a determination that depended
    # on a residency read live from the CRM would not replay (invariants 2, 5).
    licensee = licensee_jurisdiction or client.get("jurisdiction")
    residency = client.get("residency") or licensee
    domicile = client.get("domicile") or licensee

    # And whether each of them was *supplied* or *assumed*.
    #
    # Report B's concern: a missing source fact becomes a populated derived
    # field before the DSL sees it, so a rule reading it cannot tell "the firm
    # told us AU" from "the firm told us nothing and we assumed the licence".
    # The fallback itself is a deliberate modelling choice with its own test —
    # residency defaults to the licence rather than to Australia — and the
    # columns are NOT NULL, so it fires rarely. What was missing is the record
    # of *which* it was.
    #
    # Recorded as a fact rather than turned into a refusal, and that is the
    # narrower correct thing. Making the DSL treat a derived value as absent
    # would hard-code a compliance judgement in the engine for a field no pack
    # currently reads — invariant 1 says which facts matter is content. This
    # gives a regime the fact and lets its rules decide, the same way
    # `positions.source` does for custody.
    SUPPLIED, ASSUMED = "supplied", "assumed_from_licence"
    residency_source = SUPPLIED if client.get("residency") else ASSUMED
    domicile_source = SUPPLIED if client.get("domicile") else ASSUMED

    def classified(source: Pack) -> dict[str, Any]:
        other = source.classify(asset["id"])
        return {
            "id": asset["id"],
            "symbol": asset["symbol"],
            "name": asset["name"],
            "class": other["class"],
            "volatility_band": int(other["volatility_band"]),
            "leverage": bool(other["leverage"]),
            "structural_flags": sorted(other.get("structural_flags") or []),
        }

    # One regulator's major asset is another's complex product, so a regime that
    # is not the governing one still classifies the asset its own way. Those
    # classifications are frozen here rather than looked up at resolution time,
    # because replay must read back the classification each pack was actually
    # evaluated against. The governing pack is deliberately absent — it is
    # `asset` above, and a number stored twice is a number that can disagree.
    alternates = {
        source.pack_id: {"asset": classified(source)}
        for source in (also_classified_by or [])
        if source.pack_id != pack.pack_id
    }

    return {
        "as_of": as_of.isoformat(),
        "licensee": {"jurisdiction": licensee},
        "client": {
            "id": client["id"],
            "name": client["name"],
            "scenario": client["scenario"],
            "residency": residency,
            "residency_source": residency_source,
            "domicile": domicile,
            "domicile_source": domicile_source,
            "age_years": _age_years(dob, as_of),
            "client_category": client["client_category"],
            "knowledge_assessed": bool(client["knowledge_assessed"]),
            "knowledge_assessed_days_ago": (
                (as_of - knowledge_date).days if knowledge_date else None
            ),
            "loss_capacity_band": int(client["loss_capacity_band"]),
            "vulnerability_flag": bool(client["vulnerability_flag"]),
            "assessable_portfolio_cents": portfolio_cents,
            "prior_crypto_purchases": int(client["prior_crypto_purchases"]),
            "structural_acks": sorted(client.get("structural_acks") or []),
        },
        "asset": {
            "id": asset["id"],
            "symbol": asset["symbol"],
            "name": asset["name"],
            "class": classification["class"],
            "volatility_band": int(classification["volatility_band"]),
            "leverage": bool(classification["leverage"]),
            "structural_flags": sorted(classification.get("structural_flags") or []),
        },
        "jurisdictions": alternates,
        "trade": {"amount_cents": int(amount_cents)},
        # Where the holdings behind the concentration figure came from.
        #
        # Inside the frozen snapshot rather than beside it, because it is a fact
        # the determination rested on: "10% concentration, from custody" and
        # "10% concentration, because nobody has told us otherwise" are different
        # findings, and a replay years later has to reproduce which one it was.
        # The execution document asks for exactly this — a tenant without a
        # custody integration supplies positions by batch or attests manually,
        # and the snapshot records which.
        "positions": {
            "source": str(positions.get("source", "unknown")),
            "as_at": str(positions.get("as_at", "")),
            # Named, and only when there is something to name. A determination
            # replayed in two years has to be able to say *what it was decided
            # on*, and "these figures were not available" is part of that. The
            # key is absent when custody is on file so that a snapshot for a
            # client with positions is byte-identical to the ones already
            # recorded — adding a key to those would change what replay reads
            # back for every decision on file (invariants 2 and 5).
            **(
                {"withheld_calcs": list(calcs.custody_dependent())}
                if not custody_known
                else {}
            ),
        },
        # Every registered calc, computed from the three integers above. The
        # registry is the only place a derived number is defined, so a pack
        # naming one that does not exist is caught when the pack is loaded
        # rather than when a determination is being made. See engine/calcs.py.
        "calc": calcs.compute_all(
            existing_cents=existing_crypto_cents,
            amount_cents=int(amount_cents),
            portfolio_cents=portfolio_cents,
            custody_known=custody_known,
        ),
    }
