"""Argon2id, and the two things around it that are easier to get wrong.

**Why a dependency here and not next door.** `app/totp.py` argues its way out of
`pyotp` on the grounds that the algorithm is forty lines with published test
vectors. None of that is true of a password hash. Argon2id is a memory-hard
function whose security is entirely in its parameters, there is no small set of
vectors that would catch choosing them badly, and a hand-written one would look
correct and be quietly weak. So this is `argon2-cffi`, and the code here is
about the parts the library does not decide.

**The parameters, and why these.** RFC 9106's second recommended configuration:
64 MiB, three passes, four lanes. The memory is the point — a GPU that can try
billions of SHA-256 guesses a second can try very few of something that demands
sixty-four megabytes per attempt. The cost lands on us too, at roughly a tenth
of a second per login, which is why `app/auth.py` rate-limits the endpoint: the
same property that makes offline cracking expensive makes an unthrottled login
route a way to spend a server's memory bandwidth for free.

**Parameters change, and stored hashes must be able to follow.** The encoding
carries the parameters it was made with, so `needs_rehash` can tell a hash made
under an older setting from a current one. Rehashing needs the plaintext, so it
can only happen at the one moment the plaintext exists — during a successful
sign-in. `verify` returns whether that is needed rather than a bare boolean, for
the same reason `totp.verify` returns a counter: a caller that ignores it has to
ignore something.

**A password that is not there must cost the same as one that is wrong.**
Returning early for an unknown email turns the login route into a user
directory, and the timing difference is large here — the difference between an
Argon2 verification and no work at all is not subtle. `waste_time` exists to be
called on that path.
"""

from __future__ import annotations

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHash, VerificationError

#: RFC 9106, second recommended configuration. Stated as constants rather than
#: left to the library's defaults so that a change is a visible diff with a
#: reason attached, and so `needs_rehash` compares against something deliberate.
MEMORY_KIB = 64 * 1024
TIME_COST = 3
PARALLELISM = 4

_hasher = PasswordHasher(
    time_cost=TIME_COST,
    memory_cost=MEMORY_KIB,
    parallelism=PARALLELISM,
)

#: The shortest password accepted. NIST 800-63B's position, which this follows:
#: length is the property that matters, and composition rules ("one capital, one
#: symbol") measurably push people towards `Password1!` while adding almost
#: nothing an attacker has to search. So there is one rule here, and it is long.
MIN_LENGTH = 12

#: An Argon2 encoding of a value nothing will ever present, hashed at import so
#: `waste_time` costs what a real verification costs. Deriving it from a random
#: string rather than a constant keeps it out of any rainbow table, though
#: nothing depends on that — it is never stored and never compared against a
#: real credential.
_DECOY = _hasher.hash("a password no account has, used only to burn the same time")


class WeakPassword(ValueError):
    """Rejected before hashing. The message is shown to the user."""


def check_strength(password: str, *, email: str = "") -> None:
    """Raise `WeakPassword` if this one should not be accepted.

    `email` is checked because a password that is the account's own address is
    guessable by anyone who can address an envelope, and it is a thing people
    genuinely do when a form demands a password they do not want.
    """
    if len(password) < MIN_LENGTH:
        raise WeakPassword(
            f"A password must be at least {MIN_LENGTH} characters. "
            "Length is the only rule; a passphrase of ordinary words is fine."
        )
    if email and password.strip().lower() == email.strip().lower():
        raise WeakPassword("A password cannot be the email address it signs in.")


def hash_password(password: str, *, email: str = "") -> str:
    """The encoding to store, parameters and salt included."""
    check_strength(password, email=email)
    return _hasher.hash(password)


def verify(encoded: str, presented: str) -> tuple[bool, bool]:
    """`(matched, should_rehash)`.

    A two-tuple rather than a boolean so that the rehash obligation is returned
    into the caller's hands. `should_rehash` is only ever true alongside a
    match, because rehashing requires the plaintext to be known correct.

    Every failure is a `False`, never an exception: a stored value that is not a
    valid Argon2 encoding is a corrupted row, and the right response to it at a
    login endpoint is a refused sign-in, not a stack trace an attacker can
    provoke by other means.
    """
    if not encoded or not presented:
        return False, False
    try:
        _hasher.verify(encoded, presented)
    except (VerificationError, InvalidHash):
        return False, False
    return True, _hasher.check_needs_rehash(encoded)


def waste_time() -> None:
    """Spend what a verification spends, and learn nothing.

    Called where there is no hash to check — an unknown email, or a user who has
    only an OIDC identity — so that the response time of the login route does
    not answer the question of whether an account exists.
    """
    try:
        _hasher.verify(_DECOY, "not the decoy")
    except VerificationError:
        pass
