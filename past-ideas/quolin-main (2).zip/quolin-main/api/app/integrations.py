"""What is connected, what is standing in for something, and how to tell.

This module exists because of one failure mode. A prototype that mocks an edge
and does not say so reads exactly like a prototype that has integrated it. The
person being shown the demo cannot tell the difference, and when they later find
out, the honest parts of the system lose their credit along with the dishonest
part. A labelled boundary costs a sentence. An unlabelled one costs the room.

So every external edge is described here, and the descriptions are computed
rather than asserted wherever computing them is possible. `clients` reports the
number of rows actually in the table; custody reports the number of clients the
fixture actually covers. A hardcoded "connected" label cannot go stale into a
lie, because it is not hardcoded.

Status values, and what each one promises:

  live      Reads or writes the real thing. Nothing stands in for it.
  fixture   Backed by a file checked into the repository. The shape is real,
            the contents are invented, and no external system is contacted.
  local     Real behaviour, really executed, but wholly inside this deployment
            rather than reaching the counterparty it eventually would.
"""

from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .models import (
    Artefact,
    AuditEvent,
    AuthSession,
    Client,
    Decision,
    ImportRun,
    User,
)
from .providers import FixturePositionsProvider

# The three statuses a boundary may report. Kept as a tuple so a typo becomes an
# import-time failure rather than an unrecognised badge on the screen.
STATUSES = ("live", "fixture", "local")


def _endpoints(session) -> int:
    """How many webhook endpoints this firm has configured and enabled.

    Read per request rather than cached: an integration going live is exactly
    the moment this screen is looked at, and a cached `local` would be wrong
    for as long as the cache lasted.
    """
    from .models import WebhookEndpoint

    return int(
        session.scalar(
            select(func.count(WebhookEndpoint.id)).where(
                WebhookEndpoint.status == "active"
            )
        )
        or 0
    )


def _count(session: Session, model) -> int:
    return session.scalar(select(func.count()).select_from(model)) or 0


def describe(session: Session) -> list[dict]:
    """Every external edge, in the order a reader should meet them.

    Client data first, because that is the one a viewer will ask about, and the
    one the CSV importer changes.
    """
    clients = _count(session, Client)
    covered = FixturePositionsProvider().covered_ids()
    uncovered = session.scalars(
        select(Client.id).where(Client.id.notin_(covered))
    ).all() if covered else []

    return [
        {
            "id": "crm",
            "name": "Client records",
            "stands_for": "The institution's CRM or client master",
            "implementation": "DbClientProvider",
            "status": "live",
            "detail": (
                f"Reads {clients} client records from this deployment's own database. "
                "The records are real rows and the reads are real reads, but the book "
                "itself was seeded or imported here — it is not synchronised with an "
                "external CRM."
            ),
            "how_data_gets_in": "Seed fixtures, or CSV import on this screen.",
            "replaced_by": "A CRM connector implementing the same ClientProvider protocol.",
        },
        {
            "id": "custody",
            "name": "Custody positions",
            "stands_for": "The custodian or exchange holding the client's assets",
            "implementation": "FixturePositionsProvider",
            "status": "fixture",
            "detail": (
                f"Positions come from fixtures/positions.json, which covers "
                f"{len(covered)} clients. Holdings are invented. No custodian is "
                "contacted and no balance is verified."
            ),
            # The single most consequential mock in the system, so it gets its
            # own field rather than a clause buried in the paragraph above.
            "consequence": (
                "Concentration is computed from these figures. A client with no "
                "custody record is assessed as holding nothing, which makes the "
                "concentration rule pass for reasons that have nothing to do with "
                "their real portfolio."
            ),
            "clients_without_records": len(uncovered),
            "how_data_gets_in": "Written by `make seed`. CSV import does not supply positions.",
            "replaced_by": "A custody or exchange API implementing PositionsProvider.",
        },
        {
            # The edge this endpoint did not have, and `docs/integrations.md`
            # sent a customer here to check. That document told them in the
            # present tense that they get a chrooted SFTP account and that files
            # are PGP-encrypted at rest — none of which exists — and then told
            # them to "read `/integrations` before you assume something is
            # live", where there was nothing about the file drop at all.
            #
            # An absent edge is the one failure this endpoint's own docstring
            # says it exists to prevent: a boundary that is not labelled reads
            # exactly like one that has been integrated.
            "id": "batch_file_drop",
            "name": "Batch file drop",
            "stands_for": "An SFTP server with per-tenant chroots and PGP at rest",
            "implementation": "app/batch.py + scripts/batch_sweep.py",
            # `local` is exactly the word: real behaviour, really executed,
            # wholly inside this deployment rather than reaching the
            # counterparty it eventually would. The gateway runs; the transport
            # in front of it does not exist.
            "status": "local",
            "detail": (
                f"{_count(session, ImportRun)} import run(s) recorded. The "
                "gateway is real — schema validation, row-level errors, the "
                "error file, the manifest, the content hash that makes a "
                "re-sent file visible rather than doubled — and runs over a "
                "directory tree. **The transport is not built.** There is no "
                "SFTP server, no per-tenant chroot and no PGP handling in this "
                "system, and nothing in the deployed stack sweeps a drop "
                "directory: `scripts/batch_sweep.py` is run by hand. A file "
                "reaches this gateway today through `POST /import/clients`."
            ),
            "consequence": (
                "Nothing arrives here on its own. A firm that believes it is "
                "dropping a nightly export is dropping it somewhere nothing "
                "reads, and the absence of an import run is the only symptom."
            ),
            "how_data_gets_in": "`POST /import/clients`, or `make batch-sweep` by hand.",
            "replaced_by": (
                "AWS Transfer Family, or an sshd with per-tenant chroots, "
                "and PGP at rest."
            ),
        },
        {
            "id": "compliance_queue",
            "name": "Compliance queue",
            "stands_for": "The institution's review queue or case-management webhook",
            "implementation": "AuditQueueSink + webhook delivery",
            # Derived, not declared.
            #
            # This said `local` unconditionally, which was wrong in the
            # direction that matters: a deployment delivering webhooks
            # perfectly well would have told its operator that nothing was
            # posted outside it. The screen exists to say which edges are real,
            # so it has to look.
            "status": "live" if _endpoints(session) else "local",
            "detail": (
                (
                    f"Referrals are written to this system's own audit trail "
                    f"({_count(session, AuditEvent)} events recorded) *and* posted "
                    f"to {_endpoints(session)} configured endpoint(s), signed and "
                    "retried. What a receiver does with them is theirs."
                )
                if _endpoints(session)
                else (
                    f"Referrals are written to this system's own audit trail "
                    f"({_count(session, AuditEvent)} events recorded). The write is "
                    "real and the queue screen reads it. No endpoint is configured "
                    "for this firm, so nothing is posted outside this deployment — "
                    "the delivery machinery exists and has nowhere to send."
                )
            ),
            "how_data_gets_in": "Written whenever a determination refers.",
            "replaced_by": "An HTTP sink implementing QueueSink.",
        },
        {
            "id": "documents",
            "name": "Document generation",
            "stands_for": "Nothing — this is the real thing",
            "implementation": "WeasyPrint + pack-configured templates",
            "status": "live",
            "detail": (
                f"{_count(session, Artefact)} documents have been rendered from the "
                "recorded evidence by the same renderer that would run in production. "
                "Titles and templates come from the rule pack, not from code."
            ),
            "consequence": (
                "Generated documents are real PDFs. They are not lodged with any "
                "regulator — producing a return and filing it are different acts."
            ),
            "how_data_gets_in": "Rendered on request from recorded decisions.",
            "replaced_by": None,
        },
        {
            "id": "evidence",
            "name": "Decision record",
            "stands_for": "Nothing — this is the real thing",
            "implementation": "Postgres, append-only triggers, SHA-256 chain",
            "status": "live",
            "detail": (
                f"{_count(session, Decision)} determinations, each hash-chained to the "
                "one before it and frozen with the inputs it was made from. The "
                "database refuses UPDATE and DELETE on the evidence tables."
            ),
            "consequence": (
                "audit_events is append-only but not hash-chained. The decision chain "
                "carries arithmetic proof; the audit trail does not."
            ),
            "how_data_gets_in": "Written by every evaluation, override and replay.",
            "replaced_by": None,
        },
        {
            "id": "auth",
            "name": "Access control",
            "stands_for": "The institution's identity provider and role model",
            "implementation": "Per-user accounts, roles per tenant, server-side sessions",
            # `local` and not `live`: identity is real and per-person now, but it
            # is *our* directory rather than the institution's. Until a customer
            # signs in through their own IdP, joiners and leavers are managed
            # here, which is not what a bank means by access control.
            "status": "local",
            "detail": (
                f"{_count(session, User)} people hold accounts and "
                f"{_count(session, AuthSession)} browser sessions are on record. "
                "Passwords are Argon2id, second factors are TOTP, roles are held "
                "per tenant, and signing a pack demands a fresh credential — but "
                "the directory is this deployment's, not the institution's."
            ),
            "consequence": (
                "A leaver is removed here rather than by the customer's own "
                "joiner-mover-leaver process, so their access outlives their "
                "employment until somebody tells us. That is what SSO fixes, and "
                "it is why this edge is not yet live."
            ),
            "how_data_gets_in": "Accounts created in this deployment; no directory is read.",
            "replaced_by": "SSO through the customer's own identity provider.",
        },
    ]


def summary(session: Session) -> dict:
    """Headline counts, so the screen can lead with the shape of the answer."""
    edges = describe(session)
    return {
        "edges": edges,
        "live": sum(1 for e in edges if e["status"] == "live"),
        "mocked": sum(1 for e in edges if e["status"] != "live"),
        "statement": (
            "Everything mocked in this prototype sits behind a named protocol, and "
            "every one of them is listed here. Replacing a mock is a new "
            "implementation of the same protocol, not a change to the call sites."
        ),
    }
