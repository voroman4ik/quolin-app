"""The states a piece of rule content moves through, and who moved it.

Before this stage a draft had a `status` column and four values it could hold.
That answers "where is this now" and destroys the answer to "how did it get
there" every time it changes — which is the question an auditor is actually
asking. "This pack became effective on the fourteenth" is a fact; "it was
drafted by an operator on the second, put up for review on the ninth, signed by
a named signatory on the eleventh and put in force by an administrator on the
twelfth" is what makes the fact accountable.

**Six states rather than the five the execution document lists**, and the extra
one is Stage 2's doing. §S5 names DRAFT → IN_REVIEW → SIGNED → EFFECTIVE →
SUPERSEDED. Stage 2 then split signing from publication, because a signatory
putting their own signature into force is one person agreeing with themselves.
So SIGNED and PUBLISHED are distinct here: signed content is attested, published
content is scheduled, and effective content is in force. Collapsing them would
undo the two-person rule the previous stage exists for.

**REJECTED is terminal and kept.** A rejected draft is the record that somebody
looked and said no, which is worth more to an auditor than the absence of a
draft. It is reachable from DRAFT and IN_REVIEW only: once content is signed,
the way to undo it is a superseding version, not a deletion.

**Transitions are checked here and logged in the same call.** A transition that
could be recorded without being validated, or performed without being recorded,
is the one somebody eventually does by hand.
"""

from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import business_time
from ..canonical import content_hash as _content_hash
from ..models import PackDraft, PackDraftTransition

#: Written, not yet ready. Nobody is waiting on it.
DRAFT = "draft"
#: Put up for a signatory to look at. The clock a signatory is waiting on starts
#: here, which is why this is a state rather than a flag — "how long has this
#: been sitting with us" is a question a firm asks about its own backlog.
IN_REVIEW = "in_review"
#: A named person has attested to specific content. Not yet rule content.
SIGNED = "signed"
#: A pack version exists, scheduled for its effective date. Somebody other than
#: the signatory put it there — see Stage 2.
PUBLISHED = "published"
#: Its effective date has arrived and it governs determinations.
EFFECTIVE = "effective"
#: A later version has taken over. Kept, because decisions were made under it
#: and replaying one requires knowing it was once in force.
SUPERSEDED = "superseded"
#: Considered and declined. Terminal.
REJECTED = "rejected"

STATUSES = (DRAFT, IN_REVIEW, SIGNED, PUBLISHED, EFFECTIVE, SUPERSEDED, REJECTED)

#: Which moves are legal, from each state.
#:
#: Written as a table rather than as branches in each function, because the
#: interesting property is the shape of the whole thing — that nothing returns
#: from SIGNED to DRAFT, that REJECTED and SUPERSEDED have no exits, that
#: EFFECTIVE is reachable only through PUBLISHED. A reader can check that here;
#: they cannot check it by reading six functions.
TRANSITIONS: dict[str, tuple[str, ...]] = {
    DRAFT: (IN_REVIEW, REJECTED),
    # Back to DRAFT is allowed: a signatory who wants a change made asks for
    # one, and forcing that through REJECTED would make "somebody said no" and
    # "somebody asked for a comma" the same record.
    IN_REVIEW: (SIGNED, DRAFT, REJECTED),
    # No exit to DRAFT or REJECTED. Once a named person has attested to content,
    # the way to undo it is a superseding version — an edit would leave their
    # signature attached to bytes they never saw.
    SIGNED: (PUBLISHED,),
    PUBLISHED: (EFFECTIVE,),
    EFFECTIVE: (SUPERSEDED,),
    SUPERSEDED: (),
    REJECTED: (),
}


class IllegalTransition(ValueError):
    """A draft was asked to make a move the lifecycle does not have.

    The message names what was possible from where it was, because the caller is
    usually a screen and the useful answer is what the buttons should have been.
    """

    def __init__(self, draft_id: int, current: str, wanted: str):
        self.draft_id = draft_id
        self.current = current
        self.wanted = wanted
        allowed = TRANSITIONS.get(current, ())
        super().__init__(
            f"draft {draft_id} is {current!r} and cannot become {wanted!r}. "
            + (
                f"From {current!r} it can only become: {', '.join(allowed)}."
                if allowed
                else f"{current!r} is terminal — nothing follows it."
            )
        )


def _now() -> datetime:
    return datetime.now(timezone.utc)


def content_hash(body: dict[str, Any]) -> str:
    """SHA-256 of the pack body, canonically serialised.

    Canonical because the hash has to be the same tomorrow: JSON key order is
    not meaningful and a hash that changed when a dictionary was rebuilt would
    make "is this what was signed" unanswerable for the wrong reason.

    This is what a signature attests to. "They signed version 4" is a weaker
    claim than "they signed these exact bytes" the moment somebody asks what
    changed between the signature and what went live.

    The arithmetic moved to `app/canonical.py` for Q-04, which needs the same
    value in a decision's execution manifest and cannot import `app.watch`. The
    bytes are unchanged; this stays as the name every caller here already uses.
    """
    return _content_hash(body)


def may(current: str, wanted: str) -> bool:
    return wanted in TRANSITIONS.get(current, ())


def move(
    session: Session,
    draft: PackDraft,
    to_status: str,
    *,
    note: str = "",
    actor: str | None = None,
) -> PackDraftTransition:
    """Move a draft, or refuse. Records the move in the same call.

    Validated and logged together on purpose. A transition that could be
    recorded without being checked, or performed without being recorded, is the
    one somebody eventually does by hand — and the log's whole value is that it
    is complete.
    """
    if to_status not in STATUSES:
        raise IllegalTransition(draft.id, draft.status, to_status)
    if not may(draft.status, to_status):
        raise IllegalTransition(draft.id, draft.status, to_status)

    row = PackDraftTransition(
        draft_id=draft.id,
        from_status=draft.status,
        to_status=to_status,
        at=_now(),
        note=note,
    )
    if actor is not None:
        row.by_actor = actor
    session.add(row)
    draft.status = to_status
    session.flush()
    return row


def record_creation(
    session: Session, draft: PackDraft, *, actor: str | None = None
) -> PackDraftTransition:
    """The first row: a draft coming into existence.

    `from_status` is null rather than a sentinel, because "from nothing" is
    genuinely a different fact from "from draft" and a sentinel would sort among
    the real states in every query that groups by it.
    """
    row = PackDraftTransition(
        draft_id=draft.id,
        from_status=None,
        to_status=draft.status,
        at=_now(),
        note="created",
    )
    if actor is not None:
        row.by_actor = actor
    session.add(row)
    session.flush()
    return row


def history(session: Session, draft_id: int) -> list[dict[str, Any]]:
    """Every move this draft has made, oldest first.

    Oldest first because it is read as a narrative — a reader wants to start
    where the content did, not at the end.
    """
    rows = session.scalars(
        select(PackDraftTransition)
        .where(PackDraftTransition.draft_id == draft_id)
        .order_by(PackDraftTransition.at, PackDraftTransition.id)
    ).all()
    return [
        {
            "from": r.from_status,
            "to": r.to_status,
            "at": r.at.isoformat(),
            "by": r.by_actor,
            "note": r.note,
        }
        for r in rows
    ]


def settle(session: Session, *, today: date | None = None) -> dict[str, int]:
    """Move published drafts to effective, and effective ones to superseded.

    The two transitions nobody performs: they happen because a date arrived, and
    a state that changed silently at midnight with no row to show for it would
    be a hole in the middle of the log. So a scheduled sweep records them, and
    the log stays complete.

    Idempotent. It works out what should have happened by now rather than what
    changed since it last ran, so a sweep that was missed for a week catches up
    rather than skipping the states nobody was there to record.
    """
    when = today or business_time.platform_today()
    tally = {"effective": 0, "superseded": 0}

    published = session.scalars(
        select(PackDraft).where(PackDraft.status == PUBLISHED)
    ).all()
    for draft in published:
        if draft.effective_from <= when:
            move(
                session,
                draft,
                EFFECTIVE,
                note=f"effective from {draft.effective_from.isoformat()}",
                actor="schedule",
            )
            tally["effective"] += 1

    # Superseding is worked out per jurisdiction: the highest effective version
    # governs, and everything below it has been taken over. Computed from the
    # rows rather than assumed from the order they arrived, because a
    # future-dated version published before an earlier one is legitimate and
    # would break an assumption about ordering.
    effective = session.scalars(
        select(PackDraft).where(PackDraft.status == EFFECTIVE)
    ).all()
    by_regime: dict[str, list[PackDraft]] = {}
    for draft in effective:
        by_regime.setdefault(draft.jurisdiction, []).append(draft)

    for jurisdiction, drafts in by_regime.items():
        if len(drafts) < 2:
            continue
        current = max(drafts, key=lambda d: d.proposed_version)
        for draft in drafts:
            if draft.proposed_version < current.proposed_version:
                move(
                    session,
                    draft,
                    SUPERSEDED,
                    note=(
                        f"{jurisdiction} v{current.proposed_version} took over on "
                        f"{current.effective_from.isoformat()}"
                    ),
                    actor="schedule",
                )
                tally["superseded"] += 1

    session.flush()
    return tally
