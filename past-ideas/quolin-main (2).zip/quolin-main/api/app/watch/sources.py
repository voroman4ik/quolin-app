"""Which publications are watched, and whether anyone has looked lately.

The source list is pack content. This module is the operational half: it
reconciles the declared list into `watch_sources` rows and derives, for each
one, whether the deployment is keeping to the cadence its own content asked for.

Freshness is computed on read, never stored. A stored freshness column would be
correct at the moment it was written and wrong from then on — and it would go
wrong in exactly the direction that matters, sitting on `CURRENT` for a source
nobody has checked in a month. The one thing this screen exists to catch is the
thing a cached value would hide.
"""

from __future__ import annotations

import os
from datetime import date, datetime, time, timezone
from typing import Any, TypedDict

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import business_time, packs_repo
from ..identity import new_id
from ..models import SourceVerification, WatchSource
from . import fetchers

#: Checked within its declared cadence.
CURRENT = "CURRENT"
#: Past its cadence, but within twice it. A working week's slippage on a weekly
#: source is a nudge, not an incident, and a screen that cried STALE on day
#: eight would be ignored by day ten.
DUE = "DUE"
#: Past twice its cadence, or never checked at all. Never-checked is STALE
#: rather than a fourth state: from the point of view of somebody asking whether
#: this deployment is current, "we have never looked" and "we last looked in
#: April" are the same answer.
STALE = "STALE"
#: Verified by a person within its cadence, because it cannot be polled.
#:
#: §S13's review: live polling needed a machine-readable feed, and eight of the
#: nine shipped sources had none. Most of those are now read as pages — see
#: `fetchers.digest` — but some publications genuinely cannot be polled: they
#: need a login, or the URL is a search form with no stable result. Those are
#: declared MANUAL in pack content and carry the date somebody last looked.
#:
#: It is a *worse* state than CURRENT and deliberately so. A regime whose
#: monitoring rests on somebody remembering to open a page is not in the same
#: condition as one being checked automatically, and the badge must not say it
#: is. Because `worst` is worst-wins, a jurisdiction holding one manual source
#: can never roll up to a clean CURRENT — which is the whole point.
MANUAL = "MANUAL"

FRESHNESS = (CURRENT, MANUAL, DUE, STALE)

#: Worst-first, for rolling a set of sources up into one badge.
_SEVERITY = {STALE: 0, DUE: 1, MANUAL: 2, CURRENT: 3}

#: Consecutive failed checks before a source's owner is paged, when its own
#: content does not say. §S6 names three: one failure is a bad afternoon at the
#: publisher, two is a pattern, three is an outage somebody should know about.
DEFAULT_ALERT_AFTER = 3

#: How a poll was performed. `replay` reads a fixture; `live` would reach the
#: publisher. Recorded per source rather than read from the environment when a
#: screen renders — see `mode()`.
REPLAY = "replay"
LIVE = "live"
#: A person looked. §S13: a source declared MANUAL cannot be polled, so the
#: only check it can have is somebody opening it — and recording that as
#: `replay` or `live` would claim a machine did something it did not.
VERIFIED = "manual"

#: Every way a check can have happened.
MODES = (REPLAY, LIVE, VERIFIED)

#: How a source can be read at all, as pack content declares it.
AUTOMATIC = fetchers.AUTOMATIC
MANUAL_POLLING = fetchers.MANUAL


class DeclaredSource(TypedDict):
    """A source exactly as pack content declares it."""

    id: str
    jurisdiction: str
    name: str
    url: str
    cadence_days: int
    #: Who gets paged when it stops answering. Pack content rather than
    #: deployment configuration: who owns a regime's monitoring is the same kind
    #: of fact as which publications that regime watches.
    owner: str
    #: Consecutive failures before that page is sent.
    alert_after_failures: int
    #: How to read it live. `None` means it cannot be read at all — either the
    #: pack declares it MANUAL, or it has no usable URL.
    feed: dict[str, str] | None
    #: `AUTOMATIC` or `MANUAL`, as pack content declares it. Whether a
    #: publication has a readable URL is a fact about the regime.
    polling_status: str


class SourceState(TypedDict):
    """A `watch_sources` row with its freshness derived on read."""

    id: str
    jurisdiction: str
    name: str
    url: str
    cadence_days: int
    last_checked_at: str | None
    last_mode: str
    enabled: bool
    freshness: str
    days_overdue: int | None
    owner: str
    consecutive_failures: int
    alert_after_failures: int
    last_error: str
    last_failed_at: str | None
    #: `AUTOMATIC` or `MANUAL`.
    polling_status: str
    #: The most recent attestation, where a person is the only thing that can
    #: check this source. `None` for anything polled.
    last_verification: dict[str, str] | None
    #: Which adapter last read it — `rss`, `atom`, `html`, or empty. A reader is
    #: entitled to know whether "current" rests on a publisher's own feed or on
    #: a digest of their page.
    fetcher: str
    #: At or past its own threshold — the source is unreachable, not merely
    #: overdue, and somebody named is supposed to be looking at it.
    breaching: bool


def mode() -> str:
    """The mode this process would poll in.

    Defaults to `replay`, because the failure mode of the other default is a
    demo that quietly contacts four regulators. `WatchSource.last_mode` records
    what each check actually did, so a source checked in replay still says so
    after somebody flips the environment variable.
    """
    value = os.getenv("WATCH_MODE", REPLAY).strip().lower()
    return value if value in (REPLAY, LIVE) else REPLAY


def declared(session: Session, on: date) -> list[DeclaredSource]:
    """Every source declared by an in-force pack, with its jurisdiction.

    A pack with no `watch` block declares no sources, which is a legitimate
    state and not an error: a regime can be evaluated without being monitored,
    and the currency screen says so rather than showing an empty list that looks
    like a failed load.
    """
    out: list[DeclaredSource] = []
    for jurisdiction, row in sorted(packs_repo.active_rows(session, on).items()):
        watch = (row.body or {}).get("watch") or {}
        for source in watch.get("sources", []):
            out.append(
                {
                    "id": source["id"],
                    "jurisdiction": jurisdiction,
                    "name": source["name"],
                    "url": source.get("url", ""),
                    "cadence_days": int(source.get("cadence_days", 7)),
                    "owner": str(source.get("owner", "")),
                    "alert_after_failures": int(
                        source.get("alert_after_failures", DEFAULT_ALERT_AFTER)
                    ),
                    "polling_status": (
                        fetchers.MANUAL
                        if str(source.get("polling_status", "")).strip().upper()
                        == fetchers.MANUAL
                        else fetchers.AUTOMATIC
                    ),
                    "feed": fetchers.feed_of(source),
                }
            )
    return out


def vocabulary(session: Session, on: date) -> dict[str, list[dict[str, Any]]]:
    """Each in-force pack's watch vocabulary, keyed by jurisdiction.

    A jurisdiction absent from this mapping has no pack or no watch block, and
    `triage.classify` treats both the same way.
    """
    out: dict[str, list[dict[str, Any]]] = {}
    for jurisdiction, row in packs_repo.active_rows(session, on).items():
        watch = (row.body or {}).get("watch") or {}
        out[jurisdiction] = list(watch.get("vocabulary", []))
    return out


def sync(session: Session, on: date) -> dict[str, int]:
    """Reconcile declared sources into rows, preserving check history.

    Adding a source to a pack must not reset when its neighbours were last
    checked, and removing one must not delete the record that it used to be
    watched — a dropped source is disabled, not erased, so the currency history
    still explains a gap. This is why the table is keyed on the content's own
    source id rather than on an autoincrement.
    """
    wanted = {s["id"]: s for s in declared(session, on)}
    existing = {row.id: row for row in session.scalars(select(WatchSource))}

    added = updated = disabled = 0
    for source_id, spec in wanted.items():
        row = existing.get(source_id)
        if row is None:
            session.add(
                WatchSource(
                    id=source_id,
                    jurisdiction=spec["jurisdiction"],
                    name=spec["name"],
                    url=spec["url"],
                    cadence_days=spec["cadence_days"],
                    owner=spec["owner"],
                    alert_after_failures=spec["alert_after_failures"],
                    polling_status=spec.get("polling_status", AUTOMATIC),
                    enabled=True,
                )
            )
            added += 1
            continue
        changed = (
            row.name != spec["name"]
            or row.url != spec["url"]
            or row.cadence_days != spec["cadence_days"]
            or row.jurisdiction != spec["jurisdiction"]
            or row.owner != spec["owner"]
            or row.alert_after_failures != spec["alert_after_failures"]
            or row.polling_status != spec.get("polling_status", AUTOMATIC)
            or not row.enabled
        )
        if changed:
            row.name = spec["name"]
            row.url = spec["url"]
            row.cadence_days = spec["cadence_days"]
            row.jurisdiction = spec["jurisdiction"]
            # Ownership and the alert threshold are content, so content wins.
            # A pack edit reassigning a source is how a specialist hands it over
            # when they leave, and a row that kept the old name would page
            # somebody who no longer works here.
            row.owner = spec["owner"]
            row.alert_after_failures = spec["alert_after_failures"]
            # Whether a source can be polled is content too. A publisher who
            # puts a feed behind a login is a pack edit, and the row has to
            # follow or the screen keeps promising a check nobody performs.
            row.polling_status = spec.get("polling_status", AUTOMATIC)
            row.enabled = True
            updated += 1

    for source_id, row in existing.items():
        if source_id not in wanted and row.enabled:
            row.enabled = False
            disabled += 1

    session.flush()
    return {"added": added, "updated": updated, "disabled": disabled}


def freshness(
    last_checked_at: datetime | None,
    cadence_days: int,
    now: datetime,
    *,
    polling_status: str = AUTOMATIC,
) -> str:
    """How current a source is, and how much that is worth.

    Being manual does not excuse being unverified: a source nobody has looked at
    for a year is STALE whether or not a machine could have looked. What manual
    changes is the *best* it can report — a manually verified source that is
    within its cadence is MANUAL, never CURRENT, because somebody remembering to
    check is not the same assurance as a check that happens on its own.
    """
    if last_checked_at is None:
        return STALE
    age_days = (now - last_checked_at).total_seconds() / 86400
    if age_days <= cadence_days:
        return MANUAL if polling_status == MANUAL_POLLING else CURRENT
    if age_days <= cadence_days * 2:
        return DUE
    return STALE


def worst(values: list[str]) -> str:
    """Roll several freshness values into one.

    Worst-wins, and an empty set is STALE rather than CURRENT: a regime with no
    sources at all is not up to date, it is unmonitored, and the badge should
    not reward it for having nothing to be late about.
    """
    if not values:
        return STALE
    return min(values, key=lambda v: _SEVERITY.get(v, 0))


def describe(session: Session, now: datetime | None = None) -> list[SourceState]:
    """Every source row with its derived freshness, worst first."""
    now = now or datetime.now(timezone.utc)
    rows = session.scalars(select(WatchSource).order_by(WatchSource.id)).all()
    out: list[SourceState] = []
    for row in rows:
        state = freshness(
            row.last_checked_at,
            row.cadence_days,
            now,
            polling_status=row.polling_status,
        )
        if is_breaching(row) and state in (CURRENT, MANUAL):
            # A source we cannot read is not current, whatever its last
            # successful read says. Without this a monthly source could sit on a
            # green badge for a month after going dark — its cadence has not
            # elapsed, so nothing is overdue yet — which is precisely the
            # situation this screen exists to make visible. Found by looking at
            # the screen with a source marked unreachable: CURRENT in green, and
            # "not answering" in red underneath it.
            #
            # DUE rather than STALE: the cadence carries it to STALE in the
            # normal way if nobody fixes it, and overstating the age of the last
            # good read would be its own kind of wrong.
            state = DUE
        overdue = None
        if row.last_checked_at is not None:
            age = (now - row.last_checked_at).total_seconds() / 86400
            overdue = max(0, int(age - row.cadence_days))
        out.append(
            {
                "id": row.id,
                "jurisdiction": row.jurisdiction,
                "name": row.name,
                "url": row.url,
                "cadence_days": row.cadence_days,
                "last_checked_at": row.last_checked_at.isoformat() if row.last_checked_at else None,
                "last_mode": row.last_mode,
                "polling_status": row.polling_status,
                "fetcher": row.fetcher,
                # The most recent attestation, for a source nothing can poll.
                # `MANUAL` on a screen with no name against it is an assertion
                # somebody has to go and chase; with a name and a date it is a
                # record they can act on.
                "last_verification": newest_verification(session, row),
                "enabled": row.enabled,
                "freshness": state,
                "days_overdue": overdue,
                "owner": row.owner,
                "consecutive_failures": row.consecutive_failures,
                "alert_after_failures": row.alert_after_failures,
                "last_error": row.last_error,
                "last_failed_at": (
                    row.last_failed_at.isoformat() if row.last_failed_at else None
                ),
                "breaching": is_breaching(row),
            }
        )
    out.sort(key=lambda s: (_SEVERITY.get(s["freshness"], 0), s["jurisdiction"], s["id"]))
    return out


def mark_checked(
    session: Session,
    source_id: str,
    when: datetime,
    how: str,
    *,
    fetcher: str = "",
    content_hash: str | None = None,
) -> None:
    """A check that worked.

    Clears the failure count and the page marker together. A source that is
    answering again is not in breach, and leaving `alerted_at` set would mean
    the *next* outage went unannounced — the failure mode of every alerting
    system that only ever fires once.
    """
    row = session.get(WatchSource, source_id)
    if row is None:
        return
    row.last_checked_at = when
    row.last_mode = how
    if fetcher:
        row.fetcher = fetcher
    if content_hash is not None:
        # Written only by the adapter that uses it, and only after a read that
        # worked. A digest recorded after a failed fetch would make the next
        # check report "unchanged" about a page nobody managed to read.
        row.content_hash = content_hash
    row.consecutive_failures = 0
    row.last_error = ""
    row.alerted_at = None


def mark_failed(session: Session, source_id: str, when: datetime, error: str) -> int:
    """A check that was attempted and did not work. Returns the new count.

    `last_checked_at` is deliberately *not* advanced. A timeout is not a check;
    treating it as one would let a source that has been down for a month keep
    showing as freshly checked, which is the single most misleading thing this
    screen could say.
    """
    row = session.get(WatchSource, source_id)
    if row is None:
        return 0
    row.consecutive_failures = (row.consecutive_failures or 0) + 1
    row.last_error = error
    row.last_failed_at = when
    return row.consecutive_failures


def is_breaching(row: WatchSource) -> bool:
    """Past its own threshold, and so somebody's problem rather than a blip."""
    threshold = row.alert_after_failures or DEFAULT_ALERT_AFTER
    return (row.consecutive_failures or 0) >= threshold


def due(rows: list[WatchSource], now: datetime) -> list[WatchSource]:
    """The sources a scheduled sweep should actually check now.

    Cadence is a promise about how often a source is read, and reading a monthly
    source every ten minutes keeps neither the promise nor the publisher's
    goodwill. A source that has never been checked is always due — that is the
    state it starts in, and waiting a cadence before the first read would leave
    a new source silently unwatched for a month.
    """
    out = []
    for row in rows:
        if not row.enabled:
            continue
        if row.last_checked_at is None:
            out.append(row)
            continue
        age_days = (now - row.last_checked_at).total_seconds() / 86400
        if age_days >= row.cadence_days:
            out.append(row)
    return out


def breaches(session: Session, *, unalerted_only: bool = False) -> list[WatchSource]:
    """Sources at or past their alert threshold, worst first.

    `unalerted_only` is what a sweep pages on: everything in breach that the
    owner has not already been told about. The full list is what a screen shows,
    because an alert somebody has seen is still an outage that is still running.
    """
    rows = session.scalars(
        select(WatchSource).where(WatchSource.enabled.is_(True))
    ).all()
    out = [r for r in rows if is_breaching(r)]
    if unalerted_only:
        out = [r for r in out if r.alerted_at is None]
    out.sort(key=lambda r: (-(r.consecutive_failures or 0), r.id))
    return out


def mark_alerted(session: Session, source_id: str, when: datetime) -> None:
    """Record that the owner has been paged, so the next sweep does not re-page."""
    row = session.get(WatchSource, source_id)
    if row is not None:
        row.alerted_at = when


# ---------------------------------------------------------- manual verification


class NotManual(ValueError):
    """Somebody tried to attest to a source a machine already reads.

    Refused rather than recorded. A human attestation over a polled source
    claims something the poller already establishes, and — worse — it would
    reset the freshness clock on a source whose poller had silently stopped.
    The screen would then show green because a person said so about a check
    nobody performed.
    """


def verify_manually(
    session: Session,
    source_id: str,
    *,
    verified_on: date,
    verified_by: str,
    note: str = "",
    attachment_ref: str = "",
    now: datetime | None = None,
) -> SourceVerification:
    """Record that a person checked a source nothing can poll.

    Two writes, and the split matters. The attestation goes in
    `source_verifications`, which is append-only — it is somebody putting their
    name to a claim. The freshness clock on `watch_sources` is derived state and
    is updated to match, the same way a successful poll updates it, so the
    rollup needs to know nothing about how the check happened.

    A future date is refused. "I checked it on Friday" recorded on Monday is the
    normal case and is allowed; "I checked it next Tuesday" is either a typo or
    somebody buying themselves freshness they have not earned.
    """
    row = session.get(WatchSource, source_id)
    if row is None:
        raise LookupError(f"no watch source {source_id!r}")

    if row.polling_status != MANUAL_POLLING:
        raise NotManual(
            f"{source_id} is polled automatically. A person attesting to it "
            "would claim what the poller already establishes, and would reset "
            "the clock on a poller that had silently stopped."
        )

    moment = now or datetime.now(timezone.utc)
    # The attesting person's own calendar day, not the container's. FP3-05.
    #
    # `moment.date()` is UTC, and `source_verifications` is tenant-scoped: this
    # is a named person at a firm putting their name to a claim. A Sydney
    # specialist recording this morning's check before 10am local was told the
    # date was in the future — "freshness nobody has earned" pointed at somebody
    # doing exactly what they were asked to.
    #
    # Not caught by `guard_no_naive_today.sh` when it was written, because this
    # spells the business date `datetime.now(timezone.utc).date()` rather than
    # `date.today()`. The guard covers that spelling now.
    today = business_time.business_today(session, now=moment)
    if verified_on > today:
        raise ValueError(
            f"{verified_on.isoformat()} is in the future. Recording a check "
            "that has not happened is freshness nobody has earned."
        )

    verification = SourceVerification(
        id=new_id("srcver"),
        source_id=source_id,
        verified_on=verified_on,
        verified_by=verified_by,
        note=note,
        attachment_ref=attachment_ref,
    )
    session.add(verification)

    # The clock only moves forward. Recording an older check after a newer one —
    # somebody catching up on paperwork — must not make the source look staler
    # than the most recent attestation already made it.
    stamp = datetime.combine(verified_on, time.min, tzinfo=timezone.utc)
    if row.last_checked_at is None or stamp > row.last_checked_at:
        row.last_checked_at = stamp
        row.last_mode = VERIFIED
    session.flush()
    return verification


def newest_verification(session: Session, row: WatchSource) -> dict[str, str] | None:
    """The latest attestation for a manual source, or None.

    Queried only for manual sources: an automatic one cannot have an
    attestation — `verify_manually` refuses — so asking would be a query per
    row on the currency screen to learn nothing.
    """
    if row.polling_status != MANUAL_POLLING:
        return None
    latest = session.scalars(
        select(SourceVerification)
        .where(SourceVerification.source_id == row.id)
        .order_by(SourceVerification.verified_on.desc(), SourceVerification.id.desc())
        .limit(1)
    ).first()
    if latest is None:
        return None
    return {
        "verified_on": latest.verified_on.isoformat(),
        "verified_by": latest.verified_by,
        "note": latest.note,
        "attachment_ref": latest.attachment_ref,
    }


def verifications(
    session: Session, source_id: str, *, limit: int = 20
) -> list[SourceVerification]:
    """This source's attestations, newest first."""
    return list(
        session.scalars(
            select(SourceVerification)
            .where(SourceVerification.source_id == source_id)
            .order_by(SourceVerification.verified_on.desc(), SourceVerification.id.desc())
            .limit(limit)
        )
    )
