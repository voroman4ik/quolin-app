"""The one place a model is allowed to read, and the line it cannot cross.

"Is an AI writing your rules?" is a question every customer asks, and §S6 says
the answer has to be a *provable* no rather than a policy. This module is where
the proof lives. It is the only code in the system that talks to a model, and
everything about its shape is chosen so that the answer stays no under pressure.

**A model can only ever raise a hand.** `apply` returns a boolean — whether to
escalate — and there is no code path by which a suggestion becomes a tier, a
threshold, a rule or a determination. The tier stored on a watch event is the
one `triage.classify` computed from pack vocabulary, before this module runs and
regardless of what it says. Read `apply` and you have read the whole of the
model's authority.

**Uncertainty escalates.** A confident suggestion that an item matters raises it;
an *unconfident* suggestion also raises it. There is no confidence score low
enough to make an item quieter, because the failure this ordering prevents is
the expensive one: a missed rule change costs a firm a remediation programme, and
a false positive costs somebody thirty seconds. A threshold that could suppress
would be a model deciding something.

**Every call is retained.** Prompt, response, model id and confidence go into an
append-only table. A summary an officer read and acted on is part of how a
decision came to be made, and "what did it actually say" must be answerable in
two years by somebody who does not trust us.

**It runs in the watch service and nowhere else.** The watch task is the only
deployment given a model credential, `app/watch` may not import the engine or the
service layer, and `scripts/guard_no_watch_in_engine.sh` fails CI if either
stops being true. Absent a credential this module is inert and the watch service
is exactly what it was before: string matching over a vocabulary the content team
wrote.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any

from . import triage

#: The model. Opus 5 rather than something cheaper because the failure mode of a
#: weaker classifier here is a missed rule change, and this runs a handful of
#: times per sweep rather than per request.
DEFAULT_MODEL = "claude-opus-5"

#: Below this, a suggestion escalates *because* it is uncertain rather than
#: because of what it says. See the module note: there is no score low enough to
#: make an item quieter.
DEFAULT_MIN_CONFIDENCE = 0.7

#: How the model is told to answer. A schema rather than a prompt asking nicely
#: for JSON: the caller has to parse this to store it, and a parse failure in a
#: sweep is a silent gap in the retention record.
RESPONSE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "summary": {
            "type": "string",
            "description": (
                "Two sentences at most, for a compliance officer deciding "
                "whether to read the full publication."
            ),
        },
        "touches_rule_content": {
            "type": "boolean",
            "description": (
                "Whether this publication appears to bear on the rule content "
                "described. A judgement about relevance, not about correctness."
            ),
        },
        "confidence": {
            "type": "number",
            "description": "0 to 1. Be honest rather than generous.",
        },
        "reason": {
            "type": "string",
            "description": "One sentence saying what in the text led to that.",
        },
    },
    "required": ["summary", "touches_rule_content", "confidence", "reason"],
    "additionalProperties": False,
}

INSTRUCTIONS = """You are reading a regulatory publication on behalf of a \
compliance team, so that a human being can decide what to read first.

You are not deciding anything. Your output sorts a queue and is recorded \
alongside the publication; it never changes a rule, a threshold, or any \
determination made about a client. Say so to yourself before you answer, \
because it should change how you answer: you are not being asked whether the \
firm is compliant, only whether this publication looks like it bears on the \
rule content described below.

Be honest about confidence. An unconfident answer is escalated to a person, \
which is the correct outcome and costs nobody anything. An overconfident one \
sends somebody to the wrong document."""


@dataclass(frozen=True)
class Suggestion:
    """What a model said about one publication, and how sure it was."""

    summary: str
    touches_rule_content: bool
    confidence: float
    reason: str
    model: str
    prompt: str
    output: str


class AssistUnavailable(RuntimeError):
    """Asked for a model when none is configured.

    Raised rather than returning None so that a deployment that *meant* to have
    the assistant on finds out, instead of running for a month producing
    perfectly good rule-based triage that somebody believes is model-assisted.
    """


def model_name() -> str:
    return os.getenv("WATCH_ASSIST_MODEL", DEFAULT_MODEL).strip() or DEFAULT_MODEL


def min_confidence() -> float:
    try:
        return float(os.getenv("WATCH_ASSIST_MIN_CONFIDENCE", DEFAULT_MIN_CONFIDENCE))
    except ValueError:
        return DEFAULT_MIN_CONFIDENCE


def available() -> bool:
    """Whether this process holds a credential for the model.

    The credential is the boundary. Core-api is not given one — see
    `docs/llm-boundary.md` and the guard script — so this is False there even
    though the code is present in the same image.
    """
    return bool(os.getenv("ANTHROPIC_API_KEY", "").strip())


def _prompt(
    *, title: str, summary: str, jurisdiction: str, vocabulary: list[dict[str, Any]]
) -> str:
    """What the model is shown. Built here so the stored prompt is the real one.

    The pack's own vocabulary is included because it is what "rule content" means
    for this regime — the same terms `triage.classify` matched on. Giving the
    model a different notion of relevance from the deterministic tier would make
    the two incomparable, and comparing them is the entire use.
    """
    terms = ", ".join(sorted({str(v.get("term", "")) for v in vocabulary if v.get("term")}))
    return (
        f"{INSTRUCTIONS}\n\n"
        f"Regime: {jurisdiction}\n"
        f"Rule content is described by these terms: {terms or '(none recorded)'}\n\n"
        f"Publication title: {title}\n"
        f"Publication summary: {summary or '(the feed gave none)'}\n"
    )


def read(
    *,
    title: str,
    summary: str = "",
    jurisdiction: str,
    vocabulary: list[dict[str, Any]] | None = None,
    client: Any | None = None,
) -> Suggestion:
    """Ask the model about one publication. Returns what it said, verbatim.

    `client` is injectable so tests drive a stub: this module must be testable
    without a credential, or the only way to exercise the boundary would be to
    cross it.
    """
    import anthropic

    if client is None:
        if not available():
            raise AssistUnavailable(
                "No model credential in this process. The watch task is the only "
                "deployment given one — see docs/llm-boundary.md."
            )
        client = anthropic.Anthropic()

    prompt = _prompt(
        title=title,
        summary=summary,
        jurisdiction=jurisdiction,
        vocabulary=vocabulary or [],
    )
    model = model_name()
    response = client.messages.create(
        model=model,
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
        output_config={
            "format": {"type": "json_schema", "schema": RESPONSE_SCHEMA},
            # Reading one press release and saying whether it looks relevant is
            # not hard work. Effort is where the cost of running this over every
            # item in every sweep is decided.
            "effort": "low",
        },
    )

    # `output_config.format` guarantees the first text block is valid JSON, but
    # the response type covers every block a model can emit, so the narrowing is
    # spelled out rather than assumed — and a response with no text block at all
    # is a failure worth a message that says which model produced it.
    output = next(
        (
            block.text
            for block in response.content
            if isinstance(block, anthropic.types.TextBlock)
        ),
        None,
    )
    if output is None:
        raise ValueError(f"{model} returned no text block to read")
    data = json.loads(output)
    return Suggestion(
        summary=str(data["summary"]),
        touches_rule_content=bool(data["touches_rule_content"]),
        confidence=float(data["confidence"]),
        reason=str(data["reason"]),
        model=model,
        prompt=prompt,
        output=output,
    )


def apply(suggestion: Suggestion, *, deterministic_tier: str) -> tuple[bool, str]:
    """Whether to raise a hand about this item, and why. Nothing else.

    A boolean and a sentence. This function is the whole of the model's
    authority in this system, and it is short on purpose: a reader checking
    whether a model can influence a determination should be able to satisfy
    themselves in the time it takes to read one screen.

    Three outcomes:

    * **Uncertain** — escalated. Not because of what it said but because it did
      not know, and a person is the right place for that.
    * **Confident that it matters, where the vocabulary found nothing** —
      escalated. This is the case the assistant is *for*: a hand-written
      vocabulary has gaps, and a publication that uses a word nobody thought of
      still matters.
    * **Anything else** — nothing happens. In particular, a confident "this does
      not matter" is *not* a reason to lower an item the pack's own vocabulary
      matched. The pack is the authority on what its content is.
    """
    if suggestion.confidence < min_confidence():
        return True, (
            f"The model was unsure ({suggestion.confidence:.0%}), so this is raised "
            "for a person to read. Uncertainty escalates here rather than settling."
        )
    if suggestion.touches_rule_content and deterministic_tier != triage.TOUCHES_RULE_CONTENT:
        return True, (
            "Nothing in this publication matched the pack's vocabulary, but the "
            f"model thinks it bears on rule content ({suggestion.confidence:.0%}): "
            f"{suggestion.reason}"
        )
    return False, ""
