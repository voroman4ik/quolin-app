"""Regulatory currency: what has been published, and who has to sign for it.

The public surface of this package is deliberately small, and it is entirely
read-and-propose. Nothing exported here evaluates anything, and nothing in
`api/app/engine` imports this package — `scripts/guard_no_watch_in_engine.sh`
fails CI if that ever stops being true.

The one path from a publication to live rule content is:

    poll.poll -> triage.classify -> drafts.create -> drafts.sign -> drafts.publish

and `drafts.publish` refuses any draft that has not been through `sign`.
"""

from __future__ import annotations

from . import currency, drafts, poll, sources, triage

__all__ = ["currency", "drafts", "poll", "sources", "triage"]
