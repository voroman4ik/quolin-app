"""Proposing a rule change, and the one gate it cannot get past on its own.

This module is the reason the watch service is defensible. Everything upstream
of it — polling, triage, the queue — is a research assistant reading gazettes.
The moment any of that could alter what the evaluator uses, the system stops
being a compliance tool and becomes an unreviewed robot writing regulation, and
no compliance officer would sign the licence attestation for it.

So there is exactly one path from a watch event to live rule content, and it
runs through `sign()`. A draft is inert: nothing in `api/app/engine` can see
this table, `packs_repo.active()` does not read it, and `publish()` refuses a
draft that no named person has signed. The refusal is an exception rather than a
returned error, because a caller that forgets to check a boolean is a plausible
bug and a caller that swallows an exception to publish unsigned content is not.

One thing this module deliberately does not do: close the previous pack's
`effective_to`. The `packs` table is append-only at the database level, so it
could not, and it should not want to — a pack is superseded by a later one
becoming effective, which `packs_repo.active()` resolves by date. Nothing is
edited to make a new version take over.
"""

from __future__ import annotations

import copy
from datetime import date, datetime, timezone
from typing import Any

from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from .. import attestation, business_time, identity, packs_repo
from ..models import Pack as PackRow
from ..models import (
    PackDraft,
    PackPublication,
    PlatformPublisher,
    PublicationApproval,
)
from ..tenancy import current_user_or_none

# The states and the moves between them live in `lifecycle.py`, and are
# re-exported here so that every existing caller keeps working. One definition,
# because two lists of the same states is two lists that drift — and the one
# that drifts is the one the transition table is checked against.
from . import lifecycle  # noqa: E402

# Spelled `X as X` because `no_implicit_reexport` is on for `app.watch.*` — the
# strict subset invariant 6 is enforced under. A re-export has to be deliberate,
# and this is what deliberate looks like.
from .lifecycle import DRAFT as DRAFT  # noqa: E402
from .lifecycle import EFFECTIVE as EFFECTIVE  # noqa: E402
from .lifecycle import IN_REVIEW as IN_REVIEW  # noqa: E402
from .lifecycle import PUBLISHED as PUBLISHED  # noqa: E402
from .lifecycle import REJECTED as REJECTED  # noqa: E402
from .lifecycle import SIGNED as SIGNED  # noqa: E402
from .lifecycle import STATUSES as STATUSES  # noqa: E402
from .lifecycle import SUPERSEDED as SUPERSEDED  # noqa: E402
from .lifecycle import IllegalTransition as IllegalTransition  # noqa: E402
from .lifecycle import content_hash as content_hash  # noqa: E402

#: Namespace for the version-allocation advisory lock, so a hash collision with
#: another use of advisory locks in this database cannot deadlock two unrelated
#: things. The evidence chain picks its namespace the same way.
_VERSION_LOCK_NAMESPACE = 0x5041434B  # "PACK"

#: The author a draft the watch service cut records, and its printed name.
#:
#: Not a `users` row and deliberately not shaped like one: every human account
#: in this system is `usr_…` and every machine credential is `apc_…`, so this
#: cannot be mistaken for either in a log, a screen or a published pack. It is
#: the honest answer to "who proposed this rule change" for content a gazette
#: reader assembled — and it is exactly the case where the signature has to come
#: from somewhere else entirely, because nothing here reviewed anything.
WATCH_SERVICE = "svc_watch"
WATCH_SERVICE_NAME = "Quolin watch service"

#: The grant that qualifies somebody to be the independent read on content their
#: colleague both wrote and signed. Spelled here rather than imported from
#: `rbac`, which is request-layer: this is a rule about the act, and it has to
#: hold for a caller that never went through a route.
SIGNATORY_ROLE = "pack_signatory"


class NotSigned(PermissionError):
    """A draft was asked to become rule content without a signature."""

    def __init__(self, draft_id: int, status: str):
        self.draft_id = draft_id
        self.status = status
        super().__init__(
            f"draft {draft_id} is {status!r}, not {SIGNED!r}. Rule content is only "
            "ever created by a named person signing a draft. Nothing has been "
            "published and no pack version was created."
        )


class SelfReview(PermissionError):
    """One person tried to be both the signature and the second look at it.

    A sibling of `NotSigned` and raised for the same reason it is an exception
    rather than a returned flag: a caller that forgets to check a boolean is a
    plausible bug, and a caller that swallows an exception to publish its own
    signature is not.
    """

    def __init__(self, draft_id: int, signed_by: str):
        self.draft_id = draft_id
        super().__init__(
            f"draft {draft_id} was signed by {signed_by or 'nobody identifiable'} and "
            "must be published by somebody else. Publication is the second pair of "
            "eyes on signed rule content; one person doing both is not a review. "
            "Nothing has been published and no pack version was created."
        )


class SelfAuthoredSignature(PermissionError):
    """Somebody signed content they wrote, with nobody else having read it.

    Distinct from `SelfReview`, which is about publication, and the distinction
    is the whole of this finding. `SelfReview` asks whether the person pressing
    publish is the person who signed — a second pair of eyes on the *signature*.
    This asks whether anybody but the author has read the *content*. A publisher
    who is not the signatory still cannot check rule content they did not read;
    what they can check is that a named specialist attested to it. If that
    specialist is also the person who wrote it, the chain of review is one
    person long and the two later signatures are agreeing with a claim nobody
    independent ever examined.

    An exception rather than a returned flag, for the reason every refusal in
    this module is: a caller that forgets to check a boolean is a plausible bug,
    and a caller that swallows this is not.
    """

    def __init__(self, draft_id: int, author: str):
        self.draft_id = draft_id
        super().__init__(
            f"draft {draft_id} was written by {author or 'this account'}, and this "
            "account is signing it. Rule content is attested to by somebody other "
            "than its author — or, where the author is the only specialist for "
            "this regime, by the author with an independent second reviewer "
            "recorded first. Nothing has been signed."
        )


class NotQualifiedToReview(PermissionError):
    """The second reviewer does not hold `pack_signatory` for this regime.

    The same bar the signature itself is held to, and for the same reason:
    competence to attest for one regime is not competence to attest for another,
    so a second read by somebody qualified elsewhere is not the independent
    review this exists to require. Checked against the grant as it stands now
    rather than as it stood when the review was recorded — a withdrawn
    qualification is a reason the author may no longer sign their own work, not
    a technicality the recorded row can carry them past.
    """

    def __init__(self, draft_id: int, reviewer: str | None, jurisdiction: str):
        self.draft_id = draft_id
        super().__init__(
            f"{reviewer or 'this account'} is not a {SIGNATORY_ROLE} for "
            f"{jurisdiction}, so their read of draft {draft_id} is not the "
            "independent review that lets an author sign their own content."
        )


class NotIndependent(PermissionError):
    """A second review by the person who wrote the thing being reviewed."""

    def __init__(self, draft_id: int, who: str | None):
        self.draft_id = draft_id
        super().__init__(
            f"{who or 'this account'} wrote draft {draft_id} and cannot be the "
            "independent read on it. A second review is what makes an author's "
            "own signature acceptable; performed by the author it makes it "
            "nothing at all."
        )


#: The CHECK constraints on `pack_drafts` that a row written before them can
#: violate. Both were added `NOT VALID` and both were added that way on purpose:
#: this repository's own suite signed self-authored drafts for thirteen stages,
#: and every review recorded between migrations 0049 and 0050 named a person and
#: no hash. Validating either would mean rewriting history until nothing
#: violated, which is manufacturing a clean one.
#:
#: `NOT VALID` does not mean "never checked": an UPDATE to such a row re-checks
#: it, and publication updates the row. So a legacy draft reaching publication
#: makes Postgres raise — correctly — and `PredatesTheConstraint` is what stops
#: that arriving as a traceback.
LEGACY_CONSTRAINTS = (
    "pack_drafts_signature_is_independent",
    "pack_drafts_self_signature_reviewed_these_bytes",
)


class PredatesTheConstraint(PermissionError):
    """This row was written before the rule it is now being asked to satisfy.

    H1. Not a defect in the caller and not an attack: a draft signed under the
    rules as they stood, being moved by a transaction that re-checks a
    constraint added afterwards. What was wrong was the *response* — an
    unhandled `IntegrityError` reaching the client as a 500 with a traceback in
    the logs, which tells an operator nothing about which draft or which rule
    and reads as a broken deployment rather than as a refusal.

    Named as a refusal instead, with the draft and the constraint in it, and
    `docs/runbooks/legacy-draft-rows.md` says what to do with one. A row this
    fires on has a real problem — its signature is its author's with no
    independent read behind it, or a read of bytes it cannot name — and the
    answer is to raise a fresh draft, not to loosen the constraint.
    """

    def __init__(self, draft_id: int, constraint: str):
        self.draft_id = draft_id
        self.constraint = constraint
        super().__init__(
            f"draft {draft_id} cannot be moved: it violates {constraint}, which "
            "was added after the row was written and is checked whenever the row "
            "changes. The signature on it is its own author's with no "
            "independent read behind it that names the content. Nothing has "
            "been published and no pack version was created — see "
            "docs/runbooks/legacy-draft-rows.md."
        )


def refusal_for_a_violating_row(
    draft_id: int, exc: BaseException
) -> PredatesTheConstraint | None:
    """`PredatesTheConstraint` where this integrity error is one, else `None`.

    Matched on the constraint name rather than on the exception type, because
    every other `IntegrityError` this transaction can raise — a duplicate pack
    version, a duplicate approval — is a different incident with a different
    answer, and a handler that swallowed all of them would turn a genuine
    collision into a sentence about legacy rows.

    Returning `None` rather than raising is what makes that explicit at the call
    site: the caller re-raises what it does not recognise.
    """
    detail = str(getattr(exc, "orig", None) or exc)
    for constraint in LEGACY_CONSTRAINTS:
        if constraint in detail:
            return PredatesTheConstraint(draft_id, constraint)
    return None


class ReviewedBytesMoved(PermissionError):
    """The body in front of `record_second_review` is not the body that was read.

    F1, and the sibling of `ReviewedBytesChanged` one window *earlier* again.
    There are three windows around an attestation and this module now guards
    all three: `SignedBytesChanged` covers signature -> publication,
    `ReviewedBytesChanged` covers review -> signature, and this covers the
    reading -> review.

    B1 recorded `content_hash(draft.body)` when the review was posted, which
    binds the review to the bytes the POST found rather than to the bytes the
    reviewer had in front of them. An author holding `operator` can edit inside
    that gap, and the auditor did:

        the reviewer reads the draft
          -> the author edits a threshold
          -> the reviewer posts their approval
          -> the author signs their own draft

    200, signed by the author, and the reviewer's account on content they never
    saw — the same outcome B1 closed, through the same ordinary routes, one
    window along. A rule pack is read for minutes, so the window is not
    theoretical.

    Distinct from `ReviewedBytesChanged` on purpose, and the two say different
    things to different people. That one tells an *author* their draft moved
    after the review and they may not sign it. This tells a *reviewer* that what
    they are approving is not what they were shown — which is not a refusal of
    their authority but a warning about their screen, and reads as one.
    """

    def __init__(self, draft_id: int, submitted: str):
        self.draft_id = draft_id
        #: What the caller said it read. Kept for the audit rather than for the
        #: message: a hash in an error a person reads is noise, and a hash in a
        #: log is the thing that answers which version they had.
        self.submitted = submitted
        super().__init__(
            f"draft {draft_id} changed while it was being reviewed, so this "
            "approval would attest to content that was not on the screen it was "
            "given on. Nothing has been recorded and no review now stands. "
            "Re-read the draft as it now stands and approve it again — and if "
            "you did not expect it to have changed, ask its author what they "
            "altered."
        )


class SignedBytesMoved(PermissionError):
    """The body in front of `sign` is not the body the signatory read.

    F1's own defect, one route along. F1 bound the *review* to the bytes the
    reviewer read and stopped there, because that was the route that had been
    reported. `SignRequest` carried only a note, its docstring said so — "Only
    the note travels" — and twenty lines below it `SecondReviewRequest` explained
    at length why a hash has to travel beside an attestation. Two classes,
    adjacent in one file, one bound and one not.

    So the auditor ran F1's own sequence through the sibling:

        the signatory opens the draft and reads
        `max_crypto_concentration_bps = 1000`
          -> its author, who holds `operator`, PATCHes it to 9999
          -> the signatory POSTs their signature

    200, and `content_hash` on the row is of the edited body. The signatory's
    name, account and qualification reference all sit against bytes they never
    saw, and it publishes: `SignedBytesChanged` guards signature -> publication,
    and nothing guarded reading -> signature.

    A sibling of `ReviewedBytesMoved`, not of `SignedBytesChanged`, and the
    naming is the finding. `SignedBytesChanged` is about the draft — it tells a
    *publisher* that content moved after somebody signed it. This is about the
    screen: it tells a *signatory* that what they are about to put their name to
    is not what they were shown. The word is `Moved` for the same reason it is on
    `ReviewedBytesMoved`: these two are the reading windows, and they are the
    ones a person can close by reading the draft again.
    """

    def __init__(self, draft_id: int, submitted: str):
        self.draft_id = draft_id
        #: What the caller said it read. Kept for the audit rather than for the
        #: message, exactly as on `ReviewedBytesMoved`.
        self.submitted = submitted
        super().__init__(
            f"draft {draft_id} changed while it was being read, so this signature "
            "would attest to content that was not on the screen it was given on. "
            "Nothing has been signed. Re-read the draft as it now stands and sign "
            "that — and if you did not expect it to have changed, ask its author "
            "what they altered before you do."
        )


class ApprovedBytesMoved(PermissionError):
    """The body in front of `approve_publication` or `publish` is not the body
    the approver read.

    Found by the census rather than reported, and it is the same defect as
    `SignedBytesMoved` with a wider window. Both publication routes took **no
    request body at all**, so an approver had no way to say what they had read
    even if they had wanted to, and `PublicationApproval.content_hash` was
    computed when the POST arrived — which is B1's own shape, one act later.

    The window spans the signature, which is what makes it wider than the
    signatory's:

        a platform publisher opens the draft and reads
        `max_crypto_concentration_bps = 1000`
          -> its author, who holds `operator`, PATCHes it to 9999
          -> a signatory signs the edited body
          -> the publisher approves, and a second publishes

    Both of their accounts against content neither had seen, and it goes live
    for every firm under the regime. `edit_draft` refuses a `SIGNED` draft and
    `SignedBytesChanged` catches an edit that lands out of band after the
    signature, so the half of the window *after* the signature was already shut.
    The half before it was not, and reading a draft before it is signed is the
    ordinary way a publisher decides whether to approve one.

    One class for both routes, deliberately. `publish`'s own docstring says
    pressing publish counts as an approval — "requiring the publisher to record a
    separate approval first would be ceremony rather than control" — so the two
    routes are one attestation made by two people, and a second exception class
    would be two names for one claim.
    """

    def __init__(self, draft_id: int, submitted: str):
        self.draft_id = draft_id
        self.submitted = submitted
        super().__init__(
            f"draft {draft_id} is not the content this approval was given on, so "
            "putting it in force would record your name against bytes you were "
            "not shown — in front of every firm under this regime. Nothing has "
            "been approved and nothing has been published. Read the draft as it "
            "now stands, check that it is still what you meant to approve, and "
            "approve that."
        )


def _the_bytes_that_were_read(
    draft: PackDraft,
    submitted: str,
    *,
    moved: type[PermissionError],
) -> str:
    """Refuse unless `submitted` is the hash of the body on the row right now.

    The one comparison behind every read-to-attestation binding in this module,
    written once so that there is one place to read it and one place for it to be
    wrong. `record_second_review`, `sign`, `approve_publication` and `publish`
    all reach it; the only thing that differs between them is which refusal a
    caller meets, because a reviewer, a signatory and a publisher are being told
    three different things about three different screens. Three refusals for
    four routes, since the two publication routes are one attestation made by
    two people.

    Compared with `!=` on the exact string, and with no "empty means unchanged"
    branch. An absent, blank or malformed hash fails like any other wrong value,
    because the claim being made is *these bytes were read* — and a caller with
    nothing to compare has not made it. Every route makes the same field required
    at the schema, so the two layers refuse for the same reason at two distances
    from the caller.

    Returns the hash it computed, so that the recorder writes its column from the
    row rather than from the request. A value copied out of a request body would
    be a hash of whatever the caller felt like sending, which is the shape of
    every field these routes deliberately do not have.
    """
    current = content_hash(draft.body)
    if submitted != current:
        raise moved(draft.id, submitted)
    return current


class ReviewedBytesChanged(PermissionError):
    """The body in front of `sign` is not the body the second review read.

    B1, and the sibling of `SignedBytesChanged` one window earlier. That one
    guards the gap between the signature and publication; this guards the gap
    between the independent read and the signature, which had no guard at all.

    Migration 0049 recorded who performed the second review and when, and `sign`
    asked only whether the reviewer column was populated. So an author could
    obtain an independent review, edit the body, and sign their own draft: the
    reviewer was still set, the constraint was still satisfied, and the
    signature attested to bytes nobody but their author had ever seen. Both
    external audits found it, and one of them ran it.

    The principal it needs holds `operator` and `pack_signatory` — an operator
    may edit a draft and a signatory may sign one — which is the S5 workbench
    workflow rather than a corner case.

    An exception rather than a returned flag, for the reason every refusal in
    this module is: a caller that forgets to check a boolean is a plausible bug,
    and a caller that swallows this to sign anyway is not.
    """

    def __init__(self, draft_id: int, reviewer: str | None):
        self.draft_id = draft_id
        super().__init__(
            f"draft {draft_id} has changed since {reviewer or 'the second reviewer'} "
            "read it, and this account wrote it. A signature by an author is "
            "acceptable only because somebody independent read *this* content; a "
            "review of superseded content is not a review of it. Ask for the "
            "draft to be reviewed again, or have somebody else sign it. Nothing "
            "has been signed."
        )


class SignedBytesChanged(PermissionError):
    """The body in front of `publish` is not the body that was signed.

    F4. `sign` records `content_hash(draft.body)`; `publish` computed a hash of
    its own over a body it had just mutated and compared it to nothing. The
    status was doing the work: `SIGNED` was treated as proof that the bytes had
    not moved since.

    `pack_drafts` is mutable working state — this module's own docstring says so
    — and `main.edit_draft` refuses on status without taking a row lock. So an
    edit that lands between the signature and the publication, whether from a
    racing request or from a shell, went live under the signatory's name, user
    id and qualification reference. Content that reads as reviewed is worse than
    content that reads as unsigned, because unsigned content is refused to every
    acting firm and this was not.

    A sibling of `NotSigned` and `SelfReview`, raised for the same reason both
    are exceptions rather than returned flags: a caller that forgets to check a
    boolean is a plausible bug, and one that swallows this to publish anyway is
    not.
    """

    def __init__(self, draft_id: int, signed_by: str):
        self.draft_id = draft_id
        super().__init__(
            f"draft {draft_id} has been edited since {signed_by or 'its signatory'} "
            "signed it, so publishing it would put bytes nobody attested to in "
            "front of every firm under this regime — under that signature and "
            "qualification reference. Nothing has been published and no pack "
            "version was created. A specialist has to look at what the draft now "
            "says and sign it again."
        )


class AlreadyResolved(ValueError):
    def __init__(self, draft_id: int, status: str):
        super().__init__(f"draft {draft_id} is already {status!r}")


def highest_version(session: Session, jurisdiction: str) -> int | None:
    """The largest version number this regime has published, or None.

    Read as a maximum rather than as "the first row of something roughly
    ordered". `packs_repo.by_version` had the same shape of bug — `.first()`
    with no `ORDER BY` — and it is the kind that behaves perfectly until the
    plan changes.
    """
    return session.scalar(
        select(func.max(PackRow.version)).where(PackRow.jurisdiction == jurisdiction)
    )


def _is_signatory_for(session: Session, user_id: str | None, jurisdiction: str) -> bool:
    """Whether this account holds a live `pack_signatory` grant for this regime.

    Read through `identity.roles_for`, which filters the tenant explicitly and
    drops expired grants, rather than by querying `user_roles` here — a second
    implementation of "is this grant live" is a second place for a revoked role
    to go on authorising.
    """
    if not user_id:
        return False
    return any(
        grant.role == SIGNATORY_ROLE and grant.jurisdiction == jurisdiction
        for grant in identity.roles_for(session, user_id)
    )


def create(
    session: Session,
    *,
    jurisdiction: str,
    on: date,
    effective_from: date,
    title: str,
    rationale: str,
    author: str,
    author_user_id: str | None = None,
    threshold_changes: dict[str, Any] | None = None,
    event_ids: list[int] | None = None,
) -> PackDraft:
    """Cut a draft from the pack in force, with the proposed edits applied.

    The whole proposed body is stored, not a patch. A patch has to be re-applied
    to be read, which means what a signatory reviews is a recipe and what goes
    live is the result of running it — and those are two different artefacts to
    argue about later. Storing the body makes the thing signed and the thing
    published the same bytes.

    **Authorship is recorded here, and it is required.** This table had no author
    field at all until migration 0049, so the separation §3.2 asks for — the
    person who proposes a rule change is not the person who attests to it — was
    a rule about a fact nothing in the database held. The transition log knew
    who created a draft and the row did not, which is why `publish` had to go
    read the log to fill in `pack_publications.drafted_by`.

    `author` is the display name and is required rather than defaulted, for the
    reason `sign` refuses an empty signatory: the value of the record is a name
    somebody can be asked about, and "drafted by ''" reads as a gate that was
    passed. The **account** comes from the ambient scope, not from a parameter,
    so that no caller can record one person's authorship against another
    person's session — the same rule `sign` applies to signatures.

    `author_user_id` is the one exception and it is narrow: a caller with nobody
    in scope must name the non-human actor doing the writing — `WATCH_SERVICE`
    for a draft the gazette reader assembled. It is refused where there *is* an
    account in scope, because that is a person naming somebody else.
    """
    acting = current_user_or_none()
    if acting is not None:
        if author_user_id is not None and author_user_id != acting:
            raise ValueError(
                "a draft's author is the account that wrote it. This session is "
                f"{acting} and the caller named {author_user_id}; recording one "
                "person's authorship against another's session is the thing the "
                "signature separation exists to make impossible."
            )
        created_by_user_id = acting
    elif author_user_id:
        created_by_user_id = author_user_id
    else:
        raise ValueError(
            "a draft needs an author. There is no account in this scope and the "
            "caller named none — writing a rule change with nothing recorded "
            "about who wrote it is the state migration 0049 exists to end. A "
            "service that drafts without a person names itself; see "
            f"{WATCH_SERVICE!r}."
        )
    if not author.strip():
        raise ValueError("a draft needs an author's name")

    row = packs_repo.active_rows(session, on).get(jurisdiction)
    if row is None:
        raise LookupError(f"no {jurisdiction} pack in force on {on.isoformat()}")

    body = copy.deepcopy(row.body)
    # A *label*, not an allocation. Q-04: this used to be the number the pack
    # was published under, chosen here — and the §14 rolling track keeps several
    # drafts open against one base at a time, so two drafts cut on the same
    # afternoon both carried `highest + 1` and both could publish it. The real
    # number is taken in `publish`, inside the transaction that writes the row,
    # under a lock, against a UNIQUE constraint. This is what a signatory sees
    # while the draft is still a draft, and `publish` corrects it.
    proposed_version = (highest_version(session, jurisdiction) or row.version) + 1

    body["version"] = proposed_version
    body["effective_from"] = effective_from.isoformat()
    body["effective_to"] = None
    # A draft inherits nothing about its own review status. Whoever signs it is
    # signing these thresholds, and the signature block is written at sign time
    # rather than copied forward from the version it was cut from.
    body["signed_by"] = ""
    body["signed_at"] = ""
    # And the claim itself, which this line used to leave alone. `create` deep-
    # copies the base body, so a draft cut from reviewed content inherited
    # `content_status: REVIEWED` — an unsigned draft describing itself as
    # reviewed. That was harmless only for as long as no reviewed pack existed
    # to cut from, which stopped being true the moment `publish` below learned
    # to produce one. Set rather than deleted: a body with no status reads as
    # ILLUSTRATIVE, and honest work awaiting a specialist is not that.
    body["content_status"] = attestation.PENDING_REVIEW

    for key, value in (threshold_changes or {}).items():
        if key not in body["thresholds"]:
            raise KeyError(
                f"{jurisdiction} v{row.version} declares no threshold {key!r}. A draft "
                "may change a threshold the pack has; adding one is a rule change and "
                "needs the rule written too."
            )
        body["thresholds"][key] = value

    draft = PackDraft(
        jurisdiction=jurisdiction,
        base_version=row.version,
        proposed_version=proposed_version,
        effective_from=effective_from,
        title=title,
        rationale=rationale,
        body=body,
        event_ids=list(event_ids or []),
        status=DRAFT,
        created_by=author.strip(),
        created_by_user_id=created_by_user_id,
    )
    session.add(draft)
    session.flush()
    lifecycle.record_creation(session, draft)
    return draft


def record_second_review(
    session: Session,
    draft_id: int,
    *,
    reviewer_name: str,
    reviewed_content_hash: str,
    note: str = "",
) -> PackDraft:
    """Record that somebody other than the author has read this content.

    The narrow escape hatch that lets an author sign their own draft. A firm
    with one specialist for a regime would otherwise be unable to change its
    rules at all, and a rule nobody can satisfy is a rule people route around —
    by having the specialist write it and a colleague type their name into the
    signature, which is worse than what this replaces because it looks correct.

    Three things are required and each closes a way of satisfying it hollowly.

    The reviewer is **the account in scope**, never a parameter. A second review
    you can name somebody else into is a second review the author performs.

    The reviewer is **not the author**, which is what the word independent
    means, and `pack_drafts_signature_is_independent` refuses the row as well —
    so a reviewer written straight into the table by a shell is refused by
    Postgres rather than by this function.

    The reviewer **holds `pack_signatory` for this draft's regime**. Competence
    to attest for one regime is not competence to attest for another; the same
    bar the signature is held to, because this stands in for the independence a
    second signature would have provided.

    Recorded against DRAFT and IN_REVIEW only. A review that could be added to
    content already signed would be a justification assembled after the act.

    **And `reviewed_content_hash` is the fourth, F1.** The three above are about
    the reviewer. This one is about what they read. It is a required argument
    rather than an optional one because a caller that cannot say which bytes it
    read has not said it read these — and every existing call site had to be
    changed to say so, which is the point rather than the cost.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise LookupError(f"no draft {draft_id}")
    if draft.status not in (DRAFT, IN_REVIEW):
        raise AlreadyResolved(draft_id, draft.status)

    reviewer = current_user_or_none()
    if not reviewer:
        raise ValueError(
            "a second review needs an account behind it. An unattributed read is "
            "not an independent one — there is nobody to ask what they read."
        )
    if reviewer == draft.created_by_user_id:
        raise NotIndependent(draft_id, draft.created_by or reviewer)
    if not _is_signatory_for(session, reviewer, draft.jurisdiction):
        raise NotQualifiedToReview(draft_id, reviewer, draft.jurisdiction)
    if not reviewer_name.strip():
        raise ValueError("a second review needs a name")

    # F1. And that what they read is what is on the row now.
    #
    # B1 set this column from `content_hash(draft.body)` a few lines below,
    # which binds the review to the bytes *this call* found. The reviewer read
    # the draft some minutes earlier, through `view`, and an author holding
    # `operator` can edit inside that gap: the review lands on the edited body,
    # its hash matches, `sign` is satisfied, and the row names somebody who
    # never saw the change. The auditor ran exactly that and got a 200.
    #
    # Compared, and with no "empty means unchanged" branch. An absent, blank or
    # malformed hash fails this comparison like any other wrong value, because
    # the claim being made is that these bytes were read — and a caller with
    # nothing to compare has not made it. The route makes the same field
    # required at the schema, so the two layers refuse for the same reason at
    # different distances from the caller.
    #
    # Through `_the_bytes_that_were_read` since the census, which is the same
    # comparison this line always made — moved into one function so that the
    # four routes that need it cannot drift apart, and so that a reader checking
    # "is this compared exactly?" has one place to check rather than four.
    current = _the_bytes_that_were_read(
        draft, reviewed_content_hash, moved=ReviewedBytesMoved
    )

    draft.second_reviewer_user_id = reviewer
    draft.second_reviewer = reviewer_name.strip()
    draft.second_reviewed_at = datetime.now(timezone.utc)
    # B1. *What* they read, beside who and when — the same canonical form the
    # signature hashes, so that `sign` can compare the two without knowing
    # anything about how either was produced.
    #
    # F1: `current`, which the check above has just proved equal to what the
    # reviewer said they read. Written from the row rather than from the request
    # so that the column is always a hash this process computed over this body —
    # a value copied out of a request body would be a hash of whatever the
    # caller felt like sending, which is the shape of every other field this
    # route deliberately does not have.
    draft.second_reviewed_content_hash = current
    if note:
        draft.signature_note = note
    session.flush()
    return draft


def invalidate_second_review(draft: PackDraft) -> bool:
    """Forget a second review, because the content it was of has changed.

    B1's other half, and it is not an alternative to the check in `sign` — the
    two answer different questions. `sign` refuses a signature that leans on a
    review of different bytes, which is what stops the attack. This clears the
    review outright, which is what stops a stale one sitting on the row looking
    valid to `view`, to the workbench, to `publish`'s record of who reviewed
    what, and to anybody reading the table directly.

    A function here rather than four assignments in `main.edit_draft`, because
    the rule belongs to the act and not to the route: a caller that changes a
    draft's body outside HTTP has invalidated the review just as thoroughly.

    Returns whether there was anything to forget, so a caller can say so.
    """
    if draft.second_reviewer_user_id is None and not draft.second_reviewed_at:
        return False
    draft.second_reviewer_user_id = None
    draft.second_reviewer = ""
    draft.second_reviewed_at = None
    draft.second_reviewed_content_hash = None
    return True


def sign(
    session: Session,
    draft_id: int,
    *,
    signatory: str,
    signed_content_hash: str,
    qualification_ref: str = "",
    note: str = "",
) -> PackDraft:
    """Record that a named person accepts this content as their own.

    An empty signatory is refused rather than stored as a blank. The value of
    this record is a name somebody can be asked about; "signed by ''" is worse
    than unsigned, because it looks like the gate was passed.

    The account behind the name is read from the ambient scope rather than
    passed beside it, so that no caller can record one person's name against
    another person's session. It is null only where there is genuinely nobody —
    the seed, the offline scripts — and `publish` reads a null signer as a draft
    nobody can be a second pair of eyes for.

    `qualification_ref` is the engagement that makes the name worth having, and
    it is recorded here rather than read at publication because a grant can be
    revoked or corrected afterwards. What a published pack should say is what
    was claimed when the attestation was made. It defaults to empty, which reads
    as a signature with no qualification recorded and produces `PENDING_REVIEW`
    — the right answer for every caller that has none to give.

    **`signed_content_hash` says which bytes were signed**, and it is required
    for the reason `record_second_review` requires its own: a caller that cannot
    say which bytes it read has not said it read *these*. F1 made that argument
    about the reviewer and stopped at the reviewer, and the auditor walked the
    identical sequence through this function — read, edit, sign — for a 200 and a
    signature over an author's edit. See `SignedBytesMoved`.

    A required keyword rather than an optional one, and every call site in the
    tree had to be changed to pass it. That is the point rather than the cost:
    an optional argument is one a caller omits, and a caller that omits this one
    is attesting to whatever happens to be on the row. The offline callers — the
    seed, the tests that drive this function directly — pass
    `content_hash(draft.body)` and thereby say nothing they did not already
    know, which is true and is not the objection it looks like: the value of the
    requirement is at the route, where the hash comes from a `view()` a person
    actually read, and the requirement can only be enforced there if it cannot
    be skipped here.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise LookupError(f"no draft {draft_id}")
    # Both states, and the reason is the transition table in `lifecycle`: DRAFT
    # and IN_REVIEW are the two places SIGNED is reachable from. This read
    # `!= DRAFT` until Stage 6, which meant the submit step Stage 5 added made a
    # draft unsignable — put it up for review and the signatory got "already
    # resolved". Nothing caught it, because signing and submitting each had
    # tests and nothing walked the pair.
    if draft.status not in (DRAFT, IN_REVIEW):
        raise AlreadyResolved(draft_id, draft.status)
    if not signatory.strip():
        raise ValueError("a signature needs a name")

    # The reading window, and it is checked before anything about who this
    # person is. A signatory whose screen is stale should be told that their
    # screen is stale, not sent away to argue about a grant that is correct —
    # and a draft that moved under them is a fact about the draft, which is true
    # whoever is asking.
    #
    # `signed` rather than `current`: what this proves is that the bytes the
    # caller says they read are the bytes on the row, so it is the same value
    # `draft.content_hash` is set from below. Computed once, from the row.
    signed = _the_bytes_that_were_read(
        draft, signed_content_hash, moved=SignedBytesMoved
    )

    # §3.2: the person who proposes a rule change is not the person who attests
    # to it. Refused here *and* by `pack_drafts_signature_is_independent`, which
    # is what makes the forbidden state unrepresentable rather than merely
    # unreachable through this function — the two are the same pattern the
    # append-only tables use, and for the same reason: this file can be edited.
    #
    # Unless a second reviewer got there first, in which case two people have
    # read the content and the signature is not one person agreeing with
    # themselves. The reviewer's qualification is re-read *now* rather than
    # trusted from the recorded row: a grant withdrawn between the review and
    # the signature is a reason the author may no longer sign their own work.
    signer = current_user_or_none()
    if signer is not None and signer == draft.created_by_user_id:
        reviewer = draft.second_reviewer_user_id
        if reviewer is None or reviewer in (signer, draft.created_by_user_id):
            raise SelfAuthoredSignature(draft_id, draft.created_by)
        if not _is_signatory_for(session, reviewer, draft.jurisdiction):
            raise NotQualifiedToReview(draft_id, reviewer, draft.jurisdiction)
        # B1. And that the review was of *this* content. The three checks above
        # ask who reviewed and whether they were entitled to; none of them asked
        # what they read, so an author could be reviewed, edit the body and sign
        # — with the reviewer column still populated and the 0049 constraint
        # still satisfied. The same comparison `publish` makes between the
        # signature and the bytes going live, one window earlier.
        #
        # A review recorded before this column existed has no hash, and is not
        # treated as covering anything: the whole claim is that somebody read
        # these bytes, and a row that cannot say which bytes cannot support it.
        reviewed_hash = draft.second_reviewed_content_hash
        if not reviewed_hash or reviewed_hash != content_hash(draft.body):
            raise ReviewedBytesChanged(draft_id, draft.second_reviewer)

    draft.signed_by = signatory.strip()
    draft.signed_qualification_ref = (qualification_ref or "").strip()
    draft.signed_by_user_id = current_user_or_none()
    draft.signed_at = datetime.now(timezone.utc)
    draft.signature_note = note
    # What was signed, as bytes. "They signed version 4" is a weaker claim than
    # "they signed these exact bytes" the moment somebody asks what changed
    # between the signature and what went live.
    #
    # `signed`, which the check at the top of this function has already proved
    # equal to what the signatory said they read. Written from the row rather
    # than from the request, for the reason `second_reviewed_content_hash` is:
    # this column must always be a hash this process computed over this body.
    draft.content_hash = signed

    # A draft may be signed straight from `draft` as well as from `in_review`: a
    # signatory authoring their own content does not have to hand it to
    # themselves first. The table permits both and the log records which.
    if draft.status == DRAFT:
        lifecycle.move(
            session, draft, IN_REVIEW, note="signed without a separate review step"
        )
    lifecycle.move(session, draft, SIGNED, note=note)
    session.flush()
    return draft


def reject(session: Session, draft_id: int, *, rejected_by: str, note: str = "") -> PackDraft:
    """Decline a draft. Recorded in its own fields, never in the signature.

    Rejection used to write the declining person into `signed_by`, which left a
    row saying content was signed by somebody who had refused to sign it.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise LookupError(f"no draft {draft_id}")
    # As with `sign`: REJECTED is reachable from both, and a signatory who has
    # been handed something and does not want it is the *ordinary* way a draft
    # gets rejected.
    if draft.status not in (DRAFT, IN_REVIEW):
        raise AlreadyResolved(draft_id, draft.status)
    lifecycle.move(session, draft, REJECTED, note=note)
    draft.signature_note = note
    draft.rejected_by = rejected_by
    draft.rejected_by_user_id = current_user_or_none()
    draft.rejected_at = datetime.now(timezone.utc)
    session.flush()
    return draft


class NotAPlatformPublisher(Exception):
    """Somebody without a platform grant tried to publish or approve. FP3-27.

    Distinct from the route's own RBAC refusal, and both are kept. The route
    checks the *tenant* role; this checks the platform grant, and the whole
    finding is that the first one was standing in for the second.
    """

    def __init__(self, user_id: str | None) -> None:
        super().__init__(
            f"{user_id or 'this session'} does not hold platform publication. "
            "Publishing writes global rule content, so it is not something a "
            "tenant role can confer — see `platform_publishers`."
        )


class NeedsASecondApprover(Exception):
    """Publication has fewer than two approvals from two different people."""

    def __init__(self, draft_id: int, have: int) -> None:
        self.draft_id, self.have = draft_id, have
        super().__init__(
            f"draft {draft_id} has {have} publication approval(s) and needs "
            f"{REQUIRED_APPROVALS}, from {REQUIRED_APPROVALS} different platform "
            "publishers, neither of whom signed it."
        )


#: How many platform publishers must approve before content goes live.
#:
#: Not configurable, deliberately. A number in a settings table is a number
#: somebody sets to one during an incident, and the entire value of dual control
#: is that it cannot be relaxed by whoever is in a hurry.
REQUIRED_APPROVALS = 2


def is_platform_publisher(session: Session, user_id: str | None) -> bool:
    """Whether this account holds a live platform publication grant."""
    if not user_id:
        return False
    row = session.get(PlatformPublisher, user_id)
    return row is not None and row.revoked_at is None


def assert_platform_publisher(session: Session, user_id: str | None) -> None:
    if not is_platform_publisher(session, user_id):
        raise NotAPlatformPublisher(user_id)


def approve_publication(
    session: Session,
    draft_id: int,
    *,
    approved_content_hash: str,
    note: str = "",
) -> PublicationApproval:
    """Record that one platform publisher agrees this draft should go live.

    Refuses the signer, for the reason `publish` refuses them: an approval from
    the person who attested to the content is that person agreeing with
    themselves.

    The content hash is recorded alongside, so an approval of bytes that have
    since moved can be told from an approval of what is actually being
    published — the same argument F4 makes about the signature.

    **`approved_content_hash` is which bytes the approver read**, and until the
    census this function did not ask. It hashed the body it found when the POST
    arrived — B1's exact shape — and the route above it took no request body at
    all, so an approver could not have said what they read even had they tried.
    The window spans the signature and the auditor's edit fits inside it: a
    publisher reads the draft while it is `IN_REVIEW`, its author edits it, a
    signatory signs the edited body, and this records the publisher's account
    against content they never saw. See `ApprovedBytesMoved`.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise LookupError(f"no draft {draft_id}")
    if draft.status != SIGNED:
        raise NotSigned(draft_id, draft.status)

    approver = current_user_or_none()
    assert_platform_publisher(session, approver)

    if draft.signed_by_user_id is None or draft.signed_by_user_id == approver:
        raise SelfReview(draft_id, draft.signed_by)

    # What they read, proved equal to what is on the row. `approved` is then
    # what the column is written from, so the record is always a hash this
    # process computed over this body rather than a value from a request.
    approved = _the_bytes_that_were_read(
        draft, approved_content_hash, moved=ApprovedBytesMoved
    )

    row = PublicationApproval(
        draft_id=draft_id,
        approved_by=approver or "",
        content_hash=approved,
        note=note,
    )
    session.add(row)
    session.flush()
    return row


def approvals_for(session: Session, draft_id: int) -> list[PublicationApproval]:
    """Every approval recorded against this draft, oldest first."""
    return list(
        session.scalars(
            select(PublicationApproval)
            .where(PublicationApproval.draft_id == draft_id)
            .order_by(PublicationApproval.id)
        )
    )


def publish(session: Session, draft_id: int, *, published_content_hash: str) -> PackRow:
    """Turn a signed draft into a pack version. Refuses anything else.

    This is the only function in the codebase that writes a row to `packs`
    outside the seed, and the two guards below are the only thing standing
    between the watch service and live rule content.

    The second guard is the one an auditor asks about. Publication is a second
    pair of eyes on signed content, so the person publishing must not be the
    person who signed — otherwise "signed and reviewed" describes one person
    agreeing with themselves. Compared by account, not by the name printed on
    the pack, because a name is a string anybody can retype.

    A draft signed by nobody at all cannot be published by anybody: there is no
    second pair of eyes to be, and treating a null signer as "not me" would let
    an unattributed signature through the gate that exists to stop exactly that.

    **`published_content_hash` is which bytes the publisher read.** Pressing
    publish counts as one of the two approvals — that is this function's own
    argument a few lines below — so the publisher is an attester, and the census
    found them in the same window `approve_publication` was in. Required for the
    reason every other binding in this module is required: a caller that cannot
    say what it read has not said it read this.
    """
    draft = session.get(PackDraft, draft_id)
    if draft is None:
        raise LookupError(f"no draft {draft_id}")
    if draft.status != SIGNED:
        raise NotSigned(draft_id, draft.status)

    publisher = current_user_or_none()
    if draft.signed_by_user_id is None or draft.signed_by_user_id == publisher:
        raise SelfReview(draft_id, draft.signed_by)

    # FP3-27. The route's RBAC checks `quolin_operator`, which is granted
    # through `user_roles` — a **tenant-scoped** table. `packs` is global, so a
    # capability whose target is every customer was authorised by a row
    # belonging to one, and compromise of a single firm's role set reached every
    # firm's regulatory content.
    #
    # Both checks are kept. The route's is about which role may reach the
    # endpoint; this is about whether the account may perform the act.
    assert_platform_publisher(session, publisher)

    # And two of them, from two different people, neither of whom signed.
    #
    # `SelfReview` above is one pair of eyes on the *content*. This is the
    # second pair on the *publication* — the act that puts rule content in front
    # of every customer on the platform. One compromised account cannot do it,
    # and neither can one compromised account that also holds the signature.
    #
    # The publisher counts as one of the two: pressing publish is an approval,
    # and requiring them to record a separate one first would be ceremony rather
    # than control. So a draft needs one other approver, and `uq_one_approval_each`
    # stops the same person being both.
    approvals = {a.approved_by for a in approvals_for(session, draft_id)}
    approvals.add(publisher or "")
    approvals.discard("")
    if len(approvals) < REQUIRED_APPROVALS:
        raise NeedsASecondApprover(draft_id, len(approvals))

    # F4. The status says a signature happened; only the hash says what it was
    # over. Checked before the version is allocated and before anything is
    # written, so a refusal costs nothing and burns no version number.
    signed_hash = draft.content_hash or ""
    if signed_hash and content_hash(draft.body) != signed_hash:
        raise SignedBytesChanged(draft_id, draft.signed_by)

    # And that the publisher read what they are putting in force.
    #
    # **After `SignedBytesChanged`, on purpose.** The two refusals can both be
    # true at once and they are not equally informative. If a draft's body moved
    # out of band after the signature and the publisher read the *moved* body,
    # their hash matches the row and only `SignedBytesChanged` fires — which is
    # right, because the finding is that the content was altered after somebody
    # attested to it. If they read the signed body instead, both are true, and
    # `SignedBytesChanged` is still the one to answer with: "this draft was
    # edited after it was signed" is a larger fact than "your screen is stale",
    # and a publisher told only the latter would refresh and publish it.
    #
    # `NeedsASecondApprover` also answers before this one, which means a
    # publisher who is both short an approver and reading a stale screen hears
    # about the approver first and makes two trips. Left that way rather than
    # hoisted: the quorum check is about whether this act may happen at all, the
    # publisher cannot complete the publication either way, and moving a check
    # that has been in this order since FP3-27 to improve a message in a
    # double-fault case is a change to make on its own or not at all.
    _the_bytes_that_were_read(
        draft, published_content_hash, moved=ApprovedBytesMoved
    )

    draft.published_by_user_id = publisher

    # Allocate the version *here*, in the transaction that writes the row.
    #
    # The advisory lock serialises two publications of the same regime, so the
    # maximum below cannot be read by both before either writes. Transaction-
    # scoped, so it is released on commit or rollback with nothing to clean up.
    # Migration 0031's UNIQUE constraint is the second lock: if this reasoning
    # is ever wrong, the second INSERT is refused by Postgres rather than
    # quietly creating two packs with one name.
    session.execute(
        text("SELECT pg_advisory_xact_lock(:namespace, hashtext(:jurisdiction))"),
        {"namespace": _VERSION_LOCK_NAMESPACE, "jurisdiction": draft.jurisdiction},
    )
    version = (highest_version(session, draft.jurisdiction) or 0) + 1
    # The draft's provisional label becomes the real one, so a draft published as
    # v7 does not go on describing itself as the v5 it was cut as. `pack_drafts`
    # is working state, not evidence — the transition log is what is append-only.
    draft.proposed_version = version

    body = copy.deepcopy(draft.body)
    body["version"] = version
    body["signed_by"] = draft.signed_by
    body["signed_at"] = draft.signed_at.isoformat() if draft.signed_at else ""
    # Who wrote it, beside who signed it, in the bytes that travel with the
    # content — so that the artefact a compliance officer reads answers "who
    # authored this rule change" without a reconciliation against a table in
    # our database that they cannot query. The second reviewer is written only
    # where there was one, because a blank line saying "second reviewer:" on
    # every document would train people to ignore it on the one that has it.
    body["drafted_by"] = draft.created_by
    if draft.second_reviewer_user_id:
        body["second_reviewer"] = draft.second_reviewer
    # The line whose absence meant this workflow could not produce reviewed
    # content. `Pack.content_status` is GENERATED ALWAYS from
    # `body ->> 'content_status'`, so the column can only ever say what the body
    # says — and the body said whatever the draft inherited, which was never
    # REVIEWED. The generated column and migration 0025's CHECK are both right
    # and both stay; what was wrong is that nothing made the body true.
    #
    # Not every signature qualifies. `pack_signatory` is a permission; competence
    # to attest for a regime is a fact about an engagement, recorded on the grant
    # and copied onto the draft at signature time. A placeholder there produces
    # PENDING_REVIEW, which is what every signatory in this repository would
    # produce today — and stamping REVIEWED on the strength of the role alone
    # would let anybody holding it mint production-grade rule content with
    # nobody qualified behind it. See `app/attestation.py`.
    body["content_status"] = attestation.status_for(
        draft.signed_by, draft.signed_qualification_ref
    )

    # A third guard belongs here — that the content would actually evaluate —
    # and deliberately is not here. `test_watch.py` forbids anything under
    # `app/watch` from importing the engine, and that guard is invariant 6's
    # structural half: the service that drafts rule content must not be able to
    # reach the one that decides with it. A narrower rule ("may import the
    # validator but not the evaluator") is a rule somebody widens.
    #
    # So validation happens in the layer that already knows about both halves:
    # `main.publish_draft` checks the body before calling this, and the seed
    # checks every file it loads. `test_watch.py` asserts that the endpoint
    # refuses an invalid draft, so the check is not merely remembered.
    row = PackRow(
        jurisdiction=draft.jurisdiction,
        version=version,
        effective_from=draft.effective_from,
        effective_to=None,
        body=body,
        signed_by=draft.signed_by,
        signed_at=body["signed_at"],
        # The bytes, recorded beside the row, so "what is this pack" is
        # answerable without evaluating it. Computed over the body as published,
        # which is the body as signed plus the signature block and the version
        # allocated a few lines above.
        content_hash=content_hash(body),
    )
    session.add(row)
    session.flush()

    # The record every *other* firm can read. Q-12: `packs` is global and
    # `pack_draft_transitions` is tenant-scoped, so a customer inheriting this
    # content could not see who wrote it, who signed it, or that anybody had.
    # This carries what they are entitled to know and nothing about the drafting
    # workflow, which remains theirs. Written here because this is the only
    # function that creates a pack row.
    session.add(
        PackPublication(
            pack_id=row.id,
            jurisdiction=draft.jurisdiction,
            version=version,
            effective_from=draft.effective_from,
            origin_tenant=draft.tenant_id,
            # From the draft row, not from the transition log. This read
            # `history(draft.id)[0]["by"]` until migration 0049 — the creating
            # transition's actor, which is an account id, written into a column
            # every reader takes for a name. A firm inheriting these rules saw
            # `usr_3FT6FW8AcS5hIT-m` as the author, which answers "who wrote
            # this" only for somebody who can query our database.
            drafted_by=draft.created_by,
            drafted_by_user_id=draft.created_by_user_id,
            # And the independent read, where the signature needed one. Null
            # where the signer was not the author: there was nothing for a third
            # person to make independent, and a column populated on every row
            # would make the ones that matter invisible.
            second_reviewer_user_id=draft.second_reviewer_user_id,
            drafted_at=draft.created_at,
            signed_by=draft.signed_by,
            signed_by_user_id=draft.signed_by_user_id,
            signed_at=draft.signed_at,
            published_by_user_id=publisher,
            published_at=datetime.now(timezone.utc),
            content_hash=row.content_hash,
            # F4. The two hashes describe different bytes and both belong here:
            # `content_hash` is what went live, this is what was attested to.
            # Recorded in an append-only table so the claim outlives the mutable
            # draft row it was made on.
            signed_content_hash=signed_hash or None,
        )
    )
    session.flush()

    lifecycle.move(
        session,
        draft,
        PUBLISHED,
        note=(
            f"{draft.jurisdiction} v{version} scheduled for "
            f"{draft.effective_from.isoformat()}"
        ),
    )
    draft.published_pack_id = row.id
    session.flush()
    return row


def view(draft: PackDraft, *, today: date | None = None) -> dict[str, Any]:
    """A draft as a screen needs it, including what it would change.

    The delta is computed against the version the draft was cut from rather than
    against whatever is in force now, and both numbers are shown, so a draft
    raised against a base that has since been superseded is visible as such
    instead of appearing to apply cleanly.

    **All three identities, name and account.** A compliance officer asked who
    authored a rule change has to be able to answer it from this, without
    reconciling a signature against a transition log. The accounts travel beside
    the names because names are strings anybody can retype and the separation
    this screen exists to evidence is a separation of *accounts* — showing two
    names and one account would read as a review and be one person.
    """
    today = today or business_time.platform_today()
    days = (draft.effective_from - today).days
    return {
        "id": draft.id,
        "jurisdiction": draft.jurisdiction,
        "base_version": draft.base_version,
        "proposed_version": draft.proposed_version,
        "effective_from": draft.effective_from.isoformat(),
        "days_until_effective": days,
        "title": draft.title,
        "rationale": draft.rationale,
        "event_ids": list(draft.event_ids or []),
        "status": draft.status,
        "created_at": draft.created_at.isoformat() if draft.created_at else None,
        "created_by": draft.created_by,
        "created_by_user_id": draft.created_by_user_id,
        "signed_by": draft.signed_by,
        "signed_by_user_id": draft.signed_by_user_id,
        "signed_at": draft.signed_at.isoformat() if draft.signed_at else None,
        "second_reviewer": draft.second_reviewer,
        "second_reviewer_user_id": draft.second_reviewer_user_id,
        "second_reviewed_at": (
            draft.second_reviewed_at.isoformat() if draft.second_reviewed_at else None
        ),
        # F1. The hash of the body **as this view renders it**, so that a client
        # can bind its next act to the content it actually displayed.
        #
        # Without it a reviewer's approval could only ever be about the row at
        # POST time, which is not the row they read: the author can edit inside
        # the reading window, and `record_second_review` would hash the edited
        # body and match itself. This is the value it sends back.
        #
        # Named `current_content_hash` rather than `content_hash`, and the extra
        # word is doing work. `PackDraft.content_hash` is the *signed* bytes, and
        # the history screen already shows it under "what was signed". Two
        # different hashes of two different bodies called the same thing on one
        # screen is how a client comes to send the wrong one.
        "current_content_hash": content_hash(draft.body),
        # B1. Whether the review still describes what is on the row, rather than
        # only that one happened. An edit clears the review outright, so this is
        # `False` for a stale row only where something wrote the body without
        # going through `edit_draft` — which is the case the hash exists for,
        # and a screen showing "reviewed by X" beside it would be wrong.
        "second_review_covers_this_body": bool(
            draft.second_reviewed_content_hash
            and draft.second_reviewed_content_hash == content_hash(draft.body)
        ),
        # The one derived field, and it is the sentence a reader actually wants:
        # a signature by the author is only acceptable because of the review
        # beside it, and that is not obvious from three ids.
        "signed_by_its_author": bool(
            draft.signed_by_user_id
            and draft.signed_by_user_id == draft.created_by_user_id
        ),
        "signature_note": draft.signature_note,
        "published_pack_id": draft.published_pack_id,
        "is_live": draft.status == PUBLISHED,
    }


def delta(session: Session, draft: PackDraft) -> dict[str, Any]:
    """Threshold and rule differences between the draft and its base version."""
    base = session.scalars(
        select(PackRow)
        .where(PackRow.jurisdiction == draft.jurisdiction)
        .where(PackRow.version == draft.base_version)
    ).first()
    if base is None:
        return {"unavailable": f"no {draft.jurisdiction} v{draft.base_version} to compare against"}
    return packs_repo.diff(base.body, draft.body)
