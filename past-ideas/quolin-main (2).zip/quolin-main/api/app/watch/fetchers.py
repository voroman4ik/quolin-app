"""Reaching a publisher, and failing in a way somebody can act on.

Replay mode reads a fixture and is the demo default. This module is the other
half: what `WATCH_MODE=live` actually does. It fetches a source's feed, parses
it into the same shape the fixture holds, and — the part that matters for §S6 —
turns every way that can go wrong into a named failure the SLA machinery can
count.

**A source is only fetchable if its pack content says how.** A landing page URL
is what a human opens; it is not a feed. So a source that wants live polling
declares one:

    {"id": "au-asic-media", ..., "feed": {"kind": "atom", "url": "https://…"}}

A source with no `feed` block has no adapter, and live mode says so by name
rather than quietly falling back to the fixture. That fallback is the worst
available behaviour — the screen would say `live`, the data would be invented,
and nobody downstream could tell.

**Two formats, because those are the two regulators publish.** Atom and RSS 2.0
cover every source in the four packs that offers a machine-readable feed at all.
A third format should arrive with a source that needs it, not before.

**Parsing is done with the standard library's ElementTree.** It resolves no
external entities and rejects undefined ones, which is what makes a hostile feed
a parse error rather than a file read. `lxml` would be faster and would need its
own decision about entity resolution.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any, Callable
from xml.etree import ElementTree

import httpx

#: How long a publisher has. A regulator's website being slow is a fact about
#: their afternoon, not something to hold a worker open for — and a fetch that
#: times out is recorded as a failed check, which is exactly what the SLA wants
#: to know about.
TIMEOUT_SECONDS = 20.0

#: Sent so an operator reading their access log can tell who we are and stop us
#: without guessing. A watcher that will not identify itself is one a publisher
#: is right to block.
USER_AGENT = "Quolin regulatory watch (+https://quolin.com/watch)"

ATOM = "atom"
RSS = "rss"
#: A page, read and digested. Not a feed — see `digest` below for what it can
#: and cannot tell you.
HTML = "html"
KINDS = (ATOM, RSS, HTML)

#: A source that cannot be polled at all. Declared in pack content, because
#: whether a publication has a readable URL is a fact about the regime and not
#: about our deployment.
MANUAL = "MANUAL"
AUTOMATIC = "AUTOMATIC"

_ATOM_NS = "{http://www.w3.org/2005/Atom}"


@dataclass(frozen=True)
class Fetched:
    """What one read of a source produced.

    A pair rather than a bare list, because a page adapter has two things to
    report: what changed, and the digest to compare against next time. The
    first version smuggled the digest through a module-level dict, which is
    shared mutable state across every source in a sweep — and the sweep holds
    one client and walks sources in a loop, so it would have been wrong the
    first time two sources were read.
    """

    items: list[dict[str, Any]]
    #: The digest of the page just read, for adapters that work that way.
    #: `None` from a feed adapter, which has nothing to compare.
    content_hash: str | None = None


class FetchError(RuntimeError):
    """A source could not be read this time.

    Carries the source id and a message written for the person who gets paged,
    because that is who reads it: "au-asic-media: HTTP 503 from asic.gov.au" is
    actionable and `HTTPStatusError` is not.
    """

    def __init__(self, source_id: str, reason: str):
        self.source_id = source_id
        self.reason = reason
        super().__init__(f"{source_id}: {reason}")


class NoAdapter(FetchError):
    """The source declares no feed, so nothing could have been fetched.

    A distinct type because it is a *content* problem rather than an outage: the
    publisher is fine, our pack does not say how to read them. Counting it as an
    unreachable source would page somebody about a network that is working.
    """

    def __init__(self, source_id: str):
        super().__init__(
            source_id,
            "no feed declared in pack content. Add a `feed` block naming the "
            f"format and URL ({' or '.join(KINDS)}) to poll this source live.",
        )


def feed_of(spec: dict[str, Any]) -> dict[str, str] | None:
    """How to read this source, if it can be read at all.

    A declared `feed` block wins: a publisher's own feed says *what* was
    published, which is strictly better than noticing that a page moved.

    Failing that, a source with a URL is read as a page — §S13's fix for the
    finding that eight of nine shipped sources had no feed block and so could
    never be checked live. That is a weaker signal and it is not nothing: the
    triage tiers already work on "changed versus not", which is exactly what a
    digest gives them.

    A source the pack marks `MANUAL` returns None however good its URL looks.
    Some publications need a login, or the URL is a search form with no stable
    result, and inventing a poll for one of those would produce a source that
    reports itself checked every hour and notices nothing.
    """
    if str(spec.get("polling_status", "")).strip().upper() == MANUAL:
        return None

    feed = spec.get("feed") or {}
    kind = str(feed.get("kind", "")).strip().lower()
    url = str(feed.get("url", "")).strip()
    if kind in KINDS and url:
        return {"kind": kind, "url": url}

    page = str(spec.get("url", "")).strip()
    if page.startswith(("http://", "https://")):
        return {"kind": HTML, "url": page}
    return None


def _text(node: Any, *paths: str) -> str:
    for path in paths:
        found = node.find(path)
        if found is not None and (found.text or "").strip():
            return str(found.text).strip()
        if found is not None and found.get("href"):
            return str(found.get("href")).strip()
    return ""


def _published(raw: str, fallback: date) -> date:
    """A publication date from whatever the feed spells it as.

    Falls back to the day we read it rather than raising. A feed entry with an
    unparseable date is still a publication somebody should see; dropping it
    would make our parser's strictness into a missed rule change.
    """
    raw = (raw or "").strip()
    if not raw:
        return fallback
    # ISO first (Atom), then RFC 822 (RSS), then a bare date. Tried in order
    # rather than sniffed, because a feed that mislabels its own format is
    # common and a wrong guess loses the entry.
    readers: tuple[Callable[[str], date], ...] = (
        lambda v: datetime.fromisoformat(v.replace("Z", "+00:00")).date(),
        lambda v: datetime.strptime(v[:25], "%a, %d %b %Y %H:%M:%S").date(),
        lambda v: date.fromisoformat(v[:10]),
    )
    for read in readers:
        try:
            return read(raw)
        except (ValueError, TypeError):
            continue
    return fallback


#: Removed before the text is taken. Everything here either carries no words a
#: reader would see, or changes on its own between two identical page loads.
_STRIPPED = (
    re.compile(r"<script\b.*?</script>", re.S | re.I),
    re.compile(r"<style\b.*?</style>", re.S | re.I),
    re.compile(r"<!--.*?-->", re.S),
    re.compile(r"<[^>]+>", re.S),
)

#: Removed from the text that remains: a wall clock and a rendered timestamp
#: move without anybody publishing anything.
_VOLATILE_TEXT = (
    re.compile(r"\b\d{1,2}:\d{2}(?::\d{2})?\b"),
    re.compile(r"\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}[^\s]*"),
)


def digest(body: str) -> str:
    """A stable digest of what a page *says*, ignoring how it says it.

    Markup is discarded and the visible text is hashed. That is deliberate and
    it is the second design: the first digested the markup with a list of
    volatile patterns cut out of it, and a `csrf-token` meta tag defeated it
    immediately — the patterns were chasing attribute shapes, and the next
    framework spells them differently.

    Words are what a publisher changes when they publish. A rotating token, a
    reflowed template and a rebuilt asset hash all move the markup and none of
    them move the text.

    **This detects change, not content.** It cannot say what was published, only
    that something differs from last time — which is the signal the triage tiers
    already take, and is why a page source raises a queue item for a human
    rather than proposing a pack edit.

    It will also miss a change: a publisher who edits and reverts between two
    polls looks unchanged, and one whose page carries a rotating quotation looks
    changed forever. The first is why cadence matters; the second is a source
    that should be declared MANUAL. Neither is a reason to prefer no polling at
    all, which is what these sources had.
    """
    text = body
    for pattern in _STRIPPED:
        text = pattern.sub(" ", text)
    for pattern in _VOLATILE_TEXT:
        text = pattern.sub(" ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()


def parse(body: str, *, kind: str, source_id: str, today: date) -> list[dict[str, Any]]:
    """Feed XML into the shape `fixtures/watch_events.json` holds.

    One shape for both modes on purpose: everything downstream — triage,
    idempotency, the queue — then cannot tell which mode produced an item, and
    so cannot behave differently in the one that is harder to test.
    """
    try:
        root = ElementTree.fromstring(body)
    except ElementTree.ParseError as exc:
        raise FetchError(source_id, f"feed did not parse as XML: {exc}") from exc

    items: list[dict[str, Any]] = []
    if kind == ATOM:
        entries = root.findall(f".//{_ATOM_NS}entry")
        for entry in entries:
            title = _text(entry, f"{_ATOM_NS}title")
            if not title:
                continue
            items.append(
                {
                    "source_id": source_id,
                    "title": title,
                    "summary": _text(entry, f"{_ATOM_NS}summary", f"{_ATOM_NS}content"),
                    "url": _text(entry, f"{_ATOM_NS}link"),
                    "published_at": _published(
                        _text(entry, f"{_ATOM_NS}published", f"{_ATOM_NS}updated"),
                        today,
                    ).isoformat(),
                }
            )
    else:
        for entry in root.findall(".//item"):
            title = _text(entry, "title")
            if not title:
                continue
            items.append(
                {
                    "source_id": source_id,
                    "title": title,
                    "summary": _text(entry, "description"),
                    "url": _text(entry, "link", "guid"),
                    "published_at": _published(_text(entry, "pubDate"), today).isoformat(),
                }
            )
    return items


def fetch(
    spec: dict[str, Any], *, today: date, client: httpx.Client | None = None
) -> Fetched:
    """Read one source live. Raises `FetchError` rather than returning nothing.

    An empty list and a failure are different facts and must not arrive as the
    same value: a regulator who published nothing this week is a healthy source,
    and one whose site is down is an SLA breach. Returning `[]` for both would
    make the second invisible for exactly as long as it lasted.
    """
    source_id = spec["id"]
    feed = feed_of(spec)
    if feed is None:
        raise NoAdapter(source_id)

    owns_client = client is None
    client = client or httpx.Client(
        timeout=TIMEOUT_SECONDS,
        follow_redirects=True,
        headers={"User-Agent": USER_AGENT},
    )
    try:
        response = client.get(feed["url"])
        if response.status_code >= 400:
            host = httpx.URL(feed["url"]).host
            raise FetchError(source_id, f"HTTP {response.status_code} from {host}")

        if feed["kind"] == HTML:
            current = digest(response.text)
            return Fetched(
                items=page_items(
                    source_id=source_id,
                    url=feed["url"],
                    today=today,
                    seen_hash=str(spec.get("content_hash") or ""),
                    current=current,
                ),
                content_hash=current,
            )
        return Fetched(
            items=parse(
                response.text, kind=feed["kind"], source_id=source_id, today=today
            )
        )
    except httpx.TimeoutException as exc:
        raise FetchError(
            source_id, f"no answer within {TIMEOUT_SECONDS:.0f}s"
        ) from exc
    except httpx.HTTPError as exc:
        raise FetchError(source_id, f"could not be reached: {exc}") from exc
    finally:
        if owns_client:
            client.close()


def page_items(
    *,
    source_id: str,
    url: str,
    today: date,
    seen_hash: str,
    current: str,
) -> list[dict[str, Any]]:
    """One item if the page moved since last time, none if it did not.

    The shape matches what a feed adapter returns, so everything downstream —
    triage, the queue, the SLA counters — treats a page source exactly like a
    feed source. What differs is the title, which says plainly that this is a
    page that changed rather than a publication with a headline. A queue item
    claiming to be a publication it cannot name would be worse than one that
    admits what it is.

    The first ever poll records the digest and raises nothing. There is no
    previous state to compare against, and reporting "changed" on first sight
    would give every source a spurious item the day it was added.
    """
    if not seen_hash:
        return []
    if current == seen_hash:
        return []
    return [
        {
            "source_id": source_id,
            "title": f"{source_id}: the page changed since the last check",
            "url": url,
            "published_at": today,
            "summary": (
                "This source has no machine-readable feed, so it is watched by "
                "comparing a digest of the page. Something on it is different "
                "from the last check. Open it to see what."
            ),
        }
    ]

