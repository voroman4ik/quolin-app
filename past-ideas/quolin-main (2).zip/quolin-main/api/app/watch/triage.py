"""Sorting a queue for a human, and nothing more.

Triage answers one question: of the things published since we last looked,
which should a compliance officer read first? It does not answer whether the
rules should change, and it must never be mistaken for answering it. Everything
in this module exists to keep that line visible:

  * The tiers are named after *what matched*, not after how urgent something is.
    `TOUCHES_RULE_CONTENT` is a statement about a string overlap between a
    publication and a pack. It is not a statement that the pack is now wrong.
  * Every classification carries the terms that produced it. A tier with no
    `matched` list is a score, and a score is a judgement wearing a number's
    clothes — an officer cannot argue with 0.87, but they can immediately say
    "that matched 'leverage' because the release is about a different product".
  * The vocabulary comes from pack content (`watch.vocabulary`). No term, no
    regulator and no jurisdiction name appears in this file.

A false positive here costs somebody thirty seconds. A false negative costs
them a missed rule change. The tiers are ordered accordingly: anything that
matched pack content goes to the top, and everything that matched nothing is
still shown, because "we found no match" is a fact about our vocabulary rather
than a fact about the publication.
"""

from __future__ import annotations

import re
from typing import Any

#: Matched a threshold name, rule id or reason code the pack declares — via a
#: term the pack itself mapped to that content. Read first.
TOUCHES_RULE_CONTENT = "TOUCHES_RULE_CONTENT"
#: Published by a source this deployment watches for a regime it holds a pack
#: for, but nothing in it matched the pack's vocabulary. Still shown: the
#: vocabulary is a human artefact and its gaps are not the publisher's problem.
IN_SCOPE = "IN_SCOPE"
#: From a watched source, for a regime this deployment holds no active pack
#: for. Kept rather than dropped, because a coverage gap is exactly the
#: condition under which you most want to see what you are missing.
UNMATCHED = "UNMATCHED"

#: Reading order. Index in this tuple is the sort key; see `sort_key`.
TIERS = (TOUCHES_RULE_CONTENT, IN_SCOPE, UNMATCHED)

TIER_LABELS = {
    TOUCHES_RULE_CONTENT: "Touches rule content",
    IN_SCOPE: "In scope",
    UNMATCHED: "No pack for this regime",
}

TIER_EXPLANATIONS = {
    TOUCHES_RULE_CONTENT: (
        "Words in this publication are mapped by the rule pack to thresholds or "
        "rules it declares. That is a text match, not a finding — read it and decide."
    ),
    IN_SCOPE: (
        "From a watched source for a regime with an active pack, but nothing in it "
        "matched the pack's vocabulary. The vocabulary is written by hand and can "
        "be incomplete."
    ),
    UNMATCHED: (
        "From a watched source for a regime this deployment holds no active pack "
        "for. No rule content exists here to compare it against."
    ),
}


def _term_pattern(term: str) -> re.Pattern[str]:
    """A whole-token match for a term, tolerant of runs of whitespace.

    Substring matching would make 'leverage' fire on 'deleveraged' and, worse,
    make a two-character term match half the corpus. Bounding on word edges
    keeps the `matched` list defensible when somebody asks why an item is at
    the top of their queue.
    """
    parts = [re.escape(p) for p in term.split()]
    return re.compile(r"\b" + r"\s+".join(parts) + r"\b", re.IGNORECASE)


def matches(text: str, vocabulary: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Every vocabulary term found in `text`, with the pack content it touches.

    Returns one entry per matching term, in the order the pack declared them,
    so two runs over the same text produce byte-identical output. Determinism
    matters here for the same reason it matters in the evaluator: a queue that
    reorders itself between refreshes cannot be worked through.
    """
    found: list[dict[str, Any]] = []
    for entry in vocabulary:
        term = entry.get("term", "")
        if not term:
            continue
        if _term_pattern(term).search(text):
            found.append(
                {
                    "term": term,
                    "touches": list(entry.get("touches", [])),
                }
            )
    return found


def classify(
    *,
    title: str,
    summary: str = "",
    vocabulary: list[dict[str, Any]] | None,
    has_active_pack: bool,
) -> dict[str, Any]:
    """Which tier this publication lands in, and exactly what put it there.

    `vocabulary` is None when the regime has no pack, or a pack that declares no
    watch block. Both are the same situation from here: there is nothing to
    compare against, and saying so is more useful than inventing a comparison.
    """
    text = f"{title}\n{summary}"
    if not has_active_pack:
        return {"tier": UNMATCHED, "matched": []}

    found = matches(text, vocabulary or [])
    if found:
        return {"tier": TOUCHES_RULE_CONTENT, "matched": found}
    return {"tier": IN_SCOPE, "matched": []}


def sort_key(tier: str) -> int:
    """Reading order for a queue. Unknown tiers sort last rather than crash."""
    return TIERS.index(tier) if tier in TIERS else len(TIERS)


def touched_refs(matched: list[dict[str, Any]]) -> list[str]:
    """The distinct pack elements a set of matches points at, sorted.

    Used by the draft screen to say which thresholds and rules an officer is
    about to look at, and by nothing that evaluates anything.
    """
    refs: set[str] = set()
    for entry in matched or []:
        refs.update(entry.get("touches", []))
    return sorted(refs)
