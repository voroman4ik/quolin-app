"""One answer to one question: is what this system enforces still current?

A rule engine's most dangerous failure is not a wrong answer. It is a confident
right-answer-from-last-year — the determination reads exactly as it did when the
content was correct, and nothing on the screen distinguishes the two. Every
number this module produces exists to make that distinction visible without
anybody having to go looking for it.

The three things it puts together are deliberately different in kind:

  freshness   Has anyone looked at the sources lately? An operational fact about
              this deployment, derived from timestamps, never asserted.
  queue       What has been found and not yet dealt with, by triage tier.
  pending     Content already signed that has not taken effect yet, with a day
              count. This is the good case — a change caught early — and it is
              shown next to the others so the screen is not only bad news.

None of it is a judgement about whether the rules are correct. A regime can be
CURRENT on every source and hold rules that were wrong when they were written.
The claim is narrower and it is the only one this system can actually support:
here is when we last looked, here is what we found, and here is who signed what.
"""

from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import packs_repo
from ..models import PackDraft, WatchEvent
from . import drafts, sources, triage

#: Statuses a queue item can be in. `new` and `reviewing` are open; the rest are
#: closed and drop out of the count the screen leads with.
OPEN_STATUSES = ("new", "reviewing")


def _pack_summary(session: Session, on: date) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for jurisdiction, row in packs_repo.active_rows(session, on).items():
        body = row.body or {}
        watch = body.get("watch") or {}
        out[jurisdiction] = {
            "jurisdiction": jurisdiction,
            "jurisdiction_name": body.get("jurisdiction_name") or jurisdiction,
            "regulator": body.get("regulator", ""),
            "version": row.version,
            "effective_from": row.effective_from.isoformat(),
            "content_status": body.get("content_status", "ILLUSTRATIVE"),
            "signed_by": row.signed_by,
            # A pack that declares no sources is not monitored, and the screen
            # says so rather than showing a jurisdiction with a tidy empty list.
            "watched": bool(watch.get("sources")),
            "vocabulary_terms": len(watch.get("vocabulary", [])),
        }
    return out


def _queue_counts(session: Session) -> dict[str, Any]:
    rows = session.execute(
        select(WatchEvent.jurisdiction, WatchEvent.tier, WatchEvent.status, func.count())
        .group_by(WatchEvent.jurisdiction, WatchEvent.tier, WatchEvent.status)
    ).all()
    by_jurisdiction: dict[str, dict[str, Any]] = {}
    by_tier: dict[str, int] = {}
    open_total = 0
    for jurisdiction, tier, status, count in rows:
        bucket = by_jurisdiction.setdefault(jurisdiction, {"open": 0, "total": 0, "by_tier": {}})
        bucket["total"] += count
        if status in OPEN_STATUSES:
            bucket["open"] += count
            bucket["by_tier"][tier] = bucket["by_tier"].get(tier, 0) + count
            by_tier[tier] = by_tier.get(tier, 0) + count
            open_total += count
    return {"by_jurisdiction": by_jurisdiction, "by_tier": by_tier, "open": open_total}


def pending_packs(session: Session, on: date) -> list[dict[str, Any]]:
    """Signed content that has not taken effect yet, with a countdown.

    A future-dated pack changes nothing today — `packs_repo.active()` filters it
    out by date, which is what makes it safe to store one at all. The countdown
    is the point: it turns "this is stored" into "this takes over in 12 days",
    which is a sentence somebody can act on.
    """
    out: list[dict[str, Any]] = []
    for row in packs_repo.pending_rows(session, on):
        body = row.body or {}
        out.append(
            {
                "jurisdiction": row.jurisdiction,
                "jurisdiction_name": body.get("jurisdiction_name") or row.jurisdiction,
                "version": row.version,
                "effective_from": row.effective_from.isoformat(),
                "days_until_effective": (row.effective_from - on).days,
                "content_status": body.get("content_status", "ILLUSTRATIVE"),
                "signed_by": row.signed_by,
                "notes": body.get("notes", ""),
            }
        )
    return out


def overview(
    session: Session,
    on: date | None = None,
    now: datetime | None = None,
    regimes: set[str] | None = None,
) -> dict[str, Any]:
    """Everything the currency screen leads with, computed in one pass.

    `regimes` scopes the whole answer to the jurisdictions one customer is
    actually in. §S6 asks for this screen to gain tenancy, and the reason is not
    tidiness: a firm licensed only in Australia reading a rollup that goes amber
    because an ESMA feed is late learns to ignore the rollup. The badge has to
    mean *your* monitoring, or it means nothing.

    `None` means "every regime we hold a pack for", and it is deliberately not
    the same as an empty set. A customer who has not told us which regimes they
    operate in should see everything rather than nothing — the failure mode of
    the other default is a screen that reports perfect currency because it is
    watching no regimes at all.
    """
    now = now or datetime.now(timezone.utc)
    on = on or now.date()

    packs = _pack_summary(session, on)
    if regimes is not None:
        packs = {code: entry for code, entry in packs.items() if code in regimes}
    source_rows = [s for s in sources.describe(session, now) if s["enabled"]]
    queue = _queue_counts(session)

    per_jurisdiction: list[dict[str, Any]] = []
    for code in sorted(packs):
        mine = [s for s in source_rows if s["jurisdiction"] == code]
        counts = queue["by_jurisdiction"].get(code, {"open": 0, "total": 0, "by_tier": {}})
        # Sources that have stopped answering, as distinct from sources nobody
        # has got to. §S6's SLA work makes the difference visible, and it is the
        # difference between "we are behind" and "the publisher is down" — a
        # customer asking why their regime is stale deserves the right answer.
        unreachable = [s for s in mine if s["breaching"]]
        per_jurisdiction.append(
            {
                **packs[code],
                "sources": mine,
                "unreachable": [
                    {
                        "id": s["id"],
                        "name": s["name"],
                        "consecutive_failures": s["consecutive_failures"],
                        "reason": s["last_error"],
                    }
                    for s in unreachable
                ],
                "freshness": sources.worst([s["freshness"] for s in mine]),
                "open_items": counts["open"],
                "open_by_tier": counts["by_tier"],
                "last_checked_at": max(
                    (s["last_checked_at"] for s in mine if s["last_checked_at"]),
                    default=None,
                ),
            }
        )

    # Events about regimes we hold no pack for. Phase 3 stated coverage gaps on
    # a determination; this states them on the monitoring side, where the honest
    # answer is that we cannot tell whether the publication matters.
    uncovered = session.execute(
        select(WatchEvent.jurisdiction, func.count())
        .where(WatchEvent.tier == triage.UNMATCHED)
        .group_by(WatchEvent.jurisdiction)
    ).all()
    if regimes is not None:
        # A coverage gap in a regime this customer is not in is our problem and
        # not theirs. Shown to us on the internal screen; not on this one.
        uncovered = [row for row in uncovered if row[0] in regimes]

    draft_rows = session.scalars(
        select(PackDraft).order_by(PackDraft.created_at.desc())
    ).all()
    awaiting = [drafts.view(d, today=on) for d in draft_rows if d.status == drafts.DRAFT]
    signed = [drafts.view(d, today=on) for d in draft_rows if d.status == drafts.SIGNED]

    all_states = [j["freshness"] for j in per_jurisdiction]
    return {
        "as_of": on.isoformat(),
        # Which regimes this answer covers, and whether that was a choice. A
        # screen that silently showed three of four would be worse than one that
        # showed all four.
        "regimes": sorted(packs) if regimes is not None else None,
        "checked_at": now.isoformat(),
        "mode": sources.mode(),
        "mode_note": (
            "Sources are read from a fixture checked into this repository. No "
            "regulator is contacted. Each source records the mode of its own last "
            "check, so this badge cannot relabel history."
            if sources.mode() == sources.REPLAY
            else "Live polling is configured but no publisher adapter is built."
        ),
        "freshness": sources.worst(all_states),
        "jurisdictions": per_jurisdiction,
        "unreachable": sum(len(j["unreachable"]) for j in per_jurisdiction),
        "open_items": queue["open"],
        "open_by_tier": queue["by_tier"],
        "pending_packs": pending_packs(session, on),
        "drafts_awaiting_signature": awaiting,
        "drafts_signed_not_published": signed,
        "uncovered": [{"jurisdiction": j, "events": c} for j, c in sorted(uncovered)],
        "statement": (
            "This screen reports when each source was last checked and what was "
            "found. It does not assert that the rules are correct, and nothing "
            "here has changed a rule: a watch item becomes rule content only when "
            "a named person signs a draft."
        ),
    }
