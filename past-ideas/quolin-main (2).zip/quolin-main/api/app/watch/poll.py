"""Fetching what has been published, and refusing to pretend when it cannot.

Two modes, and the difference between them is the whole point of the module.

  replay  Reads `fixtures/watch_events.json`. Nothing external is contacted.
          This is the default, because the other default is a demo that quietly
          starts making requests to four regulators.
  live    Reaches the publishers, for every source whose pack content declares
          a feed. A source with no `feed` block has no adapter and is recorded
          as a *content* failure by name — never silently served from the
          fixture. That fallback would be the worst available behaviour: the
          screen would say `live`, the data would be invented, and nobody
          downstream could tell.

A live sweep respects cadence. Reading a monthly source every ten minutes keeps
neither the promise the pack made nor the publisher's goodwill, so only sources
actually due are contacted; replay sweeps check everything, because reading a
file costs nobody anything and the demo should not depend on the clock.

Failures are counted, not swallowed. A source that times out or answers 503 has
its failure count incremented and `last_checked_at` left where it was — a
timeout is not a check — and at its own threshold the owner named in pack
content is paged. See `sources.mark_failed` and `sources.breaches`.

Polling is idempotent on `WatchEvent.digest`. Re-running a poll must not
resurrect an item somebody has already dismissed — a queue that punishes an
officer for working through it is a queue they stop working through.
"""

from __future__ import annotations

import hashlib
import json
import pathlib
from datetime import date, datetime, timezone
from typing import Any, cast

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import observability
from ..models import WatchAssistCall, WatchEvent, WatchSource
from . import assist, fetchers, sources, triage

FIXTURE = (
    pathlib.Path(__file__).resolve().parent.parent.parent.parent
    / "fixtures"
    / "watch_events.json"
)


class LiveModeUnavailable(RuntimeError):
    """Raised when `WATCH_MODE=live` but not one source can be read live.

    Carries the sources it would have needed an adapter for, so the message
    names the work rather than saying 'not implemented'. Raised only when
    *nothing* is fetchable: a sweep where some sources have feeds and some do
    not is a real sweep with recorded failures against the ones that do not,
    which is more useful than refusing the whole thing.
    """

    def __init__(self, source_ids: list[str]):
        self.source_ids = source_ids
        super().__init__(
            "WATCH_MODE=live, but no declared source names a feed this build can "
            "read. Live polling needs a `feed` block per source "
            f"({', '.join(source_ids) or 'none declared'}) giving the format and "
            "URL. Nothing has been fetched and no event was recorded."
        )


def digest_for(source_id: str, url: str, title: str, published_at: str) -> str:
    """Stable identity for a publication.

    Built from the publisher's own url when there is one, because that is the
    thing that is actually stable; title and date only carry the weight when a
    feed gives no permalink. Hashed rather than stored raw so the uniqueness
    constraint is over a fixed-width value.
    """
    basis = f"{source_id}|{url or title}|{published_at}"
    return hashlib.sha256(basis.encode()).hexdigest()[:32]


def _load_fixture() -> list[dict[str, Any]]:
    if not FIXTURE.exists():
        return []
    body = json.loads(FIXTURE.read_text())
    # The file leads with a `note` saying the contents are invented, so it is an
    # object rather than a bare array. A reader who opens the fixture should not
    # have to already know that.
    return cast(
        "list[dict[str, Any]]", body["events"] if isinstance(body, dict) else body
    )


def poll(
    session: Session,
    on: date,
    now: datetime | None = None,
    client: httpx.Client | None = None,
) -> dict[str, Any]:
    """Check every source that is due and record anything not already seen.

    Returns counts rather than the events themselves: the caller reads the queue
    from the table afterwards, so what the screen shows is what was persisted
    rather than a separate in-memory view of it that could disagree.
    """
    with observability.timed("watch.poll", "swept the watch sources", on=str(on)):
        return _poll(session, on, now, client)


def _poll(
    session: Session,
    on: date,
    now: datetime | None = None,
    client: httpx.Client | None = None,
) -> dict[str, Any]:
    """The body of `poll`. See FP3-16 for why the timing is a wrapper."""
    now = now or datetime.now(timezone.utc)
    how = sources.mode()
    sources.sync(session, on)

    declared = {s["id"]: s for s in sources.declared(session, on)}
    if how == sources.LIVE and not any(s["feed"] for s in declared.values()):
        raise LiveModeUnavailable(sorted(declared))

    rows = {r.id: r for r in session.scalars(select(WatchSource)).all()}
    if how == sources.LIVE:
        # Cadence is a promise about how often a source is read. A sweep that
        # ignored it would contact a monthly source every time the scheduler
        # fired, which is both a broken promise and a good way to be blocked.
        checking = [r.id for r in sources.due(list(rows.values()), now) if r.id in declared]
    else:
        checking = [sid for sid in declared if rows.get(sid) is None or rows[sid].enabled]

    items, failures, gaps = _collect(session, declared, checking, on, now, how, client)

    vocab = sources.vocabulary(session, on)
    seen = set(session.scalars(select(WatchEvent.digest)))

    new = 0
    duplicates = 0
    escalated = 0
    by_tier: dict[str, int] = {}
    for item in items:
        source_id = item["source_id"]
        spec = declared.get(source_id)
        # An event for a source no in-force pack declares is skipped rather than
        # recorded against a jurisdiction nobody is watching. The fixture can
        # outlive a pack edit; the queue should not inherit its ghosts.
        if spec is None:
            continue

        published_at = item["published_at"]
        digest = item.get("digest") or digest_for(
            source_id, item.get("url", ""), item["title"], published_at
        )
        if digest in seen:
            duplicates += 1
            continue

        # A publication carried by one regulator's feed is not always *about*
        # that regime — regulators write about each other, and a bloc's press
        # office covers its members. When the item names the regime it concerns,
        # that is the regime whose pack it should be compared against, and when
        # we hold no pack for it the item lands in the coverage-gap tier instead
        # of being quietly filed under the publisher's own jurisdiction.
        jurisdiction = item.get("about_jurisdiction") or spec["jurisdiction"]
        verdict = triage.classify(
            title=item["title"],
            summary=item.get("summary", ""),
            vocabulary=vocab.get(jurisdiction),
            has_active_pack=jurisdiction in vocab,
        )
        event = WatchEvent(
            source_id=source_id,
            jurisdiction=jurisdiction,
            digest=digest,
            title=item["title"],
            summary=item.get("summary", ""),
            url=item.get("url", ""),
            published_at=date.fromisoformat(published_at),
            observed_at=now,
            # The tier is what the pack's own vocabulary produced, and it is
            # settled here — before the model is asked anything and regardless
            # of what it says. See `_ask_the_model`.
            tier=verdict["tier"],
            matched=verdict["matched"],
            status="new",
        )
        session.add(event)
        session.flush()
        if _ask_the_model(session, event, vocab.get(jurisdiction) or []):
            escalated += 1
        seen.add(digest)
        new += 1
        by_tier[verdict["tier"]] = by_tier.get(verdict["tier"], 0) + 1

    session.flush()
    return {
        "mode": how,
        "sources_checked": len(checking),
        "sources_failed": len(failures),
        "failures": failures,
        # Sources this build cannot read at all, because pack content declares
        # no feed for them. A backlog, not an outage — see `_collect`.
        "no_adapter": gaps,
        "new_events": new,
        "already_seen": duplicates,
        "by_tier": by_tier,
        # Items a model raised a hand about. Not a tier and not a decision — see
        # `watch/assist.py::apply`, which is the whole of its authority.
        "escalated": escalated,
        "assisted": assist.available(),
    }


def _ask_the_model(
    session: Session, event: WatchEvent, vocabulary: list[dict[str, Any]]
) -> bool:
    """Have a model read one publication, and record what it said. Returns
    whether it raised a hand.

    Called *after* the event is written with its rule-derived tier, which is the
    ordering that makes the boundary checkable: the tier exists before the model
    is asked and is not passed anywhere it could be changed. What comes back is
    stored in an append-only table and can set one boolean.

    A failure here is swallowed and recorded, never raised. The sweep's job is to
    notice what regulators published; a model being unavailable, slow or wrong
    must not cost us the publication. That is the same reasoning `service.notify`
    uses for webhooks and it applies more strongly here — this is the optional
    half of the feature.
    """
    if not assist.available():
        return False

    try:
        suggestion = assist.read(
            title=event.title,
            summary=event.summary,
            jurisdiction=event.jurisdiction,
            vocabulary=vocabulary,
        )
        escalate, reason = assist.apply(suggestion, deterministic_tier=event.tier)
    except Exception as exc:  # noqa: BLE001 — see the docstring
        session.add(
            WatchAssistCall(
                event_id=event.id,
                model=assist.model_name(),
                prompt="(the call did not complete)",
                output=f"{type(exc).__name__}: {exc}",
                confidence_pct=0,
                deterministic_tier=event.tier,
                # A failed reading escalates, for the same reason an uncertain
                # one does: we do not know, and not knowing is a person's
                # business. It also makes an outage visible in the queue rather
                # than only in a log nobody reads.
                escalated=True,
                escalation_reason=(
                    "The model could not be reached, so this is raised for a "
                    "person to read."
                ),
            )
        )
        return True

    session.add(
        WatchAssistCall(
            event_id=event.id,
            model=suggestion.model,
            prompt=suggestion.prompt,
            output=suggestion.output,
            confidence_pct=int(round(suggestion.confidence * 100)),
            deterministic_tier=event.tier,
            escalated=escalate,
            escalation_reason=reason,
        )
    )
    return escalate


def _collect(
    session: Session,
    declared: dict[str, Any],
    checking: list[str],
    on: date,
    now: datetime,
    how: str,
    client: httpx.Client | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, str]], list[dict[str, str]]]:
    """What was published, what did not answer, and what we cannot read at all.

    Three return values because they are three different facts and the SLA
    machinery turns on the differences. A regulator who published nothing this
    week is a healthy source. One whose site is down is a breach waiting to be
    counted. One our pack declares no feed for is neither — it is a piece of
    content nobody has written yet, and paging a specialist about it at 3am
    would be telling them their network is broken when it is our backlog.
    """
    if how == sources.REPLAY:
        for source_id in checking:
            sources.mark_checked(session, source_id, now, how)
        return _load_fixture(), [], []

    items: list[dict[str, Any]] = []
    failures: list[dict[str, str]] = []
    gaps: list[dict[str, str]] = []
    # One client for the whole sweep: connection reuse across a handful of
    # publishers is worth having, and a caller that already holds one — a test
    # driving a stub transport, a worker pooling across sweeps — passes it in
    # rather than having a second opened underneath it.
    owns_client = client is None
    client = client or httpx.Client(
        timeout=fetchers.TIMEOUT_SECONDS,
        follow_redirects=True,
        headers={"User-Agent": fetchers.USER_AGENT},
    )
    try:
        for source_id in checking:
            spec = declared[source_id]
            # The digest we last saw at this URL, so a page source can tell
            # "changed" from "unchanged". Read from the row rather than carried
            # in pack content: it is state about our monitoring, not a fact
            # about the regime.
            row = session.get(WatchSource, source_id)
            spec = {
                **spec,
                "content_hash": row.content_hash if row is not None else "",
            }
            feed = fetchers.feed_of(spec)
            try:
                fetched = fetchers.fetch(spec, today=on, client=client)
                items.extend(fetched.items)
            except fetchers.NoAdapter as exc:
                # Not an outage. The publisher is fine; our pack does not say how
                # to read them, and counting that toward an alert threshold would
                # page somebody about a network that is working. It is reported
                # as what it is — a gap in content — and the source keeps its
                # existing check timestamp, because nothing was checked.
                gaps.append({"source_id": source_id, "reason": exc.reason})
            except fetchers.FetchError as exc:
                # Counted, named, and the check timestamp left alone. A failed
                # fetch that advanced `last_checked_at` would show a dead source
                # as freshly checked, which is the one thing this screen exists
                # to prevent.
                count = sources.mark_failed(session, source_id, now, exc.reason)
                failures.append(
                    {"source_id": source_id, "reason": exc.reason, "consecutive": str(count)}
                )
            else:
                sources.mark_checked(
                    session,
                    source_id,
                    now,
                    how,
                    fetcher=(feed or {}).get("kind", ""),
                    # Recorded only on a successful read, and only for the
                    # adapter that uses it. A digest written after a failed
                    # fetch would make the next check report "unchanged" about
                    # a page nobody managed to read.
                    content_hash=fetched.content_hash,
                )
    finally:
        if owns_client:
            client.close()
    return items, failures, gaps
