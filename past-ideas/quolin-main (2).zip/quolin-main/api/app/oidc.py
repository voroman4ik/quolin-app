"""Signing in through the customer's own identity provider.

The execution document asks for SSO via a broker, OIDC first, with SAML
capability present. This module is the OIDC half, and the SAML half is the
reason it is written against a *broker* rather than against one vendor's IdP:
Quolin speaks OIDC to WorkOS (or Auth0, or Entra), and the broker speaks SAML,
Okta, ADFS or whatever else the customer's security team actually runs. That is
what "SAML capability present" means here — not a second protocol implemented in
this file, but a deployment where turning SAML on is the customer's tenant
configuration in the broker rather than a release of ours. `docs/deployment.md`
says so in the same words, because a claim made only in a Python docstring is a
claim the sales conversation cannot use.

**What this is not.** It is not a user directory and it does not create people.
A `sub` this deployment has never seen is refused, exactly like a password
sign-in by somebody with no role grant: authentication says who is at the door,
and only a grant made by the firm says they may come in. Just-in-time
provisioning — an IdP assertion that creates a user *and* their roles — is the
one thing that would let a misconfigured group at the customer's end mint
approvers, so it is a deliberate omission and is in docs/post-raise.md.

**The three values a login carries, and why each exists.**

* `state` — returned by the IdP untouched and compared here. Without it, an
  attacker can hand a victim a callback URL containing the attacker's own
  authorization code, and the victim's browser silently ends up holding a
  session for the attacker's account.
* `nonce` — minted here, echoed inside the signed ID token. It binds the token
  to *this* login attempt, so a token captured from another one cannot be
  replayed into it.
* PKCE `code_verifier` — the code the IdP issues is worth nothing without it, so
  an authorization code intercepted in a redirect (browser history, a logging
  proxy, a rogue extension) cannot be exchanged by whoever grabbed it.

All three live in a short-lived signed cookie rather than a database row, and
that is the one place this file departs from the server-side habit the rest of
authentication follows. A login attempt is not a session: it grants nothing,
lasts a few minutes, and its integrity requirement is that the browser cannot
forge or edit it — which an HMAC under the master key gives without a table, a
policy, and a sweeper for rows nobody ever completes. The signature is what
makes the cookie trustworthy; secrecy of its contents is not relied on.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode

import httpx
import jwt

from .crypto import master_key

#: The cookie the two halves of a login share. Deleted the moment the callback
#: reads it, whether or not the login succeeded.
STATE_COOKIE = "quolin_oidc"

#: How long a person has between being sent to the IdP and coming back. Long
#: enough to type a password and approve a push, short enough that a stale tab
#: reopened tomorrow starts again rather than completing.
STATE_TTL_SECONDS = 600

#: Timeout on every call to the provider. A hung discovery or token endpoint
#: must fail the login rather than hold a worker open.
HTTP_TIMEOUT_SECONDS = 10.0


class OidcError(RuntimeError):
    """A login could not be completed. The message is safe to show a user."""


class NotConfigured(OidcError):
    """No identity provider is configured for this deployment."""


@dataclass(frozen=True)
class Provider:
    """What the deployment was told about its identity provider."""

    issuer: str
    client_id: str
    client_secret: str
    redirect_uri: str
    #: Where the browser lands after the callback has minted a session. The API
    #: and the web app are different origins, so the callback cannot simply
    #: render a page.
    post_login_url: str
    scopes: str = "openid email profile"


def configured() -> Provider | None:
    """The provider from the environment, or None when SSO is switched off.

    Returning None rather than raising, because "this deployment has no IdP" is
    the normal state of the demo and of local development — the password
    fallback exists precisely for tenants without one. The routes turn
    themselves off when this is None; they do not 500.
    """
    issuer = os.getenv("QUOLIN_OIDC_ISSUER", "").strip().rstrip("/")
    client_id = os.getenv("QUOLIN_OIDC_CLIENT_ID", "").strip()
    client_secret = os.getenv("QUOLIN_OIDC_CLIENT_SECRET", "").strip()
    redirect_uri = os.getenv("QUOLIN_OIDC_REDIRECT_URI", "").strip()
    if not (issuer and client_id and client_secret and redirect_uri):
        return None
    return Provider(
        issuer=issuer,
        client_id=client_id,
        client_secret=client_secret,
        redirect_uri=redirect_uri,
        post_login_url=os.getenv("QUOLIN_OIDC_POST_LOGIN_URL", "").strip()
        or "http://localhost:3100/",
        scopes=os.getenv("QUOLIN_OIDC_SCOPES", "").strip() or "openid email profile",
    )


def require_configured() -> Provider:
    provider = configured()
    if provider is None:
        raise NotConfigured("No identity provider is configured for this deployment.")
    return provider


# ------------------------------------------------------------------ transport --


def _client() -> httpx.Client:
    """One place that makes HTTP clients, so nothing acquires a second, un-timed
    way out to the network.

    There is no test seam here on purpose. `tests/stub_idp.py` runs a real
    provider on a real socket and the suite points `QUOLIN_OIDC_ISSUER` at it, so
    what the tests exercise is this module making ordinary HTTP requests — not a
    branch that only exists because they are watching.
    """
    return httpx.Client(timeout=HTTP_TIMEOUT_SECONDS)


# ------------------------------------------------------------------ discovery --


def discover(provider: Provider) -> dict[str, Any]:
    """The provider's own description of its endpoints.

    Fetched rather than configured, because the three URLs below move — a broker
    rotates a hostname, a customer migrates to a new region — and a deployment
    whose endpoints are pinned in environment variables breaks silently at the
    worst moment. Not cached: this happens once per login, and a stale cached
    JWKS URI after a provider migration is a harder outage to diagnose than one
    extra request.
    """
    url = f"{provider.issuer}/.well-known/openid-configuration"
    try:
        with _client() as client:
            res = client.get(url)
    except httpx.HTTPError as exc:
        raise OidcError("Could not reach the identity provider.") from exc
    if res.status_code != 200:
        raise OidcError("The identity provider did not describe itself.")

    document = res.json()
    # The issuer in the document must be the issuer we asked, or the discovery
    # response is describing somebody else and every check below is anchored to
    # the wrong party.
    if str(document.get("issuer", "")).rstrip("/") != provider.issuer:
        raise OidcError("The identity provider's issuer does not match its address.")
    for field in ("authorization_endpoint", "token_endpoint", "jwks_uri"):
        if not document.get(field):
            raise OidcError(f"The identity provider declares no {field}.")
    return document


# ----------------------------------------------------------- the state cookie --


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def _unb64(raw: str) -> bytes:
    return base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4))


#: Domain separation. The master key wraps every tenant's data key, and using
#: the same bytes to also sign cookies would mean one key serving two purposes —
#: the arrangement where a weakness in either use becomes a weakness in both.
#: Derived per call rather than cached, for the reason `master_key` gives.
def _cookie_key() -> bytes:
    return hmac.new(master_key(), b"quolin/oidc-state/v1", hashlib.sha256).digest()


def _sign(payload: bytes) -> str:
    return _b64(hmac.new(_cookie_key(), payload, hashlib.sha256).digest())


def seal(state: str, nonce: str, verifier: str, *, now: float | None = None) -> str:
    """The cookie value binding one login attempt together."""
    body = json.dumps(
        {
            "state": state,
            "nonce": nonce,
            "verifier": verifier,
            "exp": int((now if now is not None else time.time()) + STATE_TTL_SECONDS),
        },
        separators=(",", ":"),
        sort_keys=True,
    ).encode()
    return f"{_b64(body)}.{_sign(body)}"


def unseal(cookie: str, *, now: float | None = None) -> dict[str, Any]:
    """Read a sealed cookie back, or refuse it.

    Every failure is the same exception with the same message. The caller is a
    browser mid-redirect; there is nothing it can do differently on being told
    the signature was wrong rather than the clock, and the distinction is only
    useful to somebody probing the format.
    """
    bad = OidcError("This sign-in attempt is no longer valid. Please start again.")
    try:
        encoded, signature = cookie.split(".", 1)
        body = _unb64(encoded)
    except (ValueError, TypeError) as exc:
        raise bad from exc

    # Constant-time, because a byte-by-byte comparison of a MAC is a forgery
    # oracle for anyone who can measure it.
    if not hmac.compare_digest(signature, _sign(body)):
        raise bad
    try:
        payload = json.loads(body)
    except json.JSONDecodeError as exc:
        raise bad from exc
    if float(payload.get("exp", 0)) <= (now if now is not None else time.time()):
        raise bad
    return payload


# ---------------------------------------------------------------- the redirect --


@dataclass(frozen=True)
class Start:
    """Where to send the browser, and the cookie to set while it is gone."""

    url: str
    cookie: str


def start(provider: Provider) -> Start:
    """Begin a login: mint the three values and build the authorization URL."""
    document = discover(provider)
    state = secrets.token_urlsafe(24)
    nonce = secrets.token_urlsafe(24)
    verifier = secrets.token_urlsafe(48)
    challenge = _b64(hashlib.sha256(verifier.encode()).digest())

    query = urlencode(
        {
            "response_type": "code",
            "client_id": provider.client_id,
            "redirect_uri": provider.redirect_uri,
            "scope": provider.scopes,
            "state": state,
            "nonce": nonce,
            "code_challenge": challenge,
            # S256 and never `plain`. A `plain` challenge is the verifier, so an
            # attacker who can see the authorization request can complete the
            # exchange — which is the whole attack PKCE exists to stop.
            "code_challenge_method": "S256",
        }
    )
    return Start(
        url=f"{document['authorization_endpoint']}?{query}",
        cookie=seal(state, nonce, verifier),
    )


# ----------------------------------------------------------------- the callback --


@dataclass(frozen=True)
class Claims:
    """Who the provider says came back, reduced to what this product uses."""

    issuer: str
    subject: str
    email: str
    email_verified: bool
    display_name: str


def _signing_key(jwks_uri: str, token: str) -> Any:
    """The published key this token says it was signed with.

    PyJWT ships `PyJWKClient`, which does this and fetches the key set over
    `urllib` — its own connection, with its own timeout, outside the transport
    every other call in this module goes through. So the fetch happens here
    instead, and the library is left doing the part that is worth depending on
    it for.

    Selecting by the token's `kid` is safe and is not the same mistake as
    trusting its `alg`: `kid` only chooses among keys *the provider published*,
    so the worst a forged one can do is name a key that is not there. `alg`
    would choose the algorithm, which is how a token talks a verifier into
    checking an RSA signature as an HMAC.
    """
    try:
        with _client() as client:
            res = client.get(jwks_uri)
    except httpx.HTTPError as exc:
        raise OidcError("Could not reach the identity provider.") from exc
    if res.status_code != 200:
        raise OidcError("The identity provider published no signing keys.")

    key_set = jwt.PyJWKSet.from_dict(res.json())
    usable = [k for k in key_set.keys if k.public_key_use in ("sig", None)]
    if not usable:
        raise OidcError("The identity provider published no signing keys.")

    kid = jwt.get_unverified_header(token).get("kid")
    if kid is None:
        # A provider with one key need not name it. A provider with several must,
        # because guessing which one would mean trying each — and a verifier that
        # tries every key until one works is a verifier with no key policy.
        if len(usable) != 1:
            raise OidcError("The identity token names no signing key.")
        return usable[0].key
    for candidate in usable:
        if candidate.key_id == kid:
            return candidate.key
    raise OidcError("The identity token was signed by a key we do not know.")


def _exchange(provider: Provider, document: dict[str, Any], code: str, verifier: str) -> dict:
    try:
        with _client() as client:
            res = client.post(
                document["token_endpoint"],
                data={
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": provider.redirect_uri,
                    "client_id": provider.client_id,
                    "client_secret": provider.client_secret,
                    "code_verifier": verifier,
                },
                headers={"Accept": "application/json"},
            )
    except httpx.HTTPError as exc:
        raise OidcError("Could not reach the identity provider.") from exc
    if res.status_code != 200:
        raise OidcError("The identity provider refused the sign-in.")
    body = res.json()
    if not body.get("id_token"):
        raise OidcError("The identity provider returned no identity token.")
    return body


def complete(
    provider: Provider, *, code: str, state: str, cookie: str | None
) -> Claims:
    """Turn a callback into claims, or refuse it.

    The order matters and is the order below: the cookie is validated before the
    code is spent, so a forged callback costs nothing; `state` is compared before
    the exchange, so an attacker's code is never presented to the provider under
    a victim's session; and the token's signature, issuer, audience, expiry and
    `nonce` are all checked before a single claim is read.
    """
    if not cookie:
        raise OidcError("This sign-in attempt is no longer valid. Please start again.")
    sealed = unseal(cookie)

    if not secrets.compare_digest(str(sealed.get("state", "")), state):
        raise OidcError("This sign-in did not come from a request we made.")
    if not code:
        raise OidcError("The identity provider returned no authorization code.")

    document = discover(provider)
    tokens = _exchange(provider, document, code, str(sealed["verifier"]))

    id_token = tokens["id_token"]
    try:
        claims = jwt.decode(
            id_token,
            _signing_key(document["jwks_uri"], id_token),
            # Asymmetric only, and listed rather than taken from the token. A
            # verifier that trusts the token's own `alg` accepts `none`, and
            # accepts HS256 signed with the public key it was about to verify
            # against — both are one-line total bypasses and both have shipped.
            algorithms=["RS256", "RS384", "RS512", "ES256", "ES384"],
            audience=provider.client_id,
            issuer=document["issuer"],
            options={"require": ["exp", "iat", "iss", "aud", "sub"]},
        )
    except jwt.PyJWTError as exc:
        raise OidcError("The identity token did not check out.") from exc

    # Checked here rather than by the library, which has no opinion about it:
    # `nonce` is what ties this token to the redirect this browser began.
    if not secrets.compare_digest(str(claims.get("nonce", "")), str(sealed["nonce"])):
        raise OidcError("The identity token belongs to a different sign-in.")

    subject = str(claims.get("sub", ""))
    if not subject:
        raise OidcError("The identity token names nobody.")

    return Claims(
        issuer=str(document["issuer"]).rstrip("/"),
        subject=subject,
        email=str(claims.get("email", "")).strip().lower(),
        # Absent means no. A provider that does not say an address is verified
        # has not verified it, and this flag is what decides whether an address
        # may be matched to an existing account.
        email_verified=bool(claims.get("email_verified", False)),
        display_name=str(claims.get("name", "")).strip(),
    )
