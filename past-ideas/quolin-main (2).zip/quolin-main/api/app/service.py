from __future__ import annotations

from datetime import date
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import adoption, advance, business_time, evidence, manifest, packs_repo, tenancy
from .engine import (
    Pack,
    PackError,
    build_snapshot,
    evaluate_snapshot,
    failing_reasons,
    outcome_rank,
    resolve_across,
    select_packs,
    view_for,
)
from .models import Asset, AuditEvent, Decision, Override
from .providers import AuditQueueSink, DbClientProvider, FixturePositionsProvider

#: Fallback for a client record that predates residency and domicile. Not a
#: default the engine knows about — the engine is handed a code, never a name.
DEFAULT_JURISDICTION = "AU"


class Unattributed(RuntimeError):
    """Something reached the audit trail with nobody behind it.

    Raised rather than written under a placeholder. An audit trail whose gaps
    are filled with a stand-in name is worse than one with holes in it: the
    holes are visible, and a plausible-looking stand-in reads like a person
    right up until somebody asks who that is.
    """


def audit(session: Session, action: str, subject: str) -> None:
    """Record what was done, to what, by whoever is acting.

    The actor is not a parameter. It comes from the ambient scope the auth
    middleware entered, for the reason the middleware's own note gives: a call
    site that had to remember to pass the person is a call site that writes an
    unattributed row the day somebody forgets. There is no caller that knows
    better than the session cookie who is acting.
    """
    actor = tenancy.current_user_or_none()
    if not actor:
        raise Unattributed(f"{action} on {subject} has no acting user in scope")
    event = AuditEvent(actor=actor, action=action, subject=subject)
    # Chained onto the tenant's audit history before it is added, closing T3 in
    # the threat model. Append-only stopped this row being edited; it did
    # nothing about a privileged actor inserting history that never happened,
    # and the export carried no arithmetic proof the sequence was intact.
    #
    evidence.link_audit(session, event)
    session.add(event)


def _tell_the_customers_systems(
    session: Session, event: str, subject: str, payload: dict[str, Any]
) -> None:
    """Queue an outbound webhook, and never let it break the thing that caused it.

    Two properties, and both matter more than the notification.

    **It cannot fail the determination.** A decision has been made and recorded;
    telling somebody about it is a separate obligation. If a tenant has no
    endpoints, or the row cannot be written for any reason, the determination
    still stands — so this swallows what it catches and audits the miss rather
    than raising into a caller that has just written to the evidence chain.

    **It cannot slow the determination down.** `webhooks.enqueue` writes rows and
    returns; nothing here opens a socket. The sending happens in
    `scripts/deliver_webhooks.py`, out of band, where a customer's slow case
    system costs a worker rather than a request.

    Imported here rather than at module scope to keep the dependency one-way:
    `webhooks` knows nothing about determinations, and this is the only place
    that knows about both.
    """
    from . import webhooks

    try:
        webhooks.enqueue(session, event=event, subject=subject, payload=payload)
    except Exception as exc:  # pragma: no cover - defensive, see the note above
        # Audited rather than silent. A notification nobody was told about and
        # nobody recorded failing is the shape of a customer discovering months
        # later that they were never being told.
        audit(session, "webhook.enqueue_failed", f"{event} {subject}: {exc}")


#: Reads that are worth a row in the audit trail. FP3-14.
#:
#: Deliberately not every GET. Auditing "somebody opened the dashboard" produces
#: a trail nobody reads, and a trail nobody reads is where a real access hides —
#: which is the same argument the override report makes about alert volume.
#:
#: These three are the ones where the question "who looked at this record" has
#: an answer somebody is entitled to:
#:
#:   * a client's detail, which carries their name, date of birth and contact
#:     details, and is readable by `viewer`;
#:   * a determination's snapshot, which carries the frozen client facts;
#:   * an artefact download, which is the document itself.
#:
#: And every request made under a `quolin_support` grant, whatever it reads.
#: `docs/` describes support access as "every access logged" and it was logged
#: nowhere.
READ_AUDITED = "read"


def audit_read(
    session: Session,
    *,
    resource: str,
    subject: str,
    support: bool = False,
) -> None:
    """Record that somebody looked at something.

    FP3-14. `main.py` had forty GET routes and thirty `service.audit` calls, and
    none of the thirty was on a GET. `/clients/{id}` returns a name, a date of
    birth and contact details to anybody holding `viewer`, and nothing anywhere
    recorded that it had been read.

    That is the SOC 2 question and the privacy question in the same sentence:
    *who looked at this record*. A firm answering a subject-access request, or an
    auditor asking who saw a client's file the week before a complaint, had
    nothing to read.

    Written through `audit`, so it is inside the hash chain migration 0026 added
    — a record of access that could be edited is the shape of the finding rather
    than a fix for it.
    """
    action = f"{READ_AUDITED}.{resource}"
    if support:
        # Named distinctly so "every access under a support grant" is one query
        # rather than a join against whoever held the role that week.
        action = f"support.{action}"
    audit(session, action, subject)


def _governing_pack_id(decision: Decision) -> str:
    """The pack a decision was governed by.

    Falls back for rows written before decisions carried the jurisdiction they
    were made under. Those rows are all from the single-jurisdiction era, so
    the fallback is a fact about them rather than a guess.
    """
    return decision.pack_id or DEFAULT_JURISDICTION


def evaluate(
    session: Session,
    *,
    client_id: str,
    asset_id: str,
    as_of: date | None = None,
    amount_cents: int | None = None,
    run_id: int | None = None,
    shelf: dict[str, Pack] | None = None,
    tenant: Any | None = None,
    review_overdue_by_regime: dict[str, Any] | None = None,
) -> Decision:
    """One determination, recorded.

    `shelf` is the set of packs in force, keyed by jurisdiction, resolved once
    by the caller. Passing it is how a bulk sweep stays *consistent*, not merely
    fast: without it every pair re-reads the shelf, and a version published
    halfway through a run would leave some of the book assessed under v4 and the
    rest under v5 — with a delta report nobody could interpret, because two
    different things changed at once. A sweep pins its shelf for the same reason
    it pins `as_of`.

    The speed is the secondary benefit and it is not small: the shelf is two
    queries and a pack parse, and at a hundred thousand pairs that is two
    hundred thousand queries nobody needs.
    """
    as_of = as_of or business_time.business_today(session)
    clients = DbClientProvider(session)
    positions = FixturePositionsProvider()

    client = clients.get(client_id)
    asset = session.get(Asset, asset_id)
    if asset is None:
        raise KeyError(f"unknown asset {asset_id!r}")

    licensee = client.get("jurisdiction") or DEFAULT_JURISDICTION
    in_force = shelf if shelf is not None else packs_repo.active_all(session, as_of)
    governing = in_force.get(licensee)
    if governing is None:
        # A caller-supplied shelf that does not cover this client's regime is a
        # mistake worth naming rather than papering over with a fresh read: it
        # means the sweep was planned for regimes that do not match its book.
        governing = packs_repo.active(session, licensee, as_of)

    asset_ref = {"id": asset.id, "symbol": asset.symbol, "name": asset.name}
    amount = (
        amount_cents if amount_cents is not None else client["default_trade_amount_cents"]
    )
    common: dict[str, Any] = dict(
        client=client,
        positions=positions.get(client_id, as_of),
        asset=asset_ref,
        amount_cents=amount,
        as_of=as_of,
        licensee_jurisdiction=licensee,
    )

    # Built twice on purpose. Which regimes apply is derived from the snapshot
    # rather than from the client record, so that replay derives the same set
    # from the same frozen facts. The first build establishes those facts; the
    # second adds each applicable pack's own asset classification.
    probe = build_snapshot(pack=governing, **common)
    applicable, _unmatched = select_packs(probe, in_force)
    snapshot = build_snapshot(pack=governing, also_classified_by=applicable, **common)

    others = [p for p in applicable if p.pack_id != governing.pack_id]
    evaluation = evaluate_snapshot(governing, snapshot)

    resolution: dict | None = None
    outcome = evaluation["outcome"]
    recorded_others: dict[str, dict] = {}

    if others:
        evaluations = [(governing, evaluation)]
        for other in others:
            other_eval = evaluate_snapshot(other, view_for(snapshot, other))
            evaluations.append((other, other_eval))
            recorded_others[other.pack_id] = {
                "pack_version": other.version,
                "content_status": other.content_status,
                "results": other_eval["rule_results"],
                "not_applicable": other_eval["rules_not_applicable"],
            }
        # Selection provenance is produced inside the resolver, not bolted on
        # here: replay rebuilds the resolution from the snapshot and the packs
        # of record, and anything this layer added afterwards would fail to
        # reproduce.
        resolution = resolve_across(
            snapshot=snapshot, evaluations=evaluations, governing=governing
        )
        outcome = resolution["outcome"]

    # FP3-17. A determination made while this firm's review window is open past
    # its close says so on its face.
    #
    # Added here rather than in `build_snapshot`, which lives in the engine and
    # must stay pure — the overdue state is a database read about a tenant, and
    # an engine that consulted one would break invariant 2.
    #
    # Additive by construction. Every determination already on file has no such
    # key, `evaluate_snapshot` reads only the paths a pack names, and the DSL's
    # `_walk` cannot see a field nothing asks for — so replay of every stored
    # decision is untouched. Verified rather than argued: `make nightly-replay`
    # over the seeded book after this change, no mismatches.
    #
    # Absent rather than null on an ordinary determination, so the snapshot of
    # the overwhelming majority is unchanged in shape as well as in value.
    # Resolved once per chunk by the caller, like `shelf`, and for the same two
    # reasons. The cheap one is that a bulk sweep of ten thousand pairs must not
    # run ten thousand identical queries — `test_a_sweep_does_not_re_read_the_
    # shelf_for_every_pair` caught this at 7.7 queries per pair against a budget
    # of 7, which is the test doing exactly its job.
    #
    # The one that matters is consistency: a window closing halfway through a
    # run would leave some of the book carrying the field and the rest not, and
    # a delta report cannot be read when two things changed at once.
    #
    # Keyed per regime, because the governing pack is not known until the
    # snapshot has been built — so the caller passes the whole map and this
    # picks. `None` for the map means "look it up", which is what every
    # single-determination caller wants.
    if review_overdue_by_regime is None:
        review_overdue = advance.overdue_for_snapshot(
            session, jurisdiction=governing.pack_id
        )
    else:
        review_overdue = review_overdue_by_regime.get(governing.pack_id)
    if review_overdue is not None:
        snapshot = {**snapshot, "pack_review_overdue": review_overdue}

    decision = evidence.record(
        session,
        client_id=client_id,
        asset_id=asset_id,
        as_of=as_of,
        pack_id=governing.pack_id,
        pack_version=governing.version,
        snapshot=snapshot,
        evaluation=evaluation,
        others=recorded_others or None,
        resolution=resolution,
        outcome=outcome,
        run_id=run_id,
        # What ran, on what content. Built here rather than inside `record`
        # because this is the only place that holds the actual `Pack` objects
        # the evaluation used — `record` is given their version numbers, which
        # is precisely the identification Q-04 found insufficient.
        execution_manifest=manifest.build(
            governing=governing, others=others, snapshot=snapshot
        ),
    )
    audit(session, "decision.evaluate", f"decision:{decision.id}")
    # §S10: in shadow, a determination is computed and recorded in full and has
    # no effect in the world. That promise is kept *here*, at the one place
    # every outbound consequence leaves from, rather than at each of them — a
    # firm's trust in shadow mode should not depend on somebody remembering to
    # check the stage in the next feature that notifies anybody.
    #
    # Recorded in full, deliberately. The determination, its snapshot and its
    # place in the chain are exactly what they would be live, because the whole
    # value of shadow is that what it produces is what going live would have
    # produced.
    effect = adoption.may_act(
        session,
        client_scenario=client.get("scenario"),
        asset_id=asset_id,
        tenant=tenant,
    )
    if not effect.allowed:
        audit(
            session,
            "decision.not_sent",
            f"decision:{decision.id} — {effect.reason}",
        )
        return decision

    # A sweep is one event, not a hundred thousand.
    #
    # A bulk re-check that notified per determination would put a webhook storm
    # through a customer's case system for something they asked for as a single
    # act, and would fill the internal referral queue with two hundred items
    # that are all the same news. What a sweep produces instead is a delta
    # report — every outcome that moved, with the rule that moved it — and one
    # completion event carrying the counts. That is the form the change is
    # actually reviewed in, and Stage 5's pinned-tenant UAT flow reads the same
    # list.
    #
    # The audit row above is written either way. What was done is never
    # optional, however it was asked for.
    if run_id is not None:
        return decision

    _tell_the_customers_systems(
        session,
        "decision.recorded",
        f"decision:{decision.id}",
        {
            "decision_id": decision.id,
            "client_id": client_id,
            "asset_id": asset_id,
            "as_of": as_of.isoformat(),
            "outcome": decision.outcome,
            "pack_id": governing.pack_id,
            "pack_version": governing.version,
        },
    )

    if decision.outcome == "REFER":
        AuditQueueSink(session).notify(
            "refer", f"decision:{decision.id}", {"client_id": client_id}
        )
        # A separate event from `decision.recorded`, deliberately. A firm routes
        # determinations to one place and things needing a person to another, and
        # making them filter one stream by outcome would be handing them our
        # schema to work around.
        _tell_the_customers_systems(
            session,
            "queue.referred",
            f"decision:{decision.id}",
            {
                "decision_id": decision.id,
                "client_id": client_id,
                "reason_codes": sorted(
                    r["reason_code"]
                    for r in evaluation["rule_results"]
                    if not r["passed"] and r["reason_code"]
                ),
            },
        )

    return decision


def _other_packs(session: Session, decision: Decision) -> dict[str, Pack]:
    """The non-governing packs a decision was resolved against, at their versions.

    Read back by version rather than by "what is in force now", because the
    thing being reproduced is the determination that was made, not the one that
    would be made today.
    """
    stored = (decision.rule_results or {}).get("other_jurisdictions") or {}
    return {
        code: packs_repo.by_version(session, code, entry["pack_version"])
        for code, entry in stored.items()
    }


def _per_jurisdiction(session: Session, decision: Decision, governing: Pack) -> list[dict]:
    """Each regime that touched this decision, and what it said on its own.

    "What would have happened under each regime alone" is the question the
    cross-border panel exists to answer, and answering it with an outcome word
    alone would be a worse answer than none: a reader needs the findings behind
    it. So each entry carries that regime's own failing rules, rendered through
    that regime's own reason codes.

    Every pack is read back at its version of record, and every label — the name
    of the regime, the regulator that writes for it — comes from pack content.
    None of it is hashed: this is how the record is displayed, not what it says.
    """
    stored = (decision.rule_results or {}).get("other_jurisdictions") or {}
    resolution = decision.resolution or {}
    outcomes = resolution.get("outcome_by_jurisdiction", {})

    evaluations: list[tuple[Pack, dict]] = [
        (
            governing,
            {
                "outcome": outcomes.get(governing.pack_id, decision.outcome),
                "rule_results": decision.rule_results["results"],
                "rules_not_applicable": decision.rule_results.get("not_applicable", []),
            },
        )
    ]
    for code, entry in stored.items():
        other = packs_repo.by_version(session, code, entry["pack_version"])
        evaluations.append(
            (
                other,
                {
                    "outcome": outcomes.get(code, ""),
                    "rule_results": entry["results"],
                    "rules_not_applicable": entry.get("not_applicable", []),
                },
            )
        )

    basis = {j["jurisdiction"]: j for j in resolution.get("applicable", [])}
    return [
        {
            "jurisdiction": p.pack_id,
            "name": p.jurisdiction_name,
            "regulator": p.regulator,
            "pack_version": p.version,
            "content_status": p.content_status,
            "signed_by": p.signed_by,
            "covers_states": p.covers_states,
            "governing": p is governing,
            "basis": basis.get(p.pack_id, {}).get("basis", []),
            "outcome": e["outcome"],
            "reasons": failing_reasons(e, p),
        }
        for p, e in evaluations
    ]


def _resolved_reasons(jurisdictions: list[dict]) -> list[dict]:
    """Why the determination came out as it did, across every regime.

    A cross-border BLOCK is very often a BLOCK that the governing regime would
    not have reached. Taking the reasons from the governing pack alone produced
    the worst screen this system could show: a red BLOCK banner above a green
    panel reading "every applicable rule passed" — true of that one pack, and a
    lie about the determination it sits under.

    So the findings are the union across regimes. Each carries the code and
    version of the pack that raised it, because "which regulator says so" is
    the first question anyone asks of a finding, and worst-first ordering is
    shared rather than re-decided per pack.
    """
    reasons: list[dict] = []
    for entry in jurisdictions:
        for reason in entry["reasons"]:
            reasons.append(
                {
                    **reason,
                    "jurisdiction": entry["jurisdiction"],
                    "jurisdiction_name": entry["name"],
                    "pack_version": entry["pack_version"],
                }
            )
    return sorted(
        reasons,
        key=lambda r: (
            -outcome_rank(r["outcome"]),
            r["severity"],
            r["jurisdiction"],
            r["rule_id"],
        ),
    )


def _applicability(decision: Decision, pack: Pack) -> list[dict]:
    """Why each of the pack's rules was in or out of this determination.

    Recomputed from the frozen snapshot rather than read back, and that is what
    makes it safe to add: nothing about the stored decision changes, so no
    determination on file stops reproducing. A pack that no longer loads is
    reported as no answer rather than as a crash — this is presentation, and a
    reason card must not be the thing that takes a decision page down.
    """
    try:
        return list(evaluate_snapshot(pack, decision.snapshot).get("applicability", []))
    except PackError:
        return []


def decision_view(session: Session, decision: Decision, pack: Pack | None = None) -> dict:
    pack = pack or packs_repo.by_version(
        session, _governing_pack_id(decision), decision.pack_version
    )
    evaluation = {
        "outcome": decision.outcome,
        "rule_results": decision.rule_results["results"],
        "rules_not_applicable": decision.rule_results.get("not_applicable", []),
        "pack_version": decision.pack_version,
    }
    override = session.scalars(
        select(Override).where(Override.decision_id == decision.id).order_by(Override.id.desc())
    ).first()

    jurisdictions = _per_jurisdiction(session, decision, pack)

    return {
        "id": decision.id,
        "client_id": decision.client_id,
        "client_name": decision.snapshot["client"]["name"],
        "asset_id": decision.asset_id,
        "asset_symbol": decision.snapshot["asset"]["symbol"],
        "as_of": decision.as_of.isoformat(),
        "outcome": decision.outcome,
        "pack_id": pack.pack_id,
        "pack_version": decision.pack_version,
        "pack_effective_from": pack.effective_from.isoformat(),
        "pack_signed_by": pack.signed_by,
        # Beside the signatory, because "who signed this" and "who wrote this"
        # are two questions and an artefact answering only the first leaves the
        # separation §3.2 requires unevidenced on the document a compliance
        # officer actually reads.
        "pack_drafted_by": pack.drafted_by,
        "pack_second_reviewer": pack.second_reviewer,
        "pack_content_status": pack.content_status,
        "pack_covers_states": pack.covers_states,
        "pack_jurisdiction_name": pack.jurisdiction_name,
        "pack_regulator": pack.regulator,
        # The badge is driven from the pack the decision was actually made
        # under, read back at that version — not from the pack in force now,
        # and not from anything the caller can pass in.
        "illustrative": pack.is_illustrative,
        "illustrative_jurisdictions": (decision.resolution or {}).get("illustrative", [])
        or ([pack.pack_id] if pack.is_illustrative else []),
        "resolution": decision.resolution,
        "cross_border": bool(decision.resolution),
        # Presentation of the record, not part of it: names and per-regime
        # findings are assembled here rather than stored, because a pack that
        # renamed its regulator would otherwise change a hash that has to stay
        # fixed for as long as the decision does.
        "jurisdictions": jurisdictions,
        "snapshot": decision.snapshot,
        # One regime, one source of findings. More than one, and the findings
        # are everything every applicable regime found — see `_resolved_reasons`.
        "reasons": (
            _resolved_reasons(jurisdictions)
            if decision.resolution
            else failing_reasons(evaluation, pack)
        ),
        "rule_results": decision.rule_results["results"],
        "rules_not_applicable": decision.rule_results.get("not_applicable", []),
        # F10. Why each rule was in or out, recomputed from the frozen snapshot
        # under the pack of record rather than read back from the decision row.
        #
        # `rules_not_applicable` answers *which* rules said nothing and this
        # answers *why*, which is the question somebody actually has when a
        # determination is an ALLOW that no rule produced —
        # `worst_of(..., default=ALLOW)` means an asset class no rule names
        # passes silently, and the first thing to establish is which rules were
        # even consulted.
        #
        # Recomputed rather than stored: widening the stored shape would make
        # every determination on file fail to reproduce. Safe because the
        # snapshot is frozen, so the same facts give the same answer.
        "applicability": _applicability(decision, pack),
        "prev_hash": decision.prev_hash,
        # Whether this is the first decision in the tenant's chain. Sent rather
        # than inferred, because since Stage 1 a chain starts at the tenant's
        # recorded anchor and not at a constant the client could recognise.
        "is_genesis": decision.prev_hash == evidence.anchor_hash(session),
        "this_hash": decision.this_hash,
        "created_at": decision.created_at.isoformat(),
        "override": (
            {
                "justification": override.justification,
                "approver": override.approver,
                "created_at": override.created_at.isoformat(),
            }
            if override
            else None
        ),
    }


def replay(session: Session, decision: Decision) -> dict:
    pack = packs_repo.by_version(
        session, _governing_pack_id(decision), decision.pack_version
    )
    result = evidence.replay(decision, pack, _other_packs(session, decision))
    result["chain"] = evidence.verify_chain(session)
    audit(session, "decision.replay", f"decision:{decision.id}")
    return result


class SelfApproval(PermissionError):
    """The person overruling a determination is the person who ran it.

    The two-person rule a regulator expects of an override, expressed where the
    row is written rather than at the endpoint, so that no second write path can
    be added later that skips it.
    """

    def __init__(self, decision_id: int):
        super().__init__(
            f"decision {decision_id} was run by you, and an override is somebody "
            "else's judgement that it was wrong. Ask a second approver. Nothing "
            "has been recorded."
        )


def override(
    session: Session,
    decision: Decision,
    *,
    justification: str,
    approver: str,
) -> Override:
    acting = tenancy.current_user_or_none()
    # A missing principal is a refusal, not a pass.
    #
    # This read `if acting is not None and ...`, so a caller with nobody in
    # scope skipped the check entirely. Nothing reaches that state through the
    # API — the middleware always binds one — and "nothing reaches it today" is
    # the wrong thing to rest the one rule that stops a person approving their
    # own work on. An override nobody can be named for is not a second opinion.
    if acting is None or decision.decided_by == acting:
        raise SelfApproval(decision.id)

    row = Override(
        decision_id=decision.id, justification=justification.strip(), approver=approver
    )
    session.add(row)
    session.flush()
    audit(session, "decision.override", f"decision:{decision.id}")
    _tell_the_customers_systems(
        session,
        "decision.overridden",
        f"decision:{decision.id}",
        {
            "decision_id": decision.id,
            "approver": approver,
            "justification": justification,
            "original_outcome": decision.outcome,
        },
    )
    AuditQueueSink(session).notify(
        "override", f"decision:{decision.id}", {"approver": approver}
    )
    return row
