"""Paging the specialist who owns a source that has stopped answering.

§S6: "a source unreachable for three consecutive checks pages the specialist
owner". The counting lives in `watch.sources` — the watch package may not import
the service layer, and must not, since the guard that keeps a gazette reader out
of the evaluator is the same guard. This module is the other side of that line:
it reads the breaches watch computed and does the things only core-api can do —
write an audit row, tell subscribed tenants, and hand a caller something to
print.

**A page names a person, an outage and a reason.** "au-asic-media has failed 3
consecutive checks (HTTP 503 from asic.gov.au) — owner: fiona.reid@quolin.com"
is a message somebody can act on at 7am. An alert that says a source is
unhealthy is one they have to go and investigate before they can even decide
whether it is theirs.

**It pages once per outage, and stays loud in every other way.** `alerted_at`
stops the same breach re-paging on every sweep, because an alert that arrives
every ten minutes is one that gets filtered into a folder nobody opens. The
breach itself keeps showing on the currency screen and keeps the sweep's exit
code non-zero for as long as it lasts — silence after the first page is how an
outage gets forgotten, and that is a different mistake from paging twice.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import service, tenancy
from .models import SourceBreach, SourceBreachNotice, Tenant
from .watch import sources


def _now() -> datetime:
    return datetime.now(timezone.utc)


def describe(row: Any) -> str:
    """One line, written for the person woken up by it."""
    owner = row.owner or "nobody — this source names no owner in pack content"
    return (
        f"{row.id} ({row.jurisdiction}) has failed {row.consecutive_failures} "
        f"consecutive checks: {row.last_error or 'no reason recorded'}. "
        f"Owner: {owner}."
    )


def page(session: Session, *, now: datetime | None = None) -> list[dict[str, Any]]:
    """Page the owner of every source newly in breach. Returns what was sent.

    Writes an audit row, so the caller must have an acting user in scope —
    `tenancy.acting_as_user("schedule")` for a sweep, the signed-in officer for
    the endpoint. An unattributed audit row is refused at the service layer,
    which is Stage 2 working as intended rather than an obstacle.

    Newly, per `alerted_at`. The full list of breaching sources is what a screen
    shows; this is what a sweep sends, and re-sending on every tick would train
    the recipient to ignore it.
    """
    now = now or _now()
    sent: list[dict[str, Any]] = []
    for row in sources.breaches(session, unalerted_only=True):
        message = describe(row)
        service.audit(session, "watch.source.unreachable", message)
        sources.mark_alerted(session, row.id, now)
        sent.append(
            {
                "source_id": row.id,
                "jurisdiction": row.jurisdiction,
                "owner": row.owner,
                "consecutive_failures": row.consecutive_failures,
                "reason": row.last_error,
                "message": message,
            }
        )
    session.flush()
    return sent


def open_breaches(session: Session) -> list[dict[str, Any]]:
    """Every source currently in breach, paged or not.

    Separate from `page` because they answer different questions: that one asks
    "who needs telling right now", this one asks "what is broken" — and an
    outage somebody was told about on Monday is still broken on Wednesday.
    """
    return [
        {
            "source_id": row.id,
            "jurisdiction": row.jurisdiction,
            "name": row.name,
            "owner": row.owner,
            "consecutive_failures": row.consecutive_failures,
            "alert_after_failures": row.alert_after_failures,
            "reason": row.last_error,
            "last_failed_at": (
                row.last_failed_at.isoformat() if row.last_failed_at else None
            ),
            "last_checked_at": (
                row.last_checked_at.isoformat() if row.last_checked_at else None
            ),
            "alerted_at": row.alerted_at.isoformat() if row.alerted_at else None,
        }
        for row in sources.breaches(session)
    ]


def record_breaches(session: Session, breaches: list[dict[str, Any]]) -> int:
    """Write down what the sweep saw, with the credential the sweep has.

    FP3-03. This is the whole of the watch task's part in `source.stale`. It
    does not enumerate tenants, does not open a second engine and does not send
    anything — all three of which the previous version did, and none of which
    the watch ECS task holds a credential for.

    A row per breach per sweep. Not deduplicated here on purpose: two sweeps
    seeing the same outage is two observations of it, and "how long was this
    dark" is answered by reading them. The fan-out deduplicates at the point
    that matters, which is per tenant.
    """
    if not breaches:
        return 0

    written = 0
    for breach in breaches:
        session.add(
            SourceBreach(
                source_id=str(breach["source_id"]),
                jurisdiction=str(breach["jurisdiction"]),
                detail=breach,
            )
        )
        written += 1
    session.flush()
    return written


def pending_breaches(session: Session, tenant_id: str) -> list[SourceBreach]:
    """Breaches this tenant has not been told about yet.

    The idempotency, asked as a query. `source_breach_notices` carries one row
    per (breach, tenant), so a second run of the worker selects nothing and
    sends nothing — rather than the worker having to remember where it got to,
    which is state that goes wrong the first time two of them run at once.
    """
    told = select(SourceBreachNotice.breach_id).where(
        SourceBreachNotice.tenant_id == tenant_id
    )
    return list(
        session.scalars(
            select(SourceBreach)
            .where(SourceBreach.id.not_in(told))
            .order_by(SourceBreach.id)
        )
    )


def fan_out(session: Session, tenant_id: str) -> int:
    """Tell one tenant about the breaches in its regimes that it has not heard.

    Runs as the application role, inside that tenant's transaction, from a
    worker that already holds `APP_DATABASE_URL`. That is the credential
    enqueueing a webhook needs and the one the watch task must never have.

    A notice row is written for every pending breach, including the ones this
    tenant is not in the regime for. "Told" and "decided not to tell" are both
    answers, and leaving the second one unrecorded would make the worker
    reconsider every out-of-regime breach on every run for ever.
    """
    tenant = session.get(Tenant, tenant_id)
    regimes = regimes_for(tenant)
    sent = 0

    for breach in pending_breaches(session, tenant_id):
        if regimes is None or breach.jurisdiction in regimes:
            service._tell_the_customers_systems(
                session,
                event="source.stale",
                subject=f"source:{breach.source_id}",
                payload=dict(breach.detail),
            )
            sent += 1
        session.add(SourceBreachNotice(breach_id=breach.id, tenant_id=tenant_id))

    session.flush()
    return sent


def notify_tenants(tenant_ids: list[str], breaches: list[dict[str, Any]]) -> int:
    """Tell each tenant about breaches in a regime they are actually in.

    Two deliberate shapes.

    **A session per tenant.** `app.tenant_id` binds when a transaction *begins*,
    so a single session reused across the loop would enqueue the second tenant's
    webhooks inside the first tenant's transaction — one customer's endpoint
    receiving another customer's notification. That bug was written once already,
    in the access review, and caught by reading the output; it is not being
    written twice.

    **Scoped to their regimes.** A firm licensed only in AU has no interest in
    an ESMA feed being down, and telling them anyway is how a customer learns to
    ignore our alerts. `source.stale` has been a declared event with no producer
    since the integrations stage — this is what produces it.
    """
    from .db import SessionLocal

    if not breaches:
        return 0

    sent = 0
    for tenant_id in tenant_ids:
        with tenancy.acting_as(tenant_id):
            session = SessionLocal()
            try:
                tenant = session.get(Tenant, tenant_id)
                regimes = regimes_for(tenant)
                mine = [
                    b
                    for b in breaches
                    if regimes is None or b["jurisdiction"] in regimes
                ]
                for breach in mine:
                    service._tell_the_customers_systems(
                        session,
                        event="source.stale",
                        subject=f"source:{breach['source_id']}",
                        payload=breach,
                    )
                    sent += 1
                session.commit()
            finally:
                session.close()
    return sent


def regimes_for(tenant: Tenant | None) -> set[str] | None:
    """Which regimes a tenant is in, or None for "all of them".

    None rather than the full set, because "this customer has not told us which
    regimes they operate in" and "this customer operates in all four" are
    different facts, and only the second should be inferred from a config file
    that says so.
    """
    config = (tenant.config if tenant is not None else None) or {}
    declared = config.get("jurisdictions")
    if not declared:
        return None
    return {str(j).upper() for j in declared}


# `all_tenant_ids` was here, and B2 is why it is not.
#
# It was a pure delegation to `app.owner_only`, left behind when FP3-03 moved
# the enumeration out of the watch sweep so a caller finding it would be sent to
# where the behaviour lives. Nothing called it afterwards: every worker
# enumerates through `maintenance.active_tenant_ids` on the owner session it
# opens itself, in `scripts/`, which is not the request path.
#
# What it was, though, is a request-path module holding an owner-privileged
# callable — `from app import source_alerts; source_alerts.all_tenant_ids()`
# reaches the schema owner and names none of the three connection identifiers
# the guard used to key on. That is the shape of the bypass both follow-up
# audits reported, sitting in the tree ready-made. Deleted rather than
# allowlisted: the guard now forbids importing `app.owner_only` from anything a
# request can reach, and a door nobody uses is one fewer door.
