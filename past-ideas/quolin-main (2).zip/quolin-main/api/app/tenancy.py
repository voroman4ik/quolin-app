"""Which customer the current unit of work belongs to.

One value, held in a context variable, and everything tenant-related reads it:
the default on every `tenant_id` column, and (from the RLS work) the
`app.tenant_id` Postgres setting that every policy filters on.

**Why a context variable rather than a parameter.** The alternative is to thread
a tenant id through every function that writes a row — `evaluate`, `record`,
`render`, `audit`, and everything they call. That works right up until somebody
adds an eleventh write site and forgets, at which point the failure is not a
crash but a row filed under the wrong customer. A default that reads ambient
state cannot be forgotten, because there is nothing to remember.

It is a `ContextVar` and not a module global for the reason context variables
exist: FastAPI runs endpoints in a thread pool and background work in tasks, and
a global would let one request's tenant leak into another's.

**Unset is an error, not a default.** `current_tenant()` raises rather than
falling back to anything. A fallback tenant is how the first cross-tenant write
happens — it turns "nobody said who this belongs to" from a bug into a silent
filing decision. The database says the same thing independently: `tenant_id` is
NOT NULL, and the RLS policy's WITH CHECK refuses an insert naming a tenant the
connection is not set to.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar

_current: ContextVar[str | None] = ContextVar("quolin_tenant", default=None)


def configured_tenant() -> str:
    """The customer this deployment serves.

    One deployment, one tenant, still. Identity is per-person now, but a
    person's *tenant* is not read off their user record: `user_roles` is
    tenant-scoped, so what a grant says is which firms this person may act for,
    and a deployment pointed at one firm admits the people holding a grant in
    it. One session moving between firms is a tenant switcher, which is a
    different feature and is in docs/post-raise.md.

    Not validated. A wrong value here is not a security hole: `tenant_id` is a
    foreign key, so a tenant that does not exist fails the insert at login
    rather than signing anyone into anything.

    Also what the offline scripts use. `make tamper-demo` and `make watch-tick`
    are not requests and have no cookie to read a tenant from, so they name one
    the same way the deployment does.
    """
    return os.getenv("QUOLIN_TENANT", "demo")


class NoTenantInScope(RuntimeError):
    """Raised when something tried to write a tenant-scoped row anonymously."""


def current_tenant() -> str:
    tenant = _current.get()
    if tenant is None:
        raise NoTenantInScope(
            "No tenant is in scope. Every tenant-scoped write happens inside "
            "`with tenancy.acting_as(...)` — set from the authenticated session "
            "for a request, and explicitly by the seed and by scripts."
        )
    return tenant


def current_tenant_or_none() -> str | None:
    """For the places where absence is a legitimate answer.

    The database setting is one: a connection with no tenant in scope must be
    set to a value that matches nothing, rather than left at whatever the
    previous checkout of that pooled connection was.
    """
    return _current.get()


@contextmanager
def acting_as(tenant_id: str) -> Iterator[str]:
    """Scope a block of work to one customer.

    A context manager rather than a setter so the reset is not optional. On a
    pooled connection or a reused worker thread, a tenant that outlives its
    request is the next request's tenant.
    """
    token = _current.set(tenant_id)
    try:
        yield tenant_id
    finally:
        _current.reset(token)


# ------------------------------------------------------------ and which person --

#: The user this unit of work acts for, held the same way and for the same
#: reasons as the tenant above.
#:
#: It is a second variable rather than a field on the first because the two are
#: not always both known and are not always both set. Login resolves a person
#: before it knows their tenant; the seed and the offline scripts name a tenant
#: with no person behind them at all. Folding them into one value would mean
#: inventing a placeholder for whichever half is missing, and a placeholder user
#: id is exactly the thing an audit trail must never contain.
_current_user: ContextVar[str | None] = ContextVar("quolin_user", default=None)


def current_user_or_none() -> str | None:
    """The acting user, or None where there legitimately is not one.

    No raising variant, deliberately. A tenant-scoped write with no tenant is a
    bug; a write with no user is the seed, a migration or a scheduled poll, and
    those are real callers rather than mistakes. Where a person *is* required —
    recording a decision, approving an override, signing a pack — the
    requirement is expressed at that call site, which can say what it needs the
    person for.
    """
    return _current_user.get()


@contextmanager
def acting_as_user(user_id: str | None) -> Iterator[str | None]:
    """Scope a block of work to one person.

    Accepts None so that a caller holding an optional user does not have to
    branch around the context manager, which is how one of the branches ends up
    missing the scope entirely.
    """
    token = _current_user.set(user_id)
    try:
        yield user_id
    finally:
        _current_user.reset(token)
