"""Which roles may call which endpoint.

A table rather than a decorator on each route, for the reason `PUBLIC_PATHS`
gives about authentication: forgetting a decorator opens a hole silently,
whereas forgetting a table entry is caught. Here it is caught at import —
`check_every_route_is_classified` refuses to let the application start with a
route nobody has classified. An API that cannot say who may call one of its
endpoints must not serve it, which is the same stance `crypto.KeysNotConfigured`
takes about a missing key.

There is deliberately no ladder. `tenant_admin` does not inherit `operator`'s
permissions by sitting above it in `ROLES`, and no role inherits any other. A
ladder is how the person who administers the tenant quietly acquires the ability
to both run a check and approve the override on it, which is the separation the
next task exists to enforce. Every role that may reach an endpoint is named at
that endpoint.

Role-level only. Reaching `POST /watch/drafts/{draft_id}/sign` requires a
`pack_signatory` grant; whether it is a grant for *this draft's jurisdiction* is
the handler's question, because the table cannot see the draft.
"""

from __future__ import annotations

from .models import ROLES

#: Everyone who works inside a customer's firm.
STAFF = frozenset({"viewer", "operator", "approver", "pack_signatory", "tenant_admin"})

#: Staff plus Quolin's own support engineers. Used for the endpoints that answer
#: "is this deployment healthy" rather than "what does this firm hold".
DIAGNOSTIC = STAFF | {"quolin_support"}

#: Anyone with a session. Only ever the routes about your own session — reading
#: which browsers you are signed in on, and closing them.
ANY_SESSION = frozenset(ROLES)

#: (method, path template) -> the roles that may call it.
#:
#: `quolin_support` appears against almost nothing, and that is the intent: an
#: engineer here debugging a deployment has no business reading a customer's
#: client list. Support that genuinely needs to sees it by being granted a role
#: inside that tenant, time-boxed, which `roles_for` expires on its own and the
#: access review reports. A permanent back door that never appears in a review
#: is worse than a grant that does.
ROUTE_ROLES: dict[tuple[str, str], frozenset[str]] = {
    # FastAPI adds these; nobody here wrote them. They are kept behind a session
    # because they describe every path, parameter and schema in the system, and
    # they are open to every role because a description of the API is not a
    # customer record — anyone already inside has it by reading the network tab.
    ("GET", "/docs"): ANY_SESSION,
    ("GET", "/docs/oauth2-redirect"): ANY_SESSION,
    ("GET", "/redoc"): ANY_SESSION,
    ("GET", "/openapi.json"): ANY_SESSION,
    # Your own session.
    ("POST", "/auth/reauth"): ANY_SESSION,
    # Enrolling your own second factor is not a privilege — it is the one thing
    # a privileged session with no factor is allowed to do, and gating it behind
    # a role would lock those accounts out permanently.
    ("POST", "/auth/mfa/enrol"): ANY_SESSION,
    ("POST", "/auth/mfa/verify"): ANY_SESSION,
    # Seeing what we sent a firm's systems is operational, not privileged.
    # Attesting to a source is the same kind of statement as signing rule
    # content: a named person claiming what a regulator had published. The
    # handler additionally checks the grant names *this* source's jurisdiction,
    # which the route table cannot see.
    ("POST", "/currency/sources/{source_id}/verify"): frozenset({"pack_signatory"}),
    # FP3-16. Readable by staff, because "who says this source is current" is
    # the question the currency screen's badge is an answer to, and a badge
    # nobody can look behind is an opinion.
    ("GET", "/currency/sources/{source_id}/verifications"): STAFF,
    ("GET", "/webhooks/deliveries"): STAFF,
    # Putting a dead delivery back is a decision with a consequence at the
    # customer's end — a duplicate case in their queue if it was wrong — so it
    # sits with the roles that answer for that.
    ("POST", "/webhooks/deliveries/{delivery_id}/redeliver"): frozenset(
        {"operator", "tenant_admin"}
    ),
    ("GET", "/auth/sessions"): ANY_SESSION,
    ("POST", "/auth/revoke-all"): ANY_SESSION,
    # Reading the firm's work. Every role inside the firm can read; what
    # separates them is what they may cause to happen.
    ("GET", "/scenarios"): STAFF,
    ("GET", "/assets"): STAFF,
    ("GET", "/clients"): STAFF,
    ("GET", "/clients/{client_id}"): STAFF,
    ("GET", "/decisions"): STAFF,
    ("GET", "/decisions/{decision_id}"): STAFF,
    ("GET", "/artefacts/{artefact_id}/pdf"): STAFF,
    ("GET", "/reports/periods"): STAFF,
    ("GET", "/reports/preview"): STAFF,
    ("GET", "/audit/export"): STAFF,
    ("GET", "/packs"): STAFF,
    ("GET", "/packs/{jurisdiction}"): STAFF,
    ("GET", "/queue"): STAFF,
    ("GET", "/dashboard"): STAFF,
    ("GET", "/currency"): STAFF,
    ("GET", "/watch/events"): STAFF,
    # `quolin_operator` is added rather than substituted, for the reason
    # `GET /admin/users` gives below: it is not a firm role, and it is the role
    # that acts on this.
    #
    # Found by the attestation census, and it is a finding in its own right
    # rather than a convenience. `POST …/approve-publication` and
    # `POST …/publish` are held to `quolin_operator` alone, so the two people who
    # put rule content in front of every firm on the platform **could not read
    # the draft they were putting there** — a publisher holding no firm role got
    # 403 from this route and 200 from the one that publishes. They were pressing
    # a button on a draft id.
    #
    # It is also what makes their binding satisfiable at all: both routes now
    # require the hash of the body the approver was shown, and
    # `current_content_hash` is emitted here and nowhere else.
    ("GET", "/watch/drafts"): STAFF | {"quolin_operator"},
    ("GET", "/watch/drafts/{draft_id}"): STAFF | {"quolin_operator"},
    # Reproducing a decision writes no new decision — it proves an old one still
    # comes out the same. Every role may, because a reproduction nobody but an
    # operator can run is not evidence anyone can check.
    ("POST", "/decisions/{decision_id}/replay"): STAFF,
    # Not client data, and the two endpoints support is most likely to need.
    ("GET", "/integrations"): DIAGNOSTIC,
    ("GET", "/evidence/verify"): DIAGNOSTIC,
    # Doing the work. `tenant_admin` is absent throughout, and that is the point
    # of having no ladder: an administrator who wants to run checks grants
    # themselves `operator`, and the access review then shows that they did.
    ("POST", "/evaluate"): frozenset({"operator"}),
    ("POST", "/artefacts/{kind}"): frozenset({"operator"}),
    ("POST", "/returns"): frozenset({"operator"}),
    ("POST", "/reports/overrides"): frozenset({"operator"}),
    # Overriding a decision the engine reached is the act a regulator looks at
    # first, so only `approver` reaches it. That the approver must not also be
    # the person who caused the decision is a second rule, enforced in the
    # handler, because this table cannot see who that was.
    ("POST", "/decisions/{decision_id}/override"): frozenset({"approver"}),
    # Bringing outside data in. Admin belongs here because an import is a
    # configuration act rather than a compliance judgement.
    ("POST", "/import/clients"): frozenset({"operator", "tenant_admin"}),
    ("POST", "/watch/poll"): frozenset({"operator", "tenant_admin"}),
    # The rule-change pipeline, and the one place the roles genuinely differ.
    ("POST", "/watch/events/{event_id}/triage"): frozenset({"operator", "approver"}),
    ("POST", "/watch/drafts"): frozenset({"operator", "approver"}),
    # Invariant 7: every live pack has a named human signatory. Signing and
    # publishing are split so that no one person can both attest to rule content
    # and put it live — the second of the two pairs the stage gate names.
    ("POST", "/watch/drafts/{draft_id}/sign"): frozenset({"pack_signatory"}),
    # The first of the two pairs, which had no route at all until the Gate A
    # audit: the person who *wrote* a rule change is not the person who attests
    # to it. Where a firm has one specialist for a regime and that separation
    # cannot be had, this is what stands in for it — an independent read by
    # another signatory, recorded before the signature rather than argued for
    # afterwards. Same role as signing, because it is the same competence.
    ("POST", "/watch/drafts/{draft_id}/second-review"): frozenset({"pack_signatory"}),
    # Q-12. `packs` is global: this route writes content every tenant reads, so
    # it is Quolin's act and not a customer administrator's. Everything before
    # it — drafting, editing, submitting, signing, rejecting — stays with the
    # firm, because proposing and reviewing a change to their own regime is
    # exactly what their specialists are for.
    ("POST", "/watch/drafts/{draft_id}/publish"): frozenset({"quolin_operator"}),
    # FP3-27. The second pair of eyes on the publication itself. Same role at
    # the door, and — like publish — the *act* is gated on a platform grant that
    # no tenant can confer. This table is about which role may reach the
    # endpoint; `platform_publishers` is about whether the account may do it.
    ("POST", "/watch/drafts/{draft_id}/approve-publication"): frozenset(
        {"quolin_operator"}
    ),
    ("POST", "/watch/drafts/{draft_id}/reject"): frozenset({"approver", "tenant_admin"}),
    # --- vendor change control --------------------------------------------
    #
    # Seeing what is staged is reading, and reading is open to the firm. Taking
    # or declining a version is not: it changes which rules govern their
    # determinations from that moment, which is the most consequential setting a
    # customer has. `approver` and `tenant_admin` only — an operator running
    # determinations should not be able to change the rules they run under.
    ("GET", "/advances"): STAFF,
    ("POST", "/advances/{advance_id}/take"): frozenset({"approver", "tenant_admin"}),
    ("POST", "/advances/{advance_id}/decline"): frozenset({"approver", "tenant_admin"}),
    # --- the workbench ----------------------------------------------------
    #
    # Authoring is an operator's job and reviewing is an approver's, so both
    # hold the editing routes. A `pack_signatory` holds them too, and that is
    # the case worth stating: a specialist engaged to author a jurisdiction's
    # content writes it themselves rather than dictating it to somebody who
    # cannot read the regulation. What the signatory still cannot do is publish
    # their own signature — that is `tenant_admin`, and it is the pair Stage 2
    # exists for.
    ("PATCH", "/watch/drafts/{draft_id}"): frozenset(
        {"operator", "approver", "pack_signatory"}
    ),
    ("POST", "/watch/drafts/{draft_id}/validate"): frozenset(
        {"operator", "approver", "pack_signatory"}
    ),
    ("POST", "/watch/drafts/{draft_id}/submit"): frozenset(
        {"operator", "approver", "pack_signatory"}
    ),
    # How a piece of rule content came to be is a reading, and reading is open
    # to the firm — the same principle `test_rbac.py` holds every other GET to.
    ("GET", "/watch/drafts/{draft_id}/history"): STAFF,
    # Which sources have stopped answering is reading, and the firm paying for
    # the monitoring is entitled to know it is not happening.
    ("GET", "/watch/alerts"): STAFF,
    # The same role that may generate one document may queue a hundred:
    # `POST /artefacts/{kind}` is `operator` and this is the bulk form of it,
    # not a different permission. Reading the queue is reading.
    ("POST", "/artefacts/batch"): frozenset({"operator"}),
    # Re-checking the book is the operator's act, the same as making one
    # determination — it produces evidence. Reading what it found is reading,
    # and the whole firm is entitled to it.
    # Where a firm is on the ladder is something the whole firm may read. Moving
    # it is the act that makes their determinations start affecting clients, so
    # it belongs to the person who can answer for that.
    ("GET", "/adoption"): STAFF,
    # Q-15. How a new pack version reaches this firm: on its effective date, or
    # staged behind a window they check it in. Readable by staff because it is
    # the answer to "will our rules change under us", and settable only by the
    # administrator, because it is a change-control decision rather than part of
    # the compliance work.
    # Provisioning. `quolin_operator` only — a customer's `tenant_admin` who
    # could grant roles could grant themselves the role that publishes rule
    # content to every tenant on the platform. They lose nothing: this replaces
    # a psql prompt, not a screen.
    # FP3-26. Readable by the whole firm, writable only by us.
    #
    # The first draft held the read to `quolin_operator` on the reasoning that
    # reading the roster and changing it are the same screen.
    # `test_reading_is_open_to_the_firm_and_writing_is_not` refused it, and the
    # test is right: the shape of this table is that every role inside a firm
    # can *see* the firm's work and what separates them is what they can make
    # happen. A firm's own staff directory — who holds what, granted by whom —
    # is the clearest possible case of that. It is also what makes the quarterly
    # access review something a customer can act on rather than a report they
    # receive from us, and it discloses nothing new: every one of these people
    # already appears by name on the decisions and audit events they made.
    #
    # `quolin_operator` is added rather than substituted because it is not a
    # firm role, and it is the role that administers this.
    ("GET", "/admin/users"): STAFF | {"quolin_operator"},
    ("POST", "/admin/users"): frozenset({"quolin_operator"}),
    ("POST", "/admin/users/{user_id}/roles"): frozenset({"quolin_operator"}),
    ("POST", "/admin/roles/{grant_id}/revoke"): frozenset({"quolin_operator"}),
    # FP3-13. Ending somebody's access is the same weight as granting it, so it
    # sits with the rest of provisioning and behind the same role.
    ("POST", "/admin/users/{user_id}/suspend"): frozenset({"quolin_operator"}),
    ("POST", "/admin/users/{user_id}/reinstate"): frozenset({"quolin_operator"}),
    ("GET", "/tenant/advance-policy"): STAFF,
    ("PATCH", "/tenant/advance-policy"): frozenset({"tenant_admin"}),
    ("POST", "/adoption"): frozenset({"tenant_admin"}),
    # Their own system's outcomes are their data; loading them is operational
    # work and reading the comparison is reading.
    ("POST", "/comparison/ingest"): frozenset({"operator", "tenant_admin"}),
    ("GET", "/comparison"): STAFF,
    ("POST", "/runs"): frozenset({"operator"}),
    ("GET", "/runs"): STAFF,
    ("GET", "/runs/{run_id}"): STAFF,
    ("GET", "/runs/{run_id}/deltas"): STAFF,
    ("GET", "/artefacts/jobs"): STAFF,
    # Reading, and the whole firm's business: a certificate that only some staff
    # could obtain would be one nobody thought to ask for.
    ("GET", "/audit/certificate"): STAFF,
    ("GET", "/artefacts/jobs/{job_id}"): STAFF,
    # Seeing what a document would look like is reading — and the person who
    # most needs it is the signatory deciding whether to put their name on it.
    ("GET", "/watch/drafts/{draft_id}/preview/{kind}"): STAFF,
    # --- the v1 API -------------------------------------------------------
    #
    # The same role names as the screens, and deliberately so: an integration is
    # not a fifth kind of principal with its own permission vocabulary, it is a
    # machine holding roles from this list. What differs is where the roles are
    # stored — a credential carries them on its own row rather than in
    # `user_roles`, because a grant is the firm's decision about a member of
    # staff and a credential is not one.
    #
    # Nothing here names `approver`, `pack_signatory` or `tenant_admin`. Those
    # cover acts a regulator wants a name against — approving an override,
    # signing rule content, granting a role — and an integration cannot be asked
    # why it did one. The access review reports a credential holding any of them
    # as its loudest finding; this table is why none of them would help it.
    ("POST", "/v1/clients"): frozenset({"operator", "tenant_admin"}),
    ("GET", "/v1/clients"): STAFF,
    ("POST", "/v1/evaluations"): frozenset({"operator"}),
    ("POST", "/v1/bulk"): frozenset({"operator"}),
    ("GET", "/v1/decisions"): STAFF,
    ("GET", "/v1/decisions/{decision_id}"): STAFF,
    # Replay reads and writes nothing but an audit row. A viewer may run it
    # because the whole point of the claim is that a customer can check it
    # themselves rather than take our word for it.
    ("POST", "/v1/decisions/{decision_id}/replay"): STAFF,
    ("GET", "/v1/artefacts/{artefact_id}"): STAFF,
    ("GET", "/v1/queue"): STAFF,
    # Operational rather than compliance data — what we tried to tell you, and
    # what your batch runs did. Readable by all staff like everything else: the
    # first draft of this table narrowed these two to operator and tenant_admin
    # on the reasoning of "who would want them", and `test_rbac.py` was right to
    # refuse it. Reading is open to the firm; what separates the roles is what
    # they can make happen.
    ("GET", "/v1/webhooks/deliveries"): STAFF,
    ("GET", "/v1/imports"): STAFF,
}


class UnclassifiedRoute(RuntimeError):
    """A route exists that the table does not mention.

    Raised at import, not on the request that hits it. A 403 at request time
    would mean the endpoint shipped, and the first person to find out it had no
    policy would be whoever called it.
    """


def check_every_route_is_classified(
    routes: list[tuple[str, str]], public: frozenset[str]
) -> None:
    """Fail unless each non-public route names the roles that may call it.

    Also fails on the reverse: an entry for a route that no longer exists. A
    stale line in a permissions table is how a reader comes to believe an
    endpoint is locked down when it was deleted years ago.
    """
    live = {(m, p) for m, p in routes if p not in public}
    unclassified = sorted(live - set(ROUTE_ROLES))
    if unclassified:
        raise UnclassifiedRoute(
            "these routes name no roles in app/rbac.py: "
            + ", ".join(f"{m} {p}" for m, p in unclassified)
        )
    stale = sorted(set(ROUTE_ROLES) - live)
    if stale:
        raise UnclassifiedRoute(
            "app/rbac.py names routes that do not exist: "
            + ", ".join(f"{m} {p}" for m, p in stale)
        )

    unknown = sorted(
        {r for allowed in ROUTE_ROLES.values() for r in allowed} - set(ROLES)
    )
    if unknown:
        raise UnclassifiedRoute(f"app/rbac.py names roles that do not exist: {unknown}")


def permitted(method: str, path: str, held: frozenset[str]) -> bool:
    """Does somebody holding `held` reach this endpoint?

    An unknown route is refused rather than allowed. It cannot happen — the
    import-time check would have stopped the application — but the fallback that
    a permissions function reaches for when it is confused should be "no".
    """
    return bool(held & ROUTE_ROLES.get((method, path), frozenset()))
