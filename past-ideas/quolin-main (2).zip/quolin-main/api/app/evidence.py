"""Append-only evidence store and replay.

**One chain per tenant.** Every decision's hash covers the previous decision's
hash, so the chain is a sequence, and a sequence has to belong to somebody. A
single global chain threading through every customer's records would leave each
customer holding a chain with links to hashes they have no row for — see
`migrations/versions/0004_chain_anchors.py` for why that is worse than it
sounds. Each tenant's chain therefore starts at its own recorded anchor, walks
only its own decisions, and carries the tenant id inside every hash.

That last part is belt and braces and worth being clear about. Per-tenant
ordering already catches a record moved between customers: dropped into the
middle of the receiving chain it breaks contiguity, appended at the end it
carries a `prev_hash` that names the wrong tip. Putting `tenant_id` in the
payload as well means the moved row's own hash is wrong too, so the break is
visible on the record itself rather than only in its neighbours — which is the
difference between "something here is wrong" and "this row is the one".
"""

from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Any, cast

from sqlalchemy import LargeBinary, func, literal_column, select, text
from sqlalchemy import event as sa_event
from sqlalchemy.orm import Session

from . import crypto
from . import manifest as manifest_mod
from .canonical import GENESIS, chain_hash
from .crypto import EncryptedJSON
from .engine import Pack, evaluate_snapshot, resolve_across, view_for
from .engine import validate as validate_pack
from .engine.crossborder import applicable_codes, match_packs
from .models import AuditEvent, ChainAnchor, Decision
from .tenancy import current_tenant


def genesis_hash(tenant_id: str, created_at: datetime) -> str:
    """The hash a tenant's chain begins at.

    `created_at` is in it deliberately: without a moment, a tenant deleted and
    recreated under the same slug would start a chain indistinguishable from
    the closed account's. Migration 0004 inlines this calculation — two keys
    and a sha256 — and `tests/test_chain_anchors.py` asserts the two agree.
    """
    return chain_hash(
        GENESIS, {"created_at": created_at.isoformat(), "tenant_id": tenant_id}
    )


def ensure_anchor(session: Session, tenant_id: str) -> ChainAnchor:
    """Give a tenant a chain start, if it does not have one. Idempotent.

    Called when a tenant is provisioned — by the seed today, by whatever
    replaces it later — and never lazily from a read path. An anchor that
    appears the first time somebody verifies a chain is an anchor whose value
    is whatever was convenient at that moment, which is the opposite of what it
    is for.
    """
    existing = session.get(ChainAnchor, tenant_id)
    if existing is not None:
        return existing
    created_at = datetime.now(timezone.utc)
    anchor = ChainAnchor(
        tenant_id=tenant_id,
        genesis_hash=genesis_hash(tenant_id, created_at),
        created_at=created_at,
    )
    session.add(anchor)
    session.flush()
    return anchor


class NoChainAnchor(RuntimeError):
    """This tenant has no recorded chain start.

    Raised rather than defaulted. Falling back to the old global constant would
    let a tenant whose provisioning half-finished write decisions onto a chain
    that starts where every other unprovisioned tenant's does — which is how
    two customers end up with chains that verify against each other's records.
    """


def anchor_hash(session: Session) -> str:
    tenant_id = current_tenant()
    anchor = session.get(ChainAnchor, tenant_id)
    if anchor is None:
        raise NoChainAnchor(
            f"Tenant {tenant_id!r} has no row in chain_anchors, so there is no "
            "start for its evidence chain. New tenants get one from "
            "`evidence.ensure_anchor`; a database migrated from before Stage 1 "
            "gets one from migration 0004 and then needs `make rechain`."
        )
    return anchor.genesis_hash


def _utc_isoformat(moment: datetime) -> str:
    """One instant, one string, whatever the connection's timezone happens to be.

    `created_at` is a `timestamptz`, and psycopg renders one into a Python
    datetime carrying the offset of the session's `TimeZone` setting. Nothing
    pinned that setting, so a chain written under UTC and verified under
    `Australia/Sydney` recomputed a different `isoformat()` for every row and
    reported `verified=False checked=0` — the first link failing, for every
    tenant, every chain. `docs/runbooks/` treats that as a security incident,
    and nothing in the report would have distinguished a pooler setting change
    from somebody editing a determination. Sydney is the primary region in
    `infra/`.

    Normalising rather than hashing something new — epoch microseconds, say — is
    what makes this safe to apply to evidence already on file. Every stored hash
    was computed from an aware UTC datetime, and `astimezone(utc)` on one of
    those is the identity, so not a single recorded hash moves.
    `tests/test_chain_is_timezone_independent.py` asserts that rather than
    assuming it.

    A naive datetime is read as UTC and said so explicitly. `astimezone` on a
    naive value assumes the *machine's* local zone, which would move the same
    defect from the database session to the host — a laptop in London and a
    container in Sydney hashing one row two ways. Everything this system writes
    is UTC-aware, so naive can only mean UTC.
    """
    if moment.tzinfo is None:
        return moment.replace(tzinfo=timezone.utc).isoformat()
    return moment.astimezone(timezone.utc).isoformat()


def _hashable(
    *,
    tenant_id: str,
    client_id: str,
    asset_id: str,
    as_of: date,
    pack_id: str | None,
    pack_version: int,
    snapshot: dict,
    rule_results: dict,
    resolution: dict | None,
    outcome: str,
    created_at: datetime,
    schema: int,
    execution_manifest: dict[str, Any] | None,
) -> dict:
    """The bytes a determination's chain hash is computed over.

    `schema` and `execution_manifest` are required rather than defaulted, and
    that is deliberate. A default would mean a caller that forgot got a silently
    wrong hash for a schema-2 row — which is exactly what happened to
    `scripts/tamper_demo.py`, whose only symptom was the alarming and untrue
    "the chain is already broken". A missed call site should be a TypeError.

    `schema` is what makes Q-04's manifest addable at all. This function is not
    only used to *write* a hash — it is used to recompute one when verifying the
    chain, from the columns of a row that may be years old. Adding a key
    unconditionally would therefore change the recomputed hash of every
    determination already on file and break the chain on rows nobody had
    touched: invariant 5, broken to improve provenance.

    So each row records which shape it was hashed under and this reproduces that
    shape. Schema 1 must never learn about the manifest, however tempting the
    tidier code would be; support for it is kept forever, for the same reason
    `engine/evaluate.py` keeps DSL v1 forever.
    """
    payload = {
        # First, and inside the hash rather than only in the row. See the
        # module note: it makes a re-filed record wrong on its own terms.
        "tenant_id": tenant_id,
        "client_id": client_id,
        "asset_id": asset_id,
        "as_of": as_of.isoformat(),
        "pack_id": pack_id,
        "pack_version": pack_version,
        "snapshot": snapshot,
        "rule_results": rule_results,
        # Inside the hash, not beside it. On a cross-border decision the
        # resolution is where the determination actually comes from — which
        # regime bound which constraint, and which pairs could not be ordered.
        # Leaving it out would leave the most contestable part of the record
        # unprotected by the chain.
        "resolution": resolution,
        "outcome": outcome,
        # Normalised, not merely serialised. See `_utc_isoformat`: the offset
        # this renders with is a property of the connection, not of the record.
        "created_at": _utc_isoformat(created_at),
    }
    if schema >= 2:
        # Inside the hash rather than beside it. A manifest a later writer could
        # change would attest to nothing — the whole point is that "this ran on
        # that content" is as tamper-evident as the determination itself.
        payload["manifest"] = execution_manifest
    return payload


#: What a replay reports when the pack of record will not load.
#:
#: A distinct outcome rather than a rule-outcome mismatch, because the two mean
#: entirely different things to somebody reading an alert at three in the
#: morning: one says chase down the pack, the other says the evaluator has
#: changed its mind.
PACK_INVALID_AT_REPLAY = "PACK_INVALID_AT_REPLAY"


#: Per-`Session` scratch keys, cleared when the transaction ends. Both exist to
#: keep a per-row cost off a path that runs for every pair in a sweep.
_HELD_LOCKS = "quolin.chain.locks_held"
_PENDING_AUDIT_TIP = "quolin.chain.audit_tip"

#: Namespace for the advisory lock below, so a hash collision with some other
#: use of advisory locks in this database cannot deadlock two unrelated things.
_CHAIN_LOCK_NAMESPACE = 0x51554F4C  # "QUOL"


def _lock_chain(session: Session) -> None:
    """Take this tenant's chain, so two writers cannot append from one tip.

    §S13's second restore drill found the chain broken in the one tenant §S12's
    load test had driven concurrently: ten determinations sharing a single
    `prev_hash`, written within twenty milliseconds of each other. Each writer
    read the tip, computed a hash from it, and inserted. All ten were valid links
    from the same parent, and a chain with ten children is a tree.

    Nothing before this had ever written to one tenant's chain from two
    connections at once — a determination is made by a person, the demo has one
    firm, and the bulk sweep is one worker per tenant by construction. So every
    chain test that has ever run passed, and the guarantee the product is sold on
    would have failed the first afternoon two officers worked at the same time.

    **An advisory lock rather than a row lock, and the reason matters.** The
    obvious implementation is `SELECT … FOR UPDATE` on the tenant's anchor row.
    That requires `UPDATE` on `chain_anchors` — a table the application must
    never update, and whose grant was revoked on purpose. Buying serialisation
    by handing the application write access to the record of where each chain
    begins is a bad trade, and it is the kind that reads as reasonable in a
    diff.

    `pg_advisory_xact_lock` needs no table privilege, is scoped to the
    transaction, and releases on commit or rollback — including on a connection
    that dies, which a manually managed lock would not. Keyed on the tenant, so
    appends serialise within a firm and never between firms.

    A collision between two tenants' hashes would make them wait for each other
    occasionally, which is a performance detail and not a correctness one; the
    namespace keeps the collision surface to this use.
    """
    # Once per transaction, not once per row. The lock is transaction-scoped
    # and re-entrant, so taking it again is correct and costs a round trip —
    # and a bulk sweep writes a determination and an audit row for every pair
    # in one transaction, which made this the most-called statement in the
    # system.
    tenant_id = current_tenant()
    held = session.info.setdefault(_HELD_LOCKS, set())
    if tenant_id in held:
        return
    session.execute(
        text("SELECT pg_advisory_xact_lock(:namespace, hashtext(:tenant))"),
        {"namespace": _CHAIN_LOCK_NAMESPACE, "tenant": tenant_id},
    )
    held.add(tenant_id)


def _tip_hash(session: Session) -> str:
    """The last hash in *this tenant's* chain, or its anchor if it has none yet.

    The `tenant_id` filter is redundant against row-level security, which
    already confines this query. It is here anyway because the redundancy is
    the point: this is the query whose answer becomes the next record's
    `prev_hash`, and if it ever returned another customer's tip the two chains
    would be spliced together permanently and append-only would prevent the
    repair. A WHERE clause is cheap insurance against the day someone runs this
    from an owning connection or a maintenance script.
    """
    stmt = (
        select(Decision.this_hash)
        .where(Decision.tenant_id == current_tenant())
        .order_by(Decision.id.desc())
        .limit(1)
    )
    return session.scalars(stmt).first() or anchor_hash(session)


def record(
    session: Session,
    *,
    client_id: str,
    asset_id: str,
    as_of: date,
    pack_id: str | None = None,
    pack_version: int,
    snapshot: dict,
    evaluation: dict,
    others: dict[str, dict] | None = None,
    resolution: dict | None = None,
    outcome: str | None = None,
    created_at: datetime | None = None,
    run_id: int | None = None,
    execution_manifest: dict[str, Any] | None = None,
) -> Decision:
    created_at = created_at or datetime.now(timezone.utc)
    rule_results = {
        "results": evaluation["rule_results"],
        "not_applicable": evaluation["rules_not_applicable"],
    }
    if others:
        # Only present when a second regime actually applied. A single-
        # jurisdiction record keeps the shape it has always had, so nothing
        # downstream has to special-case the ordinary case.
        rule_results["other_jurisdictions"] = others

    outcome = outcome or evaluation["outcome"]
    # Named once and used for both the hash and the row, rather than letting
    # the column default fill the row while the payload reads the context var
    # separately. They would agree, but "would agree" is not a property; this
    # way there is one read and no way for them to diverge.
    tenant_id = current_tenant()
    # Taken before the tip is read, and held until commit. Reading the tip
    # without it is what let ten determinations share a parent.
    _lock_chain(session)
    prev_hash = _tip_hash(session)
    # Schema 2 for anything written from here on. A determination that recorded
    # no manifest would be one nobody can later prove was made on the content it
    # names, which is the whole of Q-04 — so the schema is not conditional on
    # whether a caller supplied one, and a caller that supplies nothing records
    # an explicit null rather than silently dropping to the old shape.
    schema = manifest_mod.CURRENT_PAYLOAD_SCHEMA
    payload = _hashable(
        tenant_id=tenant_id,
        client_id=client_id,
        asset_id=asset_id,
        as_of=as_of,
        pack_id=pack_id,
        pack_version=pack_version,
        snapshot=snapshot,
        rule_results=rule_results,
        resolution=resolution,
        outcome=outcome,
        created_at=created_at,
        schema=schema,
        execution_manifest=execution_manifest,
    )
    decision = Decision(
        tenant_id=tenant_id,
        client_id=client_id,
        asset_id=asset_id,
        as_of=as_of,
        pack_id=pack_id,
        pack_version=pack_version,
        snapshot=snapshot,
        rule_results=rule_results,
        resolution=resolution,
        outcome=outcome,
        prev_hash=prev_hash,
        this_hash=chain_hash(prev_hash, payload),
        created_at=created_at,
        # Set here rather than attached afterwards, and not by choice: UPDATE on
        # `decisions` is revoked, so a determination cannot be annotated once it
        # exists. That is the append-only guarantee working — the sweep a
        # determination belongs to is part of the record, not a label added
        # later — and it is why this argument exists at all.
        #
        # Deliberately *not* in `payload`, so it is outside the hash. The chain
        # attests to what was decided and from what; which sweep asked is
        # operational provenance, in the same category as the override that may
        # later be recorded against it.
        run_id=run_id,
        manifest=execution_manifest,
        payload_schema=schema,
    )
    session.add(decision)
    session.flush()
    return decision


#: The provenance lists on a rule result. Both are sets wearing a list's shape.
PROVENANCE_KEYS = ("inputs_read", "thresholds_used")


def _as_a_set(entries: Any) -> Any:
    """Provenance keyed by `(kind, ref, value)`, order discarded. FP3-20.

    `inputs_read` records what a rule consulted, and it is built by walking the
    predicate — so its order is the evaluator's traversal order, which is an
    implementation detail of `evaluate_condition` and not a claim about the
    determination. `_provenance` already deduplicates it, because "a predicate
    that names the same field in two branches of an `or` reads it twice" is
    noise; the ordering is the same kind of noise and was being compared exactly.

    What that meant: **any refactor that reorders resolution makes every
    determination on file fail to reproduce with the outcome unchanged** — and
    `docs/runbooks/` says to treat a replay mismatch as a possible tamper. A
    tidy-up inside the evaluator would have produced a platform-wide security
    incident with no security event in it.

    Compared as a set because that is the semantic claim: these are the values
    the rule read, not the order in which it happened to read them. The
    alternative the finding offers — freezing the walk order in the DSL spec
    with a corpus case — pins a fact nobody depends on and makes the evaluator
    harder to change for no gain in what anybody can verify.
    """
    if not isinstance(entries, list):
        return entries
    return sorted(
        (str(e.get("kind")), str(e.get("ref")), str(e.get("value")))
        if isinstance(e, dict)
        else (str(e), "", "")
        for e in entries
    )


def _order_independent(result: dict) -> dict:
    """One rule result with its provenance normalised."""
    return {
        key: (_as_a_set(value) if key in PROVENANCE_KEYS else value)
        for key, value in result.items()
    }


def _compare_results(label: str, stored: list[dict], fresh: list[dict]) -> list[dict]:
    if stored == fresh:
        return []
    stored_by_id = {r["rule_id"]: r for r in stored}
    fresh_by_id = {r["rule_id"]: r for r in fresh}

    def same(rule_id: str) -> bool:
        a, b = stored_by_id.get(rule_id), fresh_by_id.get(rule_id)
        if a is None or b is None:
            return a is b
        return _order_independent(a) == _order_independent(b)

    return [
        {
            "field": f"{label}{rule_id}",
            "stored": stored_by_id.get(rule_id),
            "replayed": fresh_by_id.get(rule_id),
        }
        for rule_id in sorted(set(stored_by_id) | set(fresh_by_id))
        if not same(rule_id)
    ]


def _compare_not_applicable(label: str, stored: dict, fresh: dict) -> list[dict]:
    """The half of the rule results replay was not reading. FP3-07.

    `evidence.record` stores two keys under `rule_results`: `results`, and
    `not_applicable` — the rules the pack contains that did not apply to this
    client. Replay compared the first and never read the second, so the F10
    entry's justification, "compared field-by-field by `evidence.replay`", was
    false about the very list it was arguing from.

    What that missed is a real class of change and not a cosmetic one. A rule
    whose applicability condition moves — a category added to its `applies_to`,
    a threshold that decides whether it is in scope — changes which rules ran
    without necessarily changing the outcome of the ones that did. Replay would
    reproduce the outcome, report no differences, and the determination on file
    would say a rule was out of scope while today's content says it is in.

    Compared as a **set**, not as a list. The stored value is built by walking
    the pack's rules in order, so a pack edit that reorders two rules neither of
    which changed would otherwise be reported as a replay mismatch — and the
    runbook says to treat a replay mismatch as tampering. Order here carries no
    meaning that ordering the pack differently would not also carry. (The same
    argument applies to `inputs_read`, which is FP3-20.)

    Absent on older rows, and absent is not a difference. `not_applicable` was
    added by F10; every determination made before it has no key, and replaying
    one must not manufacture a mismatch out of a field that did not exist when
    it was recorded.
    """
    if "not_applicable" not in stored:
        return []

    stored_set = {_rule_key(item) for item in (stored.get("not_applicable") or [])}
    fresh_set = {_rule_key(item) for item in (fresh.get("rules_not_applicable") or [])}
    if stored_set == fresh_set:
        return []
    return [
        {
            "field": f"rule.{label}not_applicable",
            "stored": sorted(stored_set - fresh_set),
            "replayed": sorted(fresh_set - stored_set),
        }
    ]


def _rule_key(item: Any) -> str:
    """One rule's identity, however the entry happens to be shaped.

    `rules_not_applicable` has held bare rule-id strings and dicts carrying a
    reason at different points in this codebase's life, and both are on file.
    """
    if isinstance(item, dict):
        return str(item.get("rule_id") or item.get("id") or sorted(item.items()))
    return str(item)


def _replay_order(
    snapshot: dict[str, Any],
    recorded: Any,
    available: dict[str, Pack],
) -> list[str]:
    """The order the determination resolved its other regimes in, re-derived.

    F3. `resolve_across` is order-sensitive by construction — `rules_not_applicable`,
    the `binding` and `evaluated_not_binding` lists inside each dimension, and
    every rationale sentence are built by walking the evaluations as they
    arrive. Recording walks `applicable_codes` order: licensee, then residency,
    then domicile, which is the order the regimes reached the client. Replay
    walked `sorted(...)`, which is alphabetical, and the two agree only by luck.

    They disagree the moment the residency code sorts after the domicile code. A
    Hong Kong-licensed client resident in Singapore and domiciled in Germany was
    recorded as `[SG, EU]` and replayed as `[EU, SG]`; the rebuilt resolution is
    then not the one on file, and `docs/runbooks/chain-mismatch.md` says to
    treat that as tampering.

    **Re-derived rather than read back.** The recorded `other_jurisdictions` is
    jsonb, and jsonb does not preserve object key order, so the order used on
    the day cannot be recovered from the record. It can be recomputed exactly,
    because it was a function of three facts that are frozen in the snapshot —
    and matched to packs the same way recording matched them, through
    `covers_states`, so the EU pack answers for a German domicile.

    **Anything recorded that the codes do not reach is appended, never
    dropped.** A regime whose pack has since gone missing still has to be
    reported as a difference rather than silently skipped, which is what makes
    a missing pack visible instead of quiet. Sorted, so the tail is
    deterministic even though its input is not.
    """
    ordered: list[str] = []
    matched, _unmatched = match_packs(applicable_codes(snapshot), available)
    for found in matched:
        if found.pack_id in recorded and found.pack_id not in ordered:
            ordered.append(found.pack_id)
    ordered.extend(sorted(code for code in recorded if code not in ordered))
    return ordered


def replay(decision: Decision, pack: Pack, others: dict[str, Pack] | None = None) -> dict:
    """Re-evaluate the stored snapshot under the stored pack versions.

    The result must equal what was stored, exactly.

    On a cross-border decision this re-runs every regime that applied and
    re-resolves them, because the determination came from the resolution and
    not from any one pack. Replaying only the governing pack would reproduce a
    number that was never the answer.

    **Provenance is reported separately from the rules.** Reading the wrong pack
    and the evaluator having changed its mind used to arrive as the same thing —
    a list of rule-level differences — and only one of those is a regression.
    Q-04: the decision committed to `pack_version`, an integer that nothing made
    unique, so replay could read different content under the same name and
    report it as a changed answer. The `provenance` block says what drifted;
    `differences` says what the rules did. A determination that reproduces
    perfectly under a different evaluator is not a failure, but it is not the
    archival guarantee either, and it now says so.
    """
    others = others or {}

    # The pack of record has to load before anything is compared against it.
    #
    # `packs` is append-only, so a stored body does not change on its own. What
    # changes is the engine around it — a calc removed, a snapshot field
    # renamed, a DSL version retired — and a pack authored against an engine
    # that had something this one does not is exactly the drift a nightly replay
    # exists to find. Reported as its own outcome rather than as a list of rule
    # differences: "the rules of record no longer load" and "the engine now says
    # something different" have different first moves, and an unclassified
    # exception would end a run that had a whole book left to check.
    faults = validate_pack(pack)
    for code, other in sorted(others.items()):
        faults.extend(f"{code}: {fault}" for fault in validate_pack(other))
    if faults:
        return {
            "match": False,
            "outcome_code": PACK_INVALID_AT_REPLAY,
            "pack_valid": False,
            "pack_faults": faults,
            "provenance": manifest_mod.check(
                decision.manifest, governing=pack, others=others, snapshot=decision.snapshot
            ),
            "pack_version": pack.version,
            "pack_id": pack.pack_id,
            "jurisdictions_replayed": [],
            "cross_border": bool(decision.rule_results.get("other_jurisdictions")),
            "stored_outcome": decision.outcome,
            "replayed_outcome": None,
            "differences": [],
        }

    provenance = manifest_mod.check(
        decision.manifest,
        governing=pack,
        others=others,
        snapshot=decision.snapshot,
    )
    fresh = evaluate_snapshot(pack, decision.snapshot)
    differences = _compare_results("rule.", decision.rule_results["results"], fresh["rule_results"])
    differences.extend(
        _compare_not_applicable("", decision.rule_results, fresh)
    )

    stored_others = decision.rule_results.get("other_jurisdictions") or {}
    evaluations = [(pack, fresh)]
    # In the order the determination resolved them, re-derived from the frozen
    # snapshot — not alphabetically, which is a different order whenever the
    # residency code sorts after the domicile code. See `_replay_order`.
    for code in _replay_order(decision.snapshot, stored_others, others):
        stored = stored_others[code]
        other_pack = others.get(code)
        if other_pack is None:
            differences.append(
                {"field": f"pack.{code}", "stored": stored.get("pack_version"), "replayed": None}
            )
            continue
        other_fresh = evaluate_snapshot(other_pack, view_for(decision.snapshot, other_pack))
        evaluations.append((other_pack, other_fresh))
        differences.extend(
            _compare_results(f"rule.{code}.", stored["results"], other_fresh["rule_results"])
        )
        differences.extend(_compare_not_applicable(f"{code}.", stored, other_fresh))

    replayed_resolution = None
    if stored_others:
        replayed_resolution = resolve_across(
            snapshot=decision.snapshot, evaluations=evaluations, governing=pack
        )
        if replayed_resolution != decision.resolution:
            differences.append(
                {
                    "field": "resolution",
                    "stored": decision.resolution,
                    "replayed": replayed_resolution,
                }
            )
        replayed_outcome = replayed_resolution["outcome"]
    else:
        replayed_outcome = fresh["outcome"]

    outcome_match = replayed_outcome == decision.outcome
    if not outcome_match:
        differences.insert(
            0, {"field": "outcome", "stored": decision.outcome, "replayed": replayed_outcome}
        )

    return {
        # The pack of record loaded. Reported either way, so a caller reading
        # this dict never has to ask whether the key is present.
        "outcome_code": None,
        "pack_valid": True,
        "pack_faults": [],
        # Only *content* drift fails the replay: reading different rules or
        # different facts means this is not the record. A newer evaluator build
        # or a calc added to the registry is reported in `provenance` and is not
        # a failure — every deploy changes the first of those, and a verdict
        # that flipped on it would report a firm's entire history as broken the
        # first time anything shipped. `content_matches is None` is a
        # determination made before manifests existed, which is neither.
        "match": (
            outcome_match
            and not differences
            and provenance["content_matches"] is not False
        ),
        "provenance": provenance,
        "pack_version": pack.version,
        "pack_id": pack.pack_id,
        "jurisdictions_replayed": [p.pack_id for p, _ in evaluations],
        "cross_border": bool(stored_others),
        "stored_outcome": decision.outcome,
        "replayed_outcome": replayed_outcome,
        "differences": differences,
    }


#: How many links a tail check walks. Fifty, because it is the number that makes
#: the check bounded without making it decorative: it covers roughly the last
#: working day of a busy firm, which is the window where a live screen can tell
#: somebody something they did not already know from last night's full run.
TAIL_LINKS = 50


def verify_tail(session: Session, links: int = TAIL_LINKS) -> dict:
    """Verify the most recent links, in constant time, and say so.

    §S12 found the dashboard verifying the entire chain on every page load: 268ms
    against two thousand determinations, which is six or seven seconds against a
    real book and grows for as long as the customer stays. A screen that gets
    slower every day it is used is a screen that eventually stops being opened.

    **This is a weaker claim than `verify_chain`, and the difference matters.**
    Walking the tail proves the last N links are internally consistent and that
    the tip is what the records say it is. It cannot prove that nothing was
    altered a year ago, because the evidence that would show it is the very
    recomputation this skips.

    So the result says `scope: "tail"`, and the screen showing it says which
    check ran. The full walk still happens — nightly, in `make nightly-replay`,
    and in the health checks — and those are what a green badge here is
    ultimately standing on. A partial check reported as a complete one would be
    exactly the kind of quiet overstatement this product exists not to make.
    """
    tenant_id = current_tenant()
    recent = list(
        session.scalars(
            select(Decision)
            .where(Decision.tenant_id == tenant_id)
            .order_by(Decision.id.desc())
            .limit(links)
        )
    )
    recent.reverse()

    if not recent:
        return {
            "verified": True,
            "tenant_id": tenant_id,
            "genesis_hash": anchor_hash(session),
            "checked": 0,
            "tip_hash": anchor_hash(session),
            "scope": "tail",
            "of": 0,
        }

    total = session.scalar(
        select(func.count()).select_from(Decision).where(Decision.tenant_id == tenant_id)
    ) or 0

    # The first row's own `prev_hash` is taken on trust — it is the boundary of
    # what a bounded check can see, and pretending otherwise would mean walking
    # back to the anchor, which is the thing being avoided.
    prev_hash = recent[0].prev_hash
    checked = 0
    for decision in recent:
        payload = _hashable(
            tenant_id=decision.tenant_id,
            client_id=decision.client_id,
            asset_id=decision.asset_id,
            as_of=decision.as_of,
            pack_id=decision.pack_id,
            pack_version=decision.pack_version,
            snapshot=decision.snapshot,
            rule_results=decision.rule_results,
            resolution=decision.resolution,
            outcome=decision.outcome,
            created_at=decision.created_at,
            # The shape *this row* was hashed under, not today's. A payload
            # schema is a fact about a record, and recomputing an old row under
            # a new shape is how a verifier reports tampering on a database
            # nobody has touched.
            schema=decision.payload_schema,
            execution_manifest=decision.manifest,
        )
        expected = chain_hash(prev_hash, payload)
        if decision.prev_hash != prev_hash or decision.this_hash != expected:
            return {
                "verified": False,
                "tenant_id": tenant_id,
                "genesis_hash": anchor_hash(session),
                "checked": checked,
                "tip_hash": decision.prev_hash,
                "scope": "tail",
                "of": total,
                "broken_at_decision_id": decision.id,
                "expected_hash": expected,
                "stored_hash": decision.this_hash,
            }
        prev_hash = decision.this_hash
        checked += 1

    return {
        "verified": True,
        "tenant_id": tenant_id,
        "genesis_hash": anchor_hash(session),
        "checked": checked,
        "tip_hash": prev_hash,
        "scope": "tail",
        "of": total,
    }


#: The recomputed hash does not match the stored one, or the link does not name
#: the previous row. The ordinary tamper, and the one this chain was built for.
HASH_MISMATCH = "HASH_MISMATCH"

#: A row whose `snapshot` is not ciphertext this tenant's key can open.
#:
#: Which is precisely what a raw-SQL attacker produces. `decisions` is
#: append-only and INSERT is permitted — that is the property working, since a
#: chain is meant to make an *appended* forgery visible rather than impossible —
#: so an attacker with a shell writes a row with arbitrary bytes in `snapshot`,
#: and the verifier used to raise out of the decrypting column type before any
#: hash was compared.
UNDECRYPTABLE_SNAPSHOT = "UNDECRYPTABLE_SNAPSHOT"

#: Anything else about one row that stopped the walk. Kept separate from the two
#: above because "we know exactly what is wrong with row 4,201" and "row 4,201
#: did something we did not anticipate" are different sentences to be woken with.
ROW_UNREADABLE = "ROW_UNREADABLE"

#: The `snapshot` column's own type, borrowed to decode one row at a time.
#:
#: The same object the ORM would use, rather than a second implementation of the
#: decryption: a verifier that decoded snapshots by its own rules could disagree
#: with the writer about what a row says, and disagreeing about that is the one
#: thing this function must not do. Annotated because `Column.type` is declared
#: as the base `TypeEngine`, and what is on this column is the decorator.
_SNAPSHOT_TYPE: EncryptedJSON = cast("EncryptedJSON", Decision.__table__.c.snapshot.type)

#: The same column, named as raw bytes. Unqualified because `decisions` is the
#: only table the statement below selects from.
_RAW_SNAPSHOT = literal_column("snapshot", LargeBinary).label("snapshot_bytes")

#: The two crypto failures that are **not** about a row, and are re-raised.
#:
#: `KeysNotConfigured` means this process has no master key and can decrypt
#: nothing; `NoDataKey` means this tenant has no key at all. Neither is a
#: statement about decision #4,201, and reporting either as
#: `UNDECRYPTABLE_SNAPSHOT` would page somebody about tampering when the answer
#: is an unset environment variable — the same misdiagnosis this whole fix is
#: about, produced by the fix. Raised, so that `alerts.check` reports them as a
#: check that could not run, which is what they are.
#:
#: Found while verifying the fix: the first run of the new verifier, in a shell
#: with no `QUOLIN_MASTER_KEY`, confidently reported that decision 1 had been
#: tampered with.
_NOT_ABOUT_A_ROW = (crypto.KeysNotConfigured, crypto.NoDataKey)


def verify_chain(session: Session, limit: int | None = None) -> dict:
    """Walk this tenant's chain and recompute every link. Returns; never raises.

    Starts at the tenant's anchor rather than at a constant, and filters by
    tenant explicitly for the same reason `_tip_hash` does. A tenant with no
    decisions yet verifies, with a tip equal to its anchor — an empty chain is
    a valid chain, and reporting it as broken would make the first check any
    new customer ever ran a failure.

    **A row-level fault is a verdict, not an exception**, and that is the Gate A
    audit's fifth finding. `snapshot` is `EncryptedJSON`, so SQLAlchemy decrypts
    it while *materialising the row* — before this function sees anything to
    compare. A forged row therefore raised `ValueError` out of the column type,
    and the verifier went quiet at the exact moment its subject was tampering.
    In a product whose thesis is tamper-evidence that is the worst available
    failure mode: not a false negative, but a check that stops answering.

    Where it went is worth being precise about, because it went somewhere in
    each case and somewhere different each time. `alerts.check` has a blanket
    handler, so the page said *"the chain_integrity check could not run"* and
    pointed at fixing the check — rather than *"the evidence chain does not
    verify, it breaks at determination #4,201, stop issuing artefacts and follow
    chain-mismatch.md"*. The severity and the exit code were right and the
    instruction was wrong, which is worse than either being wrong alone.
    `scripts/nightly_replay.py` had no wrapper at all and the run died.

    So the rows are read as columns and the snapshot is decoded here, one row at
    a time, inside a handler. Every failure names the decision and the tenant,
    and carries a reason code a runbook can be written against. The treatment
    `replay` already had — `PACK_INVALID_AT_REPLAY` rather than an exception —
    applied to the other half of the same job.

    `NoChainAnchor` is still raised, and that is deliberate rather than an
    exception to the rule above. It is not a row-level problem: it says this
    tenant's chain has no beginning, `alerts.chain_integrity` reports it as its
    own finding with its own instruction, and folding it into a per-row reason
    code would lose the distinction between "a record is wrong" and "there is
    nothing to check any record against".
    """
    tenant_id = current_tenant()
    columns = Decision.__table__.c
    stmt = (
        select(
            columns.id,
            columns.tenant_id,
            columns.client_id,
            columns.asset_id,
            columns.as_of,
            columns.pack_id,
            columns.pack_version,
            # The ciphertext, as bytes, so that the decrypting result processor
            # does not run while the row is being materialised and this function
            # keeps control of the failure.
            #
            # `literal_column` rather than `type_coerce(columns.snapshot, …)` or
            # `.cast(…)`: both of those keep the decorated type in the
            # statement's cache key, and SQLAlchemy then prints a paragraph of
            # warning about a caching property on every verification. A verifier
            # whose real output arrives under an unrelated warning is a verifier
            # whose real output stops being read.
            _RAW_SNAPSHOT,
            columns.rule_results,
            columns.resolution,
            columns.outcome,
            columns.created_at,
            columns.payload_schema,
            columns.manifest,
            columns.prev_hash,
            columns.this_hash,
        )
        .where(columns.tenant_id == tenant_id)
        .order_by(columns.id)
    )
    if limit:
        stmt = stmt.limit(limit)

    prev_hash = anchor_hash(session)
    genesis = prev_hash
    checked = 0

    def unreadable(decision_id: Any, reason: str, detail: str) -> dict:
        return {
            "verified": False,
            "tenant_id": tenant_id,
            "genesis_hash": genesis,
            "checked": checked,
            "broken_at_decision_id": decision_id,
            "reason": reason,
            "detail": detail,
        }

    for row in session.execute(stmt):
        try:
            snapshot = _SNAPSHOT_TYPE.process_result_value(
                row.snapshot_bytes, session.get_bind().dialect
            )
        except _NOT_ABOUT_A_ROW:
            raise
        except Exception as exc:  # noqa: BLE001 — the verdict is the point
            return unreadable(row.id, UNDECRYPTABLE_SNAPSHOT, str(exc))

        try:
            payload = _hashable(
                tenant_id=row.tenant_id,
                client_id=row.client_id,
                asset_id=row.asset_id,
                as_of=row.as_of,
                pack_id=row.pack_id,
                pack_version=row.pack_version,
                snapshot=snapshot,
                rule_results=row.rule_results,
                resolution=row.resolution,
                outcome=row.outcome,
                created_at=row.created_at,
                # The shape *this row* was hashed under, not today's. A payload
                # schema is a fact about a record, and recomputing an old row
                # under a new shape is how a verifier reports tampering on a
                # database nobody has touched.
                schema=row.payload_schema,
                execution_manifest=row.manifest,
            )
            expected = chain_hash(prev_hash, payload)
        except _NOT_ABOUT_A_ROW:
            raise
        except Exception as exc:  # noqa: BLE001 — see the docstring
            return unreadable(row.id, ROW_UNREADABLE, f"{type(exc).__name__}: {exc}")

        if row.prev_hash != prev_hash or row.this_hash != expected:
            return {
                "verified": False,
                "tenant_id": tenant_id,
                "genesis_hash": genesis,
                "checked": checked,
                "broken_at_decision_id": row.id,
                "reason": HASH_MISMATCH,
                "expected_hash": expected,
                "stored_hash": row.this_hash,
            }
        prev_hash = row.this_hash
        checked += 1

    return {
        "verified": True,
        "tenant_id": tenant_id,
        "genesis_hash": genesis,
        "checked": checked,
        "tip_hash": prev_hash,
    }


def count(session: Session) -> int:
    return session.scalar(select(func.count(Decision.id))) or 0

# --------------------------------------------------------------- the audit chain
#
# T3 in docs/threat-model.md, recorded as not closed since §S9. Determinations
# were chained and the audit trail was append-only and nothing more — which
# stops the application role editing a row and does nothing about a privileged
# actor inserting history that never happened.
#
# The same mechanism, deliberately: canonical JSON, the same `chain_hash`, one
# chain per tenant. A second scheme would be a second thing to verify and a
# second thing to get wrong.


def audit_genesis(session: Session) -> str:
    """Where this tenant's audit chain starts.

    Derived from the decision chain's recorded anchor rather than stored in a
    second row. That inherits what the anchor exists for — a tenant deleted and
    recreated under the same slug gets a different anchor, so nothing from the
    old chain verifies against the new — without a second table or a wider
    primary key on an append-only one.
    """
    return chain_hash(anchor_hash(session), {"chain": "audit_events"})


def _audit_payload(event: AuditEvent) -> dict[str, Any]:
    """What an audit row commits to. Every field it has, and no derived ones."""
    return {
        "tenant_id": event.tenant_id,
        "actor": event.actor,
        "action": event.action,
        "subject": event.subject,
        # Same normalisation as the determination chain, for the same reason —
        # and it has to be the same, or the two chains would disagree about
        # which of them a timezone change had broken.
        "at": _utc_isoformat(event.at) if event.at else "",
    }


def _audit_tip(session: Session) -> str:
    """The last hash in this tenant's audit chain, or its genesis."""
    tenant_id = current_tenant()
    stmt = (
        select(AuditEvent.this_hash)
        .where(AuditEvent.tenant_id == tenant_id)
        .where(AuditEvent.this_hash != "")
        .order_by(AuditEvent.id.desc())
        .limit(1)
    )
    return session.scalars(stmt).first() or audit_genesis(session)


def link_audit(session: Session, event: AuditEvent) -> AuditEvent:
    """Chain one audit row onto the tenant's audit history.

    Takes the same per-tenant lock the determination chain takes, rather than a
    lock of its own. Both chains belong to one firm and are written inside one
    transaction, so a single lock serialises both — and the alternative costs a
    second round trip on a path that runs for every determination in a sweep.
    """
    # A tenant with no chain anchor gets an unlinked row rather than an error.
    #
    # This is the one coupling that must not exist: `service.audit` is called on
    # the way through almost every mutation, so an audit write that raises takes
    # the action with it. Chaining the trail must never be able to stop the
    # trail being written — and §S13's CI found exactly that, on two tenants
    # created by migration that never went through `ensure_anchor`.
    #
    # The row is honest about itself: `verify_audit_chain` counts unlinked rows
    # separately, and `make rechain ARGS="--table audit_events --apply"` links
    # them once the tenant has an anchor. An absence that is reported is a
    # different thing from a gap that is hidden.
    try:
        anchor_hash(session)
    except NoChainAnchor:
        return event

    _lock_chain(session)

    # Named here and used for both the hash and the row, for the reason
    # `record` gives about decisions: `tenant_id` and `at` are column defaults
    # applied at *flush*, so hashing before the row is added commits to a null
    # tenant and a null timestamp. The row then stores the real values and
    # nothing verifies. Setting them explicitly means there is one read and no
    # way for the two to diverge.
    event.tenant_id = event.tenant_id or current_tenant()
    event.at = event.at or datetime.now(timezone.utc)
    # The tip is carried through the transaction rather than re-read.
    #
    # A request that writes four audit rows would otherwise give all four the
    # same parent — the rows are not flushed yet, so the query cannot see them —
    # and the unique index refuses the second, loudly and correctly. Flushing
    # before each read fixed that and cost two round trips per determination,
    # which a bulk sweep pays for every pair.
    #
    # Remembering what we just wrote is both cheaper and more obviously right.
    # Cleared on commit and on rollback by the listeners below, so a transaction
    # that did not happen leaves nothing behind to chain onto.
    tips = session.info.setdefault(_PENDING_AUDIT_TIP, {})
    tenant_id = event.tenant_id
    event.prev_hash = tips.get(tenant_id) or _audit_tip(session)
    event.this_hash = chain_hash(event.prev_hash, _audit_payload(event))
    tips[tenant_id] = event.this_hash
    return event


def verify_audit_chain(session: Session, limit: int | None = None) -> dict:
    """Walk this tenant's audit chain and recompute every link.

    Rows written before the chain existed carry an empty `this_hash` and are
    reported as unlinked rather than as broken. They are outside the guarantee
    until `make rechain ARGS="--table audit_events --apply"` links them, and
    saying "unverified" about them is the honest answer — claiming a break would
    be as wrong as claiming they verified.

    **Only before the chain starts.** Q-13: an unlinked row was skipped wherever
    it appeared, so anybody able to write to `audit_events` could insert history
    by leaving one column empty and the verifier would report success over it.
    Once a chained row has been seen, an unlinked one is not history that
    predates the mechanism — it is a row inserted past the point where the
    mechanism applies, and it is a break.

    The watermark is the first chained row rather than a date or a migration
    number, deliberately. It is derived from the data in front of the verifier,
    so it cannot be wrong about a database it has never seen, and no new column
    has to be kept in step with it.
    """
    tenant_id = current_tenant()
    stmt = (
        select(AuditEvent)
        .where(AuditEvent.tenant_id == tenant_id)
        .order_by(AuditEvent.id)
    )
    if limit:
        stmt = stmt.limit(limit)

    genesis = audit_genesis(session)
    prev_hash = genesis
    checked = 0
    unlinked = 0
    #: Whether the chain has started. Everything unlinked before this is
    #: pre-chain history; everything unlinked after it is inserted history.
    chain_has_started = False
    for event in session.scalars(stmt):
        if not event.this_hash:
            unlinked += 1
            if chain_has_started:
                return {
                    "verified": False,
                    "tenant_id": tenant_id,
                    "genesis_hash": genesis,
                    "checked": checked,
                    "unlinked": unlinked,
                    "broken_at_audit_id": event.id,
                    "expected_hash": chain_hash(prev_hash, _audit_payload(event)),
                    "stored_hash": "",
                    "reason": (
                        "an audit row after the start of the chain carries no hash. "
                        "Rows that predate the chain are outside the guarantee and "
                        "are counted; a row written after it is not history, it is "
                        "an insertion."
                    ),
                }
            continue
        chain_has_started = True
        expected = chain_hash(prev_hash, _audit_payload(event))
        if event.prev_hash != prev_hash or event.this_hash != expected:
            return {
                "verified": False,
                "tenant_id": tenant_id,
                "genesis_hash": genesis,
                "checked": checked,
                "unlinked": unlinked,
                "broken_at_audit_id": event.id,
                "expected_hash": expected,
                "stored_hash": event.this_hash,
            }
        prev_hash = event.this_hash
        checked += 1

    return {
        "verified": True,
        "tenant_id": tenant_id,
        "genesis_hash": genesis,
        "checked": checked,
        # Named rather than folded into `checked`, because "we verified 40 of
        # 1200 rows" and "we verified 1200 rows" are different sentences and an
        # auditor is entitled to the first one.
        "unlinked": unlinked,
        "tip_hash": prev_hash,
    }


@sa_event.listens_for(Session, "after_commit")
@sa_event.listens_for(Session, "after_rollback")
@sa_event.listens_for(Session, "after_soft_rollback")
def _forget_chain_state(session: Session, *args: Any) -> None:
    """Drop what was true only inside the transaction that just ended.

    The advisory lock is released by Postgres at commit or rollback, and the
    pending audit tip describes rows that either exist now or never will. Either
    way, carrying them into the next transaction would chain onto something that
    is not there — which is exactly the shape of the fork §S13 spent a stage on.
    """
    session.info.pop(_HELD_LOCKS, None)
    session.info.pop(_PENDING_AUDIT_TIP, None)
