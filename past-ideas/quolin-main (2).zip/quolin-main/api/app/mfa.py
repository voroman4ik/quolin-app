"""Whether a privileged person has proved they are who they say they are.

`MFA_REQUIRED_ROLES` has named `approver`, `pack_signatory`, `tenant_admin` and
`quolin_support` since Stage 2. Until Stage 13's external review, it was
referenced in exactly two places: its own definition, and `access_review.py`,
which reported the gap quarterly. Nothing enforced it — a signatory with no
second factor could sign rule content, and an approver with none could complete
the second half of a two-person act.

Those are the two operations in this system that most need a person to be who
they say they are. A password alone is a credential somebody can be phished out
of, and the whole argument for separation of duties is that two people had to
act. If one of them is a stolen password, there was one.

**Two layers, and this module is both of them.** `locked_out` is what the
request middleware asks, so an unenrolled privileged session can do nothing but
enrol. `assert_second_factor` is what signing and approving ask for themselves,
so the guarantee does not rest on the middleware being right. The second is not
redundancy for its own sake: the middleware has an allow-list of paths, and an
allow-list is a thing that grows.

**It locks rather than refuses the sign-in.** Refusing to authenticate somebody
who holds a privileged role and no second factor would lock them out of the
system with no way back in — there is no enrolment that does not need a session.
So the session exists, and it can do exactly two things.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from . import identity
from .models import MFA_REQUIRED_ROLES


class MfaRequired(PermissionError):
    """A privileged action was attempted from a session with no second factor."""


#: What a locked session may still reach. Deliberately tiny, and deliberately
#: not "everything under /auth": that would include the re-authentication route,
#: which is the credential-freshness check that pack signing depends on.
UNLOCKED_PATHS = frozenset(
    {
        "/auth/session",
        "/auth/logout",
        "/auth/mfa/enrol",
        "/auth/mfa/verify",
    }
)

MESSAGE = (
    "This account holds a role that requires a second factor, and none is "
    "enrolled. Enrol an authenticator app to continue — until then this "
    "session can do nothing else."
)


def privileged_roles(session: Session, user_id: str) -> list[str]:
    """The roles this person holds that the policy names, in the tenant in scope."""
    held = {grant.role for grant in identity.roles_for(session, user_id)}
    return sorted(held & set(MFA_REQUIRED_ROLES))


def locked_out(session: Session, *, user_id: str, mfa_satisfied: bool) -> bool:
    """Whether this session is confined to enrolling a second factor."""
    if mfa_satisfied:
        return False
    return bool(privileged_roles(session, user_id))


def assert_second_factor(
    session: Session, *, user_id: str, mfa_satisfied: bool
) -> None:
    """Refuse a privileged action from a session with no verified second factor.

    Called by the action rather than trusted from the door. A middleware
    allow-list is a list somebody adds to, and the day a path is added that
    happens to reach signing, this is what still refuses.
    """
    if mfa_satisfied:
        return
    held = privileged_roles(session, user_id)
    if held:
        raise MfaRequired(
            f"{', '.join(held)} requires a second factor and this session has "
            "none. " + MESSAGE
        )
