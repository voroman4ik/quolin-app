"""What is wrong right now, and who has to be woken for it.

§S9 asks for alerting on auth anomalies, row-level-security denials, chain
verification failures, replay mismatches, queue depth and webhook dead-letters —
and says the alerts must "page a person, not a channel nobody reads".

Three decisions shape this module.

**Every check answers from the database, not from a counter in memory.** A
process that restarts forgets, and the failure this exists to catch is the one
that happened while nobody was looking. Everything here is a query.

**Severity is about what it means, not about how many.** A broken hash chain is
critical at one occurrence, because it means the evidence is not what it says it
is. A deep queue is a warning at a thousand, because it means somebody should
look before customers do. Sorting by count would put the queue first and the
chain second, which is the wrong way round on the only day it matters.

**Findings say what to do.** "chain verification failed" is a fact; "chain
verification failed — determinations after #4,201 cannot be relied on; see
docs/runbooks/chain-mismatch.md" is an instruction. An alert that requires the
reader to work out the next step is an alert that gets acknowledged and left.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from . import auth, evidence, observability
from .models import (
    ArtefactJob,
    AuthAttempt,
    Decision,
    EvalRun,
    SecurityEvent,
    WebhookDelivery,
)

CRITICAL = "critical"
WARNING = "warning"

#: How far back the rate-based checks look. An hour, because that is roughly how
#: long somebody has to notice a brute-force attempt before it either succeeds
#: or gives up, and short enough that yesterday's incident does not keep paging
#: today.
WINDOW = timedelta(hours=1)

#: Failed sign-ins against *one* account in the window before it is an incident.
#: Ten, because a person mistyping a password gives up around three and a
#: password manager does not mistype at all.
AUTH_FAILURES_PER_ACCOUNT = 10

#: Failed sign-ins from one address in the window, across any number of
#: accounts. Higher, because a shared office NAT is one address and a bad
#: Monday morning is real.
AUTH_FAILURES_PER_SOURCE = 30

#: Any denial at all is worth saying out loud. Row-level security refusing a
#: query means either an attack or a bug in the tenancy plumbing, and both are
#: things to look at the same day.
RLS_DENIALS = 1

#: Documents waiting. A hundred is a busy month-end; a thousand means the worker
#: is not running, which is the thing to find out before a customer does.
QUEUE_DEPTH = 1000

#: Deliveries that will never be retried again. One is a customer whose case
#: system missed a determination and does not know it.
DEAD_LETTERS = 1


@dataclass(frozen=True)
class Finding:
    """One thing that is wrong, and what to do about it."""

    severity: str
    kind: str
    summary: str
    action: str
    count: int = 1
    detail: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "severity": self.severity,
            "kind": self.kind,
            "summary": self.summary,
            "action": self.action,
            "count": self.count,
            **({"detail": self.detail} if self.detail else {}),
        }


def _since(now: datetime | None = None) -> datetime:
    return (now or datetime.now(timezone.utc)) - WINDOW


# ------------------------------------------------------------- the six checks --


def auth_anomalies(session: Session, *, now: datetime | None = None) -> list[Finding]:
    """Repeated failures against one account, or from one address.

    Two questions rather than one, because they are different incidents. Fifty
    failures against one account is somebody working through a password list.
    Fifty failures from one address across fifty accounts is somebody working
    through an *account* list, which means they have one from somewhere else.

    **Reads `auth_attempts`, not `security_events`.** §S12 found that this check
    had never been able to fire on a real sign-in: the rows it counted were
    written from `/auth/login`, `security_events` is tenant-scoped, and that
    endpoint is the one request in the system that cannot have a tenant in
    scope. Every insert failed the policy's row check and was swallowed. The
    game day passed because the game day writes its own rows with a tenant set —
    which is the exact shape of a monitor that tests itself and nothing else.

    `auth_attempts` has no tenant column, for the reason migration 0022 gives.
    That makes this check deployment-wide rather than per-customer: run once per
    tenant by `health_alerts`, it reports the same figures each time. That is
    accurate — the login endpoint is shared — and it is noted here because a
    reader comparing two tenants' alert output would otherwise wonder.
    """
    since = _since(now)
    findings: list[Finding] = []

    per_account = session.execute(
        select(AuthAttempt.user_id, func.count())
        .where(
            AuthAttempt.outcome == auth.FAILED,
            AuthAttempt.at >= since,
            AuthAttempt.user_id.is_not(None),
        )
        .group_by(AuthAttempt.user_id)
        .having(func.count() >= AUTH_FAILURES_PER_ACCOUNT)
    ).all()
    for user_id, count in per_account:
        findings.append(
            Finding(
                severity=CRITICAL,
                kind="auth.failures_against_account",
                summary=(
                    f"{count} failed sign-ins against one account in the last hour"
                ),
                action=(
                    "Suspend the account and speak to the person it belongs to. "
                    "See docs/runbooks/suspected-breach.md."
                ),
                count=count,
                detail={"user_id": user_id},
            )
        )

    per_source = session.execute(
        select(AuthAttempt.source_ip, func.count())
        .where(
            AuthAttempt.outcome.in_((auth.FAILED, auth.RATE_LIMITED)),
            AuthAttempt.at >= since,
            AuthAttempt.source_ip != "",
        )
        .group_by(AuthAttempt.source_ip)
        .having(func.count() >= AUTH_FAILURES_PER_SOURCE)
    ).all()
    for source_ip, count in per_source:
        findings.append(
            Finding(
                severity=WARNING,
                kind="auth.failures_from_source",
                summary=f"{count} failed sign-ins from one address in the last hour",
                action=(
                    "Check whether the address is a customer's office. If not, "
                    "block it at the load balancer. "
                    "See docs/runbooks/suspected-breach.md."
                ),
                count=count,
                detail={"source_ip": source_ip},
            )
        )
    return findings


def rls_denials(session: Session, *, now: datetime | None = None) -> list[Finding]:
    """A query row-level security refused.

    Critical at one, and that is not excessive. Every query this system makes is
    supposed to be inside a tenant that owns the rows; a denial means either an
    attempt to reach another customer's data or a bug in the plumbing that
    prevents it. Both are the same day's work.
    """
    count = session.scalar(
        select(func.count())
        .select_from(SecurityEvent)
        .where(
            SecurityEvent.kind == observability.RLS_DENIED,
            SecurityEvent.at >= _since(now),
        )
    )
    if not count or count < RLS_DENIALS:
        return []
    return [
        Finding(
            severity=CRITICAL,
            kind="rls.denied",
            summary=(
                f"{count} quer{'y was' if count == 1 else 'ies were'} refused "
                "by row-level security"
            ),
            action=(
                "Read the security_events rows. Either somebody reached for "
                "another customer's data, or a code path lost its tenant — "
                "there is no third explanation. "
                "See docs/runbooks/suspected-breach.md."
            ),
            count=count,
        )
    ]


def chain_integrity(session: Session) -> list[Finding]:
    """The evidence chain, recomputed.

    The most expensive check here and the one worth running most carefully: a
    determination whose hash does not match is a determination somebody can
    argue was altered, and every determination after it inherits the doubt.

    **A tenant with no determinations has no chain, and that is not a finding.**
    A customer who has been provisioned and has not started yet is in exactly
    the state they should be in; reporting it as a check that could not run
    would page somebody every night about a firm that has done nothing wrong.
    A tenant that holds determinations and *no anchor* is a different matter and
    is reported, because that is a chain with no beginning.
    """
    held = session.scalar(select(func.count()).select_from(Decision)) or 0
    if not held:
        return []

    try:
        result = evidence.verify_chain(session)
    except evidence.NoChainAnchor as exc:
        return [
            Finding(
                severity=CRITICAL,
                kind="chain.no_anchor",
                summary=f"{held} determinations exist with no chain anchor to start from",
                action=(
                    "The chain has no beginning, so nothing after it can be "
                    "verified. See docs/runbooks/chain-mismatch.md — this needs "
                    "`make rechain` only once the cause is understood."
                ),
                count=held,
                detail={"error": str(exc)},
            )
        ]
    except Exception as exc:  # noqa: BLE001 — see below
        # Anything else at all, as a chain finding rather than as a generic one.
        #
        # `check` below has a blanket handler and would have caught this, which
        # is why the Gate A audit's fifth finding was a degraded signal rather
        # than a silent one: a forged row raised out of the decrypting column
        # type and the page said *"the chain_integrity check could not run"*,
        # with the action "fix the check before trusting the absence of the
        # alerts it produces". Correct severity, correct exit code, and an
        # instruction that sends somebody to look at monitoring code while their
        # evidence is being altered.
        #
        # `verify_chain` returns a verdict for every row-level problem now, so
        # this is genuinely the unexpected case — but it stays, and it stays
        # *here*, because the useful sentence at 3am names the chain.
        return [
            Finding(
                severity=CRITICAL,
                kind="chain.unverifiable",
                summary=(
                    "the evidence chain could not be walked at all: "
                    f"{type(exc).__name__}: {exc}"
                ),
                action=(
                    "This is not an all-clear and it is not a chain that "
                    "verifies — it is a chain nobody has checked. Treat it as "
                    "docs/runbooks/chain-mismatch.md until the cause is known; "
                    "the two most likely are a key this process cannot read and "
                    "a row it cannot decode."
                ),
                count=held,
                detail={"error": str(exc)},
            )
        ]

    if result.get("verified"):
        return []

    reason = result.get("reason") or evidence.HASH_MISMATCH
    where = result.get("broken_at_decision_id")

    if reason == evidence.HASH_MISMATCH:
        summary = (
            "the evidence chain does not verify — "
            f"it breaks at determination #{where}"
        )
        action = (
            "Stop issuing artefacts and follow docs/runbooks/chain-mismatch.md. "
            "Do not re-chain anything until the cause is known: the repair "
            "destroys the evidence of what happened."
        )
    else:
        # A row that cannot be read is the shape a raw-SQL forgery takes.
        # `decisions` permits INSERT — that is the property working, since a
        # chain exists to make an appended forgery *visible* rather than
        # impossible — so an attacker with a shell writes a row whose snapshot
        # is not ciphertext this tenant's key can open. Named separately from a
        # hash mismatch because the first question differs: a mismatch asks what
        # changed, this asks who has write access to the database.
        summary = (
            "the evidence chain does not verify — determination #"
            f"{where} cannot be read ({reason})"
        )
        action = (
            "Stop issuing artefacts and follow docs/runbooks/chain-mismatch.md. "
            "A determination whose snapshot will not decrypt was written by "
            "something that was not this application: ask who holds write "
            "access to the database before asking what the row says. Do not "
            "re-chain: the repair destroys the evidence of what happened."
        )

    return [
        Finding(
            severity=CRITICAL,
            kind="chain.broken",
            summary=summary,
            action=action,
            detail={
                "broken_at_decision_id": where,
                "reason": reason,
                "checked": result.get("checked"),
                **({"detail": result["detail"]} if result.get("detail") else {}),
            },
        )
    ]


def replay_mismatches(session: Session, *, now: datetime | None = None) -> list[Finding]:
    """Determinations that no longer reproduce.

    Read from the audit trail rather than recomputed, because the nightly replay
    is what recomputes them and doing it twice would double the most expensive
    job this system runs. What this checks is whether that job found anything.
    """
    rows = session.execute(
        select(func.count())
        .select_from(SecurityEvent)
        .where(
            SecurityEvent.kind == observability.REPLAY_MISMATCH,
            SecurityEvent.at >= _since(now),
        )
    ).scalar()
    if not rows:
        return []
    return [
        Finding(
            severity=CRITICAL,
            kind="replay.mismatch",
            summary=f"{rows} determination(s) did not reproduce on replay",
            action=(
                "A stored determination now evaluates differently. Either the "
                "snapshot is not the only input, or a pack was edited in place. "
                "See docs/runbooks/chain-mismatch.md."
            ),
            count=rows,
        )
    ]


def queue_depth(session: Session) -> list[Finding]:
    """Work waiting, across both queues.

    Counted together because a customer does not care which of our queues is
    stuck. The detail says which, so whoever is paged does not have to look.
    """
    documents = session.scalar(
        select(func.count()).select_from(ArtefactJob).where(ArtefactJob.status == "queued")
    ) or 0
    sweeps = session.scalar(
        select(func.count()).select_from(EvalRun).where(EvalRun.status.in_(("planned", "running")))
    ) or 0

    if documents + sweeps < QUEUE_DEPTH:
        return []
    return [
        Finding(
            severity=WARNING,
            kind="queue.deep",
            summary=f"{documents + sweeps} pieces of work are waiting",
            action=(
                "Check that the artefact and bulk workers are running. A queue "
                "this deep with workers up means one job is failing repeatedly."
            ),
            count=documents + sweeps,
            detail={"documents": documents, "sweeps": sweeps},
        )
    ]


def dead_letters(session: Session) -> list[Finding]:
    """Deliveries that will not be retried again.

    One is enough. A dead delivery is a customer's case system that missed a
    determination and has no way of knowing — and the only person who can tell
    them is us.
    """
    rows = session.execute(
        select(WebhookDelivery.endpoint_id, func.count())
        .where(WebhookDelivery.status == "dead")
        .group_by(WebhookDelivery.endpoint_id)
    ).all()
    total = sum(count for _endpoint, count in rows)
    if total < DEAD_LETTERS:
        return []
    return [
        Finding(
            severity=WARNING,
            kind="webhook.dead_letters",
            summary=f"{total} webhook deliver{'y' if total == 1 else 'ies'} gave up",
            action=(
                "Tell the customer their endpoint has been failing, then replay "
                "the dead deliveries once they have fixed it. "
                "See docs/runbooks/webhook-storm.md."
            ),
            count=total,
            detail={"endpoints": len(rows)},
        )
    ]


#: Every check, paired with whether it looks at a window of time.
#:
#: The pairing is explicit rather than inferred from the signature: a check that
#: quietly stopped taking a clock would then quietly stop being given one, and
#: the window it was supposed to look at would silently become "all of history".
CHECKS: tuple[tuple[Any, bool], ...] = (
    (auth_anomalies, True),
    (rls_denials, True),
    (chain_integrity, False),
    (replay_mismatches, True),
    (queue_depth, False),
    (dead_letters, False),
)


def check(session: Session, *, now: datetime | None = None) -> list[Finding]:
    """Everything that is wrong, worst first.

    A check that raises does not stop the others. The whole point of this
    function is to be the one thing a scheduler calls, and a broken chain check
    that suppressed the queue check would be worse than either alone — and a
    check that fails is reported *as a finding*, because a blind spot is not an
    all-clear.
    """
    findings: list[Finding] = []
    for run, windowed in CHECKS:
        try:
            findings.extend(run(session, now=now) if windowed else run(session))
        except Exception as exc:  # noqa: BLE001 — see the docstring
            findings.append(
                Finding(
                    severity=CRITICAL,
                    kind="alerts.check_failed",
                    summary=f"the {run.__name__} check could not run: {exc}",
                    action=(
                        "This is a blind spot, not an all-clear. Fix the check "
                        "before trusting the absence of the alerts it produces."
                    ),
                )
            )
    order = {CRITICAL: 0, WARNING: 1}
    findings.sort(key=lambda f: (order.get(f.severity, 2), f.kind))
    return findings
