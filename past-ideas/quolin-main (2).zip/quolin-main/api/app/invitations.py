"""How a real person comes to hold a password.

FP3-11. `identity.set_password` had two callers — the seed and the load model —
and `POST /admin/users` creates, in its own words, "a person, created with no
way to sign in yet". There was no invite route, no set-password route and no
reset route, and OIDC does not provision. So the first customer's first user
could be created and could never sign in; every account that works today works
because the seed gave it a password.

Three properties, and each is the answer to a specific way this goes wrong.

**Single-use.** An invite link sits in an inbox for ever, and a mailbox is not a
vault. `consumed_at` is set by the statement that consumes it, so the check and
the use are one operation rather than two somebody has to remember to order.

**Expiring.** A credential-granting link that never dies is a credential. Seven
days is long enough for somebody on leave and short enough that a forgotten
invitation is not a standing key.

**Hashed at rest.** `invitations` is readable by the application role, and a
table of live tokens in plaintext is a worse problem than the one it solves.
The token is returned exactly once, to the administrator who created it, and is
never stored — the same shape as `auth_sessions`.

**Resets use the same mechanism**, deliberately. A reset is an invitation to
choose a credential, issued to somebody who already has an account. Two tables
would mean two implementations of one security-sensitive thing, and the second
one is always the one nobody looks at.
"""

from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import passwords
from .identity import _scope_to_user, new_id, set_password
from .models import Invitation, User

#: How long an invitation lives.
#:
#: Seven days rather than a day: an account is often created for somebody who
#: starts on Monday, and an invitation that expires before their first morning
#: is one the administrator has to issue twice. Rather than a month: a link that
#: grants a credential and sits unused for four weeks is a key in an inbox.
LIFETIME = timedelta(days=7)

INVITE = "invite"
RESET = "reset"


class InvitationInvalid(Exception):
    """The token does not name a live, unconsumed, unexpired invitation.

    One exception for every reason, and one message at the endpoint. "This link
    has expired" and "this link has already been used" and "this link is not one
    of ours" are three facts about our records, and telling somebody holding a
    bad token which one applies is telling them something about an account they
    may not hold.
    """


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def issue(
    session: Session,
    *,
    user: User,
    created_by: str,
    kind: str = INVITE,
    now: datetime | None = None,
) -> tuple[Invitation, str]:
    """Mint a single-use token for this person, and return it once.

    The plaintext comes back to the caller and is not stored. An administrator
    who loses it issues another; there is no route that reveals an existing one,
    because a route that could would make the table's hashing pointless.

    Any invitation this person already holds is left alone rather than revoked.
    Two live invitations are two ways for the same person to set the same
    password, which is not a weakness — and revoking the old one would let
    anybody who can trigger an invite invalidate a link somebody is about to
    use.
    """
    moment = now or datetime.now(timezone.utc)
    token = secrets.token_urlsafe(32)

    row = Invitation(
        id=new_id("inv"),
        user_id=user.id,
        token_hash=_hash(token),
        kind=kind,
        created_by=created_by,
        created_at=moment,
        expires_at=moment + LIFETIME,
    )
    session.add(row)
    session.flush()
    return row, token


def resolve(
    session: Session, token: str, *, now: datetime | None = None
) -> Invitation:
    """The live invitation this token names, or `InvitationInvalid`.

    Looked up by hash, so a token that is not ours matches nothing rather than
    being compared against every row.
    """
    moment = now or datetime.now(timezone.utc)

    row = session.scalars(
        select(Invitation).where(Invitation.token_hash == _hash(token))
    ).one_or_none()

    if row is None or row.consumed_at is not None or row.expires_at <= moment:
        raise InvitationInvalid(
            "That link is not valid. It may have expired, or already been used. "
            "Ask whoever set up your account for another."
        )
    return row


def consume(
    session: Session,
    token: str,
    *,
    password: str,
    now: datetime | None = None,
) -> User:
    """Set the password this invitation was issued for, and spend it.

    The order matters. The policy is checked **before** the invitation is
    marked consumed, so somebody whose first attempt is too short still holds a
    live link — otherwise the failure mode of a password rule is that people
    lock themselves out by trying to obey it.

    `set_password` and the consumption happen in one transaction, so there is no
    state where the token is spent and no credential exists.
    """
    moment = now or datetime.now(timezone.utc)
    row = resolve(session, token, now=moment)

    # `users` is invisible until `app.user_id` names the row — the policy that
    # stops one person enumerating another's account. Nobody is signed in on
    # this route by construction, so without this the lookup returns None and a
    # perfectly valid link is refused as invalid.
    #
    # Safe by the rule `_scope_to_user`'s own docstring gives: the id was not
    # supplied by the caller, it was read off an invitation row this function
    # just resolved by digest. Nothing is authorised by it — holding the token
    # is the authorisation, and that was settled above.
    _scope_to_user(session, row.user_id)

    user = session.get(User, row.user_id)
    if user is None:  # pragma: no cover - the FK makes this unreachable
        raise InvitationInvalid("That link is not valid.")

    # Raises before anything is spent.
    passwords.check_strength(password, email=user.email)

    set_password(session, user, password)
    row.consumed_at = moment
    session.flush()
    return user


def outstanding(session: Session, user_id: str, *, now: datetime | None = None) -> bool:
    """Whether this person has a live invitation they have not used.

    Read by the reset route so that asking twice in a minute does not mint a
    second token for no reason.
    """
    moment = now or datetime.now(timezone.utc)
    return bool(
        session.scalars(
            select(Invitation).where(
                Invitation.user_id == user_id,
                Invitation.consumed_at.is_(None),
                Invitation.expires_at > moment,
            )
        ).first()
    )
