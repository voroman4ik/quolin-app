from __future__ import annotations

from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    email: str
    #: No max_length and no pattern. A password is compared, never parsed, and a
    #: validation error firing before the comparison would answer questions
    #: about the real one for free.
    password: str
    #: The one-time code, when the account has a second factor. Empty otherwise,
    #: and empty on the first attempt of a sign-in that turns out to need one —
    #: the client cannot know in advance, and is told once the password checks
    #: out and not before.
    code: str = ""


class RevokeRequest(BaseModel):
    """Which sessions `/auth/revoke-all` should end.

    `me` by default, because that is what the break-glass case needs: somebody
    whose credential has leaked wants their own access gone everywhere, not the
    firm's. Q-14 — the route used to sweep the whole tenant for any caller, a
    `viewer` included, which is a denial of service anybody could trigger.

    A closed vocabulary rather than a free string, so an unrecognised scope is a
    422 rather than a quiet fall back to the default. An administrator dealing
    with an incident must not be told "ok" over a sweep that did the smaller
    thing.
    """

    scope: Literal["me", "tenant"] = "me"


class AdvancePolicyRequest(BaseModel):
    """A firm's change-control policy, set by the firm.

    Q-15: `advance.policy_for` read this on every version arrival and nothing
    could write it — a customer wanting to pin their rules had to ask somebody
    at Quolin to run an UPDATE.

    A closed vocabulary, because `policy_for` reads anything it does not
    recognise as `pinned`. That is the safe direction and exactly why an API
    must not accept a typo: a firm that sent `automatic` and was told "ok" would
    believe they were on one policy and be on the other.
    """

    policy: Literal["auto", "pinned"]
    #: Omitted leaves the window as it was. Bounded because a zero-day window is
    #: `auto` wearing the word `pinned`.
    window_days: int | None = Field(default=None, ge=1, le=90)


class SuspendUserRequest(BaseModel):
    """Why somebody's access is ending. FP3-13.

    The reason is required and is not a courtesy. Suspending an account is the
    one identity act with no undo that leaves a trace — a person cannot sign in
    to ask why — and "who decided, and on what grounds" is the question an
    access review asks first. A free-text field somebody has to fill in is a
    worse control than a vocabulary and a much better one than nothing.
    """

    reason: str = Field(min_length=4, max_length=500)


class SetPasswordRequest(BaseModel):
    """Choosing a credential from an invitation. FP3-11.

    The token travels in the body rather than the query string, because a query
    string is written into access logs, browser history and referrer headers —
    and this one grants a credential.
    """

    token: str = Field(min_length=16, max_length=200)
    password: str = Field(min_length=1, max_length=1024)


class ResetRequest(BaseModel):
    """"I have forgotten my password."" FP3-11.

    Takes an address and answers the same way whether or not it names an
    account. A route that said "no such user" would be an enumeration oracle on
    the one endpoint that has to be reachable by somebody who cannot sign in.
    """

    email: str = Field(min_length=3, max_length=320)


class NewUserRequest(BaseModel):
    """A person, created with no way to sign in yet.

    Deliberately without a password: an account created by an administrator and
    an account that has chosen a credential are different states, and collapsing
    them means an invited user exists with a password somebody else typed. The
    same split `identity.create_user` and `identity.set_password` already make.
    """

    email: str = Field(min_length=3, max_length=320)
    display_name: str = Field(min_length=1, max_length=200)


class GrantRoleRequest(BaseModel):
    """One role, for one person, inside the firm in scope.

    The tenant is not a field. `user_roles` takes it from the ambient scope and
    the row-level-security policy refuses an insert naming any other, so a grant
    cannot be written for a firm the caller is not signed in to — there is no
    parameter by which to try.
    """

    role: str
    #: Only meaningful for `pack_signatory`: competence to attest for one regime
    #: is not competence to attest for another.
    jurisdiction: str = ""
    #: The engagement behind a signatory's name. Printed on the signature block
    #: and read by `app/attestation.py` when a pack is published.
    qualification_ref: str = ""
    #: For a time-boxed grant — support access, a secondment. `roles_for` stops
    #: honouring it at the moment it lapses rather than at the next sweep.
    expires_at: datetime | None = None


class ReauthRequest(BaseModel):
    """Confirming a credential on a session that already exists.

    Deliberately carries no email. The person is whoever the session already
    says they are; accepting an address here would let a live session be
    re-pointed at a different account by anyone holding the cookie.
    """

    password: str
    code: str = ""


class EvaluateRequest(BaseModel):
    client_id: str
    asset_id: str
    as_of: date | None = None
    amount_cents: int | None = Field(default=None, ge=0)
    #: F7. The console reaches the same evaluator as `/v1` and takes the same
    #: date, so it takes the same rule: a future `as_of` is refused and a past
    #: one needs a stated reason. Fixing only the integration path would have
    #: left the firm's own staff holding the dial their integration no longer
    #: has, which is the wrong way round — the console is where somebody is
    #: signed in as a person.
    as_of_reason: str | None = None


class OverrideRequest(BaseModel):
    """Overruling a determination. Only the reasoning travels.

    There is deliberately no `approver` field, for the reason `SignRequest`
    gives about `signatory`: an approval carrying a name the caller typed is an
    approval by nobody in particular, and the separation this stage enforces —
    that the approver is not the person who ran the check — cannot be enforced
    against a string.
    """

    justification: str = Field(min_length=20)


class ArtefactRequest(BaseModel):
    decision_id: int


class PeriodReportRequest(BaseModel):
    """Named period, not a free date range — see reports.period_bounds."""

    period: str = Field(pattern=r"^\d{4}-(0[1-9]|1[0-2]|Q[1-4])$")
    #: Which regulator the return is filed with. Stated by value rather than
    #: imported from `service`, because a request schema that reaches into the
    #: service layer inverts the dependency the whole module is arranged around.
    jurisdiction: str = "AU"
    scenario: str | None = None


class ClientImportRequest(BaseModel):
    """A client book as CSV text.

    `commit` defaults to False so the dangerous call is the one you have to type
    deliberately. A caller who forgets the flag gets a preview, not a write.
    """

    csv_text: str = Field(min_length=1)
    commit: bool = False


class TriageRequest(BaseModel):
    """Moving a queue item along. Statuses are workflow, not evidence."""

    status: str = Field(pattern=r"^(new|reviewing|dismissed|actioned)$")
    note: str = ""


class DraftRequest(BaseModel):
    """A proposed pack version, cut from the one in force.

    `threshold_changes` may only touch thresholds the base pack already
    declares — adding one is a rule change and needs the rule written too, which
    is a content-authoring job rather than something a queue screen should do.
    """

    jurisdiction: str
    effective_from: date
    title: str = Field(min_length=1)
    rationale: str = Field(min_length=1)
    threshold_changes: dict = Field(default_factory=dict)
    event_ids: list[int] = Field(default_factory=list)


class SignRequest(BaseModel):
    """The gate. Only the note travels — the name comes from the session.

    There is deliberately no `signatory` field. It used to be one, and a name
    typed into a request body is not a signature: it is whatever the caller felt
    like writing, on a form that accepts any name in the firm. The signature is
    now the person holding the session, who had to present a credential minutes
    beforehand to get here.

    There is also deliberately no `publish` flag. It used to publish on signing,
    which meant the one person who signed rule content could also put it into
    force — the separation the signatory role exists to create, undone by a
    boolean. Publication is `POST /watch/drafts/{id}/publish` and belongs to
    somebody else.

    **`signed_content_hash` says which bytes were signed.** This docstring used
    to open "Only the note travels", and twenty lines below it
    `SecondReviewRequest` explained at length why a hash has to travel beside an
    attestation. Two classes, adjacent in one file, one bound and one not — and
    the auditor ran F1's own sequence through this one:

        the signatory reads `max_crypto_concentration_bps = 1000`
          -> its author, who holds `operator`, PATCHes it to 9999
          -> the signatory POSTs their signature

    200, with `content_hash` on the row taken over the author's edit, and it
    publishes: `SignedBytesChanged` guards signature -> publication and nothing
    guarded reading -> signature. So the caller sends back the
    `current_content_hash` that `view()` gave it beside the content it displayed.

    **No default**, mirroring `reviewed_content_hash` and for the reason this
    class has no `signatory` field: a caller that could omit it would be
    attesting to whatever happens to be there now. A required field makes that
    caller a 422 rather than a signature.
    """

    signed_content_hash: str = Field(min_length=1)
    note: str = ""


class SecondReviewRequest(BaseModel):
    """An independent read of content whose author intends to sign it.

    No `reviewer` field, for exactly the reason `SignRequest` has no
    `signatory`. This record's whole value is that somebody other than the
    author looked; a name in a request body is whatever the author felt like
    typing, and typing a colleague's name into it would reproduce the finding
    this route exists to close rather than fix it.

    **`reviewed_content_hash` says which bytes were read, and F1 is why.**
    B1 bound the review to the content on the row — but it hashed that content
    when the POST arrived, which is not the moment the reviewer read anything.
    The gap between the two is the reviewer's reading time, and it is minutes
    long for a rule pack:

        the reviewer opens the draft and reads
        `max_crypto_concentration_bps = 1000`
          -> its author, who holds `operator`, edits it to 9999
          -> the reviewer posts their approval
          -> the author signs their own draft

    Every check passed. `record_second_review` hashed the body it found, `sign`
    compared that hash to the same body and matched, and the row named a
    reviewer who had never seen the number. That is B1's own outcome reached
    through the ordinary workbench routes, and the auditor executed it.

    So the caller sends back the hash `view()` gave it beside the content it
    displayed, and the server refuses if the row has moved since. **No
    default**, for the reason `SignRequest` has no `signatory` field: a caller
    that omitted it would be attesting to whatever happens to be there now,
    which is precisely the thing being closed. A required field makes that
    caller a 422 instead of a signature.
    """

    reviewed_content_hash: str = Field(min_length=1)
    note: str = ""


class PublicationApprovalRequest(BaseModel):
    """One platform publisher agreeing that a signed draft should go live.

    This route had no request body at all until the census, which is how it came
    to be the third instance of F1's defect. `PublicationApproval.content_hash`
    was computed from the row when the POST arrived, so it recorded what was
    approved *as of the approval* rather than what the approver had read — and
    with no body, the approver had no way to say what they had read even if the
    recorder had asked.

    The window is wider than the signatory's because it spans the signature. A
    publisher reads a draft while it is `IN_REVIEW`, its author edits it, a
    signatory signs the edited body, and the approval lands on content the
    approver never saw — which then goes live for every firm under the regime.
    The auditor's edit was carried through both publication routes on this tree
    and reached `packs`.

    `approved_content_hash` is the `current_content_hash` from the `view()` the
    approver read. Required, with no default, for the reason every other field of
    this shape is: a caller that may omit it is approving whatever is there now.

    No `approver` field, for the reason `SignRequest` has no `signatory`. The
    approver is the account holding the session, and dual control that you can
    type a colleague's name into is not dual control.
    """

    approved_content_hash: str = Field(min_length=1)
    note: str = ""


class PublishRequest(BaseModel):
    """Putting signed content in front of every firm under a regime.

    Pressing publish counts as one of the two approvals a publication needs —
    `watch.drafts.publish` says so, and declines to make the publisher record a
    separate one first because that would be ceremony rather than control. Which
    means the publisher is an attester, and was in the same unbound window
    `PublicationApprovalRequest` describes: this route also took no body.

    `published_content_hash` is the `current_content_hash` from the `view()` the
    publisher read. Required, with no default.

    There is no note. A publication's record is the pack version it creates and
    the transition it writes; a free-text field here would be a second place to
    look for the same fact.
    """

    published_content_hash: str = Field(min_length=1)


class DraftEdit(BaseModel):
    """One edit to a draft's content, from the workbench.

    Whole sections rather than a patch. A specialist editing thresholds is
    replacing a table, not applying a diff to one — and a patch format would put
    a second representation of the content between what they see and what gets
    signed, which is the one place this product cannot afford ambiguity.

    Every field optional, so the workbench can save the section somebody touched
    without resending the rest. `None` means "leave it alone" rather than "clear
    it": clearing a pack's thresholds is a thing to do deliberately, not by
    omitting a key.
    """

    thresholds: dict | None = None
    rules: list | None = None
    reason_codes: dict | None = None
    notes: str | None = None


class AdvanceDecision(BaseModel):
    """Taking or declining a staged pack version.

    One shape for both, because the difference is the endpoint rather than the
    body. `note` is optional on taking — "we checked it and it is fine" needs no
    elaboration — and required on declining, which the handler enforces rather
    than the schema: the reason a version was refused is the thing that gets
    escalated, and an empty string is a decline nobody can act on.
    """

    note: str = ""


class ArtefactJobRequest(BaseModel):
    """One document asked for, of whichever shape its kind implies.

    A per-decision document needs a determination; a period document needs a
    period and a regime. One model with optional fields rather than two, because
    the caller is asking for "a document" and the endpoint validates which
    fields that kind actually requires — a client should not have to know which
    of our two internal shapes their document falls into.
    """

    kind: str
    decision_id: int | None = None
    period: str | None = None
    jurisdiction: str | None = None
    scenario: str | None = None
    #: For a document about one bulk sweep — §S8's delta report.
    run_id: int | None = None


class ArtefactBatchRequest(BaseModel):
    jobs: list[ArtefactJobRequest]


class RunRequest(BaseModel):
    """Ask for a book to be re-checked.

    Every field optional: the common case is "re-check everything under today's
    rules", and a caller should not have to spell that out. `client_ids` narrows
    it to a few people, which is what a profile change needs.
    """

    trigger: str | None = None
    jurisdiction: str | None = None
    client_ids: list[str] | None = None
    dry_run: bool | None = None
    note: str | None = None


class StageRequest(BaseModel):
    """A move along the adoption ladder.

    `signed_by` is optional and defaults to the signed-in person's own name:
    the account is recorded either way, and asking somebody to type their own
    name to confirm an action they are already authenticated for is ceremony.
    A different name is allowed because the person signing off may be senior to
    the person clicking, and that is worth being able to record honestly.
    """

    stage: str
    signed_by: str | None = None
    note: str | None = None


class IncumbentRow(BaseModel):
    """One outcome from a customer's own system, in their words."""

    client_id: str
    asset_id: str
    outcome: str
    as_of: str | None = None


class ComparisonIngest(BaseModel):
    rows: list[IncumbentRow]
    source: str | None = None
    #: How their vocabulary maps onto ours, when it is not one of the words we
    #: already know. Supplied by the customer rather than guessed at.
    vocabulary: dict[str, str] | None = None


class SecondFactorRequest(BaseModel):
    """The six digits from an authenticator app."""

    code: str


class SourceVerificationRequest(BaseModel):
    """A person recording that they checked a source nothing can poll."""

    #: The date they looked. Not defaulted to today: recording Friday's check on
    #: Monday is the normal case, and a silent default would quietly make the
    #: record say something the person did not.
    verified_on: date
    note: str | None = None
    #: A ticket, a document reference, a filename — wherever the proof lives.
    attachment_ref: str | None = None
