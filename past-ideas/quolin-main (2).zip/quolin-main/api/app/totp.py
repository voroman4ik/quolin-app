"""One-time codes, RFC 4226 and RFC 6238, written out rather than imported.

**Why this is not a dependency.** The usual choice here is `pyotp`, and the
argument for writing it instead is narrow: the algorithm is an HMAC, a big-endian
counter and a truncation rule, it is about forty lines, and both RFCs publish
test vectors that pin every line of it. `tests/test_totp.py` asserts against
those vectors, so this file is not trusted because it was read carefully — it is
trusted because the standard's own numbers come out of it. A dependency would
add a supply-chain surface to the login path in exchange for code we could not
check any harder than this.

That reasoning does not transfer to the password hash next door. Argon2 is a
memory-hard function with parameter choices that matter and no small set of
vectors that would catch getting them wrong, so that one is a dependency.

**What is deliberately configurable and what is not.** `digits` and `algorithm`
exist as parameters for one reason: the published vectors use eight digits and
three hash functions, and a generator that could not produce them could not be
checked against them. Enrolment always writes the six-digit SHA-1 default,
because that is what every authenticator app assumes and an issuer that quietly
used SHA-256 would produce a credential that scans and then never matches.

**Replay is not this module's problem, and it is a problem.** A code stays valid
for its whole window, so one read over a shoulder is usable for up to ninety
seconds across the accepted skew. `verify` returns the time step it matched, and
the caller is expected to store it and refuse anything at or below it — see
`mfa_credentials.last_used_counter`. Returning the step rather than a bare
boolean is what makes forgetting that awkward.

**The window has one knob and it is for laptops.** `QUOLIN_TOTP_WINDOW_STEPS`
widens the accepted skew so that a demo can be driven from a terminal and a
browser without retyping a code every thirty seconds. Unset — the deployed
configuration — is one step, and both deployment paths refuse the variable
rather than trusting anybody to unset it: `make deploy-check` for Fly,
`scripts/guard_task_credentials.py` for ECS. Widening it is a straight increase
in how long a stolen code stays usable, and it buys nothing in production.
"""

from __future__ import annotations

import base64
import hmac
import logging
import os
import secrets
import struct
import time

#: The window every authenticator app assumes.
PERIOD = 30

#: Steps of tolerance either side of now. One, not three: each extra step is
#: another thirty seconds in which a code read over a shoulder still works, and
#: one step already covers a phone clock a little out and a user typing slowly.
#:
#: This is the production value and the only value a deployed instance may run
#: with. `SKEW_STEPS` below may widen it for a laptop; see the note there.
SKEW_STEPS_DEFAULT = 1

#: The one knob that widens the accepted window, and it is a local-development
#: knob. Unset is the production configuration, which is why the guards check
#: for *presence* rather than for a value: absence is already correct.
WINDOW_ENV = "QUOLIN_TOTP_WINDOW_STEPS"

#: A ceiling on the knob, because `verify` walks every step in the window and a
#: fat-fingered `100000` would turn one login attempt into two hundred thousand
#: HMACs. Ten minutes either side is already far past anything a demo needs.
MAX_SKEW_STEPS = 20


def _skew_steps_from_env() -> int:
    """`SKEW_STEPS` from the environment, falling back to the safe value.

    Every path that is not an integer in range returns the production default,
    including a typo. This is deliberately not a startup failure: the variable
    only ever exists on a laptop, and a login path that refuses to start
    because a developer wrote `ten` is a worse outcome than a demo with a
    thirty-second window. The warning says which happened.
    """
    raw = os.getenv(WINDOW_ENV, "").strip()
    if not raw:
        return SKEW_STEPS_DEFAULT
    try:
        steps = int(raw)
    except ValueError:
        logging.getLogger(__name__).warning(
            "%s=%r is not an integer; using the default of %d step(s)",
            WINDOW_ENV,
            raw,
            SKEW_STEPS_DEFAULT,
        )
        return SKEW_STEPS_DEFAULT
    if steps < 0:
        logging.getLogger(__name__).warning(
            "%s=%r is negative, which would refuse every code; using the "
            "default of %d step(s)",
            WINDOW_ENV,
            raw,
            SKEW_STEPS_DEFAULT,
        )
        return SKEW_STEPS_DEFAULT
    if steps > MAX_SKEW_STEPS:
        logging.getLogger(__name__).warning(
            "%s=%d exceeds the ceiling of %d; using %d",
            WINDOW_ENV,
            steps,
            MAX_SKEW_STEPS,
            MAX_SKEW_STEPS,
        )
        return MAX_SKEW_STEPS
    if steps != SKEW_STEPS_DEFAULT:
        logging.getLogger(__name__).warning(
            "%s=%d: the one-time-code window is widened to +/-%d seconds. This "
            "is a local development setting and must never be set in a "
            "deployed environment.",
            WINDOW_ENV,
            steps,
            steps * PERIOD,
        )
    return steps


#: Read once, at import. A per-request read would let the window change under a
#: running process, which is a thing to be able to say did not happen.
SKEW_STEPS = _skew_steps_from_env()

DIGITS = 6

#: Twenty bytes, which is what RFC 4226 specifies and what the QR-code format
#: every app reads expects. Longer is not stronger here — the output is
#: truncated to six digits either way.
SECRET_BYTES = 20


def new_secret() -> str:
    """A fresh shared secret, base32, unpadded.

    Unpadded because the `otpauth://` URI format has no place for `=` and apps
    that receive one variously ignore it, reject it, or treat it as part of the
    secret. `decode` puts the padding back.
    """
    return base64.b32encode(secrets.token_bytes(SECRET_BYTES)).decode().rstrip("=")


def decode(secret: str) -> bytes:
    """Base32 back to bytes, tolerant of the ways a human retypes a secret.

    Spaces are how authenticator apps display it, lowercase is how a browser
    autofills it, and both are the same secret.
    """
    cleaned = secret.replace(" ", "").replace("-", "").upper()
    padding = "=" * (-len(cleaned) % 8)
    return base64.b32decode(cleaned + padding)


def _hotp(key: bytes, counter: int, *, digits: int, algorithm: str) -> str:
    """RFC 4226 section 5.3, and nothing else.

    The truncation looks arbitrary and is not: the low four bits of the last
    byte choose a four-byte window into the digest, and the top bit of that
    window is masked off so the value is positive in languages with signed
    integers. Reproducing it exactly is why the RFC's vectors are in the tests.
    """
    digest = hmac.new(key, struct.pack(">Q", counter), algorithm).digest()
    offset = digest[-1] & 0x0F
    truncated = struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFF_FFFF
    return str(truncated % (10**digits)).zfill(digits)


def code_at(
    secret: str,
    at: float | None = None,
    *,
    digits: int = DIGITS,
    algorithm: str = "sha1",
    period: int = PERIOD,
) -> str:
    """The code for a moment. Used by the tests and by the enrolment preview."""
    now = time.time() if at is None else at
    return _hotp(decode(secret), int(now // period), digits=digits, algorithm=algorithm)


def verify(
    secret: str,
    presented: str,
    *,
    after_counter: int = 0,
    at: float | None = None,
    digits: int = DIGITS,
    algorithm: str = "sha1",
    period: int = PERIOD,
) -> int | None:
    """The time step the code matched, or None.

    `after_counter` is the replay guard: a step at or below it is refused even
    when the arithmetic matches, because that code has already been spent. The
    caller stores the returned step.

    The comparison is constant-time. A code is only six digits, so a timing
    oracle that leaked how many leading digits were right would reduce a
    million guesses to sixty — and the rate limit that would otherwise cover
    this counts attempts, not bytes.
    """
    if not presented or not presented.isdigit():
        return None

    now = time.time() if at is None else at
    current = int(now // period)
    key = decode(secret)

    # Oldest first, so a code that matches two steps (which cannot happen, but
    # would if `digits` were ever made small) resolves to the one already spent
    # and is then refused by the guard rather than accepted as new.
    #
    # ---------------------------------------------------------------------
    # SKEW_STEPS IS ONE IN A DEPLOYED ENVIRONMENT. NEVER WIDEN IT THERE.
    #
    # Each step is another thirty seconds either side of now in which a code
    # read over a shoulder, left on a screen, or captured in transit is still
    # accepted. `QUOLIN_TOTP_WINDOW_STEPS=10` is a five-minute replay window on
    # the second factor — acceptable on a laptop nobody is attacking, and a
    # downgrade of the factor anywhere else.
    #
    # Two guards exist so this cannot leak:
    #   * `make deploy-check` refuses to deploy to Fly if the variable is set
    #     on the app at all, since absence is the correct configuration.
    #   * `scripts/guard_task_credentials.py` is an allow-list of the variables
    #     each ECS task may hold, and this one is deliberately not in it, so
    #     adding it to a task definition fails `make guard`.
    # If you add a third place a deployment reads environment from, guard it
    # there too before this comment stops being true.
    # ---------------------------------------------------------------------
    for step in range(current - SKEW_STEPS, current + SKEW_STEPS + 1):
        if step <= after_counter:
            continue
        expected = _hotp(key, step, digits=digits, algorithm=algorithm)
        if hmac.compare_digest(expected, presented):
            return step
    return None


def provisioning_uri(secret: str, *, account: str, issuer: str = "Quolin") -> str:
    """The `otpauth://` URI an authenticator app scans.

    Assembled by hand rather than with `urllib.parse.urlencode` because the
    label before the query string is itself path-encoded and the two halves
    escape differently — `urlencode` would produce a URI that most apps accept
    and some silently read the issuer out of wrongly.
    """
    from urllib.parse import quote

    label = f"{quote(issuer)}:{quote(account)}"
    query = f"secret={secret}&issuer={quote(issuer)}&algorithm=SHA1&digits={DIGITS}&period={PERIOD}"
    return f"otpauth://totp/{label}?{query}"
