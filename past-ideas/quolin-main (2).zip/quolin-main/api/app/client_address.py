"""Where a request came from, decided in exactly one place.

FP3-02. There were two answers to this question in the codebase and both were
wrong in the same way: `main._client_ip` and the token endpoint in `v1.py` each
read `X-Forwarded-For` and took `forwarded.split(",")[0]`.

A proxy **appends**. The real client ends up at the *end* of that header and the
first entry is whatever the caller sent, so `[0]` let a caller pick their own
rate-limit bucket. Reproduced against the shape an ALB produces —
`X-Forwarded-For: 10.0.0.<n>, <real address>` — thirty consecutive failed
sign-ins reached no limit at all, against eight without the header, and
`auth_attempts` recorded thirty distinct attacker-chosen addresses.

Nothing here parses that header any more. `uvicorn` is run with
`--proxy-headers --forwarded-allow-ips=<the VPC CIDR>`; its middleware walks the
header from the right and stops at the first entry that is not a trusted proxy,
rewriting `scope["client"]`. This reads the result. The trust boundary is
configuration in one place — `QUOLIN_TRUSTED_PROXY_CIDRS`, set by the task
definition from `var.vpc_cidr` and defaulted in the Dockerfile — instead of an
assumption inside a function.

**`--forwarded-allow-ips='*'` is not a laxer version of this. It is the bug.**
uvicorn's own `get_trusted_client_address` returns `x_forwarded_for_hosts[0]`
when everything is trusted, which is precisely the spoofable entry. Trusting
every proxy means trusting the client.
"""

from __future__ import annotations

from fastapi import Request


def client_ip(request: Request) -> str:
    """The caller's address, as the ASGI server resolved it."""
    return request.client.host if request.client else "unknown"


def forwarded_header(request: Request) -> str | None:
    """The raw `X-Forwarded-For`, for the forensic column and nothing else.

    Never an input to a decision. It is recorded because a header that disagrees
    with the resolved address is worth being able to look at afterwards — a
    spoofed one is itself a signal, and the chain a real proxy writes is how a
    CDN is told from a botnet.
    """
    return request.headers.get("x-forwarded-for") or None
