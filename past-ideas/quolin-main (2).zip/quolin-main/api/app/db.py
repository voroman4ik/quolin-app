from __future__ import annotations

import os

from sqlalchemy import create_engine, event
from sqlalchemy.engine import Connection
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from .tenancy import current_tenant_or_none, current_user_or_none

# Two URLs, two roles, and the difference between them is the whole of tenant
# isolation.
#
# OWNER_DATABASE_URL owns the schema. Migrations run as it, the seed runs as it,
# and it is the role that can create a table, drop a policy, or disable a
# trigger. Nothing serving a request uses it.
#
# APP_DATABASE_URL is what the API connects as. That role is deliberately not a
# superuser, does not own the tables, and does not hold BYPASSRLS — because
# every one of those three attributes silently switches row-level security off.
# A policy that is present and inert is worse than no policy, since it reads as
# protection in a diligence questionnaire.
#
# There is no fallback from one to the other. A missing APP_DATABASE_URL is a
# misconfiguration that must be loud, and `tests/test_rls.py` asserts the
# effective role's attributes rather than trusting this comment.
OWNER_DATABASE_URL = os.getenv(
    "DATABASE_URL", "postgresql+psycopg://quolin:quolin@localhost:5433/quolin"
)

#: Whether the value above was actually supplied, or is this file's guess.
#:
#: FP3-04. That default is what made two separate findings quiet. It is why the
#: watch sweep's call into the owner engine failed in production with
#: `connection refused` rather than `no DATABASE_URL`, and it is why
#: `infra/compute.tf` could carry a comment claiming the API would "fall back to
#: the owner connection" — what it falls back to is a hardcoded address that
#: happens to be a developer's database, which is a different and more confusing
#: failure than an escalation.
#:
#: The default is kept, because a laptop and CI both run against
#: `localhost:5433` and neither should have to say so, and because `owner_engine`
#: is constructed at module scope and bound by three `event.listens_for`
#: decorators — making it lazy to enforce this would be a large change to the
#: transaction machinery in service of a check that belongs somewhere narrower.
#:
#: `app/owner_only.py` is that narrower place: it refuses to import unless
#: `DATABASE_URL` was genuinely supplied, and it holds the only two things in
#: `api/app` that need the owner. So the guess still exists and nothing that
#: serves a request can act on it.
OWNER_URL_IS_A_GUESS = os.getenv("DATABASE_URL") is None

#: Whether an owner connection was supplied at all, for `app/owner_only.py`.
#:
#: F2. That module asked `os.getenv("DATABASE_URL")` itself, which meant the
#: name of the key was written in two files under `api/app` — and the guard's
#: third rule now forbids naming it anywhere but here. A module that can read
#: the key can build its own engine, so forbidding the door and allowing the key
#: is forbidding the handle and leaving the hinges.
#:
#: Deliberately `bool(...)` rather than `is not None`, because that is the test
#: `owner_only` made and an empty `DATABASE_URL` is not a connection.
OWNER_URL_WAS_SUPPLIED = bool(os.getenv("DATABASE_URL"))
APP_DATABASE_URL = os.getenv(
    "APP_DATABASE_URL", "postgresql+psycopg://quolin_app:quolin_app@localhost:5433/quolin"
)

#: How many requests this process will work on at once.
#:
#: §S12 found this the hard way. The pool was on SQLAlchemy's defaults — five
#: connections plus ten overflow — while Starlette ran sync endpoints in a
#: forty-thread pool. Twenty concurrent users turned a 14ms determination into a
#: 384ms one, and sustained load produced `QueuePool limit of size 5 overflow 10
#: reached, connection timed out, timeout 30.00`: twenty-five threads with work
#: to do and no connection to do it with, each waiting half a minute to find
#: out.
#:
#: The fix is not a bigger number. It is that **the two numbers have to be the
#: same number**. A request that has been admitted must be able to get a
#: connection; if it cannot, the admission was a lie and the queue has simply
#: moved somewhere with a worse error message. So this one value sets both the
#: thread limiter (see `app/main.py`) and the pool below, and neither may be
#: raised without the other.
#:
#: Twenty-four rather than forty: each connection is a Postgres backend with its
#: own memory, and `db.t4g.medium` has a max_connections in the low hundreds
#: shared with the workers, the migrations and whoever is holding a psql prompt.
MAX_CONCURRENT_REQUESTS = int(os.getenv("QUOLIN_MAX_CONCURRENT_REQUESTS", "24"))

#: Connections beyond the admitted-request budget, for work in this process that
#: is not a request: the status page's own probe, and anything else that opens a
#: session outside a handler. Small and deliberate — it is headroom, not a
#: second pool.
_POOL_HEADROOM = 4

engine = create_engine(
    APP_DATABASE_URL,
    future=True,
    pool_pre_ping=True,
    pool_size=MAX_CONCURRENT_REQUESTS + _POOL_HEADROOM,
    # No overflow. Overflow is a pool that grows past the size somebody reasoned
    # about, under exactly the conditions where the reasoning mattered — and the
    # connections it opens are real Postgres backends that the database was not
    # sized for either.
    max_overflow=0,
    # Five seconds, not thirty. With the limiter above, a request should never
    # wait here at all; if one does, something has opened sessions this file did
    # not account for, and the useful outcome is a fast, loud failure rather
    # than a handler that returns in half a minute and looks like a slow query.
    pool_timeout=5,
    # RDS drops idle connections, and a pool holding dead ones fails the first
    # request after a quiet night. `pool_pre_ping` catches that too; recycling
    # means it is usually never reached.
    pool_recycle=1800,
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, future=True)

# WATCH_DATABASE_URL is what the watch service connects as, and the role behind
# it cannot write the `packs` table — not by convention, by grant. Stage 6 makes
# the separation a property of the database rather than of our code: the guard
# script and the signature check in `drafts.publish` are both good and both are
# statements about code somebody with a shell can edit.
#
# Defaulted rather than required, unlike the two above, and the difference is
# deliberate. A missing APP_DATABASE_URL is a misconfiguration that must be
# loud. A missing WATCH_DATABASE_URL in a dev shell means the sweep runs with
# more privilege than it needs, which is worth a warning and not worth refusing
# to start — the environments where it matters set it, and `test_watch_role.py`
# asserts the role's privileges directly rather than trusting this line.
WATCH_DATABASE_URL = os.getenv(
    "WATCH_DATABASE_URL",
    "postgresql+psycopg://quolin_watch:quolin_watch@localhost:5433/quolin",
)
watch_engine = create_engine(WATCH_DATABASE_URL, future=True, pool_pre_ping=True)
WatchSessionLocal = sessionmaker(
    bind=watch_engine, autoflush=False, expire_on_commit=False, future=True
)

# The schema-owning engine. Imported by the seed and the migration environment
# and by nothing that answers an HTTP request.
owner_engine = create_engine(OWNER_DATABASE_URL, future=True, pool_pre_ping=True)
OwnerSessionLocal = sessionmaker(
    bind=owner_engine, autoflush=False, expire_on_commit=False, future=True
)


#: The Postgres setting every row-level security policy reads.
TENANT_SETTING = "app.tenant_id"

#: The setting the `session_self` policy on `auth_sessions` reads. Set only
#: while resolving a cookie to a session row — the one operation that has to
#: happen before a tenant is known, because it is what determines the tenant.
#: See the note in migration 0003.
TOKEN_SETTING = "app.session_token"

#: The person this transaction acts for. Read by the policies on the identity
#: tables, which are not tenant-scoped and so cannot be governed by the setting
#: above. See migration 0007.
USER_SETTING = "app.user_id"

#: Set only while turning a submitted email address into a user id — the one
#: step of sign-in that must happen before either of the other two settings can
#: be known, because it is what determines them. The same shape as TOKEN_SETTING
#: and for the same reason: a table whose rows are invisible until you know who
#: you are cannot tell you who you are.
LOGIN_EMAIL_SETTING = "app.login_email"

#: The pair set only while turning an identity provider's assertion into a user
#: id. The federated twin of LOGIN_EMAIL_SETTING and needed for the same reason:
#: `user_identities` is invisible until `app.user_id` is set, and the row being
#: looked up is what determines `app.user_id`.
#:
#: Two settings rather than one joined value, because `sub` is opaque — a
#: provider may put anything in it, including whatever separator a combined key
#: chose. Two predicates ANDed together cannot be confused by its contents.
#: See migration 0009.
LOGIN_ISSUER_SETTING = "app.login_issuer"
LOGIN_SUBJECT_SETTING = "app.login_subject"


@event.listens_for(engine, "begin")
@event.listens_for(watch_engine, "begin")
@event.listens_for(owner_engine, "begin")
def _bind_tenant_to_transaction(conn: Connection) -> None:
    """Tell Postgres which tenant this transaction is for, on every transaction.

    Hung off the engine's `begin` event rather than the request dependency for
    two reasons.

    The first is that a request is not one transaction. Handlers commit part-way
    through, and `set_config(..., true)` is transaction-scoped — so a value set
    once at the start of a request would silently vanish at the first commit and
    every statement after it would see nothing. Setting it per transaction means
    there is no such thing as a transaction without a tenant.

    The second is pooling. Transaction-scoped is the *point*: a connection
    returned to the pool carries no trace of who last used it. Setting the value
    at session scope would be one careless `close()` away from the next request
    inheriting the previous request's tenant, which is the exact failure this
    whole mechanism exists to make impossible.

    An empty string when no tenant is in scope, not NULL and not a skipped call.
    `tenant_id = ''` matches nothing, so a connection that has not said who it is
    sees an empty database rather than whatever the last one saw.
    """
    conn.exec_driver_sql(
        # Three settings, one round trip. The acting person is bound here too,
        # with the same empty-string default and for the same reasons; the two
        # values have different lifetimes, since a scheduled poll has a tenant
        # and no user and sign-in briefly has a user and no tenant.
        #
        # `timezone` is the third and is not about tenancy at all. Q-03: the
        # evidence chain hashed `created_at.isoformat()`, and psycopg renders a
        # `timestamptz` with the offset of *this setting*, which nothing pinned.
        # A chain written under UTC and verified under `Australia/Sydney` — the
        # primary region in `infra/` — reported `verified=False checked=0` on
        # every tenant, and the runbook treats a chain failure as a security
        # incident. `evidence._utc_isoformat` is the actual fix and makes the
        # payload independent of this; pinning the setting as well means a
        # pooler or parameter-group change cannot surprise anything *else* that
        # reads a timestamp either.
        #
        # Transaction-scoped like the other two, so a connection returned to the
        # pool carries no trace of it.
        "SELECT set_config(%s, %s, true), set_config(%s, %s, true), "
        "set_config('timezone', 'UTC', true)",
        (
            TENANT_SETTING,
            current_tenant_or_none() or "",
            USER_SETTING,
            current_user_or_none() or "",
        ),
    )


class Base(DeclarativeBase):
    pass


def get_session():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
