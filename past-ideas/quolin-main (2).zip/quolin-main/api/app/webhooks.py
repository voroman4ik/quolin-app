"""Telling a customer's own systems what happened, and proving we tried.

The execution document phrases the requirement as "alerts land in the queue they
already watch". That sentence is the whole design: a compliance officer has a
case system, and a determination that only exists in our console is one they
have to remember to come and look at. The console queue is the fallback, not the
channel.

**Delivery is out of band, always.** `enqueue` writes rows and returns; nothing
in a request path opens a socket. A determination must not fail, or wait,
because a customer's endpoint is slow or down — the decision has been made and
recorded, and telling somebody about it is a separate obligation with a separate
failure mode. `scripts/deliver_webhooks.py` is what actually sends.

**The delivery log is a log, not a queue.** A queue is empty when the work is
done, which means a delivery that failed four times and eventually succeeded
leaves no trace of having been late. "Did you tell us about decision 4,182, and
when" is a question a customer will ask, and the row has to still be there.

**Dead-lettering is visible on purpose.** The gate for this stage is that
delivery survives a dead endpoint — retries, then dead-letters *visibly*. A
silently dropped alert is worse than one that never existed, because the
customer believes they are being told. A dead delivery stays in the log with its
last error, and `/v1/webhooks/deliveries` will show it to them.

**Signing.** HMAC-SHA256 over `{timestamp}.{body}`, with the timestamp in the
signed material rather than only in a header — a signature over the body alone
is replayable forever by anyone who captures one. The receiver checks both, and
`docs/integrations.md` says so in the words their engineer needs.
"""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import os
import secrets
import socket
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import urlparse

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import WebhookDelivery, WebhookEndpoint

#: The events a tenant may subscribe to. Named after what happened rather than
#: after which table changed: an integration should not have to know our schema
#: to know what it is being told.
EVENTS = (
    "decision.recorded",
    "decision.overridden",
    "queue.referred",
    "pack.staged",
    "pack.published",
    # FP3-17. A pinned firm's review window has closed and they are still on the
    # old version. Once a day, per overdue pack, until they advance — the state
    # is not an error and the notification is not an alarm, but a firm operating
    # on superseded rules without knowing is the thing this exists to prevent.
    "pack.review_overdue",
    "source.stale",
    # Stage 7. A document a customer asked for is finished and downloadable.
    # The one event here that closes a loop the customer opened: they queued a
    # return, and this is how their system learns it exists without polling.
    "artefact.ready",
    # And the other half, which matters more. A document that was asked for and
    # never produced is exactly what a customer must not have to notice for
    # themselves at the end of a reporting period.
    "artefact.failed",
    # Stage 8. A sweep of the book finished, and this is the one event it sends
    # — not one per determination. The payload carries what moved, because
    # "your book was re-checked" is not news and "212 clients moved to REFER"
    # is.
    "bulk.completed",
)

#: How many times a delivery is attempted before it is declared dead. Six
#: attempts on the backoff below spans about half an hour, which is long enough
#: to ride out a deploy at the other end and short enough that a genuinely dead
#: endpoint is visible within the working day it broke.
MAX_ATTEMPTS = 6

#: Exponential, in seconds, one entry per attempt already made. Capped rather
#: than doubling forever: an endpoint that has been down for an hour is not going
#: to be fixed by waiting two.
BACKOFF_SECONDS = (30, 120, 300, 900, 1800, 3600)

#: How long a receiver has to answer. Short, because a slow endpoint is a failed
#: one from our side — we cannot hold a worker open while somebody's case system
#: thinks about it, and the retry is the mechanism for that.
TIMEOUT_SECONDS = 10.0

SIGNATURE_HEADER = "X-Quolin-Signature"
EVENT_HEADER = "X-Quolin-Event"
DELIVERY_HEADER = "X-Quolin-Delivery"


#: Where a delivery can be. Strings until now, which was fine while one module
#: wrote them and nothing read them back — the console and the redelivery route
#: both do now, and a typo'd literal in either would silently match nothing.
PENDING = "pending"
DELIVERED = "delivered"
DEAD = "dead"
STATUSES = (PENDING, DELIVERED, DEAD)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def new_secret() -> str:
    """Signing material for a new endpoint. Shown once, stored encrypted."""
    return f"whsec_{secrets.token_urlsafe(32)}"


def canonical(payload: dict[str, Any]) -> str:
    """The exact bytes that are signed and sent.

    Sorted keys and no incidental whitespace, so that the string a receiver
    verifies is the string we signed. A payload serialised one way for signing
    and another way for sending is the single most common reason a customer's
    first webhook integration does not work, and it is our fault when it happens.
    """
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def sign(secret: str, body: str, *, at: datetime | None = None) -> str:
    """`t=<unix>,v1=<hex>` — the timestamp is inside the signed material.

    A signature over the body alone is replayable forever by anyone who captures
    one. Including the timestamp lets a receiver reject anything older than their
    tolerance, which is the difference between authentication and a password
    written on the outside of the envelope.
    """
    stamp = int((at or _now()).timestamp())
    digest = hmac.new(
        secret.encode(), f"{stamp}.{body}".encode(), hashlib.sha256
    ).hexdigest()
    return f"t={stamp},v1={digest}"


def verify(secret: str, body: str, header: str, *, tolerance_seconds: int = 300) -> bool:
    """The check a receiver performs, implemented here so it can be tested.

    Written into the product rather than only into the documentation, because a
    signing scheme nobody has verified from the other side is a signing scheme
    with an off-by-one in it. `test_webhooks.py` uses this to check our own
    signatures, which means the documented algorithm and the shipped one cannot
    drift.
    """
    parts = dict(
        piece.split("=", 1) for piece in header.split(",") if "=" in piece
    )
    try:
        stamp = int(parts["t"])
        given = parts["v1"]
    except (KeyError, ValueError):
        return False

    if abs(int(_now().timestamp()) - stamp) > tolerance_seconds:
        return False

    expected = hmac.new(
        secret.encode(), f"{stamp}.{body}".encode(), hashlib.sha256
    ).hexdigest()
    # Constant-time: a byte-by-byte comparison of a MAC is a forgery oracle for
    # anyone who can measure it.
    return hmac.compare_digest(given, expected)


# ------------------------------------------------------------------ enqueue --


def endpoints_for(session: Session, event: str) -> list[WebhookEndpoint]:
    """Active endpoints in this tenant that want this event.

    An endpoint with an empty `events` list wants all of them — a tenant that
    has not chosen wants to hear everything rather than nothing, which is the
    safe default for an alerting channel.
    """
    return [
        row
        for row in session.scalars(
            select(WebhookEndpoint).where(WebhookEndpoint.status == "active")
        )
        if not row.events or event in row.events
    ]


def enqueue(
    session: Session, *, event: str, subject: str, payload: dict[str, Any]
) -> list[WebhookDelivery]:
    """Record that this needs sending. Sends nothing.

    Returns the rows it created so a caller can assert on them; almost nothing
    does, because the interesting question is answered by the delivery log rather
    than by the return value.

    An unknown event name raises. The alternative is a typo that silently
    subscribes nobody, and a customer who is not being told about a thing they
    asked to be told about — which is exactly the failure this module exists to
    make impossible.
    """
    if event not in EVENTS:
        raise ValueError(
            f"unknown webhook event {event!r}. Known events: {', '.join(EVENTS)}"
        )

    from .identity import new_id

    created = []
    for endpoint in endpoints_for(session, event):
        row = WebhookDelivery(
            id=new_id("whd"),
            endpoint_id=endpoint.id,
            event=event,
            subject=subject,
            payload=payload,
            status=PENDING,
            attempts=0,
            # Due immediately. The worker decides when it actually runs; this
            # says the delivery is not deliberately deferred.
            next_attempt_at=_now(),
            created_at=_now(),
        )
        session.add(row)
        created.append(row)
    session.flush()
    return created


# ----------------------------------------------------------------- delivery --


def due(session: Session, *, now: datetime | None = None, limit: int = 100) -> list:
    """Deliveries ready to be attempted, oldest first.

    Oldest first so that a backlog drains in the order things happened. A
    customer reading their case system should see a determination before the
    override that reversed it.
    """
    when = now or _now()
    rows = session.scalars(
        select(WebhookDelivery)
        .where(WebhookDelivery.status == "pending")
        .order_by(WebhookDelivery.created_at)
    ).all()
    return [r for r in rows if r.next_attempt_at is None or r.next_attempt_at <= when][:limit]


def attempt(
    session: Session,
    delivery: WebhookDelivery,
    endpoint: WebhookEndpoint,
    *,
    send,
    now: datetime | None = None,
) -> WebhookDelivery:
    """One attempt at one delivery, and what it does to the row.

    `send` is injected rather than imported, and that is what makes the retry
    logic testable without a socket: the tests pass an endpoint that fails four
    times and then succeeds, and assert the row's journey through it. A module
    that reached for `httpx` directly could only be tested against a server
    somebody had to run.

    `send(url, body, headers) -> int` returns the status code, or raises for a
    transport failure. Both are handled: a 500 and a refused connection are the
    same fact from the customer's point of view.
    """
    when = now or _now()
    body = canonical(delivery.payload)
    headers = {
        "Content-Type": "application/json",
        EVENT_HEADER: delivery.event,
        DELIVERY_HEADER: delivery.id,
        SIGNATURE_HEADER: sign(endpoint.secret, body, at=when),
    }

    delivery.attempts += 1
    try:
        status = send(endpoint.url, body, headers)
        delivery.last_status_code = status
        # Any 2xx is success. A receiver that answers 204 has taken it; one that
        # answers 302 has not, whatever it meant by that.
        if 200 <= status < 300:
            delivery.status = DELIVERED
            delivery.delivered_at = when
            delivery.next_attempt_at = None
            delivery.last_error = ""
            session.flush()
            return delivery
        delivery.last_error = f"HTTP {status}"
    except Exception as exc:
        delivery.last_status_code = None
        delivery.last_error = f"{type(exc).__name__}: {exc}"[:1000]

    if delivery.attempts >= MAX_ATTEMPTS:
        # Dead, and staying in the log saying so. The gate for this stage is that
        # this is *visible*: a customer must be able to see that we tried six
        # times over half an hour and their endpoint never answered.
        delivery.status = DEAD
        delivery.next_attempt_at = None
    else:
        wait = BACKOFF_SECONDS[min(delivery.attempts - 1, len(BACKOFF_SECONDS) - 1)]
        delivery.next_attempt_at = when + timedelta(seconds=wait)
    session.flush()
    return delivery


# ---------------------------------------------------------------- targets --
#
# A webhook is a URL a customer chooses and this system fetches on their behalf,
# from inside the network the database is in. That is the shape of every
# server-side request forgery, and the prize is usually one address:
# `169.254.169.254`, which every cloud provider serves instance credentials
# from.
#
# There is no registration route today — endpoints are rows created by the seed,
# by tests and by the game-day drill — so nothing a customer sends reaches this.
# The check is here anyway, and here specifically, because a registration screen
# is an obvious next feature and a validator on a form is one somebody routes
# around. This is the check the request cannot avoid, and it is the only place
# that can catch a redirect or a DNS answer that changed after registration.

#: Schemes this may fetch. Everything else — `file:`, `gopher:`, `ftp:` — is a
#: different protocol reached through the same string, which is the other half
#: of this class of bug.
ALLOWED_SCHEMES = ("https", "http")

#: Whether a private address is a legitimate destination here.
#:
#: `make webhook-receiver` runs a listener on localhost so a customer's engineer
#: has a working example of the signature check, and the demo posts to it.
#: Explicit rather than inferred from `QUOLIN_ENVIRONMENT`, so a deployed
#: instance cannot acquire the exception by having its environment name set to
#: something unexpected.
ALLOW_PRIVATE_ENV = "QUOLIN_WEBHOOK_ALLOW_PRIVATE"


class UnsafeTarget(ValueError):
    """A webhook target that would have reached somewhere it should not.

    A `ValueError` rather than a bespoke hierarchy because `attempt` already
    treats any exception from the sender as a failed delivery — so a poisoned
    row dead-letters and the rest of the queue is worked, which is what a worker
    needs to do with one bad endpoint.
    """


def _private_permitted() -> bool:
    return os.getenv(ALLOW_PRIVATE_ENV, "").strip().lower() in ("1", "true", "yes")


def validate_target(url: str) -> None:
    """Raise `UnsafeTarget` unless this is somewhere we may post to.

    **Resolved, not pattern-matched.** A perfectly ordinary hostname that
    answers with `169.254.169.254` is the same attack as writing the address
    down, and a string check does not see it. So the name is resolved and every
    address it answers with has to be a public one — every address, because a
    host with one public answer and one link-local answer is a host that decides
    which one you get.

    **Unresolvable is a refusal.** A name nothing can resolve is either a typo
    or a target waiting to be given an address later, and neither is a reason to
    attempt the request.
    """
    parsed = urlparse((url or "").strip())
    if parsed.scheme not in ALLOWED_SCHEMES:
        raise UnsafeTarget(
            f"{parsed.scheme or 'no'} is not a scheme this may fetch. Webhooks are "
            f"delivered over {' or '.join(ALLOWED_SCHEMES)}."
        )
    host = parsed.hostname
    if not host:
        raise UnsafeTarget(f"{url!r} names no host.")

    try:
        answers = socket.getaddrinfo(host, parsed.port or 0, proto=socket.IPPROTO_TCP)
    except (socket.gaierror, UnicodeError, ValueError) as exc:
        raise UnsafeTarget(f"{host!r} does not resolve: {exc}") from exc
    if not answers:
        raise UnsafeTarget(f"{host!r} resolves to nothing.")

    permitted = _private_permitted()
    for *_ignored, sockaddr in answers:
        address = ipaddress.ip_address(sockaddr[0])
        if address.is_global and not address.is_multicast:
            continue
        if permitted and (address.is_private or address.is_loopback):
            continue
        raise UnsafeTarget(
            f"{host!r} resolves to {address}, which is inside the network this "
            "system runs in. A webhook is delivered to a customer's system, not "
            "to ours — a link-local address in particular is where a cloud "
            "provider serves instance credentials."
        )


def http_sender(timeout: float = TIMEOUT_SECONDS):
    """The real sender. Separated so the retry logic above can be exercised
    without a network."""

    def send(url: str, body: str, headers: dict[str, str]) -> int:
        # Before the request, every time — not once at registration. DNS answers
        # change and a target can redirect, and both happen after whatever
        # validated the URL when it was written down.
        validate_target(url)
        response = httpx.post(
            url,
            content=body,
            headers=headers,
            timeout=timeout,
            # A 302 to `http://169.254.169.254/` would otherwise walk straight
            # past the check above, which was made on the URL we were given.
            follow_redirects=False,
        )
        return response.status_code

    return send


def run_once(session: Session, *, send=None, now: datetime | None = None) -> dict[str, int]:
    """Attempt everything that is due. What a worker or a cron entry calls."""
    sender = send or http_sender()
    endpoints = {e.id: e for e in session.scalars(select(WebhookEndpoint))}

    tally = {"attempted": 0, "delivered": 0, "dead": 0, "retrying": 0}
    for delivery in due(session, now=now):
        endpoint = endpoints.get(delivery.endpoint_id)
        if endpoint is None:
            # The endpoint was deleted while a delivery was queued. Not an error
            # and not a retry: there is nowhere to send it, and saying so is
            # better than leaving it pending forever.
            delivery.status = DEAD
            delivery.last_error = "endpoint no longer exists"
            delivery.next_attempt_at = None
            tally["dead"] += 1
            continue
        attempt(session, delivery, endpoint, send=sender, now=now)
        tally["attempted"] += 1
        if delivery.status == "delivered":
            tally["delivered"] += 1
        elif delivery.status == "dead":
            tally["dead"] += 1
        else:
            tally["retrying"] += 1
    session.commit()
    return tally


def revive(session: Session, delivery: WebhookDelivery) -> WebhookDelivery:
    """Put a dead delivery back on the queue, once.

    §S9's webhook-storm runbook ends with "replay the dead deliveries once they
    have fixed it", and until now that meant somebody with database access
    editing a status column. An operator action that requires a psql prompt is
    an operator action that happens at 3am, by hand, with no record.

    **The attempt count is reset.** A revived delivery gets the full backoff
    again, because the customer has told us their endpoint is fixed and the
    schedule that gave up on it was measuring a different world. Leaving the
    count would mean one more attempt and then dead again, which reads as "we
    tried" and is not trying.

    **Only a dead one.** Reviving something already pending would double it, and
    reviving something delivered would send a customer a second copy of an event
    they have already acted on — which for a determination that referred a
    client is a duplicate case in their queue.
    """
    if delivery.status != DEAD:
        raise ValueError(
            f"delivery {delivery.id} is {delivery.status}, not dead. Only a "
            "delivery that gave up can be put back — reviving a live one would "
            "send it twice."
        )
    delivery.status = PENDING
    delivery.attempts = 0
    delivery.next_attempt_at = _now()
    delivery.last_error = ""
    session.flush()
    return delivery
