"""
Sessions: what a browser holds, how long it is worth, and how to take it away.

This file used to be the whole of authentication, and what it held was one
shared passcode — no user records, no roles, and every action in the audit trail
attributed to whoever happened to be holding the secret. That is gone. Deciding
*who* somebody is now belongs to `app/identity.py`; what remains here is what
happens after: minting the session, resolving it on each request, expiring it,
and revoking it.

The properties that carried over are the ones that were already right:

* **The cookie is an opaque random id and the database holds only its SHA-256.**
  A dump of `auth_sessions` cannot be replayed as a cookie.
* **Sessions are server-side and revocable.** Logging out deletes the row, and a
  deleted row cannot be un-deleted by anything the client keeps.
* **Expiry is enforced on read, not by a sweeper.** A lapsed session is dead the
  next time it is used, whether or not any cleanup has run.

What is new is the second clock. A session records both when it was last *seen*
and when a credential was last *presented*, and step-up reads the second — see
the note above `REAUTH_MINUTES`.
"""

from __future__ import annotations

import hashlib
import os
import secrets
from datetime import datetime, timedelta, timezone

from sqlalchemy import delete, func, select, text
from sqlalchemy.orm import Session

from .db import TOKEN_SETTING
from .models import AuthAttempt, AuthSession

COOKIE_NAME = "quolin_session"

#: How long a session lasts regardless of activity. A demo runs for an hour;
#: twelve gives a day's use without leaving a laptop logged in over a weekend.
SESSION_HOURS = int(os.getenv("QUOLIN_SESSION_HOURS", "12"))

#: How long a session survives with no requests on it.
IDLE_MINUTES = int(os.getenv("QUOLIN_IDLE_MINUTES", "120"))

#: `last_seen_at` is only written when it is this stale, so an idle timeout
#: does not cost a database write per request.
_TOUCH_AFTER = timedelta(seconds=60)


class RateLimited(Exception):
    """Too many failed attempts from one address."""

    def __init__(self, retry_after: int):
        self.retry_after = retry_after
        super().__init__(
            f"Too many failed attempts. Try again in {retry_after} seconds."
        )


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ------------------------------------------------------------ rate limiting --

#: Failed attempts live in Postgres, not in this process.
#:
#: They used to be `{ip: [timestamps]}` behind a lock, with a note saying that a
#: multi-instance deployment would need Redis and that a database table would
#: "serialise every login attempt through Postgres". §S12 measured both halves of
#: that and neither survived.
#:
#: The table does not serialise anything: it is one indexed insert and one
#: indexed count, on the login path only, and a failed sign-in already wrote to
#: Postgres before this change. What the in-process dictionary *did* cost was
#: `api_desired_count = 1` — a second task would have silently doubled the
#: number of guesses an attacker gets — and pinned at one task the API used one
#: core of twelve while a load test watched it fall over.
#:
#: The other half is worse and is why this is a table rather than Redis. The
#: rows Stage 9 thought it was writing were never written: `security_events` is
#: tenant-scoped and `/auth/login` has no tenant, so every failed sign-in failed
#: the policy's row check and was swallowed. Putting the counter somewhere with
#: no durable record would have kept that hole open. See migration 0022.

MAX_ATTEMPTS = int(os.getenv("QUOLIN_MAX_ATTEMPTS", "8"))
WINDOW_SECONDS = int(os.getenv("QUOLIN_LOCKOUT_SECONDS", "300"))

#: The same window, counted against the account instead of the address.
#:
#: FP3-02. Counting only by address assumes an attacker has one, and the whole
#: finding is that they choose it. Behind a proxy the address is *derived* now
#: rather than accepted — but a botnet does not need to spoof anything, and a
#: password-spray from a thousand hosts is one guess per address and a thousand
#: guesses per account. The account is the thing being attacked, so it is the
#: thing with a counter on it.
#:
#: Higher than the per-address limit on purpose. A shared office NAT is many
#: people behind one address and would trip an account limit set equal to it;
#: an account is one person, and twelve wrong passwords in five minutes is not
#: that person.
MAX_ACCOUNT_ATTEMPTS = int(os.getenv("QUOLIN_MAX_ACCOUNT_ATTEMPTS", "12"))

#: And a much smaller number for the second factor, because the search space is.
#:
#: A TOTP code is six digits inside one thirty-second step: a million
#: possibilities, one of which is live at a time, and an attacker who already
#: holds the password is guessing against that alone. At twelve attempts per
#: five minutes an attacker gets roughly 0.1% of the space per day, which is not
#: a defence so much as a slower certainty. Five is the number a person who has
#: mistyped a code, waited for the next one, and mistyped it again can still
#: live with.
#:
#: This is separate from the password counter rather than shared with it because
#: the two failures mean opposite things. Wrong passwords are somebody guessing;
#: wrong codes are somebody who *has* the password and not the phone, which is
#: the incident where a credential has already leaked.
MAX_SECOND_FACTOR_ATTEMPTS = int(os.getenv("QUOLIN_MAX_MFA_ATTEMPTS", "5"))

FAILED = "failed"
SUCCEEDED = "succeeded"
RATE_LIMITED = "rate_limited"

#: Written into `detail` so a second-factor failure can be counted separately
#: without a second column or a second table.
SECOND_FACTOR = "second_factor"


def _recent_failures(session: Session, ip: str) -> list[datetime]:
    """Failures from this address since it last succeeded, inside the window.

    "Since it last succeeded" is how a correct password clears an address
    without deleting anything. Somebody who fumbles their password twice and
    then gets it right should not stay part-way to a lockout for five minutes —
    that punishes the legitimate user for the attacker's behaviour — and the
    record of the two failures is still there afterwards, which is the half a
    DELETE would have thrown away.
    """
    cutoff = _now() - timedelta(seconds=WINDOW_SECONDS)
    last_success = session.scalar(
        select(func.max(AuthAttempt.at)).where(
            AuthAttempt.source_ip == ip,
            AuthAttempt.outcome == SUCCEEDED,
            AuthAttempt.at >= cutoff,
        )
    )
    since = max(cutoff, last_success) if last_success else cutoff
    return list(
        session.scalars(
            select(AuthAttempt.at)
            .where(
                AuthAttempt.source_ip == ip,
                AuthAttempt.outcome == FAILED,
                AuthAttempt.at > since,
            )
            .order_by(AuthAttempt.at)
        )
    )


def check_rate_limit(session: Session, ip: str) -> None:
    """Raise RateLimited if this address has failed too often lately."""
    recent = _recent_failures(session, ip)
    if len(recent) >= MAX_ATTEMPTS:
        retry = int((recent[0] + timedelta(seconds=WINDOW_SECONDS) - _now()).total_seconds()) + 1
        raise RateLimited(max(retry, 1))


def _recent_account_failures(
    session: Session, account_id: str, *, second_factor: bool
) -> list[datetime]:
    """Failures against one account since that account last signed in.

    Same shape as the per-address count and for the same reason: a successful
    sign-in clears the counter by being a row rather than by deleting the
    failures before it, so somebody who fumbles a password and then gets it
    right is not left part-way to a lockout, and the record of the fumbles
    survives.
    """
    cutoff = _now() - timedelta(seconds=WINDOW_SECONDS)
    last_success = session.scalar(
        select(func.max(AuthAttempt.at)).where(
            AuthAttempt.user_id == account_id,
            AuthAttempt.outcome == SUCCEEDED,
            AuthAttempt.at >= cutoff,
        )
    )
    since = max(cutoff, last_success) if last_success else cutoff
    query = select(AuthAttempt.at).where(
        AuthAttempt.user_id == account_id,
        AuthAttempt.outcome == FAILED,
        AuthAttempt.at > since,
    )
    if second_factor:
        query = query.where(AuthAttempt.detail == SECOND_FACTOR)
    return list(session.scalars(query.order_by(AuthAttempt.at)))


def check_account_rate_limit(session: Session, account_id: str | None) -> None:
    """Raise RateLimited if this *account* has been guessed at too often.

    FP3-02. The address counter assumes the attacker has one address; this one
    assumes only that they are attacking one account, which is the assumption
    that actually holds. Both run, and either can refuse.

    Called with None — an attempt that resolved to no account — does nothing.
    There is nothing to count against, and inventing a bucket keyed on the
    address somebody typed would turn this table into a list of who might hold
    an account here.
    """
    if account_id is None:
        return
    recent = _recent_account_failures(session, account_id, second_factor=False)
    if len(recent) >= MAX_ACCOUNT_ATTEMPTS:
        retry = int((recent[0] + timedelta(seconds=WINDOW_SECONDS) - _now()).total_seconds()) + 1
        raise RateLimited(max(retry, 1))

    codes = _recent_account_failures(session, account_id, second_factor=True)
    if len(codes) >= MAX_SECOND_FACTOR_ATTEMPTS:
        retry = int((codes[0] + timedelta(seconds=WINDOW_SECONDS) - _now()).total_seconds()) + 1
        raise RateLimited(max(retry, 1))


def record_attempt(
    session: Session,
    *,
    ip: str,
    outcome: str,
    user_id: str | None = None,
    detail: str = "",
    forwarded_for: str | None = None,
) -> None:
    """Write down what happened, and never let doing so break the request.

    The same reasoning `observability.record` uses, and the same trap: this is
    called on the failure path of sign-in, and a system that refused to answer a
    login because it could not write a log line would have turned a record into
    an outage. The difference from the version this replaces is that the write
    now succeeds — there is no tenant policy to fail.
    """
    try:
        session.add(
            AuthAttempt(
                source_ip=ip,
                outcome=outcome,
                user_id=user_id,
                detail=detail,
                # Kept beside the resolved address, never instead of it. A
                # spoofed header is itself a signal and the chain a real proxy
                # writes is how a CDN is told from a botnet — but the column is
                # named so that nobody reads it as an address.
                forwarded_for_untrusted=forwarded_for or None,
            )
        )
        session.flush()
    except Exception:  # noqa: BLE001 — see the docstring
        session.rollback()


def record_failure(
    session: Session,
    ip: str,
    *,
    user_id: str | None = None,
    second_factor: bool = False,
    forwarded_for: str | None = None,
) -> None:
    record_attempt(
        session,
        ip=ip,
        outcome=FAILED,
        user_id=user_id,
        detail=SECOND_FACTOR if second_factor else "",
        forwarded_for=forwarded_for,
    )


def clear_failures(
    session: Session,
    ip: str,
    *,
    user_id: str | None = None,
    forwarded_for: str | None = None,
) -> None:
    """A correct password clears the address — by adding a row, not removing any."""
    record_attempt(
        session, ip=ip, outcome=SUCCEEDED, user_id=user_id, forwarded_for=forwarded_for
    )


# F2. `_reset_rate_limit_for_tests` used to be here, and it was the last reason
# `auth.py` appeared in the guard's allow-list of files that may open
# `app.owner_only`. It is `conftest.reset_rate_limit_for_tests` now.
#
# The argument for leaving it was that forty test call sites named it and moving
# them would be forty diffs changing nothing enforced. That was true about the
# diffs and wrong about what was enforced: `auth` is imported by everything that
# serves a request, and the function disabled an append-only trigger and deleted
# from `auth_attempts` — invariant 4, and the login rate limit with it, reachable
# from any handler that could reach `auth`. The allow-list entry that let it sit
# there was three characters of a grep away from being the whole boundary.
#
# The same reasoning this fix pack used on `source_alerts.all_tenant_ids`: a door
# nobody in the request path needs is one fewer door. The suite is not the
# request path, so the helper belongs in the suite.


# ----------------------------------------------------------------- sessions --


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def _scope_to_token(session: Session, token_hash: str) -> str:
    """Make exactly one session row visible: the one this cookie names.

    `auth_sessions` is under row-level security like every other tenant-scoped
    table, which leaves authentication with a bootstrap problem — the lookup
    that decides the tenant cannot be filtered by the tenant it has not decided
    yet. This is the way out, and it is narrower rather than wider than tenant
    scoping: for the duration of this transaction the policy admits one row.

    Transaction-scoped (`set_config(..., true)`), so it is gone at the next
    commit and cannot follow a pooled connection anywhere.
    """
    session.execute(
        text("SELECT set_config(:name, :value, true)"),
        {"name": TOKEN_SETTING, "value": token_hash},
    )
    return token_hash


def create_session(
    session: Session,
    *,
    tenant_id: str,
    user_id: str | None = None,
    api_client_id: str | None = None,
    mfa_satisfied: bool = False,
    user_agent: str = "",
    ip: str = "",
) -> str:
    """Mint a session and return the raw token — the only time it exists.

    `tenant_id` is a required keyword rather than something read from ambient
    state inside here. Minting a session is the one moment a tenant is chosen
    rather than inherited, and the choice should be visible at the call site.

    `user_id` keeps a default only because rows written before Stage 2 have no
    person behind them. Nothing mints one now — `resolve` is not the gate for
    that, `/auth/session` and the middleware are, and both refuse a session with
    no principal. The default goes when those rows do.

    `api_client_id` is the other kind of principal: an integration holding OAuth2
    client credentials. It goes through this same function, and therefore gets
    the same expiry, the same idle timeout, the same hashed token and the same
    revocation, rather than a second token format that would quietly become the
    weakest way in. Never both — a session naming two principals is one whose
    audit actor depends on which column the reader looked at first.
    """
    if user_id and api_client_id:
        raise ValueError(
            "a session names a person or a machine, never both — see migration 0011"
        )

    token = secrets.token_urlsafe(32)
    row = AuthSession(
        token_hash=_hash(token),
        tenant_id=tenant_id,
        user_id=user_id,
        api_client_id=api_client_id,
        created_at=_now(),
        expires_at=_now() + timedelta(hours=SESSION_HOURS),
        last_seen_at=_now(),
        authenticated_at=_now(),
        mfa_satisfied=mfa_satisfied,
        user_agent=user_agent[:300],
        created_ip=ip[:60],
    )
    session.add(row)
    session.commit()
    return token


def resolve(session: Session, token: str | None) -> AuthSession | None:
    """The live session for a cookie value, or None.

    Expiry is enforced here rather than by a sweeper, so a session that has
    lapsed is dead the moment it is next used even if no cleanup has run.
    """
    if not token:
        return None
    row = session.get(AuthSession, _scope_to_token(session, _hash(token)))
    if row is None:
        return None

    now = _now()
    if row.expires_at <= now or row.last_seen_at + timedelta(minutes=IDLE_MINUTES) <= now:
        session.delete(row)
        session.commit()
        return None

    if now - row.last_seen_at > _TOUCH_AFTER:
        row.last_seen_at = now
        session.commit()
    return row


def destroy(session: Session, token: str | None) -> bool:
    """Log out. True if a session was actually removed."""
    if not token:
        return False
    row = session.get(AuthSession, _scope_to_token(session, _hash(token)))
    if row is None:
        return False
    session.delete(row)
    session.commit()
    return True


def destroy_all(session: Session) -> int:
    """Revoke every session belonging to this tenant.

    The control you want when a credential has reached the wrong person and you
    do not know which browsers hold it. Scoped to the caller's tenant
    not by a WHERE clause here but by the policy on the table — which is why
    there is no WHERE clause here to get wrong.

    Q-14: this is now the *administrative* half. Signing every employee out to
    deal with one person's leaked password is a denial of service, and the route
    already refused it to a machine principal for exactly that reason. See
    `destroy_mine` for what a person actually needs.
    """
    total = len(list(session.scalars(select(AuthSession.token_hash))))
    session.execute(delete(AuthSession))
    session.commit()
    return total


def destroy_for(session: Session, *, user_id: str) -> int:
    """End every session belonging to one person, on somebody else's authority.

    FP3-13. `destroy_mine` is what a person does about their own leaked
    credential and `destroy_all` is the whole-tenant hammer; suspending an
    account needs the third thing, which is one named person's access ending
    now rather than when their cookie expires.

    Confined by the policy on the table as well as by the filter, so an admin
    cannot end a session belonging to another firm even by passing its id.
    """
    tokens = list(
        session.scalars(
            select(AuthSession.token_hash).where(AuthSession.user_id == user_id)
        )
    )
    session.execute(delete(AuthSession).where(AuthSession.user_id == user_id))
    session.flush()
    return len(tokens)


def destroy_mine(session: Session, *, user_id: str) -> int:
    """Revoke every session belonging to one person, across every browser.

    What "my credential has leaked" actually calls for, and what every role may
    do without asking anybody: it ends the caller's own access everywhere and
    nobody else's.

    Filtered by `user_id` *and* confined by the policy on the table, so a
    session belonging to the same person in a different firm is untouched — a
    consultant compliance officer serves several, and signing out of one is not
    signing out of all of them.
    """
    doomed = list(
        session.scalars(select(AuthSession).where(AuthSession.user_id == user_id))
    )
    for row in doomed:
        session.delete(row)
    session.commit()
    return len(doomed)


def purge_expired(session: Session) -> int:
    """Delete lapsed rows. Housekeeping only — `resolve` never trusts a row."""
    now = _now()
    rows = list(session.scalars(select(AuthSession)))
    dead = [
        r
        for r in rows
        if r.expires_at <= now or r.last_seen_at + timedelta(minutes=IDLE_MINUTES) <= now
    ]
    for r in dead:
        session.delete(r)
    session.commit()
    return len(dead)


def active_sessions(session: Session) -> list[AuthSession]:
    now = _now()
    return [
        r
        for r in session.scalars(select(AuthSession).order_by(AuthSession.created_at.desc()))
        if r.expires_at > now and r.last_seen_at + timedelta(minutes=IDLE_MINUTES) > now
    ]


# ---------------------------------------------------------------- step-up --
#
# Two timestamps on a session, and the difference between them is the whole
# idea. `last_seen_at` moves on every request, so it says the browser is still
# there. `authenticated_at` moves only when a credential is presented again, so
# it says the *person* is still there. An unattended laptop keeps the first
# fresh forever and the second not at all.


#: How recently a credential must have been presented for an action that
#: demands one.
#:
#: **Fifteen minutes, raised from five. FP3-12(c).** The old comment claimed
#: five was "long enough to read the draft that is about to be signed", and that
#: claim was untrue against the thing being signed: a pack draft is a rule
#: document with a diff, a validation report and a preview to look at, and
#: anybody who actually reads one before signing it takes longer than five
#: minutes. What the window really enforced was a habit of opening the draft,
#: signing immediately, and reading afterwards — the opposite of its purpose.
#:
#: The alternative the audit offered was to restart the window when the draft is
#: opened for signing. That was rejected, and the reason is the distinction two
#: paragraphs up: `authenticated_at` means *a credential was presented*, and
#: `last_seen_at` means *the browser is still there*. Moving the first on a page
#: load would make opening a draft count as proving you are present, which is
#: precisely the unattended-laptop case the split exists to catch — and it would
#: do it silently, on a GET, with no credential anywhere near it.
#:
#: Fifteen is bounded by what it is protecting against: somebody walking up to a
#: signed-in machine its owner has left. It is long enough to read a draft and
#: short enough that the walk-up has to be near-immediate. It is not longer,
#: because past about a quarter of an hour "the person who authenticated is
#: still the person acting" stops being a claim the timestamp supports.
#:
#: This is survivable at any finite value only because of FP3-12(b): the client
#: now answers a stale credential by asking for the password in place and
#: retrying, so an expired window costs a dialog rather than the draft.
REAUTH_MINUTES = int(os.getenv("QUOLIN_REAUTH_MINUTES", "15"))


class ReauthenticationRequired(Exception):
    """The session is live but the credential behind it is stale."""

    def __init__(self, action: str):
        self.action = action
        super().__init__(
            f"{action} requires you to confirm your password. "
            f"A credential is accepted for {REAUTH_MINUTES} minutes."
        )


def credential_is_fresh(row: AuthSession, *, within_minutes: int = REAUTH_MINUTES) -> bool:
    return row.authenticated_at + timedelta(minutes=within_minutes) > _now()


def require_fresh_credential(row: AuthSession, *, action: str) -> None:
    """Raise unless a credential was presented recently enough for this action.

    A raising check rather than a boolean, because the caller that forgets to
    look at a boolean is the caller that signs a pack for an empty chair.
    """
    if not credential_is_fresh(row):
        raise ReauthenticationRequired(action)


def mark_reauthenticated(session: Session, row: AuthSession, *, mfa_satisfied: bool) -> None:
    """Record that the person behind this session has just proved it again.

    `mfa_satisfied` is written rather than OR-ed into what was there. A session
    that once presented a second factor and has now been re-confirmed with only
    a password has not presented a second factor now, and the row should say so.
    """
    row.authenticated_at = _now()
    row.mfa_satisfied = mfa_satisfied
    session.commit()


# ------------------------------------------------------------------ cookie --


def cookie_secure() -> bool:
    """Whether to set the Secure flag, and with it SameSite=None.

    Two deployments, two correct answers:

    * Local: web on :3100, API on :8000. Different *origins* but the same
      *site* — SameSite is computed on the registrable domain, and both are
      `localhost`. `SameSite=Lax` is sent, and is the stricter choice.
    * Hosted or tunnelled: web on Vercel, API on Fly (or two different
      `trycloudflare.com` hostnames). Genuinely cross-site, so the cookie is
      only sent with `SameSite=None`, which browsers only honour together with
      `Secure`, which requires HTTPS. All three hold there.

    Defaulting this to false would silently break the hosted deployment;
    defaulting it to true would silently break local development over http.
    So it is explicit, and `docs/deployment.md` lists it as required.
    """
    return os.getenv("QUOLIN_COOKIE_SECURE", "false").strip().lower() in {
        "1",
        "true",
        "yes",
    }


def cookie_kwargs() -> dict:
    secure = cookie_secure()
    return {
        "key": COOKIE_NAME,
        "httponly": True,  # script cannot read it, so XSS cannot exfiltrate it
        "secure": secure,
        "samesite": "none" if secure else "lax",
        "path": "/",
        "max_age": SESSION_HOURS * 3600,
    }
