"""Whose calendar day "today" is.

FP3-05. Q-03 fixed the *timestamp* timezone — every `datetime` in this codebase
is `datetime.now(timezone.utc)`, and that is correct. The **business date** was
never looked at, and it is a different question with a different answer.

`date.today()` is the process's local calendar date, which on ECS is UTC. A
business date is not a fact about the process: it is what the firm being
regulated calls today. For a Sydney firm those differ for ten hours of every
day, which is most of their working morning.

Reproduced before the fix. At 2026-08-27T23:30:00Z — 09:30 on the 28th in
Sydney — a Sydney operator asking for a determination `as_of` 2026-08-28 was
refused `as_of_in_the_future` by `check_as_of`, because the container's calendar
said the 27th. The console's default `as_of` recorded yesterday's date on every
determination made before 10am local. And `packs_repo.active_rows(session,
date.today())` meant a pack effective on the 28th began governing that firm at
10:00 local rather than at midnight.

None of this touches replay: `evidence.replay` reads no clock, and a stored
`as_of` is whatever it was. What it touches is every determination made from
now on, and the direction of the error is that a firm's morning is recorded as
the previous day.

**One function, and every caller goes through it.** `scripts/guard_no_naive_today.sh`
fails the build on `date.today()` or a naive `datetime.now()` anywhere in
`api/app` or `scripts`, with this module as the single allow-listed exception —
because a rule enforced by twenty-nine call sites remembering it is not enforced.
"""

from __future__ import annotations

from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from sqlalchemy.orm import Session

from .models import Tenant
from .tenancy import current_tenant_or_none

#: The business timezone a region implies when a tenant has not been given one.
#:
#: A default rather than a guess: a firm hosted in `ap-southeast-2` is being
#: served from Sydney because that is where it is, and the tenancy stage chose
#: the region for that reason. A firm that operates on a different clock from
#: its hosting region sets `business_timezone` explicitly, which is why the
#: column exists at all.
REGION_TIMEZONES = {
    "ap-southeast-2": "Australia/Sydney",
    "ap-southeast-1": "Asia/Singapore",
    "ap-east-1": "Asia/Hong_Kong",
    "eu-central-1": "Europe/Berlin",
    "eu-west-1": "Europe/Dublin",
    "eu-west-2": "Europe/London",
    "us-east-1": "America/New_York",
    "us-west-2": "America/Los_Angeles",
}

#: What a process with no firm in scope calls today.
#:
#: UTC, and deliberately not the primary region's timezone. A platform-level
#: job — a watch sweep reading a regulator's feed, a draft's own lifecycle — is
#: not acting for any firm, and giving it Sydney's calendar would be inventing a
#: customer for it. The one thing it must not be is the *container's* local
#: date, which is the whole finding.
PLATFORM_TIMEZONE = "UTC"


def zone_for(tenant: Tenant | None) -> ZoneInfo:
    """The timezone a firm's business day is measured in."""
    if tenant is None:
        return ZoneInfo(PLATFORM_TIMEZONE)

    declared = (tenant.business_timezone or "").strip()
    if not declared:
        declared = REGION_TIMEZONES.get(tenant.region or "", PLATFORM_TIMEZONE)

    try:
        return ZoneInfo(declared)
    except (ZoneInfoNotFoundError, ValueError):
        # A tenant row with an unreadable timezone is a provisioning error, and
        # the right failure is not an exception three frames into a
        # determination. Falling back to UTC is wrong by at most a day and is
        # visible; raising here would take the firm's whole console down over a
        # typo in a config field.
        return ZoneInfo(PLATFORM_TIMEZONE)


def business_today(
    session: Session | None = None,
    *,
    tenant: Tenant | None = None,
    now: datetime | None = None,
) -> date:
    """Today, as the firm in scope counts days.

    Resolution order, and each step is deliberate:

      * an explicit `tenant`, for callers that already hold the row;
      * otherwise the tenant bound to this transaction, loaded through
        `session`;
      * otherwise UTC, because nothing is acting for a firm.

    `now` exists for tests. The alternative — freezing the process clock — makes
    every other test in the same run depend on the ordering, and this is the one
    function whose answer is supposed to depend on an instant.
    """
    instant = now or datetime.now(timezone.utc)

    if tenant is None and session is not None:
        tenant_id = current_tenant_or_none()
        if tenant_id:
            tenant = session.get(Tenant, tenant_id)

    return instant.astimezone(zone_for(tenant)).date()


def platform_today(now: datetime | None = None) -> date:
    """Today for work that is not being done on any firm's behalf.

    A separate name rather than `business_today()` with no arguments, so that a
    call site which *should* have had a tenant and does not is visible as a
    decision somebody made rather than as an omission.
    """
    return (now or datetime.now(timezone.utc)).astimezone(
        ZoneInfo(PLATFORM_TIMEZONE)
    ).date()
