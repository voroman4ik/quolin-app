"""Where a firm is on the ladder, and what their determinations are allowed to do.

§S10: `pilot → shadow → limited → full`, with transitions logged as signed-off
events. The ladder is not a feature flag. It is the answer to the question a
firm's compliance officer asks before signing anything — *what happens if you
are wrong during the first month* — and the answer is: for a month, nothing
happens at all, and you get a report every week showing where we disagree.

**The stages, and what each one changes:**

  pilot    Nothing is connected. Determinations can be made by hand for
           evaluation; nothing reaches anybody.
  shadow   Their real book flows in, determinations are computed and recorded
           in full, and *no outcome has any effect in the world*. No webhook, no
           referral, no artefact filed. Their own system stays in charge.
  limited  Live for a named slice — a client segment, an asset class — and
           shadow for everything else. The slice is tenant config, because which
           part of a book to trust us with first is the customer's judgement.
  full     Every flow live. The shadow machinery stays, forever, because Stage
           5's pinned tenants use exactly it to review a pack version before
           taking it.

**Forward only, one rung at a time, and a signature on every rung.** Skipping
from pilot to full is the transition nobody should be able to make by accident,
and a customer who needs to go back to shadow after a bad week is having a
conversation rather than clicking a button — so a retreat is allowed, recorded,
and requires the same signature.

**Whether an outcome may act is asked per determination, not per tenant.** In
`limited`, one client is live and their colleague is not. Asking the tenant
would give the wrong answer for one of them.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import business_time
from .models import Tenant, TenantStageChange
from .tenancy import current_tenant, current_user_or_none

PILOT = "pilot"
SHADOW = "shadow"
LIMITED = "limited"
FULL = "full"

#: In order, because the order is the product. A screen renders this; a
#: transition is checked against it.
LADDER = (PILOT, SHADOW, LIMITED, FULL)

WHAT_EACH_MEANS = {
    PILOT: "Nothing is connected. Determinations can be made by hand; nothing reaches anybody.",
    SHADOW: (
        "Your book flows in and every determination is computed and recorded. "
        "Nothing we decide has any effect: no notification to your systems, no "
        "document filed, no client affected. Your existing process stays in charge."
    ),
    LIMITED: (
        "Live for the part of the book you named, and shadow for everything else."
    ),
    FULL: "Every flow live. Shadow machinery stays, and is what pack-version reviews use.",
}


class LadderError(ValueError):
    """A move along the ladder that does not make sense."""


@dataclass(frozen=True)
class Effect:
    """Whether a determination may act, and why not when it may not.

    The reason travels with the answer because it is shown to people. "Nothing
    was sent" is alarming on its own and unremarkable when it says "this firm is
    in shadow mode until the fourteenth".
    """

    allowed: bool
    stage: str
    reason: str


def _now() -> datetime:
    return datetime.now(timezone.utc)


def stage_of(tenant: Tenant | None) -> str:
    """The rung a firm is on, defaulting to the safest.

    `pilot` when unknown, because the failure mode of the other default is a
    determination reaching a client's adviser on the day a customer record was
    created by hand.
    """
    stage = (tenant.stage if tenant is not None else "") or PILOT
    return stage if stage in LADDER else PILOT


def scope_of(tenant: Tenant | None) -> dict[str, list[str]]:
    """The slice of the book that is live in `limited`.

    Read from tenant config, because which part of a book to trust us with first
    is the customer's judgement and not a code change. Two dimensions, which are
    the two ways firms actually describe a slice: a client segment, and an asset
    class.
    """
    config = (tenant.config if tenant is not None else None) or {}
    scope = config.get("limited_scope") or {}
    return {
        "scenarios": [str(v) for v in (scope.get("scenarios") or [])],
        "asset_ids": [str(v) for v in (scope.get("asset_ids") or [])],
    }


def may_act(
    session: Session,
    *,
    client_scenario: str | None = None,
    asset_id: str | None = None,
    tenant_id: str | None = None,
    tenant: Tenant | None = None,
) -> Effect:
    """Whether a determination for this client and asset may have an effect.

    Asked per determination rather than per tenant, because in `limited` one
    client is live and the next is not. A per-tenant answer would be wrong for
    one of them, and wrong in the direction that reaches a person.

    `tenant` may be passed by a caller that already holds the row — a bulk sweep
    does, once per chunk. Without it this is a lookup per determination, which
    Stage 8's query-count tripwire caught the moment this was wired in: a sweep
    commits per chunk, so the identity map is empty each time and "one small
    read" becomes five hundred.
    """
    tenant = tenant if tenant is not None else session.get(Tenant, tenant_id or current_tenant())
    stage = stage_of(tenant)

    if stage == FULL:
        return Effect(True, stage, "")
    if stage in (PILOT, SHADOW):
        return Effect(
            False,
            stage,
            f"this firm is in {stage} mode, where no determination has an effect",
        )

    scope = scope_of(tenant)
    if not scope["scenarios"] and not scope["asset_ids"]:
        # Limited with nothing named is shadow. The alternative — treating an
        # empty scope as "everything" — turns a missing config key into a firm
        # going live, which is the worst possible reading of an absence.
        return Effect(
            False,
            stage,
            "this firm is live for a named part of its book, and none is named yet",
        )

    in_segment = not scope["scenarios"] or (client_scenario in scope["scenarios"])
    in_class = not scope["asset_ids"] or (asset_id in scope["asset_ids"])
    if in_segment and in_class:
        return Effect(True, stage, "")
    return Effect(
        False,
        stage,
        "this client and asset are outside the part of the book that is live",
    )


#: §S10's target: contract to shadow in under two weeks. Recorded here so the
#: measurement and the target live together — a number reported without the goal
#: beside it is one nobody acts on.
ONBOARDING_TARGET_DAYS = 14


def onboarding(session: Session, tenant_id: str | None = None) -> dict[str, Any]:
    """How long this firm took to reach shadow, against the two-week target.

    §S10 says to instrument it, and the instrumentation is only honest if the
    clock starts where the customer thinks it starts: at the contract, not at
    the day somebody got round to creating the tenant record. So `contracted_at`
    is tenant config — a date somebody enters — and when it is absent this
    reports that it is unmeasured rather than quietly measuring from the row's
    creation and flattering us by a fortnight.
    """
    tenant = session.get(Tenant, tenant_id or current_tenant())
    config = (tenant.config if tenant is not None else None) or {}
    contracted_raw = str(config.get("contracted_at") or "").strip()

    reached = session.scalars(
        select(TenantStageChange)
        .where(
            TenantStageChange.tenant_id == (tenant_id or current_tenant()),
            TenantStageChange.to_stage == SHADOW,
        )
        .order_by(TenantStageChange.at)
    ).first()

    if not contracted_raw:
        return {
            "measured": False,
            "target_days": ONBOARDING_TARGET_DAYS,
            "why_not": (
                "No contract date is recorded for this firm, so the clock has no "
                "start. Measuring from when the tenant row was created would "
                "flatter us by however long it took somebody to create it."
            ),
            "reached_shadow_at": reached.at.isoformat() if reached else None,
        }

    contracted = datetime.fromisoformat(contracted_raw)
    if contracted.tzinfo is None:
        contracted = contracted.replace(tzinfo=timezone.utc)

    if reached is None:
        elapsed = (_now() - contracted).days
        return {
            "measured": True,
            "reached_shadow": False,
            "contracted_at": contracted.isoformat(),
            "days_so_far": elapsed,
            "target_days": ONBOARDING_TARGET_DAYS,
            "within_target": elapsed <= ONBOARDING_TARGET_DAYS,
        }

    # Business dates on both sides, not instants. FP3-05.
    #
    # `contracted_at` is a date somebody typed — it parses to midnight UTC — and
    # `reached.at` is a timestamp. Subtracting them and truncating made the
    # answer depend on the hour of day the stage change happened: the same seven
    # weeks read as 49 days if the change landed near midnight UTC and 48 if it
    # landed in the evening. Found by running the suite under
    # `TZ=Australia/Sydney`, where the test's own arithmetic and this
    # calculation disagreed by exactly that one day.
    #
    # Counting the firm's calendar days between two of the firm's calendar dates
    # is both the stable answer and the one an onboarding target means.
    zone = business_time.zone_for(session.get(Tenant, tenant_id or current_tenant()))
    days = (reached.at.astimezone(zone).date() - contracted.astimezone(zone).date()).days
    return {
        "measured": True,
        "reached_shadow": True,
        "contracted_at": contracted.isoformat(),
        "reached_shadow_at": reached.at.isoformat(),
        "days": days,
        "target_days": ONBOARDING_TARGET_DAYS,
        "within_target": days <= ONBOARDING_TARGET_DAYS,
    }


def history(session: Session, tenant_id: str | None = None) -> list[dict[str, Any]]:
    """Every rung this firm has been on, oldest first."""
    rows = session.scalars(
        select(TenantStageChange)
        .where(TenantStageChange.tenant_id == (tenant_id or current_tenant()))
        .order_by(TenantStageChange.at, TenantStageChange.id)
    ).all()
    return [
        {
            "from": row.from_stage,
            "to": row.to_stage,
            "at": row.at.isoformat(),
            "signed_by": row.signed_by,
            "signed_by_user_id": row.signed_by_user_id,
            "note": row.note,
        }
        for row in rows
    ]


def move(
    session: Session,
    *,
    to_stage: str,
    signed_by: str,
    note: str = "",
    tenant_id: str | None = None,
) -> TenantStageChange:
    """Move a firm one rung, and record who signed for it.

    Refuses three things, each for its own reason:

    * **An unknown rung**, because the ladder is the product.
    * **A skip**, because pilot to full in one move is the transition nobody
      should make by accident. A firm that is genuinely ready walks it in three
      steps on the same afternoon and has three signatures to show for it.
    * **An unsigned move**, because "who decided they were ready" is the
      question asked afterwards, every time.

    A retreat — full back to shadow — is allowed and recorded. A customer having
    a bad week needs it to be possible, and the record is what makes it a
    decision rather than a disappearance.
    """
    if to_stage not in LADDER:
        raise LadderError(
            f"{to_stage!r} is not a rung. The ladder is: {' → '.join(LADDER)}."
        )
    if not signed_by.strip():
        raise LadderError(
            "moving a firm along the ladder needs a signature. Going live is a "
            "decision somebody makes, and the question afterwards is who."
        )

    tenant = session.get(Tenant, tenant_id or current_tenant())
    if tenant is None:
        raise LadderError(f"no tenant {tenant_id or current_tenant()!r}")

    current = stage_of(tenant)
    if to_stage == current:
        raise LadderError(f"this firm is already at {current!r}")

    forward = LADDER.index(to_stage) - LADDER.index(current)
    if forward > 1:
        raise LadderError(
            f"{current!r} to {to_stage!r} skips "
            f"{' and '.join(LADDER[LADDER.index(current) + 1 : LADDER.index(to_stage)])}. "
            "Walk it a rung at a time — a firm that is ready can do all of them "
            "this afternoon, and will have a signature for each."
        )

    row = TenantStageChange(
        tenant_id=tenant.id,
        from_stage=current,
        to_stage=to_stage,
        at=_now(),
        signed_by=signed_by.strip(),
        signed_by_user_id=current_user_or_none(),
        note=note,
    )
    session.add(row)
    tenant.stage = to_stage
    session.flush()
    return row
