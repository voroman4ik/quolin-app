"""Turning a submitted email address into a person the rest of the system trusts.

`app/passwords.py` and `app/totp.py` are the two credential primitives. This is
the layer above them: the order the checks happen in, what each failure is
allowed to reveal, and the row-level-security dance that sign-in needs because
the tables it reads are invisible until it knows who is reading them.

**The bootstrap, and what it is and is not.** `users`, `user_identities` and
`mfa_credentials` carry no `tenant_id` — a consultant compliance officer is one
person across several firms — so they are policed by two settings rather than
one. `app.login_email` makes exactly the row for a submitted address readable,
and nothing writable. `app.user_id` then makes that person's own rows readable
and writable, which is what lets sign-in read a password hash and what lets
enrolment write a second factor.

That second step happens *before* the password is checked, because the hash is
what the check needs. So it is worth being exact about what row-level security
is doing on these tables and what it is not: it is containment, not the
authentication boundary. It means a SQL injection in an unrelated handler cannot
enumerate the firm's staff. It does not mean an attacker who could call
`set_config` directly would be stopped — the thing that stops them is that
`app.user_id` is set in exactly two places, here and from a resolved session
cookie, and neither takes the value from the request body.

**What each failure says.** A wrong password and an unknown address are the same
answer and take the same time; `passwords.waste_time` exists for the second
case. Once the password is right, "a second factor is required" is said plainly,
because at that point the caller already knows the password and withholding it
only breaks the login form.
"""

from __future__ import annotations

import secrets
from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum

from sqlalchemy import select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from . import passwords, totp
from .db import (
    LOGIN_EMAIL_SETTING,
    LOGIN_ISSUER_SETTING,
    LOGIN_SUBJECT_SETTING,
    USER_SETTING,
)
from .models import ROLES, MfaCredential, TenantMember, User, UserIdentity, UserRole
from .tenancy import current_tenant

PASSWORD_PROVIDER = "password"
OIDC_PROVIDER = "oidc"


class Outcome(StrEnum):
    """Why a sign-in did not produce a user.

    Kept distinct here and collapsed to one message at the endpoint. The
    distinction is for the audit trail, which has to tell "someone is guessing
    passwords" from "someone has the password and not the phone" — two very
    different incidents, and only the second one means a credential has leaked.
    """

    NO_SUCH_USER = "no_such_user"
    WRONG_PASSWORD = "wrong_password"
    NOT_ACTIVE = "not_active"
    MFA_REQUIRED = "mfa_required"
    MFA_WRONG = "mfa_wrong"


@dataclass(frozen=True)
class SignIn:
    """The result of a sign-in attempt.

    `user` is set only on success. `outcome` is set only on failure. Both are
    carried rather than raising, because every one of these is an ordinary event
    at a login endpoint and none is a programming error.
    """

    user: User | None = None
    outcome: Outcome | None = None
    #: The account the attempt resolved to, set on failure as well as success.
    #:
    #: Stage 9 alerts on auth anomalies, and "fifty failures against one real
    #: account" is a different incident from "fifty failures against fifty
    #: addresses somebody guessed". Only the opaque row id — never the address,
    #: which would make the security log a list of who has an account here.
    user_id: str | None = None
    #: True when the credential presented was a second factor as well as a
    #: password. The session records it, and step-up reads it.
    mfa_satisfied: bool = False

    def __bool__(self) -> bool:
        return self.user is not None


def _now() -> datetime:
    return datetime.now(timezone.utc)


def new_id(prefix: str) -> str:
    """A random opaque id.

    Random rather than sequential because these appear in audit rows and in
    signatures: a sequential user id tells anyone who sees one how many people a
    firm has and in what order they joined.
    """
    return f"{prefix}_{secrets.token_urlsafe(12)}"


def normalise_email(raw: str) -> str:
    """One address, one row.

    Case and surrounding whitespace are not part of an identity, and a unique
    index on the raw string would happily hold `A@x.test` and `a@x.test` as two
    people with two passwords and two sets of roles.
    """
    return raw.strip().lower()


# ------------------------------------------------------------ RLS bootstrap --


def _scope_to_email(session: Session, email: str) -> None:
    """Make the row for one address readable, and nothing writable.

    Transaction-scoped, like the session-token bootstrap it is modelled on, so
    it cannot follow a pooled connection past the next commit.
    """
    session.execute(
        text("SELECT set_config(:name, :value, true)"),
        {"name": LOGIN_EMAIL_SETTING, "value": email},
    )


def _scope_to_user(session: Session, user_id: str) -> None:
    """Declare which person this transaction is acting as.

    Only ever called with an id this process resolved itself — from an address
    it just looked up, or from a session row it just validated. Never with a
    value that arrived in a request.
    """
    session.execute(
        text("SELECT set_config(:name, :value, true)"),
        {"name": USER_SETTING, "value": user_id},
    )


def _scope_to_assertion(session: Session, *, issuer: str, subject: str) -> None:
    """Make the one federated identity an assertion names readable, and nothing
    writable.

    The federated twin of `_scope_to_email`, and subject to the same warning: it
    is only as trustworthy as the caller, and the only caller sets these from a
    JWT it has already verified end to end.
    """
    for name, value in (
        (LOGIN_ISSUER_SETTING, issuer),
        (LOGIN_SUBJECT_SETTING, subject),
    ):
        session.execute(
            text("SELECT set_config(:name, :value, true)"),
            {"name": name, "value": value},
        )


def find_by_id(session: Session, user_id: str) -> User | None:
    """A person, by id, whether or not this firm has granted them anything yet.

    `users` is policed by reachability — a firm sees a person exactly when it
    has granted them a role — which is right, and produces one chicken-and-egg:
    the request that is *about* to make the first grant cannot see the person it
    is granting to. `create_user` already resolves it the same way, by naming
    the row in `app.user_id` before touching it.

    Scoped rather than widened. The setting names one person for the length of
    the transaction; it does not make the staff list readable.
    """
    if not user_id:
        return None
    _scope_to_user(session, user_id)
    return session.get(User, user_id)


def find_by_email(session: Session, email: str) -> User | None:
    address = normalise_email(email)
    if not address:
        return None
    _scope_to_email(session, address)
    return session.scalars(select(User).where(User.email == address)).one_or_none()


# --------------------------------------------------------------- enrolment --


def create_user(session: Session, *, email: str, display_name: str) -> User:
    """A person, with no way to sign in yet.

    Deliberately separate from `set_password`: an account created by an
    administrator and an account that has chosen a credential are different
    states, and collapsing them means an invited user exists with a password
    somebody else typed.
    """
    user = User(
        id=new_id("usr"),
        email=normalise_email(email),
        display_name=display_name,
        status="active",
        created_at=_now(),
    )
    _scope_to_user(session, user.id)
    session.add(user)
    session.flush()
    return user


def set_password(session: Session, user: User, password: str) -> UserIdentity:
    """Create or replace the password identity for a person."""
    encoded = passwords.hash_password(password, email=user.email)
    _scope_to_user(session, user.id)

    identity = session.scalars(
        select(UserIdentity).where(
            UserIdentity.user_id == user.id,
            UserIdentity.provider == PASSWORD_PROVIDER,
        )
    ).one_or_none()

    if identity is None:
        identity = UserIdentity(
            id=new_id("idt"),
            user_id=user.id,
            provider=PASSWORD_PROVIDER,
            issuer="",
            subject=user.email,
            created_at=_now(),
        )
        session.add(identity)
    identity.secret = encoded
    session.flush()
    return identity


def enrol_totp(session: Session, user: User, *, label: str = "") -> tuple[MfaCredential, str]:
    """An unconfirmed second factor and the URI to scan for it.

    Unconfirmed on purpose. Between showing a QR code and the user proving they
    scanned it, anything can happen — a mistyped issuer, a phone that failed to
    save it, a user who closed the tab. A credential that counted before that
    proof would lock a person out of their own account while reporting that they
    have a working second factor.
    """
    secret = totp.new_secret()
    credential = MfaCredential(
        id=new_id("mfa"),
        user_id=user.id,
        kind="totp",
        label=label,
        secret=secret,
        confirmed_at=None,
        last_used_counter=0,
        created_at=_now(),
    )
    _scope_to_user(session, user.id)
    session.add(credential)
    session.flush()
    return credential, totp.provisioning_uri(secret, account=user.email)


def confirm_totp(session: Session, credential: MfaCredential, code: str) -> bool:
    """Prove the code the user reads matches the secret we stored.

    The step that the counter makes single-use from the very beginning: the code
    spent confirming enrolment cannot then be used to sign in.
    """
    _scope_to_user(session, credential.user_id)
    step = totp.verify(credential.secret, code, after_counter=credential.last_used_counter)
    if step is None:
        return False
    credential.confirmed_at = _now()
    credential.last_used_counter = step
    session.flush()
    return True


def second_factors(session: Session, user_id: str) -> list[MfaCredential]:
    """Every *confirmed* factor for a person.

    Unconfirmed rows are excluded here rather than at each call site, so an
    abandoned enrolment can never be the thing that decides whether MFA is
    required.
    """
    _scope_to_user(session, user_id)
    return [
        row
        for row in session.scalars(
            select(MfaCredential).where(MfaCredential.user_id == user_id)
        )
        if row.confirmed_at is not None
    ]


def check_second_factor(session: Session, user_id: str, code: str) -> bool:
    """Spend a one-time code against any of this person's confirmed factors.

    The counter is written before this returns, inside the caller's transaction.
    A caller that rolls back has, correctly, not spent the code.
    """
    for credential in second_factors(session, user_id):
        step = totp.verify(credential.secret, code, after_counter=credential.last_used_counter)
        if step is not None:
            credential.last_used_counter = step
            session.flush()
            return True
    return False


# ------------------------------------------------------------ federated sign-in --


class FederatedOutcome(StrEnum):
    """Why an identity provider's assertion did not produce a user.

    Separate from `Outcome` because these are not credential failures. Nobody
    guessed anything: the provider has authenticated somebody this deployment
    has no account for, which is a provisioning question and should read like
    one in the audit trail.
    """

    UNKNOWN_SUBJECT = "unknown_subject"
    UNVERIFIED_EMAIL = "unverified_email"
    NOT_ACTIVE = "not_active"


@dataclass(frozen=True)
class FederatedSignIn:
    user: User | None = None
    outcome: FederatedOutcome | None = None
    #: True when this assertion created the link between the provider's subject
    #: and an existing account. Worth auditing separately: it happens once per
    #: person and it is the moment their firm's IdP takes over their sign-in.
    linked: bool = False

    def __bool__(self) -> bool:
        return self.user is not None


def find_by_oidc(session: Session, *, issuer: str, subject: str) -> User | None:
    """The person a provider's `sub` already names here, if any.

    Looked up by the (issuer, subject) pair and never by email, because `sub` is
    the only claim an identity provider promises not to reassign. An address
    belonging to somebody who left can be handed to their replacement; matching
    on it would hand the replacement their predecessor's grants and their
    predecessor's name in the audit trail.
    """
    row = _identity_row(session, issuer=issuer, subject=subject)
    if row is None:
        return None
    _scope_to_user(session, row.user_id)
    return session.get(User, row.user_id)


def _identity_row(session: Session, *, issuer: str, subject: str) -> UserIdentity | None:
    """The `user_identities` row for one assertion, read through the bootstrap.

    The predicates are stated here as well as in the policy, and that is not
    redundancy: the policy is what makes the row visible at all, and these are
    what make the query say what it means to a reader who has not read the
    migration.
    """
    _scope_to_assertion(session, issuer=issuer, subject=subject)
    return session.scalars(
        select(UserIdentity).where(
            UserIdentity.provider == OIDC_PROVIDER,
            UserIdentity.issuer == issuer,
            UserIdentity.subject == subject,
        )
    ).one_or_none()


def accept_assertion(
    session: Session,
    *,
    issuer: str,
    subject: str,
    email: str,
    email_verified: bool,
    display_name: str = "",
) -> FederatedSignIn:
    """Resolve an identity provider's assertion to a person, or refuse it.

    Three steps, and the second is the only interesting one.

    First, an existing link wins outright — that is the steady state, and it
    holds even if the person's address at the provider has since changed.

    Second, a *verified* address may link to an account that already exists.
    This is the migration path: a firm that has been using the password fallback
    turns on their IdP, and their staff keep their roles, their history and
    their name in the audit trail rather than becoming new people. Refusing an
    unverified address is what stops that path from becoming an account-takeover
    primitive — at a provider that lets a user set any address they like, an
    unverified `email` claim is a text field, and honouring it would let anyone
    with an account there claim any account here.

    Third, and this is the part that is deliberately missing: no account is
    created. An assertion for somebody with no row is refused. Provisioning is
    the firm's act, recorded with a granter and a date, and an IdP that could
    perform it silently would make the access review report a description of
    whoever happens to be in a directory group.
    """
    existing = find_by_oidc(session, issuer=issuer, subject=subject)
    if existing is not None:
        if existing.status != "active":
            return FederatedSignIn(outcome=FederatedOutcome.NOT_ACTIVE)
        _touch_identity(session, issuer=issuer, subject=subject)
        if display_name and display_name != existing.display_name:
            # The provider is the authority on what a person is called, and a
            # name that drifts is a name that reads wrong beside next year's
            # decisions. Signatures already recorded keep what they printed.
            existing.display_name = display_name
        session.flush()
        return FederatedSignIn(user=existing)

    if not email:
        return FederatedSignIn(outcome=FederatedOutcome.UNKNOWN_SUBJECT)
    if not email_verified:
        return FederatedSignIn(outcome=FederatedOutcome.UNVERIFIED_EMAIL)

    user = find_by_email(session, email)
    if user is None:
        return FederatedSignIn(outcome=FederatedOutcome.UNKNOWN_SUBJECT)
    if user.status != "active":
        return FederatedSignIn(outcome=FederatedOutcome.NOT_ACTIVE)

    _scope_to_user(session, user.id)
    session.add(
        UserIdentity(
            id=new_id("idt"),
            user_id=user.id,
            provider=OIDC_PROVIDER,
            issuer=issuer,
            subject=subject,
            secret="",
            created_at=_now(),
            last_used_at=_now(),
        )
    )
    if display_name and display_name != user.display_name:
        user.display_name = display_name
    session.flush()
    return FederatedSignIn(user=user, linked=True)


def _touch_identity(session: Session, *, issuer: str, subject: str) -> None:
    """Record that this link was used. Written under `app.user_id`, not the
    bootstrap, because the bootstrap policy is read-only by design."""
    row = _identity_row(session, issuer=issuer, subject=subject)
    if row is not None:
        _scope_to_user(session, row.user_id)
        row.last_used_at = _now()


# -------------------------------------------------------------------- roles --


#: The granter of record when there is genuinely nobody.
#:
#: The seed has to create a firm's first administrator, and there is no account
#: to attribute that to. What must not happen is a grant made while serving a
#: request wearing the same word — which is what happened, because this used to
#: be the *default* value of `granted_by` and every grant in the system carried
#: it. The quarterly access review then reported, accurately and uselessly, on a
#: set of permissions whose authorisation was the string "bootstrap".
BOOTSTRAP = "bootstrap"

#: Whether this call stack is allowed to use it. Set by `bootstrapping()` below,
#: which the seed and the migrations enter and a request cannot.
#:
#: A context variable rather than a parameter, for the reason the tenant is:
#: something a caller passes is something a caller can pass wrongly, and the
#: question here is not "does this call want to bootstrap" but "is this process
#: bootstrapping at all".
_bootstrapping: ContextVar[bool] = ContextVar("quolin_bootstrapping", default=False)


@contextmanager
def bootstrapping() -> Iterator[None]:
    """Permit `BOOTSTRAP` as a granter for the length of this block.

    Entered by the seed and by any migration that has to create the first
    account. Nothing that answers a request enters it, so `granted_by` on a
    grant made through the API is always an account somebody can be asked about.
    """
    token = _bootstrapping.set(True)
    try:
        yield
    finally:
        _bootstrapping.reset(token)


def ensure_member(session: Session, *, user_id: str, reason: str = "") -> None:
    """Record that this person is one of the tenant-in-scope's people.

    Idempotent, and called on every path that brings somebody into a firm:
    provisioning them, and granting them anything. Membership is the fact that
    makes a person *visible* to a firm — `user_reachable` in migration 0047 —
    and it is deliberately not the same fact as holding a role, because
    revoking a role is something somebody does on a Tuesday and revoking
    identity is not.

    `ON CONFLICT DO NOTHING` rather than a look-then-insert. Granting a second
    role to somebody already here is the common case, so it must not be an
    error the caller has to know to catch, and two requests arriving together
    must not turn into an integrity error on a path that is otherwise a no-op.

    The tenant comes from the ambient scope and is never a parameter, for the
    same reason `grant_role` refuses to take one: a caller that has not said
    which firm it is acting for must be unable to write for one at all.
    """
    session.execute(
        pg_insert(TenantMember)
        .values(
            tenant_id=current_tenant(),
            user_id=user_id,
            joined_at=_now(),
            reason=reason,
        )
        .on_conflict_do_nothing(constraint="uq_one_membership_each")
    )


def grant_role(
    session: Session,
    *,
    user_id: str,
    role: str,
    granted_by: str,
    jurisdiction: str = "",
    qualification_ref: str = "",
    expires_at: datetime | None = None,
) -> UserRole:
    """Give one person one role inside the tenant currently in scope.

    The tenant is not a parameter. `user_roles` is the one identity table that
    *is* tenant-scoped, its `tenant_id` defaults from the ambient tenant, and the
    row-level-security policy refuses an insert naming any other — so a caller
    that has not said which firm it is acting for cannot write a grant at all,
    rather than writing one under a tenant it guessed.

    `granted_by` **is** a parameter and is required. It used to default to
    `BOOTSTRAP`, which meant every grant ever made carried it and the access
    review had nothing to report. A caller that forgets is now a `TypeError`
    rather than a row nobody can be named for.
    """
    if not granted_by or not granted_by.strip():
        raise ValueError(
            f"a grant of {role!r} names nobody as its authorisation. Every grant "
            "has to say who made it, or the access review reports permissions "
            "with no reviewable authorisation behind them."
        )
    if granted_by == BOOTSTRAP and not _bootstrapping.get():
        raise ValueError(
            f"{BOOTSTRAP!r} is only a granter where there is genuinely nobody — "
            "the seed creating a firm's first administrator. A grant made while "
            "serving a request has an account behind it, and has to name it. "
            "Use `identity.bootstrapping()` if this really is the seed."
        )
    if role not in ROLES:
        raise ValueError(f"{role!r} is not a role. Known roles: {', '.join(ROLES)}.")

    # Before the grant, and inside this function rather than at its call sites.
    # A grant without the membership it implies is a person who holds a role in
    # a firm that cannot see them — which fails closed in the worst direction,
    # so the two writes are not something a caller can get half right.
    ensure_member(session, user_id=user_id, reason=f"granted {role}")

    row = UserRole(
        id=new_id("rol"),
        user_id=user_id,
        role=role,
        jurisdiction=jurisdiction,
        qualification_ref=qualification_ref,
        granted_at=_now(),
        granted_by=granted_by,
        expires_at=expires_at,
    )
    session.add(row)
    session.flush()
    return row


def roles_for(
    session: Session, user_id: str, *, tenant_id: str | None = None
) -> list[UserRole]:
    """This person's live grants in the tenant in scope.

    Expired grants are filtered here and not by a sweeper. A time-boxed
    `quolin_support` grant that has run out must stop working at the moment it
    runs out, not at the next time a cleanup job happens to run.

    **The tenant is filtered explicitly, not left to row-level security.** This
    used to rely on the policy alone, and §S12's load model found what that
    costs: a person whose only grant was in another firm signed in to this
    deployment and was handed the role, after which every screen showed them
    this firm's book.

    The mechanism is the one this repository has now been taught five times.
    `app.tenant_id` binds when a transaction *begins*, and by the time sign-in
    asks this question a transaction is already open — `authenticate` opened it
    to read the user. Entering the tenancy context afterwards does not rebind
    it, so the policy was evaluated against whatever the pooled connection last
    held, and returned a grant belonging to somebody else's firm.

    Row-level security is still on and still forced. This is the second lock,
    for the same reason `evidence.verify_chain` filters by tenant explicitly:
    the query that decides who may act is not one to leave resting on ambient
    state.
    """
    now = _now()
    scope = tenant_id or current_tenant()
    return [
        row
        for row in session.scalars(
            select(UserRole).where(
                UserRole.user_id == user_id,
                UserRole.tenant_id == scope,
            )
        )
        if row.expires_at is None or row.expires_at > now
    ]


# ----------------------------------------------------------------- sign-in --


SUSPENDED = "suspended"
ACTIVE = "active"


def set_status(session: Session, *, user_id: str, status: str) -> User:
    """Suspend an account, or put it back.

    FP3-13. `user.status` was checked at sign-in — `authenticate` refuses
    anything that is not `active` — and set by nothing but the seed. So the
    control existed, worked, and had no way to be used: off-boarding somebody
    meant revoking each of their grants one at a time, and a person with no
    grants still holds an account that signs in.

    Two things follow from that, and the second is the one that matters. There
    was no single act to audit, so the trail recorded N revocations and no
    statement that a person had left; and there was no moment at which their
    live sessions ended, so a browser open at the time kept working until the
    cookie expired.

    Deliberately not a delete. `audit_events`, `decisions` and `overrides` all
    name this person, and a row somebody removed is a name those records point
    at and cannot resolve.
    """
    if status not in (ACTIVE, SUSPENDED):
        raise ValueError(
            f"status must be {ACTIVE!r} or {SUSPENDED!r}, not {status!r}"
        )

    # `users` is invisible until `app.user_id` names the row, which is what
    # stops one person enumerating another's account. The request arrives scoped
    # to the *administrator*, so the person being suspended is not readable
    # without this — the route returned 404 for an account that plainly existed.
    #
    # Safe by the rule `_scope_to_user`'s own docstring gives: the id was
    # resolved by this process from the path, and `session.get` immediately
    # afterwards is what decides whether it names anybody at all. Nothing is
    # authorised by it — the caller's own permission was settled before this
    # function was reached.
    _scope_to_user(session, user_id)
    user = session.get(User, user_id)
    if user is None:
        raise LookupError(f"no user {user_id!r}")

    user.status = status
    session.flush()
    return user


def account_id_for(session: Session, email: str) -> str | None:
    """The account an address names, or None — for rate limiting only.

    FP3-02 needs a per-account counter checked *before* the password is
    verified, which means resolving the address to an account before anybody
    has proved anything. That is the same lookup `authenticate` opens with and
    it discloses nothing on its own: the value never reaches the response, and
    the endpoint answers "those details are not correct" whether this returned
    an id or None.

    Deliberately does not `waste_time()` on a miss. The timing defence belongs
    to `authenticate`, which runs immediately afterwards on every path that
    reaches here, and doing it twice would double the cost of every sign-in to
    defend a signal that call already covers.
    """
    user = find_by_email(session, email)
    return user.id if user is not None else None


def authenticate(session: Session, *, email: str, password: str, code: str = "") -> SignIn:
    """The whole check, in the order the failures have to happen in.

    Address, then password, then status, then second factor. Status is checked
    after the password rather than before so that a suspended account and a
    wrong password are indistinguishable to someone who does not already hold
    the password — otherwise the login form reports which former employees still
    have rows.
    """
    user = find_by_email(session, email)
    if user is None:
        passwords.waste_time()
        return SignIn(outcome=Outcome.NO_SUCH_USER)

    _scope_to_user(session, user.id)
    identity = session.scalars(
        select(UserIdentity).where(
            UserIdentity.user_id == user.id,
            UserIdentity.provider == PASSWORD_PROVIDER,
        )
    ).one_or_none()

    if identity is None or not identity.secret:
        # A real person who signs in through their firm's identity provider and
        # has no password here. Costs the same as a wrong one.
        passwords.waste_time()
        return SignIn(outcome=Outcome.WRONG_PASSWORD, user_id=user.id)

    matched, should_rehash = passwords.verify(identity.secret, password)
    if not matched:
        return SignIn(outcome=Outcome.WRONG_PASSWORD, user_id=user.id)

    if user.status != "active":
        return SignIn(outcome=Outcome.NOT_ACTIVE, user_id=user.id)

    if should_rehash:
        # The one moment the plaintext is known correct, which is the only
        # moment an upgrade to stronger parameters can happen.
        identity.secret = passwords.hash_password(password, email=user.email)
    identity.last_used_at = _now()
    session.flush()

    if not second_factors(session, user.id):
        return SignIn(user=user, mfa_satisfied=False)

    if not code:
        return SignIn(outcome=Outcome.MFA_REQUIRED, user_id=user.id)
    if not check_second_factor(session, user.id, code):
        return SignIn(outcome=Outcome.MFA_WRONG, user_id=user.id)
    return SignIn(user=user, mfa_satisfied=True, user_id=user.id)
