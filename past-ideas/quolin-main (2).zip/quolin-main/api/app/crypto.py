"""One data key per customer, wrapped by a key this deployment holds.

Row-level security stops one customer reading another's rows. It does nothing
about the people who can read the whole database: a restored backup, a stolen
snapshot, a support engineer with a psql prompt. Encryption is the answer to
that second question, and it is the one a bank's diligence team asks first.

**The envelope.** Each tenant has a random 256-bit data key. That key never
appears in the database in the clear — `tenant_keys` holds it wrapped under a
master key that lives in the environment (Fly secrets today, AWS Secrets
Manager or KMS when the Terraform in `infra/` is applied). So a database dump
on its own decrypts nothing, and the two things an attacker needs are held by
two different systems.

**Why per tenant rather than one key for everything.** A single key means one
compromise exposes every customer, and it means "is our data encrypted under a
key nobody else's data uses" gets a no. It also makes offboarding a customer a
real operation rather than a promise: destroy the wrapped key and their
ciphertext is unreadable, including in every backup already taken.

**AAD binds ciphertext to where it was stored.** Every value is sealed with
additional data naming the tenant and the column. Moving a ciphertext to
another tenant's row, or into a different column, makes it fail to decrypt
rather than quietly decode. This is the same reasoning that put `tenant_id`
inside the decision hash — a misfiled record should be wrong on its own terms,
not merely inconsistent with its neighbours.

**What this does not defend against.** A live process holding the master key
can read everything that process's tenant can reach; encryption at rest is not
access control, and RLS remains the thing that separates customers at runtime.
Ciphertexts are not bound to their row id, so an operator who has already
defeated the append-only trigger could swap two values within one tenant and
one column. The hash chain catches that on decisions, which is where it
matters; on `clients` it is an accepted gap, recorded in `docs/post-raise.md`.
"""

from __future__ import annotations

import base64
import json
import os
from datetime import date
from typing import Any

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from sqlalchemy import LargeBinary
from sqlalchemy.engine import Dialect
from sqlalchemy.orm import Session
from sqlalchemy.types import TypeDecorator

from .tenancy import current_tenant

MASTER_KEY_ENV = "QUOLIN_MASTER_KEY"

#: AES-GCM's nonce. Twelve bytes is the size the construction is specified for;
#: anything else is passed through a hash first and loses the guarantee.
NONCE_BYTES = 12

#: 256-bit keys throughout, master and data alike.
KEY_BYTES = 32

#: The first byte of every ciphertext. There is exactly one format today, and
#: the byte is here so that the day there are two, old values can still be read
#: — a stored ciphertext outlives the code that wrote it, and evidence that
#: cannot be decrypted after an upgrade is evidence that has been destroyed.
FORMAT_V1 = 1


class KeysNotConfigured(RuntimeError):
    """No master key. Raised at boot: an API that cannot decrypt must not start."""


class NoDataKey(RuntimeError):
    """This tenant has no data key.

    Raised rather than generated on the spot. A key that appears the first time
    somebody writes a row is a key whose creation nobody recorded, and a tenant
    whose provisioning half-finished would silently get a second one — leaving
    the rows written before it permanently unreadable.
    """


def master_key() -> bytes:
    """The key that wraps every tenant's data key.

    Read on every call rather than cached at import, so a rotated key takes
    effect on restart with no code path able to serve a stale one.
    """
    raw = os.getenv(MASTER_KEY_ENV, "")
    if not raw:
        raise KeysNotConfigured(
            f"{MASTER_KEY_ENV} is not set. The API will not start without it: "
            "every client snapshot and every name on file is encrypted under a "
            "key it wraps, so starting without one would mean either serving "
            "nothing or writing plaintext. Generate one with "
            "`make master-key` and see docs/deployment.md."
        )
    try:
        key = base64.b64decode(raw, validate=True)
    except Exception as exc:
        raise KeysNotConfigured(
            f"{MASTER_KEY_ENV} is not valid base64. It is {KEY_BYTES} random "
            "bytes, base64-encoded — not a passphrase."
        ) from exc
    if len(key) != KEY_BYTES:
        raise KeysNotConfigured(
            f"{MASTER_KEY_ENV} decodes to {len(key)} bytes; {KEY_BYTES} are "
            "required. A short key is not a weaker version of this, it is a "
            "different algorithm that nothing here implements."
        )
    return key


def new_key() -> bytes:
    return os.urandom(KEY_BYTES)


def _seal(key: bytes, plaintext: bytes, aad: bytes) -> bytes:
    nonce = os.urandom(NONCE_BYTES)
    return bytes([FORMAT_V1]) + nonce + AESGCM(key).encrypt(nonce, plaintext, aad)


def _open(key: bytes, sealed: bytes, aad: bytes) -> bytes:
    if not sealed or sealed[0] != FORMAT_V1:
        raise ValueError(
            f"ciphertext does not begin with a known format byte "
            f"({sealed[:1]!r}); it was not written by this code"
        )
    nonce = sealed[1 : 1 + NONCE_BYTES]
    return AESGCM(key).decrypt(nonce, sealed[1 + NONCE_BYTES :], aad)


def _wrap_aad(tenant_id: str) -> bytes:
    return f"quolin:wrap:{tenant_id}".encode()


def wrap(data_key: bytes, tenant_id: str) -> bytes:
    """Seal a tenant's data key under the master key.

    The tenant is in the AAD, so a wrapped key copied onto another tenant's row
    will not unwrap. Without that, moving one row would hand a customer another
    customer's key while every constraint in the schema stayed satisfied.
    """
    return _seal(master_key(), data_key, _wrap_aad(tenant_id))


def unwrap(wrapped: bytes, tenant_id: str) -> bytes:
    try:
        return _open(master_key(), bytes(wrapped), _wrap_aad(tenant_id))
    except InvalidTag as exc:
        raise KeysNotConfigured(
            f"The data key for tenant {tenant_id!r} does not unwrap under the "
            f"configured {MASTER_KEY_ENV}. Either the master key is the wrong "
            "one, or the key was rotated without `scripts/rotate_keys.py` "
            "having rewrapped this tenant. Refusing to continue: writing new "
            "rows now would encrypt them under a key nothing else here uses."
        ) from exc


# ------------------------------------------------------------ the key cache --

#: Unwrapped data keys, per tenant, for the life of the process.
#:
#: Populated on first use and never invalidated, which is safe precisely because
#: rotation rewraps the data key rather than replacing it — the plaintext key a
#: process holds stays correct across a rotation, and the ciphertexts it wrote
#: stay readable. See `scripts/rotate_keys.py` for why that is the rotation the
#: system has.
_KEYS: dict[str, bytes] = {}


def ensure_key(session: Session, tenant_id: str) -> bytes:
    """Give a tenant a data key if it has none, and return the plaintext key.

    Idempotent, and called explicitly at the moment a tenant is created — by the
    seed today and by whatever provisions a customer later. Never lazily from a
    write path, for the reason on `NoDataKey`.
    """
    from .models import TenantKey  # deferred: models imports the types below

    existing = session.get(TenantKey, tenant_id)
    if existing is not None:
        key = unwrap(existing.wrapped_key, tenant_id)
        _KEYS[tenant_id] = key
        return key

    key = new_key()
    session.add(TenantKey(tenant_id=tenant_id, wrapped_key=wrap(key, tenant_id)))
    session.flush()
    _KEYS[tenant_id] = key
    return key


def data_key() -> bytes:
    """This tenant's data key, unwrapped.

    Opens its own short-lived session on a cache miss rather than taking one as
    an argument. The callers are SQLAlchemy type decorators, which are handed a
    value and a dialect and have no session to be given — and threading one to
    them would mean every read path in the application knowing about keys, which
    is the arrangement this module exists to avoid.
    """
    tenant_id = current_tenant()
    key = _KEYS.get(tenant_id)
    if key is not None:
        return key

    from .db import SessionLocal
    from .models import TenantKey

    with SessionLocal() as session:
        row = session.get(TenantKey, tenant_id)
    if row is None:
        raise NoDataKey(
            f"Tenant {tenant_id!r} has no row in tenant_keys, so there is no "
            "key to read or write its data under. New tenants get one from "
            "`crypto.ensure_key`; a database migrated from before Stage 1 gets "
            "one from migration 0005."
        )
    key = unwrap(row.wrapped_key, tenant_id)
    _KEYS[tenant_id] = key
    return key


def forget_keys() -> None:
    """Drop the cache. For tests, and for a process that has just rotated."""
    _KEYS.clear()


# -------------------------------------------------------- the platform key --

#: The reserved tenant that owns platform data rather than customer data.
#:
#: It exists because Stage 2 introduced a secret that belongs to a *person*, not
#: to a customer: a TOTP seed. A user may hold roles in several tenants — the
#: consultancy case the execution document calls out by name — so there is no
#: one tenant whose key is the right one to seal their second factor under, and
#: picking whichever tenant they happened to log into would make the secret
#: unreadable from the others.
#:
#: The alternative considered and rejected was deriving a key from the master
#: key with HKDF, which needs no table at all. It also silently breaks rotation:
#: the whole point of the envelope is that rewrapping the master key leaves
#: every ciphertext readable, and a key *derived* from the master key changes
#: when the master key does. A real row in `tenant_keys` gets rotation for free,
#: because `scripts/rotate_keys.py` walks that table and does not care what the
#: rows mean.
#:
#: It carries `status = 'platform'` so that anything listing customers can
#: exclude it by asking a question about the row rather than by string-matching
#: this constant.
PLATFORM_TENANT = "_platform"


def platform_key() -> bytes:
    """The data key platform secrets are sealed under.

    Separate from `data_key()` rather than a special case inside it, because the
    two answer different questions — "which customer's key" and "the platform's
    key" — and a single function that returns either depending on ambient state
    is one a caller can be wrong about without noticing.
    """
    key = _KEYS.get(PLATFORM_TENANT)
    if key is not None:
        return key

    from . import tenancy
    from .db import SessionLocal
    from .models import TenantKey

    # `tenant_keys` is under forced RLS like everything else, so this row is
    # visible only to a connection that says it is acting as the platform. That
    # is the point rather than an obstacle: the platform key is reachable by
    # naming it, not by being logged in. The scope is around the session so that
    # `app.tenant_id` is bound when the transaction opens, and it does not
    # disturb whatever tenant the caller was in — `acting_as` restores it.
    with tenancy.acting_as(PLATFORM_TENANT), SessionLocal() as session:
        row = session.get(TenantKey, PLATFORM_TENANT)
    if row is None:
        raise NoDataKey(
            f"There is no data key for {PLATFORM_TENANT!r}, so platform secrets "
            "cannot be read or written. Migration 0007 creates the tenant row; "
            "the key itself comes from `crypto.ensure_key`, called by the seed "
            "and by `make platform-key` on a database that already has rows. "
            "Not created lazily here, for the reason on `NoDataKey`."
        )
    key = unwrap(row.wrapped_key, PLATFORM_TENANT)
    _KEYS[PLATFORM_TENANT] = key
    return key


# ------------------------------------------------------------- the envelope --


def _column_aad(column: str) -> bytes:
    return f"quolin:v1:{current_tenant()}:{column}".encode()


def encrypt(plaintext: bytes, *, column: str) -> bytes:
    return _seal(data_key(), plaintext, _column_aad(column))


def decrypt(ciphertext: bytes, *, column: str) -> bytes:
    try:
        return _open(data_key(), bytes(ciphertext), _column_aad(column))
    except InvalidTag as exc:
        raise ValueError(
            f"A value in {column} failed authentication under this tenant's "
            "data key. It was written for a different tenant or a different "
            "column, or it has been altered since. Refusing to return "
            "anything: a half-decoded record read as a whole one is how a "
            "tampered snapshot gets treated as evidence."
        ) from exc


# --------------------------------------------------------------- the columns --


class _Encrypted(TypeDecorator[Any]):
    """A column that is ciphertext in the database and a value in Python.

    Applied at the column rather than at the service boundary on purpose. The
    alternative — encrypt in the handler that writes, decrypt in the handler
    that reads — works until the eleventh write site, and the failure mode is
    not a crash but a plaintext name in a table everyone believes is encrypted.
    A column type cannot be forgotten, because there is nothing to remember.
    """

    impl = LargeBinary
    cache_ok = True

    def __init__(self, column: str) -> None:
        super().__init__()
        self.column = column

    def process_bind_param(self, value: Any, dialect: Dialect) -> bytes | None:
        if value is None:
            return None
        return encrypt(self.dump(value), column=self.column)

    def process_result_value(self, value: Any, dialect: Dialect) -> Any:
        if value is None:
            return None
        return self.load(decrypt(value, column=self.column))

    def dump(self, value: Any) -> bytes:
        raise NotImplementedError

    def load(self, raw: bytes) -> Any:
        raise NotImplementedError


class EncryptedText(_Encrypted):
    def dump(self, value: Any) -> bytes:
        return str(value).encode("utf-8")

    def load(self, raw: bytes) -> Any:
        return raw.decode("utf-8")


class PlatformEncryptedText(EncryptedText):
    """Text sealed under the platform key rather than a customer's.

    The AAD names `_platform` in the tenant position, so a value written here
    still cannot be moved into a tenant-scoped column, and a tenant's ciphertext
    cannot be moved into this one. The binding is the same shape as everywhere
    else; only the key differs.
    """

    def process_bind_param(self, value: Any, dialect: Dialect) -> bytes | None:
        if value is None:
            return None
        return _seal(platform_key(), self.dump(value), self._aad())

    def process_result_value(self, value: Any, dialect: Dialect) -> Any:
        if value is None:
            return None
        try:
            return self.load(_open(platform_key(), bytes(value), self._aad()))
        except InvalidTag as exc:
            raise ValueError(
                f"A value in {self.column} failed authentication under the "
                "platform key. It was written under a different key or has "
                "been altered since."
            ) from exc

    def _aad(self) -> bytes:
        return f"quolin:v1:{PLATFORM_TENANT}:{self.column}".encode()


class EncryptedDate(_Encrypted):
    def dump(self, value: Any) -> bytes:
        return value.isoformat().encode("ascii")

    def load(self, raw: bytes) -> Any:
        return date.fromisoformat(raw.decode("ascii"))


class EncryptedJSON(_Encrypted):
    """JSON, encoded the way the hash chain encodes it.

    Sort keys and no whitespace, which is `canonical.canonical_json`'s encoding
    — deliberately, so that what is stored decodes to something that hashes to
    the value already on the record. A snapshot that round-trips through this
    column and no longer produces its own hash would break replay, and replay
    is the guarantee the product is sold on.
    """

    def dump(self, value: Any) -> bytes:
        return json.dumps(
            value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
        ).encode("utf-8")

    def load(self, raw: bytes) -> Any:
        return json.loads(raw.decode("utf-8"))
