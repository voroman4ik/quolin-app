"""Who can do what, and who has not done anything in a while.

The execution document asks for a script that emits the quarterly access-review
report, and is specific about why: *the SOC 2 control is the report being
generated and signed off*, so the thing to optimise is that generating it is
trivial. A control that depends on somebody assembling a spreadsheet by hand
once a quarter is a control that is performed twice and then quietly skipped.

**A report, not a dump.** A list of every user and every grant is what the
access review is *made of*, but it is not the review. The review is somebody
deciding whether each of those grants should still exist, and what makes that
decision cheap is having the questionable ones already picked out. So the
findings below are the point of this module, and the roster underneath them is
the evidence for each one.

**Read through the tenant's own eyes.** This runs as the application role with a
tenant in scope, which means row-level security decides what it can see: a firm
appears in its own review exactly because it granted somebody a role, and the
`user_reachable` and `user_identities_reachable` policies from migration 0007
exist for this caller specifically. That is deliberate — a report assembled by a
connection that could see everything would be a report nobody could check
against what the product actually enforces.

The consequence is that tenants are named rather than discovered, the same
constraint `scripts/rechain.py` documents: under `FORCE ROW LEVEL SECURITY` a
query for "all tenants" returns the one in scope, so a discovery mode would work
in development and silently review nothing in production.

**What it deliberately does not do.** It changes nothing. No grant is revoked,
no account suspended, no expiry extended. Every finding is a sentence for a
person to act on, because the act of removing someone's access is a decision
with a name against it and this is not a place that decision should be made.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Iterable

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from . import tenancy
from .models import (
    MFA_REQUIRED_ROLES,
    ROLES_A_MACHINE_MAY_NOT_EXERCISE,
    ApiClient,
    AuditEvent,
    MfaCredential,
    Tenant,
    User,
    UserIdentity,
    UserRole,
)

#: A grant nobody has exercised in this long is the review's main business.
#: A quarter, because that is the review's own cadence: anybody who has done
#: nothing since the last review is exactly who this one is asked about.
DEFAULT_INACTIVE_DAYS = 90

#: Pairs of roles that one person holding both should be looked at. Not a
#: prohibition — the engine already refuses the *acts* by person, so holding
#: both is survivable and sometimes necessary at a small firm. It is a finding
#: because the reason it is survivable is a runtime check, and a reviewer should
#: know how much weight that check is carrying.
CONFLICTING_ROLES = (
    ("operator", "approver"),
    ("pack_signatory", "tenant_admin"),
)

SEVERITIES = ("attention", "review", "note")

#: Roles a machine credential may not sensibly hold.
#:
#: Every one of these is an act a regulator would want a name against: approving
#: an override, signing rule content, granting somebody else a role. A machine
#: cannot be asked why it did any of them, so a credential holding one is either
#: a misconfiguration or an integration that has been handed a person's job.
#:
#: Not prevented at grant time — this stage does not add a rule the product will
#: then have to explain — but reported as the loudest finding there is, which is
#: how a reviewer finds out before an auditor does.
#: Read from `models` rather than restated. This used to be its own tuple, and
#: a second copy of a security rule is a second copy to drift — the middleware
#: now *enforces* the same list, and a report naming a different set from the one
#: being enforced is worse than no report.
ROLES_A_MACHINE_SHOULD_NOT_HOLD = ROLES_A_MACHINE_MAY_NOT_EXERCISE


@dataclass(frozen=True)
class Grant:
    """One role, held by one person, in the tenant being reviewed."""

    role: str
    jurisdiction: str
    qualification_ref: str
    granted_at: datetime | None
    granted_by: str
    expires_at: datetime | None

    def live_at(self, when: datetime) -> bool:
        return self.expires_at is None or self.expires_at > when

    def describe(self) -> str:
        label = f"{self.role} ({self.jurisdiction})" if self.jurisdiction else self.role
        return f"{label}, granted by {self.granted_by or 'unrecorded'}"


@dataclass(frozen=True)
class Person:
    """A person as the review sees them: their access, and their use of it."""

    user_id: str
    email: str
    display_name: str
    status: str
    grants: list[Grant]
    #: How this person proves who they are — `password`, or `oidc via <issuer>`.
    #: Plural because a firm moving onto its identity provider has people
    #: holding both for a while, and that is worth being able to see.
    methods: list[str]
    #: Confirmed second factors only. An abandoned enrolment is not a factor.
    second_factors: int
    last_sign_in: datetime | None
    last_action_at: datetime | None
    actions: int

    def live_grants(self, when: datetime) -> list[Grant]:
        return [g for g in self.grants if g.live_at(when)]

    def roles_held(self, when: datetime) -> set[str]:
        return {g.role for g in self.live_grants(when)}

    def idle_days(self, when: datetime) -> int | None:
        """Days since this person last did anything, or None if they never have.

        Measured from the audit trail rather than from a session row, because
        sessions are deleted when they lapse — a person who signed in daily for a
        year and stopped last month would look, to `auth_sessions`, exactly like
        somebody who has never signed in at all.
        """
        if self.last_action_at is None:
            return None
        return (when - self.last_action_at).days


@dataclass(frozen=True)
class Credential:
    """A machine that may act, as the review sees it.

    Separate from `Person` rather than a flag on it, because a reviewer asks
    different questions. A person has a second factor, a last sign-in and a line
    manager; a credential has an expiry, an owner who created it, and a label
    that is the only thing saying what it is for. Collapsing them would produce a
    table where half the columns are blank for half the rows.
    """

    client_id: str
    label: str
    status: str
    roles: list[str]
    created_at: datetime | None
    created_by: str
    last_used_at: datetime | None
    expires_at: datetime | None
    #: Audit rows naming this credential. A machine's "activity" is what it did,
    #: not when it signed in — there is no sign-in.
    actions: int
    last_action_at: datetime | None

    def live_at(self, when: datetime) -> bool:
        return self.status == "active" and (
            self.expires_at is None or self.expires_at > when
        )

    def idle_days(self, when: datetime) -> int | None:
        if self.last_action_at is None:
            return None
        return (when - self.last_action_at).days


@dataclass(frozen=True)
class Finding:
    """One thing for the reviewer to decide about.

    `severity` orders the reviewer's attention and nothing else — nothing in the
    system reads it, and no finding here fails a build. That is on purpose: an
    access review that could fail CI would be an access review people learn to
    make empty.
    """

    kind: str
    severity: str
    subject: str
    detail: str


@dataclass(frozen=True)
class TenantReview:
    tenant_id: str
    tenant_name: str
    as_of: datetime
    inactive_days: int
    people: list[Person]
    #: Machine credentials. Stage 4 made these a second kind of actor that holds
    #: roles and appears in the audit trail, so a review that listed only people
    #: would be a document claiming to say who has access while omitting some of
    #: the things that do.
    credentials: list[Credential] = field(default_factory=list)
    findings: list[Finding] = field(default_factory=list)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _aware(value: datetime | None) -> datetime | None:
    """Postgres hands these back with a timezone; SQLite in a unit test may not.

    Normalised here rather than at each comparison, because a naive/aware
    mix-up raises `TypeError` deep inside a subtraction and reads as a bug in
    the arithmetic rather than in the row.
    """
    if value is None or value.tzinfo is not None:
        return value
    return value.replace(tzinfo=timezone.utc)


def _latest(values: Iterable[datetime | None]) -> datetime | None:
    """The most recent of some timestamps, ignoring the ones that are absent.

    A person may hold a password identity they have used and a federated one
    they have not, so "when did they last sign in" is a maximum over a list with
    holes in it rather than over a list.
    """
    present = [v for v in values if v is not None]
    return max(present) if present else None


# ------------------------------------------------------------------ collection --


def collect(
    session: Session,
    *,
    tenant_id: str,
    as_of: datetime | None = None,
    inactive_days: int = DEFAULT_INACTIVE_DAYS,
) -> TenantReview:
    """Assemble one tenant's review. Reads only.

    The caller is responsible for having entered the tenant's scope — this does
    not enter it itself, because a function that silently changed the ambient
    tenant would be one whose reads are hard to reason about from the call site.
    """
    when = as_of or _now()

    tenant = session.get(Tenant, tenant_id)
    grants_by_user: dict[str, list[Grant]] = {}
    for row in session.scalars(select(UserRole).order_by(UserRole.granted_at)):
        grants_by_user.setdefault(row.user_id, []).append(
            Grant(
                role=row.role,
                jurisdiction=row.jurisdiction or "",
                qualification_ref=row.qualification_ref or "",
                granted_at=_aware(row.granted_at),
                granted_by=row.granted_by or "",
                expires_at=_aware(row.expires_at),
            )
        )

    # One query for the whole tenant rather than one per person. The audit trail
    # is the largest table in the system and the review is a report, not a
    # request — but a report that took a round trip per employee would be the
    # kind of thing somebody switches off at the first firm with two hundred.
    activity = {
        actor: (_aware(last), count)
        for actor, last, count in session.execute(
            select(AuditEvent.actor, func.max(AuditEvent.at), func.count()).group_by(
                AuditEvent.actor
            )
        )
    }

    people: list[Person] = []
    for user_id, grants in grants_by_user.items():
        user = session.get(User, user_id)
        if user is None:
            # A grant naming somebody this tenant cannot see. Not silently
            # dropped — it becomes a finding below, because a role held by a row
            # nobody can resolve is precisely what a review exists to catch.
            people.append(
                Person(
                    user_id=user_id,
                    email="",
                    display_name="",
                    status="unresolvable",
                    grants=grants,
                    methods=[],
                    second_factors=0,
                    last_sign_in=None,
                    last_action_at=None,
                    actions=0,
                )
            )
            continue

        identities = list(
            session.scalars(select(UserIdentity).where(UserIdentity.user_id == user_id))
        )
        last_action, actions = activity.get(user_id, (None, 0))
        people.append(
            Person(
                user_id=user_id,
                email=user.email,
                display_name=user.display_name,
                status=user.status,
                grants=grants,
                methods=sorted(
                    f"oidc via {i.issuer}" if i.provider == "oidc" else i.provider
                    for i in identities
                ),
                second_factors=len(
                    [
                        c
                        for c in session.scalars(
                            select(MfaCredential).where(MfaCredential.user_id == user_id)
                        )
                        if c.confirmed_at is not None
                    ]
                ),
                last_sign_in=_latest(_aware(i.last_used_at) for i in identities),
                last_action_at=last_action,
                actions=actions,
            )
        )

    people.sort(key=lambda p: (p.email or p.user_id))

    credentials = [
        Credential(
            client_id=row.id,
            label=row.label,
            status=row.status,
            roles=sorted(row.roles or []),
            created_at=_aware(row.created_at),
            created_by=row.created_by or "",
            last_used_at=_aware(row.last_used_at),
            expires_at=_aware(row.expires_at),
            actions=activity.get(row.id, (None, 0))[1],
            last_action_at=activity.get(row.id, (None, 0))[0],
        )
        for row in session.scalars(select(ApiClient).order_by(ApiClient.created_at))
    ]

    return TenantReview(
        tenant_id=tenant_id,
        tenant_name=tenant.name if tenant is not None else "",
        as_of=when,
        inactive_days=inactive_days,
        people=people,
        credentials=credentials,
        findings=(
            examine(people, when=when, inactive_days=inactive_days)
            + examine_credentials(credentials, when=when, inactive_days=inactive_days)
        ),
    )


def collect_all(
    tenant_ids: list[str],
    *,
    as_of: datetime | None = None,
    inactive_days: int = DEFAULT_INACTIVE_DAYS,
) -> list[TenantReview]:
    """Review several tenants, each in its own session.

    A session per tenant, and this is the whole reason the loop lives here
    rather than in the script. `app.tenant_id` is bound when a transaction
    *begins* — so a single session reused across the loop assembles the second
    tenant's report inside the first tenant's still-open transaction, and every
    section after the first names the first firm's staff.

    That is not a cosmetic bug. It is one customer's employee list printed under
    another customer's heading, in the document that exists to prove the two
    cannot see each other. It was written that way first and caught by reading
    the output, which is why the loop is now in a module a test can reach and
    why `test_access_review.py` asserts the isolation directly.
    """
    from .db import SessionLocal

    reviews = []
    for tenant_id in tenant_ids:
        with tenancy.acting_as(tenant_id):
            session = SessionLocal()
            try:
                reviews.append(
                    collect(
                        session,
                        tenant_id=tenant_id,
                        as_of=as_of,
                        inactive_days=inactive_days,
                    )
                )
            finally:
                session.close()
    return reviews


# -------------------------------------------------------------------- findings --


def examine(people: list[Person], *, when: datetime, inactive_days: int) -> list[Finding]:
    """Everything in the roster a reviewer should be asked about.

    Ordered by severity and then by subject, so that a report read from the top
    is read in the order the questions are worth asking.
    """
    found: list[Finding] = []
    cutoff = when - timedelta(days=inactive_days)

    for person in people:
        who = person.email or person.user_id
        live = person.live_grants(when)
        roles = person.roles_held(when)

        if person.status == "unresolvable":
            found.append(
                Finding(
                    "grant_names_nobody",
                    "attention",
                    who,
                    f"{len(person.grants)} grant(s) name a user this tenant cannot "
                    "resolve. Either the account was removed — which it should not "
                    "have been — or the grant belongs to a different firm.",
                )
            )
            continue

        if live and person.status != "active":
            found.append(
                Finding(
                    "inactive_account_with_access",
                    "attention",
                    who,
                    f"Account is {person.status} but still holds "
                    f"{len(live)} live grant(s). Sign-in is refused today, so this is "
                    "not an open door — but the grants should be removed rather than "
                    "left for whoever reactivates the account.",
                )
            )

        for role in sorted(roles & set(MFA_REQUIRED_ROLES)):
            # Only where a password is in play. Where the firm's identity
            # provider authenticates, the second factor is its policy and is not
            # visible here — reporting its absence would be reporting our own
            # ignorance as the person's failing.
            if person.second_factors == 0 and "password" in person.methods:
                found.append(
                    Finding(
                        "no_second_factor",
                        "attention",
                        who,
                        f"Holds {role}, which requires a second factor, and has "
                        "none enrolled. This account is locked pending enrolment: "
                        "it can sign in, enrol an authenticator and nothing else. "
                        "Until Stage 13 that constant was checked only here and "
                        "enforced nowhere; it is enforced at the session and at "
                        "the action now, so this line reports a state rather than "
                        "a gap.",
                    )
                )
                break

        for first, second in CONFLICTING_ROLES:
            if {first, second} <= roles:
                found.append(
                    Finding(
                        "separation_of_duties",
                        "review",
                        who,
                        f"Holds both {first} and {second}. The engine still refuses the "
                        "combined act — nobody approves their own determination or "
                        "publishes their own signature — so this is not a breach. It is "
                        "a question of whether one person should be that close to both "
                        "halves at all.",
                    )
                )

        for grant in live:
            if grant.role == "quolin_support":
                found.append(
                    Finding(
                        "support_access",
                        "attention" if grant.expires_at is None else "review",
                        who,
                        "Quolin support access is live"
                        + (
                            ", with no expiry set. The execution document requires "
                            "these to be time-boxed."
                            if grant.expires_at is None
                            else f", until {grant.expires_at:%Y-%m-%d}."
                        ),
                    )
                )
            if grant.role == "pack_signatory" and not grant.qualification_ref:
                found.append(
                    Finding(
                        "signatory_without_qualification",
                        "review",
                        who,
                        f"Signs {grant.jurisdiction or 'an unnamed regime'} with no "
                        "qualification recorded. The signature prints this field, so "
                        "an empty one is a signature that says nothing about why it "
                        "can be relied on.",
                    )
                )
            if not grant.granted_by:
                found.append(
                    Finding(
                        "grant_without_granter",
                        "review",
                        who,
                        f"{grant.describe()} — nobody is recorded as having granted it.",
                    )
                )

        if live:
            idle = person.idle_days(when)
            if idle is None:
                found.append(
                    Finding(
                        "never_used",
                        "review",
                        who,
                        f"Holds {len(live)} live grant(s) and has never taken an action. "
                        "Either the access was never needed, or it was granted in "
                        "advance of a start date that has passed.",
                    )
                )
            elif person.last_action_at is not None and person.last_action_at < cutoff:
                found.append(
                    Finding(
                        "inactive",
                        "review",
                        who,
                        f"Last acted {idle} days ago ({person.last_action_at:%Y-%m-%d}), "
                        f"which is beyond the {inactive_days}-day window, and still "
                        f"holds {len(live)} grant(s).",
                    )
                )

        lapsed = [g for g in person.grants if not g.live_at(when)]
        if lapsed:
            found.append(
                Finding(
                    "lapsed_grants",
                    "note",
                    who,
                    f"{len(lapsed)} grant(s) have expired and are no longer in force. "
                    "Kept on file deliberately — the record of what somebody could once "
                    "do is what a reviewer looking at last quarter needs.",
                )
            )

    return _ordered(found)


def _ordered(found: list[Finding]) -> list[Finding]:
    order = {name: i for i, name in enumerate(SEVERITIES)}
    return sorted(
        found, key=lambda f: (order.get(f.severity, len(SEVERITIES)), f.subject, f.kind)
    )


def examine_credentials(
    credentials: list[Credential], *, when: datetime, inactive_days: int
) -> list[Finding]:
    """What a reviewer should be asked about the machines.

    Different questions from the ones asked about people, which is why this is a
    separate function rather than a branch inside `examine`. Nobody asks whether
    a credential has enrolled a second factor; everybody should ask when it was
    last rotated, and whether it can do something only a person should.
    """
    found: list[Finding] = []
    cutoff = when - timedelta(days=inactive_days)

    for credential in credentials:
        who = f"{credential.label or credential.client_id} ({credential.client_id})"

        overreaching = sorted(
            set(credential.roles) & set(ROLES_A_MACHINE_SHOULD_NOT_HOLD)
        )
        if overreaching and credential.live_at(when):
            found.append(
                Finding(
                    "machine_holds_a_human_role",
                    "attention",
                    who,
                    f"Holds {', '.join(overreaching)} — acts a regulator would want a "
                    "name against. A machine cannot be asked why it approved an "
                    "override or signed rule content, so this is either a "
                    "misconfiguration or an integration doing a person's job.",
                )
            )

        if not credential.live_at(when):
            if credential.roles and credential.status == "active":
                found.append(
                    Finding(
                        "expired_credential_still_granted",
                        "note",
                        who,
                        f"Expired {credential.expires_at:%Y-%m-%d} and still carries "
                        f"{len(credential.roles)} role(s). It cannot authenticate, so "
                        "this is tidying rather than exposure.",
                    )
                )
            continue

        if credential.expires_at is None:
            found.append(
                Finding(
                    "credential_without_expiry",
                    "review",
                    who,
                    "Never expires. A machine credential with no expiry is one nobody "
                    "ever rotates, and the secret was shown once at creation — so the "
                    "only way to change it is to issue a new one deliberately.",
                )
            )

        if not credential.created_by:
            found.append(
                Finding(
                    "credential_without_an_owner",
                    "review",
                    who,
                    "Nobody is recorded as having created it. A credential with no "
                    "owner is one nobody can be asked about when this review reaches "
                    "the question of whether it is still needed.",
                )
            )

        idle = credential.idle_days(when)
        if idle is None:
            found.append(
                Finding(
                    "credential_never_used",
                    "review",
                    who,
                    "Has never taken an action. Either the integration was never "
                    "built, or it was issued in advance of one that has not arrived.",
                )
            )
        elif credential.last_action_at is not None and credential.last_action_at < cutoff:
            found.append(
                Finding(
                    "credential_inactive",
                    "review",
                    who,
                    f"Last acted {idle} days ago "
                    f"({credential.last_action_at:%Y-%m-%d}), beyond the "
                    f"{inactive_days}-day window, and can still authenticate.",
                )
            )

    return _ordered(found)


# ------------------------------------------------------------------ rendering --


def _stamp(value: datetime | None) -> str:
    return f"{value:%Y-%m-%d %H:%M} UTC" if value is not None else "never"


def render(reviews: list[TenantReview]) -> str:
    """The report, as the thing that gets signed.

    Markdown rather than CSV, because the deliverable is a document somebody
    reads, decides against, and puts their name on. A spreadsheet is the right
    shape for the roster alone and the wrong shape for the findings, and the
    findings are the part the control is actually about.
    """
    lines: list[str] = ["# Quarterly access review", ""]
    generated = reviews[0].as_of if reviews else _now()
    lines += [
        f"Generated {_stamp(generated)}.",
        "",
        "Read the findings, decide on each one, then record the decision and sign "
        "below. This report changes nothing by itself — every grant it names is "
        "still in force until somebody removes it.",
        "",
    ]

    for review in reviews:
        title = f"{review.tenant_name} (`{review.tenant_id}`)" if review.tenant_name else (
            f"`{review.tenant_id}`"
        )
        lines += [f"## {title}", ""]

        if not review.people and not review.credentials:
            lines += [
                "No role grants and no credentials. Nothing can act in this tenant, "
                "which is either one that has not been provisioned yet or one whose "
                "staff and integrations have all been removed.",
                "",
            ]
            continue

        lines += [f"### Findings ({len(review.findings)})", ""]
        if not review.findings:
            lines += ["None. Every grant is live, used, and held by an active account.", ""]
        else:
            for finding in review.findings:
                lines.append(
                    f"- **{finding.severity}** · `{finding.kind}` · **{finding.subject}** — "
                    f"{finding.detail}"
                )
            lines.append("")

        lines += [
            f"### People ({len(review.people)})",
            "",
            "| Person | Status | Roles | Signs in with | 2FA | Last action | Actions |",
            "|---|---|---|---|---|---|---|",
        ]
        for person in review.people:
            live = person.live_grants(review.as_of)
            roles = ", ".join(sorted(g.describe().split(",")[0] for g in live)) or "—"
            lines.append(
                f"| {person.display_name or '—'}<br>`{person.email or person.user_id}` "
                f"| {person.status} "
                f"| {roles} "
                f"| {', '.join(person.methods) or 'no credential'} "
                f"| {person.second_factors or '—'} "
                f"| {_stamp(person.last_action_at)} "
                f"| {person.actions} |"
            )
        lines.append("")

        # Machines, in their own table. Stage 4 made these a second kind of
        # actor that holds roles and appears in the audit trail — a review that
        # listed only people would be a document claiming to say who has access
        # while omitting some of the things that do.
        lines += [f"### Integrations ({len(review.credentials)})", ""]
        if not review.credentials:
            lines += ["None. Nothing but people can act in this tenant.", ""]
        else:
            lines += [
                "| Credential | Status | Roles | Created by | Expires | Last action | Actions |",
                "|---|---|---|---|---|---|---|",
            ]
            for credential in review.credentials:
                lines.append(
                    f"| {credential.label or '—'}<br>`{credential.client_id}` "
                    f"| {credential.status} "
                    f"| {', '.join(credential.roles) or '—'} "
                    f"| {credential.created_by or 'unrecorded'} "
                    f"| {_stamp(credential.expires_at) if credential.expires_at else 'never'} "
                    f"| {_stamp(credential.last_action_at)} "
                    f"| {credential.actions} |"
                )
            lines.append("")

    lines += [
        "---",
        "",
        "## Sign-off",
        "",
        "| | |",
        "|---|---|",
        "| Reviewed by | |",
        "| Role | |",
        "| Date | |",
        "| Decisions recorded | |",
        "",
    ]
    body = "\n".join(lines)
    # A digest of the report as rendered, so that "the report that was signed" is
    # a specific document rather than a description of one. It covers everything
    # above it and nothing below, which is why it is last.
    return f"{body}\nReport digest (SHA-256): `{digest(body)}`\n"


def digest(body: str) -> str:
    return hashlib.sha256(body.encode()).hexdigest()


def to_dict(review: TenantReview) -> dict:
    """The same content, for an evidence archive that is not read by a person."""
    return {
        "tenant_id": review.tenant_id,
        "tenant_name": review.tenant_name,
        "as_of": review.as_of.isoformat(),
        "inactive_days": review.inactive_days,
        "findings": [
            {
                "kind": f.kind,
                "severity": f.severity,
                "subject": f.subject,
                "detail": f.detail,
            }
            for f in review.findings
        ],
        "credentials": [
            {
                "client_id": c.client_id,
                "label": c.label,
                "status": c.status,
                "roles": c.roles,
                "created_at": c.created_at.isoformat() if c.created_at else None,
                "created_by": c.created_by,
                "last_used_at": c.last_used_at.isoformat() if c.last_used_at else None,
                "expires_at": c.expires_at.isoformat() if c.expires_at else None,
                "last_action_at": (
                    c.last_action_at.isoformat() if c.last_action_at else None
                ),
                "actions": c.actions,
                "live": c.live_at(review.as_of),
            }
            for c in review.credentials
        ],
        "people": [
            {
                "user_id": p.user_id,
                "email": p.email,
                "display_name": p.display_name,
                "status": p.status,
                "methods": p.methods,
                "second_factors": p.second_factors,
                "last_sign_in": p.last_sign_in.isoformat() if p.last_sign_in else None,
                "last_action_at": p.last_action_at.isoformat() if p.last_action_at else None,
                "actions": p.actions,
                "grants": [
                    {
                        "role": g.role,
                        "jurisdiction": g.jurisdiction,
                        "qualification_ref": g.qualification_ref,
                        "granted_at": g.granted_at.isoformat() if g.granted_at else None,
                        "granted_by": g.granted_by,
                        "expires_at": g.expires_at.isoformat() if g.expires_at else None,
                        "live": g.live_at(review.as_of),
                    }
                    for g in p.grants
                ],
            }
            for p in review.people
        ],
    }
