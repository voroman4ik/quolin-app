"""Telling every firm that the rules governing them have changed.

FP3-08. `pack.staged` and `pack.published` were emitted through
`service._tell_the_customers_systems`, which resolves subscribers with
`webhooks.endpoints_for` — an RLS-scoped query — inside the publisher's own
tenant transaction.

Packs are global. `quolin_operator` is Quolin's own role, granted inside a
tenant. So the only firm that could ever receive either event was whichever
tenant the publisher happened to be acting in, which is not a customer.

§S4 promises a staged-pack notice and §S5 has a "tenants notified" gate. Neither
had ever fired for anybody. It is the same shape as `source.stale` and was
missed for the same reason: the producer exists, is called, and writes rows, so
nothing reads as unwired — the rows simply go to a tenant nobody is watching.

**The same two-step as FP3-03, and for a second reason here.** The publish
endpoint records the event; a worker holding the maintenance grant fans it out.
The first reason is the one FP3-03 gives: fanning out means enumerating firms,
which needs a credential the request path must not hold. The second is FP3-04 —
the API task no longer holds `DATABASE_URL` at all, so it *cannot* enumerate
even if it wanted to.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import service
from .models import PackEvent, PackEventNotice, Tenant
from .source_alerts import regimes_for


def record(
    session: Session,
    *,
    event: str,
    subject: str,
    jurisdiction: str,
    payload: dict[str, Any],
) -> PackEvent:
    """Write down that a pack event happened. Tells nobody.

    Called from the publish and sign endpoints, which hold the application role
    and one tenant's scope — enough to write a global row, not enough to
    enumerate the firms that need to hear about it.
    """
    row = PackEvent(
        event=event,
        subject=subject,
        jurisdiction=(jurisdiction or "").upper(),
        payload=payload,
    )
    session.add(row)
    session.flush()
    return row


def pending(session: Session, tenant_id: str) -> list[PackEvent]:
    """Pack events this firm has not been told about yet."""
    told = select(PackEventNotice.pack_event_id).where(
        PackEventNotice.tenant_id == tenant_id
    )
    return list(
        session.scalars(
            select(PackEvent).where(PackEvent.id.not_in(told)).order_by(PackEvent.id)
        )
    )


def fan_out(session: Session, tenant_id: str) -> int:
    """Tell one firm about the pack events in its regimes that it has not heard.

    Runs as the application role inside that tenant's transaction, from the
    worker that already enumerates firms.

    A notice row is written for every pending event, including those in regimes
    this firm is not licensed in. "Told" and "decided not to tell" are both
    answers; leaving the second unrecorded would make the worker reconsider
    every out-of-regime event on every run for the life of the deployment.
    """
    tenant = session.get(Tenant, tenant_id)
    regimes = regimes_for(tenant)
    sent = 0

    for event in pending(session, tenant_id):
        if regimes is None or event.jurisdiction in regimes:
            service._tell_the_customers_systems(
                session,
                event=event.event,
                subject=event.subject,
                payload=dict(event.payload),
            )
            sent += 1
        session.add(PackEventNotice(pack_event_id=event.id, tenant_id=tenant_id))

    session.flush()
    return sent
