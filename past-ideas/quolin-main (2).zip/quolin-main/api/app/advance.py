"""Whether a new pack version applies to a customer, and when they agreed to it.

This is the answer to "how do you control vendor changes?", which is the first
question a bank's diligence team asks about a rules vendor and the one a
prototype usually has no answer to. §S5 is explicit that it is a feature rather
than paperwork.

Two policies:

* **auto** — a version applies when its effective date arrives. Right for a firm
  that wants their vendor's judgement, and the row recording it is still written
  so that "when did we move to v4" has an answer.
* **pinned** — the version is staged and the firm gets a window to check it
  against their own book before it applies. At the end of the window they
  advance, or they decline and escalate.

**Pinned is the default, and that is the safe choice rather than the convenient
one.** A firm that has not chosen has not agreed to rule content changing under
them without a look. Auto is a decision somebody makes.

**The policy is copied onto each advance rather than read from the tenant.** A
firm that switched from pinned to auto last month did not thereby change what
happened in March, and a report that derived the policy from the tenant row
would rewrite its own history every time somebody changed a setting.

**Declining is not refusing the version forever.** A pinned tenant that declines
stays on what they have and the row records that they looked and said no — which
is the thing to escalate. What it is not is a fork: there is one pack, and a firm
that will not take it has a conversation to have rather than a private copy of
the rules.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .identity import new_id
from .models import Pack, Tenant, TenantAdvance

#: Applies when the effective date arrives.
AUTO = "auto"
#: Staged, with a window to check it first.
PINNED = "pinned"
POLICIES = (AUTO, PINNED)

#: What a tenant that has not chosen gets. Pinned rather than auto: not choosing
#: is not the same as agreeing to rule content changing under you.
DEFAULT_POLICY = PINNED

#: What each policy means, in the words a customer reads.
#:
#: Beside the vocabulary rather than in the handler, for the reason
#: `adoption.WHAT_EACH_MEANS` gives: a screen that said "pinned" and nothing
#: else would leave the most important fact — that rule content will not change
#: under this firm without somebody looking — as tribal knowledge.
WHAT_EACH_MEANS = {
    AUTO: (
        "A new version of a rule pack applies the day it becomes effective. "
        "You are told it happened; you are not asked first."
    ),
    PINNED: (
        "A new version is staged and does not apply until you take it. You get "
        "a window to check the change against your own book, and if the window "
        "closes without a decision the version stays pending rather than "
        "applying."
    ),
}

#: How long a pinned tenant has, when their config does not say. Two weeks is a
#: fortnightly compliance meeting plus a few days, which is the cadence these
#: decisions actually get made on.
DEFAULT_WINDOW_DAYS = 14

#: What a window may be set to. A zero-day window is `auto` wearing the word
#: `pinned`, and a year is a firm that has stopped reading them — both are worth
#: refusing rather than storing.
MIN_WINDOW_DAYS = 1
MAX_WINDOW_DAYS = 90

PENDING = "pending"
ADVANCED = "advanced"
DECLINED = "declined"


class AdvanceError(ValueError):
    """An advance was asked for that does not make sense."""


def _now() -> datetime:
    return datetime.now(timezone.utc)


def policy_for(tenant: Tenant | None) -> tuple[str, int]:
    """This tenant's policy and window, with the safe defaults applied.

    Read from `config` rather than a column because it is a setting rather than
    a fact about the customer — and because Stage 1 put tenant configuration
    there deliberately, so that a new one is not a migration.
    """
    config = (tenant.config if tenant is not None else None) or {}
    policy = config.get("advance_policy", DEFAULT_POLICY)
    if policy not in POLICIES:
        # An unrecognised value is treated as pinned rather than as auto. A typo
        # in a config file must not be the reason a firm's rules changed without
        # them looking.
        policy = PINNED
    window = int(config.get("uat_window_days", DEFAULT_WINDOW_DAYS))
    return policy, window


def notice(
    session: Session,
    *,
    tenant_id: str,
    jurisdiction: str,
    pack_version: int,
    effective_from: datetime | None = None,
) -> TenantAdvance:
    """Record that a new version exists and what this tenant does about it.

    Idempotent per tenant per version — a unique constraint enforces it, and the
    existing row is returned rather than a second written. A sweep that runs
    twice must not give a firm two windows on the same change.

    An `auto` tenant is recorded as advanced immediately. The row is not
    ceremony: "we moved to v4 on the fourteenth without review, per our
    standing policy" is a thing a firm may need to evidence, and deriving it
    later from a policy setting that has since changed would be a guess.
    """
    existing = session.scalars(
        select(TenantAdvance).where(
            TenantAdvance.jurisdiction == jurisdiction,
            TenantAdvance.pack_version == pack_version,
        )
    ).first()
    if existing is not None:
        return existing

    tenant = session.get(Tenant, tenant_id)
    policy, window_days = policy_for(tenant)
    now = _now()

    row = TenantAdvance(
        id=new_id("adv"),
        jurisdiction=jurisdiction,
        pack_version=pack_version,
        policy=policy,
        noticed_at=now,
    )
    if policy == AUTO:
        row.status = ADVANCED
        row.advanced_at = effective_from or now
        row.advanced_by = "policy:auto"
        row.note = "advanced automatically, per this tenant's standing policy"
    else:
        row.status = PENDING
        row.window_closes_at = now + timedelta(days=window_days)
        row.note = f"staged for review; window of {window_days} days"

    session.add(row)
    session.flush()
    return row


def advance(
    session: Session, advance_id: str, *, actor: str, note: str = ""
) -> TenantAdvance:
    """A pinned tenant taking a version they have checked."""
    row = session.get(TenantAdvance, advance_id)
    if row is None:
        raise AdvanceError(f"no advance {advance_id!r} in this tenant")
    if row.status != PENDING:
        raise AdvanceError(
            f"advance {advance_id} is already {row.status!r}. A version is taken "
            "once; taking it again would put a second date on the same change."
        )
    row.status = ADVANCED
    row.advanced_at = _now()
    row.advanced_by = actor
    row.note = note or "reviewed and accepted"
    session.flush()
    return row


def decline(
    session: Session, advance_id: str, *, actor: str, note: str
) -> TenantAdvance:
    """A pinned tenant that has looked and will not take this version.

    A `note` is required rather than optional. The whole value of a decline is
    the reason — it is what gets escalated, and a declined version with no
    explanation is a dead end for whoever picks it up.

    This is not a fork. There is one pack; a firm that will not take a version
    stays on what they have and has a conversation to have. A private copy of
    the rules is the thing this product exists not to be.
    """
    row = session.get(TenantAdvance, advance_id)
    if row is None:
        raise AdvanceError(f"no advance {advance_id!r} in this tenant")
    if row.status != PENDING:
        raise AdvanceError(f"advance {advance_id} is already {row.status!r}")
    if not note.strip():
        raise AdvanceError(
            "declining a version needs a reason. It is what gets escalated, and a "
            "decline with no explanation is a dead end for whoever picks it up."
        )
    row.status = DECLINED
    row.advanced_by = actor
    row.note = note.strip()
    session.flush()
    return row


def taken_versions(session: Session, *, tenant_id: str) -> dict[str, list[int]]:
    """Every version this tenant has taken, per regime, ascending. Empty for `auto`.

    The batch form, and the one the shelf reads. `packs_repo.active_all`
    assembles every jurisdiction at once for a determination, and asking per
    regime there would be one query per regime on the interactive path for an
    answer that is a single small table.

    Every version rather than only the newest, because which one governs
    depends on what is in force — see `newest_taken`. A firm that took v2, then
    took a future-dated v4 during its review window, is on v2 until v4's date
    arrives, and a helper that had already collapsed that to `max` would have
    lost the fact that they never took v3.

    Empty rather than absent for an `auto` tenant, because auto means the shelf
    decides and an empty pin dictionary is exactly that.
    """
    tenant = session.get(Tenant, tenant_id)
    policy, _ = policy_for(tenant)
    if policy == AUTO:
        return {}  # the shelf decides; no pin to apply

    out: dict[str, list[int]] = {}
    for row in session.scalars(
        select(TenantAdvance).where(TenantAdvance.status == ADVANCED)
    ):
        out.setdefault(row.jurisdiction, []).append(row.pack_version)
    return {regime: sorted(set(versions)) for regime, versions in out.items()}


def newest_taken(versions: list[int], *, not_after: int | None = None) -> int | None:
    """The version that governs, out of the ones this firm has taken.

    `not_after` is the version actually in force. Taking a version early — which
    a review window positively encourages — must not bring it into effect early,
    so anything above the ceiling is ignored rather than applied. What remains
    is the newest version the firm has both taken *and* seen become effective.

    With every taken version above the ceiling, the answer is `None` and the
    shelf governs: a firm whose only advances are still in the future has not
    yet taken anything that applies.
    """
    if not_after is not None:
        versions = [v for v in versions if v <= not_after]
    return max(versions, default=None)


def effective_version_for(
    session: Session,
    *,
    tenant_id: str,
    jurisdiction: str,
    on: Any = None,
    not_after: int | None = None,
) -> int | None:
    """The version this tenant is actually on, which is not always the newest.

    A pinned tenant sits on the last version they advanced to until they take
    the next one. Returning the newest effective pack for them would be the
    single most damaging bug this module could have: their determinations would
    silently be made under rules they have not agreed to, which is precisely
    what pinning exists to prevent.

    F1: that is exactly what happened, and for two rounds. This function was
    written, documented and tested, and no caller in `api/app` ever asked it —
    so every determination went on reading the newest effective pack while the
    test asserting the pin passed. It is called from `packs_repo.active` now,
    which is where the shelf for a single regime is assembled;
    `packs_repo.active_all` uses `taken_versions` for the whole shelf.

    None means they have advanced to nothing yet, and the caller falls back to
    whatever was in force when they were provisioned.
    """
    return newest_taken(
        taken_versions(session, tenant_id=tenant_id).get(jurisdiction, []),
        not_after=not_after,
    )


def pending(session: Session) -> list[dict[str, Any]]:
    """Versions staged for this tenant, soonest deadline first.

    Soonest first because it is a to-do list. A window that closes on Friday
    matters more than one that closes next month, and sorting by when the change
    arrived would bury it.
    """
    rows = session.scalars(
        select(TenantAdvance)
        .where(TenantAdvance.status == PENDING)
        .order_by(TenantAdvance.window_closes_at)
    ).all()
    now = _now()
    return [
        {
            "id": r.id,
            "jurisdiction": r.jurisdiction,
            "pack_version": r.pack_version,
            "policy": r.policy,
            "noticed_at": r.noticed_at.isoformat(),
            "window_closes_at": (
                r.window_closes_at.isoformat() if r.window_closes_at else None
            ),
            "days_left": (
                (r.window_closes_at - now).days if r.window_closes_at else None
            ),
            # An overdue window is not automatically an advance. The firm still
            # has to look — the deadline is a prompt, and a version that applied
            # itself because nobody clicked would be pinning in name only.
            "overdue": bool(r.window_closes_at and r.window_closes_at < now),
            "note": r.note,
        }
        for r in rows
    ]


def overdue(session: Session, *, tenant_id: str = "", now: datetime | None = None):
    """Pinned versions whose review window has closed and been left. FP3-17.

    Still `PENDING`, deliberately. The two alternatives were considered and
    rejected: auto-advancing is what this module's own comment calls pinning in
    name only, and refusing determinations means halting a customer's business
    on our authority, which is a contractual position nobody has taken.
    """
    # `tenant_id` is accepted and not used in the query, and that is the tenancy
    # model rather than an oversight: `tenant_advances` is tenant-scoped, so the
    # policy on the table has already confined this to the firm in scope. The
    # parameter is there so a caller states which firm it believes it is asking
    # about, and it is optional for the readers that are already inside one.
    _ = tenant_id
    moment = now or _now()
    return [
        row
        for row in session.scalars(
            select(TenantAdvance)
            .where(
                TenantAdvance.status == PENDING,
                TenantAdvance.window_closes_at.is_not(None),
            )
            .order_by(TenantAdvance.window_closes_at)
        )
        if row.window_closes_at is not None and row.window_closes_at < moment
    ]


def days_overdue(row: TenantAdvance, *, now: datetime | None = None) -> int:
    """How long this window has been closed, in whole days."""
    if row.window_closes_at is None:
        return 0
    return max(0, ((now or _now()) - row.window_closes_at).days)


def overdue_for_snapshot(session: Session, *, jurisdiction: str) -> dict | None:
    """What a determination made under superseded content should say on its face.

    FP3-17, and the reason this exists rather than a report somebody runs: an
    auditor asking "how long did this firm operate on superseded rules" should
    not have to join a policy table against a publication date. Every
    determination made while a window is open past its close carries the answer.

    Returns None when nothing is overdue, so the field is absent rather than
    null on the overwhelming majority of determinations — which keeps it out of
    the snapshot of every ordinary decision.
    """
    for row in overdue(session):
        if row.jurisdiction != jurisdiction:
            continue
        return {
            "pack_id": row.jurisdiction,
            "superseding_version": row.pack_version,
            "days_overdue": days_overdue(row),
            "window_closed_at": (
                row.window_closes_at.isoformat() if row.window_closes_at else None
            ),
        }
    return None


def announce_overdue(
    session: Session, *, tenant_id: str, now: datetime | None = None
) -> int:
    """Tell this firm, once a day, for each pack whose window has closed.

    Once a day is the whole shape of it, and the uniqueness constraint is what
    enforces it rather than the caller remembering: a worker on a ten-minute
    cycle would otherwise send a hundred and forty-four notifications a day, and
    an alert arriving every ten minutes is one somebody filters into a folder.

    Both a webhook and a chained audit event, and they answer different
    questions. The webhook is how the firm's own systems learn; the audit event
    is the artefact proving they were told, which is the thing that has to
    survive somebody later saying they were not.
    """
    from . import business_time, service
    from .models import ReviewOverdueNotice

    moment = now or _now()
    today = business_time.business_today(session)
    sent = 0

    for row in overdue(session, tenant_id=tenant_id, now=moment):
        late = days_overdue(row, now=moment)
        # A savepoint, not a transaction.
        #
        # The first version caught `IntegrityError` and called
        # `session.rollback()`, which discards **the caller's** transaction —
        # here that meant the audit event written moments earlier in the same
        # session vanished, and the test asserting "one event per day" found
        # zero. A duplicate is an expected outcome of this loop, not a failure
        # of the work around it, so only the duplicate is undone.
        notice_row = ReviewOverdueNotice(
            tenant_id=tenant_id,
            jurisdiction=row.jurisdiction,
            pack_version=row.pack_version,
            on_day=today,
            days_overdue=late,
            sent_at=moment,
        )
        try:
            with session.begin_nested():
                session.add(notice_row)
                session.flush()
        except IntegrityError:
            # Already told today. `uq_one_overdue_notice_per_day` is the control
            # and this is what it looks like working.
            continue

        payload = {
            "jurisdiction": row.jurisdiction,
            "superseding_version": row.pack_version,
            "days_overdue": late,
            "window_closed_at": (
                row.window_closes_at.isoformat() if row.window_closes_at else None
            ),
        }
        service._tell_the_customers_systems(
            session,
            event="pack.review_overdue",
            subject=f"{row.jurisdiction} v{row.pack_version}",
            payload=payload,
        )
        service.audit(
            session,
            "pack.review_overdue",
            f"{row.jurisdiction} v{row.pack_version}: review window closed "
            f"{late} day(s) ago and this firm is still on the previous version",
        )
        sent += 1

    session.flush()
    return sent


def sweep(session: Session, *, tenant_id: str) -> list[TenantAdvance]:
    """Notice every effective pack version this tenant has not been told about.

    Run after `lifecycle.settle`, which is what makes a version effective in the
    first place. Catches up rather than tracking a cursor: a sweep that was
    missed for a week must not leave a firm un-noticed about a change that has
    already applied to everybody on auto.
    """
    versions = session.execute(
        select(Pack.jurisdiction, Pack.version).where(
            Pack.effective_from <= _now().date()
        )
    ).all()

    noticed = []
    for jurisdiction, version in versions:
        row = notice(
            session,
            tenant_id=tenant_id,
            jurisdiction=jurisdiction,
            pack_version=version,
        )
        noticed.append(row)
    session.flush()
    return noticed
