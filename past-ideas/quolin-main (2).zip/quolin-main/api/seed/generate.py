"""Deterministic generation of the Meridian retail book.

Fixed seed: the same 200 clients, positions and history every time, so a demo
looks identical in every meeting and the replay test is stable.
"""

from __future__ import annotations

import random
from datetime import date, timedelta

from faker import Faker

SEED = 20260819
MERIDIAN_CLIENT_COUNT = 200

LOSS_BAND_WEIGHTS = [(1, 12), (2, 28), (3, 34), (4, 18), (5, 8)]

# Most of the book sits well inside the concentration cap; a tail does not.
CRYPTO_PCT_OF_PORTFOLIO = [0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 8, 9, 13, 18, 24]


def _weighted(rng: random.Random, weights: list[tuple[int, int]]) -> int:
    population = [value for value, weight in weights for _ in range(weight)]
    return rng.choice(population)


def generate_meridian_clients(as_of: date) -> tuple[list[dict], dict]:
    rng = random.Random(SEED)
    faker = Faker("en_AU")
    Faker.seed(SEED)

    clients: list[dict] = []
    positions: dict[str, dict] = {}

    for index in range(1, MERIDIAN_CLIENT_COUNT + 1):
        client_id = f"mrd-{index:04d}"
        knowledge_assessed = rng.random() > 0.11
        knowledge_date = (
            as_of - timedelta(days=rng.randint(20, 1100)) if knowledge_assessed else None
        )
        portfolio_cents = rng.randrange(400_000, 40_000_000, 10_000)
        crypto_cents = portfolio_cents * rng.choice(CRYPTO_PCT_OF_PORTFOLIO) // 100
        prior_purchases = 0 if rng.random() < 0.18 else rng.randint(1, 24)

        clients.append(
            {
                "id": client_id,
                "name": faker.name(),
                "scenario": "meridian",
                "dob": (as_of - timedelta(days=rng.randint(18 * 365, 74 * 365))).isoformat(),
                "client_category": "retail",
                "knowledge_assessed": knowledge_assessed,
                "knowledge_date": knowledge_date.isoformat() if knowledge_date else None,
                "loss_capacity_band": _weighted(rng, LOSS_BAND_WEIGHTS),
                "vulnerability_flag": rng.random() < 0.045,
                "assessable_portfolio_cents": portfolio_cents,
                "prior_crypto_purchases": prior_purchases,
                "structural_acks": [],
                "default_trade_amount_cents": rng.randrange(50_000, 900_000, 5_000),
                "note": "",
            }
        )
        positions[client_id] = {
            "crypto_value_cents": crypto_cents,
            "holdings": [{"asset_id": "BTC", "value_cents": crypto_cents}]
            if crypto_cents
            else [],
        }

    return clients, positions


def backdated_decision_plan(as_of: date) -> list[dict]:
    """~40 historical decisions spread across both pack versions.

    The first entry is pinned: Harold's November 2025 assessment is the one the
    replay demo opens, and it must land inside the v1 window.
    """
    rng = random.Random(SEED + 1)

    plan: list[dict] = [
        # A larger-than-usual purchase, sized so post-trade concentration lands at
        # 12%: inside the v1 cap of 15%, outside the v2 cap of 10%. That gap is the
        # whole replay story — the decision stands, the rules moved on.
        {
            "client_id": "harold-bell",
            "asset_id": "SOL",
            "as_of": date(2025, 11, 14),
            "amount_cents": 5_400_000,
        },
        {"client_id": "margaret-wu", "asset_id": "BTC", "as_of": date(2025, 12, 3)},
        {"client_id": "tom-askew", "asset_id": "BTC", "as_of": date(2026, 1, 19)},
        {"client_id": "alex-reyes", "asset_id": "BTC", "as_of": date(2026, 3, 8)},
        {"client_id": "priya-nair", "asset_id": "BTC", "as_of": date(2026, 4, 22)},
        {"client_id": "margaret-wu", "asset_id": "ETH", "as_of": date(2026, 7, 2)},
        {"client_id": "harold-bell", "asset_id": "BTC", "as_of": date(2026, 7, 28)},
    ]

    assets = ["BTC", "BTC", "BTC", "ETH", "ETH", "SOL", "USDT", "ALGO-USD"]
    v1_window = (date(2025, 11, 2), date(2026, 5, 30))
    v2_window = (date(2026, 6, 2), as_of - timedelta(days=2))

    def spread(window: tuple[date, date], count: int) -> None:
        start, end = window
        span = (end - start).days
        for _ in range(count):
            plan.append(
                {
                    "client_id": f"mrd-{rng.randint(1, MERIDIAN_CLIENT_COUNT):04d}",
                    "asset_id": rng.choice(assets),
                    "as_of": start + timedelta(days=rng.randint(0, span)),
                }
            )

    spread(v1_window, 14)
    spread(v2_window, 14)

    # A handful dated today so the dashboard opens with live-looking counts.
    for _ in range(6):
        plan.append(
            {
                "client_id": f"mrd-{rng.randint(1, MERIDIAN_CLIENT_COUNT):04d}",
                "asset_id": rng.choice(assets),
                "as_of": as_of,
            }
        )

    return plan
