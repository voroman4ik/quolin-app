"""make seed — rebuild the entire demo state from zero. Idempotent by construction."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import sys
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy import select, text

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import crypto, evidence, packs_repo, service, tenancy  # noqa: E402
from app.canonical import content_hash  # noqa: E402
from app.db import OwnerSessionLocal, owner_engine  # noqa: E402
from app.engine import build_snapshot, evaluate_snapshot  # noqa: E402
from app.models import (  # noqa: E402
    MFA_REQUIRED_ROLES,  # noqa: E402
    Asset,
    AuditEvent,
    Client,
    Decision,
    Override,
    Pack,
)
from app.providers import fixtures as fixtures_module  # noqa: E402
from app.providers.fixtures import FixturePositionsProvider  # noqa: E402
from seed.generate import backdated_decision_plan, generate_meridian_clients  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
PACKS_DIR = ROOT / "packs"
FIXTURES_DIR = ROOT / "fixtures"

#: The demo firm. Created by migration 0002, not here — every tenant-scoped
#: column has a NOT NULL foreign key to it, so the row has to exist before the
#: schema is complete rather than after the seed gets around to it.
DEMO_TENANT = "demo"


def rebuild_schema() -> None:
    """Drop everything and rebuild it by running the migrations.

    Deliberately not `create_all` any more. A seed that builds the schema its
    own way is a second definition of the schema, and the two drift silently
    until a migration fails in staging against a shape no developer has ever
    had locally. Running the migrations here means the demo database, the CI
    database and staging are all produced by the same statements in the same
    order — and it means a broken migration fails at `make seed` rather than at
    a deploy.
    """
    with owner_engine.begin() as conn:
        # Triggers block DELETE, so the append-only tables are dropped, not emptied.
        conn.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public;"))
        conn.execute(text("DROP TABLE IF EXISTS alembic_version;"))

    api_dir = Path(__file__).resolve().parents[1]
    config = Config(str(api_dir / "alembic.ini"))
    config.set_main_option("script_location", str(api_dir / "migrations"))
    command.upgrade(config, "head")

    _grant_dev_login()


def _grant_dev_login() -> None:
    """Give the application and watch roles a password so they can connect.

    The migrations create both roles NOLOGIN and without a password on purpose —
    a password in a committed migration is a password in every clone of the
    repository. Setting one is environment-specific, and this is the seed, which
    only ever runs against dev, CI and staging. Production is never seeded, so
    this code path never runs there; its passwords come from Secrets Manager.

    Two roles, because Stage 6 runs the watch service as its own process with
    its own credential: `quolin_watch` can read packs and cannot write them. In
    a real deployment they are separate tasks with separate secrets; here they
    are two connection strings, which is the same separation at a smaller scale.
    """
    for role, variable, fallback in (
        ("quolin_app", "QUOLIN_APP_DB_PASSWORD", "quolin_app"),
        ("quolin_watch", "QUOLIN_WATCH_DB_PASSWORD", "quolin_watch"),
    ):
        password = os.getenv(variable, fallback)
        with owner_engine.begin() as conn:
            # ALTER ROLE is a utility statement and cannot take a bind parameter,
            # so the password has to be interpolated. `format(..., %L)` makes
            # Postgres do the quoting rather than an f-string, which would let a
            # password containing a quote character end the statement and start
            # another one.
            statement = conn.execute(
                text(
                    "SELECT format('ALTER ROLE %I LOGIN PASSWORD %L', "
                    "cast(:role AS text), cast(:pw AS text))"
                ),
                {"role": role, "pw": password},
            ).scalar_one()
            conn.execute(text(statement))


#: The demo firm's staff, and the whole point of Stage 2: five people with five
#: different sets of permissions, rather than one passcode five people share.
#:
#: The split is not decorative. `write_overrides` seeds an override that one
#: person requested and another approved, and separation of duties is only a
#: real rule if the demo database actually contains two people who could have
#: swapped places and did not.
#:
#: Every address is `@quolin.example` — a reserved TLD that cannot resolve, so
#: no seeded account can ever correspond to a mailbox anyone controls.
DEMO_PEOPLE = [
    {
        "email": "dana.whitfield@quolin.example",
        "name": "Dana Whitfield",
        "roles": [{"role": "operator"}],
    },
    {
        "email": "marcus.oyelaran@quolin.example",
        "name": "Marcus Oyelaran",
        "roles": [{"role": "approver"}],
    },
    {
        "email": "aoife.brennan@quolin.example",
        "name": "Aoife Brennan",
        # Two rows, not one. A signatory role carries the regime it is competent
        # for: someone qualified to sign an Australian design and distribution
        # determination is not thereby qualified to sign a Hong Kong one, and a
        # single unscoped signatory role would say they were.
        "roles": [
            {
                "role": "pack_signatory",
                "jurisdiction": "AU",
                "qualification_ref": "[illustrative — no engagement in place]",
            },
            {
                "role": "pack_signatory",
                "jurisdiction": "HK",
                "qualification_ref": "[illustrative — no engagement in place]",
            },
        ],
    },
    {
        "email": "ruth.castellanos@quolin.example",
        "name": "Ruth Castellanos",
        "roles": [{"role": "tenant_admin"}],
    },
    {
        "email": "peter.lindqvist@quolin.example",
        "name": "Peter Lindqvist",
        "roles": [{"role": "viewer"}],
    },
    {
        # Not the firm's staff. Quolin's own, and the reason they appear in a
        # customer's grant list at all is that grants are tenant-scoped: to act
        # for this firm they must hold a role in it, exactly as `quolin_support`
        # would. The access review reports them like anybody else, which is the
        # point — a platform operator who never appears in a customer's review
        # is a back door.
        #
        # Q-12: publication writes to the global `packs` table, so it is our act
        # rather than a customer administrator's. Everything before it stays
        # with the firm.
        "email": "sofia.marchetti@quolin.example",
        "name": "Sofia Marchetti",
        "roles": [{"role": "quolin_operator"}],
    },
]

#: The people who may put rule content in front of every customer. FP3-27.
#:
#: Named individuals, and that is the whole point of the list. Publication is
#: not a role a tenant can grant, not the engineering role, and not a service
#: account — it is two specific humans, and publishing takes both of them.
#:
#: Sofia Marchetti above holds `quolin_operator`, which is what lets her reach
#: the endpoint. Holding the *capability* is this table, which has no
#: `tenant_id` and cannot be written by any tenant-scoped grant.
#:
#: Recorded here and in `docs/deployment.md`. Changing who is on it is a
#: deliberate act by somebody holding the owner credential, at the same bar as
#: running a migration — there is no API route that grants it, deliberately.
PLATFORM_PUBLISHERS = [
    {
        "email": "volodymyr.romanenko@quolin.example",
        "name": "Volodymyr Romanenko",
        "note": "Founder. Named platform publisher, FP3-27.",
    },
    {
        "email": "su-lee.oei@quolin.example",
        "name": "Su-Lee Oei",
        "note": "Named platform publisher, FP3-27.",
    },
]

#: The password every seeded account gets.
#:
#: Not a secret and must never become one. It is committed, it is printed by
#: `make seed`, and it only ever exists on a database built by this script —
#: which is dev, CI and staging, never production. The same rule as
#: DEV_MASTER_KEY in the Makefile, for the same reason: a value that is
#: obviously fake cannot quietly become the real one.
SEED_PASSWORD = os.getenv("QUOLIN_SEED_PASSWORD", "demo password not a real one")


#: The seeded accounts the rest of the seed acts as. Named here rather than read
#: out of DEMO_PEOPLE by position, so that reordering that list cannot silently
#: make the operator the approver.
OPERATOR_EMAIL = "dana.whitfield@quolin.example"
APPROVER_EMAIL = "marcus.oyelaran@quolin.example"
SIGNATORY_EMAIL = "aoife.brennan@quolin.example"
ADMIN_EMAIL = "ruth.castellanos@quolin.example"


def _person(session, email: str):
    """The seeded account for `email`, or a failure that says what is missing.

    Raises rather than returning None because every caller is downstream of
    `seed_people` in `_seed_everything`, and a caller that ran before it would
    otherwise fall through to writing an unattributed row — the exact defect
    this seed was changed to remove.
    """
    from app import identity

    user = identity.find_by_email(session, email)
    if user is None:
        raise RuntimeError(f"seed_people must run before this: no account for {email}")
    return user




def _second_factor_codes(session) -> list[tuple[str, str, str]]:
    """Every seeded account with an authenticator, and a code that works now."""
    from app import totp
    from app.models import MfaCredential, User

    out = []
    users = {u.id: u for u in session.scalars(select(User))}
    for credential in session.scalars(select(MfaCredential)):
        user = users.get(credential.user_id)
        if user is None or credential.confirmed_at is None:
            continue
        secret = str(credential.secret)
        out.append((user.email, secret, totp.code_at(secret)))
    return sorted(out)


def _ensure_second_factor(session, user) -> str:
    """Give a privileged demo account a confirmed authenticator, idempotently.

    Returns the secret, so the seed can print a code somebody can actually type.
    """
    from app.identity import new_id
    from app.models import MfaCredential

    existing = session.scalars(
        select(MfaCredential).where(MfaCredential.user_id == user.id)
    ).first()
    if existing is not None:
        return str(existing.secret)

    # Derived from the address so it is stable across reseeds, and base32 so it
    # is a real TOTP secret. Not a secret in any meaningful sense: it belongs to
    # a demonstration account in a database `make seed` rebuilds.
    digest = hashlib.sha256(f"quolin-demo-totp:{user.email}".encode()).digest()
    secret = base64.b32encode(digest[:20]).decode().rstrip("=")

    credential = MfaCredential(
        id=new_id("mfa"),
        user_id=user.id,
        kind="totp",
        label="authenticator",
        secret=secret,
        # Confirmed, because a demonstration firm is a configured firm. An
        # unconfirmed row would leave every privileged account locked, which is
        # the enforcement working and the wrong scene for a demo.
        confirmed_at=datetime.now(timezone.utc),
        last_used_counter=0,
        created_at=datetime.now(timezone.utc),
    )
    session.add(credential)
    session.flush()
    return secret


def seed_people(session) -> list[str]:
    """Create the demo firm's staff and grant them their roles.

    Runs as the schema owner like the rest of the seed, which means row-level
    security is not in force for these writes — so `identity.create_user` sets
    `app.user_id` on a connection where nothing reads it. That is fine and
    deliberate: the seed uses the same functions the application does, so a
    change that breaks provisioning breaks `make seed` rather than being
    discovered the first time a real administrator invites somebody.
    """
    from app import identity

    created = []
    for person in DEMO_PEOPLE:
        user = identity.find_by_email(session, person["email"])
        if user is None:
            user = identity.create_user(
                session, email=person["email"], display_name=person["name"]
            )
        identity.set_password(session, user, SEED_PASSWORD)

        # A second factor for anybody the policy requires one from.
        #
        # §S13's external review found `MFA_REQUIRED_ROLES` enforced nowhere.
        # It is enforced now — a privileged account with no factor can enrol one
        # and nothing else — which means the demonstration firm has to be a
        # correctly configured firm rather than an exception to the control it
        # is demonstrating. The seed enrols and confirms the factor here, and
        # prints the current code below so a demo can sign in without an
        # authenticator app to hand.
        #
        # The secret is fixed per person rather than random, so the code printed
        # by one `make seed` still works after the next one.
        if set(r["role"] for r in person["roles"]) & set(MFA_REQUIRED_ROLES):
            _ensure_second_factor(session, user)

        for grant in person["roles"]:
            identity.grant_role(
                session,
                user_id=user.id,
                role=grant["role"],
                jurisdiction=grant.get("jurisdiction", ""),
                qualification_ref=grant.get("qualification_ref", ""),
                granted_by="seed",
            )
        created.append(f"{person['name']} <{person['email']}>")

    # FP3-27. The two named humans who may publish rule content, and the reason
    # they are here rather than in DEMO_PEOPLE: publication is not a role, it is
    # a platform grant, and `platform_publishers` has no `tenant_id` precisely
    # so that no tenant-scoped write can produce one.
    #
    # They also hold `quolin_operator`, because that is what lets them reach the
    # endpoint at all — the route's RBAC and the platform grant are two
    # different checks and FP3-27 is what happens when the first stands in for
    # the second.
    from app.models import PlatformPublisher

    for publisher in PLATFORM_PUBLISHERS:
        user = identity.find_by_email(session, publisher["email"])
        if user is None:
            user = identity.create_user(
                session, email=publisher["email"], display_name=publisher["name"]
            )
        identity.set_password(session, user, SEED_PASSWORD)
        _ensure_second_factor(session, user)
        if not any(
            g.role == "quolin_operator"
            for g in identity.roles_for(session, user.id)
        ):
            identity.grant_role(
                session,
                user_id=user.id,
                role="quolin_operator",
                granted_by="seed",
            )
        if session.get(PlatformPublisher, user.id) is None:
            session.add(
                PlatformPublisher(
                    user_id=user.id,
                    note=publisher["note"],
                    granted_by="seed",
                )
            )
        created.append(f"{publisher['name']} <{publisher['email']}> (platform publisher)")

    session.flush()
    return created


#: The machine the scheduled watch sweep acts as.
#:
#: A sweep is not a person — nobody typed a password and nobody can be asked
#: what they meant — so it is a machine principal, in the table Stage 4 built for
#: exactly that. The alternative is what this repository already threw away
#: once: an audit actor that is a string nobody provisioned. The shared
#: placeholder officer was deleted in Stage 2 for naming nobody, and a bare
#: "schedule" would have been the same mistake in new clothes.
#:
#: A fixed id rather than a random one, because a script has to be able to name
#: it. That is a departure from how customer credentials are issued — those are
#: random precisely so a credential does not disclose which customers exist —
#: and it is safe here for the reason below: this row cannot authenticate.
WATCH_SWEEP_CLIENT = "apc_watch_sweep"

#: The machine a scheduled artefact render is attributed to, when no person
#: asked. Month-end returns are produced by a schedule, and a document with no
#: generator identity is one §S7 says should not exist.
ARTEFACT_WORKER_CLIENT = "apc_artefact_worker"

#: The machine a scheduled book re-check is attributed to. §S8 re-checks a whole
#: book when a pack becomes effective or on a schedule, and every determination
#: it writes carries an audit row — which has to name something a reviewer can
#: ask about, not a bare string.
BULK_SWEEP_CLIENT = "apc_bulk_sweep"

#: The machine an evidence re-chain is attributed to.
#:
#: `scripts/rechain.py` writes an audit row recording that it rewrote hashes —
#: which it should, because an auditor comparing an old export against a new one
#: needs an answer to why every hash changed. It attributed that row to the bare
#: string `scripts.rechain`, and `test_attribution.py` never caught it because
#: nothing in the suite had ever run the script's write path. §S13's audit-chain
#: backfill did, and the guard fired immediately.
RECHAIN_CLIENT = "apc_rechain"


def seed_machines(session) -> list[str]:
    """Provision the machine principals this deployment's own jobs act as.

    **The secret is hashed from a value that is thrown away.** The sweep runs
    in-process against the database; it never calls the v1 API and has no use
    for a token. So the row exists to be *nameable and reviewable* — the audit
    trail points at it, and the quarterly access review asks about it like any
    other credential — while holding no secret anybody could present. A real
    secret sitting in a scheduler's configuration for a job that would never
    send it is a credential leak waiting for a reason.

    No roles, for the same reason. The sweep writes watch rows through the
    database, not through an endpoint, so a role would be an authorisation
    nothing checks.
    """
    import secrets

    from app.models import ApiClient
    from app.passwords import hash_password

    machines = [
        (WATCH_SWEEP_CLIENT, "Regulatory watch sweep (scheduled, no API access)"),
        (
            ARTEFACT_WORKER_CLIENT,
            "Artefact worker (scheduled renders, no API access)",
        ),
        (
            BULK_SWEEP_CLIENT,
            "Bulk re-evaluation sweep (scheduled, no API access)",
        ),
        (
            RECHAIN_CLIENT,
            "Evidence re-chain (run by hand, no API access)",
        ),
    ]
    created = []
    for client_id, label in machines:
        if session.get(ApiClient, client_id) is None:
            session.add(
                ApiClient(
                    id=client_id,
                    tenant_id=DEMO_TENANT,
                    label=label,
                    secret_hash=hash_password(secrets.token_urlsafe(32)),
                    roles=[],
                    status="active",
                )
            )
        created.append(f"{client_id} — {label}")
    session.flush()
    return created


def place_demo_on_the_ladder(session) -> str:
    """The demo firm is a live customer, so it sits at the top of the ladder.

    §S10 defaults a new tenant to `pilot`, which is the right default — a
    customer record created by hand should not be able to affect anybody. But
    the demo firm is the story of a firm *in production*: its determinations
    notify, its referrals queue, its documents are filed. Left at `pilot` the
    whole demo goes quiet, which is the ladder working and the wrong scene.

    The transition is recorded like any other, signed by the seed, because a
    stage that appeared without a signature would be the one hole in a table
    whose entire purpose is to say who decided.
    """
    from app import adoption
    from app.models import Tenant, TenantStageChange

    tenant = session.get(Tenant, DEMO_TENANT)
    if tenant is None or tenant.stage == adoption.FULL:
        return adoption.FULL if tenant else ""

    # The contract date, so §S10's onboarding metric has a clock to start from.
    # Eleven days before the firm reached shadow, which is what the target of
    # two weeks looks like when it is met.
    tenant.config = {
        **(tenant.config or {}),
        "contracted_at": (datetime.now(timezone.utc) - timedelta(days=11)).isoformat(),
    }

    for rung in (adoption.SHADOW, adoption.LIMITED, adoption.FULL):
        session.add(
            TenantStageChange(
                tenant_id=DEMO_TENANT,
                from_stage=tenant.stage,
                to_stage=rung,
                signed_by="seed",
                note="the demo firm is a live customer",
            )
        )
        tenant.stage = rung
    session.flush()
    return tenant.stage


def declare_demo_regimes(session) -> list[str]:
    """Which regimes the demo firm is licensed in.

    A fact about the customer rather than about their book: a firm licensed in
    Singapore with no Singaporean clients yet still needs to know when the MAS
    changes something. So it is declared in tenant config, not derived from the
    clients table.

    Three of the four, deliberately. The demo firm advises in AU, HK and SG and
    not in the EU — which is what makes the tenancy on the currency screen
    visible rather than theoretical: an ESMA feed going stale does not turn this
    customer's rollup amber, because it is not their regulator.
    """
    from app.models import Tenant

    tenant = session.get(Tenant, DEMO_TENANT)
    if tenant is None:
        return []
    config = dict(tenant.config or {})
    config["jurisdictions"] = ["AU", "HK", "SG"]
    # The demonstration firm is the one tenant permitted to decide on content
    # nobody qualified has signed.
    #
    # It has to sit at `full` — at `pilot` or `shadow` its webhooks and
    # referrals go quiet and the demo stops being a demo — and the shipped packs
    # are `PENDING_REVIEW` and `ILLUSTRATIVE` until specialists are engaged. So
    # it is exactly the situation `packs_repo` now refuses for everybody else,
    # and the exception is declared here, on the tenant's own row, where the
    # access review can see it and an auditor can ask about it. The alternative
    # was a comparison against the literal string "demo" inside production code,
    # which is the shape `guard_no_tier_divergence.sh` forbids elsewhere.
    #
    # A column rather than a key in `config` since migration 0032: the
    # application role may rewrite `config`, and the single override on the
    # refusal that cannot be waived should not be reachable from a request.
    tenant.illustrative_content_permitted = True
    tenant.config = config
    session.flush()
    return list(config["jurisdictions"])


def load_packs(session) -> None:
    """Load every pack file, refusing any that would not evaluate.

    Validated here rather than when a pack is read, because a pack is checked
    once on the way in and read on every determination — and because a pack
    already in force that suddenly failed validation would take every request
    down with it rather than telling somebody. `make seed` is the first place a
    specialist's typo can be caught, and the message names the rule.
    """
    from app.engine import Pack as EnginePack
    from app.engine import check

    for path in sorted(PACKS_DIR.glob("*.json")):
        body = json.loads(path.read_text())
        check(EnginePack.from_body(body))
        session.add(
            Pack(
                jurisdiction=body["pack_id"],
                version=body["version"],
                effective_from=date.fromisoformat(body["effective_from"]),
                effective_to=(
                    date.fromisoformat(body["effective_to"]) if body["effective_to"] else None
                ),
                body=body,
                signed_by=body.get("signed_by", ""),
                signed_at=body.get("signed_at", ""),
                # The same hash `watch.drafts.publish` records, so a seeded pack
                # and a published one are identified the same way. See Q-04.
                content_hash=content_hash(body),
            )
        )
    session.flush()


def load_assets(session) -> None:
    for row in json.loads((FIXTURES_DIR / "assets.json").read_text()):
        session.add(Asset(**row))
    session.flush()


def load_clients(session, today: date) -> int:
    cast = json.loads((FIXTURES_DIR / "clients_cast.json").read_text())
    generated, generated_positions = generate_meridian_clients(today)

    cast_ids = {row["id"] for row in cast}

    for row in cast + generated:
        session.add(
            Client(
                id=row["id"],
                name=row["name"],
                scenario=row["scenario"],
                dob=date.fromisoformat(row["dob"]),
                client_category=row["client_category"],
                knowledge_assessed=row["knowledge_assessed"],
                knowledge_date=(
                    date.fromisoformat(row["knowledge_date"]) if row["knowledge_date"] else None
                ),
                loss_capacity_band=row["loss_capacity_band"],
                vulnerability_flag=row["vulnerability_flag"],
                assessable_portfolio_cents=row["assessable_portfolio_cents"],
                prior_crypto_purchases=row["prior_crypto_purchases"],
                structural_acks=row["structural_acks"],
                default_trade_amount_cents=row["default_trade_amount_cents"],
                # Three separate facts, and only the first is about the firm.
                # A fixture that says nothing is a single-jurisdiction client,
                # which is what every row written before this phase was.
                jurisdiction=row.get("jurisdiction", "AU"),
                residency=row.get("residency") or row.get("jurisdiction", "AU"),
                domicile=row.get("domicile") or row.get("jurisdiction", "AU"),
                note=row["note"],
                is_cast=row["id"] in cast_ids,
            )
        )
    session.flush()

    positions = json.loads((FIXTURES_DIR / "positions_cast.json").read_text())
    positions.update(generated_positions)
    (FIXTURES_DIR / "positions.json").write_text(json.dumps(positions, indent=2) + "\n")
    fixtures_module._positions_fixture.cache_clear()

    return len(cast) + len(generated)


def write_history(session, today: date) -> int:
    """Backdated decisions, recorded under whichever pack was effective at the time.

    Recorded as the seeded operator for the same reason the cross-border book is:
    `decided_by` is what the override rule compares, and a demo history where it
    is null is a history in which nobody could have been refused an override of
    their own work.
    """
    provider = FixturePositionsProvider()
    operator = _person(session, OPERATOR_EMAIL)
    written = 0

    for step in backdated_decision_plan(today):
        client = session.get(Client, step["client_id"])
        asset = session.get(Asset, step["asset_id"])
        as_of = step["as_of"]
        pack = packs_repo.active(session, client.jurisdiction, as_of)

        snapshot = build_snapshot(
            pack=pack,
            licensee_jurisdiction=client.jurisdiction,
            client={
                "id": client.id,
                "name": client.name,
                "scenario": client.scenario,
                "residency": client.residency,
                "domicile": client.domicile,
                "dob": client.dob,
                "client_category": client.client_category,
                "knowledge_assessed": client.knowledge_assessed,
                "knowledge_date": client.knowledge_date,
                "loss_capacity_band": client.loss_capacity_band,
                "vulnerability_flag": client.vulnerability_flag,
                "assessable_portfolio_cents": client.assessable_portfolio_cents,
                "prior_crypto_purchases": client.prior_crypto_purchases,
                "structural_acks": client.structural_acks,
            },
            positions=provider.get(client.id, as_of),
            asset={"id": asset.id, "symbol": asset.symbol, "name": asset.name},
            amount_cents=step.get("amount_cents", client.default_trade_amount_cents),
            as_of=as_of,
        )
        with tenancy.acting_as_user(operator.id):
            evidence.record(
                session,
                client_id=client.id,
                asset_id=asset.id,
                as_of=as_of,
                pack_id=pack.pack_id,
                pack_version=pack.version,
                snapshot=snapshot,
                evaluation=evaluate_snapshot(pack, snapshot),
                created_at=datetime.combine(as_of, time(10, 30), tzinfo=timezone.utc),
            )
        written += 1

    return written


#: Cross-border cast, and the trade that makes each one worth opening.
#: Written through `service.evaluate` rather than `evidence.record`, because the
#: resolution is the point: seeding these by hand would let the demo state and
#: the code path that produces it drift apart, and the seed would stop being
#: evidence that the resolver works.
CROSS_BORDER_PLAN = [
    ("wei-lin-chow", "SOL", 4),
    ("ingrid-halvorsen", "ALGO-USD", 3),
    ("marcus-tan", "BTC", 2),
    ("chen-yu-hsuan", "ETH", 1),
]


def write_crossborder(session, today: date) -> int:
    # Run as the seeded operator, because these go through `service.evaluate`
    # and that writes an audit row: a determination seeded with nobody in scope
    # would be refused, which is the rule working rather than an obstacle. The
    # operator is the person who would have run these, and the approver stays
    # free to override them.
    operator = _person(session, OPERATOR_EMAIL)

    written = 0
    with tenancy.acting_as_user(operator.id):
        for client_id, asset_id, days_ago in CROSS_BORDER_PLAN:
            service.evaluate(
                session,
                client_id=client_id,
                asset_id=asset_id,
                as_of=today - timedelta(days=days_ago),
            )
            written += 1
    session.flush()
    return written


#: Justifications only. The approver used to be a string beside each one —
#: two invented compliance officers who existed nowhere but this list. A seeded
#: history that names people the firm does not employ is the same defect as the
#: placeholder actor, so the approver is now the seeded approver account and
#: these rows carry the name that account actually has.
RESOLVED_OVERRIDES = [
    "Client holds a self-managed super fund with independent advice on record. "
    "Loss capacity band re-tested at band 3 in a supplementary questionnaire; "
    "proceeding on the refreshed assessment.",
    "Vulnerability flag relates to a 2024 bereavement marker that has since lapsed. "
    "Confirmed with the client's adviser by phone; flag scheduled for review.",
]

def write_overrides(session, today: date) -> int:
    """A little override history, so the dashboard and the override report open with content."""
    approver = _person(session, APPROVER_EMAIL)

    refers = session.scalars(
        select(Decision)
        .where(Decision.outcome == "REFER")
        .where(Decision.as_of < today)
        .order_by(Decision.id)
    ).all()

    # Deliberately unequal: there are more REFERs in the book than there are
    # written overrides, and only the first few are meant to arrive resolved.
    for decision, justification in zip(refers, RESOLVED_OVERRIDES, strict=False):
        session.add(
            Override(
                decision_id=decision.id,
                justification=justification,
                approver=approver.display_name,
                approved_by=approver.id,
                created_at=datetime.combine(decision.as_of, time(14, 5), tzinfo=timezone.utc),
            )
        )
        # Chained, not merely added. Written directly rather than through
        # `service.audit` because the timestamp is historical — an override
        # recorded as having happened on the determination's own date — and
        # `audit()` stamps the clock. What it must not skip is `link_audit`:
        # two rows here went in unchained, and `verify_audit_chain` reported the
        # trail as verified because it skipped anything without a hash. Q-13.
        override_event = AuditEvent(
            actor=approver.id,
            action="decision.override",
            subject=f"decision:{decision.id}",
            at=datetime.combine(decision.as_of, time(14, 5), tzinfo=timezone.utc),
        )
        evidence.link_audit(session, override_event)
        session.add(override_event)
    session.flush()
    return min(len(refers), len(RESOLVED_OVERRIDES))


#: How long ago each source was last checked, in days. Hand-set so the currency
#: screen has something to say: a deployment where every source is CURRENT
#: demonstrates nothing, because the badge that matters is the one that goes
#: amber. AU and HK land on DUE, EU on STALE, SG on CURRENT.
LAST_CHECKED_DAYS_AGO = {
    "au-asic-media": 2,
    "au-asic-rg": 35,
    "au-legislation": 10,
    "hk-sfc-circulars": 3,
    "hk-sfc-news": 20,
    "sg-mas-media": 1,
    "sg-mas-notices": 12,
    "eu-esma-news": 30,
    "eu-oj": 5,
}


def record_manual_verifications(session, today: date) -> int:
    """Give the manually verified sources a last-verified date.

    §S13 added `polling_status: MANUAL` for publications a machine cannot read —
    a search portal whose front page moves without anything being published, in
    this pack's case. A manual source carries the date somebody last looked, and
    without one it reads STALE, which is correct and makes the demo show a state
    the product does not otherwise explain.

    **There is no way to record a verification through the product yet.** A
    person confirming they checked a source is a screen and an endpoint nobody
    has built, so this is the seed asserting what a firm would have done. It is
    recorded in `docs/post-raise.md` rather than left looking finished.
    """
    from app.models import WatchSource
    from app.watch import fetchers, sources

    marked = 0
    for row in session.scalars(
        select(WatchSource).where(WatchSource.polling_status == fetchers.MANUAL)
    ):
        row.last_checked_at = datetime.now(timezone.utc) - timedelta(days=2)
        row.last_mode = sources.VERIFIED
        marked += 1
    session.flush()
    return marked


def write_watch(session, today: date) -> dict:
    """Poll the fixture, age the check timestamps, and stage the demo drafts.

    Two drafts are left in deliberately different states. The AU one is
    *unsigned*, because the moment worth showing is the refusal: the screen has
    a proposed threshold, a rationale and the events behind it, and it still
    cannot become rule content until somebody puts their name on it. The HK one
    is signed and published with a future effective date, so the same screen
    also shows what the far side of that gate looks like — a countdown to
    content that is real, dated, and changing nothing today.
    """
    from app.models import WatchEvent, WatchSource  # noqa: PLC0415
    from app.watch import drafts as watch_drafts  # noqa: PLC0415
    from app.watch import poll as watch_poll  # noqa: PLC0415

    result = watch_poll.poll(session, today)

    now = datetime.now(timezone.utc)
    for source_id, days in LAST_CHECKED_DAYS_AGO.items():
        row = session.get(WatchSource, source_id)
        if row is not None:
            row.last_checked_at = now - timedelta(days=days)
    session.flush()

    def event_by(fragment: str) -> WatchEvent | None:
        return session.scalars(
            select(WatchEvent).where(WatchEvent.title.contains(fragment))
        ).first()

    # A queue where nothing has been touched looks abandoned; one where
    # everything has been looks staged. Two items moved, the rest left new.
    reviewing = event_by("client knowledge assessment record-keeping")
    if reviewing is not None:
        reviewing.status = "reviewing"
        reviewing.note = "Checking whether our 24-month validity still matches."
    dismissed = event_by("small business engagement")
    if dismissed is not None:
        dismissed.status = "dismissed"
        dismissed.note = "Not about advice licensees."
    session.flush()

    au_event = event_by("tightening crypto-asset concentration limits")
    au_draft = watch_drafts.create(
        session,
        jurisdiction="AU",
        on=today,
        effective_from=today + timedelta(days=30),
        title="Tighten retail crypto-asset concentration limit to 8%",
        rationale=(
            "ASIC's consultation proposes reducing the maximum crypto-asset exposure "
            "a retail portfolio may hold. This draft lowers the pack's concentration "
            "threshold to match the proposed figure. It has not been reviewed by a "
            "qualified adviser and is unsigned: nothing in it affects any "
            "determination until a named signatory accepts it."
        ),
        threshold_changes={"max_crypto_concentration_bps": 800},
        event_ids=[au_event.id] if au_event else [],
        # The watch service, because that is what cut it: both drafts here are
        # raised from watch events, and migration 0049 requires every draft to
        # name an author. Recording a person would be a fabrication, and it is
        # exactly the case where the human signature has to be independent —
        # which the HK draft below then demonstrates.
        author=watch_drafts.WATCH_SERVICE_NAME,
        author_user_id=watch_drafts.WATCH_SERVICE,
    )
    if au_event is not None:
        au_event.status = "actioned"

    hk_event = event_by("virtual asset concentration in client portfolios")
    hk_draft = watch_drafts.create(
        session,
        jurisdiction="HK",
        on=today,
        effective_from=today + timedelta(days=21),
        title="Align virtual-asset concentration ceiling with SFC circular",
        rationale=(
            "The circular states a revised expectation for the proportion of a retail "
            "client's portfolio held in virtual assets. Signed and published so the "
            "currency screen can show the far side of the signature gate: content "
            "that is real, dated, and not yet in force."
        ),
        threshold_changes={"max_crypto_concentration_bps": 1200},
        event_ids=[hk_event.id] if hk_event else [],
        author=watch_drafts.WATCH_SERVICE_NAME,
        author_user_id=watch_drafts.WATCH_SERVICE,
    )
    # Two people, because publication refuses to be one. The signature used to
    # be the string "[HK counsel — illustrative signature]" and the publication
    # had nobody behind it at all, which meant the seeded pack on the shelf was
    # the one artefact in the demo that had passed no gate. It is signed by the
    # seeded signatory — who holds an HK grant — and put in force by the tenant
    # administrator, and `publish` would reject any other arrangement.
    signatory = _person(session, SIGNATORY_EMAIL)
    # FP3-27. The seed used to publish as the tenant administrator — an account
    # that could not have published through the API at all, since the route
    # requires `quolin_operator`, and the seed calls `watch_drafts.publish`
    # directly. Worth naming rather than quietly fixing: the demo data was built
    # by a path no real publication takes.
    #
    # It publishes as a named platform publisher now, with the second one
    # recording an approval first — so the seeded HK v2 is a pack two people
    # agreed to put live, neither of them the signatory, which is what the demo
    # is supposed to be showing.
    publisher = _person(session, PLATFORM_PUBLISHERS[0]["email"])
    second = _person(session, PLATFORM_PUBLISHERS[1]["email"])

    # Each of the three passes the hash of the body it is acting on. The seed is
    # one process holding the row, so it says nothing it did not already know —
    # but the argument is required precisely so that it cannot be skipped at the
    # route, where the value comes from a `view()` a person actually read.
    with tenancy.acting_as_user(signatory.id):
        watch_drafts.sign(
            session,
            hk_draft.id,
            signatory=signatory.display_name,
            signed_content_hash=watch_drafts.content_hash(hk_draft.body),
            note=(
                "Illustrative. This account stands in for a qualified signatory: the "
                "grant behind it records no engagement, and no qualified person has "
                "reviewed this content."
            ),
        )
        service.audit(
            session,
            "watch.draft.sign",
            f"draft {hk_draft.id}: HK v{hk_draft.proposed_version}",
        )

    with tenancy.acting_as_user(second.id):
        watch_drafts.approve_publication(
            session,
            hk_draft.id,
            approved_content_hash=watch_drafts.content_hash(hk_draft.body),
            note="Reviewed the signed content before release.",
        )
        service.audit(
            session,
            "watch.publication.approved",
            f"draft {hk_draft.id} approved by {second.id}",
        )

    with tenancy.acting_as_user(publisher.id):
        published = watch_drafts.publish(
            session,
            hk_draft.id,
            published_content_hash=watch_drafts.content_hash(hk_draft.body),
        )
        service.audit(
            session,
            "watch.draft.publish",
            f"HK v{published.version} effective {published.effective_from.isoformat()}",
        )
    if hk_event is not None:
        hk_event.status = "actioned"

    with tenancy.acting_as_user(_person(session, OPERATOR_EMAIL).id):
        service.audit(session, "watch.poll", f"{result['new_events']} events recorded")
        service.audit(session, "watch.draft.create", f"AU draft {au_draft.id}, unsigned")
    session.flush()
    return {
        "events": result["new_events"],
        "by_tier": result["by_tier"],
        "unsigned_draft": au_draft.id,
        "pending_pack": (
            f"HK v{published.version} in {(published.effective_from - today).days} days"
        ),
    }


#: The mark that says a database is the suite's to write to.
#:
#: Q-16 could not be reproduced, and the README has always warned that the
#: suite writes to the demo database. A warning in a README is not a control:
#: nothing stopped `make test` being pointed at a database holding a customer's
#: records, and the suite creates tenants, mints determinations, disables
#: append-only triggers and deletes every row of `auth_attempts`.
#:
#: Written as a comment on the database rather than as a table, so it needs no
#: migration and therefore cannot arrive on a deployment by being applied there.
#: `make seed` drops the schema and rebuilds it, so any database this has run
#: against is disposable by definition — which is exactly the claim the mark
#: makes.
DISPOSABLE_MARK = "quolin-disposable"


def mark_disposable(session) -> None:
    """Say, on the database itself, that everything here may be destroyed."""
    name = session.execute(text("SELECT current_database()")).scalar()
    stamp = datetime.now(timezone.utc).isoformat()
    session.execute(
        text(
            f'COMMENT ON DATABASE "{name}" IS '
            f"'{DISPOSABLE_MARK}: rebuilt from zero by seed.seed at {stamp}'"
        )
    )
    session.commit()


def main() -> None:
    today = date.today()
    print(f"seeding demo state as at {today.isoformat()}")

    rebuild_schema()
    # As the owner, not as the application role. The seed writes global content
    # and sets up tenants, which is administration rather than a request — and
    # once row-level security is on, the application role is filtered to one
    # tenant by design, which is exactly what a seed must not be.
    session = OwnerSessionLocal()
    # Everything the seed writes belongs to the demo firm. Declared once, here,
    # rather than passed to each loader: `tenant_id` defaults to whatever tenant
    # is in scope, so a loader added later is stamped correctly without its
    # author having had to know that tenants exist.
    try:
        # Marked before anything is written, so a run interrupted half-way still
        # leaves a database the suite recognises as its own.
        mark_disposable(session)
        with tenancy.acting_as(DEMO_TENANT):
            _seed_everything(session, today)
    finally:
        session.close()


def _ensure_platform_key(session) -> None:
    """Give the reserved `_platform` tenant its data key.

    In its own session, and that is not tidiness. `tenant_keys` is under forced
    row-level security with a WITH CHECK on `tenant_id`, and the setting the
    policy reads is bound when a transaction opens — so an insert naming
    `_platform` from inside the demo tenant's transaction is refused by
    Postgres, correctly. A separate scope is the only way to write it, which is
    the mechanism working rather than an obstacle to route around.

    Idempotent, because `ensure_key` is: a re-seed finds the row and returns it.
    """
    from app.crypto import PLATFORM_TENANT

    with tenancy.acting_as(PLATFORM_TENANT):
        platform = OwnerSessionLocal()
        try:
            crypto.ensure_key(platform, PLATFORM_TENANT)
            platform.commit()
        finally:
            platform.close()


def _seed_everything(session, today: date) -> None:
    # Before anything writes a decision. Migration 0004 already anchored every
    # tenant that existed when it ran, so this is normally a no-op — but the
    # seed names its own tenant and should not depend on a migration having
    # guessed the same name. Provisioning a customer includes starting their
    # chain, and this is the only place the seed provisions one.
    evidence.ensure_anchor(session, DEMO_TENANT)
    # And before anything writes a client. The very next statement that stores a
    # name or a snapshot needs this tenant's data key to exist, and `data_key`
    # raises rather than creating one on demand — a key that appears the first
    # time somebody writes a row is a key whose creation nobody recorded.
    crypto.ensure_key(session, DEMO_TENANT)
    _ensure_platform_key(session)
    # Before anything that records who did it. Every decision and override
    # below is written as one of these accounts, and `service.evaluate` refuses
    # to audit with nobody in scope — so this is an ordering the seed cannot
    # get wrong quietly.
    people = seed_people(session)
    machines = seed_machines(session)
    regimes = declare_demo_regimes(session)
    stage = place_demo_on_the_ladder(session)
    load_packs(session)
    load_assets(session)
    clients = load_clients(session, today)
    decisions = write_history(session, today)
    crossborder = write_crossborder(session, today)
    overrides = write_overrides(session, today)
    # Last, and after the decisions above are written: a published draft adds
    # a future-dated pack row, and seeding it before the history would invite
    # the question of whether any of that history saw it. It cannot — the
    # pack is not effective yet — but the ordering makes that obvious rather
    # than something a reader has to reason about.
    watch_summary = write_watch(session, today)
    record_manual_verifications(session, today)
    session.commit()

    chain = evidence.verify_chain(session)
    print(f"  machines   {len(machines)}")
    print(f"  regimes    {', '.join(regimes) or 'all'} (this firm's licences)")
    print(f"  stage      {stage} (adoption ladder)")
    print(f"  packs      {len(list(PACKS_DIR.glob('*.json')))}")
    print(f"  clients    {clients}")
    print(f"  decisions  {decisions + crossborder} ({crossborder} cross-border)")
    print(f"  overrides  {overrides}")
    print(f"  chain      {'verified' if chain['verified'] else 'BROKEN'} "
          f"({chain['checked']} links)")
    print(f"  watch      {watch_summary['events']} events {watch_summary['by_tier']}")
    print(f"  drafts     AU #{watch_summary['unsigned_draft']} unsigned; "
          f"{watch_summary['pending_pack']}")

    summary = {}
    for row in session.execute(
        text("SELECT outcome, count(*) FROM decisions GROUP BY outcome ORDER BY outcome")
    ):
        summary[row[0]] = row[1]
    print(f"  outcomes   {summary}")

    print(f"\n  sign in with any of these and the password {SEED_PASSWORD!r}:")
    for line in people:
        print(f"    {line}")

    # Anybody holding a role `MFA_REQUIRED_ROLES` names is asked for a six-digit
    # code as well — §S13 enforces that, and the demonstration firm is a
    # correctly configured firm rather than an exception to the control it is
    # demonstrating. The codes are printed because a demo cannot stop while
    # somebody sets up an authenticator app, and they are only good for thirty
    # seconds; the secret is derived from the address, so it survives a reseed.
    codes = _second_factor_codes(session)
    if codes:
        print("\n  these hold privileged roles and need a code as well")
        print("  (valid ~30 seconds — rerun `make seed` or read the secret below):")
        for email, secret, code in codes:
            print(f"    {email:<38} {code}   secret {secret}")


if __name__ == "__main__":
    main()
